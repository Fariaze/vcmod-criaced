VCModels['models/azok30peugeot_308_2.mdl']	=	{
		em_state	=	5236594929,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Copyright	=	"Copyright © 2012-2019 VCMod (freemmaann). All Rights Reserved.",
		Exhaust	=	{
				{
				EffectStress	=	"VC_Exhaust_Stress",
				Invulnerable	=	true,
				EffectIdle	=	"VC_Exhaust",
				Ang	=	Angle(15,-79.400001525879,0),
				Pos	=	Vector(21.879999160767,-85.879997253418,-0.77999997138977),
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(15.819999694824,7.6100001335144,19.819999694824),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(-15.819999694824,-28.590000152588,20.819999694824),
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(15.819999694824,-28.590000152588,20.819999694824),
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(0.81999999284744,-28.590000152588,20.819999694824),
					},
				},
		DLT	=	3491063286,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.02,
						},
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-22.110000610352,88.279998779297,18.309999465942),
				UseDynamic	=	true,
				RenderInner_Size	=	3.9828,
				SpecMLine	=	{
					Amount	=	83,
					Use	=	true,
					LTbl	=	{
							{
							Size	=	0.1,
							Pos	=	Vector(-23.39999961853,87.26000213623,19.760000228882),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.590000152588,86.23999786377,21.209999084473),
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Size	=	0.1,
								},
							{
							Size	=	0.1,
							Pos	=	Vector(-29.10000038147,82.610000610352,22.549999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Size	=	0.1,
							Pos	=	Vector(-31.709999084473,78.98999786377,23.889999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Size	=	0.1,
							Pos	=	Vector(-33.720001220703,75.360000610352,25.229999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.099998474121,71.730003356934,26.569999694824),
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Size	=	1,
								},
							},
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.02,
						},
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(22.110000610352,88.279998779297,18.309999465942),
				UseDynamic	=	true,
				RenderInner_Size	=	3.9828,
				SpecMLine	=	{
					Amount	=	83,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(23.39999961853,87.26000213623,19.760000228882),
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Size	=	0.1,
								},
							{
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Pos	=	Vector(25.590000152588,86.23999786377,21.209999084473),
							Size	=	0.1,
							UseClr	=	false,
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.10000038147,82.610000610352,22.549999237061),
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Size	=	0.1,
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.709999084473,78.98999786377,23.889999389648),
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Size	=	0.1,
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.720001220703,75.360000610352,25.229999542236),
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Size	=	0.1,
								},
							{
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Pos	=	Vector(35.099998474121,71.730003356934,26.569999694824),
							Size	=	1,
							UseClr	=	false,
								},
							},
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Use	=	true,
					UseColor	=	true,
					Pos2	=	Vector(-34.029998779297,79.209999084473,23.299999237061),
					Color	=	{
						r	=	220,
						b	=	255,
						a	=	255,
						g	=	225,
							},
					Pos4	=	Vector(-29.889999389648,79.209999084473,19.159999847412),
					Pos1	=	Vector(-29.889999389648,79.209999084473,23.299999237061),
					Pos3	=	Vector(-34.029998779297,79.209999084473,19.159999847412),
						},
				HBeamColor	=	{
					r	=	255,
					b	=	255,
					a	=	255,
					g	=	255,
						},
				UsePrjTex	=	true,
				Pos	=	Vector(-31.959999084473,79.209999084473,21.229999542236),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Use	=	true,
					UseColor	=	true,
					Pos2	=	Vector(34.029998779297,79.209999084473,23.299999237061),
					Color	=	{
						r	=	220,
						b	=	255,
						a	=	255,
						g	=	225,
							},
					Pos4	=	Vector(29.889999389648,79.209999084473,19.159999847412),
					Pos1	=	Vector(29.889999389648,79.209999084473,23.299999237061),
					Pos3	=	Vector(34.029998779297,79.209999084473,19.159999847412),
						},
				HBeamColor	=	{
					r	=	255,
					b	=	255,
					a	=	255,
					g	=	255,
						},
				UseSprite	=	true,
				Pos	=	Vector(31.959999084473,79.209999084473,21.229999542236),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				UsePrjTex	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Use	=	true,
					UseColor	=	true,
					Pos2	=	Vector(-26.549999237061,82.480003356934,20.299999237061),
					Color	=	{
						r	=	220,
						b	=	255,
						a	=	255,
						g	=	225,
							},
					Pos4	=	Vector(-24.489999771118,82.480003356934,18.239999771118),
					Pos1	=	Vector(-24.489999771118,82.480003356934,20.299999237061),
					Pos3	=	Vector(-26.549999237061,82.480003356934,18.239999771118),
						},
				UseSprite	=	true,
				Pos	=	Vector(-25.520000457764,82.480003356934,19.270000457764),
				UseDynamic	=	true,
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RunningColor	=	{
					r	=	255,
					b	=	255,
					a	=	255,
					g	=	255,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Use	=	true,
					UseColor	=	true,
					Pos2	=	Vector(26.549999237061,82.480003356934,20.299999237061),
					Color	=	{
						r	=	220,
						b	=	255,
						a	=	255,
						g	=	225,
							},
					Pos4	=	Vector(24.489999771118,82.480003356934,18.239999771118),
					Pos1	=	Vector(24.489999771118,82.480003356934,20.299999237061),
					Pos3	=	Vector(26.549999237061,82.480003356934,18.239999771118),
						},
				UseSprite	=	true,
				Pos	=	Vector(25.520000457764,82.480003356934,19.270000457764),
				UseDynamic	=	true,
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RunningColor	=	{
					r	=	255,
					b	=	255,
					a	=	255,
					g	=	255,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_Size	=	3.9828,
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-29.219999313354,87.930000305176,6.1100001335144),
				UseDynamic	=	true,
				seq_stay	=	true,
				SpecMLine	=	{
					Amount	=	31,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-35.240001678467,80.860000610352,8.2600002288818),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				seq_use	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner	=	true,
				RenderInner_Size	=	3.9828,
				UseSprite	=	true,
				Pos	=	Vector(29.219999313354,87.930000305176,6.1100001335144),
				UseDynamic	=	true,
				seq_stay	=	true,
				SpecMLine	=	{
					Amount	=	31,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(35.240001678467,80.860000610352,8.2600002288818),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				seq_use	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Use	=	true,
					Pos2	=	Vector(-32.490001678467,84.279998779297,4.3099999427795),
					Color	=	{
						r	=	220,
						b	=	255,
						a	=	255,
						g	=	225,
							},
					Pos4	=	Vector(-29.329999923706,84.279998779297,1.1499999761581),
					Pos1	=	Vector(-29.329999923706,84.279998779297,4.3099999427795),
					Pos3	=	Vector(-32.490001678467,84.279998779297,1.1499999761581),
						},
				FogColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseSprite	=	true,
				Pos	=	Vector(-30.909999847412,84.279998779297,2.7300000190735),
				UseDynamic	=	true,
				UseFog	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Use	=	true,
					Pos2	=	Vector(32.490001678467,84.279998779297,4.3099999427795),
					Color	=	{
						r	=	220,
						b	=	255,
						a	=	255,
						g	=	225,
							},
					Pos4	=	Vector(29.329999923706,84.279998779297,1.1499999761581),
					Pos1	=	Vector(29.329999923706,84.279998779297,4.3099999427795),
					Pos3	=	Vector(32.490001678467,84.279998779297,1.1499999761581),
						},
				FogColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseSprite	=	true,
				Pos	=	Vector(30.909999847412,84.279998779297,2.7300000190735),
				UseDynamic	=	true,
				UseFog	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.02,
						},
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_Size	=	2,
				UseSprite	=	true,
				Pos	=	Vector(-26.340000152588,-82.779998779297,35.400001525879),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	75,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-25.079999923706,-84.139999389648,32.689998626709),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-23.809999465942,-84.98999786377,29.969999313354),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.02,
						},
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_Size	=	2,
				UseSprite	=	true,
				Pos	=	Vector(-28.979999542236,-81.599998474121,35.909999847412),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	75,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-27.610000610352,-83.230003356934,32.900001525879),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-26.239999771118,-84.230003356934,29.889999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.02,
						},
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(26.340000152588,-82.779998779297,35.400001525879),
				UseDynamic	=	true,
				RenderInner_Size	=	2,
				SpecMLine	=	{
					Amount	=	75,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(25.079999923706,-84.139999389648,32.689998626709),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(23.809999465942,-84.98999786377,29.969999313354),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.02,
						},
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(28.979999542236,-81.599998474121,35.909999847412),
				UseDynamic	=	true,
				RenderInner_Size	=	2,
				SpecMLine	=	{
					Amount	=	75,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(27.610000610352,-83.230003356934,32.900001525879),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(26.239999771118,-84.230003356934,29.889999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.02,
						},
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_Size	=	2,
				UseSprite	=	true,
				Pos	=	Vector(-32.880001068115,-77.660003662109,36.360000610352),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	75,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-31.590000152588,-79.209999084473,36.169998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-31.110000610352,-79.98999786377,35.900001525879),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-30.85000038147,-80.540000915527,35.630001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-30.340000152588,-81.400001525879,34.459999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-29.829999923706,-82.040000915527,33.279998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Size	=	0.1,
							Pos	=	Vector(-28.64999961853,-83.199996948242,30.040000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.02,
						},
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
				UseBrake	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-34.040000915527,-78.720001220703,31.889999389648),
				UseDynamic	=	true,
				RenderInner_Size	=	4,
				SpecMLine	=	{
					Amount	=	75,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-30.389999389648,-81.209999084473,31.729999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.02,
						},
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_Size	=	2,
				UseSprite	=	true,
				Pos	=	Vector(32.880001068115,-77.660003662109,36.360000610352),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	75,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(31.590000152588,-79.209999084473,36.169998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(31.110000610352,-79.98999786377,35.900001525879),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(30.85000038147,-80.540000915527,35.630001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(30.340000152588,-81.400001525879,34.459999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(29.829999923706,-82.040000915527,33.279998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Pos	=	Vector(28.64999961853,-83.199996948242,30.040000915527),
							Size	=	0.1,
							UseClr	=	false,
								},
							},
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.02,
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_Size	=	4,
				UseSprite	=	true,
				Pos	=	Vector(34.040000915527,-78.720001220703,31.889999389648),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	75,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(30.389999389648,-81.209999084473,31.729999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.02,
						},
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
				UseReverse	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-34.040000915527,-78.370002746582,32.939998626709),
				UseDynamic	=	true,
				ReverseColor	=	{
					r	=	255,
					b	=	255,
					a	=	255,
					g	=	255,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				SpecMLine	=	{
					Amount	=	75,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-31.569999694824,-80.120002746582,32.830001831055),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.02,
						},
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
				UseReverse	=	true,
				UseSprite	=	true,
				Pos	=	Vector(34.040000915527,-78.370002746582,32.939998626709),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	75,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(31.569999694824,-80.120002746582,32.830001831055),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				ReverseColor	=	{
					r	=	255,
					b	=	255,
					a	=	255,
					g	=	255,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.02,
						},
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseSprite	=	true,
				Pos	=	Vector(-34.040000915527,-77.01000213623,34.689998626709),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	75,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-31.569999694824,-78.76000213623,34.580001831055),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.02,
						},
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseSprite	=	true,
				Pos	=	Vector(34.040000915527,-77.01000213623,34.689998626709),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	75,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(31.569999694824,-78.76000213623,34.580001831055),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseBlinkers	=	true,
					},
				},
		Date	=	"Thu Jan 24 22:50:47 2019",
		Fuel	=	{
			FuelType	=	0,
				},
		Author	=	"Azok30 (76561198183398967)",
}