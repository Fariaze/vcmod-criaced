-- DurkaTeam @ 2025 Никакие права не защищены
ENT.Base 		= "base_anim"
ENT.Type 		= "anim"
ENT.PrintName	= "Jerry can, diesel, 20 l"
ENT.Author		= "freemmaann"
ENT.Category	= "VCMod"

ENT.Spawnable = true
ENT.AdminSpawnable = true

ENT.VC_Type = "fuel"
ENT.VC_FuelType = 1
ENT.VC_Storage = 20
ENT.VC_MaxStorage = 20
ENT.VC_CanBeDamaged = true