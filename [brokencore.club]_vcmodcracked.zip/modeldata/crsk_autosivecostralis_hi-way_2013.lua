VCModels['models/crsk_autosivecostralis_hi-way_2013.mdl']	=	{
		IsBig	=	true,
		em_state	=	5236594365,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		SocketType	=	1,
		Date	=	"Fri Sep 29 23:59:52 2017",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,90),
				EffectStress	=	"VC_Exhaust_Truck_Stress",
				Pos	=	Vector(-52.139999389648,-9.9200000762939,16.559999465942),
				EffectIdle	=	"VC_Exhaust_Truck",
					},
				},
		UseSocket	=	true,
		Copyright	=	"Copyright © 2012-2017 VCMod (freemmaann). All Rights Reserved.",
		Sound_Backup	=	true,
		ExtraSeats	=	{
				{
				Ang	=	Angle(17,0,0),
				Pos	=	Vector(28.450000762939,89.599998474121,79.440002441406),
				RadioControl	=	true,
					},
				},
		SocketPos	=	Vector(0,-63.819999694824,40.400001525879),
		Sound_Airbrake	=	true,
		DLT	=	3491062910,
		Fuel	=	{
			FuelLidPos	=	Vector(46.959999084473,-43.669998168945,43.770000457764),
			Override	=	true,
			FuelType	=	1,
			Capacity	=	600,
			FuelTypeUse	=	true,
			FuelLidUse	=	true,
				},
		Author	=	"CrushingSkirmish (76561198017348899)",
}