VCModels['models/azok30peugeot_508_gt_2019.mdl']	=	{
		em_state	=	5236594839,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Date	=	"Sun Dec  2 19:18:30 2018",
		Exhaust	=	{
				{
				EffectStress	=	"VC_Exhaust_Stress",
				Invulnerable	=	true,
				EffectIdle	=	"VC_Exhaust",
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-27.340000152588,-118.91000366211,7.6999998092651),
					},
				{
				EffectStress	=	"VC_Exhaust_Stress",
				Invulnerable	=	true,
				EffectIdle	=	"VC_Exhaust",
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(27.340000152588,-118.91000366211,7.6999998092651),
					},
				},
		ExtraSeats	=	{
				{
				Pos	=	Vector(17.020000457764,9.6499996185303,23.079999923706),
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(-19,-32.900001525879,25.260000228882),
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(19,-32.900001525879,25.260000228882),
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(-0.68000000715256,-33.490001678467,25.39999961853),
					},
				},
		DLT	=	3491063226,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-38.549999237061,91.089996337891,27.389999389648),
				UseDynamic	=	true,
				RenderInner_Size	=	2.3276,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-38.270000457764,93.610000610352,21.780000686646),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-38.119998931885,93.970001220703,20.75),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-37.860000610352,94.379997253418,19.879999160767),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-33.080001831055,97.309997558594,9.6400003433228),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				RenderInner_Size	=	2.3276,
				UseSprite	=	true,
				Pos	=	Vector(38.549999237061,91.089996337891,27.389999389648),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(38.270000457764,93.610000610352,21.780000686646),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(38.119998931885,93.970001220703,20.75),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(37.860000610352,94.379997253418,19.879999160767),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(33.080001831055,97.309997558594,9.6400003433228),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(-32.319999694824,92.300003051758,23.75),
					Pos2	=	Vector(-36.560001373291,92.300003051758,27.989999771118),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-32.319999694824,92.300003051758,27.989999771118),
					Pos3	=	Vector(-36.560001373291,92.300003051758,23.75),
						},
				SpecMat	=	{
						},
				RenderInner_Size	=	4,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseSprite	=	true,
				Pos	=	Vector(-34.439998626709,92.300003051758,25.870000839233),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(32.319999694824,92.300003051758,23.75),
					Pos2	=	Vector(36.560001373291,92.300003051758,27.989999771118),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(32.319999694824,92.300003051758,27.989999771118),
					Pos3	=	Vector(36.560001373291,92.300003051758,23.75),
						},
				SpecMat	=	{
						},
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner_Size	=	4,
				UseSprite	=	true,
				Pos	=	Vector(34.439998626709,92.300003051758,25.870000839233),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(-25.930000305176,95.449996948242,22.479999542236),
					Pos2	=	Vector(-30.170000076294,95.449996948242,26.719999313354),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-25.930000305176,95.449996948242,26.719999313354),
					Pos3	=	Vector(-30.170000076294,95.449996948242,22.479999542236),
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-28.049999237061,95.449996948242,24.60000038147),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				HBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UsePrjTex	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(25.930000305176,95.449996948242,22.479999542236),
					Pos2	=	Vector(30.170000076294,95.449996948242,26.719999313354),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(25.930000305176,95.449996948242,26.719999313354),
					Pos3	=	Vector(30.170000076294,95.449996948242,22.479999542236),
						},
				HBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UsePrjTex	=	true,
				Pos	=	Vector(28.049999237061,95.449996948242,24.60000038147),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				SpecMat	=	{
						},
				UseSprite	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseBlinkers	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				seq_stay	=	true,
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				RenderInner_Size	=	4,
				UseSprite	=	true,
				Pos	=	Vector(-23.319999694824,101.55999755859,22.120000839233),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-27.040000915527,100.5,22.510000228882),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-32.930000305176,97.589996337891,24.180000305176),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-37.080001831055,93.75,24.409999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				seq_use	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RenderInner	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				UseBlinkers	=	true,
				RenderInner_Size	=	4,
				UseSprite	=	true,
				Pos	=	Vector(23.319999694824,101.55999755859,22.120000839233),
				UseDynamic	=	true,
				seq_stay	=	true,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(27.040000915527,100.5,22.510000228882),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(32.930000305176,97.589996337891,24.180000305176),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(37.080001831055,93.75,24.409999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				seq_use	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				UseBlinkers	=	true,
				RenderInner_Size	=	4,
				UseSprite	=	true,
				Pos	=	Vector(-44.310001373291,30.860000610352,40.290000915527),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-47.709999084473,27.510000228882,40.590000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-49.950000762939,21.159999847412,41.180000305176),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				RenderInner_Size	=	4,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(44.310001373291,30.860000610352,40.290000915527),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(47.709999084473,27.510000228882,40.590000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(49.950000762939,21.159999847412,41.180000305176),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseBlinkers	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				RenderInner_Size	=	0.7069,
				UseSprite	=	true,
				Pos	=	Vector(-18.329999923706,-116.5299987793,35.560001373291),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-19.180000305176,-115.86000061035,33.599998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				RenderInner_Size	=	0.7069,
				UseSprite	=	true,
				Pos	=	Vector(-19.190000534058,-116.44999694824,35.560001373291),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-20.040000915527,-115.7799987793,33.599998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RenderInner	=	true,
				SpecMat	=	{
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				UseRunning	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-20.090000152588,-116.20999908447,35.560001373291),
				UseDynamic	=	true,
				RenderInner_Size	=	0.7069,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-20.940000534058,-115.54000091553,33.599998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RenderInner	=	true,
				SpecMat	=	{
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				UseRunning	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-21,-116.01000213623,35.560001373291),
				UseDynamic	=	true,
				RenderInner_Size	=	0.7069,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-21.85000038147,-115.33999633789,33.599998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RenderInner	=	true,
				SpecMat	=	{
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				UseRunning	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-24.760000228882,-114.58000183105,35.529998779297),
				UseDynamic	=	true,
				RenderInner_Size	=	0.7069,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-25.610000610352,-113.91000366211,33.569999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RenderInner	=	true,
				SpecMat	=	{
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				UseRunning	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-25.540000915527,-114.11000061035,35.529998779297),
				UseDynamic	=	true,
				RenderInner_Size	=	0.7069,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-26.389999389648,-113.44000244141,33.569999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				RenderInner_Size	=	0.7069,
				UseSprite	=	true,
				Pos	=	Vector(-26.39999961853,-113.84999847412,35.529998779297),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-27.25,-113.18000030518,33.569999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-27.309999465942,-113.58000183105,35.529998779297),
				UseDynamic	=	true,
				RenderInner_Size	=	0.7069,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-28.159999847412,-112.91000366211,33.569999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-31.690000534058,-110.37999725342,35.720001220703),
				UseDynamic	=	true,
				RenderInner_Size	=	0.7069,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-32.540000915527,-109.70999908447,33.759998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RenderInner	=	true,
				SpecMat	=	{
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				UseRunning	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-32.709999084473,-110.23999786377,35.770000457764),
				UseDynamic	=	true,
				RenderInner_Size	=	0.7069,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-33.560001373291,-109.56999969482,33.810001373291),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-33.720001220703,-109.65000152588,35.759998321533),
				UseDynamic	=	true,
				RenderInner_Size	=	0.7069,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-34.569999694824,-108.98000335693,33.799999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-34.790000915527,-108.70999908447,35.560001373291),
				UseDynamic	=	true,
				RenderInner_Size	=	0.7069,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-35.639999389648,-108.04000091553,33.599998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(18.329999923706,-116.5299987793,35.560001373291),
				UseDynamic	=	true,
				RenderInner_Size	=	0.7069,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(19.180000305176,-115.86000061035,33.599998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				RenderInner_Size	=	0.7069,
				UseSprite	=	true,
				Pos	=	Vector(19.190000534058,-116.44999694824,35.560001373291),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(20.040000915527,-115.7799987793,33.599998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RenderInner	=	true,
				SpecMat	=	{
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				UseRunning	=	true,
				UseSprite	=	true,
				Pos	=	Vector(20.090000152588,-116.20999908447,35.560001373291),
				UseDynamic	=	true,
				RenderInner_Size	=	0.7069,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(20.940000534058,-115.54000091553,33.599998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RenderInner	=	true,
				SpecMat	=	{
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				UseRunning	=	true,
				UseSprite	=	true,
				Pos	=	Vector(21,-116.01000213623,35.560001373291),
				UseDynamic	=	true,
				RenderInner_Size	=	0.7069,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(21.85000038147,-115.33999633789,33.599998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RenderInner	=	true,
				SpecMat	=	{
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				UseRunning	=	true,
				UseSprite	=	true,
				Pos	=	Vector(24.760000228882,-114.58000183105,35.529998779297),
				UseDynamic	=	true,
				RenderInner_Size	=	0.7069,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(25.610000610352,-113.91000366211,33.569999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RenderInner	=	true,
				SpecMat	=	{
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				UseRunning	=	true,
				UseSprite	=	true,
				Pos	=	Vector(25.540000915527,-114.11000061035,35.529998779297),
				UseDynamic	=	true,
				RenderInner_Size	=	0.7069,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(26.389999389648,-113.44000244141,33.569999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				RenderInner_Size	=	0.7069,
				UseSprite	=	true,
				Pos	=	Vector(26.39999961853,-113.84999847412,35.529998779297),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(27.25,-113.18000030518,33.569999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(27.309999465942,-113.58000183105,35.529998779297),
				UseDynamic	=	true,
				RenderInner_Size	=	0.7069,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(28.159999847412,-112.91000366211,33.569999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(31.690000534058,-110.37999725342,35.720001220703),
				UseDynamic	=	true,
				RenderInner_Size	=	0.7069,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(32.540000915527,-109.70999908447,33.759998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RenderInner	=	true,
				SpecMat	=	{
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				UseRunning	=	true,
				UseSprite	=	true,
				Pos	=	Vector(32.709999084473,-110.23999786377,35.770000457764),
				UseDynamic	=	true,
				RenderInner_Size	=	0.7069,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(33.560001373291,-109.56999969482,33.810001373291),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(33.720001220703,-109.65000152588,35.759998321533),
				UseDynamic	=	true,
				RenderInner_Size	=	0.7069,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(34.569999694824,-108.98000335693,33.799999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				RenderInner_Size	=	0.7069,
				UseSprite	=	true,
				Pos	=	Vector(34.790000915527,-108.70999908447,35.560001373291),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(35.639999389648,-108.04000091553,33.599998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseReverse	=	true,
				SpecMat	=	{
						},
				RenderInner_Size	=	0.7069,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-32.459999084473,-116.23999786377,12.489999771118),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseSprite	=	true,
				Pos	=	Vector(-27.959999084473,-118.80999755859,12.920000076294),
				UseDynamic	=	true,
				RenderInner	=	true,
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseReverse	=	true,
				SpecMat	=	{
						},
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(32.459999084473,-116.23999786377,12.489999771118),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseSprite	=	true,
				Pos	=	Vector(27.959999084473,-118.80999755859,12.920000076294),
				UseDynamic	=	true,
				RenderInner_Size	=	0.7069,
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RenderInner	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				UseBlinkers	=	true,
				RenderInner_Size	=	1.6379,
				UseSprite	=	true,
				Pos	=	Vector(-19.040000915527,-117.51000213623,32.959999084473),
				UseDynamic	=	true,
				seq_stay	=	true,
				SpecMLine	=	{
					Amount	=	65,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-29.389999389648,-114.12999725342,32.290000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-31.75,-113.33000183105,32.340000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-33.770000457764,-112.41000366211,32.310001373291),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-35.970001220703,-109.79000091553,31.950000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-39.439998626709,-105.79000091553,31.860000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				seq_use	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseBlinkers	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RenderInner_Size	=	1.6379,
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(19.040000915527,-117.51000213623,32.959999084473),
				UseDynamic	=	true,
				seq_stay	=	true,
				SpecMLine	=	{
					Amount	=	65,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(29.389999389648,-114.12999725342,32.290000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(31.75,-113.33000183105,32.340000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(33.770000457764,-112.41000366211,32.310001373291),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(35.970001220703,-109.79000091553,31.950000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(39.439998626709,-105.79000091553,31.860000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				seq_use	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RenderInner_Size	=	2.7759,
				SpecMat	=	{
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-17.139999389648,-116.05000305176,35.380001068115),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	65,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-30.030000686646,-111.48999786377,35.610000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-33.229999542236,-109.05000305176,35.540000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-34.419998168945,-107.87999725342,35.490001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-36.180000305176,-105.91000366211,35.459999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				UseBrake	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(17.139999389648,-116.05000305176,35.380001068115),
				UseDynamic	=	true,
				RenderInner_Size	=	2.7759,
				SpecMLine	=	{
					Amount	=	65,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(30.030000686646,-111.48999786377,35.610000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(33.229999542236,-109.05000305176,35.540000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(34.419998168945,-107.87999725342,35.490001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(36.180000305176,-105.91000366211,35.459999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseBrake	=	true,
				SpecMat	=	{
						},
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-9.8699998855591,-73.230003356934,53.659999847412),
				UseDynamic	=	true,
				RenderInner_Size	=	1.2586,
				SpecMLine	=	{
					Amount	=	65,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(9.7399997711182,-74.120002746582,53.779998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				},
		Copyright	=	"Copyright © 2012-2018 VCMod (freemmaann). All Rights Reserved.",
		Fuel	=	{
			FuelType	=	0,
				},
		Author	=	"Azok30 (76561198183398967)",
}