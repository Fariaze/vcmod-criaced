VCModels['models/crsk_autostofaskartal.mdl']	=	{
		em_state	=	5236594653,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		HealthEnginePosOvr	=	true,
		Date	=	"Wed Aug  8 03:10:45 2018",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(26.959999084473,-95.819999694824,13.109999656677),
				EffectIdle	=	"VC_Exhaust",
					},
				},
		Indication	=	{
			fuel	=	{
				max	=	1,
				pp	=	"fuel_needle",
				top	=	1,
					},
				},
		Copyright	=	"Copyright © 2012-2018 VCMod (freemmaann). All Rights Reserved.",
		HealthEnginePos	=	Vector(0,68.019996643066,35.040000915527),
		DLT	=	3491063102,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-19.819999694824,91.110000610352,26.969999313354),
					UseColor	=	true,
					Pos2	=	Vector(-30.639999389648,91.160003662109,32.950000762939),
					Color	=	{
						r	=	255,
						b	=	100,
						a	=	255,
						g	=	175,
							},
					Use	=	true,
					Pos1	=	Vector(-19.530000686646,90.949996948242,32.900001525879),
					Pos3	=	Vector(-30.559999465942,91.160003662109,26.979999542236),
						},
				SpecMat	=	{
					Select	=	21,
					New	=	"models\crskautos\tofas\dogan\whiteillum_on",
					Use	=	true,
						},
				UseSprite	=	true,
				Pos	=	Vector(-25.079999923706,89.580001831055,29.670000076294),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(19.819999694824,91.110000610352,26.969999313354),
					UseColor	=	true,
					Pos2	=	Vector(30.639999389648,91.160003662109,32.950000762939),
					Color	=	{
						r	=	255,
						b	=	100,
						a	=	255,
						g	=	175,
							},
					Use	=	true,
					Pos1	=	Vector(19.530000686646,90.949996948242,32.900001525879),
					Pos3	=	Vector(30.559999465942,91.160003662109,26.979999542236),
						},
				SpecMat	=	{
					Select	=	22,
					New	=	"models\crskautos\tofas\dogan\redillum_on",
					Use	=	true,
						},
				UseSprite	=	true,
				Pos	=	Vector(25.079999923706,89.580001831055,29.670000076294),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-33.700000762939,90.910003662109,27.709999084473),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(33.700000762939,90.910003662109,27.709999084473),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-22.049999237061,94,13.390000343323),
					UseColor	=	true,
					Pos2	=	Vector(-29.469999313354,94.809997558594,17.360000610352),
					Color	=	{
						r	=	255,
						b	=	100,
						a	=	255,
						g	=	175,
							},
					Use	=	true,
					Pos1	=	Vector(-22.25,95.339996337891,17.059999465942),
					Pos3	=	Vector(-28.889999389648,93.410003662109,13.529999732971),
						},
				FogColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				SpecMat	=	{
						},
				BGroups	=	{
					[8]	=	{
						[0]	=	"protivotumanki",
							},
						},
				UseSprite	=	true,
				Pos	=	Vector(-25.89999961853,94.230003356934,15.470000267029),
				UseDynamic	=	true,
				UseFog	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(22.049999237061,94,13.390000343323),
					UseColor	=	true,
					Pos2	=	Vector(29.469999313354,94.809997558594,17.360000610352),
					Color	=	{
						r	=	255,
						b	=	100,
						a	=	255,
						g	=	175,
							},
					Use	=	true,
					Pos1	=	Vector(22.25,95.339996337891,17.059999465942),
					Pos3	=	Vector(28.889999389648,93.410003662109,13.529999732971),
						},
				FogColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				SpecMat	=	{
						},
				BGroups	=	{
					[8]	=	{
						[0]	=	"protivotumanki",
							},
						},
				UseSprite	=	true,
				Pos	=	Vector(25.89999961853,94.230003356934,15.470000267029),
				UseDynamic	=	true,
				UseFog	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseInter	=	true,
				InterColor	=	{
					r	=	225,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				SpecMat	=	{
						},
				IsInterior	=	true,
				UseSprite	=	true,
				Pos	=	Vector(0,12.159999847412,60.040000915527),
				UseDynamic	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(22.049999237061,94,13.390000343323),
					UseColor	=	true,
					Pos2	=	Vector(29.469999313354,94.809997558594,17.360000610352),
					Color	=	{
						r	=	255,
						b	=	100,
						a	=	255,
						g	=	175,
							},
					Use	=	true,
					Pos1	=	Vector(22.25,95.339996337891,17.059999465942),
					Pos3	=	Vector(28.889999389648,93.410003662109,13.529999732971),
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.35,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-28.799999237061,-93.26000213623,30.110000610352),
					Use	=	true,
					Pos2	=	Vector(-34.810001373291,-93.279998779297,33.650001525879),
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	155,
							},
					UseColor	=	true,
					Pos1	=	Vector(-29.120000839233,-93.169998168945,33.619998931885),
					Pos3	=	Vector(-35.369998931885,-93.230003356934,30.190000534058),
						},
				SpecMat	=	{
					New	=	"models\crskautos\tofas\dogan\whiteillum_on",
					Select	=	22,
						},
				UseSprite	=	true,
				Pos	=	Vector(-32.049999237061,-93.309997558594,31.879999160767),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.35,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(28.799999237061,-93.26000213623,30.110000610352),
					Use	=	true,
					Pos2	=	Vector(34.810001373291,-93.279998779297,33.650001525879),
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	155,
							},
					UseColor	=	true,
					Pos1	=	Vector(29.120000839233,-93.169998168945,33.619998931885),
					Pos3	=	Vector(35.369998931885,-93.230003356934,30.190000534058),
						},
				SpecMat	=	{
					New	=	"models\crskautos\tofas\dogan\whiteillum_on",
					Select	=	22,
						},
				UseSprite	=	true,
				Pos	=	Vector(32.049999237061,-93.309997558594,31.879999160767),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-19.819999694824,91.110000610352,26.969999313354),
					UseColor	=	true,
					Pos2	=	Vector(-30.639999389648,91.160003662109,32.950000762939),
					Color	=	{
						r	=	255,
						b	=	100,
						a	=	255,
						g	=	175,
							},
					Use	=	true,
					Pos1	=	Vector(-19.530000686646,90.949996948242,32.900001525879),
					Pos3	=	Vector(-30.559999465942,91.160003662109,26.979999542236),
						},
				SpecMat	=	{
					New	=	"models\crskautos\tofas\dogan\whiteillum_on",
					Select	=	23,
						},
				HBeamColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				UsePrjTex	=	true,
				Pos	=	Vector(-25.079999923706,89.580001831055,29.670000076294),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				LBeamColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(19.819999694824,91.110000610352,26.969999313354),
					UseColor	=	true,
					Pos2	=	Vector(30.639999389648,91.160003662109,32.950000762939),
					Color	=	{
						r	=	255,
						b	=	100,
						a	=	255,
						g	=	175,
							},
					Use	=	true,
					Pos1	=	Vector(19.530000686646,90.949996948242,32.900001525879),
					Pos3	=	Vector(30.559999465942,91.160003662109,26.979999542236),
						},
				HBeamColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				SpecMat	=	{
					New	=	"models\crskautos\tofas\dogan\whiteillum_on",
					Select	=	23,
						},
				UsePrjTex	=	true,
				Pos	=	Vector(25.079999923706,89.580001831055,29.670000076294),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				LBeamColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.35,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-28.479999542236,-93.26000213623,27.229999542236),
					Use	=	true,
					Pos2	=	Vector(-35.349998474121,-93.279998779297,30.440000534058),
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	80,
							},
					UseColor	=	true,
					Pos1	=	Vector(-28.909999847412,-93.309997558594,30.409999847412),
					Pos3	=	Vector(-35.200000762939,-93.230003356934,27.190000534058),
						},
				SpecMat	=	{
					New	=	"models\crskautos\tofas\dogan\whiteillum_on",
					Select	=	22,
						},
				UseSprite	=	true,
				Pos	=	Vector(-32.049999237061,-93.309997558594,28.670000076294),
				UseDynamic	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.35,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(28.479999542236,-93.26000213623,27.229999542236),
					Use	=	true,
					Pos2	=	Vector(35.349998474121,-93.279998779297,30.440000534058),
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	80,
							},
					UseColor	=	true,
					Pos1	=	Vector(28.909999847412,-93.309997558594,30.409999847412),
					Pos3	=	Vector(35.200000762939,-93.230003356934,27.190000534058),
						},
				SpecMat	=	{
					New	=	"models\crskautos\tofas\dogan\whiteillum_on",
					Select	=	22,
						},
				UseSprite	=	true,
				Pos	=	Vector(32.049999237061,-93.309997558594,28.670000076294),
				UseDynamic	=	true,
				UseRunning	=	true,
				UseBrake	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.35,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-28.030000686646,-93.26000213623,24.069999694824),
					Use	=	true,
					Pos2	=	Vector(-35.319999694824,-93.279998779297,27.479999542236),
					Color	=	{
						r	=	220,
						b	=	255,
						a	=	255,
						g	=	225,
							},
					UseColor	=	true,
					Pos1	=	Vector(-28.440000534058,-93.309997558594,27.590000152588),
					Pos3	=	Vector(-35.200000762939,-93.230003356934,24.209999084473),
						},
				SpecMat	=	{
					New	=	"models\crskautos\tofas\dogan\whiteillum_on",
					Select	=	22,
						},
				UseSprite	=	true,
				Pos	=	Vector(-31.950000762939,-93.309997558594,25.690000534058),
				UseDynamic	=	true,
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.35,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(28.030000686646,-93.26000213623,24.069999694824),
					Use	=	true,
					Pos2	=	Vector(35.319999694824,-93.279998779297,27.479999542236),
					Color	=	{
						r	=	220,
						b	=	255,
						a	=	255,
						g	=	225,
							},
					UseColor	=	true,
					Pos1	=	Vector(28.440000534058,-93.309997558594,27.590000152588),
					Pos3	=	Vector(35.200000762939,-93.230003356934,24.209999084473),
						},
				SpecMat	=	{
					New	=	"models\crskautos\tofas\dogan\whiteillum_on",
					Select	=	22,
						},
				UseSprite	=	true,
				Pos	=	Vector(31.950000762939,-93.309997558594,25.690000534058),
				UseDynamic	=	true,
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(25,0,0),
				Pos	=	Vector(18.530000686646,13.189999580383,28.360000610352),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(20,0,0),
				Pos	=	Vector(-18.530000686646,-24.85000038147,28.39999961853),
					},
				{
				Ang	=	Angle(20,0,0),
				Pos	=	Vector(18.530000686646,-24.85000038147,28.39999961853),
					},
				{
				Ang	=	Angle(20,0,0),
				Pos	=	Vector(0,-24.85000038147,28.39999961853),
					},
				},
		Fuel	=	{
			FuelLidPos	=	Vector(-36.340000152588,-72.089996337891,34.599998474121),
			FuelTypeUse	=	true,
			FuelLidUse	=	true,
			FuelType	=	0,
				},
		Author	=	"CrushingSkirmish (76561198017348899)",
}