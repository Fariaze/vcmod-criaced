VCModels['models/crsk_autosavtovaz2114_trafficpolice.mdl']	=	{
		em_state	=	5236594746,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Siren	=	{
			Sounds	=	{
					{
					Volume	=	1,
					Pitch	=	100,
					Distance	=	95,
					Name	=	"Wail",
					Sound	=	"vcmod/tdmsirens/wail.wav",
						},
					{
					Volume	=	1,
					Pitch	=	100,
					Distance	=	95,
					Name	=	"Yelp",
					Sound	=	"vcmod/tdmsirens/siren2.wav",
						},
					{
					Volume	=	1,
					Pitch	=	100,
					Distance	=	95,
					Name	=	"phaser",
					Sound	=	"vcmod/els/phaser_2.wav",
						},
					},
			Sections_BGroups	=	{
				[8]	=	{
					[0]	=	"migalka",
						},
					},
			Sequences	=	{
					{
					SubSeq	=	{
							{
							Type	=	"Custom",
							Time	=	5,
							Stages	=	{
									{
									Lights	=	{
											1,
											2,
											},
									Time	=	0.3,
										},
									{
									Lights	=	{
											3,
											4,
											},
									Time	=	0.3,
										},
									},
								},
							{
							Type	=	"Custom",
							Time	=	5,
							Stages	=	{
									{
									Lights	=	{
											1,
											2,
											3,
											4,
											},
									Time	=	0.3,
										},
									{
									Lights	=	{
											},
									Time	=	0.3,
										},
									},
								},
							},
					Codes	=	{
							true,
							},
					Lights_Sel	=	{
							true,
							true,
							true,
							true,
							},
						},
					{
					SubSeq	=	{
							{
							Type	=	"Custom",
							Time	=	5,
							Stages	=	{
									{
									Lights	=	{
											1,
											3,
											},
									Time	=	0.12,
										},
									{
									Lights	=	{
											},
									Time	=	0.12,
										},
									{
									Lights	=	{
											1,
											3,
											},
									Time	=	0.12,
										},
									{
									Lights	=	{
											},
									Time	=	0.12,
										},
									{
									Lights	=	{
											2,
											4,
											},
									Time	=	0.12,
										},
									{
									Lights	=	{
											},
									Time	=	0.12,
										},
									{
									Lights	=	{
											2,
											4,
											},
									Time	=	0.12,
										},
									{
									Lights	=	{
											},
									Time	=	0.12,
										},
									},
								},
							{
							Type	=	"Custom",
							Time	=	5,
							Stages	=	{
									{
									Lights	=	{
											3,
											4,
											},
									Time	=	0.12,
										},
									{
									Lights	=	{
											1,
											2,
											},
									Time	=	0.12,
										},
									},
								},
							},
					Codes	=	{
						[2]	=	true,
							},
					Lights_Sel	=	{
							true,
							true,
							true,
							true,
							},
						},
					{
					SubSeq	=	{
							{
							Type	=	"Custom",
							Time	=	3,
							Stages	=	{
									{
									Lights	=	{
											1,
											2,
											4,
											},
									Time	=	0.07,
										},
									{
									Lights	=	{
											3,
											},
									Time	=	0.07,
										},
									},
								},
							{
							Type	=	"Custom",
							Time	=	3,
							Stages	=	{
									{
									Lights	=	{
											},
									Time	=	0.04,
										},
									{
									Lights	=	{
											1,
											4,
											2,
											3,
											},
									Time	=	0.05,
										},
									},
								},
							{
							Type	=	"Custom",
							Time	=	3,
							Stages	=	{
									{
									Lights	=	{
											1,
											2,
											4,
											},
									Time	=	0.07,
										},
									{
									Lights	=	{
											3,
											},
									Time	=	0.07,
										},
									},
								},
							{
							Type	=	"Custom",
							Time	=	3,
							Stages	=	{
									{
									Lights	=	{
											1,
											2,
											},
									Time	=	0.06,
										},
									{
									Lights	=	{
											3,
											4,
											},
									Time	=	0.06,
										},
									},
								},
							},
					Codes	=	{
						[3]	=	true,
							},
					Lights_Sel	=	{
							true,
							true,
							true,
							true,
							},
						},
					{
					SubSeq	=	{
							{
							Type	=	"Custom",
							Time	=	5,
							Stages	=	{
									{
									Lights	=	{
											3,
											4,
											},
									Time	=	0.3,
										},
									{
									Lights	=	{
											1,
											2,
											},
									Time	=	0.3,
										},
									},
								},
							{
							Type	=	"Custom",
							Time	=	5,
							Stages	=	{
									{
									Lights	=	{
											3,
											4,
											},
									Time	=	0.3,
										},
									{
									Lights	=	{
											1,
											2,
											},
									Time	=	0.3,
										},
									},
								},
							},
					Codes	=	{
						[9]	=	true,
							},
					Lights_Sel	=	{
							true,
							true,
							true,
							true,
							},
						},
					},
			Lights	=	{
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.4,
							},
					inner_AsSpheres	=	true,
					SpecRec	=	{
						Use	=	true,
						Pos2	=	Vector(22.120000839233,-7.8099999427795,66.930000305176),
						Pos4	=	Vector(22.450000762939,-7.8299999237061,66.73999786377),
						Pos1	=	Vector(22.440000534058,-7.8200001716614,66.919998168945),
						Pos3	=	Vector(22.120000839233,-7.8200001716614,66.730003356934),
							},
					BGroups	=	{
						[8]	=	{
							[0]	=	"migalka",
								},
							},
					UseDynamic	=	true,
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner_ClrUse	=	false,
					Dynamic	=	{
						Size	=	2,
						Brightness	=	2,
							},
					Spec3D	=	{
						Mat	=	"vcmod/square",
						Pos4	=	Vector(20.799999237061,-7.7699999809265,67.970001220703),
						Pos2	=	Vector(23.690000534058,-7.8699998855591,65.059997558594),
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
						Use	=	true,
						Pos1	=	Vector(20.860000610352,-7.8400001525879,65.120002746582),
						Pos3	=	Vector(23.729999542236,-7.8000001907349,67.959999084473),
							},
					UseSprite	=	true,
					Pos	=	Vector(22.280000686646,-7.8099999427795,66.800003051758),
					SpecModel	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
					RenderInner_Size	=	1,
					Color	=	{
						r	=	0,
						b	=	255,
						a	=	255,
						g	=	55,
							},
					RenderInner	=	true,
					RenderHD_Adv	=	true,
					Beta_Inner3D	=	true,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.4,
							},
					inner_AsSpheres	=	true,
					Dynamic	=	{
						Size	=	2,
						Brightness	=	2,
							},
					SpecRec	=	{
						Use	=	true,
						Pos2	=	Vector(9.7200002670288,-7.6900000572205,66.889999389648),
						Pos4	=	Vector(10.050000190735,-7.710000038147,66.699996948242),
						Pos1	=	Vector(10.039999961853,-7.6999998092651,66.879997253418),
						Pos3	=	Vector(9.7200002670288,-7.6999998092651,66.690002441406),
							},
					UseSprite	=	true,
					Spec3D	=	{
						Mat	=	"vcmod/square",
						Pos4	=	Vector(8.3299999237061,-7.6500000953674,68.029998779297),
						Pos2	=	Vector(11.199999809265,-7.75,65),
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
						Use	=	true,
						Pos1	=	Vector(8.3000001907349,-7.7199997901917,65.099998474121),
						Pos3	=	Vector(11.199999809265,-7.6799998283386,68.029998779297),
							},
					RenderInner_Size	=	1,
					Beta_Inner3D	=	true,
					RenderHD_Adv	=	true,
					Pos	=	Vector(9.8800001144409,-7.6900000572205,66.76000213623),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
						r	=	0,
						b	=	255,
						a	=	255,
						g	=	55,
							},
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					SpecModel	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
					RenderInner_ClrUse	=	false,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.4,
							},
					inner_AsSpheres	=	true,
					SpecRec	=	{
						Pos4	=	Vector(-9.6000003814697,-7.8499999046326,66.389999389648),
						Pos2	=	Vector(-9.2700004577637,-7.8299999237061,66.580001831055),
						Use	=	true,
						Pos1	=	Vector(-9.5900001525879,-7.8400001525879,66.569999694824),
						Pos3	=	Vector(-9.2700004577637,-7.8400001525879,66.379997253418),
							},
					BGroups	=	{
						[8]	=	{
							[0]	=	"migalka",
								},
							},
					UseDynamic	=	true,
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner_ClrUse	=	false,
					Dynamic	=	{
						Size	=	2,
						Brightness	=	2,
							},
					Spec3D	=	{
						Mat	=	"vcmod/square",
						Pos4	=	Vector(-8.1099996566772,-7.789999961853,68.019996643066),
						UseColor	=	true,
						Pos2	=	Vector(-10.989999771118,-7.8899998664856,65.059997558594),
						Color	=	{
							r	=	255,
							b	=	0,
							a	=	255,
							g	=	141,
								},
						Use	=	true,
						Pos1	=	Vector(-8.1400003433228,-7.8600001335144,65.050003051758),
						Pos3	=	Vector(-11.010000228882,-7.8200001716614,68.019996643066),
							},
					UseSprite	=	true,
					Pos	=	Vector(-9.4300003051758,-7.8299999237061,66.449996948242),
					SpecModel	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
					RenderInner	=	true,
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	55,
							},
					RenderInner_Size	=	1,
					Beta_Inner3D	=	true,
					RenderHD_Adv	=	true,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.4,
							},
					inner_AsSpheres	=	true,
					SpecRec	=	{
						Use	=	true,
						Pos2	=	Vector(-21.639999389648,-7.6399998664856,66.620002746582),
						Pos4	=	Vector(-21.969999313354,-7.6599998474121,66.430000305176),
						Pos1	=	Vector(-21.959999084473,-7.6500000953674,66.610000610352),
						Pos3	=	Vector(-21.639999389648,-7.6500000953674,66.419998168945),
							},
					BGroups	=	{
						[8]	=	{
							[0]	=	"migalka",
								},
							},
					UseDynamic	=	true,
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner_ClrUse	=	false,
					Dynamic	=	{
						Size	=	2,
						Brightness	=	2,
							},
					Spec3D	=	{
						Mat	=	"vcmod/square",
						Pos4	=	Vector(-23.5,-7.6999998092651,65.139999389648),
						UseColor	=	true,
						Pos2	=	Vector(-20.569999694824,-7.5999999046326,68.099998474121),
						Color	=	{
							r	=	255,
							b	=	0,
							a	=	255,
							g	=	155,
								},
						Use	=	true,
						Pos1	=	Vector(-23.489999771118,-7.6300001144409,68.150001525879),
						Pos3	=	Vector(-20.620000839233,-7.6700000762939,65.150001525879),
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-21.799999237061,-7.6399998664856,66.48999786377),
					SpecModel	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
					RenderInner	=	true,
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	55,
							},
					RenderInner_Size	=	1,
					Beta_Inner3D	=	true,
					UseSprite	=	true,
						},
					},
			Sounds_Horn	=	{
				Use	=	true,
				Volume	=	1,
				Distance	=	95,
				Pitch	=	50,
				Sound	=	"vcmod/els/smartsiren/horn.wav",
					},
			Codes	=	{
				[13]	=	{
					Include	=	true,
						},
					},
			Sounds_Manual	=	{
				Use	=	true,
				Volume	=	1,
				Distance	=	95,
				Pitch	=	100,
				Sound	=	"vcmod/tdmsirens/wail.wav",
					},
				},
		Date	=	"Sun Apr 14 13:37:47 2019",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(-25.489999771118,-82.819999694824,10.119999885559),
				EffectIdle	=	"VC_Exhaust",
					},
				},
		Indication	=	{
			fuel	=	{
				max	=	1,
				pp	=	"fuel_needle",
				top	=	1,
					},
				},
		Copyright	=	"Copyright © 2012-2019 VCMod (freemmaann). All Rights Reserved.",
		ExtraSeats	=	{
				{
				Ang	=	Angle(22,0,0),
				Pos	=	Vector(16.25,12.369999885559,30.860000610352),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(18,0,0),
				Pos	=	Vector(20.89999961853,-25.110000610352,30.139999389648),
					},
				{
				Ang	=	Angle(18,0,0),
				Pos	=	Vector(-1.1699999570847,-25.110000610352,30.139999389648),
					},
				{
				Ang	=	Angle(18,0,0),
				Pos	=	Vector(-21.620000839233,-25.110000610352,30.139999389648),
					},
				},
		HealthEnginePos	=	Vector(0,77.830001831055,33.189998626709),
		DLT	=	3491063164,
		Lights	=	{
				{
				UseRunning	=	true,
				Pos	=	Vector(-20.270000457764,23.329999923706,43.330001831055),
				SpecMat	=	{
					Select	=	11,
					New	=	"models/crskautos/shared/vmt/white_illum_on",
					Use	=	true,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
					},
				{
				UseRunning	=	true,
				Pos	=	Vector(-16.879999160767,23.329999923706,43.330001831055),
				SpecMat	=	{
					Select	=	16,
					New	=	"models/crskautos/shared/vmt/red_illum_on",
					Use	=	true,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2.1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-18.620000839233,94.459999084473,27.739999771118),
					UseColor	=	true,
					Pos2	=	Vector(-29.14999961853,91.370002746582,31.89999961853),
					Color	=	{
						r	=	255,
						b	=	100,
						a	=	255,
						g	=	192,
							},
					Use	=	true,
					Pos1	=	Vector(-18.360000610352,92.220001220703,31.75),
					Pos3	=	Vector(-29.440000534058,93.430000305176,27.89999961853),
						},
				UseSprite	=	true,
				Pos	=	Vector(-23.909999847412,92.379997253418,30.030000686646),
				UseDynamic	=	true,
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				RunningColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-18.620000839233,94.459999084473,27.739999771118),
					UseColor	=	true,
					Pos2	=	Vector(-29.14999961853,91.370002746582,31.89999961853),
					Color	=	{
						r	=	255,
						b	=	100,
						a	=	255,
						g	=	192,
							},
					Use	=	true,
					Pos1	=	Vector(-18.360000610352,92.220001220703,31.75),
					Pos3	=	Vector(-29.440000534058,93.430000305176,27.89999961853),
						},
				HBeamColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				UsePrjTex	=	true,
				Pos	=	Vector(-23.909999847412,92.379997253418,30.030000686646),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				UseSprite	=	true,
				LBeamColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2.1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(19.069999694824,94.459999084473,27.540000915527),
					UseColor	=	true,
					Pos2	=	Vector(29.60000038147,91.370002746582,31.700000762939),
					Color	=	{
						r	=	255,
						b	=	100,
						a	=	255,
						g	=	192,
							},
					Use	=	true,
					Pos1	=	Vector(18.809999465942,92.220001220703,31.549999237061),
					Pos3	=	Vector(29.889999389648,93.430000305176,27.700000762939),
						},
				UseSprite	=	true,
				Pos	=	Vector(24.360000610352,92.379997253418,29.829999923706),
				UseDynamic	=	true,
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				RunningColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(19.069999694824,94.459999084473,27.540000915527),
					UseColor	=	true,
					Pos2	=	Vector(29.60000038147,91.370002746582,31.700000762939),
					Color	=	{
						r	=	255,
						b	=	100,
						a	=	255,
						g	=	192,
							},
					Use	=	true,
					Pos1	=	Vector(18.809999465942,92.220001220703,31.549999237061),
					Pos3	=	Vector(29.889999389648,93.430000305176,27.700000762939),
						},
				HBeamColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				UsePrjTex	=	true,
				Pos	=	Vector(24.360000610352,92.379997253418,29.829999923706),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				UseSprite	=	true,
				LBeamColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2.1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-22.170000076294,94.900001525879,14.659999847412),
					UseColor	=	true,
					Pos2	=	Vector(-28.25,95.360000610352,18.340000152588),
					Color	=	{
						r	=	255,
						b	=	155,
						a	=	255,
						g	=	206,
							},
					Use	=	true,
					Pos1	=	Vector(-22.14999961853,95.279998779297,18.280000686646),
					Pos3	=	Vector(-28.139999389648,95.01000213623,14.670000076294),
						},
				FogColor	=	{
					r	=	255,
					b	=	155,
					a	=	255,
					g	=	206,
						},
				UseSprite	=	true,
				Pos	=	Vector(-25.139999389648,94.940002441406,16.420000076294),
				UseDynamic	=	true,
				UseFog	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2.1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(22.629999160767,94.779998779297,14.60000038147),
					UseColor	=	true,
					Pos2	=	Vector(28.709999084473,95.23999786377,18.280000686646),
					Color	=	{
						r	=	255,
						b	=	155,
						a	=	255,
						g	=	206,
							},
					Use	=	true,
					Pos1	=	Vector(22.610000610352,95.160003662109,18.219999313354),
					Pos3	=	Vector(28.60000038147,94.889999389648,14.609999656677),
						},
				FogColor	=	{
					r	=	255,
					b	=	155,
					a	=	255,
					g	=	206,
						},
				UseSprite	=	true,
				Pos	=	Vector(25.60000038147,94.819999694824,16.360000610352),
				UseDynamic	=	true,
				UseFog	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
				UseDynamic	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				Pos	=	Vector(33,87.959999084473,29.60000038147),
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
				UseDynamic	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				Pos	=	Vector(-32.509998321533,88.290000915527,29.760000228882),
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.23,
						},
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2.1,
						},
				UseDynamic	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				Pos	=	Vector(-38.130001068115,45.009998321533,28.670000076294),
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.23,
						},
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2.1,
						},
				UseDynamic	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				Pos	=	Vector(38.290000915527,44.869998931885,28.459999084473),
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.28,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2.1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-26.389999389648,-81.639999389648,25.260000228882),
					UseColor	=	true,
					Pos2	=	Vector(-31.159999847412,-81.98999786377,33.349998474121),
					Color	=	{
						r	=	141,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-26.459999084473,-82.190002441406,33.389999389648),
					Pos3	=	Vector(-31.159999847412,-81.610000610352,25.319999694824),
						},
				UseSprite	=	true,
				Pos	=	Vector(-28.840000152588,-81.5,29.379999160767),
				UseDynamic	=	true,
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2.1,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				BGroups	=	{
					[10]	=	{
						[0]	=	"spoiler",
							},
						},
				UseSprite	=	true,
				Pos	=	Vector(-5.6799998283386,-85.910003662109,42.659999847412),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	11,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(5.3699998855591,-85.970001220703,42.650001525879),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				Dynamic	=	{
					Size	=	0.09,
					Brightness	=	2.1,
						},
				UseInter	=	true,
				InterColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				SpecMat	=	{
					Select	=	12,
					New	=	"models/crskautos/avtovaz/2115/st_plafon_on",
					Use	=	true,
						},
				UseSprite	=	true,
				Pos	=	Vector(0.10000000149012,-12.069999694824,60.380001068115),
				UseDynamic	=	true,
				RenderType	=	2,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				DD_Main	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.28,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2.1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(26,-82.01000213623,25.200000762939),
					UseColor	=	true,
					Pos2	=	Vector(30.770000457764,-82.360000610352,33.290000915527),
					Color	=	{
						r	=	141,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(26.069999694824,-82.559997558594,33.330001831055),
					Pos3	=	Vector(30.770000457764,-81.980003356934,25.260000228882),
						},
				UseSprite	=	true,
				Pos	=	Vector(28.549999237061,-81.519996643066,29.200000762939),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2.1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseSprite	=	true,
				Pos	=	Vector(-33.009998321533,-81.120002746582,29.340000152588),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-30.719999313354,-81.309997558594,25.260000228882),
					UseColor	=	true,
					Pos2	=	Vector(-35.490001678467,-80.669998168945,33.349998474121),
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	155,
							},
					Use	=	true,
					Pos1	=	Vector(-30.790000915527,-81.860000610352,33.389999389648),
					Pos3	=	Vector(-35.490001678467,-80.660003662109,25.319999694824),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2.1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(30.360000610352,-81.790000915527,25.170000076294),
					UseColor	=	true,
					Pos2	=	Vector(35.130001068115,-81.150001525879,33.259998321533),
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	155,
							},
					Use	=	true,
					Pos1	=	Vector(30.430000305176,-82.339996337891,33.299999237061),
					Pos3	=	Vector(35.130001068115,-81.139999389648,25.229999542236),
						},
				UseSprite	=	true,
				Pos	=	Vector(32.709999084473,-81.599998474121,29.260000228882),
				UseDynamic	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.52,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2.1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-15.470000267029,-82.790000915527,25.229999542236),
					UseColor	=	true,
					Pos2	=	Vector(-20.239999771118,-83.139999389648,33.319999694824),
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	128,
							},
					Use	=	true,
					Pos1	=	Vector(-15.539999961853,-83.339996337891,33.360000610352),
					Pos3	=	Vector(-20.239999771118,-82.76000213623,25.290000915527),
						},
				UseSprite	=	true,
				Pos	=	Vector(-17.920000076294,-82.650001525879,29.35000038147),
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.52,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2.1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(15.260000228882,-82.790000915527,25.200000762939),
					UseColor	=	true,
					Pos2	=	Vector(20.030000686646,-83.139999389648,33.290000915527),
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	128,
							},
					Use	=	true,
					Pos1	=	Vector(15.329999923706,-83.339996337891,33.330001831055),
					Pos3	=	Vector(20.030000686646,-82.76000213623,25.260000228882),
						},
				UseSprite	=	true,
				Pos	=	Vector(17.709999084473,-82.650001525879,29.319999694824),
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.28,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2.1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-26.389999389648,-81.639999389648,25.260000228882),
					UseColor	=	true,
					Pos2	=	Vector(-31.159999847412,-81.98999786377,33.349998474121),
					Color	=	{
						r	=	141,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-26.459999084473,-82.190002441406,33.389999389648),
					Pos3	=	Vector(-31.159999847412,-81.610000610352,25.319999694824),
						},
				UseSprite	=	true,
				Pos	=	Vector(-28.840000152588,-81.5,29.379999160767),
				UseDynamic	=	true,
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.28,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2.1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-26.389999389648,-81.639999389648,25.260000228882),
					UseColor	=	true,
					Pos2	=	Vector(-31.159999847412,-81.98999786377,33.349998474121),
					Color	=	{
						r	=	141,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-26.459999084473,-82.190002441406,33.389999389648),
					Pos3	=	Vector(-31.159999847412,-81.610000610352,25.319999694824),
						},
				UseSprite	=	true,
				Pos	=	Vector(-28.840000152588,-81.5,29.379999160767),
				UseDynamic	=	true,
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.28,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2.1,
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-27.059999465942,-82.379997253418,25.579999923706),
					UseColor	=	true,
					Pos2	=	Vector(-19.520000457764,-82.779998779297,29.579999923706),
					Color	=	{
						r	=	220,
						b	=	255,
						a	=	255,
						g	=	225,
							},
					Use	=	true,
					Pos1	=	Vector(-19.5,-82.639999389648,25.520000457764),
					Pos3	=	Vector(-26.989999771118,-82.360000610352,29.629999160767),
						},
				UseSprite	=	true,
				Pos	=	Vector(-23.270000457764,-82.190002441406,27.799999237061),
				UseDynamic	=	true,
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.28,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2.1,
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(26.770000457764,-82.379997253418,25.60000038147),
					UseColor	=	true,
					Pos2	=	Vector(19.229999542236,-82.779998779297,29.60000038147),
					Color	=	{
						r	=	220,
						b	=	255,
						a	=	255,
						g	=	225,
							},
					Use	=	true,
					Pos1	=	Vector(19.209999084473,-82.639999389648,25.540000915527),
					Pos3	=	Vector(26.700000762939,-82.360000610352,29.60000038147),
						},
				UseSprite	=	true,
				Pos	=	Vector(22.979999542236,-82.190002441406,27.819999694824),
				UseDynamic	=	true,
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
					},
				},
		HealthEnginePosOvr	=	true,
		Fuel	=	{
			FuelLidPos	=	Vector(36.430000305176,-74.690002441406,29.360000610352),
			FuelTypeUse	=	true,
			FuelType	=	0,
			Capacity	=	43,
			Override	=	true,
			FuelLidUse	=	true,
				},
		Author	=	"CrushingSkirmish (76561198017348899)",
}