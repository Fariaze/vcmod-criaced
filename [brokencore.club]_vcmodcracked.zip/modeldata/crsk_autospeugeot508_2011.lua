VCModels['models/crsk_autospeugeot508_2011.mdl']	=	{
		em_state	=	5236594617,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Date	=	"04/13/17 17:35:23",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(-23.299999237061,-112.15000152588,12.979999542236),
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(22.790000915527,-112.68000030518,12.739999771118),
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(14,0,0),
				Pos	=	Vector(17.760000228882,14.829999923706,32.340000152588),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(1,0,0),
				Pos	=	Vector(-17.760000228882,-29.629999160767,32.119998931885),
					},
				{
				Ang	=	Angle(14,0,0),
				Pos	=	Vector(17.760000228882,-29.35000038147,32.119998931885),
					},
				},
		DLT	=	3491063078,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.0758,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(36.529998779297,89.690002441406,31.629999160767),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	6,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(36.479999542236,89.680000305176,32.729999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.580001831055,89.75,32.169998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.569999694824,89.839996337891,31.110000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.5,89.839996337891,30.579999923706),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.400001525879,89.779998779297,31.10000038147),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.409999847412,89.709999084473,32.159999847412),
								},
							},
						},
				UseRunning	=	true,
				RunningColor	=	{
						229.07,
						237.01,
						243.33,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	1.0821,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.197,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	1.9776,
						},
				UseSprite	=	true,
				LBeamColor	=	{
						227,
						213,
						255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				HBeamColor	=	{
						221,
						225,
						255,
						},
				UsePrjTex	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				Pos	=	Vector(30.719999313354,95.980003356934,29.940000534058),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.197,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	1.9776,
						},
				UseSprite	=	true,
				LBeamColor	=	{
						227,
						213,
						255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UsePrjTex	=	true,
				HBeamColor	=	{
						221,
						225,
						255,
						},
				Pos	=	Vector(-30.35000038147,96.269996643066,30.139999389648),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.45,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				FogColor	=	{
						255,
						255,
						205,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(34.400001525879,95.73999786377,15.859999656677),
				RenderInner	=	true,
				UseFog	=	true,
				RenderInner_Size	=	1,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.45,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				FogColor	=	{
						255,
						255,
						205,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-33.959999084473,95.830001831055,16),
				RenderInner	=	true,
				UseFog	=	true,
				RenderInner_Size	=	1,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.7197,
					Size	=	0.06,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(38.270000457764,95.269996643066,18.840000152588),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	57,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(35.990001678467,98.160003662109,18.360000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.889999389648,99.73999786377,18.030000686646),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.870000839233,101.12999725342,17.659999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.690000534058,102.75,17.360000610352),
								},
							{
							Pos	=	Vector(26.75,104.38999938965,17.159999847412),
							UseClr	=	false,
							Size	=	0.1,
								},
							},
						},
				Dynamic	=	{
					Size	=	0.1119,
					Brightness	=	0.1866,
						},
				RenderInner_Size	=	1,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.7197,
					Size	=	0.06,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-26.229999542236,105.08999633789,17.319999694824),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	57,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-29.659999847412,102.01000213623,17.739999771118),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.530000686646,100.68000030518,17.959999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.639999389648,98.75,18.340000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.389999389648,97.5,18.530000686646),
								},
							{
							Pos	=	Vector(-37.939998626709,95.360000610352,18.950000762939),
							UseClr	=	false,
							Size	=	0.1,
								},
							},
						},
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.1119,
					Brightness	=	0.1866,
						},
				RenderInner_Size	=	1,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.0758,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-35.900001525879,89.690002441406,31.809999465942),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	6,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-35.950000762939,89.680000305176,32.909999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.849998474121,89.75,32.349998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.860000610352,89.839996337891,31.290000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.930000305176,89.839996337891,30.760000228882),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.029998779297,89.779998779297,31.280000686646),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.020000457764,89.709999084473,32.340000152588),
								},
							},
						},
				UseRunning	=	true,
				RunningColor	=	{
						229.07,
						237.01,
						243.33,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	1.0821,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.7197,
					Size	=	0.04,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-47.229999542236,27.469999313354,45.849998474121),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	57,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-47.549999237061,26.479999542236,45.880001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-47.919998168945,25.180000305176,45.880001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-48.040000915527,23.319999694824,45.889999389648),
								},
							},
						},
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.1119,
					Brightness	=	0.1866,
						},
				RenderInner_Size	=	1,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.7197,
					Size	=	0.04,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(47.360000610352,27.120000839233,45.560001373291),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	57,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(48.080001831055,26.129999160767,45.590000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(48.330001831055,24.829999923706,45.590000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(48.409999847412,22.969999313354,45.599998474121),
								},
							},
						},
				Dynamic	=	{
					Size	=	0.1119,
					Brightness	=	0.1866,
						},
				RenderInner_Size	=	1,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.7197,
					Size	=	0.04,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseBrake	=	true,
				UseRunning	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner_Size	=	1,
				UseSprite	=	true,
				Pos	=	Vector(-34.610000610352,-107.41000366211,41.430000305176),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	57,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-34.459999084473,-107.90000152588,40.029998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.229999542236,-108.63999938965,38.279998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34,-109.29000091553,36.490001678467),
								},
							},
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						0,
						0,
						},
				Dynamic	=	{
					Size	=	0.1119,
					Brightness	=	0.1866,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.7197,
					Size	=	0.04,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.1119,
					Brightness	=	0.1866,
						},
				UseSprite	=	true,
				Pos	=	Vector(-34.610000610352,-107.41000366211,41.430000305176),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	57,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-34.459999084473,-107.90000152588,40.029998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.229999542236,-108.63999938965,38.279998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34,-109.29000091553,36.490001678467),
								},
							},
						},
				RenderInner	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.7197,
					Size	=	0.04,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseBrake	=	true,
				UseRunning	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-30.549999237061,-109.66000366211,40.75),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	57,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-30.309999465942,-110.15000152588,39.349998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.030000686646,-110.88999938965,37.599998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.700000762939,-111.54000091553,35.810001373291),
								},
							},
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						0,
						0,
						},
				Dynamic	=	{
					Size	=	0.1119,
					Brightness	=	0.1866,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.7197,
					Size	=	0.04,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseBrake	=	true,
				UseRunning	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-26.629999160767,-111.0299987793,39.590000152588),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	57,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-26.39999961853,-111.51999664307,38.189998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.120000839233,-112.26000213623,36.439998626709),
								},
							{
							Pos	=	Vector(-25.64999961853,-112.91000366211,34.790000915527),
							UseClr	=	true,
							Clr	=	{
									0,
									0,
									0,
									},
								},
							},
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						0,
						0,
						},
				Dynamic	=	{
					Size	=	0.1119,
					Brightness	=	0.1866,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.7197,
					Size	=	0.04,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseRunning	=	true,
				UseBrake	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(34.419998168945,-107.25,41.900001525879),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	57,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(34.200000762939,-108.11000061035,40.430000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.959999084473,-108.87999725342,38.819999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.659999847412,-109.55000305176,36.389999389648),
								},
							},
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						0,
						0,
						},
				Dynamic	=	{
					Size	=	0.1119,
					Brightness	=	0.1866,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.7197,
					Size	=	0.04,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseBrake	=	true,
				UseRunning	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner_Size	=	1,
				UseSprite	=	true,
				Pos	=	Vector(30,-109.7799987793,40.389999389648),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	57,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(29.780000686646,-110.43000030518,38.919998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.540000915527,-110.98999786377,37.310001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.239999771118,-111.44000244141,35.209999084473),
								},
							},
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						0,
						0,
						},
				Dynamic	=	{
					Size	=	0.1119,
					Brightness	=	0.1866,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.7197,
					Size	=	0.04,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseRunning	=	true,
				UseBrake	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(26.370000839233,-111.30999755859,39.419998168945),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	57,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(25.979999542236,-111.95999908447,37.950000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.690000534058,-112.51999664307,36.340000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.340000152588,-112.9700012207,34.689998626709),
								},
							},
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						0,
						0,
						},
				Dynamic	=	{
					Size	=	0.1119,
					Brightness	=	0.1866,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.7197,
					Size	=	0.06,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseReverse	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(29.059999465942,-113.0299987793,18.469999313354),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	57,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(30.510000228882,-111.94000244141,18.379999160767),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.929901123047,-111.79000091553,18.420000076294),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.520000457764,-109.94999694824,18.299999237061),
								},
							},
						},
				Dynamic	=	{
					Size	=	0.1119,
					Brightness	=	0.1866,
						},
				ReverseColor	=	{
						200,
						225,
						255,
						},
				RenderInner	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.7197,
					Size	=	0.06,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseReverse	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-29.540000915527,-113.06999969482,18.569999694824),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	57,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-30.940000534058,-112.48000335693,18.60000038147),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.220001220703,-111.55999755859,18.540000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.979999542236,-110.2200012207,18.5),
								},
							},
						},
				RenderInner	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				Dynamic	=	{
					Size	=	0.1119,
					Brightness	=	0.1866,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.7197,
					Size	=	0.04,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseRunning	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-34.610000610352,-107.41000366211,41.430000305176),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	57,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-34.459999084473,-107.90000152588,40.029998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.229999542236,-108.63999938965,38.279998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34,-109.29000091553,36.490001678467),
								},
							},
						},
				RenderInner	=	true,
				RunningColor	=	{
						255,
						0,
						0,
						},
				Dynamic	=	{
					Size	=	0.1119,
					Brightness	=	0.1866,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.7197,
					Size	=	0.07,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-32.310001373291,-107.7200012207,41.130001068115),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	57,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-32.159999847412,-108.20999908447,39.729999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.930000305176,-108.94999694824,37.979999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.700000762939,-109.59999847412,36.189998626709),
								},
							},
						},
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.1119,
					Brightness	=	0.1866,
						},
				RenderInner_Size	=	1,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.7197,
					Size	=	0.07,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-28.340000152588,-109.9700012207,39.889999389648),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	57,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-28.190000534058,-110.45999908447,38.490001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.860000610352,-111.19999694824,36.740001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.729999542236,-111.62000274658,35.860000610352),
								},
							},
						},
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.1119,
					Brightness	=	0.1866,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.7197,
					Size	=	0.07,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(28.319999694824,-109.33000183105,39.959999084473),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	57,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(28.14999961853,-109.81999969482,38.560001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.829999923706,-110.55999755859,36.810001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.459999084473,-111.12999725342,34.759998321533),
								},
							},
						},
				UseBlinkers	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.1119,
					Brightness	=	0.1866,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.7197,
					Size	=	0.07,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(32.169998168945,-108.16000366211,41.009998321533),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	57,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(32,-108.65000152588,39.610000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.680000305176,-109.38999938965,37.860000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.309999465942,-109.80999755859,35.810001373291),
								},
							},
						},
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.1119,
					Brightness	=	0.1866,
						},
				RenderInner_Size	=	1,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.7197,
					Size	=	0.04,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBrake	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-4.3299999237061,-85.610000610352,50.909999847412),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	57,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-1.5700000524521,-85.949996948242,50.959999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(2.039999961853,-85.720001220703,50.900001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(4.7300000190735,-85.690002441406,50.860000610352),
								},
							},
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.1119,
					Brightness	=	0.1866,
						},
					},
				},
		Copyright	=	"Copyright © 2012-2017 VCMod (freemmaann). All Rights Reserved.",
		Fuel	=	{
			FuelLidPos	=	Vector(39.810001373291,-70.150001525879,40.810001373291),
			FuelType	=	0,
			Capacity	=	72,
			Override	=	true,
			FuelLidUse	=	true,
				},
		Author	=	"CrushingSkirmish (76561198017348899)",
}