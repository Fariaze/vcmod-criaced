VCModels['models/azok30renault_midlum_fpt.mdl']	=	{
		em_state	=	5236594428,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Copyright	=	"Copyright © 2012-2019 VCMod (freemmaann). All Rights Reserved.",
		Exhaust	=	{
				{
				EffectStress	=	"VC_Exhaust_Stress",
				Invulnerable	=	true,
				EffectIdle	=	"VC_Exhaust",
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(25.85000038147,-127.83000183105,10.970000267029),
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(24.659999847412,100.37000274658,61.759998321533),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(-26.549999237061,34.060001373291,62.330001831055),
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(26.549999237061,34.060001373291,62.330001831055),
					},
				{
				Ang	=	Angle(0,-180,0),
				Pos	=	Vector(0.61000001430511,48.849998474121,63.009998321533),
					},
				{
				Ang	=	Angle(0,-180,0),
				Pos	=	Vector(27.110000610352,48.349998474121,63.009998321533),
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(1.0599999427795,34.759998321533,62.330001831055),
					},
				{
				Ang	=	Angle(0,-180,0),
				Pos	=	Vector(-27.110000610352,48.349998474121,63.009998321533),
					},
				},
		DLT	=	3491062952,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Use	=	true,
					Pos2	=	Vector(-33.220001220703,136.64999389648,21.610000610352),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Pos4	=	Vector(-28,136.64999389648,16.389999389648),
					Pos1	=	Vector(-28,136.64999389648,21.610000610352),
					Pos3	=	Vector(-33.220001220703,136.64999389648,16.389999389648),
						},
				UseSprite	=	true,
				Pos	=	Vector(-30.610000610352,136.64999389648,19),
				UseDynamic	=	true,
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Use	=	true,
					Pos2	=	Vector(33.220001220703,136.64999389648,21.610000610352),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Pos4	=	Vector(28,136.64999389648,16.389999389648),
					Pos1	=	Vector(28,136.64999389648,21.610000610352),
					Pos3	=	Vector(33.220001220703,136.64999389648,16.389999389648),
						},
				UseSprite	=	true,
				Pos	=	Vector(30.610000610352,136.64999389648,19),
				UseDynamic	=	true,
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Use	=	true,
					Pos2	=	Vector(-39.639999389648,136.53999328613,21.610000610352),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Pos4	=	Vector(-34.419998168945,136.53999328613,16.389999389648),
					Pos1	=	Vector(-34.419998168945,136.53999328613,21.610000610352),
					Pos3	=	Vector(-39.639999389648,136.53999328613,16.389999389648),
						},
				HBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseSprite	=	true,
				Pos	=	Vector(-37.029998779297,136.53999328613,19),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				UsePrjTex	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Use	=	true,
					Pos2	=	Vector(39.639999389648,136.53999328613,21.610000610352),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Pos4	=	Vector(34.419998168945,136.53999328613,16.389999389648),
					Pos1	=	Vector(34.419998168945,136.53999328613,21.610000610352),
					Pos3	=	Vector(39.639999389648,136.53999328613,16.389999389648),
						},
				HBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseSprite	=	true,
				Pos	=	Vector(37.029998779297,136.53999328613,19),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				UsePrjTex	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseSprite	=	true,
				Pos	=	Vector(-42.709999084473,131.27000427246,18.959999084473),
				UseDynamic	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Use	=	true,
					Pos2	=	Vector(-42.759998321533,128.67999267578,21.569999694824),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Pos4	=	Vector(-42.659999847412,133.36000061035,16.35000038147),
					Pos1	=	Vector(-42.659999847412,133.36000061035,21.569999694824),
					Pos3	=	Vector(-42.759998321533,128.67999267578,16.35000038147),
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseSprite	=	true,
				Pos	=	Vector(42.709999084473,131.27000427246,18.959999084473),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Use	=	true,
					Pos2	=	Vector(42.759998321533,128.67999267578,21.569999694824),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Pos4	=	Vector(42.659999847412,133.36000061035,16.35000038147),
					Pos1	=	Vector(42.659999847412,133.36000061035,21.569999694824),
					Pos3	=	Vector(42.759998321533,128.67999267578,16.35000038147),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				Pos	=	Vector(-40.840000152588,-131.61000061035,15.170000076294),
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				Pos	=	Vector(40.840000152588,-131.61000061035,15.170000076294),
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseSprite	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				Pos	=	Vector(-38.069999694824,-131.61000061035,15.170000076294),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseSprite	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				Pos	=	Vector(38.069999694824,-131.61000061035,15.170000076294),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				UseBrake	=	true,
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
				UseSprite	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				Pos	=	Vector(-35.330001831055,-131.61000061035,15.170000076294),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				UseBrake	=	true,
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
				UseSprite	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				Pos	=	Vector(35.330001831055,-131.61000061035,15.170000076294),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
				UseReverse	=	true,
				Pos	=	Vector(-33.229999542236,-131.61000061035,15.170000076294),
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseDynamic	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
				UseReverse	=	true,
				Pos	=	Vector(33.229999542236,-131.61000061035,15.170000076294),
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseDynamic	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				UseSprite	=	true,
					},
				},
		Date	=	"Sun Jan 20 01:20:36 2019",
		Fuel	=	{
			FuelType	=	1,
				},
		Author	=	"Azok30 (76561198183398967)",
}