VCModels['models/crsk_autosvolkswagenkarmann_ghia.mdl']	=	{
		em_state	=	5236594590,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		HealthEnginePosOvr	=	true,
		Date	=	"02/15/17 01:43:38",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(8.210000038147,-100.80999755859,8.7200002670288),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-8.6999998092651,-100.80999755859,8.7200002670288),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		Copyright	=	"Copyright © 2012-2017 VCMod (freemmaann). All Rights Reserved.",
		HealthEnginePos	=	Vector(2.1400001049042,-73.650001525879,38.529998779297),
		DLT	=	3491063060,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-26.670000076294,94.080001831055,25.809999465942),
					UseColor	=	true,
					Pos2	=	Vector(-37,94,36.669998168945),
					Color	=	{
							255,
							225,
							200,
							},
					Use	=	true,
					Pos1	=	Vector(-25.739999771118,94,36.020000457764),
					Pos3	=	Vector(-37.340000152588,94.01000213623,25.670000076294),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-31.479999542236,94.019996643066,30.409999847412),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseSprite	=	true,
				RunningColor	=	{
						255,
						175,
						100,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-26.170000076294,93.949996948242,25.049999237061),
					UseColor	=	true,
					Pos2	=	Vector(-37.389999389648,93.949996948242,35.979999542236),
					Color	=	{
							255,
							225,
							200,
							},
					Use	=	true,
					Pos1	=	Vector(-25.930000305176,94.169998168945,36.990001678467),
					Pos3	=	Vector(-36.630001068115,93.949996948242,25.049999237061),
						},
				SpecMat	=	{
						},
				HBeamColor	=	{
						255,
						175,
						155,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				Beta_Inner3D	=	true,
				LBeamColor	=	{
						255,
						175,
						155,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-31.39999961853,93.949996948242,30.280000686646),
				UsePrjTex	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-31.159999847412,92.889999389648,22.35000038147),
				UseDynamic	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(26.670000076294,94.080001831055,25.809999465942),
					UseColor	=	true,
					Pos2	=	Vector(37,94,36.669998168945),
					Color	=	{
							255,
							225,
							200,
							},
					Use	=	true,
					Pos1	=	Vector(26.319999694824,94,35.720001220703),
					Pos3	=	Vector(37.479999542236,94.01000213623,25.770000457764),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(31.479999542236,94.019996643066,30.409999847412),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseSprite	=	true,
				RunningColor	=	{
						255,
						175,
						100,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(26.700000762939,94.349998474121,25.129999160767),
					UseColor	=	true,
					Pos2	=	Vector(37.139999389648,94.059997558594,36.799999237061),
					Color	=	{
							255,
							225,
							200,
							},
					Use	=	true,
					Pos1	=	Vector(26.049999237061,93.709999084473,36.490001678467),
					Pos3	=	Vector(37.540000915527,94.300003051758,25.450000762939),
						},
				HBeamColor	=	{
						255,
						175,
						155,
						},
				SpecMat	=	{
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseSprite	=	true,
				LBeamColor	=	{
						255,
						175,
						155,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(31.39999961853,94.360000610352,30.280000686646),
				UsePrjTex	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(31.5,92.889999389648,22.35000038147),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				SpecRec	=	{
					Use	=	true,
					Mid	=	true,
					AmountH	=	3,
					Pos1	=	Vector(-23.379999160767,-96.790000915527,19.14999961853),
					AmountV	=	2,
					Mid_V	=	true,
					Pos2	=	Vector(-27.540000915527,-95.629997253418,19.14999961853),
					Pos4	=	Vector(-23.530000686646,-95.940002441406,17.020000457764),
					Pos3	=	Vector(-27.469999313354,-95.889999389648,16.780000686646),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-25.469999313354,-97.699996948242,17.889999389648),
				UseDynamic	=	true,
				RenderMLCenter	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/rectangle_rounded_2x8_texture",
					Pos4	=	Vector(-23.379999160767,-97.440002441406,17.079999923706),
					UseColor	=	true,
					Pos2	=	Vector(-27.989999771118,-96.730003356934,19.14999961853),
					Color	=	{
							255,
							255,
							255,
							},
					Use	=	true,
					Pos1	=	Vector(-23.379999160767,-97.48999786377,19.14999961853),
					Pos3	=	Vector(-27.889999389648,-96.779998779297,17.10000038147),
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(33.450000762939,-94.650001525879,23.629999160767),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderInner_Size	=	1,
				RenderMLCenter	=	true,
				Beta_Inner3D	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-33.770000457764,-94.650001525879,23.629999160767),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				RenderInner	=	true,
				UseBlinkers	=	true,
				UseSprite	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-33.639999389648,-94.230003356934,25.739999771118),
				UseDynamic	=	true,
				RenderMLCenter	=	true,
				UseRunning	=	true,
				UseSprite	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(33.290000915527,-94.370002746582,25.5),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				UseSprite	=	true,
				RenderMLCenter	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-33.590000152588,-93.790000915527,28.700000762939),
				UseDynamic	=	true,
				RenderMLCenter	=	true,
				UseBrake	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(33.270000457764,-93.620002746582,28.120000839233),
				UseDynamic	=	true,
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				UseSprite	=	true,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				SpecRec	=	{
					Pos4	=	Vector(27.170000076294,-96.709999084473,16.89999961853),
					Mid	=	true,
					AmountH	=	3,
					Pos1	=	Vector(27.319999694824,-97.559997558594,19.030000686646),
					AmountV	=	2,
					Mid_V	=	true,
					Pos2	=	Vector(23.159999847412,-96.400001525879,19.030000686646),
					Use	=	true,
					Pos3	=	Vector(23.229999542236,-96.660003662109,16.659999847412),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(25.229999542236,-98.470001220703,17.770000457764),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				ReverseColor	=	{
						200,
						225,
						255,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/rectangle_rounded_2x8_texture",
					Pos4	=	Vector(27.610000610352,-96.870002746582,16.959999084473),
					UseColor	=	true,
					Pos2	=	Vector(22.940000534058,-97.5,19.030000686646),
					Color	=	{
							255,
							255,
							255,
							},
					Use	=	true,
					Pos1	=	Vector(27.670000076294,-96.870002746582,19.030000686646),
					Pos3	=	Vector(22.979999542236,-97.550003051758,16.979999542236),
						},
				RenderMLCenter	=	true,
				UseSprite	=	true,
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(12,0,0),
				Pos	=	Vector(15.75,14.029999732971,32.180000305176),
					},
				{
				Ang	=	Angle(16,0,0),
				Pos	=	Vector(-15.75,-17.770000457764,29.790000915527),
					},
				{
				Ang	=	Angle(16,0,0),
				Pos	=	Vector(15.75,-17.770000457764,29.790000915527),
					},
				},
		Fuel	=	{
			FuelType	=	0,
			Capacity	=	40,
			Override	=	true,
				},
		Author	=	"CrushingSkirmish (76561198017348899)",
}