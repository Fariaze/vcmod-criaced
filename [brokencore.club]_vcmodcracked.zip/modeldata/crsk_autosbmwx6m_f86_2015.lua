VCModels['models/crsk_autosbmwx6m_f86_2015.mdl']	=	{
		em_state	=	5236594557,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		HealthEnginePosOvr	=	true,
		Date	=	"Tue Oct 16 18:44:27 2018",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(-24.829999923706,-111.16000366211,18.809999465942),
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(24.299999237061,-111.16000366211,18.809999465942),
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(-19.790000915527,-111.16000366211,18.809999465942),
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(19.270000457764,-111.16000366211,18.809999465942),
				EffectIdle	=	"VC_Exhaust",
					},
				},
		Indication	=	{
			fuel	=	{
				max	=	1,
				pp	=	"fuel_needle",
				top	=	1,
					},
				},
		Copyright	=	"Copyright © 2012-2018 VCMod (freemmaann). All Rights Reserved.",
		HealthEnginePos	=	Vector(0,98.720001220703,50.740001678467),
		DLT	=	3491063038,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	4,
					Size	=	0.06,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				DD_HD	=	true,
				RenderMLCenter	=	true,
				SpecMat	=	{
					Use	=	true,
					New	=	"models\crskautos\bmw\x6m_f86_2015\interior_symbols2_illum_on",
					Select	=	24,
						},
				RunningColor	=	{
					r	=	180,
					b	=	255,
					a	=	255,
					g	=	180,
						},
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-40.400001525879,110.83999633789,46.5),
				RenderInner	=	true,
				RenderInner_Size	=	1.0172,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-40.754001617432,110.83699798584,45.970001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-40.976001739502,110.83699798584,45.43399810791),
								},
							{
							Pos	=	Vector(-41.130001068115,110.83999633789,44.900001525879),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-41.159999847412,110.83999633789,44.279998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-41.130001068115,110.83999633789,43.680000305176),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-41,110.83999633789,43.110000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-40.740001678467,110.83999633789,42.389999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-40.229999542236,110.83999633789,41.700000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-39.040000915527,110.83999633789,40.799999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-35.810001373291,110.83999633789,40.810001373291),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-34.860000610352,110.83999633789,41.599998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-34.360000610352,110.83999633789,42.180000305176),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-33.939998626709,110.83999633789,43.060001373291),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-33.819999694824,110.83999633789,44.009998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Pos	=	Vector(-33.919998168945,110.83999633789,44.939998626709),
							UseClr	=	false,
							Size	=	0.1,
								},
							{
							Size	=	0.1,
							Pos	=	Vector(-34.169998168945,110.83999633789,45.590000152588),
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							UseClr	=	false,
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.580001831055,110.83000183105,46.340000152588),
							Size	=	0.1,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.06,
						},
				SpecSpin	=	{
						},
				DD_HD	=	true,
				DD_Blnk_Run	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models/tdmcars/bmw_340i/lights_on_a",
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-27.610000610352,120.19000244141,45.900001525879),
				RenderMLCenter	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	35,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-29.459999084473,119.01000213623,46.119998931885),
							Size	=	1,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.290000915527,117.16999816895,46.419998168945),
							Size	=	1,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Size	=	1,
							Pos	=	Vector(-35.080001831055,115.29000091553,46.770000457764),
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							UseClr	=	false,
								},
							{
							Size	=	1,
							Pos	=	Vector(-37.5,113.38999938965,46.939998626709),
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							UseClr	=	false,
								},
							{
							Size	=	1,
							Pos	=	Vector(-40.279998779297,110.84999847412,47.209999084473),
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							UseClr	=	false,
								},
							},
						},
				RenderInner	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.5,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-33.110000610352,108.45999908447,39.900001525879),
					UseColor	=	true,
					Pos2	=	Vector(-42.009998321533,108.45999908447,47.909999847412),
					Color	=	{
						r	=	200,
						b	=	200,
						a	=	255,
						g	=	200,
							},
					Use	=	true,
					Pos1	=	Vector(-33.5,108.45999908447,48.169998168945),
					Pos3	=	Vector(-41.270000457764,108.45999908447,39.930000305176),
						},
				HBeamColor	=	{
					r	=	180,
					b	=	255,
					a	=	255,
					g	=	180,
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-37.599998474121,109.66000366211,44.189998626709),
				RenderInner	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.5,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-24.299999237061,114.90000152588,40.110000610352),
					UseColor	=	true,
					Pos2	=	Vector(-33.110000610352,114.90000152588,47.450000762939),
					Color	=	{
						r	=	200,
						b	=	200,
						a	=	255,
						g	=	200,
							},
					Use	=	true,
					Pos1	=	Vector(-24.229999542236,114.90000152588,46.590000152588),
					Pos3	=	Vector(-33.259998321533,114.90000152588,40.069999694824),
						},
				SpecMat	=	{
						},
				HBeamColor	=	{
					r	=	180,
					b	=	255,
					a	=	255,
					g	=	180,
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				UseSprite	=	true,
				LBeamColor	=	{
					r	=	180,
					b	=	255,
					a	=	255,
					g	=	180,
						},
				RenderMLCenter	=	true,
				UseHighBeams	=	true,
				RenderInner	=	true,
				Pos	=	Vector(-29.25,116.09999847412,43.459999084473),
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	4,
					Size	=	0.06,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				DD_HD	=	true,
				SpecMat	=	{
					Use	=	true,
					New	=	"models\crskautos\bmw\x6m_f86_2015\priborka_on",
					Select	=	29,
						},
				RenderMLCenter	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(40.970001220703,110.83999633789,46.5),
				RunningColor	=	{
					r	=	180,
					b	=	255,
					a	=	255,
					g	=	180,
						},
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(41.324001312256,110.83699798584,45.970001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(41.546001434326,110.83699798584,45.43399810791),
								},
							{
							Pos	=	Vector(41.700000762939,110.83999633789,44.900001525879),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(41.729999542236,110.83999633789,44.279998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(41.700000762939,110.83999633789,43.680000305176),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(41.569999694824,110.83999633789,43.110000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(41.310001373291,110.83999633789,42.389999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(40.799999237061,110.83999633789,41.700000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(39.610000610352,110.83999633789,40.799999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(36.380001068115,110.83999633789,40.810001373291),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(35.430000305176,110.83999633789,41.599998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(34.930000305176,110.83999633789,42.180000305176),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(34.509998321533,110.83999633789,43.060001373291),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(34.389999389648,110.83999633789,44.009998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.490001678467,110.83999633789,44.939998626709),
							Size	=	0.1,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Pos	=	Vector(34.740001678467,110.83999633789,45.590000152588),
							UseClr	=	false,
							Size	=	0.1,
								},
							{
							Size	=	0.1,
							Pos	=	Vector(35.150001525879,110.83000183105,46.340000152588),
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							UseClr	=	false,
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.5,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(33.970001220703,108.45999908447,39.669998168945),
					UseColor	=	true,
					Pos2	=	Vector(42.869998931885,108.45999908447,47.680000305176),
					Color	=	{
						r	=	200,
						b	=	200,
						a	=	255,
						g	=	200,
							},
					Use	=	true,
					Pos1	=	Vector(34.360000610352,108.45999908447,47.939998626709),
					Pos3	=	Vector(42.130001068115,108.45999908447,39.700000762939),
						},
				SpecMat	=	{
					New	=	"models\crskautos\bmw\x6m_f86_2015\priborka_on",
					Select	=	29,
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(38.459999084473,109.66000366211,43.959999084473),
				RenderInner	=	true,
				RenderMLCenter	=	true,
				HBeamColor	=	{
					r	=	180,
					b	=	255,
					a	=	255,
					g	=	180,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				DD_HD	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	200,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-47.770000457764,107.73000335693,32.979999542236),
				SpecMLine	=	{
					Amount	=	16,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-47.849998474121,106.20999908447,35.5),
							Size	=	1,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-48.110000610352,104.73000335693,37.259998321533),
							Size	=	1,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Pos	=	Vector(-48.310001373291,103.06999969482,38.740001678467),
							UseClr	=	false,
							Size	=	1,
								},
							{
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Pos	=	Vector(-48.369998931885,101.19000244141,40.130001068115),
							UseClr	=	false,
							Size	=	1,
								},
							{
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Pos	=	Vector(-48.5,99.349998474121,41.330001831055),
							UseClr	=	false,
							Size	=	1,
								},
							},
						},
				UseBlinkers	=	true,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.04,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	200,
						},
				SpecMat	=	{
						},
				RenderMLCenter	=	true,
				UseBlinkers	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-41.810001373291,109.79000091553,44.25),
				RenderInner	=	true,
				RenderInner_Size	=	3,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Pos	=	Vector(-43.080001831055,108.58000183105,44.279998779297),
							Size	=	0.1,
							UseClr	=	false,
								},
							{
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Pos	=	Vector(-43.790000915527,107.33000183105,44.340000152588),
							Size	=	0.1,
							UseClr	=	false,
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-44.470001220703,104.30999755859,44.479999542236),
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Size	=	0.1,
								},
							},
						},
				UseSprite	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.04,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	200,
						},
				SpecMat	=	{
						},
				RenderMLCenter	=	true,
				UseBlinkers	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(42.529998779297,109.79000091553,44.069999694824),
				RenderInner_Size	=	3,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							Size	=	0.1,
							Pos	=	Vector(43.799999237061,108.58000183105,44.099998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Size	=	0.1,
							Pos	=	Vector(44.509998321533,107.33000183105,44.159999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Pos	=	Vector(45.189998626709,104.30999755859,44.299999237061),
							Size	=	0.1,
							UseClr	=	false,
								},
							},
						},
				UseSprite	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.5,
						},
				SpecSpin	=	{
						},
				DD_HD	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-27.079999923706,123.12999725342,30.510000228882),
					UseColor	=	true,
					Pos2	=	Vector(-31.89999961853,121.7799987793,35.330001831055),
					Color	=	{
						r	=	200,
						b	=	200,
						a	=	255,
						g	=	200,
							},
					Use	=	true,
					Pos1	=	Vector(-27.079999923706,123.01000213623,35.330001831055),
					Pos3	=	Vector(-31.89999961853,121.90000152588,30.510000228882),
						},
				FogColor	=	{
					r	=	180,
					b	=	255,
					a	=	255,
					g	=	180,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-29.489999771118,122.90000152588,32.919998168945),
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				UseFog	=	true,
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				DD_HD	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(27.700000762939,123.12999725342,30.510000228882),
					UseColor	=	true,
					Pos2	=	Vector(32.520000457764,121.7799987793,35.330001831055),
					Color	=	{
						r	=	200,
						b	=	200,
						a	=	255,
						g	=	200,
							},
					Use	=	true,
					Pos1	=	Vector(27.700000762939,123.01000213623,35.330001831055),
					Pos3	=	Vector(32.520000457764,121.90000152588,30.510000228882),
						},
				FogColor	=	{
					r	=	180,
					b	=	255,
					a	=	255,
					g	=	180,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(30.110000610352,122.90000152588,32.919998168945),
				RenderInner_Size	=	1,
				UseFog	=	true,
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	180,
						},
				SpecMat	=	{
					New	=	"models/tdmcars/bmw_340i/lights_on_a",
						},
				RenderMLCenter	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-49.759998321533,42.130001068115,60.689998626709),
				UseBlinkers	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Pos	=	Vector(-53.299999237061,40.310001373291,60.729999542236),
							Size	=	0.1,
							UseClr	=	false,
								},
							{
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Pos	=	Vector(-54.130001068115,39.330001831055,60.75),
							Size	=	0.1,
							UseClr	=	false,
								},
							{
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Pos	=	Vector(-55.040000915527,37.819999694824,60.909999847412),
							Size	=	0.1,
							UseClr	=	false,
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-55.349998474121,35.5,61.020000457764),
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Size	=	0.1,
								},
							},
						},
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	180,
						},
				SpecMat	=	{
					New	=	"models/tdmcars/bmw_340i/lights_on_a",
						},
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(48.729999542236,42.130001068115,60.349998474121),
				RenderMLCenter	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							Size	=	0.1,
							Pos	=	Vector(52.270000457764,40.310001373291,60.389999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Size	=	0.1,
							Pos	=	Vector(53.689998626709,39.590000152588,60.409999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Size	=	0.1,
							Pos	=	Vector(55.330001831055,37.819999694824,60.569999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Pos	=	Vector(55.709999084473,35.5,60.680000305176),
							Size	=	0.1,
							UseClr	=	false,
								},
							},
						},
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.12,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
					New	=	"models/tdmcars/bmw_340i/lights_on_r",
						},
				ReducedVis	=	true,
				UseRunning	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-33.610000610352,-106.58999633789,53.689998626709),
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	60,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-34.720001220703,-105.98000335693,53.830001831055),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-35.729999542236,-105.5,53.990001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-36.709999084473,-105.0299987793,54.389999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-37.189998626709,-104.56999969482,55.110000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-37.529998779297,-104.08999633789,55.799999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-37.689998626709,-103.94000244141,56.209999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-38.439998626709,-102.98000335693,56.240001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-39.509998321533,-101.41000366211,56.200000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-40.770000457764,-99.519996643066,56.209999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-41.470001220703,-95.220001220703,56.069999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-41.450000762939,-96.599998474121,55.229999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-41.159999847412,-97.550003051758,54.270000457764),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-41.099998474121,-99.029998779297,53.5),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-40.770000457764,-100.06999969482,52.939998626709),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-40.380001068115,-100.98000335693,52.580001831055),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-39.930000305176,-102.11000061035,52.340000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-39.319999694824,-103.01000213623,52.020000457764),
								},
							{
							Pos	=	Vector(-38.459999084473,-103.87000274658,51.759998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.259998321533,-104.73999786377,51.619998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.132999420166,-105.41200256348,51.602001190186),
								},
							{
							Pos	=	Vector(-35.319999694824,-105.84999847412,51.540000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-34.119998931885,-106.38999938965,51.430000305176),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Size	=	0.1,
							Pos	=	Vector(-33.220001220703,-106.76999664307,51.409999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderMLCenter	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	50,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.12,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseRunning	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-31.510000228882,-107.37999725342,53.450000762939),
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							Size	=	0.1,
							Pos	=	Vector(-23.090000152588,-109.23999786377,52.759998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderMLCenter	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	50,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.12,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(31.049999237061,-106.2200012207,51.330001831055),
				SpecMLine	=	{
					Amount	=	15,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(23.030000686646,-107.33000183105,50.869998931885),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderMLCenter	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	50,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.12,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseRunning	=	true,
				UseSprite	=	true,
				Pos	=	Vector(31.510000228882,-107.51000213623,53.450000762939),
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(22.860000610352,-108.66000366211,52.840000152588),
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Size	=	0.1,
								},
							},
						},
				RenderMLCenter	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	50,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.12,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
					New	=	"models/tdmcars/bmw_340i/lights_on_r",
						},
				ReducedVis	=	true,
				UseRunning	=	true,
				UseSprite	=	true,
				Pos	=	Vector(33.610000610352,-106.58999633789,53.689998626709),
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	60,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(34.720001220703,-105.98000335693,53.830001831055),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(35.729999542236,-105.5,53.990001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(36.709999084473,-105.0299987793,54.389999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(37.189998626709,-104.56999969482,55.110000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(37.529998779297,-104.08999633789,55.799999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(37.689998626709,-103.94000244141,56.209999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(38.439998626709,-102.98000335693,56.240001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(39.509998321533,-101.41000366211,56.200000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(40.770000457764,-99.519996643066,56.209999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(41.470001220703,-95.220001220703,56.069999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(41.450000762939,-96.599998474121,55.229999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(41.159999847412,-97.550003051758,54.270000457764),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(41.099998474121,-99.029998779297,53.5),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(40.770000457764,-100.06999969482,52.939998626709),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(40.380001068115,-100.98000335693,52.580001831055),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							UseClr	=	false,
							Pos	=	Vector(39.930000305176,-102.11000061035,52.340000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(39.319999694824,-103.01000213623,52.020000457764),
								},
							{
							Pos	=	Vector(38.459999084473,-103.87000274658,51.759998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.259998321533,-104.73999786377,51.619998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.132999420166,-105.41200256348,51.602001190186),
								},
							{
							Pos	=	Vector(35.319999694824,-105.84999847412,51.540000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(34.119998931885,-106.38999938965,51.430000305176),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.220001220703,-106.76999664307,51.409999847412),
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Size	=	0.1,
								},
							},
						},
				RenderMLCenter	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	50,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.12,
						},
				SpecSpin	=	{
						},
				RenderMLCenter	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecMat	=	{
					New	=	"models/tdmcars/bmw_340i/lights_on_r",
						},
				UseBrake	=	true,
				UseRunning	=	true,
				RenderHD_Adv	=	true,
				Pos	=	Vector(-31.180000305176,-107.13999938965,51.790000915527),
				UseSprite	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	15,
					Use	=	true,
					LTbl	=	{
							{
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Pos	=	Vector(-24.170000076294,-109.26000213623,51.659999847412),
							Size	=	0.1,
							UseClr	=	false,
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.12,
						},
				SpecSpin	=	{
						},
				UseBrake	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecMat	=	{
					New	=	"models/tdmcars/bmw_340i/lights_on_r",
						},
				UseRunning	=	true,
				RenderMLCenter	=	true,
				UseSprite	=	true,
				Pos	=	Vector(31.180000305176,-107.13999938965,51.790000915527),
				RenderHD_Adv	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	15,
					Use	=	true,
					LTbl	=	{
							{
							Size	=	0.1,
							Pos	=	Vector(24.170000076294,-109.26000213623,51.659999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.13,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				RenderMLCenter	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-8.039999961853,-71.75,76.430000305176),
				UseBrake	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	13,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(8.3199996948242,-71.75,76.430000305176),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				SpecMat	=	{
					New	=	"models/tdmcars/bmw_340i/lights_on_w",
						},
				UseSprite	=	true,
				Pos	=	Vector(-28.409999847412,-109.36000061035,55.799999237061),
				ReverseColor	=	{
					r	=	255,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderMLCenter	=	true,
				DD_HD	=	true,
				SpecMLine	=	{
					Amount	=	12,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-22.799999237061,-109.66999816895,55.240001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				SpecMat	=	{
					New	=	"models/tdmcars/bmw_340i/lights_on_w",
						},
				UseSprite	=	true,
				Pos	=	Vector(28.409999847412,-109.36000061035,55.799999237061),
				ReverseColor	=	{
					r	=	255,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				DD_HD	=	true,
				RenderMLCenter	=	true,
				SpecMLine	=	{
					Amount	=	12,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(22.799999237061,-109.66999816895,55.240001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.06,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				UseSprite	=	true,
				Pos	=	Vector(-24.700000762939,118.68000030518,42.869998931885),
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Pos	=	Vector(-24.629999160767,120.04000091553,42.849998474121),
							Size	=	0.1,
							UseClr	=	false,
								},
							{
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Pos	=	Vector(-24.459999084473,121.30000305176,42.819999694824),
							Size	=	0.1,
							UseClr	=	false,
								},
							{
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Pos	=	Vector(-23.829999923706,122.38999938965,42.759998321533),
							Size	=	0.1,
							UseClr	=	false,
								},
							{
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Pos	=	Vector(-22.809999465942,123.56999969482,42.709999084473),
							Size	=	0.1,
							UseClr	=	false,
								},
							},
						},
				RenderMLCenter	=	true,
				RunningColor	=	{
					r	=	180,
					b	=	255,
					a	=	255,
					g	=	180,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.06,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(25.639999389648,118.68000030518,42.869998931885),
				UseSprite	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	15,
					Use	=	true,
					LTbl	=	{
							{
							Size	=	0.1,
							Pos	=	Vector(25.569999694824,120.04000091553,42.849998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Size	=	0.1,
							Pos	=	Vector(25.39999961853,121.30000305176,42.819999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Size	=	0.1,
							Pos	=	Vector(24.770000457764,122.38999938965,42.759998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Size	=	0.1,
							Pos	=	Vector(23.75,123.56999969482,42.709999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderMLCenter	=	true,
				RunningColor	=	{
					r	=	180,
					b	=	255,
					a	=	255,
					g	=	180,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	4,
					Size	=	0.06,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				DD_HD	=	true,
				RenderMLCenter	=	true,
				SpecMat	=	{
					Select	=	8,
					New	=	"models\crskautos\bmw\x6m_f86_2015\interior_symbols_illum_on",
					Use	=	true,
						},
				RunningColor	=	{
					r	=	180,
					b	=	255,
					a	=	255,
					g	=	180,
						},
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-31.260000228882,117.26000213623,45.840000152588),
				RenderInner_Size	=	1,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-31.559999465942,117.26000213623,45.590000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-31.819999694824,117.26000213623,45.25),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-32.189998626709,117.26000213623,44.779998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-32.259998321533,117.26000213623,44.419998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-32.400001525879,117.26000213623,43.799999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-32.430000305176,117.26000213623,43.209999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-32.240001678467,117.26000213623,42.450000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-31.799999237061,117.26000213623,41.659999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-30.989999771118,117.26000213623,40.869998931885),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-27.639999389648,117.26000213623,40.759998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-26.680000305176,117.26000213623,41.540000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-26.200000762939,117.26000213623,42.169998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-25.950000762939,117.26000213623,42.849998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-25.89999961853,117.26000213623,43.560001373291),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.940000534058,117.26000213623,44.319999694824),
							Size	=	0.1,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Pos	=	Vector(-26.260000228882,117.26000213623,45.020000457764),
							UseClr	=	false,
							Size	=	0.1,
								},
							{
							Size	=	0.1,
							Pos	=	Vector(-26.60000038147,117.26000213623,45.290000915527),
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							UseClr	=	false,
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	4,
					Size	=	0.06,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				DD_HD	=	true,
				RenderMLCenter	=	true,
				SpecMat	=	{
					Use	=	true,
					New	=	"models\crskautos\bmw\x6m_f86_2015\red_illum_on",
					Select	=	28,
						},
				RunningColor	=	{
					r	=	180,
					b	=	255,
					a	=	255,
					g	=	180,
						},
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(31.870000839233,117.26000213623,45.840000152588),
				RenderInner	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(32.169998168945,117.26000213623,45.590000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(32.430000305176,117.26000213623,45.25),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(32.799999237061,117.26000213623,44.779998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(32.869998931885,117.26000213623,44.419998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(33.009998321533,117.26000213623,43.799999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(33.040000915527,117.26000213623,43.209999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(32.849998474121,117.26000213623,42.450000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(32.409999847412,117.26000213623,41.659999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(31.60000038147,117.26000213623,40.869998931885),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(28.25,117.26000213623,40.759998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(27.290000915527,117.26000213623,41.540000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(26.809999465942,117.26000213623,42.169998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(26.559999465942,117.26000213623,42.849998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(26.510000228882,117.26000213623,43.560001373291),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Pos	=	Vector(26.549999237061,117.26000213623,44.319999694824),
							UseClr	=	false,
							Size	=	0.1,
								},
							{
							Size	=	0.1,
							Pos	=	Vector(26.870000839233,117.26000213623,45.020000457764),
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							UseClr	=	false,
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.209999084473,117.26000213623,45.290000915527),
							Size	=	0.1,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.06,
						},
				SpecSpin	=	{
						},
				DD_HD	=	true,
				DD_Blnk_Run	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models/tdmcars/bmw_340i/lights_on_a",
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(28.510000228882,120.19000244141,45.830001831055),
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	35,
					Use	=	true,
					LTbl	=	{
							{
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Pos	=	Vector(30.360000610352,119.01000213623,46.049999237061),
							UseClr	=	false,
							Size	=	1,
								},
							{
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Pos	=	Vector(33.189998626709,117.16999816895,46.349998474121),
							UseClr	=	false,
							Size	=	1,
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.979999542236,115.29000091553,46.700000762939),
							Size	=	1,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							UseClr	=	false,
							Pos	=	Vector(38.400001525879,113.38999938965,46.869998931885),
							Size	=	1,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							UseClr	=	false,
							Pos	=	Vector(41.180000305176,110.84999847412,47.139999389648),
							Size	=	1,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseBlinkers	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				DD_HD	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	200,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(48.389999389648,107.73000335693,32.979999542236),
				SpecMLine	=	{
					Amount	=	16,
					Use	=	true,
					LTbl	=	{
							{
							Size	=	1,
							Pos	=	Vector(48.470001220703,106.20999908447,35.5),
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							UseClr	=	false,
								},
							{
							Size	=	1,
							Pos	=	Vector(48.729999542236,104.73000335693,37.259998321533),
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							UseClr	=	false,
								},
							{
							UseClr	=	false,
							Pos	=	Vector(48.930000305176,103.06999969482,38.740001678467),
							Size	=	1,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							UseClr	=	false,
							Pos	=	Vector(48.990001678467,101.19000244141,40.130001068115),
							Size	=	1,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							UseClr	=	false,
							Pos	=	Vector(49.119998931885,99.349998474121,41.330001831055),
							Size	=	1,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseBlinkers	=	true,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.06,
						},
				SpecSpin	=	{
						},
				DD_HD	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models/tdmcars/bmw_340i/lights_on_w",
						},
				UseSprite	=	true,
				Pos	=	Vector(-39.810001373291,-98.139999389648,57.490001678467),
				SpecMLine	=	{
					Amount	=	24,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-38.439998626709,-100.93000030518,57.509998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-36.720001220703,-103.31999969482,57.439998626709),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Pos	=	Vector(-34.360000610352,-105.75,57.299999237061),
							Size	=	0.1,
							UseClr	=	false,
								},
							},
						},
				UseBlinkers	=	true,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				DD_HD	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models/tdmcars/bmw_340i/lights_on_w",
						},
				UseSprite	=	true,
				Pos	=	Vector(31.190000534058,-107.73999786377,57.099998474121),
				SpecMLine	=	{
					Amount	=	24,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(27.510000228882,-108.7799987793,56.630001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(22.989999771118,-110.45999908447,56.209999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(20.64999961853,-111.08999633789,55.990001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseBlinkers	=	true,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				DD_HD	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models/tdmcars/bmw_340i/lights_on_w",
						},
				UseSprite	=	true,
				Pos	=	Vector(-31.790000915527,-107.73999786377,57.349998474121),
				SpecMLine	=	{
					Amount	=	24,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-28.110000610352,-108.7799987793,56.880001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-23.590000152588,-110.45999908447,56.459999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-21.25,-111.08999633789,56.240001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderMLCenter	=	true,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.06,
						},
				SpecSpin	=	{
						},
				DD_HD	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models/tdmcars/bmw_340i/lights_on_w",
						},
				UseSprite	=	true,
				Pos	=	Vector(-39.650001525879,-98.410003662109,58.740001678467),
				SpecMLine	=	{
					Amount	=	24,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-38.279998779297,-101.19999694824,58.950000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-36.560001373291,-103.58999633789,58.889999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-34.200000762939,-104.51999664307,58.590000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderMLCenter	=	true,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.06,
						},
				SpecSpin	=	{
						},
				DD_HD	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models/tdmcars/bmw_340i/lights_on_w",
						},
				UseSprite	=	true,
				Pos	=	Vector(39.810001373291,-98.139999389648,57.490001678467),
				SpecMLine	=	{
					Amount	=	24,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(38.439998626709,-100.93000030518,57.509998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(36.720001220703,-103.31999969482,57.439998626709),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(34.360000610352,-105.75,57.299999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseBlinkers	=	true,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.06,
						},
				SpecSpin	=	{
						},
				DD_HD	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models/tdmcars/bmw_340i/lights_on_w",
						},
				UseSprite	=	true,
				Pos	=	Vector(39.650001525879,-98.410003662109,58.740001678467),
				SpecMLine	=	{
					Amount	=	24,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(38.279998779297,-101.19999694824,58.950000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(36.560001373291,-103.58999633789,58.889999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(34.200000762939,-104.51999664307,58.590000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseBlinkers	=	true,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.5,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				LBeamColor	=	{
					r	=	180,
					b	=	255,
					a	=	255,
					g	=	180,
						},
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(25.209999084473,114.90000152588,40.090000152588),
					UseColor	=	true,
					Pos2	=	Vector(34.020000457764,114.90000152588,47.430000305176),
					Color	=	{
						r	=	200,
						b	=	200,
						a	=	255,
						g	=	200,
							},
					Use	=	true,
					Pos1	=	Vector(25.139999389648,114.90000152588,46.569999694824),
					Pos3	=	Vector(34.169998168945,114.90000152588,39.959999084473),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(30.159999847412,116.09999847412,43.439998626709),
				RenderInner_Size	=	1,
				RenderMLCenter	=	true,
				RenderInner	=	true,
				HBeamColor	=	{
					r	=	180,
					b	=	255,
					a	=	255,
					g	=	180,
						},
				Beta_Inner3D	=	true,
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(25,0,0),
				Pos	=	Vector(18.659999847412,17.590000152588,44.259998321533),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(20,0,0),
				Pos	=	Vector(-17.479999542236,-31.409999847412,44.220001220703),
				EnterAnim	=	"enter4",
				ExitAnim	=	"exit4",
					},
				{
				Ang	=	Angle(20,0,0),
				Pos	=	Vector(17.479999542236,-31.409999847412,44.220001220703),
				ExitAnim	=	"exit4",
				EnterAnim	=	"enter4",
					},
				{
				Ang	=	Angle(20,0,0),
				Pos	=	Vector(0,-31.409999847412,44.220001220703),
					},
				},
		Fuel	=	{
			FuelLidPos	=	Vector(45.889999389648,-71.160003662109,55.909999847412),
			FuelTypeUse	=	true,
			FuelType	=	0,
			Capacity	=	85,
			FuelLidUse	=	true,
			Override	=	true,
				},
		Author	=	"CrushingSkirmish (76561198017348899)",
}