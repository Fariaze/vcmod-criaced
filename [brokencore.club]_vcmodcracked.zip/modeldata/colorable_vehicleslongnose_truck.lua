VCModels['models/colorable_vehicleslongnose_truck.mdl']	=	{
		IsBig	=	true,
		em_state	=	5236594797,
		Date	=	"06/17/16 19:48:50",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-180,0),
				Pos	=	Vector(-44.319999694824,11.489999771118,161.53999328613),
				EffectStress	=	"VC_Exhaust_Truck_Stress",
				EffectIdle	=	"VC_Exhaust_Truck",
					},
				},
		Sound_Airbrake	=	true,
		DLT	=	3491063198,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseHead	=	true,
				UsePrjTex	=	true,
				Pos	=	Vector(42.049999237061,133.13999938965,54.060001373291),
				UseDynamic	=	true,
				RenderInner	=	true,
				HeadColor	=	{
						192,
						186,
						255,
						},
				UseSprite	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				ProjTexture	=	{
					Forward	=	30,
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseHead	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-42.049999237061,133.13999938965,54.060001373291),
				UseDynamic	=	true,
				RenderInner	=	true,
				HeadColor	=	{
						192,
						186,
						255,
						},
				ProjTexture	=	{
					Forward	=	30,
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UsePrjTex	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-41.900001525879,133.13999938965,54.060001373291),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseRunning	=	true,
				RunningColor	=	{
						187.6,
						240.03,
						243.72,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(41.900001525879,133.13999938965,54.060001373291),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseRunning	=	true,
				RunningColor	=	{
						187.6,
						240.03,
						243.72,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(30.89999961853,59.330001831055,119.51999664307),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseRunning	=	true,
				RunningColor	=	{
						255,
						155,
						0,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-30.89999961853,59.330001831055,119.51999664307),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseRunning	=	true,
				RunningColor	=	{
						255,
						155,
						0,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(9.4899997711182,64.949996948242,119.41000366211),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseRunning	=	true,
				RunningColor	=	{
						255,
						155,
						0,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-9.4899997711182,64.949996948242,119.41000366211),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseRunning	=	true,
				RunningColor	=	{
						255,
						155,
						0,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(0,64.970001220703,119.54000091553),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseRunning	=	true,
				RunningColor	=	{
						255,
						155,
						0,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						55,
						0,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-17.260000228882,-210.53999328613,23.129999160767),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						55,
						0,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(17.260000228882,-210.53999328613,23.129999160767),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-8.7399997711182,-211.58000183105,24),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseRunning	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(8.7399997711182,-211.58000183105,24),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseRunning	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				},
		Sound_Backup	=	true,
		Copyright	=	"Copyright © 2012-2016 VCMod (freemmaann). All Rights Reserved.",
		Author	=	"[CG] Tokimune (76561198087327799)",
}