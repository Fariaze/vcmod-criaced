VCModels['models/crsk_autospaganihuayrabc_2016.mdl']	=	{
		em_state	=	5236594761,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Date	=	"05/10/17 22:20:12",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,-20),
				Pos	=	Vector(1.9500000476837,-100.01000213623,32.180000305176),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,-20),
				Pos	=	Vector(-2.210000038147,-100.01000213623,32.180000305176),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,-20),
				Pos	=	Vector(1.8899999856949,-99.919998168945,27.959999084473),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,-20),
				Pos	=	Vector(-2.3900001049042,-99.919998168945,27.959999084473),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(14.460000038147,16.520000457764,19.459999084473),
				RadioControl	=	true,
					},
				},
		DLT	=	3491063174,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(36.930000305176,88.300003051758,24.870000839233),
					Pos2	=	Vector(33.509998321533,88.300003051758,28.290000915527),
					Use	=	true,
					Pos1	=	Vector(36.930000305176,88.300003051758,28.290000915527),
					Pos3	=	Vector(33.509998321533,88.300003051758,24.870000839233),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(35.220001220703,88.300003051758,26.579999923706),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-34.720001220703,88.449996948242,26.700000762939),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-36.430000305176,88.449996948242,24.989999771118),
					Pos2	=	Vector(-33.009998321533,88.449996948242,28.409999847412),
					Use	=	true,
					Pos1	=	Vector(-36.430000305176,88.449996948242,28.409999847412),
					Pos3	=	Vector(-33.009998321533,88.449996948242,24.989999771118),
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(31.780000686646,90.699996948242,24.260000228882),
					Pos2	=	Vector(28.360000610352,90.699996948242,27.680000305176),
					Color	=	{
							0,
							0,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(31.780000686646,90.699996948242,27.680000305176),
					Pos3	=	Vector(28.360000610352,90.699996948242,24.260000228882),
						},
				FogColor	=	{
						255,
						255,
						222,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				UseSprite	=	true,
				Pos	=	Vector(30.069999694824,90.699996948242,25.969999313354),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseFog	=	true,
				Beta_Inner3D	=	true,
				UsePrjTex	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-31.280000686646,90.849998474121,24.260000228882),
					Pos2	=	Vector(-27.860000610352,90.849998474121,27.680000305176),
					Color	=	{
							0,
							0,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(-31.280000686646,90.849998474121,27.680000305176),
					Pos3	=	Vector(-27.860000610352,90.849998474121,24.260000228882),
						},
				FogColor	=	{
						255,
						255,
						222,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				UseSprite	=	true,
				Pos	=	Vector(-29.569999694824,90.849998474121,25.969999313354),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseFog	=	true,
				Beta_Inner3D	=	true,
				UsePrjTex	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
						255,
						244,
						255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(37.560001373291,82.809997558594,28.219999313354),
					UseColor	=	true,
					Pos2	=	Vector(34.139999389648,82.809997558594,31.639999389648),
					Color	=	{
							255,
							255,
							255,
							},
					Use	=	true,
					Pos1	=	Vector(37.560001373291,82.809997558594,31.639999389648),
					Pos3	=	Vector(34.139999389648,82.809997558594,28.219999313354),
						},
				HBeamColor	=	{
						255,
						244,
						255,
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(35.849998474121,82.809997558594,29.930000305176),
				RenderInner	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseSprite	=	true,
				SpecMat	=	{
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
						255,
						244,
						255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-37.099998474121,82.980003356934,28.420000076294),
					UseColor	=	true,
					Pos2	=	Vector(-33.680000305176,82.980003356934,31.840000152588),
					Color	=	{
							255,
							255,
							255,
							},
					Use	=	true,
					Pos1	=	Vector(-37.099998474121,82.980003356934,31.840000152588),
					Pos3	=	Vector(-33.680000305176,82.980003356934,28.420000076294),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-35.389999389648,82.980003356934,30.129999160767),
				RenderInner	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				Beta_Inner3D	=	true,
				HBeamColor	=	{
						255,
						244,
						255,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(32.159999847412,85.01000213623,27.569999694824),
					UseColor	=	true,
					Pos2	=	Vector(28.739999771118,85.01000213623,30.989999771118),
					Color	=	{
							255,
							255,
							255,
							},
					Use	=	true,
					Pos1	=	Vector(32.159999847412,85.01000213623,30.989999771118),
					Pos3	=	Vector(28.739999771118,85.01000213623,27.569999694824),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(30.450000762939,85.01000213623,29.280000686646),
				UseDynamic	=	true,
				RenderInner	=	true,
				HBeamColor	=	{
						244,
						244,
						255,
						},
				UseHighBeams	=	true,
				Beta_Inner3D	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-31.629999160767,85.160003662109,27.780000686646),
					UseColor	=	true,
					Pos2	=	Vector(-28.209999084473,85.160003662109,31.200000762939),
					Color	=	{
							255,
							255,
							255,
							},
					Use	=	true,
					Pos1	=	Vector(-31.629999160767,85.160003662109,31.200000762939),
					Pos3	=	Vector(-28.209999084473,85.160003662109,27.780000686646),
						},
				HBeamColor	=	{
						244,
						244,
						255,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-29.920000076294,85.160003662109,29.489999771118),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMat	=	{
						},
				UseHighBeams	=	true,
				Beta_Inner3D	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				DD_HD	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(33.139999389648,100.20999908447,11.210000038147),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				UseSprite	=	true,
				RunningColor	=	{
						222,
						222,
						255,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				DD_HD	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(31.260000228882,101.2200012207,11.210000038147),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				UseSprite	=	true,
				RunningColor	=	{
						222,
						222,
						255,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				DD_HD	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(29.260000228882,102.2200012207,11.210000038147),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				UseSprite	=	true,
				RunningColor	=	{
						222,
						222,
						255,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				DD_HD	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(27.260000228882,103.2200012207,11.210000038147),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				UseSprite	=	true,
				RunningColor	=	{
						222,
						222,
						255,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				DD_HD	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(25.39999961853,104.2200012207,11.210000038147),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				UseSprite	=	true,
				RunningColor	=	{
						222,
						222,
						255,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				DD_HD	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-24.909999847412,104.2200012207,11.35000038147),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				UseSprite	=	true,
				RunningColor	=	{
						222,
						222,
						255,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				DD_HD	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-26.909999847412,103.2200012207,11.35000038147),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				UseSprite	=	true,
				RunningColor	=	{
						222,
						222,
						255,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				DD_HD	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-28.799999237061,102.2200012207,11.35000038147),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				UseSprite	=	true,
				RunningColor	=	{
						222,
						222,
						255,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				DD_HD	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-30.700000762939,101.2200012207,11.35000038147),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				UseSprite	=	true,
				RunningColor	=	{
						222,
						222,
						255,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				DD_HD	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-32.700000762939,100.2200012207,11.35000038147),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				UseSprite	=	true,
				RunningColor	=	{
						222,
						222,
						255,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-39.659999847412,-90.400001525879,34.75),
					Pos2	=	Vector(-36.380001068115,-90.5,38.029998779297),
					Color	=	{
							255,
							255,
							255,
							},
					Use	=	true,
					Pos1	=	Vector(-39.659999847412,-90.400001525879,38.029998779297),
					Pos3	=	Vector(-36.380001068115,-90.5,34.75),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-38.020000457764,-90.400001525879,36.389999389648),
				UseDynamic	=	true,
				RenderInner	=	true,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(39.419998168945,-90.580001831055,34.549999237061),
					Pos2	=	Vector(36.139999389648,-90.680000305176,37.830001831055),
					Color	=	{
							255,
							255,
							255,
							},
					Use	=	true,
					Pos1	=	Vector(39.419998168945,-90.580001831055,37.830001831055),
					Pos3	=	Vector(36.139999389648,-90.680000305176,34.549999237061),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(37.779998779297,-90.580001831055,36.189998626709),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-40.459999084473,-92.419998168945,29.040000915527),
					Pos2	=	Vector(-37.180000305176,-92.400001525879,32.319999694824),
					Color	=	{
							255,
							255,
							255,
							},
					Use	=	true,
					Pos1	=	Vector(-40.459999084473,-92.419998168945,32.319999694824),
					Pos3	=	Vector(-37.180000305176,-92.400001525879,29.040000915527),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-38.819999694824,-92.419998168945,30.680000305176),
				UseDynamic	=	true,
				RenderInner	=	true,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(38.5,-92.5,30.459999084473),
				UseDynamic	=	true,
				RenderInner	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(40.139999389648,-92.5,28.819999694824),
					Pos2	=	Vector(36.860000610352,-92.480003356934,32.099998474121),
					Color	=	{
							255,
							255,
							255,
							},
					Use	=	true,
					Pos1	=	Vector(40.139999389648,-92.5,32.099998474121),
					Pos3	=	Vector(36.860000610352,-92.480003356934,28.819999694824),
						},
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(34.130001068115,-94.599998474121,33.680000305176),
					Pos2	=	Vector(30.85000038147,-94.800003051758,36.959999084473),
					Color	=	{
							255,
							255,
							255,
							},
					Use	=	true,
					Pos1	=	Vector(34.130001068115,-94.599998474121,36.959999084473),
					Pos3	=	Vector(30.85000038147,-94.800003051758,33.680000305176),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(32.490001678467,-94.580001831055,35.319999694824),
				UseDynamic	=	true,
				RenderInner	=	true,
				ReverseColor	=	{
						255,
						255,
						255,
						},
				Beta_Inner3D	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-34.409999847412,-94.419998168945,33.799999237061),
					Pos2	=	Vector(-31.129999160767,-94.620002746582,37.080001831055),
					Color	=	{
							255,
							255,
							255,
							},
					Use	=	true,
					Pos1	=	Vector(-34.409999847412,-94.419998168945,37.080001831055),
					Pos3	=	Vector(-31.129999160767,-94.620002746582,33.799999237061),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-32.770000457764,-94.400001525879,35.439998626709),
				UseDynamic	=	true,
				RenderInner	=	true,
				ReverseColor	=	{
						255,
						255,
						255,
						},
				UseSprite	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseRunning	=	true,
				UseBrake	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				UseSprite	=	true,
				Pos	=	Vector(-38.020000457764,-90.300003051758,36.290000915527),
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	14,
					Use	=	true,
					Radius	=	2,
						},
				RenderInner	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBrake	=	true,
				UseSprite	=	true,
				Pos	=	Vector(37.680000305176,-90.300003051758,36.119998931885),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecCircle	=	{
					Amount	=	14,
					Use	=	true,
					Radius	=	2,
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				UseSprite	=	true,
				Pos	=	Vector(-32.770000457764,-94.300003051758,35.439998626709),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecCircle	=	{
					Amount	=	14,
					Use	=	true,
					Radius	=	2,
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				Beta_Inner3D	=	true,
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(32.490001678467,-94.480003356934,35.319999694824),
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	14,
					Use	=	true,
					Radius	=	2,
						},
				RenderInner	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				UseSprite	=	true,
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseRunning	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-38.819999694824,-92.319999694824,30.680000305176),
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	14,
					Use	=	true,
					Radius	=	2,
						},
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseRunning	=	true,
				UseSprite	=	true,
				Pos	=	Vector(38.5,-92.400001525879,30.459999084473),
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	14,
					Use	=	true,
					Radius	=	2,
						},
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-1.8999999761581,-102.19999694824,10.39999961853),
					Pos2	=	Vector(1.3799999952316,-102.19999694824,13.680000305176),
					Color	=	{
							255,
							90,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(-1.8999999761581,-102.19999694824,13.680000305176),
					Pos3	=	Vector(1.3799999952316,-102.19999694824,10.39999961853),
						},
				FogColor	=	{
						255,
						55,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-0.25999999046326,-102.18000030518,12.039999961853),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseFog	=	true,
				Beta_Inner3D	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.12,
						},
				SpecSpin	=	{
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(6.460000038147,-100.56999969482,47.430000305176),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-6.6999998092651,-100.58000183105,47.409999847412),
								},
							},
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.12,
						},
				SpecSpin	=	{
						},
				UseBrake	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(4.0599999427795,-13.39999961853,49.529998779297),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	18,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-3.3800001144409,-13.39999961853,49.540000915527),
								},
							},
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderMLCenter	=	true,
				UseSprite	=	true,
					},
				},
		Copyright	=	"Copyright © 2012-2017 VCMod (freemmaann). All Rights Reserved.",
		Fuel	=	{
			FuelLidPos	=	Vector(0,0,0),
			Capacity	=	85,
			Override	=	true,
			FuelType	=	0,
				},
		Author	=	"CrushingSkirmish (76561198017348899)",
}