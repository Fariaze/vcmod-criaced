VCModels['models/crsk_autosdevelsixteen.mdl']	=	{
		em_state	=	5236594437,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		HealthEnginePosOvr	=	true,
		Date	=	"Fri Nov  3 15:41:23 2017",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-16.520000457764,-131,27.39999961853),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-15.420000076294,-131,33.779998779297),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-17.760000228882,-131,30.770000457764),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-11.539999961853,-131,27.709999084473),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-13.5,-131,34.319999694824),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-10.819999694824,-131,31.590000152588),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-14.319999694824,-131,30.590000152588),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(14.289999961853,-131.25,34.220001220703),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(12.239999771118,-131.25,33.659999847412),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(9.9200000762939,-131.25,30.700000762939),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(13.369999885559,-131.25,30.469999313354),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(16.840000152588,-131.25,31.579999923706),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(16.139999389648,-131.25,27.799999237061),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(11.270000457764,-131.25,27.290000915527),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		Indication	=	{
			speedo_kmph	=	{
				max	=	1,
				pp	=	"vehicle_guage",
				min	=	0,
				top	=	320,
					},
				},
		Copyright	=	"Copyright © 2012-2017 VCMod (freemmaann). All Rights Reserved.",
		HealthEnginePos	=	Vector(0,-47.5,36.5),
		DLT	=	3491062958,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.11,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				DD_Blnk_Run	=	true,
				UseDynamic	=	true,
				RenderHD_Size	=	0,
				RenderInner_Clr	=	{
						195,
						195,
						255,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.5311,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-34.099998474121,83.900001525879,25.129999160767),
				RenderInner_Size	=	2,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-33.639999389648,88.900001525879,18.219999313354),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.830001831055,92.940002441406,10.64999961853),
								},
							},
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
						111,
						111,
						255,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.11,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				DD_Blnk_Run	=	true,
				UseDynamic	=	true,
				RenderHD_Size	=	0,
				RenderInner_Clr	=	{
						195,
						195,
						255,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.5311,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-38.990001678467,83,27.940000534058),
				RenderInner	=	true,
				RenderInner_Size	=	2,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-37.069999694824,88.949996948242,19.39999961853),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.830001831055,92.940002441406,10.64999961853),
								},
							},
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
						111,
						111,
						255,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.11,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				DD_Blnk_Run	=	true,
				UseDynamic	=	true,
				RenderHD_Size	=	0,
				RenderInner_Clr	=	{
						195,
						195,
						255,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.5311,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(34.569999694824,83.809997558594,25.010000228882),
				RenderInner	=	true,
				RenderInner_Size	=	2,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(34.110000610352,88.809997558594,18.10000038147),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.299999237061,92.849998474121,10.529999732971),
								},
							},
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
						111,
						111,
						255,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.11,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				DD_Blnk_Run	=	true,
				UseDynamic	=	true,
				RenderHD_Size	=	0,
				RenderInner_Clr	=	{
						195,
						195,
						255,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.5311,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(39.509998321533,82.849998474121,27.770000457764),
				RenderInner	=	true,
				RenderInner_Size	=	2,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(37.590000152588,88.800003051758,19.229999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.349998474121,92.790000915527,10.479999542236),
								},
							},
						},
				UseSprite	=	true,
				RunningColor	=	{
						111,
						111,
						255,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
						195,
						195,
						255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
						195,
						195,
						255,
						},
				Dynamic	=	{
					Size	=	1,
					Brightness	=	2,
						},
				HBeamColor	=	{
						195,
						195,
						255,
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-36.439998626709,84.830001831055,22.879999160767),
				SpecMat	=	{
						},
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-36.439998626709,86.540000915527,18.180000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.319999694824,86.540000915527,18.180000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.380001068115,84.819999694824,22.909999847412),
								},
							},
						},
				UseSprite	=	true,
				RenderInner_Size	=	0.4,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.02,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						200,
						200,
						200,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	1,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-52.209999084473,-134.72999572754,6.1700000762939),
					UseColor	=	true,
					Pos2	=	Vector(-51.389999389648,-135.55999755859,11.960000038147),
					Color	=	{
							255,
							55,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(-50.509998321533,-135.58999633789,11.949999809265),
					Pos3	=	Vector(-53.150001525879,-134.74000549316,6.1100001335144),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-51.040000915527,-135.5,11.569999694824),
				RenderMLCenter	=	true,
				RenderInner_Size	=	1.3,
				SpecMLine	=	{
					Amount	=	72,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-52.540000915527,-134.69999694824,6.5599999427795),
								},
							},
						},
				RenderInner	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.02,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						200,
						200,
						200,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	1,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(51.569999694824,-134.97999572754,5.9099998474121),
					UseColor	=	true,
					Pos2	=	Vector(50.75,-135.80999755859,11.699999809265),
					Color	=	{
							255,
							55,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(49.869998931885,-135.83999633789,11.689999580383),
					Pos3	=	Vector(52.509998321533,-134.99000549316,5.8499999046326),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(50.400001525879,-135.75,11.310000419617),
				RenderMLCenter	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	72,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(51.900001525879,-134.94999694824,6.3000001907349),
								},
							},
						},
				RenderInner_Size	=	1.3,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.02,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseDynamic	=	true,
				BrakeColor	=	{
						255,
						0,
						0,
						},
				RenderInner_Clr	=	{
						200,
						200,
						200,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	1,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-0.30000001192093,-134.99000549316,14.390000343323),
					UseColor	=	true,
					Pos2	=	Vector(-7.7800002098083,-134.99000549316,15.14999961853),
					Color	=	{
							255,
							55,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(-0.30000001192093,-134.99000549316,15.14999961853),
					Pos3	=	Vector(-7.6700000762939,-134.99000549316,14.390000343323),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-7.5,-134.91000366211,14.779999732971),
				RenderMLCenter	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	91,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-0.69999998807907,-134.91000366211,14.779999732971),
								},
							},
						},
				RenderInner_Size	=	1.4,
				UseSprite	=	true,
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.02,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseDynamic	=	true,
				BrakeColor	=	{
						255,
						0,
						0,
						},
				RenderInner_Clr	=	{
						200,
						200,
						200,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	1,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-0.31999999284744,-135,14.369999885559),
					UseColor	=	true,
					Pos2	=	Vector(7.1599998474121,-135,15.130000114441),
					Color	=	{
							255,
							55,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(-0.31999999284744,-135,15.130000114441),
					Pos3	=	Vector(7.0500001907349,-135,14.369999885559),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(6.8800001144409,-134.91999816895,14.760000228882),
				RenderMLCenter	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	91,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(0.079999998211861,-134.91999816895,14.760000228882),
								},
							},
						},
				RenderInner_Size	=	1.4,
				UseSprite	=	true,
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseDynamic	=	true,
				BrakeColor	=	{
						255,
						0,
						0,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	1,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						55,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-48.450000762939,-132.4700012207,35.799999237061),
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-43.409999847412,-131.83000183105,36.790000915527),
					UseColor	=	true,
					Pos2	=	Vector(-48.5,-133.02000427246,36.599998474121),
					Color	=	{
							200,
							200,
							200,
							},
					Use	=	true,
					Pos1	=	Vector(-43.450000762939,-131.92999267578,38.310001373291),
					Pos3	=	Vector(-48.259998321533,-132.86000061035,35.110000610352),
						},
				Beta_Inner3D	=	true,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-43.819999694824,-131.75,37.409999847412),
								},
							},
						},
				UseBrake	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseDynamic	=	true,
				BrakeColor	=	{
						255,
						0,
						0,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	1,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-43.409999847412,-131.83000183105,36.790000915527),
					UseColor	=	true,
					Pos2	=	Vector(-31.139999389648,-130.10000610352,35.729999542236),
					Color	=	{
							200,
							200,
							200,
							},
					Use	=	true,
					Pos1	=	Vector(-43.450000762939,-131.92999267578,38.310001373291),
					Pos3	=	Vector(-30.770000457764,-129.92999267578,34.240001678467),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-30.340000152588,-129.49000549316,34.759998321533),
				BlinkersColor	=	{
						255,
						55,
						0,
						},
				UseSprite	=	true,
				SpecMLine	=	{
					Amount	=	40,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-42.580001831055,-131.36000061035,37.409999847412),
								},
							},
						},
				RenderMLCenter	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
						195,
						195,
						255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
						195,
						195,
						255,
						},
				Dynamic	=	{
					Size	=	1,
					Brightness	=	2,
						},
				HBeamColor	=	{
						195,
						195,
						255,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(36.919998168945,84.650001525879,22.719999313354),
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				RenderInner_Size	=	0.4,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(36.909999847412,86.389999389648,17.920000076294),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.779998779297,86.400001525879,17.920000076294),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.840000152588,84.650001525879,22.709999084473),
								},
							},
						},
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				SpecMat	=	{
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseDynamic	=	true,
				BrakeColor	=	{
						255,
						0,
						0,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	1,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(42.900001525879,-132.05999755859,36.569999694824),
					UseColor	=	true,
					Pos2	=	Vector(47.990001678467,-133.24000549316,36.380001068115),
					Color	=	{
							200,
							200,
							200,
							},
					Use	=	true,
					Pos1	=	Vector(42.939998626709,-132.14999389648,38.090000152588),
					Pos3	=	Vector(47.75,-133.08999633789,34.889999389648),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(47.939998626709,-132.69999694824,35.580001831055),
				BlinkersColor	=	{
						255,
						55,
						0,
						},
				UseSprite	=	true,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(43.310001373291,-131.97999572754,37.189998626709),
								},
							},
						},
				UseBrake	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseDynamic	=	true,
				BrakeColor	=	{
						255,
						0,
						0,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	1,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						55,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBrake	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(29.799999237061,-129.71000671387,34.599998474121),
				UseBlinkers	=	true,
				RenderMLCenter	=	true,
				SpecMLine	=	{
					Amount	=	40,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(42.040000915527,-131.58000183105,37.25),
								},
							},
						},
				UseSprite	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(42.900001525879,-132.05999755859,36.569999694824),
					UseColor	=	true,
					Pos2	=	Vector(30.60000038147,-130.24000549316,35.569999694824),
					Color	=	{
							200,
							200,
							200,
							},
					Use	=	true,
					Pos1	=	Vector(42.939998626709,-132.14999389648,38.090000152588),
					Pos3	=	Vector(30.229999542236,-130.05999755859,34.080001831055),
						},
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(10,0,0),
				Pos	=	Vector(18.409999847412,10.930000305176,21.520000457764),
				RadioControl	=	true,
					},
				},
		Fuel	=	{
			FuelLidPos	=	Vector(0,-45,40),
			Capacity	=	100,
			Override	=	true,
			FuelType	=	0,
				},
		Author	=	"CгεερεгƬv (76561198051637331)",
}