VCModels['models/crsk_autosferrari360stradale_2003.mdl']	=	{
		em_state	=	5236595061,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		HealthEnginePosOvr	=	true,
		Date	=	"Fri Jul  6 22:36:58 2018",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-32.860000610352,-93.019996643066,20.290000915527),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(32.689998626709,-93.220001220703,20.200000762939),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-28.799999237061,-95.01000213623,20.389999389648),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(28.520000457764,-95.209999084473,20.25),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		Copyright	=	"Copyright © 2012-2018 VCMod (freemmaann). All Rights Reserved.",
		HealthEnginePos	=	Vector(0,-42.5,36),
		DLT	=	3491063374,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.7,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-29.959999084473,85.680000305176,27.10000038147),
					UseColor	=	true,
					Pos2	=	Vector(-34.080001831055,85.680000305176,31.219999313354),
					Color	=	{
							255,
							255,
							253,
							},
					Use	=	true,
					Pos1	=	Vector(-29.959999084473,85.680000305176,31.219999313354),
					Pos3	=	Vector(-34.080001831055,85.680000305176,27.10000038147),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
				LBeamColor	=	{
						255,
						255,
						253,
						},
				UseDynamic	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				UsePrjTex	=	true,
				Pos	=	Vector(-32.020000457764,85.180000305176,29.159999847412),
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-24.549999237061,87.550003051758,25.959999084473),
					UseColor	=	true,
					Pos2	=	Vector(-29.370000839233,87.550003051758,30.780000686646),
					Color	=	{
							255,
							222,
							155,
							},
					Use	=	true,
					Pos1	=	Vector(-24.549999237061,87.550003051758,30.780000686646),
					Pos3	=	Vector(-29.370000839233,87.550003051758,25.959999084473),
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				HBeamColor	=	{
						255,
						222,
						155,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-26.959999084473,87.050003051758,28.370000839233),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				UsePrjTex	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(25.159999847412,87.400001525879,25.719999313354),
					UseColor	=	true,
					Pos2	=	Vector(29.979999542236,87.400001525879,30.540000915527),
					Color	=	{
							255,
							222,
							155,
							},
					Use	=	true,
					Pos1	=	Vector(25.159999847412,87.400001525879,30.540000915527),
					Pos3	=	Vector(29.979999542236,87.400001525879,25.719999313354),
						},
				UseSprite	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				HBeamColor	=	{
						255,
						222,
						155,
						},
				UsePrjTex	=	true,
				Pos	=	Vector(27.569999694824,86.900001525879,28.129999160767),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.7,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(30.450000762939,85.5,26.979999542236),
					UseColor	=	true,
					Pos2	=	Vector(34.569999694824,85.5,31.10000038147),
					Color	=	{
							255,
							255,
							253,
							},
					Use	=	true,
					Pos1	=	Vector(30.450000762939,85.5,31.10000038147),
					Pos3	=	Vector(34.569999694824,85.5,26.979999542236),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				Beta_Inner3D	=	true,
				LBeamColor	=	{
						255,
						255,
						253,
						},
				UseDynamic	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				UsePrjTex	=	true,
				Pos	=	Vector(32.509998321533,85,29.040000915527),
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-37.470001220703,82.099998474121,29.14999961853),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				Beta_Inner3D	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-35.759998321533,82.599998474121,27.440000534058),
					UseColor	=	true,
					Pos2	=	Vector(-39.180000305176,82.599998474121,30.860000610352),
					Color	=	{
							255,
							155,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(-35.759998321533,82.599998474121,30.860000610352),
					Pos3	=	Vector(-39.180000305176,82.599998474121,27.440000534058),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(36.290000915527,82.400001525879,27.209999084473),
					UseColor	=	true,
					Pos2	=	Vector(39.709999084473,82.400001525879,30.629999160767),
					Color	=	{
							255,
							155,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(36.290000915527,82.400001525879,30.629999160767),
					Pos3	=	Vector(39.709999084473,82.400001525879,27.209999084473),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(38,81.900001525879,28.920000076294),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				Beta_Inner3D	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	3,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				SpecMat	=	{
					Select	=	5,
					New	=	"models\crskautos\ferrari\360stradale_2003\interior_lod0_illum_on",
					Use	=	true,
						},
				ReducedVis	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				UseSprite	=	true,
				Pos	=	Vector(-35.159999847412,84.919998168945,31.530000686646),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseRunning	=	true,
				Beta_Inner3D	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	3,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				UseRunning	=	true,
				SpecMat	=	{
					Select	=	20,
					New	=	"models\crskautos\ferrari\360stradale_2003\vehiclelights_inter_on",
					Use	=	true,
						},
				ReducedVis	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				UseSprite	=	true,
				Pos	=	Vector(35.680000305176,84.720001220703,31.340000152588),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-45.599998474121,42.259998321533,26.39999961853),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				UseSprite	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.06,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	35,
					Use	=	true,
					Radius	=	2.23,
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-33.889999389648,-91.129997253418,36.049999237061),
				RenderInner_Size	=	2.5,
				UseBrake	=	true,
				RenderInner	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.06,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	35,
					Use	=	true,
					Radius	=	2.23,
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						255,
						55,
						0,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(33.580001831055,-91.330001831055,35.970001220703),
				RenderInner_Size	=	2.5,
				RenderInner	=	true,
				UseSprite	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.06,
						},
				SpecSpin	=	{
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Size	=	2.5,
				SpecMat	=	{
					Use	=	true,
					New	=	"models\crskautos\shared\vmt\redillum_on",
					Select	=	28,
						},
				ReducedVis	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-25.440000534058,-94.129997253418,35.959999084473),
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	35,
					Use	=	true,
					Radius	=	2.23,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.06,
						},
				SpecSpin	=	{
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				RenderInner	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner_Size	=	2.5,
				UseSprite	=	true,
				Pos	=	Vector(25.180000305176,-94.360000610352,35.889999389648),
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	35,
					Use	=	true,
					Radius	=	2.23,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
						255,
						55,
						0,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-24.049999237061,-94.980003356934,34.459999084473),
					Pos2	=	Vector(-27.110000610352,-94.980003356934,37.520000457764),
					Use	=	true,
					Pos1	=	Vector(-24.049999237061,-94.980003356934,37.520000457764),
					Pos3	=	Vector(-27.110000610352,-94.980003356934,34.459999084473),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-25.579999923706,-93.980003356934,35.990001678467),
				UseDynamic	=	true,
				RenderInner	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(23.760000228882,-95.099998474121,34.369998931885),
					Pos2	=	Vector(26.819999694824,-95.099998474121,37.430000305176),
					Color	=	{
							0,
							0,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(23.760000228882,-95.099998474121,37.430000305176),
					Pos3	=	Vector(26.819999694824,-95.099998474121,34.369998931885),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(25.290000915527,-94.099998474121,35.900001525879),
				UseDynamic	=	true,
				RenderInner	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				Beta_Inner3D	=	true,
				BlinkersColor	=	{
						255,
						90,
						0,
						},
				RenderInner	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-32.360000610352,-92.120002746582,34.520000457764),
					Pos2	=	Vector(-35.419998168945,-92.120002746582,37.580001831055),
					Use	=	true,
					Pos1	=	Vector(-32.360000610352,-92.120002746582,37.580001831055),
					Pos3	=	Vector(-35.419998168945,-92.120002746582,34.520000457764),
						},
				UseSprite	=	true,
				Pos	=	Vector(-33.889999389648,-91.120002746582,36.049999237061),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
						255,
						90,
						0,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				UseBlinkers	=	true,
				BlinkersColor	=	{
						255,
						90,
						0,
						},
				UseSprite	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(32.069999694824,-92.269996643066,34.340000152588),
					Pos2	=	Vector(35.130001068115,-92.269996643066,37.400001525879),
					Use	=	true,
					Pos1	=	Vector(32.069999694824,-92.269996643066,37.400001525879),
					Pos3	=	Vector(35.130001068115,-92.269996643066,34.340000152588),
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(33.599998474121,-91.269996643066,35.869998931885),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderInner_Size	=	1,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
						255,
						90,
						0,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						255,
						90,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-8.1000003814697,-96.830001831055,43.409999847412),
				UseSprite	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(7.8400001525879,-96.830001831055,43.389999389648),
								},
							},
						},
				RenderInner_Size	=	1,
				RenderMLCenter	=	true,
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(45.900001525879,42.090000152588,26.170000076294),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseSprite	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(15,0,0),
				Pos	=	Vector(16.700000762939,12.460000038147,23.379999160767),
				RadioControl	=	true,
					},
				},
		Fuel	=	{
			FuelLidPos	=	Vector(-42.650001525879,-55.279998779297,42),
			Override	=	true,
			FuelType	=	0,
			Capacity	=	95,
			FuelLidUse	=	true,
			FuelTypeUse	=	true,
				},
		Author	=	"CrushingSkirmish (76561198017348899)",
}