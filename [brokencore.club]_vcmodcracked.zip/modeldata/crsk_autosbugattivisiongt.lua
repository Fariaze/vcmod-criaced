VCModels['models/crsk_autosbugattivisiongt.mdl']	=	{
		em_state	=	5236594437,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		HealthEnginePosOvr	=	true,
		Date	=	"06/14/17 18:28:34",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-70,0),
				Pos	=	Vector(-12.659999847412,-94.870002746582,18.549999237061),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-110,0),
				Pos	=	Vector(12.659999847412,-94.870002746582,18.549999237061),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-70,0),
				Pos	=	Vector(-6.6599998474121,-94.870002746582,18.549999237061),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-110,0),
				Pos	=	Vector(6.6599998474121,-94.870002746582,18.549999237061),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		Copyright	=	"Copyright © 2012-2017 VCMod (freemmaann). All Rights Reserved.",
		HealthEnginePos	=	Vector(0,-44,37.5),
		DLT	=	3491062958,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						255,
						100,
						0,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-39.819999694824,-99.800003051758,28.270000457764),
				UseBrake	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	100,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-20.120000839233,-104.18000030518,28.270000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-16.620000839233,-104.40000152588,28.270000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(16.879999160767,-104.5,28.209999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(20.879999160767,-104.12000274658,28.209999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(39.380001068115,-100.12000274658,28.209999084473),
								},
							},
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.03,
						},
				SpecSpin	=	{
						},
				RenderMLCenter	=	true,
				SpecRec	=	{
					Use	=	true,
					Mid	=	true,
					AmountH	=	15,
					Pos1	=	Vector(-38.479999542236,89.800003051758,31.110000610352),
					InnerCenterOnly	=	true,
					AmountV	=	4,
					Mid_V	=	true,
					Pos2	=	Vector(-40.939998626709,89.819999694824,31.139999389648),
					Pos4	=	Vector(-38.490001678467,89.290000915527,29.969999313354),
					Mid_Full	=	true,
					Pos3	=	Vector(-40.849998474121,89.349998474121,29.979999542236),
						},
				RunningColor	=	{
						195,
						195,
						255,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-39.700000762939,89.819999694824,30.549999237061),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-40.939998626709,89.819999694824,31.139999389648),
								},
							{
							Pos	=	Vector(-40.849998474121,89.349998474121,29.979999542236),
								},
							{
							Pos	=	Vector(-38.490001678467,89.290000915527,29.969999313354),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.479999542236,89.800003051758,31.110000610352),
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
						255,
						100,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.03,
						},
				SpecSpin	=	{
						},
				RenderMLCenter	=	true,
				SpecRec	=	{
					Use	=	true,
					Mid	=	true,
					AmountH	=	15,
					Pos1	=	Vector(38.979999542236,89.800003051758,30.989999771118),
					InnerCenterOnly	=	true,
					AmountV	=	4,
					Mid_V	=	true,
					Pos2	=	Vector(41.439998626709,89.819999694824,31.020000457764),
					Pos4	=	Vector(38.990001678467,89.290000915527,29.85000038147),
					Mid_Full	=	true,
					Pos3	=	Vector(41.349998474121,89.349998474121,29.860000610352),
						},
				RunningColor	=	{
						195,
						195,
						255,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				UseSprite	=	true,
				Pos	=	Vector(40.200000762939,89.819999694824,30.430000305176),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(41.439998626709,89.819999694824,31.020000457764),
								},
							{
							Pos	=	Vector(41.349998474121,89.349998474121,29.860000610352),
								},
							{
							Pos	=	Vector(38.990001678467,89.290000915527,29.85000038147),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(38.979999542236,89.800003051758,30.989999771118),
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
						255,
						100,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.03,
						},
				SpecSpin	=	{
						},
				RenderMLCenter	=	true,
				SpecRec	=	{
					Use	=	true,
					Mid	=	true,
					AmountH	=	15,
					Pos1	=	Vector(34.610000610352,92.309997558594,30.590000152588),
					InnerCenterOnly	=	true,
					AmountV	=	4,
					Mid_V	=	true,
					Pos2	=	Vector(37.069999694824,92.330001831055,30.620000839233),
					Pos4	=	Vector(34.619998931885,91.800003051758,29.450000762939),
					Mid_Full	=	true,
					Pos3	=	Vector(36.979999542236,91.860000610352,29.459999084473),
						},
				RunningColor	=	{
						195,
						195,
						255,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				UseSprite	=	true,
				Pos	=	Vector(35.830001831055,92.330001831055,30.030000686646),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(37.069999694824,92.330001831055,30.620000839233),
								},
							{
							Pos	=	Vector(36.979999542236,91.860000610352,29.459999084473),
								},
							{
							Pos	=	Vector(34.619998931885,91.800003051758,29.450000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.610000610352,92.309997558594,30.590000152588),
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
						255,
						100,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.03,
						},
				SpecSpin	=	{
						},
				RenderMLCenter	=	true,
				SpecRec	=	{
					Use	=	true,
					Mid	=	true,
					AmountH	=	15,
					Pos1	=	Vector(-34.099998474121,92.300003051758,30.760000228882),
					InnerCenterOnly	=	true,
					AmountV	=	4,
					Mid_V	=	true,
					Pos2	=	Vector(-36.560001373291,92.319999694824,30.790000915527),
					Pos4	=	Vector(-34.110000610352,91.790000915527,29.620000839233),
					Mid_Full	=	true,
					Pos3	=	Vector(-36.470001220703,91.849998474121,29.629999160767),
						},
				RunningColor	=	{
						195,
						195,
						255,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-35.319999694824,92.319999694824,30.200000762939),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-36.560001373291,92.319999694824,30.790000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.470001220703,91.849998474121,29.629999160767),
								},
							{
							Pos	=	Vector(-34.110000610352,91.790000915527,29.620000839233),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.099998474121,92.300003051758,30.760000228882),
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
						255,
						100,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.03,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					Use	=	true,
					Mid	=	true,
					AmountH	=	15,
					Pos1	=	Vector(30.110000610352,94.360000610352,30.25),
					InnerCenterOnly	=	true,
					AmountV	=	4,
					Mid_V	=	true,
					Pos2	=	Vector(32.569999694824,94.379997253418,30.280000686646),
					Pos4	=	Vector(30.120000839233,93.849998474121,29.110000610352),
					Mid_Full	=	true,
					Pos3	=	Vector(32.479999542236,93.910003662109,29.120000839233),
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
						255,
						100,
						0,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				HBeamColor	=	{
						195,
						195,
						255,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(31.329999923706,94.379997253418,29.690000534058),
				RenderMLCenter	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(32.569999694824,94.379997253418,30.280000686646),
								},
							{
							Pos	=	Vector(32.479999542236,93.910003662109,29.120000839233),
								},
							{
							Pos	=	Vector(30.120000839233,93.849998474121,29.110000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.110000610352,94.360000610352,30.25),
								},
							},
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
						195,
						195,
						255,
						},
				SpecMat	=	{
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.03,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					Use	=	true,
					Mid	=	true,
					AmountH	=	15,
					Pos1	=	Vector(-29.610000610352,94.360000610352,30.25),
					InnerCenterOnly	=	true,
					AmountV	=	4,
					Mid_V	=	true,
					Pos2	=	Vector(-32.069999694824,94.379997253418,30.280000686646),
					Pos4	=	Vector(-29.620000839233,93.849998474121,29.110000610352),
					Mid_Full	=	true,
					Pos3	=	Vector(-31.979999542236,93.910003662109,29.120000839233),
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
						255,
						100,
						0,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				HBeamColor	=	{
						195,
						195,
						255,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-30.829999923706,94.379997253418,29.690000534058),
				RenderMLCenter	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-32.069999694824,94.379997253418,30.280000686646),
								},
							{
							Pos	=	Vector(-31.979999542236,93.910003662109,29.120000839233),
								},
							{
							Pos	=	Vector(-29.620000839233,93.849998474121,29.110000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.610000610352,94.360000610352,30.25),
								},
							},
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
						195,
						195,
						255,
						},
				SpecMat	=	{
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.03,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					Use	=	true,
					Mid	=	true,
					AmountH	=	15,
					Pos1	=	Vector(25.610000610352,96.860000610352,29.75),
					InnerCenterOnly	=	true,
					AmountV	=	4,
					Mid_V	=	true,
					Pos2	=	Vector(28.069999694824,96.879997253418,29.780000686646),
					Pos4	=	Vector(25.620000839233,96.349998474121,28.610000610352),
					Mid_Full	=	true,
					Pos3	=	Vector(27.979999542236,96.410003662109,28.620000839233),
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
						255,
						100,
						0,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(26.829999923706,96.879997253418,29.190000534058),
				RenderMLCenter	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(28.069999694824,96.879997253418,29.780000686646),
								},
							{
							Pos	=	Vector(27.979999542236,96.410003662109,28.620000839233),
								},
							{
							Pos	=	Vector(25.620000839233,96.349998474121,28.610000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.610000610352,96.860000610352,29.75),
								},
							},
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
						195,
						195,
						255,
						},
				HBeamColor	=	{
						195,
						195,
						255,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.03,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					Use	=	true,
					Mid	=	true,
					AmountH	=	15,
					Pos1	=	Vector(-25.020000457764,96.860000610352,29.85000038147),
					InnerCenterOnly	=	true,
					AmountV	=	4,
					Mid_V	=	true,
					Pos2	=	Vector(-27.479999542236,96.879997253418,29.879999160767),
					Pos4	=	Vector(-25.030000686646,96.349998474121,28.709999084473),
					Mid_Full	=	true,
					Pos3	=	Vector(-27.389999389648,96.410003662109,28.719999313354),
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
						255,
						100,
						0,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-26.239999771118,96.879997253418,29.290000915527),
				RenderMLCenter	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-27.479999542236,96.879997253418,29.879999160767),
								},
							{
							Pos	=	Vector(-27.389999389648,96.410003662109,28.719999313354),
								},
							{
							Pos	=	Vector(-25.030000686646,96.349998474121,28.709999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.020000457764,96.860000610352,29.85000038147),
								},
							},
						},
				UseSprite	=	true,
				RunningColor	=	{
						195,
						195,
						255,
						},
				HBeamColor	=	{
						195,
						195,
						255,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.1,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				SpecMat	=	{
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UsePrjTex	=	true,
				LBeamColor	=	{
						195,
						195,
						255,
						},
				UseDynamic	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(40.200000762939,89.819999694824,30.430000305176),
				RenderInner_Clr	=	{
						255,
						100,
						0,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.1,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseSprite	=	true,
				Pos	=	Vector(-39.700000762939,88.819999694824,30.549999237061),
				UseDynamic	=	true,
				RenderInner	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
						195,
						195,
						255,
						},
				RenderInner_Clr	=	{
						255,
						100,
						0,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				Beta_Inner3D	=	true,
				LBeamColor	=	{
						195,
						195,
						255,
						},
				UseDynamic	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-35.319999694824,92.319999694824,30.200000762939),
				RenderInner_Clr	=	{
						255,
						100,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				Beta_Inner3D	=	true,
				LBeamColor	=	{
						195,
						195,
						255,
						},
				UseDynamic	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(35.830001831055,92.330001831055,30.030000686646),
				RenderInner_Clr	=	{
						255,
						100,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1,
						},
				SpecSpin	=	{
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				HBeamColor	=	{
						195,
						195,
						255,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				UsePrjTex	=	true,
				Pos	=	Vector(-30.829999923706,94.379997253418,29.690000534058),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				Beta_Inner3D	=	true,
				RenderInner_Clr	=	{
						255,
						100,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1,
						},
				SpecSpin	=	{
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				HBeamColor	=	{
						195,
						195,
						255,
						},
				SpecMat	=	{
						},
				UseHighBeams	=	true,
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(31.329999923706,94.379997253418,29.690000534058),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderMLCenter	=	true,
				UsePrjTex	=	true,
				RenderInner_Clr	=	{
						255,
						100,
						0,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1,
						},
				SpecSpin	=	{
						},
				HBeamColor	=	{
						195,
						195,
						255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(26.829999923706,96.879997253418,29.190000534058),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				RenderInner_Clr	=	{
						255,
						100,
						0,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1,
						},
				SpecSpin	=	{
						},
				HBeamColor	=	{
						195,
						195,
						255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-26.239999771118,96.879997253418,29.290000915527),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderMLCenter	=	true,
				RenderInner	=	true,
				RenderInner_Clr	=	{
						255,
						100,
						0,
						},
				UseSprite	=	true,
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(25,0,0),
				Pos	=	Vector(20.39999961853,5.789999961853,21.85000038147),
				RadioControl	=	true,
					},
				},
		Fuel	=	{
			FuelLidPos	=	Vector(-32.490001678467,-34.229999542236,48.229999542236),
			FuelType	=	0,
			Capacity	=	100,
			Override	=	true,
			FuelLidUse	=	true,
				},
		Author	=	"freemmaann (76561197989323181)",
}