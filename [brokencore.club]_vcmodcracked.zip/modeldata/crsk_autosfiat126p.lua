VCModels['models/crsk_autosfiat126p.mdl']	=	{
		em_state	=	5236594569,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		HealthEnginePosOvr	=	true,
		Date	=	"Sat Nov 10 22:50:17 2018",
		Exhaust	=	{
				{
				Ang	=	Angle(20,-90,10),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(9.9099998474121,-68.650001525879,11.039999961853),
				EffectIdle	=	"VC_Exhaust",
					},
				},
		Copyright	=	"Copyright © 2012-2018 VCMod (freemmaann). All Rights Reserved.",
		HealthEnginePos	=	Vector(0,-63.099998474121,29.719999313354),
		DLT	=	3491063046,
		Lights	=	{
				{
				UseRunning	=	true,
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
					Select	=	21,
					New	=	"models\crskautos\fiat\126p\newwhitesped_on",
					Use	=	true,
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Pos	=	Vector(-14.75,20.420000076294,45.009998321533),
					},
				{
				UseRunning	=	true,
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
					Select	=	19,
					New	=	"models\crskautos\fiat\126p\illumsped_on",
					Use	=	true,
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Pos	=	Vector(-11.720000267029,20.420000076294,45.009998321533),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
					New	=	"models\crskautos\fiat\126p\illumsped_on",
					Select	=	19,
						},
				UseSprite	=	true,
				Pos	=	Vector(-23.360000610352,65.959999084473,30.479999542236),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
					New	=	"models\crskautos\fiat\126p\illumsped_on",
					Select	=	19,
						},
				UseSprite	=	true,
				Pos	=	Vector(23.770000457764,65.959999084473,30.479999542236),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				HBeamColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UsePrjTex	=	true,
				Pos	=	Vector(-23.520000457764,65.959999084473,30.479999542236),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				LBeamColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				UseSprite	=	true,
				SpecMat	=	{
					New	=	"models\crskautos\fiat\126p\illumsped_on",
					Select	=	19,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				SpecMat	=	{
					New	=	"models\crskautos\fiat\126p\illumsped_on",
					Select	=	19,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				UseSprite	=	true,
				LBeamColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				HBeamColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				UsePrjTex	=	true,
				Pos	=	Vector(23.639999389648,65.959999084473,30.479999542236),
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				BlinkerLeft	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-23.440000534058,69.01000213623,24.200000762939),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-19.840000152588,69.26000213623,23.079999923706),
					Pos2	=	Vector(-27.200000762939,68.690002441406,25.219999313354),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-19.680000305176,69.220001220703,25.319999694824),
					Pos3	=	Vector(-27.260000228882,68.779998779297,23.14999961853),
						},
				UseBlinkers	=	true,
				SpecMat	=	{
					New	=	"models\crskautos\fiat\126p\illumsped_on",
					Select	=	19,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\fiat\126p\illumsped_on",
					Select	=	19,
						},
				UseSprite	=	true,
				Pos	=	Vector(-35.369998931885,37.040000915527,34.889999389648),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\fiat\126p\illumsped_on",
					Select	=	19,
						},
				UseSprite	=	true,
				Pos	=	Vector(35.369998931885,36.849998474121,34.680000305176),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\fiat\126p\illumsped_on",
					Select	=	19,
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-26.870000839233,-72.410003662109,30.840000152588),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	6,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-31.450000762939,-70.900001525879,30.89999961853),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseBlinkers	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\fiat\126p\illumsped_on",
					Select	=	19,
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(26.610000610352,-72.410003662109,30.659999847412),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	6,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(31.190000534058,-70.900001525879,30.719999313354),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseBlinkers	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1126,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
					New	=	"models\crskautos\fiat\126p\illumsped_on",
					Select	=	19,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-26.870000839233,-72.410003662109,28.120000839233),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-31.450000762939,-70.900001525879,28.180000305176),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.12,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
					New	=	"models\crskautos\fiat\126p\illumsped_on",
					Select	=	19,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(26.559999465942,-72.410003662109,28.229999542236),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(31.139999389648,-70.900001525879,28.290000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
					New	=	"models\crskautos\fiat\126p\illumsped_on",
					Select	=	19,
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-28.040000915527,-72,25.209999084473),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBrake	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
					New	=	"models\crskautos\fiat\126p\illumsped_on",
					Select	=	19,
						},
				ReducedVis	=	true,
				UseBrake	=	true,
				UseSprite	=	true,
				Pos	=	Vector(27.790000915527,-72,25.030000686646),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\fiat\126p\illumsped_on",
					Select	=	19,
						},
				UseSprite	=	true,
				Pos	=	Vector(23.85000038147,69.01000213623,24.200000762939),
				UseDynamic	=	true,
				BlinkerRight	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(20.25,69.26000213623,23.079999923706),
					Pos2	=	Vector(27.610000610352,68.690002441406,25.219999313354),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(20.090000152588,69.220001220703,25.319999694824),
					Pos3	=	Vector(27.670000076294,68.779998779297,23.14999961853),
						},
				UseBlinkers	=	true,
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(12,0,0),
				Pos	=	Vector(14.170000076294,9.8000001907349,31.85000038147),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(12,0,0),
				Pos	=	Vector(-19.629999160767,-24.909999847412,33.369998931885),
					},
				{
				Ang	=	Angle(12,0,0),
				Pos	=	Vector(16.930000305176,-24.909999847412,33.369998931885),
					},
				{
				Ang	=	Angle(12,0,0),
				Pos	=	Vector(-0.68999999761581,-24.909999847412,33.369998931885),
					},
				},
		Fuel	=	{
			FuelLidPos	=	Vector(-36.770000457764,-24.430000305176,29.840000152588),
			FuelType	=	0,
			Capacity	=	20,
			Override	=	true,
			FuelLidUse	=	true,
				},
		Author	=	"DangerKiddy(DK) (76561198132964487)",
}