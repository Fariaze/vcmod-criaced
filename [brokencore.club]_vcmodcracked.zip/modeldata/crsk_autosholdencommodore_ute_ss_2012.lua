VCModels['models/crsk_autosholdencommodore_ute_ss_2012.mdl']	=	{
		em_state	=	5236594986,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Copyright	=	"Copyright © 2012-2017 VCMod (freemmaann). All Rights Reserved.",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(26.959999084473,-134.33999633789,15),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(22.889999389648,-135.66999816895,15.10000038147),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-27.520000457764,-134.16999816895,15.10000038147),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-23.459999084473,-135.57000732422,15.180000305176),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(20,0,0),
				Pos	=	Vector(-18.409999847412,4.8600001335144,31.409999847412),
				RadioControl	=	true,
					},
				},
		DLT	=	3491063324,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.7,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(28.559999465942,94.110000610352,26.860000610352),
					UseColor	=	true,
					Pos2	=	Vector(21.409999847412,95.5,35.200000762939),
					Color	=	{
							222,
							222,
							222,
							},
					Use	=	true,
					Pos1	=	Vector(29.090000152588,92.629997253418,34.869998931885),
					Pos3	=	Vector(20.379999160767,97.309997558594,26.629999160767),
						},
				UseRunning	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				HBeamColor	=	{
						255,
						175,
						100,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(24.639999389648,94.110000610352,30.610000610352),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				RunningColor	=	{
						255,
						175,
						100,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
						195,
						195,
						255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(35.479999542236,91.610000610352,28.309999465942),
					UseColor	=	true,
					Pos2	=	Vector(29.180000305176,91.610000610352,34.610000610352),
					Color	=	{
							222,
							222,
							222,
							},
					Use	=	true,
					Pos1	=	Vector(35.479999542236,91.610000610352,34.610000610352),
					Pos3	=	Vector(29.180000305176,91.610000610352,28.309999465942),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(32.330001831055,91.610000610352,31.459999084473),
				RenderInner	=	true,
				HBeamColor	=	{
						195,
						195,
						255,
						},
				Beta_Inner3D	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
						195,
						195,
						255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-34.950000762939,91.769996643066,28.479999542236),
					UseColor	=	true,
					Pos2	=	Vector(-28.64999961853,91.769996643066,34.779998779297),
					Color	=	{
							222,
							222,
							222,
							},
					Use	=	true,
					Pos1	=	Vector(-34.950000762939,91.769996643066,34.779998779297),
					Pos3	=	Vector(-28.64999961853,91.769996643066,28.479999542236),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-31.799999237061,91.769996643066,31.629999160767),
				RenderInner	=	true,
				HBeamColor	=	{
						195,
						195,
						255,
						},
				Beta_Inner3D	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(37.790000915527,85.720001220703,32.169998168945),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-37.279998779297,85.940002441406,32.349998474121),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				Beta_Inner3D	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(37.569999694824,93.059997558594,13.829999923706),
					Use	=	true,
					Pos2	=	Vector(32.75,93.050003051758,18.5),
					Color	=	{
							222,
							222,
							222,
							},
					UseColor	=	true,
					Pos1	=	Vector(37.569999694824,93.059997558594,18.5),
					Pos3	=	Vector(32.75,93.050003051758,13.829999923706),
						},
				FogColor	=	{
						255,
						175,
						100,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseSprite	=	true,
				Pos	=	Vector(35.159999847412,91.559997558594,16.239999771118),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseFog	=	true,
				Beta_Inner3D	=	true,
				UsePrjTex	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseSprite	=	true,
				UseRunning	=	true,
				RenderInner_Size	=	1,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBrake	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(35.080001831055,-128.27000427246,43.220001220703),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderHD_Size	=	1.2,
				BrakeColor	=	{
						255,
						0,
						0,
						},
				RunningColor	=	{
						255,
						0,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseSprite	=	true,
				UseRunning	=	true,
				RenderInner	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBrake	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-35.689998626709,-128.03999328613,43.540000915527),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				RenderHD_Size	=	1.2,
				BrakeColor	=	{
						255,
						0,
						0,
						},
				RunningColor	=	{
						255,
						0,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseRunning	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(37.659999847412,-125.44999694824,43.180000305176),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderHD_Size	=	1.2,
				UseSprite	=	true,
				RunningColor	=	{
						255,
						0,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseRunning	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-38.200000762939,-125.12999725342,43.590000152588),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderHD_Size	=	1.2,
				Beta_Inner3D	=	true,
				RunningColor	=	{
						255,
						0,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(37.759998321533,-124.88999938965,39.529998779297),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(39.729999542236,-123.30999755859,38.090000152588),
					Pos2	=	Vector(37.110000610352,-127.20999908447,41.180000305176),
					Color	=	{
							0,
							0,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(39.509998321533,-123.51999664307,41.029998779297),
					Pos3	=	Vector(37.119998931885,-127.2200012207,37.639999389648),
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-40.349998474121,-123.01999664307,38.459999084473),
					Pos2	=	Vector(-37.729999542236,-126.91999816895,41.549999237061),
					Color	=	{
							0,
							0,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(-40.130001068115,-123.23000335693,41.400001525879),
					Pos3	=	Vector(-37.740001678467,-126.93000030518,38.009998321533),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-38.380001068115,-124.59999847412,39.900001525879),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(37.099998474121,-127.2200012207,38.009998321533),
					UseColor	=	true,
					Pos2	=	Vector(33.209999084473,-130.97999572754,41.290000915527),
					Color	=	{
							255,
							175,
							100,
							},
					Use	=	true,
					Pos1	=	Vector(37.090000152588,-127.19999694824,41.279998779297),
					Pos3	=	Vector(33.319999694824,-131.00999450684,38.299999237061),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(35.349998474121,-127.90000152588,39.599998474121),
				UseDynamic	=	true,
				RenderInner	=	true,
				ReverseColor	=	{
						255,
						175,
						100,
						},
				UseSprite	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseDynamic	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						255,
						133,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-5.8699998855591,-35.310001373291,69.730003356934),
				RenderHD_Adv	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	11,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(5.9800000190735,-35.349998474121,69.699996948242),
								},
							},
						},
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.7,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Beta_Inner3D	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-28.020000457764,94.110000610352,26.969999313354),
					UseColor	=	true,
					Pos2	=	Vector(-20.870000839233,95.5,35.310001373291),
					Color	=	{
							222,
							222,
							222,
							},
					Use	=	true,
					Pos1	=	Vector(-28.549999237061,92.629997253418,34.979999542236),
					Pos3	=	Vector(-19.840000152588,97.309997558594,26.739999771118),
						},
				RunningColor	=	{
						255,
						175,
						100,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				HBeamColor	=	{
						255,
						175,
						100,
						},
				UseSprite	=	true,
				Pos	=	Vector(-24.10000038147,94.110000610352,30.719999313354),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner	=	true,
				UseRunning	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RenderInner_Size	=	1,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-37.060001373291,93.220001220703,14.039999961853),
					Use	=	true,
					Pos2	=	Vector(-32.240001678467,93.209999084473,18.709999084473),
					Color	=	{
							222,
							222,
							222,
							},
					UseColor	=	true,
					Pos1	=	Vector(-37.060001373291,93.220001220703,18.709999084473),
					Pos3	=	Vector(-32.240001678467,93.209999084473,14.039999961853),
						},
				FogColor	=	{
						255,
						175,
						100,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UsePrjTex	=	true,
				Pos	=	Vector(-34.650001525879,91.720001220703,16.450000762939),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseFog	=	true,
				Beta_Inner3D	=	true,
				UseSprite	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-37.709999084473,-127,38.340000152588),
					UseColor	=	true,
					Pos2	=	Vector(-33.819999694824,-130.75999450684,41.619998931885),
					Color	=	{
							255,
							175,
							100,
							},
					Use	=	true,
					Pos1	=	Vector(-37.700000762939,-126.98000335693,41.610000610352),
					Pos3	=	Vector(-33.930000305176,-130.78999328613,38.630001068115),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-35.959999084473,-127.68000030518,39.930000305176),
				UseDynamic	=	true,
				RenderInner	=	true,
				ReverseColor	=	{
						255,
						175,
						100,
						},
				UseSprite	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				UseSprite	=	true,
				Pos	=	Vector(-45.450000762939,47.180000305176,30.530000686646),
				UseDynamic	=	true,
				RenderInner_Size	=	3,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-45.340000152588,38.299999237061,31.180000305176),
								},
							},
						},
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner_Size	=	3,
				Beta_Inner3D	=	true,
				Pos	=	Vector(45.790000915527,46.810001373291,30.409999847412),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(45.680000305176,37.930000305176,31.059999465942),
								},
							},
						},
				UseSprite	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				RenderMLCenter	=	true,
					},
				},
		Date	=	"Mon Nov 20 02:01:39 2017",
		Fuel	=	{
			FuelType	=	0,
			FuelLidPos	=	Vector(0,0,0),
				},
		Author	=	"CгεερεгƬv (76561198051637331)",
}