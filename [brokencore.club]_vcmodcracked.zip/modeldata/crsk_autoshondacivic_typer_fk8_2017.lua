VCModels['models/crsk_autoshondacivic_typer_fk8_2017.mdl']	=	{
		em_state	=	5236594887,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		HealthEnginePosOvr	=	true,
		Date	=	"Mon Dec 17 19:19:03 2018",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(-4.6900000572205,-100.15000152588,11.699999809265),
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(4.6900000572205,-100.15000152588,11.699999809265),
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(0,-100.15000152588,11.699999809265),
				EffectIdle	=	"VC_Exhaust",
					},
				},
		Copyright	=	"Copyright © 2012-2018 VCMod (freemmaann). All Rights Reserved.",
		HealthEnginePos	=	Vector(0,69.25,34.509998321533),
		DLT	=	3491063258,
		Lights	=	{
				{
				UseRunning	=	true,
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
					Select	=	24,
					New	=	"models\crskautos\honda\civic_typer_fk8_2017\int_symbols_emissive_on",
					Use	=	true,
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Pos	=	Vector(-2.5199999809265,16.360000610352,46.619998931885),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.0887,
						},
				SpecSpin	=	{
						},
				UseRunning	=	true,
				SpecMat	=	{
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-25.829999923706,-88.319999694824,46.849998474121),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-27.459999084473,-87.330001831055,46.240001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-29.559999465942,-85.970001220703,45.409999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.0887,
						},
				SpecSpin	=	{
						},
				UseRunning	=	true,
				SpecMat	=	{
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-25.620000839233,-88.360000610352,45.669998168945),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-27.170000076294,-87.410003662109,45.110000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-29.25,-86.01000213623,44.319999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.0887,
						},
				SpecSpin	=	{
						},
				UseRunning	=	true,
				SpecMat	=	{
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-30.770000457764,-84.919998168945,44.889999389648),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	12,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-32.799999237061,-83.900001525879,43.889999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-34.75,-82.949996948242,42.540000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.0887,
						},
				SpecSpin	=	{
						},
				UseRunning	=	true,
				SpecMat	=	{
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-30.180000305176,-85.400001525879,43.930000305176),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	12,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-32.090000152588,-84.419998168945,42.939998626709),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-33.659999847412,-83.529998779297,41.950000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				UseRunning	=	true,
				SpecMat	=	{
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-33.849998474121,-83.98999786377,40.180000305176),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	22,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-33.580001831055,-84.620002746582,38.950000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-33.259998321533,-85.389999389648,37.75),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-32.630001068115,-86.069999694824,36.970001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-31.639999389648,-87.300003051758,36.419998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-30.579999923706,-88.120002746582,36.049999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-29.270000457764,-89.220001220703,35.650001525879),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-27.860000610352,-90.230003356934,35.279998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-26.14999961853,-91.480003356934,34.909999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				UseRunning	=	true,
				SpecMat	=	{
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-35.490001678467,-82.870002746582,41.009998321533),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	22,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-35.479999542236,-83.269996643066,40.279998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-35.270000457764,-84.050003051758,38.770000457764),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-35.110000610352,-84.809997558594,37.380001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-34.599998474121,-85.639999389648,36.380001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-34.069999694824,-86.279998779297,35.869998931885),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-32.529998779297,-87.639999389648,35.180000305176),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-29.319999694824,-90.23999786377,34.610000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-25.870000839233,-92.169998168945,33.740001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.0887,
						},
				SpecSpin	=	{
						},
				UseRunning	=	true,
				SpecMat	=	{
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(25.829999923706,-88.319999694824,46.849998474121),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(27.459999084473,-87.330001831055,46.240001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(29.559999465942,-85.970001220703,45.409999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.0887,
						},
				SpecSpin	=	{
						},
				UseRunning	=	true,
				SpecMat	=	{
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(25.620000839233,-88.360000610352,45.669998168945),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(27.170000076294,-87.410003662109,45.110000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(29.25,-86.01000213623,44.319999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.0887,
						},
				SpecSpin	=	{
						},
				UseRunning	=	true,
				SpecMat	=	{
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(30.770000457764,-84.919998168945,44.889999389648),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	12,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(32.799999237061,-83.900001525879,43.889999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(34.75,-82.949996948242,42.540000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.0887,
						},
				SpecSpin	=	{
						},
				UseRunning	=	true,
				SpecMat	=	{
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(30.180000305176,-85.400001525879,43.930000305176),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	12,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(32.090000152588,-84.419998168945,42.939998626709),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(33.659999847412,-83.529998779297,41.950000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				UseRunning	=	true,
				SpecMat	=	{
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(35.490001678467,-82.870002746582,41.009998321533),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	22,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(35.479999542236,-83.269996643066,40.279998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(35.270000457764,-84.050003051758,38.770000457764),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(35.110000610352,-84.809997558594,37.380001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(34.599998474121,-85.639999389648,36.380001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(34.069999694824,-86.279998779297,35.869998931885),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(32.529998779297,-87.639999389648,35.180000305176),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(29.319999694824,-90.23999786377,34.610000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(25.870000839233,-92.169998168945,33.740001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				UseRunning	=	true,
				SpecMat	=	{
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(33.849998474121,-83.98999786377,40.180000305176),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	22,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(33.580001831055,-84.620002746582,38.950000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(33.259998321533,-85.389999389648,37.75),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(32.630001068115,-86.069999694824,36.970001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(31.639999389648,-87.300003051758,36.419998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(30.579999923706,-88.120002746582,36.049999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(29.270000457764,-89.220001220703,35.650001525879),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(27.860000610352,-90.230003356934,35.279998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(26.14999961853,-91.480003356934,34.909999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-34.310001373291,-83.400001525879,39.040000915527),
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(34.310001373291,-83.400001525879,39.040000915527),
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				BlinkerLeft	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-30.610000610352,-85.080001831055,40.540000915527),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				UseBlinkers	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-28.829999923706,-87.110000610352,39.330001831055),
					Pos2	=	Vector(-32.909999847412,-84.480003356934,41.330001831055),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-29.139999389648,-85.599998474121,43.200000762939),
					Pos3	=	Vector(-32.479999542236,-84.690002441406,39.270000457764),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(28.829999923706,-87.110000610352,39.330001831055),
					Pos2	=	Vector(32.909999847412,-84.480003356934,41.330001831055),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(29.139999389648,-85.599998474121,43.200000762939),
					Pos3	=	Vector(32.479999542236,-84.690002441406,39.270000457764),
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(30.610000610352,-85.080001831055,40.540000915527),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				BlinkerRight	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-26.379999160767,-90.309997558594,35.419998168945),
					Pos2	=	Vector(-32.470001220703,-85.379997253418,39.020000457764),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-26.860000610352,-89.290000915527,38.959999084473),
					Pos3	=	Vector(-31.309999465942,-85.75,36.880001068115),
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-29.979999542236,-85.819999694824,38.080001831055),
				UseDynamic	=	true,
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(26.379999160767,-90.309997558594,35.419998168945),
					Pos2	=	Vector(32.470001220703,-85.379997253418,39.020000457764),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(26.860000610352,-89.290000915527,38.959999084473),
					Pos3	=	Vector(31.309999465942,-85.75,36.880001068115),
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(29.979999542236,-85.819999694824,38.080001831055),
				UseDynamic	=	true,
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2435,
						},
				SpecSpin	=	{
						},
				UseSprite	=	true,
				SpecMat	=	{
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderHD_Adv	=	true,
				Pos	=	Vector(-2.4100000858307,-92.110000610352,47.650001525879),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					LTbl	=	{
							{
							Pos	=	Vector(-0.76999998092651,-92.040000915527,47.619998931885),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(0.87000000476837,-91.550003051758,47.479999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(2.6099998950958,-91.650001525879,47.5),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
					Use	=	true,
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				DD_Blnk_Run	=	true,
				BlinkerLeft	=	true,
				seq_stay	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-28.049999237061,91.099998474121,27.120000839233),
				RenderInner	=	true,
				RenderInner_Size	=	1.1118,
				SpecMLine	=	{
					Amount	=	23,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-31.670000076294,87.98999786377,28.270000457764),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-33.240001678467,86.160003662109,28.959999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-34.709999084473,83.650001525879,29.790000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-35.75,81,31.10000038147),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-35.889999389648,78.48999786377,33.169998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				seq_use	=	true,
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				DD_Blnk_Run	=	true,
				seq_stay	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				BlinkerRight	=	true,
				UseSprite	=	true,
				Pos	=	Vector(28.049999237061,91.099998474121,27.120000839233),
				UseBlinkers	=	true,
				RenderInner_Size	=	1.1118,
				SpecMLine	=	{
					Amount	=	23,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(31.670000076294,87.98999786377,28.270000457764),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(33.240001678467,86.160003662109,28.959999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(34.709999084473,83.650001525879,29.790000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(35.75,81,31.10000038147),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(35.889999389648,78.48999786377,33.169998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				seq_use	=	true,
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				RenderInner	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-32.610000610352,82.339996337891,30.829999923706),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1625,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				SpecMat	=	{
						},
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-32.610000610352,82.339996337891,30.829999923706),
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1625,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				SpecMat	=	{
						},
				UseSprite	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Pos	=	Vector(-31.389999389648,83.23999786377,30.420000076294),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1625,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				SpecMat	=	{
						},
				UseSprite	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Pos	=	Vector(-29.620000839233,83.879997253418,29.909999847412),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1625,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseSprite	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				Pos	=	Vector(-28.489999771118,85.529998779297,29.680000305176),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1625,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseSprite	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				SpecMat	=	{
						},
				UsePrjTex	=	true,
				Pos	=	Vector(-26.879999160767,86.48999786377,29.379999160767),
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseSprite	=	true,
				Pos	=	Vector(-25.309999465942,87.650001525879,28.799999237061),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-23.819999694824,88.720001220703,28.469999313354),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-22.579999923706,89.449996948242,28.170000076294),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(22.579999923706,89.449996948242,28.170000076294),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(23.819999694824,88.720001220703,28.469999313354),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseSprite	=	true,
				Pos	=	Vector(25.309999465942,87.650001525879,28.799999237061),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1625,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseSprite	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				SpecMat	=	{
						},
				UsePrjTex	=	true,
				Pos	=	Vector(26.879999160767,86.48999786377,29.379999160767),
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1625,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseSprite	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				Pos	=	Vector(28.489999771118,85.529998779297,29.680000305176),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1625,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				SpecMat	=	{
						},
				UseSprite	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Pos	=	Vector(29.620000839233,83.879997253418,29.909999847412),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1625,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				SpecMat	=	{
						},
				UseSprite	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Pos	=	Vector(31.389999389648,83.23999786377,30.420000076294),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				SpecMat	=	{
						},
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(32.610000610352,82.339996337891,30.829999923706),
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				RenderInner	=	true,
				FogColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				SpecMat	=	{
						},
				inner_AsSpheres	=	true,
				UseSprite	=	true,
				UsePrjTex	=	true,
				Pos	=	Vector(-32.389999389648,91.209999084473,15.829999923706),
				UseDynamic	=	true,
				RenderInner_Size	=	1.7844,
				UseFog	=	true,
				Dynamic	=	{
					Size	=	0.8,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				inner_AsSpheres	=	true,
				FogColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				RenderInner	=	true,
				UsePrjTex	=	true,
				Pos	=	Vector(32.389999389648,91.209999084473,15.829999923706),
				UseDynamic	=	true,
				RenderInner_Size	=	1.7844,
				UseFog	=	true,
				Dynamic	=	{
					Size	=	0.8,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(25,0,0),
				Pos	=	Vector(16.079999923706,14.460000038147,30.639999389648),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(21,0,0),
				Pos	=	Vector(-18.329999923706,-25.450000762939,28.139999389648),
					},
				{
				Ang	=	Angle(21,0,0),
				Pos	=	Vector(18.329999923706,-25.450000762939,28.139999389648),
					},
				{
				Ang	=	Angle(21,0,0),
				Pos	=	Vector(-0.63999998569489,-25.450000762939,28.139999389648),
					},
				},
		Fuel	=	{
			FuelLidPos	=	Vector(-37.849998474121,-65.01000213623,41.720001220703),
			FuelLidUse	=	true,
			FuelType	=	0,
			Capacity	=	47,
			Override	=	true,
			FuelTypeUse	=	true,
				},
		Author	=	"Krijag (76561198102043843)",
}