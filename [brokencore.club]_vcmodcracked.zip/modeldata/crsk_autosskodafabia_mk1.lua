VCModels['models/crsk_autosskodafabia_mk1.mdl']	=	{
		em_state	=	5236594395,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Copyright	=	"Copyright © 2012-2018 VCMod (freemmaann). All Rights Reserved.",
		ExtraSeats	=	{
				{
				Ang	=	Angle(16,0,0),
				Pos	=	Vector(16.870000839233,18.610000610352,30.540000915527),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(16,0,0),
				Pos	=	Vector(-20.139999389648,-30.639999389648,34.880001068115),
					},
				{
				Ang	=	Angle(16,0,0),
				Pos	=	Vector(20.139999389648,-30.639999389648,34.880001068115),
					},
				{
				Ang	=	Angle(16,0,0),
				Pos	=	Vector(0,-30.639999389648,34.880001068115),
					},
				},
		DLT	=	3491062930,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-25.409999847412,88.720001220703,33.400001525879),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
						195,
						195,
						255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-20.190000534058,91.599998474121,33.220001220703),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
						195,
						195,
						255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(26.479999542236,89.269996643066,33.349998474121),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
						195,
						195,
						255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(20.659999847412,91.660003662109,33.060001373291),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
						195,
						195,
						255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-31.180000305176,87.930000305176,34.099998474121),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(31.680000305176,88.040000915527,33.880001068115),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-38.759998321533,47.389999389648,35.25),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(37.380001068115,47.150001525879,34.990001678467),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				SpecMat	=	{
						},
				UsePrjTex	=	true,
				Pos	=	Vector(26.260000228882,88.370002746582,33.340000152588),
				UseDynamic	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseSprite	=	true,
				LBeamColor	=	{
						195,
						195,
						255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				SpecMat	=	{
						},
				UsePrjTex	=	true,
				LBeamColor	=	{
						195,
						195,
						255,
						},
				UseDynamic	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				Pos	=	Vector(-25.139999389648,89.519996643066,33.509998321533),
				UseSprite	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				UsePrjTex	=	true,
				Pos	=	Vector(-19.920000076294,88.599998474121,33.130001068115),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseSprite	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				HBeamColor	=	{
						195,
						195,
						255,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				HBeamColor	=	{
						195,
						195,
						255,
						},
				UsePrjTex	=	true,
				Pos	=	Vector(20.559999465942,88.440002441406,33.029998779297),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				SpecMat	=	{
						},
				UseSprite	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				FogColor	=	{
						195,
						195,
						255,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(28.729999542236,95.819999694824,17.14999961853),
				UseDynamic	=	true,
				UseFog	=	true,
				Dynamic	=	{
					Size	=	0.8,
					Brightness	=	2,
						},
				UsePrjTex	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				FogColor	=	{
						195,
						195,
						255,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-28.879999160767,95.970001220703,17.090000152588),
				UseDynamic	=	true,
				UseFog	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UsePrjTex	=	true,
				Dynamic	=	{
					Size	=	0.8,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-33.220001220703,-82.540000915527,40.919998168945),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	2,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-29.809999465942,-80.889999389648,41.040000915527),
								},
							},
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(33.229999542236,-80.26000213623,40.709999084473),
				UseDynamic	=	true,
				SpecMLine	=	{
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(30.010000228882,-81.389999389648,40.889999389648),
								},
							},
					Use	=	true,
						},
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-33.200000762939,-81.400001525879,44.25),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	2,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-29.790000915527,-82.139999389648,44.369998931885),
								},
							},
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(33.299999237061,-80.389999389648,43.889999389648),
				UseDynamic	=	true,
				SpecMLine	=	{
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(30.85000038147,-81.669998168945,44.069999694824),
								},
							},
					Use	=	true,
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(34.340000152588,-80.23999786377,33.590000152588),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	3,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(29.829999923706,-82.690002441406,33.110000610352),
								},
							},
						},
				UseRunning	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-33.729999542236,-79.559997558594,33.470001220703),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	3,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-28.35000038147,-81.26000213623,32.810001373291),
								},
							},
						},
				UseRunning	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseReverse	=	true,
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-33.299999237061,-79.870002746582,37.049999237061),
				UseDynamic	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				SpecMLine	=	{
					Amount	=	3,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-28.75,-83.089996337891,37.169998168945),
								},
							},
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseReverse	=	true,
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(33.889999389648,-79.76000213623,36.880001068115),
				UseDynamic	=	true,
				ReverseColor	=	{
					r	=	200,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				SpecMLine	=	{
					Amount	=	3,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(29.020000457764,-82.790000915527,37.060001373291),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
					},
				},
		Date	=	"Fri Mar 16 20:25:56 2018",
		Fuel	=	{
			FuelLidPos	=	Vector(38.080001831055,-68.650001525879,43.610000610352),
			FuelType	=	0,
			Capacity	=	45,
			Override	=	true,
			FuelLidUse	=	true,
				},
		Author	=	"CrushingSkirmish (76561198017348899)",
}