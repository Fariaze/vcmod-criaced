VCModels['models/crsk_autosmitsubishigalante39a_1987.mdl']	=	{
		em_state	=	5236595049,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		HealthEnginePosOvr	=	true,
		Date	=	"Tue Jun 20 15:34:04 2017",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(19.819999694824,-98.900001525879,13.329999923706),
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(23.219999313354,-98.900001525879,13.329999923706),
				EffectIdle	=	"VC_Exhaust",
					},
				},
		Copyright	=	"Copyright © 2012-2017 VCMod (freemmaann). All Rights Reserved.",
		HealthEnginePos	=	Vector(0,72,27),
		DLT	=	3491063366,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				SpecRec	=	{
					Pos4	=	Vector(31.569999694824,94.300003051758,26.790000915527),
					AmountH	=	10,
					Pos1	=	Vector(31.530000686646,95.209999084473,30.969999313354),
					InnerCenterOnly	=	true,
					AmountV	=	10,
					Pos2	=	Vector(23.950000762939,96.839996337891,31.049999237061),
					Use	=	true,
					Mid_Full	=	true,
					Pos3	=	Vector(23.780000686646,96.23999786377,26.729999542236),
						},
				LBeamColor	=	{
						255,
						175,
						100,
						},
				UseDynamic	=	true,
				RenderHD_Size	=	0.3,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(27.690000534058,96.300003051758,29),
				DD_Glow	=	true,
				RenderGlow_Size	=	0,
				RunningColor	=	{
						255,
						175,
						100,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				SpecRec	=	{
					Pos4	=	Vector(-30.819999694824,94.569999694824,26.920000076294),
					AmountH	=	10,
					Pos1	=	Vector(-30.780000686646,95.480003356934,31.10000038147),
					InnerCenterOnly	=	true,
					AmountV	=	10,
					Pos2	=	Vector(-23.200000762939,97.110000610352,31.180000305176),
					Use	=	true,
					Mid_Full	=	true,
					Pos3	=	Vector(-23.030000686646,96.51000213623,26.860000610352),
						},
				LBeamColor	=	{
						255,
						175,
						100,
						},
				UseDynamic	=	true,
				RenderHD_Size	=	0.3,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-26.940000534058,96.569999694824,29.129999160767),
				DD_Glow	=	true,
				Beta_Inner3D	=	true,
				RunningColor	=	{
						255,
						175,
						100,
						},
				RenderGlow_Size	=	0,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(27.870000839233,95.080001831055,28.930000305176),
				UseDynamic	=	true,
				UseSprite	=	true,
				RenderHD_Size	=	0.6,
				UsePrjTex	=	true,
				LBeamColor	=	{
						255,
						175,
						100,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.04,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecRec	=	{
					Pos4	=	Vector(23.170000076294,96.669998168945,26.760000228882),
					AmountH	=	17,
					Pos1	=	Vector(23.170000076294,97.370002746582,31),
					InnerCenterOnly	=	true,
					AmountV	=	17,
					Pos2	=	Vector(15.859999656677,98.019996643066,31.049999237061),
					Use	=	true,
					Mid_Full	=	true,
					Pos3	=	Vector(14.14999961853,97.970001220703,26.670000076294),
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				HBeamColor	=	{
						255,
						175,
						100,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(19.299999237061,97.5,29.10000038147),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderHD_Size	=	0.3,
				RenderGlow_Size	=	0,
				DD_Glow	=	true,
				SpecMat	=	{
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(19.629999160767,96.300003051758,28.770000457764),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderHD_Size	=	0.7,
				UsePrjTex	=	true,
				HBeamColor	=	{
						255,
						175,
						100,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.06,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						90,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				SpecRec	=	{
					Pos4	=	Vector(35.599998474121,88.180000305176,26.629999160767),
					AmountH	=	10,
					Pos1	=	Vector(34.930000305176,89.830001831055,31.370000839233),
					InnerCenterOnly	=	true,
					AmountV	=	5,
					Pos2	=	Vector(32.049999237061,94.379997253418,31.229999542236),
					Use	=	true,
					Mid_Full	=	true,
					Pos3	=	Vector(32.400001525879,94.080001831055,26.85000038147),
						},
				UseSprite	=	true,
				Pos	=	Vector(33.080001831055,90.48999786377,28.760000228882),
				DD_Glow	=	true,
				RenderHD_Size	=	0.3,
				RenderGlow_Size	=	0,
				UseDynamic	=	true,
				Beta_Inner3D	=	true,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.06,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						90,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				SpecRec	=	{
					Pos4	=	Vector(-35.180000305176,88.099998474121,26.770000457764),
					AmountH	=	10,
					Pos1	=	Vector(-34.509998321533,89.75,31.510000228882),
					InnerCenterOnly	=	true,
					AmountV	=	5,
					Pos2	=	Vector(-31.629999160767,94.300003051758,31.370000839233),
					Use	=	true,
					Mid_Full	=	true,
					Pos3	=	Vector(-31.979999542236,94,26.989999771118),
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-32.659999847412,90.410003662109,28.89999961853),
				DD_Glow	=	true,
				RenderHD_Size	=	0.3,
				RenderGlow_Size	=	0,
				UseDynamic	=	true,
				UseSprite	=	true,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.06,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecRec	=	{
					AmountV	=	8,
					Pos4	=	Vector(26.219999313354,99.599998474121,17.069999694824),
					Mid_Full	=	true,
					Pos2	=	Vector(22.030000686646,101.54000091553,19.770000457764),
					AmountH	=	8,
					Use	=	true,
					Pos1	=	Vector(26.459999084473,100.34999847412,19.700000762939),
					Pos3	=	Vector(21.770000457764,100.48000335693,17.110000610352),
						},
				FogColor	=	{
						255,
						175,
						100,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(24.360000610352,99.949996948242,18.090000152588),
				UseDynamic	=	true,
				Beta_Inner3D	=	true,
				RenderGlow_Size	=	0,
				UseFog	=	true,
				RenderHD_Size	=	0,
				DD_Glow	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				FogColor	=	{
						255,
						175,
						100,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(23.860000610352,99.769996643066,18.489999771118),
				UseDynamic	=	true,
				RenderGlow_Size	=	0,
				RenderHD_Size	=	0.8,
				UseFog	=	true,
				UseSprite	=	true,
				UsePrjTex	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				FogColor	=	{
						255,
						175,
						100,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UsePrjTex	=	true,
				Pos	=	Vector(-23.409999847412,99.790000915527,18.610000610352),
				UseDynamic	=	true,
				RenderGlow_Size	=	0,
				UseFog	=	true,
				RenderHD_Size	=	0.8,
				Beta_Inner3D	=	true,
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.03,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecRec	=	{
					Pos4	=	Vector(-21.10000038147,-98.75,31.639999389648),
					AmountH	=	15,
					Pos1	=	Vector(-21.020000457764,-98.76000213623,36.529998779297),
					InnerCenterOnly	=	true,
					AmountV	=	15,
					Pos2	=	Vector(-32.310001373291,-97.559997558594,36.240001678467),
					Use	=	true,
					Mid_Full	=	true,
					Pos3	=	Vector(-34.439998626709,-95.910003662109,31.729999542236),
						},
				UseDynamic	=	true,
				RenderGlow_Size	=	5,
				BrakeColor	=	{
						255,
						0,
						0,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-29.549999237061,-97.099998474121,34.080001831055),
				RenderHD_Adv	=	true,
				UseBrake	=	true,
				RenderHD_Size	=	0.5,
				RunningColor	=	{
						255,
						0,
						0,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.03,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecRec	=	{
					Pos4	=	Vector(20.60000038147,-98.849998474121,31.639999389648),
					AmountH	=	15,
					Pos1	=	Vector(20.520000457764,-98.860000610352,36.529998779297),
					InnerCenterOnly	=	true,
					AmountV	=	15,
					Pos2	=	Vector(31.809999465942,-97.660003662109,36.240001678467),
					Use	=	true,
					Mid_Full	=	true,
					Pos3	=	Vector(34.439998626709,-96.01000213623,31.729999542236),
						},
				UseDynamic	=	true,
				RenderHD_Size	=	0.5,
				BrakeColor	=	{
						255,
						0,
						0,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(29.049999237061,-97.199996948242,34.080001831055),
				UseBrake	=	true,
				RenderHD_Adv	=	true,
				RenderGlow_Size	=	5,
				RunningColor	=	{
						255,
						0,
						0,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.03,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecRec	=	{
					Pos4	=	Vector(19.270000457764,-98.860000610352,31.860000610352),
					AmountH	=	13,
					Pos1	=	Vector(19.270000457764,-98.949996948242,36.5),
					InnerCenterOnly	=	true,
					AmountV	=	13,
					Pos2	=	Vector(10.279999732971,-99.330001831055,36.5),
					Use	=	true,
					Mid_Full	=	true,
					Pos3	=	Vector(11.739999771118,-98.860000610352,31.879999160767),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(14.659999847412,-99.099998474121,34.169998168945),
				UseDynamic	=	true,
				UseSprite	=	true,
				RenderHD_Size	=	0.3,
				RenderGlow_Size	=	0,
				RunningColor	=	{
						255,
						0,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.03,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecRec	=	{
					Pos4	=	Vector(-19.60000038147,-98.860000610352,31.85000038147),
					AmountH	=	13,
					Pos1	=	Vector(-19.60000038147,-98.949996948242,36.5),
					InnerCenterOnly	=	true,
					AmountV	=	13,
					Pos2	=	Vector(-10.590000152588,-99.330001831055,36.450000762939),
					Use	=	true,
					Mid_Full	=	true,
					Pos3	=	Vector(-12.069999694824,-98.860000610352,31.870000839233),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-14.989999771118,-99.099998474121,34.159999847412),
				UseDynamic	=	true,
				Beta_Inner3D	=	true,
				RenderHD_Size	=	0.3,
				RenderGlow_Size	=	0,
				RunningColor	=	{
						255,
						0,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.13,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BGroups	=	{
					[5]	=	{
						[0]	=	"spoiler",
							},
						},
				UseDynamic	=	true,
				RenderGlow_Size	=	5,
				BrakeColor	=	{
						255,
						0,
						0,
						},
				RenderInner_Clr	=	{
						255,
						55,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-10.779999732971,-100.05000305176,44.700000762939),
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	23,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-0.12999999523163,-100.04000091553,44.790000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(10.5,-100.04000091553,44.599998474121),
								},
							},
						},
				RenderMLCenter	=	true,
				UseBrake	=	true,
				RenderHD_Size	=	0.5,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.13,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseDynamic	=	true,
				RenderHD_Size	=	0.5,
				RenderInner_Clr	=	{
						255,
						55,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						133,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-34.610000610352,-95.199996948242,30.670000076294),
				RenderGlow_Size	=	5,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	23,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-34.240001678467,-95.669998168945,30.64999961853),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.689998626709,-96.129997253418,30.629999160767),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.810001373291,-96.629997253418,30.610000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.799999237061,-97.099998474121,30.590000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.129999160767,-97.589996337891,30.60000038147),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.280000686646,-97.910003662109,30.60000038147),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.579999923706,-98.169998168945,30.579999923706),
								},
							},
						},
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.13,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseDynamic	=	true,
				RenderHD_Size	=	0.5,
				RenderInner_Clr	=	{
						255,
						55,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						133,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderGlow_Size	=	5,
				Beta_Inner3D	=	true,
				Pos	=	Vector(34.220001220703,-95.389999389648,30.489999771118),
				UseSprite	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	23,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(33.849998474121,-95.860000610352,30.469999313354),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.299999237061,-96.319999694824,30.450000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.419998168945,-96.819999694824,30.430000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.409999847412,-97.290000915527,30.409999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.739999771118,-97.779998779297,30.420000076294),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.889999389648,-98.099998474121,30.420000076294),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.190000534058,-98.360000610352,30.39999961853),
								},
							},
						},
				UseBlinkers	=	true,
				RenderInner_Size	=	1,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.13,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseReverse	=	true,
				UseDynamic	=	true,
				RenderHD_Size	=	0.5,
				RenderInner_Clr	=	{
						255,
						175,
						100,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				ReverseColor	=	{
						255,
						175,
						100,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(11.699999809265,-99.169998168945,30.459999084473),
				UseSprite	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	15,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(19.020000457764,-98.75,30.479999542236),
								},
							},
						},
				RenderInner_Size	=	1.7,
				RenderGlow_Size	=	5,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.13,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseReverse	=	true,
				UseDynamic	=	true,
				ReverseColor	=	{
						255,
						175,
						100,
						},
				RenderInner_Clr	=	{
						255,
						175,
						100,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-12.260000228882,-99.099998474121,30.450000762939),
				RenderHD_Size	=	0.5,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	15,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-19.579999923706,-98.680000305176,30.469999313354),
								},
							},
						},
				RenderInner_Size	=	1.7,
				RenderGlow_Size	=	5,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.13,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseReverse	=	true,
				UseDynamic	=	true,
				RenderHD_Size	=	0.5,
				RenderInner_Clr	=	{
						255,
						175,
						100,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				UseSprite	=	true,
				Pos	=	Vector(20.180000305176,-98.699996948242,30.450000762939),
				ReverseColor	=	{
						255,
						175,
						100,
						},
				RenderInner_Size	=	1.7,
				SpecMLine	=	{
					Amount	=	9,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(24.379999160767,-98.440002441406,30.430000305176),
								},
							},
						},
				RenderInner	=	true,
				RenderGlow_Size	=	5,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.13,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseReverse	=	true,
				UseDynamic	=	true,
				ReverseColor	=	{
						255,
						175,
						100,
						},
				RenderInner_Clr	=	{
						255,
						175,
						100,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-20.729999542236,-98.580001831055,30.510000228882),
				RenderHD_Size	=	0.5,
				RenderInner_Size	=	1.7,
				SpecMLine	=	{
					Amount	=	9,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-24.930000305176,-98.319999694824,30.489999771118),
								},
							},
						},
				RenderInner	=	true,
				RenderGlow_Size	=	5,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseDynamic	=	true,
				RenderHD_Size	=	0.5,
				RenderInner_Clr	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						55,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-38.450000762939,-82.309997558594,23.420000076294),
				RenderHD_Adv	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	11,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-38.430000305176,-83.800003051758,23.430000305176),
								},
							},
						},
				UseBlinkers	=	true,
				RenderInner_Size	=	1,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseDynamic	=	true,
				RenderHD_Size	=	0.5,
				RenderInner_Clr	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						55,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				RenderHD_Adv	=	true,
				Pos	=	Vector(38.099998474121,-82.540000915527,23.200000762939),
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	11,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(38.080001831055,-84.029998779297,23.209999084473),
								},
							},
						},
				RenderMLCenter	=	true,
				RenderInner_Size	=	1,
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.04,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecRec	=	{
					Pos4	=	Vector(-22.569999694824,96.800003051758,26.889999389648),
					AmountH	=	17,
					Pos1	=	Vector(-22.569999694824,97.5,31.129999160767),
					InnerCenterOnly	=	true,
					AmountV	=	17,
					Pos2	=	Vector(-15.260000228882,98.150001525879,31.180000305176),
					Use	=	true,
					Mid_Full	=	true,
					Pos3	=	Vector(-13.550000190735,98.099998474121,26.799999237061),
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				HBeamColor	=	{
						255,
						175,
						100,
						},
				UseSprite	=	true,
				Pos	=	Vector(-18.700000762939,97.629997253418,29.229999542236),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderGlow_Size	=	0,
				RenderHD_Size	=	0.3,
				DD_Glow	=	true,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UsePrjTex	=	true,
				LBeamColor	=	{
						255,
						175,
						100,
						},
				UseDynamic	=	true,
				Beta_Inner3D	=	true,
				RenderHD_Size	=	0.6,
				UseSprite	=	true,
				Pos	=	Vector(-27.329999923706,95.180000305176,28.909999847412),
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				HBeamColor	=	{
						255,
						175,
						100,
						},
				ReducedVis	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UsePrjTex	=	true,
				Pos	=	Vector(-19.059999465942,96.400001525879,28.829999923706),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderHD_Size	=	0.7,
				Beta_Inner3D	=	true,
				SpecMat	=	{
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.06,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecRec	=	{
					AmountV	=	8,
					Pos4	=	Vector(-25.659999847412,99.680000305176,17.14999961853),
					Mid_Full	=	true,
					Pos2	=	Vector(-21.469999313354,101.62000274658,19.85000038147),
					AmountH	=	8,
					Use	=	true,
					Pos1	=	Vector(-25.89999961853,100.43000030518,19.780000686646),
					Pos3	=	Vector(-21.209999084473,100.55999755859,17.190000534058),
						},
				FogColor	=	{
						255,
						175,
						100,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-23.799999237061,100.0299987793,18.170000076294),
				UseDynamic	=	true,
				UseSprite	=	true,
				UseFog	=	true,
				RenderGlow_Size	=	0,
				RenderHD_Size	=	0,
				DD_Glow	=	true,
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(16.780000686646,18.989999771118,26.840000152588),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(-16.780000686646,-28.920000076294,29.840000152588),
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(16.780000686646,-28.920000076294,29.840000152588),
					},
				},
		Fuel	=	{
			FuelLidPos	=	Vector(-36.869998931885,-69.699996948242,35.029998779297),
			FuelType	=	0,
			Capacity	=	62,
			Override	=	true,
			FuelLidUse	=	true,
				},
		Author	=	"CгεερεгƬv (76561198051637331)",
}