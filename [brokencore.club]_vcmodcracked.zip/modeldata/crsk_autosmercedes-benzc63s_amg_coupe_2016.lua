VCModels['models/crsk_autosmercedes-benzc63s_amg_coupe_2016.mdl']	=	{
		em_state	=	5236594485,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		HealthEnginePosOvr	=	true,
		Date	=	"Sat Dec  2 23:07:44 2017",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(-28.299999237061,-114.81999969482,16.440000534058),
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(-21.860000610352,-116.48999786377,16.690000534058),
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(27.85000038147,-114.79000091553,16.239999771118),
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(21.489999771118,-116.55000305176,16.5),
				EffectIdle	=	"VC_Exhaust",
					},
				},
		Indication	=	{
			speedo_kmph	=	{
				max	=	1,
				pp	=	"vehicle_guage",
				min	=	0,
				top	=	240,
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(10,0,0),
				Pos	=	Vector(17.510000228882,-2.5799999237061,28.229999542236),
				RadioControl	=	true,
					},
				{
				Pos	=	Vector(-15.020000457764,-37.939998626709,34.740001678467),
				DriveBy_Cant	=	true,
				Ang	=	Angle(10,0,0),
				Cant_EnterExitOutside	=	true,
				Cant_Exit_Lock	=	true,
				Cant_EnterOutside	=	true,
					},
				{
				Pos	=	Vector(15.020000457764,-37.939998626709,34.740001678467),
				DriveBy_Cant	=	true,
				Ang	=	Angle(10,0,0),
				Cant_EnterExitOutside	=	true,
				Cant_Exit_Lock	=	true,
				Cant_EnterOutside	=	true,
					},
				},
		HealthEnginePos	=	Vector(0,67.23999786377,32.599998474121),
		DLT	=	3491062990,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseBrake	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-36.479999542236,-98.220001220703,41.450000762939),
				RenderInner_Size	=	1,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	15,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-36.150001525879,-99.059997558594,41.5),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.700000762939,-100,41.569999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.330001831055,-100.68000030518,41.610000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.869998931885,-101.40000152588,41.639999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.380001068115,-102.13999938965,41.669998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.900001525879,-102.7799987793,41.689998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33,-103.83000183105,41.740001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.159999847412,-104.69999694824,41.779998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.489999771118,-105.36000061035,41.799999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.819999694824,-105.94000244141,41.810001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.139999389648,-106.51000213623,41.830001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.459999084473,-107.01999664307,41.849998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.879999160767,-107.41000366211,41.869998931885),
								},
							},
						},
				UseSprite	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-37.840000152588,-96.059997558594,40.25),
				RenderMLCenter	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	15,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-36.770000457764,-98.970001220703,40.229999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.220001220703,-100.48000335693,40.220001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.840000152588,-101.33000183105,40.220001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.430000305176,-102.16999816895,40.209999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.169998168945,-102.66000366211,40.209999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.869998931885,-103.16000366211,40.200000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.560001373291,-103.62999725342,40.200000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.169998168945,-104.13999938965,40.189998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.799999237061,-104.58999633789,40.180000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.310001373291,-105.11000061035,40.169998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.799999237061,-105.62999725342,40.159999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.259998321533,-106.11000061035,40.139999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.709999084473,-106.56999969482,40.110000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.14999961853,-107.01999664307,40.099998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.239999771118,-107.73000335693,40.069999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.930000305176,-107.94999694824,40.060001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.469999313354,-108.26999664307,40.049999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.059999465942,-108.55999755859,40.040000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.719999313354,-108.79000091553,40.029998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.290000915527,-109.05000305176,40.020000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.780000686646,-109.33999633789,40.020000457764),
								},
							},
						},
				UseBrake	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseRunning	=	true,
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-38.090000152588,-96.849998474121,39.229999542236),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	15,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-37.389999389648,-98.839996337891,39.25),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.590000152588,-100.95999908447,39.25),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.159999847412,-101.93000030518,39.229999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.75,-102.76000213623,39.209999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.279998779297,-103.55999755859,39.180000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.740001678467,-104.33000183105,39.169998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.200000762939,-105.01000213623,39.139999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.479999542236,-105.80000305176,39.099998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.740001678467,-106.5,39.069999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.75,-107.30000305176,39.020000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.739999771118,-108.04000091553,38.990001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.940000534058,-109.2200012207,38.919998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.110000610352,-110.33999633789,38.900001525879),
								},
							},
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-37.639999389648,-99.540000915527,37.970001220703),
				RenderInner_Size	=	1,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-37.169998168945,-101.01999664307,37.889999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.619998931885,-102.45999908447,37.810001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.150001525879,-103.48000335693,37.759998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.630001068115,-104.4700012207,37.700000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.310001373291,-105.01000213623,37.659999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.959999084473,-105.51000213623,37.619998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.590000152588,-105.95999908447,37.580001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.139999389648,-106.44000244141,37.549999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.659999847412,-106.91000366211,37.5),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.040000915527,-107.45999908447,37.450000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.279998779297,-108.05000305176,37.380001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.270000457764,-108.7200012207,37.310001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.180000305176,-109.37999725342,37.229999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.059999465942,-109.98000335693,37.150001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.920000076294,-110.56999969482,37.099998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.760000228882,-111.12000274658,37.049999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.170000076294,-111.34999847412,37.040000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.610000610352,-111.55000305176,37.029998779297),
								},
							},
						},
				RenderMLCenter	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.11,
						},
				SpecSpin	=	{
						},
				RenderMLCenter	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseSprite	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-20.209999084473,-112.73999786377,39),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-26.059999465942,-110.66999816895,38.889999389648),
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-24.909999847412,-111.73000335693,37.099998474121),
				RenderInner_Size	=	1,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-23.489999771118,-112.16000366211,37.380001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-22.85000038147,-112.33999633789,37.520000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-22.329999923706,-112.48000335693,37.639999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-21.969999313354,-112.55999755859,37.75),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-21.719999313354,-112.62000274658,37.830001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-21.479999542236,-112.66000366211,37.919998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-21.159999847412,-112.7200012207,38.069999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-20.85000038147,-112.76999664307,38.240001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-20.610000610352,-112.79000091553,38.419998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-20.479999542236,-112.79000091553,38.540000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-20.370000839233,-112.7799987793,38.700000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-20.280000686646,-112.76000213623,38.849998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-20.209999084473,-112.73999786377,39),
								},
							},
						},
				RenderMLCenter	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.09,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						255,
						155,
						0,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-26.989999771118,-109.56999969482,40.069999694824),
				UseSprite	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-20.510000228882,-112.15000152588,40.130001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-20.409999847412,-112.16999816895,40.180000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-20.319999694824,-112.18000030518,40.279998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-20.319999694824,-112.11000061035,40.450000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-20.469999313354,-111.98999786377,40.590000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-20.680000305176,-111.80000305176,40.790000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-21.010000228882,-111.5299987793,41.040000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-21.409999847412,-111.23999786377,41.319999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-21.760000228882,-110.98999786377,41.540000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-22.159999847412,-110.73000335693,41.729999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-22.360000610352,-110.58999633789,41.810001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-22.559999465942,-110.48000335693,41.849998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-22.770000457764,-110.37999725342,41.889999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-23.010000228882,-110.26000213623,41.930000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-23.299999237061,-110.12000274658,41.959999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-23.590000152588,-109.98999786377,41.979999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.209999084473,-109.70999908447,42),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.540000915527,-109.11000061035,41.990001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.120000839233,-107.86000061035,41.930000305176),
								},
							},
						},
				RenderInner	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseBrake	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(37.490001678467,-96.230003356934,40.060001373291),
				RenderInner	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(36.419998168945,-99.139999389648,40.040000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.869998931885,-100.65000152588,40.029998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.490001678467,-101.5,40.029998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.080001831055,-102.33999633789,40.020000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.819999694824,-102.83000183105,40.020000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.520000457764,-103.33000183105,40.009998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.209999084473,-103.80000305176,40.009998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.819999694824,-104.30999755859,40),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.450000762939,-104.76000213623,40),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.959999084473,-105.2799987793,40),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.450000762939,-105.80000305176,39.990001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.909999847412,-106.2799987793,39.979999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.360000610352,-106.73999786377,39.970001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.799999237061,-107.19000244141,39.959999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.889999389648,-107.90000152588,39.950000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.579999923706,-108.12000274658,39.939998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.120000839233,-108.44000244141,39.930000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.709999084473,-108.73000335693,39.919998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.370000839233,-108.95999908447,39.919998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.940000534058,-109.2200012207,39.909999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.430000305176,-109.51000213623,39.900001525879),
								},
							},
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(37.720001220703,-97.01000213623,39.040000915527),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(37.020000457764,-99,39.060001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.220001220703,-101.12000274658,39.060001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.790000915527,-102.08999633789,39.040000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.380001068115,-102.91999816895,39.020000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.909999847412,-103.7200012207,39.009998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.369998931885,-104.48999786377,39),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.830001831055,-105.16999816895,38.970001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.110000610352,-105.95999908447,38.939998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.369998931885,-106.66000366211,38.909999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.379999160767,-107.45999908447,38.860000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.370000839233,-108.19999694824,38.830001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.569999694824,-109.37999725342,38.790000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.700000762939,-110.5,38.759998321533),
								},
							},
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(37.310001373291,-99.680000305176,37.799999237061),
				RenderInner	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(36.840000152588,-101.16000366211,37.720001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.290000915527,-102.59999847412,37.639999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.819999694824,-103.62000274658,37.590000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.299999237061,-104.61000061035,37.529998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.979999542236,-105.15000152588,37.490001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.630001068115,-105.65000152588,37.450000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.259998321533,-106.09999847412,37.409999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.810001373291,-106.58000183105,37.380001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.330001831055,-107.05000305176,37.330001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.709999084473,-107.59999847412,37.279998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.950000762939,-108.19000244141,37.240001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.940000534058,-108.86000061035,37.180000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.85000038147,-109.51999664307,37.110000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.729999542236,-110.12000274658,37.049999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.590000152588,-110.70999908447,36.990001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.430000305176,-111.26000213623,36.939998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.840000152588,-111.48999786377,36.930000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.209999084473,-111.70999908447,36.919998168945),
								},
							},
						},
				RenderMLCenter	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.11,
						},
				SpecSpin	=	{
						},
				RenderMLCenter	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				Beta_Inner3D	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(19.780000686646,-112.87000274658,38.900001525879),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(25.680000305176,-110.7799987793,38.779998779297),
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(24.479999542236,-111.86000061035,36.979999542236),
				RenderInner	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(23.059999465942,-112.29000091553,37.259998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(22.420000076294,-112.4700012207,37.400001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(21.89999961853,-112.61000061035,37.520000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(21.540000915527,-112.69000244141,37.630001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(21.290000915527,-112.75,37.720001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(21.049999237061,-112.79000091553,37.810001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(20.729999542236,-112.84999847412,37.970001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(20.420000076294,-112.90000152588,38.139999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(20.180000305176,-112.91999816895,38.319999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(20.049999237061,-112.91999816895,38.439998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(19.940000534058,-112.91000366211,38.599998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(19.85000038147,-112.88999938965,38.75),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(19.780000686646,-112.87000274658,38.900001525879),
								},
							},
						},
				RenderMLCenter	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.09,
						},
				SpecSpin	=	{
						},
				RenderMLCenter	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				Beta_Inner3D	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(26.610000610352,-109.69999694824,39.939998626709),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(20.129999160767,-112.2799987793,40.049999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(20.030000686646,-112.30000305176,40.099998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(19.940000534058,-112.30999755859,40.25),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(19.940000534058,-112.23999786377,40.369998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(20.090000152588,-112.12000274658,40.509998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(20.299999237061,-111.93000030518,40.669998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(20.629999160767,-111.66000366211,40.909999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(21.030000686646,-111.37000274658,41.189998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(21.379999160767,-111.12000274658,41.409999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(21.780000686646,-110.86000061035,41.599998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(21.979999542236,-110.7200012207,41.680000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(22.180000305176,-110.61000061035,41.720001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(22.389999389648,-110.51000213623,41.759998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(22.629999160767,-110.38999938965,41.799999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(22.920000076294,-110.25,41.830001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(23.209999084473,-110.12000274658,41.849998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(23.829999923706,-109.83999633789,41.869998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.159999847412,-109.23999786377,41.860000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.739999771118,-107.98999786377,41.799999237061),
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.16,
						},
				SpecSpin	=	{
						},
				DD_Blnk_Run	=	true,
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-37.319999694824,84.209999084473,34.939998626709),
				RenderInner	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	15,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-36.979999542236,85.410003662109,34.720001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.549999237061,86.529998779297,34.470001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.150001525879,87.419998168945,34.259998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.659999847412,88.319999694824,34.029998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.069999694824,89.309997558594,33.740001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.419998168945,90.25,33.439998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.990001678467,90.830001831055,33.25),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.490001678467,91.400001525879,33.060001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.009998321533,91.870002746582,32.880001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.540000915527,92.349998474121,32.669998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.040000915527,92.809997558594,32.479999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.540000915527,93.26000213623,32.290000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.840000152588,93.860000610352,31.989999771118),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.10000038147,94.470001220703,31.700000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.319999694824,95.080001831055,31.35000038147),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.489999771118,95.639999389648,31),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.950000762939,96,30.719999313354),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.459999084473,96.360000610352,30.389999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.889999389648,96.699996948242,29.969999313354),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.360000610352,97.029998779297,29.479999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.670000076294,97.389999389648,28.790000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.979999542236,97.76000213623,28.030000686646),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.340000152588,98.120002746582,27.219999313354),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-23.739999771118,98.440002441406,26.39999961853),
								},
							},
						},
				RenderMLCenter	=	true,
				RunningColor	=	{
						195,
						195,
						255,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Pos4	=	Vector(-26.090000152588,94.440002441406,30.979999542236),
					Pos2	=	Vector(-27.819999694824,93.050003051758,32.470001220703),
					Use	=	true,
					Pos1	=	Vector(-25.840000152588,94.540000915527,31.920000076294),
					Pos3	=	Vector(-27.5,94.650001525879,31.520000457764),
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						255,
						200,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-26.790000915527,94.540000915527,31.64999961853),
				RenderInner_Size	=	1.6,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Pos4	=	Vector(-28.180000305176,92.930000305176,31.799999237061),
					Pos2	=	Vector(-29.909999847412,91.540000915527,33.290000915527),
					Use	=	true,
					Pos1	=	Vector(-27.930000305176,93.029998779297,32.740001678467),
					Pos3	=	Vector(-29.590000152588,93.139999389648,32.340000152588),
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						255,
						200,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-28.879999160767,93.029998779297,32.470001220703),
				RenderInner	=	true,
				RenderInner_Size	=	1.5,
				UseSprite	=	true,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Pos4	=	Vector(-29.979999542236,91.440002441406,32.5),
					Pos2	=	Vector(-31.709999084473,90.050003051758,33.990001678467),
					Use	=	true,
					Pos1	=	Vector(-29.729999542236,91.540000915527,33.439998626709),
					Pos3	=	Vector(-31.389999389648,91.650001525879,33.040000915527),
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						255,
						200,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-30.680000305176,91.540000915527,33.169998168945),
				RenderInner_Size	=	1.4,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Pos4	=	Vector(26.690000534058,94.400001525879,30.950000762939),
					Pos2	=	Vector(28.420000076294,93.01000213623,32.439998626709),
					Use	=	true,
					Pos1	=	Vector(26.440000534058,94.5,31.889999389648),
					Pos3	=	Vector(28.10000038147,94.610000610352,31.489999771118),
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						255,
						200,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(27.389999389648,94.5,31.620000839233),
				RenderInner	=	true,
				RenderInner_Size	=	1.6,
				UseSprite	=	true,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Pos4	=	Vector(-31.680000305176,89.440002441406,33.150001525879),
					Pos2	=	Vector(-33.409999847412,88.050003051758,34.639999389648),
					Use	=	true,
					Pos1	=	Vector(-31.430000305176,89.540000915527,34.090000152588),
					Pos3	=	Vector(-33.090000152588,89.650001525879,33.689998626709),
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						255,
						200,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-32.380001068115,89.540000915527,33.819999694824),
				RenderInner_Size	=	1.2,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Pos4	=	Vector(-33.180000305176,87.440002441406,33.650001525879),
					Pos2	=	Vector(-34.909999847412,86.050003051758,35.139999389648),
					Use	=	true,
					Pos1	=	Vector(-32.930000305176,87.540000915527,34.590000152588),
					Pos3	=	Vector(-34.590000152588,87.650001525879,34.189998626709),
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						255,
						200,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-33.880001068115,87.540000915527,34.319999694824),
				RenderInner	=	true,
				RenderInner_Size	=	1.2,
				Beta_Inner3D	=	true,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Pos4	=	Vector(-34.5,85.98999786377,34.150001525879),
					Pos2	=	Vector(-36.229999542236,84.599998474121,35.639999389648),
					Use	=	true,
					Pos1	=	Vector(-34.25,86.089996337891,35.090000152588),
					Pos3	=	Vector(-35.909999847412,86.199996948242,34.689998626709),
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						255,
						200,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-35.200000762939,86.089996337891,34.819999694824),
				RenderInner	=	true,
				RenderInner_Size	=	1,
				Beta_Inner3D	=	true,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.65,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
						195,
						195,
						255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
						255,
						200,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-32.330001831055,89.779998779297,28.120000839233),
					Pos2	=	Vector(-36.110000610352,89.779998779297,31.89999961853),
					Color	=	{
							0,
							0,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(-32.330001831055,89.779998779297,31.89999961853),
					Pos3	=	Vector(-36.110000610352,89.779998779297,28.120000839233),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-34.220001220703,89.779998779297,30.010000228882),
				RenderInner	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1.4,
				HBeamColor	=	{
						195,
						195,
						255,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				LBeamColor	=	{
						195,
						195,
						255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
						255,
						200,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-27.610000610352,93.809997558594,26.829999923706),
					Pos2	=	Vector(-30.709999084473,93.809997558594,29.930000305176),
					Use	=	true,
					Pos1	=	Vector(-27.610000610352,93.809997558594,29.930000305176),
					Pos3	=	Vector(-30.709999084473,93.809997558594,26.829999923706),
						},
				HBeamColor	=	{
						195,
						195,
						255,
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-29.159999847412,93.809997558594,28.379999160767),
				RenderInner_Size	=	1.4,
				SpecMat	=	{
						},
				RenderInner	=	true,
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderHD_Size	=	0.5,
				BrakeColor	=	{
						255,
						0,
						0,
						},
				RenderInner_Clr	=	{
						255,
						133,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-28.709999084473,-107.73000335693,40.959999084473),
				UseBrake	=	true,
				RenderInner_Size	=	1.3,
				SpecMLine	=	{
					Amount	=	73,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-30.819999694824,-106.23999786377,40.939998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.919998168945,-104.15000152588,40.919998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.669998168945,-101.95999908447,40.889999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.909999847412,-99.620002746582,40.860000610352),
								},
							},
						},
				RenderInner	=	true,
				UseSprite	=	true,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.11,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderHD_Size	=	0.5,
				RenderInner_Clr	=	{
						255,
						44,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-26.719999313354,-111,37.959999084473),
				RenderHD_Adv	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-28.909999847412,-109.76999664307,38.009998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.860000610352,-107.76000213623,38.139999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.060001373291,-106.7799987793,38.240001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.150001525879,-105.55999755859,38.330001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.200000762939,-104.23000335693,38.419998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.020000457764,-102.93000030518,38.490001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.659999847412,-101.7200012207,38.549999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.279998779297,-100.41000366211,38.560001373291),
								},
							},
						},
				UseBlinkers	=	true,
				RenderInner_Size	=	1.9,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.02,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				SpecRec	=	{
					Use	=	true,
					AmountV	=	8,
					Pos1	=	Vector(-22.670000076294,-112.08000183105,38.279998779297),
					Pos2	=	Vector(-25.540000915527,-111.05000305176,38.430000305176),
					AmountH	=	7,
					Pos4	=	Vector(-21.010000228882,-112.58000183105,38.580001831055),
					Mid_Full	=	true,
					Pos3	=	Vector(-24.829999923706,-111.55999755859,37.669998168945),
						},
				UseDynamic	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				RenderInner_Clr	=	{
						255,
						44,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-23.159999847412,-112.09999847412,38.130001068115),
				RenderHD_Size	=	0.5,
				RenderInner	=	true,
				UseSprite	=	true,
				RenderMLCenter	=	true,
				RenderInner_Size	=	3,
				RenderHD_Adv	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.04,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(14.420000076294,-88.910003662109,50.849998474121),
					UseColor	=	true,
					Pos2	=	Vector(-14.579999923706,-88.879997253418,52.349998474121),
					Color	=	{
							255,
							155,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(14.420000076294,-88.910003662109,52.349998474121),
					Pos3	=	Vector(-14.579999923706,-88.879997253418,50.849998474121),
						},
				UseBrake	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				SpecRec	=	{
					Pos4	=	Vector(11.920000076294,-88.910003662109,51.360000610352),
					AmountH	=	35,
					Pos1	=	Vector(11.920000076294,-88.910003662109,51.840000152588),
					InnerCenterOnly	=	true,
					AmountV	=	11,
					Pos2	=	Vector(-12.079999923706,-88.879997253418,51.840000152588),
					Use	=	true,
					Mid_Full	=	true,
					Pos3	=	Vector(-12.079999923706,-88.879997253418,51.360000610352),
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-0.079999998211861,-88.879997253418,51.849998474121),
				UseDynamic	=	true,
				UseSprite	=	true,
				RenderHD_Size	=	0.5,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.02,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				SpecRec	=	{
					Use	=	true,
					AmountV	=	8,
					Pos1	=	Vector(22.25,-112.2200012207,38.119998931885),
					Pos2	=	Vector(25.120000839233,-111.19000244141,38.270000457764),
					AmountH	=	7,
					Pos4	=	Vector(20.590000152588,-112.7200012207,38.419998168945),
					Mid_Full	=	true,
					Pos3	=	Vector(24.409999847412,-111.69999694824,37.509998321533),
						},
				UseDynamic	=	true,
				RenderHD_Size	=	0.5,
				RenderInner_Clr	=	{
						255,
						44,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(22.739999771118,-112.23999786377,37.970001220703),
				ReverseColor	=	{
						200,
						225,
						255,
						},
				RenderInner	=	true,
				RenderHD_Adv	=	true,
				RenderMLCenter	=	true,
				RenderInner_Size	=	3,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.11,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderHD_Size	=	0.5,
				RenderInner_Clr	=	{
						255,
						44,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(26.409999847412,-111.06999969482,37.819999694824),
				RenderHD_Adv	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(28.60000038147,-109.83999633789,37.869998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.549999237061,-107.83000183105,38),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.75,-106.84999847412,38.099998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.840000152588,-105.62999725342,38.189998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.889999389648,-104.30000305176,38.279998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.709999084473,-103,38.349998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.349998474121,-101.79000091553,38.409999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.970001220703,-100.48000335693,38.419998168945),
								},
							},
						},
				RenderMLCenter	=	true,
				RenderInner_Size	=	1.9,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderHD_Size	=	0.5,
				BrakeColor	=	{
						255,
						0,
						0,
						},
				RenderInner_Clr	=	{
						255,
						133,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(28.420000076294,-107.83000183105,40.790000915527),
				RenderMLCenter	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	73,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(30.530000686646,-106.33999633789,40.770000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.630001068115,-104.25,40.75),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.380001068115,-102.05999755859,40.720001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.619998931885,-99.720001220703,40.689998626709),
								},
							},
						},
				RenderInner_Size	=	1.3,
				Beta_Inner3D	=	true,
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				LBeamColor	=	{
						195,
						195,
						255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
						255,
						200,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(28.10000038147,93.720001220703,26.64999961853),
					Pos2	=	Vector(31.200000762939,93.720001220703,29.75),
					Use	=	true,
					Pos1	=	Vector(28.10000038147,93.720001220703,29.75),
					Pos3	=	Vector(31.200000762939,93.720001220703,26.64999961853),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(29.64999961853,93.720001220703,28.200000762939),
				RenderInner_Size	=	1.4,
				HBeamColor	=	{
						195,
						195,
						255,
						},
				RenderInner	=	true,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.65,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
						195,
						195,
						255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
						255,
						200,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(32.840000152588,89.610000610352,27.969999313354),
					Pos2	=	Vector(36.619998931885,89.610000610352,31.75),
					Use	=	true,
					Pos1	=	Vector(32.840000152588,89.610000610352,31.75),
					Pos3	=	Vector(36.619998931885,89.610000610352,27.969999313354),
						},
				HBeamColor	=	{
						195,
						195,
						255,
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(34.729999542236,89.610000610352,29.860000610352),
				RenderInner	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseSprite	=	true,
				RenderInner_Size	=	1.4,
				SpecMat	=	{
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.03,
						},
				SpecSpin	=	{
						},
				Beta_Inner3D	=	true,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner_Size	=	2,
				UseSprite	=	true,
				Pos	=	Vector(-47.459999084473,14.130000114441,48.360000610352),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	72,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-47.110000610352,15.659999847412,48.209999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-46.709999084473,16.780000686646,48.119998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-46.349998474121,17.540000915527,48.049999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-46.020000457764,18.120000839233,48),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-45.590000152588,18.719999313354,47.950000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-45.180000305176,19.209999084473,47.909999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-44.680000305176,19.739999771118,47.860000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-44.110000610352,20.299999237061,47.790000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-43.029998779297,21.14999961853,47.680000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-41,22.389999389648,47.459999084473),
								},
							},
						},
				RenderMLCenter	=	true,
				RenderInner_Clr	=	{
						255,
						200,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.03,
						},
				SpecSpin	=	{
						},
				UseSprite	=	true,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(47.729999542236,13.880000114441,48.139999389648),
				UseDynamic	=	true,
				RenderInner_Size	=	2,
				SpecMLine	=	{
					Amount	=	72,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(47.380001068115,15.409999847412,47.990001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(46.979999542236,16.530000686646,47.900001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(46.619998931885,17.290000915527,47.830001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(46.290000915527,17.870000839233,47.779998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(45.860000610352,18.469999313354,47.729999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(45.450000762939,18.959999084473,47.689998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(44.950000762939,19.489999771118,47.639999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(44.380001068115,20.049999237061,47.569999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(43.299999237061,20.89999961853,47.459999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(41.270000457764,22.139999389648,47.240001678467),
								},
							},
						},
				UseBlinkers	=	true,
				RenderInner_Clr	=	{
						255,
						200,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Pos4	=	Vector(28.780000686646,92.889999389648,31.760000228882),
					Pos2	=	Vector(30.510000228882,91.5,33.25),
					Use	=	true,
					Pos1	=	Vector(28.530000686646,92.98999786377,32.700000762939),
					Pos3	=	Vector(30.190000534058,93.099998474121,32.299999237061),
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						255,
						200,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(29.479999542236,92.98999786377,32.430000305176),
				RenderInner	=	true,
				RenderInner_Size	=	1.5,
				Beta_Inner3D	=	true,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Pos4	=	Vector(30.60000038147,91.160003662109,32.380001068115),
					Pos2	=	Vector(32.330001831055,89.769996643066,33.869998931885),
					Use	=	true,
					Pos1	=	Vector(30.35000038147,91.26000213623,33.319999694824),
					Pos3	=	Vector(32.009998321533,91.370002746582,32.919998168945),
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						255,
						200,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(31.299999237061,91.26000213623,33.049999237061),
				RenderInner	=	true,
				RenderInner_Size	=	1.4,
				UseSprite	=	true,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Pos4	=	Vector(32.200000762939,89.669998168945,32.970001220703),
					Pos2	=	Vector(33.930000305176,88.279998779297,34.459999084473),
					Use	=	true,
					Pos1	=	Vector(31.950000762939,89.769996643066,33.909999847412),
					Pos3	=	Vector(33.610000610352,89.879997253418,33.509998321533),
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						255,
						200,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(32.900001525879,89.769996643066,33.639999389648),
				RenderInner	=	true,
				RenderInner_Size	=	1.2,
				Beta_Inner3D	=	true,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Pos4	=	Vector(33.680000305176,87.669998168945,33.509998321533),
					Pos2	=	Vector(35.409999847412,86.279998779297,35),
					Use	=	true,
					Pos1	=	Vector(33.430000305176,87.769996643066,34.450000762939),
					Pos3	=	Vector(35.090000152588,87.879997253418,34.049999237061),
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						255,
						200,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(34.380001068115,87.769996643066,34.180000305176),
				RenderInner	=	true,
				RenderInner_Size	=	1.2,
				UseSprite	=	true,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Pos4	=	Vector(35.009998321533,85.639999389648,33.959999084473),
					Pos2	=	Vector(36.740001678467,84.25,35.450000762939),
					Use	=	true,
					Pos1	=	Vector(34.759998321533,85.73999786377,34.900001525879),
					Pos3	=	Vector(36.419998168945,85.849998474121,34.5),
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						255,
						200,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(35.709999084473,85.73999786377,34.630001068115),
				RenderInner_Size	=	1,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.16,
						},
				SpecSpin	=	{
						},
				DD_Blnk_Run	=	true,
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(37.919998168945,84.099998474121,34.810001373291),
				RenderInner_Size	=	1,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	15,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(37.580001831055,85.300003051758,34.590000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.150001525879,86.419998168945,34.340000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.75,87.309997558594,34.130001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.259998321533,88.209999084473,33.900001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.669998168945,89.199996948242,33.610000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.020000457764,90.139999389648,33.310001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.590000152588,90.720001220703,33.119998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.090000152588,91.290000915527,32.930000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.610000610352,91.76000213623,32.75),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.139999389648,92.23999786377,32.540000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.639999389648,92.699996948242,32.349998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.139999389648,93.150001525879,32.159999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.440000534058,93.75,31.860000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.700000762939,94.360000610352,31.569999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.920000076294,94.970001220703,31.219999313354),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.090000152588,95.529998779297,30.870000839233),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.549999237061,95.889999389648,30.590000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.059999465942,96.25,30.260000228882),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.489999771118,96.589996337891,29.840000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.959999084473,96.919998168945,29.35000038147),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.270000457764,97.279998779297,28.659999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.579999923706,97.650001525879,27.89999961853),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.940000534058,98.01000213623,27.090000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.340000152588,98.330001831055,26.270000457764),
								},
							},
						},
				RenderMLCenter	=	true,
				RunningColor	=	{
						195,
						195,
						255,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.01,
						},
				SpecSpin	=	{
						},
				RenderInner	=	true,
				RunningColor	=	{
						195,
						195,
						255,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(7.8000001907349,74.800003051758,38.810001373291),
				UseSprite	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	2,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(7.7300000190735,75.01000213623,38.779998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(7.6399998664856,74.809997558594,38.819999694824),
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
						200,
						225,
						255,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.01,
						},
				SpecSpin	=	{
						},
				RenderInner	=	true,
				RunningColor	=	{
						195,
						195,
						255,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(7.3400001525879,74.819999694824,38.799999237061),
				UseSprite	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	2,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(7.5500001907349,74.849998474121,38.799999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(7.5300002098083,75.01000213623,38.779998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(7.3600001335144,74.98999786377,38.779998779297),
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
						200,
						225,
						255,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.16,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(37.919998168945,84.099998474121,34.810001373291),
				RenderInner_Size	=	1,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(37.580001831055,85.300003051758,34.590000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.150001525879,86.419998168945,34.340000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.75,87.309997558594,34.130001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.259998321533,88.209999084473,33.900001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.669998168945,89.199996948242,33.610000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.020000457764,90.139999389648,33.310001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.590000152588,90.720001220703,33.119998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.090000152588,91.290000915527,32.930000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.610000610352,91.76000213623,32.75),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.139999389648,92.23999786377,32.540000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.639999389648,92.699996948242,32.349998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.139999389648,93.150001525879,32.159999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.440000534058,93.75,31.860000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.700000762939,94.360000610352,31.569999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.920000076294,94.970001220703,31.219999313354),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.090000152588,95.529998779297,30.870000839233),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.549999237061,95.889999389648,30.590000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.059999465942,96.25,30.260000228882),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.489999771118,96.589996337891,29.840000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.959999084473,96.919998168945,29.35000038147),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.270000457764,97.279998779297,28.659999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.579999923706,97.650001525879,27.89999961853),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.940000534058,98.01000213623,27.090000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.340000152588,98.330001831055,26.270000457764),
								},
							},
						},
				RenderMLCenter	=	true,
				RunningColor	=	{
						195,
						195,
						255,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.16,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-37.319999694824,84.209999084473,34.939998626709),
				RenderInner	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-36.979999542236,85.410003662109,34.720001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.549999237061,86.529998779297,34.470001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.150001525879,87.419998168945,34.259998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.659999847412,88.319999694824,34.029998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.069999694824,89.309997558594,33.740001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.419998168945,90.25,33.439998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.990001678467,90.830001831055,33.25),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.490001678467,91.400001525879,33.060001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.009998321533,91.870002746582,32.880001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.540000915527,92.349998474121,32.669998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.040000915527,92.809997558594,32.479999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.540000915527,93.26000213623,32.290000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.840000152588,93.860000610352,31.989999771118),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.10000038147,94.470001220703,31.700000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.319999694824,95.080001831055,31.35000038147),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.489999771118,95.639999389648,31),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.950000762939,96,30.719999313354),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.459999084473,96.360000610352,30.389999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.889999389648,96.699996948242,29.969999313354),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.360000610352,97.029998779297,29.479999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.670000076294,97.389999389648,28.790000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.979999542236,97.76000213623,28.030000686646),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.340000152588,98.120002746582,27.219999313354),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-23.739999771118,98.440002441406,26.39999961853),
								},
							},
						},
				RenderMLCenter	=	true,
				RunningColor	=	{
						195,
						195,
						255,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseBrake	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(36.119998931885,-98.519996643066,41.290000915527),
				RenderInner	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	15,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(35.790000915527,-99.360000610352,41.360000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.340000152588,-100.30000305176,41.409999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.970001220703,-100.98000335693,41.459999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.509998321533,-101.69999694824,41.5),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.020000457764,-102.44000244141,41.529998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.540000915527,-103.08000183105,41.549999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.639999389648,-104.12999725342,41.599998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.799999237061,-105,41.639999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.129999160767,-105.66000366211,41.659999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.459999084473,-106.23999786377,41.669998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.780000686646,-106.80999755859,41.689998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.10000038147,-107.31999969482,41.709999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.520000457764,-107.70999908447,41.729999542236),
								},
							},
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.01,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Pos4	=	Vector(-14.729999542236,24.430000305176,45.369998931885),
					AmountV	=	2,
					Pos2	=	Vector(-14.770000457764,24.430000305176,45.450000762939),
					AmountH	=	2,
					Use	=	true,
					Pos1	=	Vector(-14.729999542236,24.440000534058,45.450000762939),
					Pos3	=	Vector(-14.770000457764,24.430000305176,45.369998931885),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-14.75,24.190000534058,45.509998321533),
				UseBlinkers	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/indicator_single",
					Pos4	=	Vector(-14.449999809265,24.370000839233,44.959999084473),
					UseColor	=	true,
					Pos2	=	Vector(-15.050000190735,24.489999771118,45.860000610352),
					Color	=	{
							55,
							255,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(-14.449999809265,24.489999771118,45.860000610352),
					Pos3	=	Vector(-15.050000190735,24.379999160767,44.959999084473),
						},
				BlinkersColor	=	{
						55,
						255,
						0,
						},
				RenderMLCenter	=	true,
				UseSprite	=	true,
				BlinkerRight	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.01,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	55,
					b	=	0,
					a	=	255,
					g	=	255,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-18.75,24.200000762939,45.5),
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Pos4	=	Vector(-18.770000457764,24.440000534058,45.360000610352),
					Pos2	=	Vector(-18.729999542236,24.440000534058,45.439998626709),
					Use	=	true,
					Pos1	=	Vector(-18.770000457764,24.450000762939,45.439998626709),
					Pos3	=	Vector(-18.729999542236,24.440000534058,45.360000610352),
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/indicator_single",
					Pos4	=	Vector(-19.049999237061,24.379999160767,44.950000762939),
					UseColor	=	true,
					Pos2	=	Vector(-18.450000762939,24.5,45.849998474121),
					Color	=	{
						r	=	55,
						b	=	0,
						a	=	255,
						g	=	255,
							},
					Use	=	true,
					Pos1	=	Vector(-19.049999237061,24.5,45.849998474121),
					Pos3	=	Vector(-18.450000762939,24.389999389648,44.950000762939),
						},
				RenderMLCenter	=	true,
				UseBlinkers	=	true,
				UseSprite	=	true,
					},
				},
		Copyright	=	"Copyright © 2012-2017 VCMod (freemmaann). All Rights Reserved.",
		Fuel	=	{
			FuelLidPos	=	Vector(38.770000457764,-80.459999084473,42.799999237061),
			FuelType	=	0,
			Capacity	=	65,
			FuelLidUse	=	true,
			Override	=	true,
				},
		Author	=	"CгεερεгƬv (76561198051637331)",
}