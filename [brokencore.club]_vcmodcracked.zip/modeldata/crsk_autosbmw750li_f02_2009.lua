VCModels['models/crsk_autosbmw750li_f02_2009.mdl']	=	{
		Light_DD_Int	=	true,
		HealthEnginePosOvr	=	true,
		Date	=	"Sat May  5 19:56:54 2018",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(26.450000762939,-120.98999786377,14.489999771118),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-26.450000762939,-120.98999786377,14.489999771118),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		Copyright	=	"Copyright © 2012-2018 VCMod (freemmaann). All Rights Reserved.",
		HealthEnginePos	=	Vector(0,97.620002746582,35.439998626709),
		DLT	=	3491063178,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.07,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	35,
					Use	=	true,
					Radius	=	3.1,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-33.650001525879,110.37999725342,31.299999237061),
				RenderInner	=	true,
				RenderInner_Size	=	1.15,
				RunningColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.07,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	35,
					Use	=	true,
					Radius	=	3.1,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(34.270000457764,110.09999847412,31.190000534058),
				RenderInner_Size	=	1.15,
				RenderInner	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.04,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	35,
					Use	=	true,
					Radius	=	2.27,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(27.809999465942,112.69999694824,30.719999313354),
				RenderInner	=	true,
				RenderInner_Size	=	2,
				RunningColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.04,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	35,
					Use	=	true,
					Radius	=	2.27,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-27.200000762939,112.79000091553,30.840000152588),
				RenderInner	=	true,
				RenderInner_Size	=	2,
				RunningColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.07,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				LBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	13,
					Use	=	true,
					Radius	=	1,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-33.659999847412,109.95999908447,31.319999694824),
				RenderInner	=	true,
				HBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner_Size	=	1.7,
				UseHighBeams	=	true,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.07,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				LBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(34.299999237061,109.83999633789,31.110000610352),
				RenderInner	=	true,
				HBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner_Size	=	1.7,
				SpecCircle	=	{
					Amount	=	13,
					Use	=	true,
					Radius	=	1,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderHD_Size	=	3,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				HBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(34.299999237061,110.33999633789,31.110000610352),
				RenderInner	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				SpecMat	=	{
						},
				RenderInner_Size	=	1,
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderHD_Size	=	3,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				HBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-33.659999847412,110.45999908447,31.319999694824),
				RenderInner	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				SpecMat	=	{
						},
				RenderInner_Size	=	1,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				RenderInner_Size	=	2,
				Beta_Inner3D	=	true,
				HBeamColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				ReducedVis	=	true,
				SpecCircle	=	{
					Amount	=	15,
					Use	=	true,
					Radius	=	1,
						},
				UseSprite	=	true,
				Pos	=	Vector(-27.159999847412,112.29000091553,30.829999923706),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				SpecCircle	=	{
					Amount	=	15,
					Use	=	true,
					Radius	=	1,
						},
				Beta_Inner3D	=	true,
				HBeamColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner_Size	=	2,
				UseSprite	=	true,
				Pos	=	Vector(27.85000038147,112.18000030518,30.739999771118),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				RenderInner_Size	=	1,
				HBeamColor	=	{
					r	=	255,
					b	=	177,
					a	=	255,
					g	=	215,
						},
				ReducedVis	=	true,
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(27.85000038147,111.68000030518,30.739999771118),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderHD_Size	=	4,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				UseSprite	=	true,
				RenderInner_Size	=	1,
				RenderInner	=	true,
				HBeamColor	=	{
					r	=	255,
					b	=	177,
					a	=	255,
					g	=	215,
						},
				ReducedVis	=	true,
				SpecMat	=	{
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-27.159999847412,111.79000091553,30.829999923706),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderHD_Size	=	4,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				UsePrjTex	=	true,
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-33.340000152588,110.87999725342,12.14999961853),
					UseColor	=	true,
					Pos2	=	Vector(-38.200000762939,111.05999755859,17.010000228882),
					Color	=	{
						r	=	255,
						b	=	100,
						a	=	255,
						g	=	175,
							},
					Use	=	true,
					Pos1	=	Vector(-33.340000152588,111.05999755859,17.010000228882),
					Pos3	=	Vector(-38.200000762939,110.87999725342,12.14999961853),
						},
				FogColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-35.840000152588,109.7200012207,14.539999961853),
				RenderInner	=	true,
				UseFog	=	true,
				UseSprite	=	true,
				RenderInner_Size	=	1,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				UsePrjTex	=	true,
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(33.939998626709,110.69999694824,11.949999809265),
					UseColor	=	true,
					Pos2	=	Vector(38.799999237061,110.87999725342,16.809999465942),
					Color	=	{
						r	=	255,
						b	=	100,
						a	=	255,
						g	=	175,
							},
					Use	=	true,
					Pos1	=	Vector(33.939998626709,110.87999725342,16.809999465942),
					Pos3	=	Vector(38.799999237061,110.69999694824,11.949999809265),
						},
				FogColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(36.439998626709,109.54000091553,14.340000152588),
				RenderInner_Size	=	1,
				UseFog	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				RenderInner	=	true,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-37.240001678467,107.51000213623,33.439998626709),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				UseSprite	=	true,
				Pos	=	Vector(37.849998474121,107.33000183105,33.25),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				UseSprite	=	true,
				Pos	=	Vector(39.240001678467,107.33000183105,33.299999237061),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-38.590000152588,107.51000213623,33.5),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-38.740001678467,107.5,32.430000305176),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-37.479999542236,107.5,32.409999847412),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-37.400001525879,107.43000030518,30.170000076294),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-38.650001525879,107.43000030518,30.180000305176),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-38.840000152588,107.4700012207,31.309999465942),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-37.599998474121,107.4700012207,31.280000686646),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				UseSprite	=	true,
				Pos	=	Vector(39.419998168945,107.30999755859,32.220001220703),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				UseSprite	=	true,
				Pos	=	Vector(38.090000152588,107.30999755859,32.25),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				UseSprite	=	true,
				Pos	=	Vector(39.450000762939,107.30999755859,31.10000038147),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				UseSprite	=	true,
				Pos	=	Vector(38.200000762939,107.2799987793,31.110000610352),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				UseSprite	=	true,
				Pos	=	Vector(38.020000457764,107.26000213623,29.989999771118),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				UseSprite	=	true,
				Pos	=	Vector(39.270000457764,107.25,30),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderGlow_Size	=	5,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(44.770000457764,52.200000762939,25.270000457764),
				UseBlinkers	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	5,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(44.770000457764,57.479999542236,25.270000457764),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseSprite	=	true,
				RenderInner_Size	=	2,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(44.5,51.299999237061,24.760000228882),
					Pos2	=	Vector(44.580001831055,58.540000915527,25.75),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(44.580001831055,51.380001068115,25.75),
					Pos3	=	Vector(44.430000305176,57.810001373291,24.760000228882),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderGlow_Size	=	5,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-44.169998168945,51.439998626709,24.969999313354),
					Pos2	=	Vector(-44.169998168945,58.680000305176,25.959999084473),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-44.290000915527,51.520000457764,26),
					Pos3	=	Vector(-44.069999694824,57.950000762939,24.969999313354),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-44.5,52.340000152588,25.479999542236),
				UseBlinkers	=	true,
				RenderInner_Size	=	2,
				SpecMLine	=	{
					Amount	=	5,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-44.5,57.619998931885,25.479999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseSprite	=	true,
				RenderInner	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-8.289999961853,-63.889999389648,61.779998779297),
					Pos2	=	Vector(8.7200002670288,-63.889999389648,62.729999542236),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-8.7200002670288,-63.889999389648,62.729999542236),
					Pos3	=	Vector(8.289999961853,-63.889999389648,61.779998779297),
						},
				UseBrake	=	true,
				SpecMat	=	{
						},
				RenderInner_Size	=	1,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-7.5700001716614,-63.860000610352,62.220001220703),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(7.5700001716614,-63.860000610352,62.220001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-25.719999313354,-117.41000366211,40.799999237061),
					Pos2	=	Vector(-21.60000038147,-118.26000213623,41.869998931885),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-26.020000457764,-117.0299987793,41.880001068115),
					Pos3	=	Vector(-21.270000457764,-118.51000213623,40.770000457764),
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-25.10000038147,-117.69999694824,41.340000152588),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	3,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-22.010000228882,-118.2799987793,41.340000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(25.370000839233,-117.48999786377,40.669998168945),
					Pos2	=	Vector(21.25,-118.26000213623,41.759998321533),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(25.670000076294,-117.08999633789,41.759998321533),
					Pos3	=	Vector(20.920000076294,-118.58999633789,40.709999084473),
						},
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(24.75,-117.7799987793,41.279998779297),
				UseDynamic	=	true,
				RenderInner	=	true,
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				SpecMLine	=	{
					Amount	=	3,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(21.659999847412,-118.36000061035,41.279998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(19.950000762939,-118.61000061035,39.330001831055),
				RenderInner_Size	=	1.4,
				SpecMLine	=	{
					Amount	=	7,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(21.430000305176,-118.33000183105,39.330001831055),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(23.799999237061,-117.76999664307,39.330001831055),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(26,-117.06999969482,39.330001831055),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(27.860000610352,-116.37000274658,39.330001831055),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(19.489999771118,-118.86000061035,38.209999084473),
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	7,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(20.969999313354,-118.58000183105,38.209999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(23.340000152588,-118.01999664307,38.209999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(25.540000915527,-117.31999969482,38.209999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(27.489999771118,-116.62000274658,38.209999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseBrake	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Size	=	1.4,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(19.110000610352,-119.01000213623,37.090000152588),
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	7,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(20.590000152588,-118.73000335693,37.090000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(22.959999084473,-118.16999816895,37.090000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(25.159999847412,-117.4700012207,37.090000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(27.139999389648,-116.76000213623,37.090000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseBrake	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Size	=	1.4,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-20.290000915527,-118.56999969482,39.419998168945),
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	7,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-21.770000457764,-118.29000091553,39.419998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-24.139999389648,-117.73000335693,39.419998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-26.340000152588,-117.0299987793,39.419998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-28.200000762939,-116.33000183105,39.419998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseBrake	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Size	=	1.4,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-19.840000152588,-118.73999786377,38.299999237061),
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	7,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-21.319999694824,-118.45999908447,38.299999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-23.690000534058,-117.90000152588,38.299999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-25.889999389648,-117.19999694824,38.299999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-27.840000152588,-116.5,38.299999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseBrake	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Size	=	1.4,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-19.469999313354,-118.91999816895,37.169998168945),
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	7,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-20.950000762939,-118.63999938965,37.169998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-23.319999694824,-118.08000183105,37.169998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-25.520000457764,-117.37999725342,37.169998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-27.5,-116.66999816895,37.169998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseBrake	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Size	=	1.4,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				RenderInner_Size	=	1.4,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(28.940000534058,-115.83000183105,39.470001220703),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	7,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(30.420000076294,-115.23999786377,39.470001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(32.450000762939,-114.30999755859,39.470001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(34.310001373291,-113.16999816895,39.470001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(35.369998931885,-112.15000152588,39.470001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				RenderInner	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(28.579999923706,-116.15000152588,38.319999694824),
				UseDynamic	=	true,
				RenderInner_Size	=	1.4,
				SpecMLine	=	{
					Amount	=	7,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(30.059999465942,-115.61000061035,38.319999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(32.090000152588,-114.76000213623,38.319999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(32.810001373291,-114.41999816895,38.319999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(33.310001373291,-114.15000152588,38.319999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(34.060001373291,-113.68000030518,38.319999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(34.840000152588,-113.18000030518,38.360000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(35.5,-112.51999664307,38.400001525879),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(35.990001678467,-112.01999664307,38.549999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(36.25,-111.48999786377,38.720001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(36.689998626709,-110.33999633789,39.409999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(36.979999542236,-109.30999755859,40.520000457764),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(37.080001831055,-108.93000030518,40.970001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(37.080001831055,-108.65000152588,41.349998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(37.069999694824,-108.30000305176,41.799999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				RenderInner_Size	=	1.4,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(28.260000228882,-116.36000061035,37.290000915527),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	7,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(29.739999771118,-115.81999969482,37.290000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(31.770000457764,-114.9700012207,37.290000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(32.490001678467,-114.62999725342,37.290000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(32.990001678467,-114.36000061035,37.290000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(33.740001678467,-113.88999938965,37.290000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(35.009998321533,-113.08999633789,37.330001831055),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(35.490001678467,-112.73000335693,37.369998931885),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(35.889999389648,-112.31999969482,37.439998626709),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(36.299999237061,-111.79000091553,37.540000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(36.619998931885,-111.11000061035,37.720001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(37.409999847412,-109.51999664307,38.869998931885),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(37.619998931885,-108.55000305176,39.700000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(37.799999237061,-106.7200012207,41.689998626709),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				RenderInner	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-28.940000534058,-115.83000183105,39.470001220703),
				UseDynamic	=	true,
				RenderInner_Size	=	1.4,
				SpecMLine	=	{
					Amount	=	7,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-30.420000076294,-115.23999786377,39.470001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-32.450000762939,-114.30999755859,39.470001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-34.310001373291,-113.16999816895,39.470001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-35.369998931885,-112.15000152588,39.470001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				RenderInner_Size	=	1.4,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-28.579999923706,-116.15000152588,38.319999694824),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	7,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-30.059999465942,-115.61000061035,38.319999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-32.090000152588,-114.76000213623,38.319999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-32.810001373291,-114.41999816895,38.319999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-33.310001373291,-114.15000152588,38.319999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-34.060001373291,-113.68000030518,38.319999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-34.840000152588,-113.18000030518,38.360000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-35.5,-112.51999664307,38.400001525879),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-35.990001678467,-112.01999664307,38.549999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-36.25,-111.48999786377,38.720001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-36.689998626709,-110.33999633789,39.409999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-36.979999542236,-109.30999755859,40.520000457764),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-37.080001831055,-108.93000030518,40.970001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-37.080001831055,-108.65000152588,41.349998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-37.069999694824,-108.30000305176,41.799999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				RenderInner	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-28.260000228882,-116.36000061035,37.290000915527),
				UseDynamic	=	true,
				RenderInner_Size	=	1.4,
				SpecMLine	=	{
					Amount	=	7,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-29.739999771118,-115.81999969482,37.290000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-31.770000457764,-114.9700012207,37.290000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-32.490001678467,-114.62999725342,37.290000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-32.990001678467,-114.36000061035,37.290000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-33.740001678467,-113.88999938965,37.290000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-35.009998321533,-113.08999633789,37.330001831055),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-35.490001678467,-112.73000335693,37.369998931885),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-35.889999389648,-112.31999969482,37.439998626709),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-36.299999237061,-111.79000091553,37.540000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-36.619998931885,-111.11000061035,37.720001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-37.409999847412,-109.51999664307,38.869998931885),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-37.619998931885,-108.55000305176,39.700000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-37.799999237061,-106.7200012207,41.689998626709),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-35.830001831055,-109.01999664307,43.159999847412),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-35.319999694824,-110.19999694824,43.159999847412),
				UseDynamic	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-34.630001068115,-111.33000183105,43.139999389648),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-33.840000152588,-112.2200012207,43.130001068115),
				UseDynamic	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-32.880001068115,-112.98000335693,43.130001068115),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-31.909999847412,-113.62999725342,43.110000610352),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-30.870000839233,-114.05000305176,43.110000610352),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-35.400001525879,-110.83999633789,42.119998931885),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-34.779998779297,-111.84999847412,42.119998931885),
				UseDynamic	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-30.639999389648,-114.62000274658,42.119998931885),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-34.200000762939,-112.66999816895,41.200000762939),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-33.389999389648,-113.33000183105,41.200000762939),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-32.540000915527,-113.83999633789,41.200000762939),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-31.719999313354,-114.26999664307,41.200000762939),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-30.840000152588,-114.63999938965,41.200000762939),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				UseSprite	=	true,
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-29.989999771118,-115.05000305176,41.200000762939),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(30.64999961853,-114.23000335693,42.939998626709),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(31.569999694824,-113.69999694824,42.939998626709),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(32.569999694824,-113.08999633789,42.939998626709),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(33.5,-112.30000305176,42.939998626709),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(34.360000610352,-111.41999816895,42.939998626709),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(34.970001220703,-110.33000183105,42.939998626709),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(35.599998474121,-109.19999694824,42.939998626709),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(30.25,-114.76000213623,41.950000762939),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(34.419998168945,-111.91000366211,41.950000762939),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(35.099998474121,-110.91999816895,41.950000762939),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(29.590000152588,-115.18000030518,41.080001831055),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(30.459999084473,-114.80999755859,41.080001831055),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(31.270000457764,-114.38999938965,41.080001831055),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(32.180000305176,-114.01000213623,41.080001831055),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(32.979999542236,-113.43000030518,41.080001831055),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(33.869998931885,-112.80000305176,41.080001831055),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	250,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
					},
				},
		em_state	=	5236594767,
		Fuel	=	{
			FuelLidPos	=	Vector(41.090000152588,-75.23999786377,44.599998474121),
			FuelLidUse	=	true,
			FuelType	=	0,
			Capacity	=	82,
			Override	=	true,
			FuelTypeUse	=	true,
				},
		Author	=	"TetraFox (76561198174178969)",
}