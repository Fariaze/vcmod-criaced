VCModels['models/crsk_autosgtasatampa.mdl']	=	{
		em_state	=	5236594896,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		HealthEnginePosOvr	=	true,
		Date	=	"Sun May 14 00:08:26 2017",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(19.309999465942,-105.59999847412,10.569999694824),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		Copyright	=	"Copyright © 2012-2017 VCMod (freemmaann). All Rights Reserved.",
		HealthEnginePos	=	Vector(-2,78,25.5),
		DLT	=	3491063264,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
						255,
						233,
						111,
						},
				RenderHD_Adv	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(40.540000915527,111.18000030518,29.930000305176),
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	5,
					Use	=	true,
					Radius	=	1.84,
						},
				RenderInner_Size	=	4,
				UseRunning	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				Dynamic	=	{
					Brightness	=	1.57,
					Size	=	0.06,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				UseSprite	=	true,
				RunningColor	=	{
						255,
						233,
						111,
						},
				Beta_Inner3D	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner	=	true,
				RenderHD_Adv	=	true,
				Pos	=	Vector(-40.040000915527,111.68000030518,29.930000305176),
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	5,
					Use	=	true,
					Radius	=	1.84,
						},
				RenderInner_Size	=	4,
				UseRunning	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				Dynamic	=	{
					Brightness	=	1.57,
					Size	=	0.06,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				Beta_Inner3D	=	true,
				RenderInner_Size	=	4,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				RenderHD_Adv	=	true,
				LBeamColor	=	{
						255,
						233,
						111,
						},
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	5,
					Use	=	true,
					Radius	=	1.84,
						},
				RenderInner	=	true,
				Pos	=	Vector(40.540000915527,111.18000030518,29.930000305176),
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				Dynamic	=	{
					Brightness	=	1.57,
					Size	=	0.06,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.7,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				Beta_Inner3D	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
						255,
						233,
						111,
						},
				UseDynamic	=	true,
				RenderInner_Size	=	4,
				Pos	=	Vector(40.540000915527,111.68000030518,29.930000305176),
				UseSprite	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				Dynamic	=	{
					Brightness	=	1.57,
					Size	=	0.06,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.7,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseSprite	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
						255,
						233,
						111,
						},
				UseDynamic	=	true,
				RenderInner_Size	=	4,
				Pos	=	Vector(-40.040000915527,112.18000030518,29.930000305176),
				Beta_Inner3D	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				Dynamic	=	{
					Brightness	=	1.57,
					Size	=	0.06,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				RenderHD_Adv	=	true,
				RenderInner	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				LBeamColor	=	{
						255,
						233,
						111,
						},
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	5,
					Use	=	true,
					Radius	=	1.84,
						},
				RenderInner_Size	=	4,
				Pos	=	Vector(-40.040000915527,111.68000030518,29.930000305176),
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				Dynamic	=	{
					Brightness	=	1.57,
					Size	=	0.06,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				SpecCircle	=	{
					Amount	=	5,
					Use	=	true,
					Radius	=	1.84,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				HBeamColor	=	{
						255,
						233,
						111,
						},
				ReducedVis	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(33.040000915527,111.68000030518,29.930000305176),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Size	=	4,
				RenderHD_Adv	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				Dynamic	=	{
					Brightness	=	1.57,
					Size	=	0.06,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				UseHighBeams	=	true,
				Beta_Inner3D	=	true,
				RenderHD_Adv	=	true,
				HBeamColor	=	{
						255,
						233,
						111,
						},
				ReducedVis	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-32.540000915527,111.68000030518,29.930000305176),
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	5,
					Use	=	true,
					Radius	=	1.84,
						},
				RenderInner_Size	=	4,
				SpecMat	=	{
						},
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				Dynamic	=	{
					Brightness	=	1.57,
					Size	=	0.06,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.9,
						},
				SpecSpin	=	{
						},
				UsePrjTex	=	true,
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				Dynamic	=	{
					Brightness	=	1.57,
					Size	=	0.06,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(33.029998779297,111.69999694824,29.860000610352),
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				RenderInner_Size	=	4,
				RenderHD_Adv	=	true,
				UseSprite	=	true,
				RenderInner	=	true,
				HBeamColor	=	{
						255,
						233,
						111,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.9,
						},
				SpecSpin	=	{
						},
				UsePrjTex	=	true,
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				Dynamic	=	{
					Brightness	=	1.57,
					Size	=	0.06,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-32.529998779297,111.69999694824,29.860000610352),
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				RenderInner_Size	=	4,
				RenderHD_Adv	=	true,
				UseSprite	=	true,
				RenderInner	=	true,
				HBeamColor	=	{
						255,
						233,
						111,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.7,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						255,
						0,
						0,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Brightness	=	1.57,
					Size	=	0.06,
						},
				BlinkersColor	=	{
						255,
						55,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				RenderHD_Adv	=	true,
				Pos	=	Vector(39.790000915527,-115.69999694824,31.920000076294),
				UseSprite	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.7,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						255,
						0,
						0,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Brightness	=	1.57,
					Size	=	0.06,
						},
				BlinkersColor	=	{
						255,
						55,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-40.209999084473,-115.38999938965,32.090000152588),
				RenderHD_Adv	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				RenderInner_Size	=	1,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.7,
						},
				SpecSpin	=	{
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
						255,
						0,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				RenderHD_Adv	=	true,
				Pos	=	Vector(30.290000915527,-115.69999694824,31.920000076294),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Brightness	=	1.57,
					Size	=	0.06,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.7,
						},
				SpecSpin	=	{
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
						255,
						0,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-30.809999465942,-115.4700012207,32.159999847412),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderInner_Size	=	1,
				RenderHD_Adv	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Brightness	=	1.57,
					Size	=	0.06,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				SpecRec	=	{
					Pos4	=	Vector(-20.760000228882,-111.15000152588,15.550000190735),
					AmountH	=	5,
					Pos1	=	Vector(-21.069999694824,-112.15000152588,20.450000762939),
					InnerCenterOnly	=	true,
					AmountV	=	5,
					Pos2	=	Vector(-1.9800000190735,-112.73999786377,20.450000762939),
					Use	=	true,
					Mid_Full	=	true,
					Pos3	=	Vector(-1.9800000190735,-110.62000274658,15.449999809265),
						},
				UseSprite	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner_Size	=	1,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-20.389999389648,-112.12000274658,19.680000305176),
				UseDynamic	=	true,
				RenderInner	=	true,
				ReverseColor	=	{
						255,
						255,
						255,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-23.059999465942,-110.94000244141,15.010000228882),
					Pos2	=	Vector(-0.20000000298023,-112.94999694824,21.040000915527),
					Use	=	true,
					Pos1	=	Vector(-23.069999694824,-113.30000305176,21.049999237061),
					Pos3	=	Vector(-0.059999998658895,-110.41000366211,14.939999580383),
						},
				RenderInner_Clr	=	{
						255,
						0,
						0,
						},
				Dynamic	=	{
					Brightness	=	1.57,
					Size	=	0.06,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				SpecRec	=	{
					Pos4	=	Vector(20.030000686646,-111.16000366211,15.430000305176),
					AmountH	=	5,
					Pos1	=	Vector(20.340000152588,-112.16000366211,20.329999923706),
					InnerCenterOnly	=	true,
					AmountV	=	5,
					Pos2	=	Vector(1.25,-112.75,20.329999923706),
					Use	=	true,
					Mid_Full	=	true,
					Pos3	=	Vector(1.25,-110.62999725342,15.329999923706),
						},
				UseSprite	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(19.659999847412,-112.12999725342,19.559999465942),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				ReverseColor	=	{
						255,
						255,
						255,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(22.329999923706,-110.94999694824,14.890000343323),
					Pos2	=	Vector(-0.52999997138977,-112.95999908447,20.920000076294),
					Use	=	true,
					Pos1	=	Vector(22.340000152588,-113.30999755859,20.930000305176),
					Pos3	=	Vector(-0.6700000166893,-110.41999816895,14.819999694824),
						},
				RenderInner_Clr	=	{
						255,
						0,
						0,
						},
				Dynamic	=	{
					Brightness	=	1.57,
					Size	=	0.06,
						},
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(20.010000228882,21.129999160767,30.190000534058),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(-21.010000228882,-13.960000038147,27.190000534058),
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(20.010000228882,-13.960000038147,27.190000534058),
					},
				},
		Fuel	=	{
			FuelLidPos	=	Vector(-47.520000457764,-51.400001525879,38.479999542236),
			FuelLidUse	=	true,
			FuelType	=	0,
				},
		Author	=	"𝒞𝓇𝑒𝑒𝓅𝑒𝓇 (76561198051637331)",
}