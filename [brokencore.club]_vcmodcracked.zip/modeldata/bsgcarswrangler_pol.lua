VCModels['models/bsgcarswrangler_pol.mdl']	=	{
		em_state	=	5236595022,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Siren	=	{
			InterSec	=	{
					{
					Color	=	{
							0,
							0,
							0,
							},
					Pos1	=	Vector(11.199999809265,12.10000038147,64),
					SzM	=	1,
					Pos2	=	Vector(12.5,12.10000038147,64),
						},
					},
			Sounds	=	{
					{
					Pitch	=	100,
					Volume	=	1,
					Distance	=	95,
					Name	=	"Wail",
					Sound	=	"vcmod/els/cencom/wail.wav",
						},
					{
					Pitch	=	100,
					Volume	=	1,
					Distance	=	95,
					Name	=	"Yelp",
					Sound	=	"vcmod/els/cencom/yelp.wav",
						},
					{
					Pitch	=	100,
					Volume	=	1,
					Distance	=	95,
					Name	=	"Priority",
					Sound	=	"vcmod/els/cencom/priority.wav",
						},
					},
			Codes	=	{
				[13]	=	{
					Include	=	true,
						},
				[8]	=	{
					SSeq_Ovr_SSeq	=	3,
					SSeq_Ovr	=	true,
						},
				[6]	=	{
					SSeq_Ovr_SSeq	=	2,
					SSeq_Ovr	=	true,
						},
					},
			Sections	=	{
				[1]	=	{
					[14]	=	true,
					[13]	=	true,
					[20]	=	true,
					[18]	=	true,
					[17]	=	true,
					[16]	=	true,
					[15]	=	true,
					[19]	=	true,
						},
				[3]	=	{
						true,
						true,
						true,
						true,
						true,
						true,
						true,
						true,
						true,
						true,
						true,
						true,
						},
					},
			Lights	=	{
					{
					Sprite	=	{
						Size	=	0.15,
							},
					Dynamic	=	{
						Size	=	0.55,
						Brightness	=	2,
							},
					SpecRec	=	{
						Pos4	=	Vector(-14.770000457764,-16,89.900001525879),
						AmountV	=	3,
						Pos2	=	Vector(-9,-16,91.400001525879),
						AmountH	=	7,
						Use	=	true,
						Pos1	=	Vector(-14.800000190735,-16,91.400001525879),
						Pos3	=	Vector(-9,-16,89.900001525879),
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-11.890000343323,-16,90.650001525879),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							0,
							55,
							255,
							},
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.15,
							},
					Dynamic	=	{
						Size	=	0.55,
						Brightness	=	2,
							},
					SpecRec	=	{
						AmountV	=	3,
						Pos4	=	Vector(-23.020000457764,-16,89.900001525879),
						Pos2	=	Vector(-17.479999542236,-16,91.400001525879),
						AmountH	=	7,
						Use	=	true,
						Pos1	=	Vector(-23.020000457764,-16,91.400001525879),
						Pos3	=	Vector(-17.479999542236,-16,89.900001525879),
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-20.25,-16,90.650001525879),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							0,
							55,
							255,
							},
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.15,
							},
					Dynamic	=	{
						Size	=	0.55,
						Brightness	=	2,
							},
					SpecRec	=	{
						Pos4	=	Vector(-31,-14,89.900001525879),
						AmountV	=	3,
						Pos2	=	Vector(-25.329999923706,-16,91.400001525879),
						AmountH	=	7,
						Use	=	true,
						Pos1	=	Vector(-31,-14,91.400001525879),
						Pos3	=	Vector(-25.329999923706,-16,89.900001525879),
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-28.170000076294,-15,90.650001525879),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							0,
							55,
							255,
							},
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.15,
							},
					Dynamic	=	{
						Size	=	0.55,
						Brightness	=	2,
							},
					SpecRec	=	{
						AmountV	=	3,
						Pos4	=	Vector(-14.770000457764,-5.0999999046326,89.900001525879),
						Pos2	=	Vector(-9,-5.0999999046326,91.400001525879),
						AmountH	=	7,
						Use	=	true,
						Pos1	=	Vector(-14.800000190735,-5.0999999046326,91.400001525879),
						Pos3	=	Vector(-9,-5.0999999046326,89.900001525879),
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-11.890000343323,-5.0999999046326,90.650001525879),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							0,
							55,
							255,
							},
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.15,
							},
					Dynamic	=	{
						Size	=	0.55,
						Brightness	=	2,
							},
					SpecRec	=	{
						Pos4	=	Vector(-23.020000457764,-5.0999999046326,89.900001525879),
						AmountV	=	3,
						Pos2	=	Vector(-17.479999542236,-5.0999999046326,91.400001525879),
						AmountH	=	7,
						Use	=	true,
						Pos1	=	Vector(-23.020000457764,-5.0999999046326,91.400001525879),
						Pos3	=	Vector(-17.479999542236,-5.0999999046326,89.900001525879),
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-20.25,-5.0999999046326,90.650001525879),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							0,
							55,
							255,
							},
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.15,
							},
					Dynamic	=	{
						Size	=	0.55,
						Brightness	=	2,
							},
					SpecRec	=	{
						AmountV	=	3,
						Pos4	=	Vector(-31,-7.0999999046326,89.900001525879),
						Pos2	=	Vector(-25.329999923706,-5.0999999046326,91.400001525879),
						AmountH	=	7,
						Use	=	true,
						Pos1	=	Vector(-31,-7.0999999046326,91.400001525879),
						Pos3	=	Vector(-25.329999923706,-5.0999999046326,89.900001525879),
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-28.170000076294,-6.0999999046326,90.650001525879),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							0,
							55,
							255,
							},
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.15,
							},
					Dynamic	=	{
						Size	=	0.55,
						Brightness	=	2,
							},
					SpecRec	=	{
						AmountV	=	3,
						Pos4	=	Vector(14.770000457764,-16,89.900001525879),
						Pos2	=	Vector(9,-16,91.400001525879),
						AmountH	=	7,
						Use	=	true,
						Pos1	=	Vector(14.800000190735,-16,91.400001525879),
						Pos3	=	Vector(9,-16,89.900001525879),
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(11.890000343323,-16,90.650001525879),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					Beta_Inner3D	=	true,
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.15,
							},
					Dynamic	=	{
						Size	=	0.55,
						Brightness	=	2,
							},
					SpecRec	=	{
						Pos4	=	Vector(23.020000457764,-16,89.900001525879),
						AmountV	=	3,
						Pos2	=	Vector(17.479999542236,-16,91.400001525879),
						AmountH	=	7,
						Use	=	true,
						Pos1	=	Vector(23.020000457764,-16,91.400001525879),
						Pos3	=	Vector(17.479999542236,-16,89.900001525879),
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(20.25,-16,90.650001525879),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					Beta_Inner3D	=	true,
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.15,
							},
					Dynamic	=	{
						Size	=	0.55,
						Brightness	=	2,
							},
					SpecRec	=	{
						AmountV	=	3,
						Pos4	=	Vector(31,-14,89.900001525879),
						Pos2	=	Vector(25.329999923706,-16,91.400001525879),
						AmountH	=	7,
						Use	=	true,
						Pos1	=	Vector(31,-14,91.400001525879),
						Pos3	=	Vector(25.329999923706,-16,89.900001525879),
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(28.170000076294,-15,90.650001525879),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					Beta_Inner3D	=	true,
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.15,
							},
					Dynamic	=	{
						Size	=	0.55,
						Brightness	=	2,
							},
					SpecRec	=	{
						Pos4	=	Vector(14.770000457764,-5.0999999046326,89.900001525879),
						AmountV	=	3,
						Pos2	=	Vector(9,-5.0999999046326,91.400001525879),
						AmountH	=	7,
						Use	=	true,
						Pos1	=	Vector(14.800000190735,-5.0999999046326,91.400001525879),
						Pos3	=	Vector(9,-5.0999999046326,89.900001525879),
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(11.890000343323,-5.0999999046326,90.650001525879),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					Beta_Inner3D	=	true,
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.15,
							},
					Dynamic	=	{
						Size	=	0.55,
						Brightness	=	2,
							},
					SpecRec	=	{
						AmountV	=	3,
						Pos4	=	Vector(23.020000457764,-5.0999999046326,89.900001525879),
						Pos2	=	Vector(17.479999542236,-5.0999999046326,91.400001525879),
						AmountH	=	7,
						Use	=	true,
						Pos1	=	Vector(23.020000457764,-5.0999999046326,91.400001525879),
						Pos3	=	Vector(17.479999542236,-5.0999999046326,89.900001525879),
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(20.25,-5.0999999046326,90.650001525879),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					Beta_Inner3D	=	true,
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.15,
							},
					Dynamic	=	{
						Size	=	0.55,
						Brightness	=	2,
							},
					SpecRec	=	{
						Pos4	=	Vector(31,-7.0999999046326,89.900001525879),
						AmountV	=	3,
						Pos2	=	Vector(25.329999923706,-5.0999999046326,91.400001525879),
						AmountH	=	7,
						Use	=	true,
						Pos1	=	Vector(31,-7.0999999046326,91.400001525879),
						Pos3	=	Vector(25.329999923706,-5.0999999046326,89.900001525879),
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(28.170000076294,-6.0999999046326,90.650001525879),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					Beta_Inner3D	=	true,
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.075,
							},
					Dynamic	=	{
						Size	=	0.45,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(13.010000228882,99.449996948242,45.529998779297),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							0,
							55,
							255,
							},
					SpecLine	=	{
						Amount	=	6,
						Pos	=	Vector(10.89999961853,99.449996948242,45.529998779297),
						Use	=	true,
							},
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.075,
							},
					Dynamic	=	{
						Size	=	0.45,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(10.439999580383,99.449996948242,45.529998779297),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							0,
							55,
							255,
							},
					SpecLine	=	{
						Amount	=	6,
						Pos	=	Vector(8.3299999237061,99.449996948242,45.529998779297),
						Use	=	true,
							},
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.075,
							},
					Dynamic	=	{
						Size	=	0.45,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(7.9299998283386,99.449996948242,45.529998779297),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							0,
							55,
							255,
							},
					SpecLine	=	{
						Amount	=	6,
						Pos	=	Vector(5.8200001716614,99.449996948242,45.529998779297),
						Use	=	true,
							},
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.075,
							},
					Dynamic	=	{
						Size	=	0.45,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(5.3699998855591,99.449996948242,45.529998779297),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							0,
							55,
							255,
							},
					SpecLine	=	{
						Amount	=	6,
						Pos	=	Vector(3.2599999904633,99.449996948242,45.529998779297),
						Use	=	true,
							},
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.075,
							},
					Dynamic	=	{
						Size	=	0.45,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-13.010000228882,99.449996948242,45.529998779297),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					SpecLine	=	{
						Amount	=	6,
						Pos	=	Vector(-10.89999961853,99.449996948242,45.529998779297),
						Use	=	true,
							},
					Beta_Inner3D	=	true,
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.075,
							},
					Dynamic	=	{
						Size	=	0.45,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-10.439999580383,99.449996948242,45.529998779297),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					SpecLine	=	{
						Amount	=	6,
						Pos	=	Vector(-8.3299999237061,99.449996948242,45.529998779297),
						Use	=	true,
							},
					Beta_Inner3D	=	true,
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.075,
							},
					Dynamic	=	{
						Size	=	0.45,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-7.9299998283386,99.449996948242,45.529998779297),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					SpecLine	=	{
						Amount	=	6,
						Pos	=	Vector(-5.8200001716614,99.449996948242,45.529998779297),
						Use	=	true,
							},
					Beta_Inner3D	=	true,
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.075,
							},
					Dynamic	=	{
						Size	=	0.45,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-5.3699998855591,99.449996948242,45.529998779297),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					SpecLine	=	{
						Amount	=	6,
						Pos	=	Vector(-3.2599999904633,99.449996948242,45.529998779297),
						Use	=	true,
							},
					Beta_Inner3D	=	true,
					UseSprite	=	true,
						},
					},
			Sounds_Horn	=	{
				Use	=	true,
				Volume	=	1,
				Distance	=	95,
				Pitch	=	100,
				Sound	=	"vcmod/els/cencom/bullhorn.wav",
					},
			Sequences	=	{
					{
					SubSeq	=	{
							{
							Stages	=	{
									{
									Lights	=	{
											1,
											2,
											3,
											4,
											5,
											6,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											1,
											2,
											3,
											4,
											5,
											6,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											1,
											2,
											3,
											4,
											5,
											6,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											1,
											2,
											3,
											4,
											5,
											6,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											1,
											2,
											3,
											4,
											5,
											6,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											7,
											8,
											9,
											10,
											11,
											12,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											7,
											8,
											9,
											10,
											11,
											12,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											7,
											8,
											9,
											10,
											11,
											12,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											7,
											8,
											9,
											10,
											11,
											12,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											7,
											8,
											9,
											10,
											11,
											12,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									},
							Time	=	5,
								},
							{
							Stages	=	{
									{
									Lights	=	{
											1,
											2,
											3,
											4,
											5,
											6,
											},
									Time	=	0.2,
										},
									{
									Lights	=	{
											7,
											8,
											9,
											10,
											11,
											12,
											},
									Time	=	0.2,
										},
									},
							Time	=	5,
								},
							{
							Stages	=	{
									{
									Lights	=	{
											3,
											6,
											9,
											12,
											},
									Time	=	0.075,
										},
									{
									Lights	=	{
											2,
											5,
											8,
											11,
											},
									Time	=	0.075,
										},
									{
									Lights	=	{
											1,
											4,
											7,
											10,
											},
									Time	=	0.075,
										},
									{
									Lights	=	{
											2,
											5,
											8,
											11,
											},
									Time	=	0.075,
										},
									},
							Time	=	5,
								},
							},
					Codes	=	{
						[7]	=	true,
						[6]	=	true,
							},
					Lights_Sel	=	{
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							},
						},
					{
					SubSeq	=	{
							{
							Stages	=	{
									{
									Lights	=	{
											17,
											18,
											19,
											20,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											17,
											18,
											19,
											20,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											13,
											14,
											15,
											16,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											13,
											14,
											15,
											16,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									},
							Time	=	5,
								},
							{
							Stages	=	{
									{
									Lights	=	{
											17,
											13,
											},
									Time	=	0.075,
										},
									{
									Lights	=	{
											18,
											14,
											},
									Time	=	0.075,
										},
									{
									Lights	=	{
											19,
											15,
											},
									Time	=	0.075,
										},
									{
									Lights	=	{
											20,
											16,
											},
									Time	=	0.075,
										},
									{
									Lights	=	{
											19,
											15,
											},
									Time	=	0.075,
										},
									{
									Lights	=	{
											18,
											14,
											},
									Time	=	0.075,
										},
									},
							Time	=	5,
								},
							{
							Stages	=	{
									{
									Lights	=	{
											17,
											18,
											19,
											20,
											},
									Time	=	0.2,
										},
									{
									Lights	=	{
											13,
											14,
											15,
											16,
											},
									Time	=	0.2,
										},
									},
							Time	=	5,
								},
							},
					Codes	=	{
						[6]	=	true,
						[7]	=	true,
						[8]	=	true,
							},
					Lights_Sel	=	{
						[14]	=	true,
						[13]	=	true,
						[20]	=	true,
						[18]	=	true,
						[17]	=	true,
						[16]	=	true,
						[15]	=	true,
						[19]	=	true,
							},
						},
					},
			Sounds_Manual	=	{
				Use	=	true,
				Volume	=	1,
				Distance	=	95,
				Pitch	=	100,
				Sound	=	"vcmod/els/cencom/wail.wav",
					},
				},
		Date	=	"03/05/15 19:43:56",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(23.299999237061,-87.48999786377,22.219999313354),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(18.5,-5,46.200000762939),
				RadioControl	=	true,
					},
				{
				Pos	=	Vector(-18.5,-40,46.200000762939),
				Ang	=	Angle(0,0,0),
				Cant_Exit_Lock	=	true,
				switch_rear	=	true,
				Switch_Rear	=	true,
					},
				{
				Pos	=	Vector(18.5,-40,46.200000762939),
				Ang	=	Angle(0,0,0),
				Cant_Exit_Lock	=	true,
				switch_rear	=	true,
				Switch_Rear	=	true,
					},
				},
		DLT	=	3491063348,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
				UseReverse	=	true,
				UseSprite	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				SpecLine	=	{
					Amount	=	3,
					Pos	=	Vector(-32.389999389648,-83.620002746582,46.340000152588),
					Use	=	true,
						},
				Pos	=	Vector(-35.680000305176,-83.620002746582,46.340000152588),
				UseDynamic	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				UseBrake	=	true,
				UseDynamic	=	true,
				Pos	=	Vector(-2.9700000286102,-88.580001831055,69.930000305176),
				UseSprite	=	true,
				SpecLine	=	{
					Amount	=	4,
					Pos	=	Vector(2.9700000286102,-88.580001831055,69.930000305176),
					Use	=	true,
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						55,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(-33.959999084473,-83.629997253418,50.590000152588),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-23.479999542236,85.25,38.110000610352),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				RenderInner_Size	=	1.2,
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-43.659999847412,81.680000305176,43.319999694824),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				RenderInner_Size	=	1.2,
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				ProjTexture	=	{
					Forward	=	30,
					Size	=	2000,
					Angle	=	Angle(0,90,0),
						},
				UseHead	=	true,
				UsePrjTex	=	true,
				Pos	=	Vector(-22.479999542236,81.949996948242,47.400001525879),
				UseDynamic	=	true,
				HeadColor	=	{
						192,
						223,
						255,
						},
				UseSprite	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				UseRunning	=	true,
				UseSprite	=	true,
				RunningColor	=	{
						199.23,
						239.35,
						243.48,
						},
				Pos	=	Vector(-10.680000305176,96.099998474121,29.200000762939),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
				UseReverse	=	true,
				UseSprite	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				SpecLine	=	{
					Amount	=	3,
					Pos	=	Vector(32.389999389648,-83.620002746582,46.340000152588),
					Use	=	true,
						},
				Pos	=	Vector(35.680000305176,-83.620002746582,46.340000152588),
				UseDynamic	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						55,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(33.959999084473,-83.629997253418,50.590000152588),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(23.479999542236,85.25,38.110000610352),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				RenderInner_Size	=	1.2,
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(43.659999847412,81.680000305176,43.319999694824),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				RenderInner_Size	=	1.2,
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				ProjTexture	=	{
					Forward	=	30,
					Size	=	2000,
					Angle	=	Angle(0,90,0),
						},
				UseHead	=	true,
				UsePrjTex	=	true,
				Pos	=	Vector(22.479999542236,81.949996948242,47.400001525879),
				UseDynamic	=	true,
				HeadColor	=	{
						192,
						223,
						255,
						},
				UseSprite	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				UseRunning	=	true,
				Pos	=	Vector(10.680000305176,96.099998474121,29.200000762939),
				RunningColor	=	{
						199.23,
						239.35,
						243.48,
						},
				UseSprite	=	true,
					},
				},
		Copyright	=	"DurkaTeam @ 2025 No rights reserved",
		Author	=	"freemmaann",
}