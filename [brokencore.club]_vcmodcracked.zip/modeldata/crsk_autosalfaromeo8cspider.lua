VCModels['models/crsk_autosalfaromeo8cspider.mdl']	=	{
		Light_DD_Int	=	true,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		HealthEnginePosOvr	=	true,
		Date	=	"Sun Nov  4 15:41:32 2018",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-24.829999923706,-99.849998474121,16.700000762939),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-29.829999923706,-99.849998474121,16.700000762939),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(29.329999923706,-99.849998474121,16.5),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(24.549999237061,-99.849998474121,16.5),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		Copyright	=	"Copyright © 2012-2018 VCMod (freemmaann). All Rights Reserved.",
		em_state	=	5236594506,
		HealthEnginePos	=	Vector(0,60,38),
		DLT	=	3491063004,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(32.340000152588,81,30.639999389648),
					UseColor	=	true,
					Pos2	=	Vector(28.219999313354,81,34.759998321533),
					Color	=	{
						r	=	255,
						b	=	255,
						a	=	255,
						g	=	255,
							},
					Use	=	true,
					Pos1	=	Vector(32.340000152588,81,34.759998321533),
					Pos3	=	Vector(28.219999313354,81,30.639999389648),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(30.280000686646,81,32.700000762939),
				UseDynamic	=	true,
				UseRunning	=	true,
				Beta_Inner3D	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	255,
					a	=	255,
					g	=	255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-31.969999313354,81.040000915527,30.89999961853),
					UseColor	=	true,
					Pos2	=	Vector(-27.85000038147,81.040000915527,35.020000457764),
					Color	=	{
						r	=	255,
						b	=	255,
						a	=	255,
						g	=	255,
							},
					Use	=	true,
					Pos1	=	Vector(-31.969999313354,81.040000915527,35.020000457764),
					Pos3	=	Vector(-27.85000038147,81.040000915527,30.89999961853),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-29.909999847412,81.040000915527,32.959999084473),
				UseDynamic	=	true,
				UseRunning	=	true,
				Beta_Inner3D	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	255,
					a	=	255,
					g	=	255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(37.599998474121,78.919998168945,32.090000152588),
					Pos2	=	Vector(33.479999542236,78.919998168945,36.209999084473),
					Color	=	{
							255,
							255,
							255,
							},
					Use	=	true,
					Pos1	=	Vector(37.599998474121,78.919998168945,36.209999084473),
					Pos3	=	Vector(33.479999542236,78.919998168945,32.090000152588),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(35.540000915527,78.919998168945,34.150001525879),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				UseSprite	=	true,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-35.090000152588,78.919998168945,34.369998931885),
				UseDynamic	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-37.150001525879,78.919998168945,32.310001373291),
					Pos2	=	Vector(-33.029998779297,78.919998168945,36.430000305176),
					Color	=	{
							255,
							255,
							255,
							},
					Use	=	true,
					Pos1	=	Vector(-37.150001525879,78.919998168945,36.430000305176),
					Pos3	=	Vector(-33.029998779297,78.919998168945,32.310001373291),
						},
				Beta_Inner3D	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(35.209999084473,87.169998168945,25.270000457764),
					UseColor	=	true,
					Pos2	=	Vector(31.069999694824,87.169998168945,29.409999847412),
					Color	=	{
						r	=	225,
						b	=	255,
						a	=	255,
						g	=	222,
							},
					Use	=	true,
					Pos1	=	Vector(35.209999084473,87.169998168945,29.409999847412),
					Pos3	=	Vector(31.069999694824,87.169998168945,25.270000457764),
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				HBeamColor	=	{
					r	=	222,
					b	=	255,
					a	=	255,
					g	=	222,
						},
				ReducedVis	=	true,
				SpecMat	=	{
						},
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	222,
					b	=	255,
					a	=	255,
					g	=	222,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				UseSprite	=	true,
				Pos	=	Vector(33.139999389648,87.169998168945,27.340000152588),
				Beta_Inner3D	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-34.819999694824,87.319999694824,25.530000686646),
					UseColor	=	true,
					Pos2	=	Vector(-30.680000305176,87.319999694824,29.670000076294),
					Color	=	{
						r	=	225,
						b	=	255,
						a	=	255,
						g	=	222,
							},
					Use	=	true,
					Pos1	=	Vector(-34.819999694824,87.319999694824,29.670000076294),
					Pos3	=	Vector(-30.680000305176,87.319999694824,25.530000686646),
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				HBeamColor	=	{
					r	=	222,
					b	=	255,
					a	=	255,
					g	=	222,
						},
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	222,
					b	=	255,
					a	=	255,
					g	=	222,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-32.75,87.319999694824,27.60000038147),
				UseSprite	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				UsePrjTex	=	true,
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				FogColor	=	{
					r	=	255,
					b	=	254,
					a	=	255,
					g	=	255,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				UseSprite	=	true,
				Pos	=	Vector(26.709999084473,95.98999786377,17.479999542236),
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(25.569999694824,96.339996337891,16.64999961853),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.040000915527,96.150001525879,15.220000267029),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.469999313354,96.349998474121,15.340000152588),
								},
							{
							Pos	=	Vector(27.860000610352,96.199996948242,16.75),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
					Use	=	true,
						},
				UseFog	=	true,
				RenderHD_Adv	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				UsePrjTex	=	true,
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				FogColor	=	{
					r	=	255,
					b	=	254,
					a	=	255,
					g	=	255,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				RenderHD_Adv	=	true,
				Pos	=	Vector(-26.270000457764,96.099998474121,17.629999160767),
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-25.129999160767,96.449996948242,16.799999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.60000038147,96.26000213623,15.369999885559),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.030000686646,96.459999084473,15.489999771118),
								},
							{
							Pos	=	Vector(-27.420000076294,96.309997558594,16.89999961853),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
					Use	=	true,
						},
				UseFog	=	true,
				UseSprite	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-42.5,81.529998779297,18.930000305176),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-40.5,85.029998779297,18.930000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38,88.529998779297,18.930000305176),
								},
							},
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				Beta_Inner3D	=	true,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				RenderMLCenter	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				Beta_Inner3D	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(43,81.529998779297,18.930000305176),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(41,85.029998779297,18.930000305176),
								},
							{
							Pos	=	Vector(38.5,88.529998779297,18.930000305176),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				FogColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(26.170000076294,-102.90000152588,38.270000457764),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseFog	=	true,
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				FogColor	=	{
						255,
						55,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-26.489999771118,-102.69999694824,38.450000762939),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseFog	=	true,
				RenderInner_Size	=	1,
				Beta_Inner3D	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.04,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						100,
						0,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(26.170000076294,-103.09999847412,38.270000457764),
				UseDynamic	=	true,
				RenderInner_Size	=	3.6,
				UseSprite	=	true,
				SpecCircle	=	{
					Amount	=	35,
					Use	=	true,
					Radius	=	2.2,
						},
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.04,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						100,
						0,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(26.170000076294,-103.09999847412,38.270000457764),
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	35,
					Use	=	true,
					Radius	=	1.6,
						},
				UseSprite	=	true,
				RenderInner	=	true,
				RenderInner_Size	=	3.6,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				UseSprite	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(26.170000076294,-102.90000152588,38.270000457764),
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	35,
					Use	=	true,
					Radius	=	3,
						},
				UseRunning	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Size	=	1,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.04,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						100,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-26.559999465942,-103.09999847412,38.479999542236),
				UseDynamic	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				SpecCircle	=	{
					Amount	=	35,
					Use	=	true,
					Radius	=	2.2,
						},
				RenderInner_Size	=	3.6,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.04,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						100,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-26.559999465942,-103.09999847412,38.479999542236),
				UseDynamic	=	true,
				RenderInner_Size	=	3.6,
				SpecCircle	=	{
					Amount	=	35,
					Use	=	true,
					Radius	=	1.6,
						},
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				Beta_Inner3D	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner_Size	=	1,
				UseSprite	=	true,
				Pos	=	Vector(-26.39999961853,-103.09999847412,38.479999542236),
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	35,
					Use	=	true,
					Radius	=	3,
						},
				UseRunning	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				RenderInner	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(17.639999389648,-102.69999694824,14.710000038147),
					UseColor	=	true,
					Pos2	=	Vector(13.880000114441,-102.69999694824,18.469999313354),
					Color	=	{
						r	=	255,
						b	=	255,
						a	=	255,
						g	=	255,
							},
					Use	=	true,
					Pos1	=	Vector(17.639999389648,-102.69999694824,18.469999313354),
					Pos3	=	Vector(13.880000114441,-102.69999694824,14.710000038147),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(15.760000228882,-102.69999694824,16.590000152588),
				UseDynamic	=	true,
				ReverseColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-18.139999389648,-102.69999694824,14.779999732971),
					UseColor	=	true,
					Pos2	=	Vector(-14.380000114441,-102.69999694824,18.540000915527),
					Color	=	{
						r	=	255,
						b	=	255,
						a	=	255,
						g	=	255,
							},
					Use	=	true,
					Pos1	=	Vector(-18.139999389648,-102.69999694824,18.540000915527),
					Pos3	=	Vector(-14.380000114441,-102.69999694824,14.779999732971),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-16.260000228882,-102.69999694824,16.659999847412),
				UseDynamic	=	true,
				ReverseColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						55,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-43.479999542236,-90.199996948242,26.5),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-41.299999237061,-94.699996948242,26.5),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-39.479999542236,-97.699996948242,26.5),
								},
							},
						},
				UseSprite	=	true,
				RenderMLCenter	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						55,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				UseSprite	=	true,
				Pos	=	Vector(42.979999542236,-90.199996948242,26.299999237061),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(40.799999237061,-94.699996948242,26.299999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(38.979999542236,-97.699996948242,26.299999237061),
								},
							},
						},
				Beta_Inner3D	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				UseBrake	=	true,
				RenderMLCenter	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(13.960000038147,-105.83000183105,46.200000762939),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	50,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(0.28000000119209,-106,46.200000762939),
								},
							{
							Pos	=	Vector(-13.720000267029,-105.83000183105,46.200000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(14.60000038147,0,0),
				Pos	=	Vector(17.040000915527,-12.560000419617,28.829999923706),
				RadioControl	=	true,
					},
				},
		Fuel	=	{
			FuelLidPos	=	Vector(29.719999313354,-82.680000305176,47.549999237061),
			FuelTypeUse	=	true,
			FuelType	=	0,
			Capacity	=	90,
			FuelLidUse	=	true,
			Override	=	true,
				},
		Author	=	"DangerKiddy(DK) (76561198132964487)",
}