VCModels['models/crsk_autosdodgechallenger_hellcat_2015.mdl']	=	{
		em_state	=	5236594470,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		HealthEnginePosOvr	=	true,
		Date	=	"Sun Sep 17 14:13:06 2017",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-27.010000228882,-114.7200012207,17.159999847412),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(26.479999542236,-114.84999847412,17.010000228882),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		Copyright	=	"Copyright © 2012-2017 VCMod (freemmaann). All Rights Reserved.",
		HealthEnginePos	=	Vector(0,85.5,37.5),
		DLT	=	3491062980,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.02,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				SpecRec	=	{
					AmountV	=	5,
					Pos4	=	Vector(12.770000457764,-115.59999847412,45.259998321533),
					Mid_Full	=	true,
					Pos2	=	Vector(25.020000457764,-114.91000366211,46.220001220703),
					AmountH	=	23,
					Use	=	true,
					Pos1	=	Vector(12.760000228882,-115.44999694824,46.299999237061),
					Pos3	=	Vector(24.940000534058,-115.13999938965,45.319999694824),
						},
				UseDynamic	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(19.260000228882,-115.2200012207,45.720001220703),
				RenderInner	=	true,
				RenderHD_Size	=	0.2,
				Beta_Inner3D	=	true,
				RenderInner_Size	=	4,
				RenderHD_Adv	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
						},
				DD_Blnk_Run	=	true,
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						195,
						195,
						255,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(27.5,111.30000305176,38.919998168945),
				UseBlinkers	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(27.045000076294,111.31700134277,38.340000152588),
								},
							{
							Pos	=	Vector(26.694000244141,111.33499908447,37.523998260498),
								},
							{
							Pos	=	Vector(26.587999343872,111.33999633789,36.708999633789),
								},
							{
							Pos	=	Vector(26.694000244141,111.33499908447,35.89400100708),
								},
							{
							Pos	=	Vector(27.003999710083,111.31999969482,35.134998321533),
								},
							{
							Pos	=	Vector(27.496999740601,111.29499816895,34.483001708984),
								},
							{
							Pos	=	Vector(28.138999938965,111.26300048828,33.981998443604),
								},
							{
							Pos	=	Vector(28.888000488281,111.2259979248,33.667999267578),
								},
							{
							Pos	=	Vector(29.693000793457,111.18599700928,33.560001373291),
								},
							{
							Pos	=	Vector(30.497999191284,111.14600372314,33.667999267578),
								},
							{
							Pos	=	Vector(31.246999740601,111.10900115967,33.981998443604),
								},
							{
							Pos	=	Vector(31.888999938965,111.077003479,34.481998443604),
								},
							{
							Pos	=	Vector(32.381999969482,111.05200195312,35.134998321533),
								},
							{
							Pos	=	Vector(32.692001342773,111.03700256348,35.89400100708),
								},
							{
							Pos	=	Vector(32.798000335693,111.03199768066,36.708999633789),
								},
							{
							Pos	=	Vector(32.692001342773,111.03700256348,37.523998260498),
								},
							{
							Pos	=	Vector(32.340999603271,111.05400085449,38.340000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.889999389648,111.08000183105,38.919998168945),
								},
							},
						},
				UseSprite	=	true,
				RunningColor	=	{
						200,
						225,
						255,
						},
				RenderInner_Size	=	1.5,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
						195,
						195,
						255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(40.860000610352,108.81999969482,39.310001373291),
					UseColor	=	true,
					Pos2	=	Vector(35.680000305176,108.81999969482,34.130001068115),
					Color	=	{
							255,
							255,
							255,
							},
					Use	=	true,
					Pos1	=	Vector(35.680000305176,108.81999969482,39.310001373291),
					Pos3	=	Vector(40.860000610352,108.81999969482,34.130001068115),
						},
				HBeamColor	=	{
						195,
						195,
						255,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(38.270000457764,108.81999969482,36.720001220703),
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1,
				SpecMat	=	{
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.03,
						},
				SpecSpin	=	{
						},
				RenderHD_Size	=	0.2,
				RenderInner_Clr	=	{
						255,
						55,
						0,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				UseSprite	=	true,
				Pos	=	Vector(37.720001220703,-114.09999847412,47.459999084473),
				RenderInner	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	250,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(38.148998260498,-114.06500244141,47.157001495361),
								},
							{
							Pos	=	Vector(38.486999511719,-114.04699707031,46.604000091553),
								},
							{
							Pos	=	Vector(38.694400787354,-114.04399871826,46.023998260498),
								},
							{
							Pos	=	Vector(38.770999908447,-114.05100250244,45.411998748779),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(38.779998779297,-114.08999633789,44.869998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(38.540000915527,-114.12000274658,44.319999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(38.299999237061,-114.13999938965,43.919998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.860000610352,-114.16000366211,43.659999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.279998779297,-114.23000335693,43.470001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.689998626709,-114.30000305176,43.419998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.430000305176,-114.94999694824,43.369998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(18.60000038147,-115.83000183105,43.439998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(15.029999732971,-116,43.459999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(13.050000190735,-116.06999969482,43.490001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(11.699999809265,-116.15000152588,43.650001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(11.239999771118,-116.16000366211,43.860000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(10.989999771118,-116.16000366211,44.229999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(10.920000076294,-116.12999725342,46.040000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(10.939999580383,-116.08999633789,47.049999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(11.10000038147,-116.06999969482,47.509998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(11.479999542236,-116.08000183105,47.799999237061),
								},
							{
							Pos	=	Vector(11.984000205994,-116.09200286865,47.865001678467),
								},
							{
							Pos	=	Vector(18.697999954224,-115.72200012207,47.832000732422),
								},
							{
							Pos	=	Vector(30.264999389648,-114.87000274658,47.717998504639),
								},
							{
							Pos	=	Vector(36.448001861572,-114.2320022583,47.615001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.479999542236,-114.08999633789,47.540000915527),
								},
							},
						},
				RenderHD_Adv	=	true,
				RunningColor	=	{
						255,
						10,
						0,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.02,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				SpecRec	=	{
					Pos4	=	Vector(-12.770000457764,-115.59999847412,45.259998321533),
					AmountV	=	5,
					Pos1	=	Vector(-12.760000228882,-115.44999694824,46.299999237061),
					Pos2	=	Vector(-25.020000457764,-114.91000366211,46.220001220703),
					AmountH	=	23,
					Use	=	true,
					Mid_Full	=	true,
					Pos3	=	Vector(-24.940000534058,-115.13999938965,45.319999694824),
						},
				UseDynamic	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderHD_Adv	=	true,
				Pos	=	Vector(-19.260000228882,-115.2200012207,45.720001220703),
				RenderInner_Size	=	4,
				RenderHD_Size	=	0.2,
				UseSprite	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
						},
				DD_Blnk_Run	=	true,
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						195,
						195,
						255,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-26.85000038147,111.76999664307,39.150001525879),
				UseBlinkers	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-26.395000457764,111.78700256348,38.569999694824),
								},
							{
							Pos	=	Vector(-26.04400062561,111.80500030518,37.754001617432),
								},
							{
							Pos	=	Vector(-25.937999725342,111.80999755859,36.938999176025),
								},
							{
							Pos	=	Vector(-26.04400062561,111.80500030518,36.124000549316),
								},
							{
							Pos	=	Vector(-26.354000091553,111.79000091553,35.365001678467),
								},
							{
							Pos	=	Vector(-26.84700012207,111.76499938965,34.713001251221),
								},
							{
							Pos	=	Vector(-27.489000320435,111.73300170898,34.212001800537),
								},
							{
							Pos	=	Vector(-28.238000869751,111.69599914551,33.897998809814),
								},
							{
							Pos	=	Vector(-29.042999267578,111.65599822998,33.790000915527),
								},
							{
							Pos	=	Vector(-29.847999572754,111.61599731445,33.897998809814),
								},
							{
							Pos	=	Vector(-30.59700012207,111.57900238037,34.212001800537),
								},
							{
							Pos	=	Vector(-31.239000320435,111.54699707031,34.712001800537),
								},
							{
							Pos	=	Vector(-31.732000350952,111.52200317383,35.365001678467),
								},
							{
							Pos	=	Vector(-32.041999816895,111.50700378418,36.124000549316),
								},
							{
							Pos	=	Vector(-32.147998809814,111.50199890137,36.938999176025),
								},
							{
							Pos	=	Vector(-32.041999816895,111.50700378418,37.754001617432),
								},
							{
							Pos	=	Vector(-31.690999984741,111.5240020752,38.569999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.239999771118,111.55000305176,39.150001525879),
								},
							},
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
						200,
						225,
						255,
						},
				RenderInner_Size	=	1.5,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
						},
				UseSprite	=	true,
				RunningColor	=	{
						200,
						225,
						255,
						},
				RenderInner	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-35.290000915527,110.80000305176,38.979999542236),
				UseDynamic	=	true,
				RenderInner_Size	=	2,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-34.889999389648,110.84999847412,38.439998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.509998321533,110.88999938965,37.549999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.439998626709,110.91000366211,36.700000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.580001831055,110.90000152588,35.840000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.950000762939,110.90000152588,35.009998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.490001678467,110.84999847412,34.430000305176),
								},
							{
							Pos	=	Vector(-36.131999969482,110.80599975586,33.931999206543),
								},
							{
							Pos	=	Vector(-36.880001068115,110.76899719238,33.618000030518),
								},
							{
							Pos	=	Vector(-37.685001373291,110.72899627686,33.509998321533),
								},
							{
							Pos	=	Vector(-38.49100112915,110.68900299072,33.618000030518),
								},
							{
							Pos	=	Vector(-39.238998413086,110.65200042725,33.931999206543),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-39.939998626709,110.62000274658,34.419998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-40.470001220703,110.58000183105,35.049999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-40.860000610352,110.54000091553,35.860000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-40.970001220703,110.55000305176,36.700000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-40.860000610352,110.56999969482,37.549999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-40.659999847412,110.58000183105,38.159999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-40.310001373291,110.62000274658,38.799999237061),
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
						195,
						195,
						255,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
						195,
						195,
						255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-40.330001831055,109,39.430000305176),
					UseColor	=	true,
					Pos2	=	Vector(-35.150001525879,109,34.25),
					Color	=	{
							255,
							255,
							255,
							},
					Use	=	true,
					Pos1	=	Vector(-35.150001525879,109,39.430000305176),
					Pos3	=	Vector(-40.330001831055,109,34.25),
						},
				HBeamColor	=	{
						195,
						195,
						255,
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-37.740001678467,109,36.840000152588),
				RenderInner	=	true,
				SpecMat	=	{
						},
				RenderInner_Size	=	1,
				UseSprite	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.03,
						},
				SpecSpin	=	{
						},
				RenderHD_Size	=	0.2,
				RenderInner_Clr	=	{
						255,
						55,
						0,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				RenderHD_Adv	=	true,
				Pos	=	Vector(-38.069999694824,-114,47.630001068115),
				RenderInner	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	250,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-38.499000549316,-113.96499633789,47.326999664307),
								},
							{
							Pos	=	Vector(-38.837001800537,-113.94699859619,46.773998260498),
								},
							{
							Pos	=	Vector(-39.044399261475,-113.94400024414,46.194000244141),
								},
							{
							Pos	=	Vector(-39.120998382568,-113.95099639893,45.582000732422),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-39.130001068115,-113.98999786377,45.040000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.889999389648,-114.01999664307,44.490001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.650001525879,-114.04000091553,44.090000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.209999084473,-114.05999755859,43.830001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.630001068115,-114.12999725342,43.639999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.040000915527,-114.19999694824,43.590000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.780000686646,-114.84999847412,43.540000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-18.950000762939,-115.73000335693,43.610000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-15.380000114441,-115.90000152588,43.630001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-13.39999961853,-115.9700012207,43.659999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-12.050000190735,-116.05000305176,43.819999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-11.590000152588,-116.05999755859,44.029998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-11.340000152588,-116.05999755859,44.400001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-11.270000457764,-116.0299987793,46.209999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-11.289999961853,-115.98999786377,47.220001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-11.449999809265,-115.9700012207,47.680000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-11.859999656677,-115.98000335693,47.950000762939),
								},
							{
							Pos	=	Vector(-12.333999633789,-115.99199676514,48.034999847412),
								},
							{
							Pos	=	Vector(-19.048000335693,-115.62200164795,48.001998901367),
								},
							{
							Pos	=	Vector(-30.614999771118,-114.76999664307,47.888000488281),
								},
							{
							Pos	=	Vector(-36.798000335693,-114.13200378418,47.784999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.830001831055,-113.98999786377,47.709999084473),
								},
							},
						},
				UseSprite	=	true,
				RunningColor	=	{
						255,
						10,
						0,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-42.919998168945,106.93000030518,23.709999084473),
				UseSprite	=	true,
				RenderInner_Size	=	2,
				SpecMLine	=	{
					Amount	=	15,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-43.580001831055,100.30000305176,23.909999847412),
								},
							},
						},
				RenderInner	=	true,
				RunningColor	=	{
						255,
						155,
						0,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(43.540000915527,106.73999786377,23.510000228882),
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	15,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(44.200000762939,100.11000061035,23.709999084473),
								},
							},
						},
				RenderInner_Size	=	2,
				RunningColor	=	{
						255,
						155,
						0,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						255,
						60,
						0,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				BlinkersColor	=	{
						255,
						55,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(44.270000457764,-97.589996337891,28.85000038147),
				RenderInner	=	true,
				RenderInner_Size	=	2,
				SpecMLine	=	{
					Amount	=	15,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(43.75,-105.9700012207,29.090000152588),
								},
							},
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						255,
						60,
						0,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				BlinkersColor	=	{
						255,
						55,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-44.650001525879,-97.440002441406,29.059999465942),
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	15,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-44.130001068115,-105.81999969482,29.299999237061),
								},
							},
						},
				RenderInner_Size	=	2,
				RunningColor	=	{
						255,
						55,
						0,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.03,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					Pos4	=	Vector(-25.670000076294,-115.06999969482,45.25),
					AmountH	=	20,
					Pos1	=	Vector(-25.639999389648,-114.7200012207,46.259998321533),
					InnerCenterOnly	=	true,
					AmountV	=	5,
					Pos2	=	Vector(-37.080001831055,-113.80999755859,46.099998474121),
					Use	=	true,
					Mid_Full	=	true,
					Pos3	=	Vector(-37.380001068115,-113.95999908447,45.310001373291),
						},
				DD_Blnk_Run	=	true,
				UseDynamic	=	true,
				RenderHD_Size	=	0.2,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				BlinkersColor	=	{
						255,
						55,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderHD_Adv	=	true,
				Pos	=	Vector(-31.659999847412,-114.19000244141,45.709999084473),
				UseSprite	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				UseBlinkers	=	true,
				RenderInner_Size	=	1,
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.03,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					Pos4	=	Vector(25.409999847412,-115.12000274658,45.069999694824),
					AmountH	=	20,
					Pos1	=	Vector(25.379999160767,-114.76999664307,46.080001831055),
					InnerCenterOnly	=	true,
					AmountV	=	5,
					Pos2	=	Vector(36.819999694824,-113.86000061035,45.919998168945),
					Use	=	true,
					Mid_Full	=	true,
					Pos3	=	Vector(37.119998931885,-114.01000213623,45.130001068115),
						},
				DD_Blnk_Run	=	true,
				UseDynamic	=	true,
				RenderHD_Size	=	0.2,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						255,
						55,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				BlinkersColor	=	{
						255,
						55,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(31.39999961853,-114.23999786377,45.529998779297),
				RenderHD_Adv	=	true,
				RenderInner	=	true,
				UseBrake	=	true,
				RenderInner_Size	=	1,
				UseBlinkers	=	true,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					Use	=	true,
					AmountH	=	8,
					Pos1	=	Vector(5.8699998855591,-60.099998474121,69.5),
					InnerCenterOnly	=	true,
					AmountV	=	7,
					Pos2	=	Vector(-5.6100001335144,-60.099998474121,69.5),
					Pos4	=	Vector(4.8699998855591,-60.099998474121,67.319999694824),
					Mid_Full	=	true,
					Pos3	=	Vector(-4.6100001335144,-60.099998474121,67.319999694824),
						},
				BGroups	=	{
					[12]	=	{
						[0]	=	"tinting_notint",
						[1]	=	"tinting_50percent",
							},
						},
				UseDynamic	=	true,
				RenderHD_Size	=	0.4,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						255,
						60,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(4.8699998855591,-60.099998474121,67.319999694824),
					Pos2	=	Vector(-5.6100001335144,-60.099998474121,69.5),
					Color	=	{
							0,
							0,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(5.8699998855591,-60.099998474121,69.5),
					Pos3	=	Vector(-4.6100001335144,-60.099998474121,67.319999694824),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-3.6199998855591,-60.099998474121,68.410003662109),
				RenderMLCenter	=	true,
				RenderInner	=	true,
				RenderHD_Adv	=	true,
				RenderInner_Size	=	1,
				Beta_Inner3D	=	true,
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
						200,
						225,
						255,
						},
				RenderInner	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(35.950000762939,110.41000366211,38.819999694824),
				UseDynamic	=	true,
				RenderInner_Size	=	2,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(35.549999237061,110.45999908447,38.279998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.169998168945,110.5,37.389999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.099998474121,110.51999664307,36.540000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.240001678467,110.51000213623,35.680000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.610000610352,110.51000213623,34.849998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.150001525879,110.45999908447,34.270000457764),
								},
							{
							Pos	=	Vector(36.791999816895,110.41600036621,33.771999359131),
								},
							{
							Pos	=	Vector(37.540000915527,110.37899780273,33.458000183105),
								},
							{
							Pos	=	Vector(38.345001220703,110.33899688721,33.349998474121),
								},
							{
							Pos	=	Vector(39.151000976562,110.29900360107,33.458000183105),
								},
							{
							Pos	=	Vector(39.898998260498,110.2620010376,33.771999359131),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(40.599998474121,110.23000335693,34.259998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(41.130001068115,110.19000244141,34.889999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(41.520000457764,110.15000152588,35.700000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(41.630001068115,110.16000366211,36.540000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(41.520000457764,110.18000030518,37.389999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(41.319999694824,110.19000244141,38),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(40.970001220703,110.23000335693,38.639999389648),
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
						195,
						195,
						255,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.01,
						},
				SpecSpin	=	{
						},
				RenderMLCenter	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-5.4299998283386,-50.599998474121,11.5),
				RenderInner	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	125,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-3.6500000953674,-46.740001678467,11.5),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-1.9900000095367,-50.659999847412,11.5),
								},
							},
						},
				Beta_Inner3D	=	true,
				RenderInner_Clr	=	{
						195,
						195,
						255,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.01,
						},
				SpecSpin	=	{
						},
				UseSprite	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(5,-50.709999084473,11.5),
				RenderInner_Size	=	1,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	125,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(2.6500000953674,-50.650001525879,11.5),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(2.1500000953674,-50.599998474121,11.5),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(1.8899999856949,-50.430000305176,11.5),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(1.6499999761581,-50.090000152588,11.5),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(1.5599999427795,-49.880001068115,11.5),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(1.4400000572205,-47.919998168945,11.5),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(1.4800000190735,-47.310001373291,11.5),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(1.7599999904633,-46.990001678467,11.5),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(2.210000038147,-46.889999389648,11.5),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(5.0199999809265,-46.869998931885,11.5),
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
						195,
						195,
						255,
						},
				RenderMLCenter	=	true,
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(15,0,0),
				Pos	=	Vector(18.889999389648,11.430000305176,33.930000305176),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(-19.389999389648,-33.049999237061,35.930000305176),
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(17.889999389648,-33.049999237061,35.930000305176),
					},
				},
		Fuel	=	{
			FuelLidPos	=	Vector(-44.849998474121,-74.190002441406,53.229999542236),
			FuelType	=	0,
			Capacity	=	70,
			Override	=	true,
			FuelLidUse	=	true,
				},
		Author	=	"CгεερεгƬv (76561198051637331)",
}