VCModels['models/crsk_autoschevroletcaprice_1993.mdl']	=	{
		em_state	=	5236595037,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Date	=	"Tue Oct 24 20:35:13 2017",
		Exhaust	=	{
				{
				Ang	=	Angle(45,-90,0),
				Pos	=	Vector(35.849998474121,-135.02000427246,9.8699998855591),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Pos	=	Vector(20,9.0200004577637,32.169998168945),
				DoorSounds	=	true,
				Ang	=	Angle(16,0,0),
				EnterRange	=	80,
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(16,0,0),
				Pos	=	Vector(-20,-35.790000915527,33.040000915527),
				EnterRange	=	80,
				DoorSounds	=	true,
					},
				{
				Ang	=	Angle(16,0,0),
				Pos	=	Vector(20,-35.790000915527,33.040000915527),
				EnterRange	=	80,
				DoorSounds	=	true,
					},
				{
				Ang	=	Angle(16,0,0),
				Pos	=	Vector(-1.3200000524521,-35.5,33.319999694824),
				EnterRange	=	80,
				DoorSounds	=	true,
					},
				},
		DLT	=	3491063358,
		Lights	=	{
				{
				UseBlinkers	=	true,
				UseBrake	=	true,
				BlinkersColor	=	{
						255,
						55,
						0,
						},
				SpecMat	=	{
						},
				SpecSpin	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-28.190000534058,-133.92999267578,38.430000305176),
				UseDynamic	=	true,
				Sprite	=	{
					Size	=	0.7,
						},
				Dynamic	=	{
					Brightness	=	2.06,
					Size	=	0.48,
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
					},
				{
				UseBlinkers	=	true,
				UseBrake	=	true,
				BlinkersColor	=	{
						255,
						55,
						0,
						},
				SpecMat	=	{
						},
				SpecSpin	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(28.190000534058,-133.92999267578,38.430000305176),
				UseDynamic	=	true,
				Sprite	=	{
					Size	=	0.7,
						},
				Dynamic	=	{
					Brightness	=	2.06,
					Size	=	0.48,
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
					},
				{
				UseBlinkers	=	true,
				UseBrake	=	true,
				BlinkersColor	=	{
						255,
						55,
						0,
						},
				SpecMat	=	{
						},
				SpecSpin	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-37.779998779297,-131.36999511719,38.369998931885),
				UseDynamic	=	true,
				Sprite	=	{
					Size	=	0.7,
						},
				Dynamic	=	{
					Brightness	=	2.06,
					Size	=	0.48,
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
					},
				{
				UseBlinkers	=	true,
				UseBrake	=	true,
				BlinkersColor	=	{
						255,
						55,
						0,
						},
				SpecMat	=	{
						},
				SpecSpin	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(37.779998779297,-131.36999511719,38.369998931885),
				UseDynamic	=	true,
				Sprite	=	{
					Size	=	0.7,
						},
				Dynamic	=	{
					Brightness	=	2.06,
					Size	=	0.48,
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-23.75,113.2799987793,31.690000534058),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
						218,
						214,
						195,
						},
				Dynamic	=	{
					Brightness	=	4.1418,
					Size	=	0.71,
						},
					},
				{
				Sprite	=	{
					Size	=	0.5,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-33.029998779297,-133.75999450684,35.099998474121),
				UseDynamic	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				Dynamic	=	{
					Brightness	=	1.78,
					Size	=	0.24,
						},
					},
				{
				Sprite	=	{
					Size	=	0.5,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(33.029998779297,-133.75999450684,35.099998474121),
				UseDynamic	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				Dynamic	=	{
					Brightness	=	1.78,
					Size	=	0.24,
						},
					},
				{
				UseBlinkers	=	true,
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						130,
						0,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-39.439998626709,106.41999816895,31.530000686646),
				UseDynamic	=	true,
				Sprite	=	{
					Size	=	0.6,
						},
				Dynamic	=	{
					Brightness	=	1.6791,
					Size	=	0.3358,
						},
					},
				{
				UseBlinkers	=	true,
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						130,
						0,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(39.439998626709,106.41999816895,31.530000686646),
				UseDynamic	=	true,
				Sprite	=	{
					Size	=	0.6,
						},
				Dynamic	=	{
					Brightness	=	1.6791,
					Size	=	0.3358,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	1.6,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				HBeamColor	=	{
						218,
						214,
						195,
						},
				ProjTexture	=	{
					Size	=	2024,
					Angle	=	Angle(0,90,0),
						},
				UsePrjTex	=	true,
				LBeamColor	=	{
						218,
						214,
						195,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				SpecMat	=	{
						},
				Pos	=	Vector(-31.239999771118,111.61000061035,31.959999084473),
				UseSprite	=	true,
				Dynamic	=	{
					Brightness	=	3.4701,
					Size	=	1.3806,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	1.6,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				HBeamColor	=	{
						218,
						214,
						195,
						},
				SpecMat	=	{
						},
				UsePrjTex	=	true,
				LBeamColor	=	{
						218,
						214,
						195,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Pos	=	Vector(31.239999771118,111.61000061035,31.959999084473),
				UseSprite	=	true,
				Dynamic	=	{
					Brightness	=	3.4701,
					Size	=	1.3806,
						},
				ProjTexture	=	{
					Size	=	2024,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(23.75,113.2799987793,31.690000534058),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
						218,
						214,
						195,
						},
				Dynamic	=	{
					Brightness	=	4.1418,
					Size	=	0.709,
						},
					},
				},
		Copyright	=	"Copyright © 2012-2017 VCMod (freemmaann). All Rights Reserved.",
		Fuel	=	{
			FuelType	=	0,
			Capacity	=	95,
			Override	=	true,
				},
		Author	=	"CrushingSkirmish (76561198017348899)",
}