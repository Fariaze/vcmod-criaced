VCModels['models/bsgcarschev_impala96_und.mdl']	=	{
		em_state	=	5236594563,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Siren	=	{
			Sounds	=	{
					{
					Pitch	=	100,
					Volume	=	1,
					Distance	=	95,
					Name	=	"Wail",
					Sound	=	"vcmod/els/cencom/wail.wav",
						},
					{
					Pitch	=	100,
					Volume	=	1,
					Distance	=	95,
					Name	=	"Yelp",
					Sound	=	"vcmod/els/cencom/yelp.wav",
						},
					{
					Pitch	=	100,
					Volume	=	1,
					Distance	=	95,
					Name	=	"Priority",
					Sound	=	"vcmod/els/cencom/priority.wav",
						},
					},
			Codes	=	{
				[6]	=	{
					SSeq_Ovr_SSeq	=	1,
					Spd_Stg_M	=	0.5,
					Spd_Stg	=	true,
					SSeq_Ovr	=	true,
						},
				[7]	=	{
					OvrC	=	6,
						},
				[8]	=	{
					SSeq_Ovr_SSeq	=	1,
					SSeq_Ovr	=	true,
						},
				[13]	=	{
					Include	=	true,
						},
					},
			Sections	=	{
				[1]	=	{
					[1]	=	true,
					[2]	=	true,
					[3]	=	true,
					[4]	=	true,
					[6]	=	true,
					[7]	=	true,
					[8]	=	true,
					[9]	=	true,
						},
				[5]	=	{
					[5]	=	true,
					[10]	=	true,
						},
					},
			Lights	=	{
					{
					Sprite	=	{
						Size	=	0.1,
							},
					Dynamic	=	{
						Size	=	0.5,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(17.120000839233,112.19999694824,31.829999923706),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							0,
							55,
							255,
							},
					SpecLine	=	{
						Amount	=	6,
						Pos	=	Vector(14.970000267029,112.40000152588,31.85000038147),
						Use	=	true,
							},
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.1,
							},
					Dynamic	=	{
						Size	=	0.5,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(14.5,112.5,31.829999923706),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							0,
							55,
							255,
							},
					SpecLine	=	{
						Amount	=	6,
						Pos	=	Vector(12.35000038147,112.69999694824,31.85000038147),
						Use	=	true,
							},
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.1,
							},
					Dynamic	=	{
						Size	=	0.5,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(11.989999771118,112.80000305176,31.829999923706),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							0,
							55,
							255,
							},
					SpecLine	=	{
						Amount	=	6,
						Pos	=	Vector(9.8400001525879,113,31.85000038147),
						Use	=	true,
							},
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.1,
							},
					Dynamic	=	{
						Size	=	0.5,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(9.4499998092651,113.09999847412,31.829999923706),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							0,
							55,
							255,
							},
					SpecLine	=	{
						Amount	=	6,
						Pos	=	Vector(7.3000001907349,113.30000305176,31.85000038147),
						Use	=	true,
							},
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.15,
							},
					Dynamic	=	{
						Size	=	0.55,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(30.370000839233,-93,52.75),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							0,
							55,
							255,
							},
					SpecLine	=	{
						Amount	=	8,
						Pos	=	Vector(26.219999313354,-93,52.770000457764),
						Use	=	true,
							},
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.1,
							},
					Dynamic	=	{
						Size	=	0.5,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-17.120000839233,112.19999694824,31.829999923706),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					SpecLine	=	{
						Amount	=	6,
						Pos	=	Vector(-14.970000267029,112.40000152588,31.85000038147),
						Use	=	true,
							},
					Beta_Inner3D	=	true,
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.1,
							},
					Dynamic	=	{
						Size	=	0.5,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-14.5,112.5,31.829999923706),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					SpecLine	=	{
						Amount	=	6,
						Pos	=	Vector(-12.35000038147,112.69999694824,31.85000038147),
						Use	=	true,
							},
					Beta_Inner3D	=	true,
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.1,
							},
					Dynamic	=	{
						Size	=	0.5,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-11.989999771118,112.80000305176,31.829999923706),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					SpecLine	=	{
						Amount	=	6,
						Pos	=	Vector(-9.8400001525879,113,31.85000038147),
						Use	=	true,
							},
					Beta_Inner3D	=	true,
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.1,
							},
					Dynamic	=	{
						Size	=	0.5,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-9.4499998092651,113.09999847412,31.829999923706),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					SpecLine	=	{
						Amount	=	6,
						Pos	=	Vector(-7.3000001907349,113.30000305176,31.85000038147),
						Use	=	true,
							},
					Beta_Inner3D	=	true,
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.15,
							},
					Dynamic	=	{
						Size	=	0.55,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-30.370000839233,-93,52.75),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					SpecLine	=	{
						Amount	=	8,
						Pos	=	Vector(-26.219999313354,-93,52.770000457764),
						Use	=	true,
							},
					Beta_Inner3D	=	true,
					UseSprite	=	true,
						},
					},
			Sounds_Horn	=	{
				Use	=	true,
				Volume	=	1,
				Distance	=	95,
				Pitch	=	100,
				Sound	=	"vcmod/els/cencom/bullhorn.wav",
					},
			Sequences	=	{
					{
					SubSeq	=	{
							{
							Stages	=	{
									{
									Lights	=	{
											6,
											7,
											8,
											9,
											},
									Time	=	0.3,
										},
									{
									Lights	=	{
											1,
											2,
											3,
											4,
											},
									Time	=	0.3,
										},
									},
							Time	=	5,
							Type	=	"Each side",
								},
							{
							Stages	=	{
									{
									Lights	=	{
											8,
											9,
											1,
											2,
											},
									Time	=	0.2,
										},
									{
									Lights	=	{
											6,
											7,
											3,
											4,
											},
									Time	=	0.2,
										},
									},
							Time	=	5,
							Type	=	"Each half of side",
								},
							{
							Stages	=	{
									{
									Lights	=	{
											6,
											7,
											8,
											9,
											},
									Time	=	0.1,
										},
									{
									Lights	=	{
											1,
											2,
											3,
											4,
											},
									Time	=	0.1,
										},
									},
							Time	=	1,
							Type	=	"Each side",
								},
							},
					Codes	=	{
						[6]	=	true,
						[8]	=	true,
							},
					Lights_Sel	=	{
						[1]	=	true,
						[2]	=	true,
						[3]	=	true,
						[4]	=	true,
						[6]	=	true,
						[7]	=	true,
						[8]	=	true,
						[9]	=	true,
							},
						},
					{
					SubSeq	=	{
							{
							Stages	=	{
									{
									Lights	=	{
											10,
											},
									Time	=	0.2,
										},
									{
									Lights	=	{
											5,
											},
									Time	=	0.2,
										},
									},
							Time	=	5,
							Type	=	"Each side",
								},
							{
							Stages	=	{
									{
									Lights	=	{
											10,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											10,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											5,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											5,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									},
							Time	=	5,
							Type	=	"Each side, flash",
								},
							},
					Codes	=	{
						[6]	=	true,
							},
					Lights_Sel	=	{
						[5]	=	true,
						[10]	=	true,
							},
						},
					},
			Sounds_Manual	=	{
				Use	=	true,
				Volume	=	1,
				Distance	=	95,
				Pitch	=	100,
				Sound	=	"vcmod/els/cencom/wail.wav",
					},
				},
		Date	=	"03/05/15 19:50:51",
		Exhaust	=	{
				{
				Ang	=	Angle(35,-75,0),
				Pos	=	Vector(-32.130001068115,-133.39999389648,14.550000190735),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(35,-90,0),
				Pos	=	Vector(32.130001068115,-133.39999389648,14.550000190735),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(20,-4.9998998641968,34.200000762939),
				RadioControl	=	true,
					},
				{
				Pos	=	Vector(-20,-36.399898529053,34.200000762939),
				Ang	=	Angle(0,0,0),
				Cant_Exit_Lock	=	true,
				switch_rear	=	true,
				Switch_Rear	=	true,
					},
				{
				Pos	=	Vector(20,-36.400001525879,34.200000762939),
				Ang	=	Angle(0,0,0),
				Cant_Exit_Lock	=	true,
				switch_rear	=	true,
				Switch_Rear	=	true,
					},
				},
		DLT	=	3491063042,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				UseBrake	=	true,
				UseDynamic	=	true,
				Pos	=	Vector(-4.0999999046326,-96.940002441406,55),
				UseSprite	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				SpecLine	=	{
					Amount	=	12,
					Use	=	true,
					Pos	=	Vector(4.0999999046326,-96.940002441406,55),
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-39.290000915527,103.43000030518,29.909999847412),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				RenderInner_Size	=	1.2,
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseHead	=	true,
				UsePrjTex	=	true,
				Pos	=	Vector(-32.580001831055,107.15000152588,30.010000228882),
				UseDynamic	=	true,
				HeadColor	=	{
						224,
						210,
						255,
						},
				ProjTexture	=	{
					Forward	=	30,
					Size	=	2000,
					Angle	=	Angle(0,90,0),
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				UseRunning	=	true,
				Pos	=	Vector(-24.229999542236,110.08999633789,30.049999237061),
				RunningColor	=	{
						237.17,
						240,
						244.1,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.12,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseReverse	=	true,
				UseSprite	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				SpecLine	=	{
					Amount	=	4,
					Use	=	true,
					Pos	=	Vector(-35.720001220703,-135.41999816895,37.810001373291),
						},
				Pos	=	Vector(-30.260000228882,-136.94999694824,37.729999542236),
				UseDynamic	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				UseBrake	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-23.639999389648,-137.7200012207,39.930000305176),
				UseDynamic	=	true,
				UseRunning	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				SpecLine	=	{
					Amount	=	4,
					Use	=	true,
					Pos	=	Vector(-35.790000915527,-135.33000183105,39.819999694824),
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				UseBrake	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-43.009998321533,-128.22999572754,39.5),
				UseDynamic	=	true,
				UseRunning	=	true,
				SpecLine	=	{
					Amount	=	3,
					Use	=	true,
					Pos	=	Vector(-39.450000762939,-134.41999816895,39.709999084473),
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-42.889999389648,-130.30999755859,39.580001831055),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				RenderInner_Size	=	1.2,
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(39.290000915527,103.43000030518,29.909999847412),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				RenderInner_Size	=	1.2,
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				ProjTexture	=	{
					Forward	=	30,
					Size	=	2000,
					Angle	=	Angle(0,90,0),
						},
				UseHead	=	true,
				UsePrjTex	=	true,
				Pos	=	Vector(32.580001831055,107.15000152588,30.010000228882),
				UseDynamic	=	true,
				HeadColor	=	{
						224,
						210,
						255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				UseRunning	=	true,
				Pos	=	Vector(24.229999542236,110.08999633789,30.049999237061),
				RunningColor	=	{
						237.17,
						240,
						244.1,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.12,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseReverse	=	true,
				UseSprite	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				SpecLine	=	{
					Amount	=	4,
					Use	=	true,
					Pos	=	Vector(35.720001220703,-135.41999816895,37.810001373291),
						},
				Pos	=	Vector(30.260000228882,-136.94999694824,37.729999542236),
				UseDynamic	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				UseBrake	=	true,
				UseSprite	=	true,
				Pos	=	Vector(23.639999389648,-137.7200012207,39.930000305176),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				SpecLine	=	{
					Amount	=	4,
					Use	=	true,
					Pos	=	Vector(35.790000915527,-135.33000183105,39.819999694824),
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				UseBrake	=	true,
				UseSprite	=	true,
				Pos	=	Vector(43.009998321533,-128.22999572754,39.5),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
				SpecLine	=	{
					Amount	=	3,
					Use	=	true,
					Pos	=	Vector(39.450000762939,-134.41999816895,39.709999084473),
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(42.889999389648,-130.30999755859,39.580001831055),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				RenderInner_Size	=	1.2,
				UseSprite	=	true,
					},
				},
		Copyright	=	"DurkaTeam @ 2025 No rights reserved",
		Author	=	"freemmaann",
}