VCModels['models/crsk_autosmercedes-benzcklasse_w205_2014.mdl']	=	{
		em_state	=	5236594656,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		HealthEnginePosOvr	=	true,
		Date	=	"Wed May 10 15:47:45 2017",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(-26.639999389648,-114.41000366211,17.530000686646),
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(26.139999389648,-114.41000366211,17.530000686646),
				EffectIdle	=	"VC_Exhaust",
					},
				},
		Copyright	=	"Copyright © 2012-2017 VCMod (freemmaann). All Rights Reserved.",
		HealthEnginePos	=	Vector(1.5,77.5,45.5),
		DLT	=	3491063104,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RenderMLCenter	=	true,
				UseRunning	=	true,
				RenderInner_Size	=	1,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(36.970001220703,-101.01999664307,46.680000305176),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(36.580001831055,-102.20999908447,46.610000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36,-103.62999725342,46.470001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.580001831055,-104.55000305176,46.349998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.759998321533,-105.86000061035,46.180000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.639999389648,-107.09999847412,45.900001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.560001373291,-108.16000366211,45.549999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.940000534058,-108.86000061035,45.259998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.520000457764,-109.30000305176,44.919998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.930000305176,-109.94000244141,44.380001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.629999160767,-110.30999755859,43.959999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.35000038147,-110.69000244141,43.450000762939),
								},
							},
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RenderMLCenter	=	true,
				UseRunning	=	true,
				RenderInner_Size	=	1,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(30.25,-110.80000305176,43.419998168945),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(30.959999084473,-110.4700012207,43.409999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.029998779297,-109.86000061035,43.549999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.740001678467,-109.36000061035,43.650001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.840000152588,-108.51999664307,43.840000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.220001220703,-107.16000366211,44.069999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.529998779297,-105.56999969482,44.349998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.049999237061,-104.68000030518,44.509998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.369998931885,-103.83999633789,44.680000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.569999694824,-102.98000335693,44.909999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.819999694824,-101.5,45.279998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(38.080001831055,-99.910003662109,45.439998626709),
								},
							},
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RenderMLCenter	=	true,
				UseRunning	=	true,
				RenderInner	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(38.490001678467,-102.45999908447,43.119998931885),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(38.319999694824,-103.06999969482,43.069999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(38.080001831055,-103.81999969482,42.979999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.560001373291,-105.0299987793,42.849998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.110000610352,-105.94000244141,42.740001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.799999237061,-106.44999694824,42.669998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.549999237061,-106.84999847412,42.610000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.270000457764,-107.18000030518,42.560001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.939998626709,-107.5299987793,42.509998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.299999237061,-108.15000152588,42.400001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.830001831055,-108.56999969482,42.319999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.119998931885,-109.13999938965,42.200000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.479999542236,-109.58000183105,42.090000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.860000610352,-110.58000183105,41.819999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.479999542236,-111.44000244141,41.509998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.879999160767,-111.83999633789,41.330001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.430000305176,-112.15000152588,41.060001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.860000610352,-112.58000183105,40.580001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.379999160767,-112.94000244141,40.069999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.059999465942,-113.19999694824,39.700000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.870000839233,-113.40000152588,39.299999237061),
								},
							},
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(27.770000457764,-113.41999816895,39.299999237061),
				RenderInner	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(28.549999237061,-113.12999725342,39.319999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.620000839233,-112.73000335693,39.419998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.89999961853,-112.12000274658,39.560001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.690000534058,-111.70999908447,39.650001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.139999389648,-110.83999633789,39.840000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.590000152588,-109.83000183105,40.029998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.849998474121,-108.93000030518,40.229999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.650001525879,-108.11000061035,40.430000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.189998626709,-107.44999694824,40.659999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.759998321533,-106.34999847412,41.049999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(38.380001068115,-104.87000274658,41.509998321533),
								},
							},
						},
				RenderMLCenter	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-28.39999961853,-113.41999816895,39.099998474121),
				RenderInner	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-29.180000305176,-113.12999725342,39.119998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.25,-112.73000335693,39.220001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.530000686646,-112.12000274658,39.360000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.319999694824,-111.70999908447,39.450000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.770000457764,-110.83999633789,39.639999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.220001220703,-109.83000183105,39.830001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.479999542236,-108.93000030518,40.029998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.279998779297,-108.11000061035,40.229999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.819999694824,-107.44999694824,40.459999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.389999389648,-106.34999847412,40.849998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-39.009998321533,-104.87000274658,41.310001373291),
								},
							},
						},
				RenderMLCenter	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RenderMLCenter	=	true,
				UseRunning	=	true,
				RenderInner_Size	=	1,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-39.099998474121,-102.45999908447,42.979999542236),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-38.930000305176,-103.06999969482,42.930000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.689998626709,-103.81999969482,42.840000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.169998168945,-105.0299987793,42.709999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.720001220703,-105.94000244141,42.599998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.409999847412,-106.44999694824,42.529998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.159999847412,-106.84999847412,42.470001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.880001068115,-107.18000030518,42.419998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.549999237061,-107.5299987793,42.369998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.909999847412,-108.15000152588,42.259998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.439998626709,-108.56999969482,42.180000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.729999542236,-109.13999938965,42.060001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.090000152588,-109.58000183105,41.950000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.470001220703,-110.58000183105,41.680000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.090000152588,-111.44000244141,41.369998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.489999771118,-111.83999633789,41.189998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.040000915527,-112.15000152588,40.919998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.469999313354,-112.58000183105,40.439998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.989999771118,-112.94000244141,39.930000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.670000076294,-113.19999694824,39.560001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.479999542236,-113.40000152588,39.159999847412),
								},
							},
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				DD_Blnk_Run	=	true,
				UseDynamic	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(39.930000305176,92.389999389648,38.520000457764),
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(39.720001220703,93.139999389648,38.369998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(39.400001525879,94.059997558594,38.159999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(39.069999694824,94.819999694824,37.990001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(38.75,95.519996643066,37.819999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(38.360000610352,96.330001831055,37.610000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.979999542236,97.040000915527,37.419998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.720001220703,97.440002441406,37.310001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.380001068115,97.940002441406,37.169998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.830001831055,99.849998474121,36.520000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.349998474121,100.37999725342,36.330001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.720001220703,101.06999969482,36.060001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.990001678467,101.73000335693,35.799999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.319999694824,102.30000305176,35.540000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.610000610352,102.91999816895,35.229999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.060001373291,103.33999633789,35),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.559999465942,103.76000213623,34.740001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.860000610352,104.2799987793,34.360000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.450000762939,104.58000183105,34.099998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.979999542236,104.91999816895,33.799999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.340000152588,105.36000061035,33.360000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.829999923706,105.7200012207,32.959999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.129999160767,106.16999816895,32.349998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.760000228882,106.41000366211,31.989999771118),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.180000305176,106.76999664307,31.360000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.569999694824,107.11000061035,30.680000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.719999313354,107.44000244141,29.719999313354),
								},
							},
						},
				RenderMLCenter	=	true,
				RunningColor	=	{
						195,
						195,
						255,
						},
				RenderInner	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RenderMLCenter	=	true,
				UseRunning	=	true,
				RenderInner	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-37.599998474121,-101.01999664307,46.5),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-37.209999084473,-102.20999908447,46.430000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.630001068115,-103.62999725342,46.290000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.209999084473,-104.55000305176,46.169998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.389999389648,-105.86000061035,46),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.270000457764,-107.09999847412,45.720001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.189998626709,-108.16000366211,45.369998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.569999694824,-108.86000061035,45.080001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.150001525879,-109.30000305176,44.740001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.559999465942,-109.94000244141,44.200000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.260000228882,-110.30999755859,43.779998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.979999542236,-110.69000244141,43.270000457764),
								},
							},
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-30.89999961853,-110.80000305176,43.299999237061),
				UseSprite	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-31.610000610352,-110.4700012207,43.290000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.680000305176,-109.86000061035,43.430000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.389999389648,-109.36000061035,43.529998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.490001678467,-108.51999664307,43.720001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.869998931885,-107.16000366211,43.950000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.180000305176,-105.56999969482,44.229999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.700000762939,-104.68000030518,44.389999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.020000457764,-103.83999633789,44.560001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.220001220703,-102.98000335693,44.790000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.470001220703,-101.5,45.159999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.729999542236,-99.910003662109,45.319999694824),
								},
							},
						},
				RenderMLCenter	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				RenderInner	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Pos4	=	Vector(29.420000076294,103.20999908447,34.990001678467),
					AmountV	=	2,
					Pos2	=	Vector(27.790000915527,102.11000061035,35.110000610352),
					AmountH	=	2,
					Use	=	true,
					Pos1	=	Vector(29.340000152588,101.41000366211,35.799999237061),
					Pos3	=	Vector(28.030000686646,103.33999633789,34.209999084473),
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				Beta_Inner3D	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(28.290000915527,103.61000061035,34.610000610352),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderMLCenter	=	true,
				RenderInner_Size	=	1,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-27.89999961853,103.61000061035,34.409999847412),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				RenderInner_Size	=	1,
				RenderMLCenter	=	true,
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Pos4	=	Vector(-29.030000686646,103.20999908447,34.790000915527),
					AmountV	=	2,
					Pos2	=	Vector(-27.39999961853,102.11000061035,34.909999847412),
					AmountH	=	2,
					Use	=	true,
					Pos1	=	Vector(-28.950000762939,101.41000366211,35.599998474121),
					Pos3	=	Vector(-27.639999389648,103.33999633789,34.009998321533),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(30.409999847412,101.48999786377,35.369998931885),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				RenderInner_Size	=	1,
				UseBlinkers	=	true,
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Pos4	=	Vector(31.540000915527,101.08999633789,35.75),
					AmountV	=	2,
					Pos2	=	Vector(29.909999847412,99.98999786377,35.869998931885),
					AmountH	=	2,
					Use	=	true,
					Pos1	=	Vector(31.459999084473,99.290000915527,36.560001373291),
					Pos3	=	Vector(30.14999961853,101.2200012207,34.970001220703),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-30.10000038147,101.48999786377,35.169998168945),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Pos4	=	Vector(-31.229999542236,101.08999633789,35.549999237061),
					AmountV	=	2,
					Pos2	=	Vector(-29.60000038147,99.98999786377,35.669998168945),
					AmountH	=	2,
					Use	=	true,
					Pos1	=	Vector(-31.14999961853,99.290000915527,36.360000610352),
					Pos3	=	Vector(-29.840000152588,101.2200012207,34.770000457764),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(32.409999847412,99.699996948242,36.150001525879),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Pos4	=	Vector(33.540000915527,99.300003051758,36.529998779297),
					AmountV	=	2,
					Pos2	=	Vector(31.909999847412,98.199996948242,36.650001525879),
					AmountH	=	2,
					Use	=	true,
					Pos1	=	Vector(33.459999084473,97.5,37.340000152588),
					Pos3	=	Vector(32.150001525879,99.430000305176,35.75),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Pos4	=	Vector(35.380001068115,97.900001525879,37.340000152588),
					AmountV	=	2,
					Pos2	=	Vector(33.75,96.800003051758,37.459999084473),
					AmountH	=	2,
					Use	=	true,
					Pos1	=	Vector(35.299999237061,96.099998474121,38.150001525879),
					Pos3	=	Vector(33.990001678467,98.029998779297,36.560001373291),
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(34.25,98.300003051758,36.959999084473),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RenderMLCenter	=	true,
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Pos4	=	Vector(-33.040000915527,99.300003051758,36.330001831055),
					AmountV	=	2,
					Pos2	=	Vector(-31.409999847412,98.199996948242,36.450000762939),
					AmountH	=	2,
					Use	=	true,
					Pos1	=	Vector(-32.959999084473,97.5,37.139999389648),
					Pos3	=	Vector(-31.64999961853,99.430000305176,35.549999237061),
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				RenderInner_Size	=	1,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-31.909999847412,99.699996948242,35.950000762939),
				UseDynamic	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Pos4	=	Vector(-34.979999542236,97.900001525879,37.139999389648),
					AmountV	=	2,
					Pos2	=	Vector(-33.349998474121,96.800003051758,37.259998321533),
					AmountH	=	2,
					Use	=	true,
					Pos1	=	Vector(-34.900001525879,96.099998474121,37.950000762939),
					Pos3	=	Vector(-33.590000152588,98.029998779297,36.360000610352),
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				Beta_Inner3D	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-33.849998474121,98.300003051758,36.759998321533),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				RenderInner	=	true,
				UseBlinkers	=	true,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Pos4	=	Vector(37.009998321533,95.900001525879,38.020000457764),
					AmountV	=	2,
					Pos2	=	Vector(35.380001068115,94.800003051758,38.139999389648),
					AmountH	=	2,
					Use	=	true,
					Pos1	=	Vector(36.930000305176,94.099998474121,38.830001831055),
					Pos3	=	Vector(35.619998931885,96.029998779297,37.240001678467),
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(35.880001068115,96.300003051758,37.639999389648),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				RenderInner_Size	=	1,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Pos4	=	Vector(38.360000610352,94.349998474121,38.389999389648),
					AmountV	=	2,
					Pos2	=	Vector(36.729999542236,93.25,38.509998321533),
					AmountH	=	2,
					Use	=	true,
					Pos1	=	Vector(38.279998779297,92.550003051758,39.200000762939),
					Pos3	=	Vector(36.970001220703,94.480003356934,37.610000610352),
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				UseSprite	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(37.229999542236,94.75,38.009998321533),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Pos4	=	Vector(-36.680000305176,95.900001525879,37.819999694824),
					AmountV	=	2,
					Pos2	=	Vector(-35.049999237061,94.800003051758,37.939998626709),
					AmountH	=	2,
					Use	=	true,
					Pos1	=	Vector(-36.599998474121,94.099998474121,38.630001068115),
					Pos3	=	Vector(-35.290000915527,96.029998779297,37.040000915527),
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-35.549999237061,96.300003051758,37.439998626709),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				RenderInner_Size	=	1,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Pos4	=	Vector(-38.029998779297,94.349998474121,38.189998626709),
					AmountV	=	2,
					Pos2	=	Vector(-36.400001525879,93.25,38.310001373291),
					AmountH	=	2,
					Use	=	true,
					Pos1	=	Vector(-37.950000762939,92.550003051758,39),
					Pos3	=	Vector(-36.639999389648,94.480003356934,37.409999847412),
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				Beta_Inner3D	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-36.900001525879,94.75,37.810001373291),
				UseDynamic	=	true,
				RenderInner	=	true,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				RenderInner_Size	=	1,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.07,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RenderMLCenter	=	true,
				UseRunning	=	true,
				RenderInner	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(39.930000305176,92.389999389648,38.520000457764),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(39.720001220703,93.139999389648,38.369998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(39.400001525879,94.059997558594,38.159999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(39.069999694824,94.819999694824,37.990001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(38.75,95.519996643066,37.819999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(38.360000610352,96.330001831055,37.610000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.979999542236,97.040000915527,37.419998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.720001220703,97.440002441406,37.310001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.380001068115,97.940002441406,37.169998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.830001831055,99.849998474121,36.520000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.349998474121,100.37999725342,36.330001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.720001220703,101.06999969482,36.060001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.990001678467,101.73000335693,35.799999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.319999694824,102.30000305176,35.540000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.610000610352,102.91999816895,35.229999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.060001373291,103.33999633789,35),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.559999465942,103.76000213623,34.740001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.860000610352,104.2799987793,34.360000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.450000762939,104.58000183105,34.099998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.979999542236,104.91999816895,33.799999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.340000152588,105.36000061035,33.360000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.829999923706,105.7200012207,32.959999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.129999160767,106.16999816895,32.349998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.760000228882,106.41000366211,31.989999771118),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.180000305176,106.76999664307,31.360000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.569999694824,107.11000061035,30.680000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.719999313354,107.44000244141,29.719999313354),
								},
							},
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
						195,
						195,
						255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.07,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RenderMLCenter	=	true,
				UseRunning	=	true,
				RenderInner	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-39.459999084473,92.5,38.319999694824),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-39.25,93.25,38.169998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.930000305176,94.169998168945,37.959999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.599998474121,94.930000305176,37.790000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.279998779297,95.629997253418,37.619998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.889999389648,96.440002441406,37.409999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.509998321533,97.150001525879,37.220001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.25,97.550003051758,37.110000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.909999847412,98.050003051758,36.970001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.360000610352,99.959999084473,36.319999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.880001068115,100.48999786377,36.130001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.25,101.18000030518,35.860000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.520000457764,101.83999633789,35.599998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.849998474121,102.41000366211,35.340000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.139999389648,103.0299987793,35.029998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.590000152588,103.44999694824,34.799999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.090000152588,103.87000274658,34.540000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.389999389648,104.38999938965,34.159999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.979999542236,104.69000244141,33.900001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.510000228882,105.0299987793,33.599998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.870000839233,105.4700012207,33.159999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.360000610352,105.83000183105,32.759998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.659999847412,106.2799987793,32.150001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.290000915527,106.51999664307,31.790000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.709999084473,106.87999725342,31.159999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.10000038147,107.2200012207,30.479999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.25,107.55000305176,29.520000457764),
								},
							},
						},
				UseSprite	=	true,
				RunningColor	=	{
						195,
						195,
						255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
						195,
						195,
						255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(38.340000152588,98.5,31.709999084473),
					Pos2	=	Vector(34.849998474121,98.680000305176,35.110000610352),
					Use	=	true,
					Pos1	=	Vector(38.450000762939,98.580001831055,35.319999694824),
					Pos3	=	Vector(34.529998779297,98.5,31.579999923706),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(36.560001373291,98.620002746582,33.389999389648),
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				RenderInner_Size	=	1,
				HBeamColor	=	{
						195,
						195,
						255,
						},
				RenderMLCenter	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
						195,
						195,
						255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-37.939998626709,98.650001525879,31.559999465942),
					Pos2	=	Vector(-34.450000762939,98.830001831055,34.959999084473),
					Use	=	true,
					Pos1	=	Vector(-38.049999237061,98.730003356934,35.169998168945),
					Pos3	=	Vector(-34.130001068115,98.650001525879,31.430000305176),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-36.159999847412,98.769996643066,33.240001678467),
				RenderMLCenter	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				RenderInner_Size	=	1,
				HBeamColor	=	{
						195,
						195,
						255,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.7,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UsePrjTex	=	true,
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(32.979999542236,103.19999694824,30.450000762939),
					Pos2	=	Vector(29.60000038147,103.33000183105,33.130001068115),
					Use	=	true,
					Pos1	=	Vector(33.020000457764,103,33.740001678467),
					Pos3	=	Vector(29.069999694824,103.18000030518,29.280000686646),
						},
				FogColor	=	{
						195,
						195,
						255,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(31.340000152588,103.30000305176,31.680000305176),
				UseSprite	=	true,
				RenderInner	=	true,
				UseFog	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				RenderInner_Size	=	1,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.7,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UsePrjTex	=	true,
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-32.740001678467,103.34999847412,30.35000038147),
					Pos2	=	Vector(-29.360000610352,103.48000335693,33.029998779297),
					Use	=	true,
					Pos1	=	Vector(-32.779998779297,103.15000152588,33.639999389648),
					Pos3	=	Vector(-28.829999923706,103.33000183105,29.180000305176),
						},
				FogColor	=	{
						195,
						195,
						255,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-31.10000038147,103.44999694824,31.579999923706),
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				RenderInner_Size	=	1,
				UseFog	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.13,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RenderMLCenter	=	true,
				FogColor	=	{
						255,
						55,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(29.290000915527,-113.55000305176,36.930000305176),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	4,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(31.200000762939,-112.62999725342,37.049999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.860000610352,-111.83000183105,37.25),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.470001220703,-110.83000183105,37.529998779297),
								},
							},
						},
				UseFog	=	true,
				RenderInner_Clr	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.13,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				FogColor	=	{
						255,
						55,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner_Size	=	1,
				UseSprite	=	true,
				Pos	=	Vector(-30.10000038147,-113.55000305176,36.799999237061),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	4,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-32.009998321533,-112.62999725342,36.919998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.669998168945,-111.83000183105,37.119998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.279998779297,-110.83000183105,37.400001525879),
								},
							},
						},
				UseFog	=	true,
				RenderInner_Clr	=	{
						255,
						55,
						0,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Beta_Inner3D	=	true,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner_Size	=	1,
				UseSprite	=	true,
				Pos	=	Vector(37.340000152588,-107.58000183105,39.099998474121),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(36.139999389648,-108.76999664307,38.930000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.950000762939,-109.68000030518,38.75),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33,-110.98000335693,38.5),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.969999313354,-112.08999633789,38.240001678467),
								},
							},
						},
				RenderMLCenter	=	true,
				RenderInner_Clr	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Beta_Inner3D	=	true,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner_Size	=	1,
				UseSprite	=	true,
				Pos	=	Vector(-38.299999237061,-107.58000183105,38.990001678467),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-37.099998474121,-108.76999664307,38.819999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.909999847412,-109.68000030518,38.639999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.959999084473,-110.98000335693,38.389999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.930000305176,-112.08999633789,38.130001068115),
								},
							},
						},
				UseBlinkers	=	true,
				RenderInner_Clr	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(30.129999160767,-112.48000335693,37.400001525879),
					Pos2	=	Vector(28.319999694824,-112.19999694824,38.669998168945),
					Use	=	true,
					Pos1	=	Vector(30.129999160767,-111.59999847412,38.700000762939),
					Pos3	=	Vector(28.35000038147,-113.25,37.240001678467),
						},
				RenderInner	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(29.479999542236,-111.98000335693,38.049999237061),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				RenderMLCenter	=	true,
				RenderInner_Clr	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-30.950000762939,-112.48000335693,37.400001525879),
					Pos2	=	Vector(-29.139999389648,-112.19999694824,38.669998168945),
					Use	=	true,
					Pos1	=	Vector(-30.950000762939,-111.59999847412,38.700000762939),
					Pos3	=	Vector(-29.170000076294,-113.25,37.240001678467),
						},
				RenderInner_Size	=	1,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-30.299999237061,-111.98000335693,38.049999237061),
				UseDynamic	=	true,
				RenderInner	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				UseSprite	=	true,
				RenderInner_Clr	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(28.180000305176,-113.30000305176,37.270000457764),
					Pos2	=	Vector(25.879999160767,-113,38.569999694824),
					Use	=	true,
					Pos1	=	Vector(28.180000305176,-112.5,38.569999694824),
					Pos3	=	Vector(24.379999160767,-115.5,37.270000457764),
						},
				RenderInner	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(27.030000686646,-113,37.919998168945),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				RenderMLCenter	=	true,
				RenderInner_Clr	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-28.85000038147,-113.30000305176,37.270000457764),
					Pos2	=	Vector(-26.549999237061,-113,38.569999694824),
					Use	=	true,
					Pos1	=	Vector(-28.85000038147,-112.5,38.569999694824),
					Pos3	=	Vector(-25.049999237061,-115.5,37.270000457764),
						},
				RenderInner_Size	=	1,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-27.700000762939,-113,37.919998168945),
				UseDynamic	=	true,
				RenderInner	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				UseSprite	=	true,
				RenderInner_Clr	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RenderMLCenter	=	true,
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBrake	=	true,
				UseSprite	=	true,
				Pos	=	Vector(29.959999084473,-111.94999694824,40.319999694824),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(31.909999847412,-110.7799987793,40.759998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.639999389648,-109.55999755859,41.060001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.319999694824,-108.09999847412,41.319999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.740001678467,-106.7200012207,41.619998931885),
								},
							},
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						255,
						100,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseBrake	=	true,
				UseSprite	=	true,
				RenderInner_Size	=	1,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-30.60000038147,-111.94999694824,40.119998931885),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-32.549999237061,-110.7799987793,40.560001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.279998779297,-109.55999755859,40.860000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.959999084473,-108.09999847412,41.119998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.380001068115,-106.7200012207,41.419998168945),
								},
							},
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						255,
						100,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseBrake	=	true,
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				UseSprite	=	true,
				Pos	=	Vector(31.89999961853,-108.84999847412,44.319999694824),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	15,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(33.819999694824,-107.13999938965,44.869998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.479999542236,-105.30000305176,45.270000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.75,-103.34999847412,45.630001068115),
								},
							},
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						255,
						100,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RenderMLCenter	=	true,
				UseSprite	=	true,
				RenderInner_Size	=	1,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBrake	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-32.599998474121,-108.84999847412,44.119998931885),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	15,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-34.520000457764,-107.13999938965,44.669998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.180000305176,-105.30000305176,45.069999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.450000762939,-103.34999847412,45.430000305176),
								},
							},
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						255,
						100,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseBrake	=	true,
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner_Size	=	1,
				UseSprite	=	true,
				Pos	=	Vector(-13.260000228882,-90.019996643066,55.869998931885),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-7.1199998855591,-90.889999389648,55.900001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-0.93000000715256,-91.23999786377,55.990001678467),
								},
							},
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				UseSprite	=	true,
				Pos	=	Vector(12.760000228882,-90.019996643066,55.869998931885),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(6.6199998855591,-90.889999389648,55.900001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(0.43000000715256,-91.23999786377,55.990001678467),
								},
							},
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner	=	true,
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(49.950000762939,21.10000038147,52.270000457764),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(49.569999694824,23.360000610352,52.080001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(48.650001525879,25.420000076294,51.889999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(47.479999542236,26.690000534058,51.740001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(45.159999847412,28.60000038147,51.540000915527),
								},
							},
						},
				RenderInner_Size	=	1,
				Beta_Inner3D	=	true,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Beta_Inner3D	=	true,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-50.099998474121,21.10000038147,52.069999694824),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-49.720001220703,23.360000610352,51.880001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-48.799999237061,25.420000076294,51.689998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-47.630001068115,26.690000534058,51.540000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-45.310001373291,28.60000038147,51.340000152588),
								},
							},
						},
				UseBlinkers	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				DD_Blnk_Run	=	true,
				UseDynamic	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-39.459999084473,92.5,38.319999694824),
				RenderMLCenter	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-39.25,93.25,38.169998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.930000305176,94.169998168945,37.959999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.599998474121,94.930000305176,37.790000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.279998779297,95.629997253418,37.619998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.889999389648,96.440002441406,37.409999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.509998321533,97.150001525879,37.220001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.25,97.550003051758,37.110000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.909999847412,98.050003051758,36.970001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.360000610352,99.959999084473,36.319999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.880001068115,100.48999786377,36.130001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.25,101.18000030518,35.860000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.520000457764,101.83999633789,35.599998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.849998474121,102.41000366211,35.340000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.139999389648,103.0299987793,35.029998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.590000152588,103.44999694824,34.799999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.090000152588,103.87000274658,34.540000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.389999389648,104.38999938965,34.159999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.979999542236,104.69000244141,33.900001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.510000228882,105.0299987793,33.599998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.870000839233,105.4700012207,33.159999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.360000610352,105.83000183105,32.759998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.659999847412,106.2799987793,32.150001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.290000915527,106.51999664307,31.790000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.709999084473,106.87999725342,31.159999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.10000038147,107.2200012207,30.479999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.25,107.55000305176,29.520000457764),
								},
							},
						},
				RenderInner_Size	=	1,
				RunningColor	=	{
						195,
						195,
						255,
						},
				UseSprite	=	true,
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(18.319999694824,4.5199999809265,32.409999847412),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(-22.819999694824,-37.139999389648,33.909999847412),
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(19.819999694824,-37.139999389648,33.909999847412),
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(-1.6799999475479,-37.139999389648,33.909999847412),
					},
				},
		Fuel	=	{
			FuelLidPos	=	Vector(41.639999389648,-78.639999389648,45.770000457764),
			FuelType	=	0,
			Capacity	=	66,
			Override	=	true,
			FuelLidUse	=	true,
				},
		Author	=	"𝒞𝓇𝑒𝑒𝓅𝑒𝓇 (76561198051637331)",
}