VCModels['models/azok30opel_vivaro.mdl']	=	{
		em_state	=	5236594647,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Date	=	"Tue Nov 27 19:46:55 2018",
		Exhaust	=	{
				{
				Ang	=	Angle(15,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(25.200000762939,-113.98000335693,2.9700000286102),
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Pos	=	Vector(5,11.5,37),
					},
				{
				Pos	=	Vector(26,11.5,37),
					},
				},
		DLT	=	3491063098,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					Use	=	true,
					AmountV	=	13,
					Pos2	=	Vector(38.220001220703,-112.16999816895,58.020000457764),
					AmountH	=	2,
					Pos4	=	Vector(37.840000152588,-113.12999725342,47.580001831055),
					Pos1	=	Vector(37.840000152588,-112.16999816895,58.020000457764),
					Pos3	=	Vector(38.220001220703,-113.12999725342,47.580001831055),
						},
				SpecMat	=	{
						},
				UseBrake	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(38.029998779297,-112.65000152588,56.549999237061),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-35.580001831055,-113.95999908447,44.529998779297),
				UseDynamic	=	true,
				RenderInner_Size	=	4,
				RenderInner	=	true,
				UseBlinkers	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(38.310001373291,-114.58999633789,43.860000610352),
				UseDynamic	=	true,
				RenderInner_Size	=	4,
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					Use	=	true,
					AmountV	=	13,
					Pos2	=	Vector(-36.720001220703,-112.16999816895,58.020000457764),
					AmountH	=	2,
					Pos4	=	Vector(-36.340000152588,-113.12999725342,47.580001831055),
					Pos1	=	Vector(-36.340000152588,-112.16999816895,58.020000457764),
					Pos3	=	Vector(-36.720001220703,-113.12999725342,47.580001831055),
						},
				SpecMat	=	{
						},
				UseBrake	=	true,
				RenderInner_Size	=	1,
				UseSprite	=	true,
				Pos	=	Vector(-36.529998779297,-112.65000152588,56.549999237061),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					Use	=	true,
					AmountV	=	13,
					Pos2	=	Vector(-36.720001220703,-112.16999816895,58.020000457764),
					AmountH	=	2,
					Pos4	=	Vector(-36.340000152588,-113.12999725342,47.580001831055),
					Pos1	=	Vector(-36.340000152588,-112.16999816895,58.020000457764),
					Pos3	=	Vector(-36.720001220703,-113.12999725342,47.580001831055),
						},
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderInner_Size	=	1,
				UseSprite	=	true,
				Pos	=	Vector(-36.529998779297,-112.65000152588,56.549999237061),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBrake	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-36.25,-114.61000061035,41.869998931885),
				UseDynamic	=	true,
				RenderInner_Size	=	4,
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(38.209999084473,-113.34999847412,41.720001220703),
				UseDynamic	=	true,
				RenderInner_Size	=	4,
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				RenderInner	=	true,
				RenderType	=	2,
				SpecMat	=	{
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	19,
						},
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-35.75,-114.88999938965,38.599998474121),
				UseDynamic	=	true,
				RenderInner_Size	=	1.1207,
				SpecMLine	=	{
					Amount	=	36,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-37.029998779297,-112.73000335693,39.279998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-37.340000152588,-111.66999816895,41.790000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-37.430000305176,-111.19999694824,46.540000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-37.060001373291,-110.80999755859,52.880001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-36.200000762939,-110.93000030518,56.740001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-35.490001678467,-112.66000366211,57.099998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-35.340000152588,-112.87000274658,48.369998931885),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					Use	=	true,
					AmountV	=	13,
					Pos2	=	Vector(-38.220001220703,-112.16999816895,58.020000457764),
					AmountH	=	2,
					Pos4	=	Vector(-37.840000152588,-113.12999725342,47.580001831055),
					Pos1	=	Vector(-37.840000152588,-112.16999816895,58.020000457764),
					Pos3	=	Vector(-38.220001220703,-113.12999725342,47.580001831055),
						},
				SpecMat	=	{
						},
				UseBrake	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-38.029998779297,-112.65000152588,56.549999237061),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(35.580001831055,-113.95999908447,44.529998779297),
				UseDynamic	=	true,
				RenderInner_Size	=	4,
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-38.310001373291,-114.58999633789,43.860000610352),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderInner_Size	=	4,
				UseBlinkers	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					Use	=	true,
					AmountV	=	13,
					Pos2	=	Vector(36.720001220703,-112.16999816895,58.020000457764),
					AmountH	=	2,
					Pos4	=	Vector(36.340000152588,-113.12999725342,47.580001831055),
					Pos1	=	Vector(36.340000152588,-112.16999816895,58.020000457764),
					Pos3	=	Vector(36.720001220703,-113.12999725342,47.580001831055),
						},
				SpecMat	=	{
						},
				UseBrake	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(36.529998779297,-112.65000152588,56.549999237061),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(36.25,-114.61000061035,41.869998931885),
				UseDynamic	=	true,
				RenderInner	=	true,
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner_Size	=	4,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-38.209999084473,-113.34999847412,41.720001220703),
				UseDynamic	=	true,
				RenderInner_Size	=	4,
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				RenderInner_Size	=	1.1207,
				RenderType	=	2,
				SpecMat	=	{
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	19,
						},
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(35.75,-114.88999938965,38.599998474121),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	36,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(37.029998779297,-112.73000335693,39.279998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(37.340000152588,-111.66999816895,41.790000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(37.430000305176,-111.19999694824,46.540000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(37.060001373291,-110.80999755859,52.880001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(36.200000762939,-110.93000030518,56.740001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(35.490001678467,-112.66000366211,57.099998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(35.340000152588,-112.87000274658,48.369998931885),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(-28.959999084473,71.930000305176,34.770000457764),
					Pos2	=	Vector(-30.959999084473,71.930000305176,36.770000457764),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-28.959999084473,71.930000305176,36.770000457764),
					Pos3	=	Vector(-30.959999084473,71.930000305176,34.770000457764),
						},
				RenderType	=	2,
				SpecMat	=	{
						},
				UsePrjTex	=	true,
				Pos	=	Vector(-29.959999084473,71.930000305176,35.770000457764),
				UseDynamic	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseRunning	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(28.959999084473,71.930000305176,34.770000457764),
					Pos2	=	Vector(30.959999084473,71.930000305176,36.770000457764),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(28.959999084473,71.930000305176,36.770000457764),
					Pos3	=	Vector(30.959999084473,71.930000305176,34.770000457764),
						},
				RenderType	=	2,
				SpecMat	=	{
						},
				UsePrjTex	=	true,
				Pos	=	Vector(29.959999084473,71.930000305176,35.770000457764),
				UseDynamic	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseRunning	=	true,
				UseSprite	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(-23.629999160767,79.040000915527,31.670000076294),
					Pos2	=	Vector(-25.629999160767,79.040000915527,33.669998168945),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-23.629999160767,79.040000915527,33.669998168945),
					Pos3	=	Vector(-25.629999160767,79.040000915527,31.670000076294),
						},
				RenderType	=	2,
				HBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseSprite	=	true,
				Pos	=	Vector(-24.629999160767,79.040000915527,32.669998168945),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				SpecMat	=	{
						},
				UsePrjTex	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(23.629999160767,79.040000915527,31.670000076294),
					Pos2	=	Vector(25.629999160767,79.040000915527,33.669998168945),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(23.629999160767,79.040000915527,33.669998168945),
					Pos3	=	Vector(25.629999160767,79.040000915527,31.670000076294),
						},
				RenderType	=	2,
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(24.629999160767,79.040000915527,32.669998168945),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UsePrjTex	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				HBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(-28.420000076294,84.610000610352,7.1799998283386),
					Pos2	=	Vector(-30.420000076294,84.610000610352,9.1800003051758),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-28.420000076294,84.610000610352,9.1800003051758),
					Pos3	=	Vector(-30.420000076294,84.610000610352,7.1799998283386),
						},
				RenderType	=	2,
				SpecMat	=	{
						},
				UsePrjTex	=	true,
				Pos	=	Vector(-29.420000076294,84.610000610352,8.1800003051758),
				UseDynamic	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseFog	=	true,
				FogColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseSprite	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(28.420000076294,84.610000610352,7.1799998283386),
					Pos2	=	Vector(30.420000076294,84.610000610352,9.1800003051758),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(28.420000076294,84.610000610352,9.1800003051758),
					Pos3	=	Vector(30.420000076294,84.610000610352,7.1799998283386),
						},
				RenderType	=	2,
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(29.420000076294,84.610000610352,8.1800003051758),
				UseDynamic	=	true,
				FogColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseFog	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UsePrjTex	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RenderType	=	2,
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-23.729999542236,83.550003051758,28.260000228882),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RenderType	=	2,
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(23.729999542236,83.550003051758,28.260000228882),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				},
		Copyright	=	"Copyright © 2012-2018 VCMod (freemmaann). All Rights Reserved.",
		Fuel	=	{
			FuelType	=	0,
				},
		Author	=	"Azok30 (76561198183398967)",
}