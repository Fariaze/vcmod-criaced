VCModels['models/crsk_autostoyotachaservtourerx100_1998.mdl']	=	{
		em_state	=	5236594461,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		HealthEnginePosOvr	=	true,
		Date	=	"Mon Sep 11 15:36:41 2017",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(25.440000534058,-146.05000305176,9.1899995803833),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		Copyright	=	"Copyright © 2012-2017 VCMod (freemmaann). All Rights Reserved.",
		HealthEnginePos	=	Vector(0,58.5,21.5),
		DLT	=	3491062974,
		Lights	=	{
				{
				UseBlinkers	=	true,
				SpecSpin	=	{
						},
				Beta_Inner3D	=	true,
				BlinkersColor	=	{
						255,
						150,
						0,
						},
				RenderInner	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.06,
						},
				UseSprite	=	true,
				Pos	=	Vector(-39.650001525879,-136.41999816895,39.409999847412),
				UseDynamic	=	true,
				RenderInner_Size	=	4,
				SpecMLine	=	{
					Amount	=	48,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-37.639999389648,-139.75999450684,39.610000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.959999084473,-141.07000732422,39.619998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.200000762939,-141.38000488281,39.669998168945),
								},
							},
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.5,
						},
				RenderInner_Clr	=	{
						255,
						150,
						0,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.5,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.6,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-31.219999313354,-137.9700012207,30.940000534058),
					UseColor	=	true,
					Pos2	=	Vector(-40.779998779297,-137.9700012207,40),
					Color	=	{
							255,
							55,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(-31.219999313354,-137.9700012207,40),
					Pos3	=	Vector(-40.779998779297,-137.9700012207,30.940000534058),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-36.040000915527,-137.47999572754,35.430000305176),
				RenderInner_Size	=	1,
				UseSprite	=	true,
				RenderInner	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.5,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(30.719999313354,-138.16000366211,30.780000686646),
					UseColor	=	true,
					Pos2	=	Vector(40.279998779297,-138.16000366211,39.840000152588),
					Color	=	{
							255,
							55,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(30.719999313354,-138.16000366211,39.840000152588),
					Pos3	=	Vector(40.279998779297,-138.16000366211,30.780000686646),
						},
				UseBrake	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseRunning	=	true,
				UseSprite	=	true,
				Pos	=	Vector(35.540000915527,-138.16999816895,35.270000457764),
				UseDynamic	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.6,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.5,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-24.510000228882,-140.38000488281,30.979999542236),
					UseColor	=	true,
					Pos2	=	Vector(-34.069999694824,-140.38000488281,40.040000915527),
					Color	=	{
							255,
							55,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(-24.510000228882,-140.38000488281,40.040000915527),
					Pos3	=	Vector(-34.069999694824,-140.38000488281,30.979999542236),
						},
				UseBrake	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseRunning	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-29.299999237061,-140.38999938965,35.520000457764),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.6,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.5,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.6,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(24.049999237061,-140.50999450684,30.709999084473),
					UseColor	=	true,
					Pos2	=	Vector(33.610000610352,-140.50999450684,39.770000457764),
					Color	=	{
							255,
							55,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(24.049999237061,-140.50999450684,39.770000457764),
					Pos3	=	Vector(33.610000610352,-140.50999450684,30.709999084473),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(28.840000152588,-140.52000427246,35.25),
				RenderInner	=	true,
				UseBrake	=	true,
				RenderInner_Size	=	1,
				RunningColor	=	{
						255,
						55,
						0,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.07,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				UseSprite	=	true,
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				SpecMLine	=	{
					Amount	=	48,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-25.780000686646,-142.22999572754,39.650001525879),
								},
							},
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-30.520000457764,-141.55999755859,39.659999847412),
				UseDynamic	=	true,
				RenderInner	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				RenderInner_Size	=	2,
				RenderInner_Clr	=	{
						255,
						150,
						0,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.5,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.07,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				Beta_Inner3D	=	true,
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				SpecMLine	=	{
					Amount	=	48,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(25.299999237061,-142.2200012207,39.509998321533),
								},
							},
						},
				UseSprite	=	true,
				Pos	=	Vector(30.040000915527,-141.55000305176,39.520000457764),
				UseDynamic	=	true,
				RenderInner_Size	=	2,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
						255,
						150,
						0,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.5,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.07,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(6.7600002288818,-109.12999725342,49.529998779297),
					UseColor	=	true,
					Pos2	=	Vector(-5.7399997711182,-107.08999633789,51.529998779297),
					Color	=	{
							255,
							55,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(5.2600002288818,-107.08999633789,51.529998779297),
					Pos3	=	Vector(-6.7399997711182,-109.19999694824,49.529998779297),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-5.2399997711182,-108.58999633789,50.529998779297),
				UseDynamic	=	true,
				UseBrake	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.5,
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				UseSprite	=	true,
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Pos4	=	Vector(6.7600002288818,-109.12999725342,49.529998779297),
					AmountV	=	2,
					Pos2	=	Vector(-5.7399997711182,-107.08999633789,51.529998779297),
					AmountH	=	16,
					Use	=	true,
					Pos1	=	Vector(5.2600002288818,-107.08999633789,51.529998779297),
					Pos3	=	Vector(-6.7399997711182,-109.19999694824,49.529998779297),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	1.1,
						},
				SpecSpin	=	{
						},
				UsePrjTex	=	true,
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
						255,
						150,
						0,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.5,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/2x4sgm_tex",
					Pos4	=	Vector(27.5,89,25.510000228882),
					UseColor	=	true,
					Pos2	=	Vector(20.059999465942,89,31.950000762939),
					Color	=	{
							247,
							211,
							221,
							},
					Use	=	true,
					Pos1	=	Vector(28,89,32.450000762939),
					Pos3	=	Vector(20.559999465942,89,25.510000228882),
						},
				HBeamColor	=	{
						247,
						211,
						221,
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(23.950000762939,89.019996643066,28.889999389648),
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				RenderInner_Size	=	2,
				SpecMat	=	{
						},
				RenderMLCenter	=	true,
				UseSprite	=	true,
				RenderInner	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.9,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
						247,
						211,
						221,
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						255,
						150,
						0,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.5,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/2x4sgm_tex",
					Pos4	=	Vector(36,86.529998779297,25.510000228882),
					UseColor	=	true,
					Pos2	=	Vector(28.559999465942,86.529998779297,32.450000762939),
					Color	=	{
							247,
							211,
							221,
							},
					Use	=	true,
					Pos1	=	Vector(36.5,86.529998779297,32.450000762939),
					Pos3	=	Vector(29.25,86.529998779297,25.579999923706),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(32.790000915527,86.519996643066,28.950000762939),
				RenderInner	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				Beta_Inner3D	=	true,
				RenderInner_Size	=	2,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.9,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
						247,
						211,
						211,
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						255,
						150,
						0,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.5,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/2x4sgm_tex",
					Pos4	=	Vector(-35.549999237061,86.690002441406,25.709999084473),
					UseColor	=	true,
					Pos2	=	Vector(-28.110000610352,86.690002441406,32.650001525879),
					Color	=	{
							247,
							211,
							221,
							},
					Use	=	true,
					Pos1	=	Vector(-36.049999237061,86.690002441406,32.650001525879),
					Pos3	=	Vector(-28.799999237061,86.690002441406,25.780000686646),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-32.340000152588,86.680000305176,29.14999961853),
				RenderInner	=	true,
				RenderMLCenter	=	true,
				RenderInner_Size	=	2,
				Beta_Inner3D	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				RenderMLCenter	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/2x4sgm_tex",
					Pos4	=	Vector(36,86.529998779297,25.510000228882),
					UseColor	=	true,
					Pos2	=	Vector(28.559999465942,86.529998779297,32.450000762939),
					Color	=	{
							247,
							211,
							221,
							},
					Use	=	true,
					Pos1	=	Vector(36.5,86.529998779297,32.450000762939),
					Pos3	=	Vector(29.25,86.529998779297,25.579999923706),
						},
				RunningColor	=	{
						247,
						211,
						221,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				UseSprite	=	true,
				Pos	=	Vector(32.790000915527,86.519996643066,28.950000762939),
				UseDynamic	=	true,
				RenderInner_Size	=	2,
				RenderInner	=	true,
				UseRunning	=	true,
				RenderInner_Clr	=	{
						255,
						150,
						0,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.5,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.16,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderGlow_Size	=	2.6709,
				RenderInner_Clr	=	{
						255,
						175,
						100,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.5,
						},
				FogColor	=	{
						247,
						190,
						150,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderHD_Adv	=	true,
				Pos	=	Vector(33.720001220703,89.98999786377,14.189999580383),
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(35.389999389648,89.160003662109,14.180000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.099998474121,87.870002746582,14.220000267029),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(38.540000915527,85.849998474121,14.289999961853),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(39.700000762939,83.720001220703,14.300000190735),
								},
							},
					Use	=	true,
						},
				RenderInner_Size	=	4,
				UseFog	=	true,
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.16,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderGlow_Size	=	2.6709,
				RenderInner_Clr	=	{
						255,
						175,
						100,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.5,
						},
				FogColor	=	{
						247,
						190,
						150,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-33.439998626709,89.98999786377,14.390000343323),
				RenderHD_Adv	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-35.110000610352,89.160003662109,14.380000114441),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.819999694824,87.870002746582,14.420000076294),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.259998321533,85.849998474121,14.489999771118),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-39.419998168945,83.720001220703,14.5),
								},
							},
					Use	=	true,
						},
				RenderInner_Size	=	4,
				UseFog	=	true,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.5,
						},
				SpecSpin	=	{
						},
				UsePrjTex	=	true,
				UseDynamic	=	true,
				RenderGlow_Size	=	2.6709,
				RenderInner_Clr	=	{
						255,
						175,
						100,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.5,
						},
				FogColor	=	{
						247,
						211,
						221,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(36.759998321533,88.080001831055,14.189999580383),
				RenderInner	=	true,
				RenderInner_Size	=	1,
				UseFog	=	true,
				RenderHD_Adv	=	true,
				UseSprite	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.5,
						},
				SpecSpin	=	{
						},
				UsePrjTex	=	true,
				UseDynamic	=	true,
				RenderGlow_Size	=	2.6709,
				RenderInner_Clr	=	{
						255,
						175,
						100,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.5,
						},
				FogColor	=	{
						247,
						211,
						221,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderHD_Adv	=	true,
				Pos	=	Vector(-36.779998779297,87.98999786377,14.430000305176),
				UseSprite	=	true,
				RenderInner_Size	=	1,
				UseFog	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				RenderHD_Adv	=	true,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				RenderInner_Size	=	1,
				SpecMat	=	{
					New	=	"vcmod/models/pickups/logo_vcmod",
					Select	=	20,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(38.840000152588,84.099998474121,29.020000457764),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderGlow_Size	=	2.6709,
				UseBlinkers	=	true,
				RenderInner_Clr	=	{
						255,
						155,
						0,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.5,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				Beta_Inner3D	=	true,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				RenderInner_Size	=	1,
				SpecMat	=	{
					New	=	"vcmod/models/pickups/logo_vcmod",
					Select	=	20,
						},
				ReducedVis	=	true,
				RenderHD_Adv	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-38.279998779297,84.339996337891,29.200000762939),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderGlow_Size	=	2.6709,
				UseBlinkers	=	true,
				RenderInner_Clr	=	{
						255,
						155,
						0,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.5,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				RenderMLCenter	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/2x4sgm_tex",
					Pos4	=	Vector(-35.549999237061,86.690002441406,25.709999084473),
					UseColor	=	true,
					Pos2	=	Vector(-28.110000610352,86.690002441406,32.650001525879),
					Color	=	{
							247,
							211,
							221,
							},
					Use	=	true,
					Pos1	=	Vector(-36.049999237061,86.690002441406,32.650001525879),
					Pos3	=	Vector(-28.799999237061,86.690002441406,25.780000686646),
						},
				RunningColor	=	{
						247,
						211,
						221,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-32.340000152588,86.680000305176,29.14999961853),
				UseDynamic	=	true,
				RenderInner_Size	=	2,
				RenderInner	=	true,
				UseRunning	=	true,
				RenderInner_Clr	=	{
						255,
						150,
						0,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.5,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	1.1,
						},
				SpecSpin	=	{
						},
				UsePrjTex	=	true,
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
						255,
						150,
						0,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.5,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/2x4sgm_tex",
					Pos4	=	Vector(-27.049999237061,89.069999694824,25.659999847412),
					UseColor	=	true,
					Pos2	=	Vector(-19.610000610352,89.069999694824,32.099998474121),
					Color	=	{
							247,
							211,
							221,
							},
					Use	=	true,
					Pos1	=	Vector(-27.549999237061,89.069999694824,32.599998474121),
					Pos3	=	Vector(-20.110000610352,89.069999694824,25.659999847412),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-23.5,89.089996337891,29.040000915527),
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				RenderInner	=	true,
				RenderMLCenter	=	true,
				HBeamColor	=	{
						247,
						211,
						221,
						},
				Beta_Inner3D	=	true,
				RenderInner_Size	=	2,
					},
				{
				UseBlinkers	=	true,
				SpecSpin	=	{
						},
				Beta_Inner3D	=	true,
				BlinkersColor	=	{
						255,
						150,
						0,
						},
				RenderInner_Size	=	4,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.06,
						},
				UseSprite	=	true,
				Pos	=	Vector(39.200000762939,-136.50999450684,39.080001831055),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	48,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(37.189998626709,-139.85000610352,39.279998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.509998321533,-141.16000366211,39.290000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.75,-141.4700012207,39.340000152588),
								},
							},
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.5,
						},
				RenderInner_Clr	=	{
						255,
						150,
						0,
						},
				RenderInner_ClrUse	=	true,
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(16,0,0),
				Pos	=	Vector(-21.840000152588,-2.5499999523163,29.040000915527),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(16,0,0),
				Pos	=	Vector(20.340000152588,-50.119998931885,27.540000915527),
					},
				{
				Ang	=	Angle(16,0,0),
				Pos	=	Vector(-20.340000152588,-50.119998931885,27.540000915527),
					},
				{
				Ang	=	Angle(16,0,0),
				Pos	=	Vector(0,-50.119998931885,27.540000915527),
					},
				},
		Fuel	=	{
			FuelLidPos	=	Vector(-43.779998779297,-104.83999633789,41.439998626709),
			FuelType	=	0,
			Capacity	=	70,
			Override	=	true,
			FuelLidUse	=	true,
				},
		Author	=	"CrushingSkirmish (76561198017348899)",
}