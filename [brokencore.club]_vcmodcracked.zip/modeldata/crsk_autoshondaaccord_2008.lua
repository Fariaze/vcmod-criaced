VCModels['models/crsk_autoshondaaccord_2008.mdl']	=	{
		em_state	=	5236594632,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Date	=	"Sun Sep 24 17:25:57 2017",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-28.159999847412,-112.23000335693,15.630000114441),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(28.159999847412,-112.23000335693,15.630000114441),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Pos	=	Vector(17.459999084473,8.1199998855591,32.580001831055),
					},
				{
				Pos	=	Vector(17.459999084473,-31.700000762939,32.580001831055),
					},
				{
				Pos	=	Vector(-0.28999999165535,-31.700000762939,32.580001831055),
					},
				{
				Pos	=	Vector(-19.090000152588,-31.700000762939,32.580001831055),
					},
				},
		DLT	=	3491063088,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(36.840000152588,96.900001525879,35.439998626709),
					Pos2	=	Vector(32.779998779297,96.900001525879,38.959999084473),
					Use	=	true,
					Pos1	=	Vector(36.520000457764,96.900001525879,39.119998931885),
					Pos3	=	Vector(32.569999694824,96.98999786377,35.599998474121),
						},
				SpecMat	=	{
						},
				HBeamColor	=	{
						195,
						195,
						255,
						},
				UsePrjTex	=	true,
				LBeamColor	=	{
						195,
						195,
						255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Pos	=	Vector(34.75,96.900001525879,37.180000305176),
				UseSprite	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(32.189998626709,100.33000183105,32.580001831055),
					Pos2	=	Vector(22.309999465942,100.33000183105,38.830001831055),
					Use	=	true,
					Pos1	=	Vector(32.330001831055,100.33000183105,40.389999389648),
					Pos3	=	Vector(24.159999847412,100.33000183105,31.770000457764),
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(28.510000228882,100.33000183105,35.970001220703),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
						195,
						195,
						255,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				FogColor	=	{
						195,
						195,
						255,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-33.569999694824,104.87999725342,19.379999160767),
				UseDynamic	=	true,
				UseFog	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				FogColor	=	{
						195,
						195,
						255,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(33.569999694824,104.87999725342,19.379999160767),
				UseDynamic	=	true,
				UseFog	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(39.720001220703,88.389999389648,38.279998779297),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-39.720001220703,88.389999389648,38.279998779297),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(52.509998321533,29.110000610352,49.529998779297),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-52.520000457764,29.110000610352,49.909999847412),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Use	=	true,
					Pos2	=	Vector(27.549999237061,-105.05000305176,48.220001220703),
					Pos4	=	Vector(33.099998474121,-105.05000305176,41.700000762939),
					Pos1	=	Vector(35.380001068115,-105.05000305176,48.540000915527),
					Pos3	=	Vector(31.10000038147,-105.05000305176,41.209999084473),
						},
				SpecMat	=	{
						},
				UseBrake	=	true,
				UseSprite	=	true,
				Pos	=	Vector(32.099998474121,-105.05000305176,45.430000305176),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Use	=	true,
					Pos2	=	Vector(-28.069999694824,-105.05000305176,48.220001220703),
					Pos4	=	Vector(-33.619998931885,-105.05000305176,41.700000762939),
					Pos1	=	Vector(-35.900001525879,-105.05000305176,48.540000915527),
					Pos3	=	Vector(-30.780000686646,-105.05000305176,41.209999084473),
						},
				SpecMat	=	{
						},
				UseBrake	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-32.270000457764,-105.05000305176,45.430000305176),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(-32.189998626709,100.33000183105,32.580001831055),
					Pos2	=	Vector(-22.309999465942,100.33000183105,38.830001831055),
					Use	=	true,
					Pos1	=	Vector(-31.64999961853,100.33000183105,40.389999389648),
					Pos3	=	Vector(-24.159999847412,100.33000183105,31.770000457764),
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-28.510000228882,100.33000183105,35.970001220703),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
						195,
						195,
						255,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(-36.840000152588,96.900001525879,35.439998626709),
					Pos2	=	Vector(-32.779998779297,96.900001525879,38.959999084473),
					Use	=	true,
					Pos1	=	Vector(-36.520000457764,96.900001525879,39.119998931885),
					Pos3	=	Vector(-32.569999694824,96.98999786377,35.599998474121),
						},
				SpecMat	=	{
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UsePrjTex	=	true,
				LBeamColor	=	{
						195,
						195,
						255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				HBeamColor	=	{
						195,
						195,
						255,
						},
				Pos	=	Vector(-34.75,96.900001525879,37.180000305176),
				UseSprite	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-36.790000915527,-104.93000030518,44.630001068115),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(36.790000915527,-104.93000030518,44.630001068115),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(24.659999847412,-109.90000152588,43.799999237061),
					Pos2	=	Vector(19.690000534058,-110.61000061035,47.560001373291),
					Use	=	true,
					Pos1	=	Vector(24.530000686646,-110.76000213623,47.549999237061),
					Pos3	=	Vector(19.700000762939,-109.90000152588,43.080001831055),
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(22.040000915527,-109.90000152588,45.330001831055),
				UseDynamic	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-24.659999847412,-109.90000152588,43.799999237061),
					Pos2	=	Vector(-19.690000534058,-110.61000061035,47.560001373291),
					Use	=	true,
					Pos1	=	Vector(-24.530000686646,-110.76000213623,47.549999237061),
					Pos3	=	Vector(-19.700000762939,-109.90000152588,43.080001831055),
						},
				FogColor	=	{
						255,
						55,
						0,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-22.040000915527,-109.90000152588,45.330001831055),
				UseDynamic	=	true,
				UseFog	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-5.8699998855591,-84.650001525879,56.959999084473),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-0.10000000149012,-84.180000305176,57.25),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(5.4899997711182,-84.839996337891,57.220001220703),
								},
							},
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
					},
				},
		Copyright	=	"Copyright © 2012-2017 VCMod (freemmaann). All Rights Reserved.",
		Fuel	=	{
			FuelType	=	0,
				},
		Author	=	"Tokimune (76561198087327799)",
}