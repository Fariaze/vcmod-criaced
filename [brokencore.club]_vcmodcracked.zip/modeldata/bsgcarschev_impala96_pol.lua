VCModels['models/bsgcarschev_impala96_pol.mdl']	=	{
		em_state	=	5236594800,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Siren	=	{
			Sounds	=	{
					{
					Pitch	=	100,
					Volume	=	1,
					Distance	=	95,
					Name	=	"Wail",
					Sound	=	"vcmod/els/cencom/wail.wav",
						},
					{
					Pitch	=	100,
					Volume	=	1,
					Distance	=	95,
					Name	=	"Yelp",
					Sound	=	"vcmod/els/cencom/yelp.wav",
						},
					{
					Pitch	=	100,
					Volume	=	1,
					Distance	=	95,
					Name	=	"Priority",
					Sound	=	"vcmod/els/cencom/priority.wav",
						},
					},
			Codes	=	{
				[13]	=	{
					Include	=	true,
						},
				[6]	=	{
					Spd_Stg_M	=	0.7,
					Spd_Sub	=	true,
					OvrC	=	7,
					Spd_Stg	=	true,
					Spd_Sub_M	=	0.7,
						},
					},
			Sections	=	{
				[1]	=	{
						true,
						true,
						true,
						true,
						true,
						true,
						true,
						true,
						},
				[3]	=	{
					[11]	=	true,
					[12]	=	true,
					[13]	=	true,
					[14]	=	true,
					[15]	=	true,
					[16]	=	true,
					[17]	=	true,
					[18]	=	true,
					[19]	=	true,
					[20]	=	true,
					[21]	=	true,
					[22]	=	true,
						},
				[5]	=	{
					[10]	=	true,
					[9]	=	true,
						},
					},
			Lights	=	{
					{
					Sprite	=	{
						Size	=	0.075,
							},
					Dynamic	=	{
						Size	=	0.45,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-3.289999961853,120,34.240001678467),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					SpecLine	=	{
						Amount	=	4,
						Pos	=	Vector(-4.9400000572205,120,34.240001678467),
						Use	=	true,
							},
					Beta_Inner3D	=	true,
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.075,
							},
					Dynamic	=	{
						Size	=	0.45,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-5.7199997901917,120,34.240001678467),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					SpecLine	=	{
						Amount	=	4,
						Pos	=	Vector(-7.3699998855591,120,34.240001678467),
						Use	=	true,
							},
					Beta_Inner3D	=	true,
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.075,
							},
					Dynamic	=	{
						Size	=	0.45,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-8.210000038147,120,34.240001678467),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					SpecLine	=	{
						Amount	=	4,
						Pos	=	Vector(-9.8599996566772,120,34.240001678467),
						Use	=	true,
							},
					Beta_Inner3D	=	true,
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.075,
							},
					Dynamic	=	{
						Size	=	0.45,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-10.760000228882,120,34.240001678467),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					SpecLine	=	{
						Amount	=	4,
						Pos	=	Vector(-12.409999847412,120,34.240001678467),
						Use	=	true,
							},
					Beta_Inner3D	=	true,
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.075,
							},
					Dynamic	=	{
						Size	=	0.45,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(3.289999961853,120,34.240001678467),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							0,
							55,
							255,
							},
					SpecLine	=	{
						Amount	=	4,
						Pos	=	Vector(4.9400000572205,120,34.240001678467),
						Use	=	true,
							},
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.075,
							},
					Dynamic	=	{
						Size	=	0.45,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(5.7199997901917,120,34.240001678467),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							0,
							55,
							255,
							},
					SpecLine	=	{
						Amount	=	4,
						Pos	=	Vector(7.3699998855591,120,34.240001678467),
						Use	=	true,
							},
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.075,
							},
					Dynamic	=	{
						Size	=	0.45,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(8.210000038147,120,34.240001678467),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							0,
							55,
							255,
							},
					SpecLine	=	{
						Amount	=	4,
						Pos	=	Vector(9.8599996566772,120,34.240001678467),
						Use	=	true,
							},
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.075,
							},
					Dynamic	=	{
						Size	=	0.45,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(10.760000228882,120,34.240001678467),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							0,
							55,
							255,
							},
					SpecLine	=	{
						Amount	=	4,
						Pos	=	Vector(12.409999847412,120,34.240001678467),
						Use	=	true,
							},
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.15,
							},
					Dynamic	=	{
						Size	=	0.55,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(30.370000839233,-93,52.75),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							0,
							55,
							255,
							},
					SpecLine	=	{
						Amount	=	8,
						Pos	=	Vector(26.219999313354,-93,52.770000457764),
						Use	=	true,
							},
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.15,
							},
					Dynamic	=	{
						Size	=	0.55,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-30.370000839233,-93,52.75),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					SpecLine	=	{
						Amount	=	8,
						Pos	=	Vector(-26.219999313354,-93,52.770000457764),
						Use	=	true,
							},
					Beta_Inner3D	=	true,
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.15,
							},
					Dynamic	=	{
						Size	=	0.55,
						Brightness	=	2,
							},
					SpecRec	=	{
						AmountV	=	3,
						Pos4	=	Vector(-11.770000457764,-28.299999237061,74.730003356934),
						Pos2	=	Vector(-7.5999999046326,-28.299999237061,76),
						AmountH	=	5,
						Use	=	true,
						Pos1	=	Vector(-11.770000457764,-28.299999237061,76),
						Pos3	=	Vector(-7.5999999046326,-28.299999237061,74.730003356934),
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-9.6899995803833,-28.299999237061,75.370002746582),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							0,
							55,
							255,
							},
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.15,
							},
					Dynamic	=	{
						Size	=	0.55,
						Brightness	=	2,
							},
					SpecRec	=	{
						Pos4	=	Vector(-18.64999961853,-28.299999237061,74.730003356934),
						AmountV	=	3,
						Pos2	=	Vector(-14.380000114441,-28.299999237061,76),
						AmountH	=	5,
						Use	=	true,
						Pos1	=	Vector(-18.64999961853,-28.299999237061,76),
						Pos3	=	Vector(-14.380000114441,-28.299999237061,74.730003356934),
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-16.510000228882,-28.299999237061,75.370002746582),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							0,
							55,
							255,
							},
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.15,
							},
					Dynamic	=	{
						Size	=	0.55,
						Brightness	=	2,
							},
					SpecRec	=	{
						AmountV	=	3,
						Pos4	=	Vector(-25,-26.799999237061,74.730003356934),
						Pos2	=	Vector(-20.780000686646,-28.299999237061,76),
						AmountH	=	5,
						Use	=	true,
						Pos1	=	Vector(-25,-26.799999237061,76),
						Pos3	=	Vector(-20.780000686646,-28.299999237061,74.730003356934),
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-22.889999389648,-27.549999237061,75.370002746582),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							0,
							55,
							255,
							},
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.15,
							},
					Dynamic	=	{
						Size	=	0.55,
						Brightness	=	2,
							},
					SpecRec	=	{
						Pos4	=	Vector(-11.770000457764,-17.700000762939,74.730003356934),
						AmountV	=	3,
						Pos2	=	Vector(-7.5999999046326,-17.700000762939,76),
						AmountH	=	5,
						Use	=	true,
						Pos1	=	Vector(-11.770000457764,-17.700000762939,76),
						Pos3	=	Vector(-7.5999999046326,-17.700000762939,74.730003356934),
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-9.6899995803833,-17.700000762939,75.370002746582),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							0,
							55,
							255,
							},
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.15,
							},
					Dynamic	=	{
						Size	=	0.55,
						Brightness	=	2,
							},
					SpecRec	=	{
						AmountV	=	3,
						Pos4	=	Vector(-18.64999961853,-17.700000762939,74.730003356934),
						Pos2	=	Vector(-14.380000114441,-17.700000762939,76),
						AmountH	=	5,
						Use	=	true,
						Pos1	=	Vector(-18.64999961853,-17.700000762939,76),
						Pos3	=	Vector(-14.380000114441,-17.700000762939,74.730003356934),
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-16.510000228882,-17.700000762939,75.370002746582),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							0,
							55,
							255,
							},
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.15,
							},
					Dynamic	=	{
						Size	=	0.55,
						Brightness	=	2,
							},
					SpecRec	=	{
						Pos4	=	Vector(-25,-19.299999237061,74.730003356934),
						AmountV	=	3,
						Pos2	=	Vector(-20.780000686646,-17.700000762939,76),
						AmountH	=	5,
						Use	=	true,
						Pos1	=	Vector(-25,-19.299999237061,76),
						Pos3	=	Vector(-20.780000686646,-17.700000762939,74.730003356934),
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-22.889999389648,-18.5,75.370002746582),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							0,
							55,
							255,
							},
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.15,
							},
					Dynamic	=	{
						Size	=	0.55,
						Brightness	=	2,
							},
					SpecRec	=	{
						Pos4	=	Vector(11.770000457764,-28.299999237061,74.730003356934),
						AmountV	=	3,
						Pos2	=	Vector(7.5999999046326,-28.299999237061,76),
						AmountH	=	5,
						Use	=	true,
						Pos1	=	Vector(11.770000457764,-28.299999237061,76),
						Pos3	=	Vector(7.5999999046326,-28.299999237061,74.730003356934),
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(9.6899995803833,-28.299999237061,75.370002746582),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					Beta_Inner3D	=	true,
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.15,
							},
					Dynamic	=	{
						Size	=	0.55,
						Brightness	=	2,
							},
					SpecRec	=	{
						AmountV	=	3,
						Pos4	=	Vector(18.64999961853,-28.299999237061,74.730003356934),
						Pos2	=	Vector(14.380000114441,-28.299999237061,76),
						AmountH	=	5,
						Use	=	true,
						Pos1	=	Vector(18.64999961853,-28.299999237061,76),
						Pos3	=	Vector(14.380000114441,-28.299999237061,74.730003356934),
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(16.510000228882,-28.299999237061,75.370002746582),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					Beta_Inner3D	=	true,
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.15,
							},
					Dynamic	=	{
						Size	=	0.55,
						Brightness	=	2,
							},
					SpecRec	=	{
						Pos4	=	Vector(25,-26.799999237061,74.730003356934),
						AmountV	=	3,
						Pos2	=	Vector(20.780000686646,-28.299999237061,76),
						AmountH	=	5,
						Use	=	true,
						Pos1	=	Vector(25,-26.799999237061,76),
						Pos3	=	Vector(20.780000686646,-28.299999237061,74.730003356934),
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(22.889999389648,-27.549999237061,75.370002746582),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					Beta_Inner3D	=	true,
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.15,
							},
					Dynamic	=	{
						Size	=	0.55,
						Brightness	=	2,
							},
					SpecRec	=	{
						AmountV	=	3,
						Pos4	=	Vector(11.770000457764,-17.700000762939,74.730003356934),
						Pos2	=	Vector(7.5999999046326,-17.700000762939,76),
						AmountH	=	5,
						Use	=	true,
						Pos1	=	Vector(11.770000457764,-17.700000762939,76),
						Pos3	=	Vector(7.5999999046326,-17.700000762939,74.730003356934),
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(9.6899995803833,-17.700000762939,75.370002746582),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					Beta_Inner3D	=	true,
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.15,
							},
					Dynamic	=	{
						Size	=	0.55,
						Brightness	=	2,
							},
					SpecRec	=	{
						Pos4	=	Vector(18.64999961853,-17.700000762939,74.730003356934),
						AmountV	=	3,
						Pos2	=	Vector(14.380000114441,-17.700000762939,76),
						AmountH	=	5,
						Use	=	true,
						Pos1	=	Vector(18.64999961853,-17.700000762939,76),
						Pos3	=	Vector(14.380000114441,-17.700000762939,74.730003356934),
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(16.510000228882,-17.700000762939,75.370002746582),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					Beta_Inner3D	=	true,
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.15,
							},
					Dynamic	=	{
						Size	=	0.55,
						Brightness	=	2,
							},
					SpecRec	=	{
						AmountV	=	3,
						Pos4	=	Vector(25,-19.299999237061,74.730003356934),
						Pos2	=	Vector(20.780000686646,-17.700000762939,76),
						AmountH	=	5,
						Use	=	true,
						Pos1	=	Vector(25,-19.299999237061,76),
						Pos3	=	Vector(20.780000686646,-17.700000762939,74.730003356934),
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(22.889999389648,-18.5,75.370002746582),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					Beta_Inner3D	=	true,
					UseSprite	=	true,
						},
					},
			Sounds_Horn	=	{
				Use	=	true,
				Volume	=	1,
				Distance	=	95,
				Pitch	=	100,
				Sound	=	"vcmod/els/cencom/bullhorn.wav",
					},
			Sequences	=	{
					{
					SubSeq	=	{
							{
							Stages	=	{
									{
									Lights	=	{
											1,
											2,
											3,
											4,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											1,
											2,
											3,
											4,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											5,
											6,
											7,
											8,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											5,
											6,
											7,
											8,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									},
							Time	=	5,
								},
							{
							Stages	=	{
									{
									Lights	=	{
											1,
											2,
											3,
											4,
											},
									Time	=	0.2,
										},
									{
									Lights	=	{
											5,
											6,
											7,
											8,
											},
									Time	=	0.2,
										},
									},
							Time	=	5,
								},
							{
							Stages	=	{
									{
									Lights	=	{
											4,
											8,
											},
									Time	=	0.075,
										},
									{
									Lights	=	{
											3,
											7,
											},
									Time	=	0.075,
										},
									{
									Lights	=	{
											2,
											6,
											},
									Time	=	0.075,
										},
									{
									Lights	=	{
											1,
											5,
											},
									Time	=	0.075,
										},
									{
									Lights	=	{
											2,
											6,
											},
									Time	=	0.075,
										},
									{
									Lights	=	{
											3,
											7,
											},
									Time	=	0.075,
										},
									},
							Time	=	5,
								},
							},
					Codes	=	{
						[7]	=	true,
							},
					Lights_Sel	=	{
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							},
						},
					{
					SubSeq	=	{
							{
							Stages	=	{
									{
									Lights	=	{
											10,
											},
									Time	=	0.1,
										},
									{
									Lights	=	{
											9,
											},
									Time	=	0.1,
										},
									},
							Time	=	5,
								},
							{
							Stages	=	{
									{
									Lights	=	{
											10,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											10,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											9,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											9,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									},
							Time	=	5,
								},
							},
					Codes	=	{
						[7]	=	true,
							},
					Lights_Sel	=	{
						[10]	=	true,
						[9]	=	true,
							},
						},
					{
					SubSeq	=	{
							{
							Stages	=	{
									{
									Lights	=	{
											11,
											12,
											13,
											14,
											15,
											16,
											},
									Time	=	0.2,
										},
									{
									Lights	=	{
											17,
											18,
											19,
											20,
											21,
											22,
											},
									Time	=	0.2,
										},
									},
							Time	=	5,
								},
							{
							Stages	=	{
									{
									Lights	=	{
											11,
											12,
											13,
											14,
											15,
											16,
											},
									Time	=	0.1,
										},
									{
									Lights	=	{
											},
									Time	=	0.1,
										},
									},
							Time	=	1,
								},
							{
							Stages	=	{
									{
									Lights	=	{
											17,
											18,
											19,
											20,
											21,
											22,
											},
									Time	=	0.1,
										},
									{
									Lights	=	{
											},
									Time	=	0.1,
										},
									},
							Time	=	1,
								},
							{
							Stages	=	{
									{
									Lights	=	{
											11,
											12,
											13,
											14,
											15,
											16,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											11,
											12,
											13,
											14,
											15,
											16,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											11,
											12,
											13,
											14,
											15,
											16,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											11,
											12,
											13,
											14,
											15,
											16,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											11,
											12,
											13,
											14,
											15,
											16,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											17,
											18,
											19,
											20,
											21,
											22,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											17,
											18,
											19,
											20,
											21,
											22,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											17,
											18,
											19,
											20,
											21,
											22,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											17,
											18,
											19,
											20,
											21,
											22,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											17,
											18,
											19,
											20,
											21,
											22,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									},
							Time	=	5,
								},
							{
							Stages	=	{
									{
									Lights	=	{
											11,
											12,
											13,
											14,
											15,
											16,
											17,
											18,
											19,
											20,
											21,
											22,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											11,
											12,
											13,
											14,
											15,
											16,
											17,
											18,
											19,
											20,
											21,
											22,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											11,
											12,
											13,
											14,
											15,
											16,
											17,
											18,
											19,
											20,
											21,
											22,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											11,
											12,
											13,
											14,
											15,
											16,
											17,
											18,
											19,
											20,
											21,
											22,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											11,
											12,
											13,
											14,
											15,
											16,
											17,
											18,
											19,
											20,
											21,
											22,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.5,
										},
									},
							Time	=	2,
								},
							},
					Codes	=	{
						[7]	=	true,
							},
					Lights_Sel	=	{
						[11]	=	true,
						[12]	=	true,
						[13]	=	true,
						[14]	=	true,
						[15]	=	true,
						[16]	=	true,
						[17]	=	true,
						[18]	=	true,
						[19]	=	true,
						[20]	=	true,
						[21]	=	true,
						[22]	=	true,
							},
						},
					},
			Sounds_Manual	=	{
				Use	=	true,
				Volume	=	1,
				Distance	=	95,
				Pitch	=	100,
				Sound	=	"vcmod/els/cencom/wail.wav",
					},
				},
		Date	=	"03/05/15 19:43:18",
		Exhaust	=	{
				{
				Ang	=	Angle(35,-75,0),
				Pos	=	Vector(-32.130001068115,-133.39999389648,14.550000190735),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(35,-90,0),
				Pos	=	Vector(32.130001068115,-133.39999389648,14.550000190735),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(20,-4.9998998641968,34.200000762939),
				RadioControl	=	true,
					},
				{
				Pos	=	Vector(-20,-36.399898529053,34.200000762939),
				Ang	=	Angle(0,0,0),
				Cant_Exit_Lock	=	true,
				switch_rear	=	true,
				Switch_Rear	=	true,
					},
				{
				Pos	=	Vector(20,-36.400001525879,34.200000762939),
				Ang	=	Angle(0,0,0),
				Cant_Exit_Lock	=	true,
				switch_rear	=	true,
				Switch_Rear	=	true,
					},
				},
		DLT	=	3491063200,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				UseBrake	=	true,
				UseDynamic	=	true,
				Pos	=	Vector(-4.0999999046326,-96.940002441406,55),
				UseSprite	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				SpecLine	=	{
					Amount	=	12,
					Use	=	true,
					Pos	=	Vector(4.0999999046326,-96.940002441406,55),
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-39.290000915527,103.43000030518,29.909999847412),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				RenderInner_Size	=	1.2,
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseHead	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-39.290000915527,103.43000030518,29.909999847412),
				UseDynamic	=	true,
				HeadColor	=	{
						228,
						221,
						255,
						},
				ProjTexture	=	{
					Forward	=	30,
					Size	=	2000,
					Angle	=	Angle(0,90,0),
						},
				UsePrjTex	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				UseRunning	=	true,
				Pos	=	Vector(-24.229999542236,110.08999633789,30.049999237061),
				RunningColor	=	{
						237.17,
						240,
						244.1,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.12,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseReverse	=	true,
				UseSprite	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				SpecLine	=	{
					Amount	=	4,
					Use	=	true,
					Pos	=	Vector(-35.720001220703,-135.41999816895,37.810001373291),
						},
				Pos	=	Vector(-30.260000228882,-136.94999694824,37.729999542236),
				UseDynamic	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				UseBrake	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-23.639999389648,-137.7200012207,39.930000305176),
				UseDynamic	=	true,
				UseRunning	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				SpecLine	=	{
					Amount	=	4,
					Use	=	true,
					Pos	=	Vector(-35.790000915527,-135.33000183105,39.819999694824),
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				UseBrake	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-43.009998321533,-128.22999572754,39.5),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
				SpecMLine	=	{
					LTbl	=	{
							{
							Amount	=	2,
							Pos	=	Vector(-41.020000457764,-132.88999938965,39.569999694824),
								},
							{
							Amount	=	2,
							Pos	=	Vector(-38.349998474121,-134.28999328613,39.470001220703),
								},
							},
					Use	=	true,
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-42.889999389648,-130.30999755859,39.580001831055),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				RenderInner_Size	=	1.2,
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(39.290000915527,103.43000030518,29.909999847412),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				RenderInner_Size	=	1.2,
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseHead	=	true,
				UseSprite	=	true,
				Pos	=	Vector(39.290000915527,103.43000030518,29.909999847412),
				UseDynamic	=	true,
				HeadColor	=	{
						228,
						221,
						255,
						},
				ProjTexture	=	{
					Forward	=	30,
					Size	=	2000,
					Angle	=	Angle(0,90,0),
						},
				UsePrjTex	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				UseRunning	=	true,
				Pos	=	Vector(24.229999542236,110.08999633789,30.049999237061),
				RunningColor	=	{
						237.17,
						240,
						244.1,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.12,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseReverse	=	true,
				UseSprite	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				SpecLine	=	{
					Amount	=	4,
					Use	=	true,
					Pos	=	Vector(35.720001220703,-135.41999816895,37.810001373291),
						},
				Pos	=	Vector(30.260000228882,-136.94999694824,37.729999542236),
				UseDynamic	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				UseBrake	=	true,
				UseSprite	=	true,
				Pos	=	Vector(23.639999389648,-137.7200012207,39.930000305176),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
				SpecLine	=	{
					Amount	=	4,
					Use	=	true,
					Pos	=	Vector(35.790000915527,-135.33000183105,39.819999694824),
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				UseBrake	=	true,
				UseSprite	=	true,
				Pos	=	Vector(43.009998321533,-128.22999572754,39.5),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
				SpecMLine	=	{
					LTbl	=	{
							{
							Amount	=	2,
							Pos	=	Vector(41.020000457764,-132.88999938965,39.569999694824),
								},
							{
							Amount	=	2,
							Pos	=	Vector(38.349998474121,-134.28999328613,39.470001220703),
								},
							},
					Use	=	true,
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(42.889999389648,-130.30999755859,39.580001831055),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				RenderInner_Size	=	1.2,
				UseSprite	=	true,
					},
				},
		Copyright	=	"DurkaTeam @ 2025 No rights reserved",
		Author	=	"freemmaann",
}