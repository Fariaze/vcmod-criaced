VCModels['models/colorable_vehiclespickup_truck_2004.mdl']	=	{
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				SpecSpin	=	{
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				ProjTexture	=	{
					Forward	=	30,
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				SpecMat	=	{
						},
				Beta_Inner3D	=	true,
				UseHead	=	true,
				UseSprite	=	true,
				Pos	=	Vector(38.599998474121,116.76999664307,46.549999237061),
				UseDynamic	=	true,
				RenderInner	=	true,
				HeadColor	=	{
						255,
						158,
						67,
						},
				UsePrjTex	=	true,
				RenderInner_Clr	=	{
						200,
						225,
						255,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				SpecRec	=	{
					Pos4	=	Vector(43.130001068115,-145.64999389648,38.810001373291),
					AmountV	=	3,
					Pos2	=	Vector(46.759998321533,-145.64999389648,40.860000610352),
					AmountH	=	3,
					Use	=	true,
					Pos1	=	Vector(43.119998931885,-145.64999389648,40.880001068115),
					Pos3	=	Vector(46.740001678467,-145.64999389648,38.75),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(44.979999542236,-145.64999389648,39.799999237061),
				UseDynamic	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_blur",
					Use	=	true,
					UseColor	=	true,
					Pos2	=	Vector(47.619998931885,-145.64999389648,41.360000610352),
					Color	=	{
							200,
							225,
							255,
							},
					Pos4	=	Vector(42.270000457764,-145.64999389648,38.310001373291),
					Pos1	=	Vector(42.259998321533,-145.64999389648,41.380001068115),
					Pos3	=	Vector(47.599998474121,-145.64999389648,38.25),
						},
				Beta_Inner3D	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(44.409999847412,-145.16000366211,51.529998779297),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				UseSprite	=	true,
				SpecRec	=	{
					Pos4	=	Vector(43.150001525879,-145.16000366211,50.159999847412),
					AmountV	=	3,
					Pos2	=	Vector(46.189998626709,-145.16000366211,52.590000152588),
					AmountH	=	3,
					Use	=	true,
					Pos1	=	Vector(43.060001373291,-145.16000366211,52.610000610352),
					Pos3	=	Vector(46.5,-145.13000488281,50.090000152588),
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/rectangle_rounded_2x8_texture",
					Use	=	true,
					Pos2	=	Vector(47.049999237061,-145.16000366211,53.330001831055),
					Color	=	{
							200,
							225,
							255,
							},
					Pos4	=	Vector(42.520000457764,-145.55000305176,49.409999847412),
					Pos1	=	Vector(42.409999847412,-145.16000366211,53.470001220703),
					Pos3	=	Vector(47.340000152588,-145.52000427246,49.380001068115),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					AmountV	=	3,
					Pos4	=	Vector(43.470001220703,-145.58000183105,45.630001068115),
					Pos2	=	Vector(46.509998321533,-145.58000183105,48.060001373291),
					AmountH	=	3,
					Use	=	true,
					Pos1	=	Vector(43.380001068115,-145.58000183105,48.080001831055),
					Pos3	=	Vector(46.819999694824,-145.58000183105,45.560001373291),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(44.729999542236,-145.58000183105,47),
				UseDynamic	=	true,
				UseBrake	=	true,
				Beta_Inner3D	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/rectangle_rounded_2x8_texture",
					Use	=	true,
					Pos2	=	Vector(47.659999847412,-145.58000183105,48.799999237061),
					Color	=	{
							200,
							225,
							255,
							},
					Pos4	=	Vector(42.380001068115,-145.58000183105,44.880001068115),
					Pos1	=	Vector(42.319999694824,-145.58000183105,48.939998626709),
					Pos3	=	Vector(47.659999847412,-145.58000183105,44.849998474121),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/rectangle_rounded_2x8_texture",
					Use	=	true,
					Pos2	=	Vector(47.659999847412,-145.66000366211,45.259998321533),
					Color	=	{
							200,
							225,
							255,
							},
					Pos4	=	Vector(42.380001068115,-145.66000366211,41.340000152588),
					Pos1	=	Vector(42.319999694824,-145.66000366211,45.400001525879),
					Pos3	=	Vector(47.659999847412,-145.66000366211,41.310001373291),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(44.729999542236,-145.66000366211,43.459999084473),
				UseDynamic	=	true,
				UseRunning	=	true,
				Beta_Inner3D	=	true,
				SpecRec	=	{
					Pos4	=	Vector(43.470001220703,-145.66000366211,42.090000152588),
					AmountV	=	3,
					Pos2	=	Vector(46.509998321533,-145.66000366211,44.520000457764),
					AmountH	=	3,
					Use	=	true,
					Pos1	=	Vector(43.380001068115,-145.66000366211,44.540000915527),
					Pos3	=	Vector(46.819999694824,-145.66000366211,42.020000457764),
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(45.990001678467,114.7799987793,48.689998626709),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	8,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(46.049999237061,114.33000183105,43.619998931885),
								},
							},
						},
				Beta_Inner3D	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					Pos4	=	Vector(34.459999084473,118.30000305176,43.790000915527),
					AmountV	=	4,
					Pos2	=	Vector(43.580001831055,116.04000091553,48.409999847412),
					AmountH	=	5,
					Use	=	true,
					Pos1	=	Vector(34.590000152588,118.41999816895,48.270000457764),
					Pos3	=	Vector(43.630001068115,115.79000091553,44.630001068115),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(38.930000305176,117.12000274658,46.5),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
				UseRunning	=	true,
				RunningColor	=	{
						255,
						158,
						67,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Use	=	true,
					UseColor	=	true,
					Pos2	=	Vector(45.450000762939,116.26000213623,49.950000762939),
					Color	=	{
							255,
							255,
							234,
							},
					Pos4	=	Vector(33.950000762939,118.41000366211,42.950000762939),
					Pos1	=	Vector(32.979999542236,119.37000274658,50.040000915527),
					Pos3	=	Vector(44.849998474121,115.51999664307,43.240001678467),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					Pos4	=	Vector(34.509998321533,118.30000305176,43.790000915527),
					AmountV	=	4,
					Pos2	=	Vector(43.630001068115,116.04000091553,48.409999847412),
					AmountH	=	5,
					Use	=	true,
					Pos1	=	Vector(34.639999389648,118.41999816895,48.270000457764),
					Pos3	=	Vector(43.680000305176,115.79000091553,44.630001068115),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseHead	=	true,
				UseSprite	=	true,
				Pos	=	Vector(38.979999542236,117.12000274658,46.5),
				UseDynamic	=	true,
				HeadColor	=	{
						255,
						158,
						67,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Use	=	true,
					UseColor	=	true,
					Pos2	=	Vector(45.5,116.26000213623,49.950000762939),
					Color	=	{
							255,
							255,
							234,
							},
					Pos4	=	Vector(34,118.41000366211,42.950000762939),
					Pos1	=	Vector(33.029998779297,119.37000274658,50.040000915527),
					Pos3	=	Vector(44.900001525879,115.51999664307,43.240001678467),
						},
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				SpecSpin	=	{
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				ProjTexture	=	{
					Forward	=	30,
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				SpecMat	=	{
						},
				Beta_Inner3D	=	true,
				UseHead	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-38.599998474121,116.76999664307,46.549999237061),
				UseDynamic	=	true,
				RenderInner	=	true,
				HeadColor	=	{
						255,
						158,
						67,
						},
				UsePrjTex	=	true,
				RenderInner_Clr	=	{
						200,
						225,
						255,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				SpecRec	=	{
					Pos4	=	Vector(-43.130001068115,-145.64999389648,38.810001373291),
					AmountV	=	3,
					Pos2	=	Vector(-46.759998321533,-145.64999389648,40.860000610352),
					AmountH	=	3,
					Use	=	true,
					Pos1	=	Vector(-43.119998931885,-145.64999389648,40.880001068115),
					Pos3	=	Vector(-46.740001678467,-145.64999389648,38.75),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-44.979999542236,-145.64999389648,39.799999237061),
				UseDynamic	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				Beta_Inner3D	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_blur",
					Use	=	true,
					UseColor	=	true,
					Pos2	=	Vector(-47.619998931885,-145.64999389648,41.360000610352),
					Color	=	{
							200,
							225,
							255,
							},
					Pos4	=	Vector(-42.270000457764,-145.64999389648,38.310001373291),
					Pos1	=	Vector(-42.259998321533,-145.64999389648,41.380001068115),
					Pos3	=	Vector(-47.599998474121,-145.64999389648,38.25),
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-44.409999847412,-145.16000366211,51.529998779297),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Beta_Inner3D	=	true,
				SpecRec	=	{
					Pos4	=	Vector(-43.150001525879,-145.16000366211,50.159999847412),
					AmountV	=	3,
					Pos2	=	Vector(-46.189998626709,-145.16000366211,52.590000152588),
					AmountH	=	3,
					Use	=	true,
					Pos1	=	Vector(-43.060001373291,-145.16000366211,52.610000610352),
					Pos3	=	Vector(-46.5,-145.13000488281,50.090000152588),
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/rectangle_rounded_2x8_texture",
					Use	=	true,
					Pos2	=	Vector(-47.049999237061,-145.16000366211,53.330001831055),
					Color	=	{
							200,
							225,
							255,
							},
					Pos4	=	Vector(-42.520000457764,-145.55000305176,49.409999847412),
					Pos1	=	Vector(-42.409999847412,-145.16000366211,53.470001220703),
					Pos3	=	Vector(-47.340000152588,-145.52000427246,49.380001068115),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					AmountV	=	3,
					Pos4	=	Vector(-43.470001220703,-145.58000183105,45.630001068115),
					Pos2	=	Vector(-46.509998321533,-145.58000183105,48.060001373291),
					AmountH	=	3,
					Use	=	true,
					Pos1	=	Vector(-43.380001068115,-145.58000183105,48.080001831055),
					Pos3	=	Vector(-46.819999694824,-145.58000183105,45.560001373291),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-44.729999542236,-145.58000183105,47),
				UseDynamic	=	true,
				UseBrake	=	true,
				Beta_Inner3D	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/rectangle_rounded_2x8_texture",
					Use	=	true,
					Pos2	=	Vector(-47.659999847412,-145.58000183105,48.799999237061),
					Color	=	{
							200,
							225,
							255,
							},
					Pos4	=	Vector(-42.380001068115,-145.58000183105,44.880001068115),
					Pos1	=	Vector(-42.319999694824,-145.58000183105,48.939998626709),
					Pos3	=	Vector(-47.659999847412,-145.58000183105,44.849998474121),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					Pos4	=	Vector(-43.470001220703,-145.66000366211,42.090000152588),
					AmountV	=	3,
					Pos2	=	Vector(-46.509998321533,-145.66000366211,44.520000457764),
					AmountH	=	3,
					Use	=	true,
					Pos1	=	Vector(-43.380001068115,-145.66000366211,44.540000915527),
					Pos3	=	Vector(-46.819999694824,-145.66000366211,42.020000457764),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-44.729999542236,-145.66000366211,43.459999084473),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
				UseRunning	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/rectangle_rounded_2x8_texture",
					Use	=	true,
					Pos2	=	Vector(-47.659999847412,-145.66000366211,45.259998321533),
					Color	=	{
							200,
							225,
							255,
							},
					Pos4	=	Vector(-42.380001068115,-145.66000366211,41.340000152588),
					Pos1	=	Vector(-42.319999694824,-145.66000366211,45.400001525879),
					Pos3	=	Vector(-47.659999847412,-145.66000366211,41.310001373291),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-45.990001678467,114.7799987793,48.689998626709),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	8,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-46.049999237061,114.33000183105,43.619998931885),
								},
							},
						},
				Beta_Inner3D	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					Pos4	=	Vector(-34.459999084473,118.30000305176,43.790000915527),
					AmountV	=	4,
					Pos2	=	Vector(-43.580001831055,116.04000091553,48.409999847412),
					AmountH	=	5,
					Use	=	true,
					Pos1	=	Vector(-34.590000152588,118.41999816895,48.270000457764),
					Pos3	=	Vector(-43.630001068115,115.79000091553,44.630001068115),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-38.930000305176,117.12000274658,46.5),
				UseDynamic	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Use	=	true,
					UseColor	=	true,
					Pos2	=	Vector(-45.450000762939,116.26000213623,49.950000762939),
					Color	=	{
							255,
							255,
							234,
							},
					Pos4	=	Vector(-33.950000762939,118.41000366211,42.950000762939),
					Pos1	=	Vector(-32.979999542236,119.37000274658,50.040000915527),
					Pos3	=	Vector(-44.849998474121,115.51999664307,43.240001678467),
						},
				UseRunning	=	true,
				Beta_Inner3D	=	true,
				RunningColor	=	{
						255,
						158,
						67,
						},
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					AmountV	=	4,
					Pos4	=	Vector(-34.509998321533,118.30000305176,43.790000915527),
					Pos2	=	Vector(-43.630001068115,116.04000091553,48.409999847412),
					AmountH	=	5,
					Use	=	true,
					Pos1	=	Vector(-34.639999389648,118.41999816895,48.270000457764),
					Pos3	=	Vector(-43.680000305176,115.79000091553,44.630001068115),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseHead	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-38.979999542236,117.12000274658,46.5),
				UseDynamic	=	true,
				HeadColor	=	{
						255,
						158,
						67,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Use	=	true,
					UseColor	=	true,
					Pos2	=	Vector(-45.5,116.26000213623,49.950000762939),
					Color	=	{
							255,
							255,
							234,
							},
					Pos4	=	Vector(-34,118.41000366211,42.950000762939),
					Pos1	=	Vector(-33.029998779297,119.37000274658,50.040000915527),
					Pos3	=	Vector(-44.900001525879,115.51999664307,43.240001678467),
						},
				Beta_Inner3D	=	true,
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
					},
				},
		em_state	=	5236594356,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		DLT	=	3491062904,
		Date	=	"06/14/16 22:22:56",
		ExtraSeats	=	{
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(22.479999542236,30,50.349998474121),
				RadioControl	=	true,
					},
				},
		Copyright	=	"Copyright © 2012-2016 VCMod (freemmaann). All Rights Reserved.",
		Author	=	"freemmaann (76561197989323181)",
}