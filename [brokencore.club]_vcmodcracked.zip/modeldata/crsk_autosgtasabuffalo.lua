VCModels['models/crsk_autosgtasabuffalo.mdl']	=	{
		em_state	=	5236595019,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Date	=	"Sat Mar 18 01:25:19 2017",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-73,0),
				Pos	=	Vector(22,-110,15),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-95,0),
				Pos	=	Vector(-22,-110,15),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(21.39999961853,-1.6399999856949,33.790000915527),
				RadioControl	=	true,
					},
				},
		DLT	=	3491063346,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(32.180000305176,110.56999969482,28.450000762939),
					UseColor	=	true,
					Pos2	=	Vector(23.819999694824,110.06999969482,36.810001373291),
					Color	=	{
							255,
							255,
							255,
							},
					Use	=	true,
					Pos1	=	Vector(32.180000305176,108.56999969482,36.810001373291),
					Pos3	=	Vector(23.819999694824,112.06999969482,28.450000762939),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(28,110.56999969482,32.630001068115),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				Beta_Inner3D	=	true,
				HBeamColor	=	{
						232,
						200,
						255,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-31.680000305176,110.56999969482,28.520000457764),
					UseColor	=	true,
					Pos2	=	Vector(-23.319999694824,110.06999969482,36.880001068115),
					Color	=	{
							255,
							255,
							255,
							},
					Use	=	true,
					Pos1	=	Vector(-31.680000305176,108.56999969482,36.880001068115),
					Pos3	=	Vector(-23.319999694824,112.06999969482,28.520000457764),
						},
				HBeamColor	=	{
						232,
						200,
						255,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-27.5,110.56999969482,32.700000762939),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Beta_Inner3D	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				SpecMat	=	{
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-39.680000305176,109.56999969482,28.520000457764),
					UseColor	=	true,
					Pos2	=	Vector(-31.319999694824,109.06999969482,36.880001068115),
					Color	=	{
							255,
							255,
							255,
							},
					Use	=	true,
					Pos1	=	Vector(-39.680000305176,107.56999969482,36.880001068115),
					Pos3	=	Vector(-31.319999694824,111.06999969482,28.520000457764),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-35.5,109.56999969482,32.700000762939),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				UseSprite	=	true,
				RunningColor	=	{
						231.96,
						230.97,
						205.73,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(40.180000305176,109.06999969482,28.520000457764),
					UseColor	=	true,
					Pos2	=	Vector(31.819999694824,108.56999969482,36.880001068115),
					Color	=	{
							255,
							255,
							255,
							},
					Use	=	true,
					Pos1	=	Vector(40.180000305176,107.06999969482,36.880001068115),
					Pos3	=	Vector(31.819999694824,110.56999969482,28.520000457764),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(36,109.06999969482,32.700000762939),
				UseDynamic	=	true,
				UseRunning	=	true,
				Beta_Inner3D	=	true,
				RunningColor	=	{
						231.96,
						230.97,
						205.73,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-39.680000305176,109.56999969482,28.520000457764),
					UseColor	=	true,
					Pos2	=	Vector(-31.319999694824,109.06999969482,36.880001068115),
					Color	=	{
							255,
							255,
							255,
							},
					Use	=	true,
					Pos1	=	Vector(-39.680000305176,107.56999969482,36.880001068115),
					Pos3	=	Vector(-31.319999694824,111.06999969482,28.520000457764),
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				HBeamColor	=	{
						187,
						219,
						255,
						},
				ReducedVis	=	true,
				SpecMat	=	{
						},
				UsePrjTex	=	true,
				LBeamColor	=	{
						187,
						219,
						255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-35.5,109.56999969482,32.700000762939),
				Beta_Inner3D	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(40.180000305176,109.06999969482,28.520000457764),
					UseColor	=	true,
					Pos2	=	Vector(31.819999694824,108.56999969482,36.880001068115),
					Color	=	{
							255,
							255,
							255,
							},
					Use	=	true,
					Pos1	=	Vector(40.180000305176,107.06999969482,36.880001068115),
					Pos3	=	Vector(31.819999694824,110.56999969482,28.520000457764),
						},
				HBeamColor	=	{
						187,
						219,
						255,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
						187,
						219,
						255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				Pos	=	Vector(36,109.06999969482,32.700000762939),
				Beta_Inner3D	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				BlinkersColor	=	{
						255,
						55,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-36,-105.19999694824,37.700000762939),
				UseBrake	=	true,
				UseBlinkers	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-20.5,-105.19999694824,37.700000762939),
								},
							},
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-40.180000305176,-105.69999694824,33.520000457764),
					UseColor	=	true,
					Pos2	=	Vector(-16.819999694824,-104.69999694824,41.880001068115),
					Color	=	{
							255,
							55,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(-40.180000305176,-103.69999694824,41.880001068115),
					Pos3	=	Vector(-16.819999694824,-107.19999694824,33.520000457764),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(39.680000305176,-106.19999694824,33.319999694824),
					UseColor	=	true,
					Pos2	=	Vector(16.319999694824,-105.19999694824,41.680000305176),
					Color	=	{
							255,
							55,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(39.680000305176,-104.19999694824,41.680000305176),
					Pos3	=	Vector(16.319999694824,-107.69999694824,33.319999694824),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(35.5,-105.69999694824,37.5),
				UseBrake	=	true,
				UseBlinkers	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(20,-105.69999694824,37.5),
								},
							},
						},
				UseSprite	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				BlinkersColor	=	{
						255,
						55,
						0,
						},
					},
				},
		Copyright	=	"Copyright © 2012-2017 VCMod (freemmaann). All Rights Reserved.",
		Fuel	=	{
			FuelType	=	0,
				},
		Author	=	"ᶜʳᵉᵉᵖᵉʳᵀᵛ (76561198051637331)",
}