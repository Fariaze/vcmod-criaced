-- DurkaTeam @ 2025 Никакие права не защищены

include('shared.lua')

ENT.RenderGroup = RENDERGROUP_BOTH

function ENT:Initialize() end

function ENT:Think() if VC and VC.CodeEnt.Spikestrip and VC.CodeEnt.Spikestrip.Think then return VC.CodeEnt.Spikestrip.Think(self) end end