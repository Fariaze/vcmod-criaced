-- DurkaTeam @ 2025 Никакие права не защищены

include('shared.lua')

ENT.RenderGroup = RENDERGROUP_BOTH

function ENT:Initialize() self.VC_Color = Color(100, 255, 55, 255) self.VC_Length = 225 self.VC_Text = "Vehicle Repair 100%" self.VC_PVsb = util.GetPixelVisibleHandle() end