VCModels['models/crsk_autosuazpatriot_2014_investigation.mdl']	=	{
		em_state	=	5236594398,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Siren	=	{
			Sounds	=	{
					{
					Pitch	=	100,
					Volume	=	1,
					Distance	=	95,
					Name	=	"Wail",
					Sound	=	"vcmod/els/cencom/wail.wav",
						},
					{
					Pitch	=	100,
					Volume	=	1,
					Distance	=	95,
					Name	=	"Yelp",
					Sound	=	"vcmod/els/cencom/yelp.wav",
						},
					{
					Pitch	=	100,
					Volume	=	1,
					Distance	=	95,
					Name	=	"Priority",
					Sound	=	"vcmod/els/cencom/priority.wav",
						},
					},
			Lights	=	{
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	1,
							},
					Dynamic	=	{
						Size	=	1,
						Brightness	=	2,
							},
					RenderInner_Size	=	1,
					UseSprite	=	true,
					Pos	=	Vector(-27.10000038147,-16.969999313354,102.2799987793),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
						r	=	0,
						b	=	255,
						a	=	255,
						g	=	55,
							},
					RenderHD_Adv	=	true,
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner_ClrUse	=	false,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	1,
							},
					Dynamic	=	{
						Size	=	1,
						Brightness	=	2,
							},
					RenderInner	=	true,
					UseSprite	=	true,
					Pos	=	Vector(27.10000038147,-16.969999313354,102.55000305176),
					UseDynamic	=	true,
					RenderInner_Size	=	1,
					Color	=	{
						r	=	0,
						b	=	255,
						a	=	255,
						g	=	55,
							},
					RenderHD_Adv	=	true,
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner_ClrUse	=	false,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	1,
							},
					Dynamic	=	{
						Size	=	1,
						Brightness	=	2,
							},
					RenderInner	=	true,
					UseSprite	=	true,
					Pos	=	Vector(-11.819999694824,-16.969999313354,102.2799987793),
					UseDynamic	=	true,
					RenderInner_Size	=	1,
					Color	=	{
						r	=	0,
						b	=	255,
						a	=	255,
						g	=	55,
							},
					RenderHD_Adv	=	true,
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner_ClrUse	=	false,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	1,
							},
					Dynamic	=	{
						Size	=	1,
						Brightness	=	2,
							},
					UseSprite	=	true,
					SpecModel	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
						scale	=	1,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(12.140000343323,-16.969999313354,102.55000305176),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
						r	=	0,
						b	=	255,
						a	=	255,
						g	=	55,
							},
					RenderInner_Size	=	1,
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner_ClrUse	=	false,
						},
					},
			Sounds_Horn	=	{
				Use	=	true,
				Volume	=	1,
				Distance	=	95,
				Pitch	=	100,
				Sound	=	"vcmod/els/cencom/bullhorn.wav",
					},
			Sequences	=	{
					{
					SubSeq	=	{
							{
							Stages	=	{
									{
									Lights	=	{
											1,
											3,
											},
									Time	=	0.1,
										},
									{
									Lights	=	{
											2,
											4,
											},
									Time	=	0.1,
										},
									},
							Time	=	5,
							Type	=	"Each side",
								},
							},
					Codes	=	{
							true,
							},
					Lights_Sel	=	{
							true,
							true,
							true,
							true,
							},
						},
					{
					SubSeq	=	{
							{
							Stages	=	{
									{
									Lights	=	{
											3,
											2,
											},
									Time	=	0.1,
										},
									{
									Lights	=	{
											1,
											4,
											},
									Time	=	0.1,
										},
									},
							Time	=	5,
							Type	=	"Each half of side",
								},
							},
					Codes	=	{
						[2]	=	true,
							},
					Lights_Sel	=	{
							true,
							true,
							true,
							true,
							},
						},
					{
					SubSeq	=	{
							{
							Stages	=	{
									{
									Lights	=	{
											},
									Time	=	0.1,
										},
									{
									Lights	=	{
											2,
											},
									Time	=	0.1,
										},
									{
									Lights	=	{
											2,
											4,
											},
									Time	=	0.1,
										},
									{
									Lights	=	{
											2,
											4,
											3,
											},
									Time	=	0.1,
										},
									{
									Lights	=	{
											2,
											4,
											3,
											1,
											},
									Time	=	0.1,
										},
									},
							Time	=	2,
							Type	=	"Traffic left",
								},
							},
					Codes	=	{
						[10]	=	true,
							},
					Lights_Sel	=	{
							true,
							true,
							true,
							true,
							},
						},
					{
					SubSeq	=	{
							{
							Stages	=	{
									{
									Lights	=	{
											},
									Time	=	0.1,
										},
									{
									Lights	=	{
											1,
											},
									Time	=	0.1,
										},
									{
									Lights	=	{
											1,
											3,
											},
									Time	=	0.1,
										},
									{
									Lights	=	{
											1,
											3,
											4,
											},
									Time	=	0.1,
										},
									{
									Lights	=	{
											1,
											3,
											4,
											2,
											},
									Time	=	0.1,
										},
									},
							Time	=	2,
							Type	=	"Traffic right",
								},
							},
					Codes	=	{
						[12]	=	true,
							},
					Lights_Sel	=	{
							true,
							true,
							true,
							true,
							},
						},
					{
					SubSeq	=	{
							{
							Stages	=	{
									{
									Lights	=	{
											1,
											2,
											3,
											4,
											},
									Time	=	0.1,
										},
									{
									Lights	=	{
											3,
											4,
											},
									Time	=	0.1,
										},
									{
									Lights	=	{
											},
									Time	=	0.1,
										},
									{
									Lights	=	{
											3,
											4,
											},
									Time	=	0.1,
										},
									},
							Time	=	5,
							Type	=	"Both from middle keep",
								},
							},
					Codes	=	{
						[11]	=	true,
							},
					Lights_Sel	=	{
							true,
							true,
							true,
							true,
							},
						},
					},
			Sounds_Manual	=	{
				Use	=	true,
				Volume	=	1,
				Distance	=	95,
				Pitch	=	100,
				Sound	=	"vcmod/els/cencom/wail.wav",
					},
				},
		Date	=	"Sun Feb 17 14:42:54 2019",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(-20.309999465942,-122.34999847412,21.469999313354),
				EffectIdle	=	"VC_Exhaust",
					},
				},
		Indication	=	{
			fuel	=	{
				max	=	1,
				pp	=	"fuel_needle",
				top	=	1,
					},
				},
		Copyright	=	"Copyright © 2012-2019 VCMod (freemmaann). All Rights Reserved.",
		ExtraSeats	=	{
				{
				Ang	=	Angle(20,0,0),
				Pos	=	Vector(20.659999847412,-4.6999998092651,56.240001678467),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(15,0,0),
				Pos	=	Vector(-20.659999847412,-45.840000152588,56.240001678467),
					},
				{
				Ang	=	Angle(15,0,0),
				Pos	=	Vector(20.659999847412,-45.840000152588,56.240001678467),
					},
				{
				Ang	=	Angle(15,0,0),
				Pos	=	Vector(-1.1299999952316,-45.840000152588,56.240001678467),
					},
				},
		HealthEnginePos	=	Vector(0,64.199996948242,61.909999847412),
		DLT	=	3491062932,
		Lights	=	{
				{
				UseRunning	=	true,
				Pos	=	Vector(-23.979999542236,38.069999694824,67.569999694824),
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				SpecMat	=	{
					Select	=	30,
					New	=	"models\crskautos\shared\vmt\white_illum_on",
					Use	=	true,
						},
					},
				{
				UseRunning	=	true,
				Pos	=	Vector(-28.620000839233,38.069999694824,67.569999694824),
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				SpecMat	=	{
					Select	=	31,
					New	=	"models\crskautos\shared\vmt\red_illum_on",
					Use	=	true,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.135,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-20.14999961853,88.940002441406,53.189998626709),
				UseDynamic	=	true,
				RenderInner_Size	=	1.1882,
				SpecMLine	=	{
					Amount	=	14,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-20.829999923706,89.26000213623,51.740001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-21.920000076294,89.480003356934,50.290000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-23.389999389648,89.319999694824,49.729999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-25.129999160767,88.690002441406,49.75),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-27,87.949996948242,49.950000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-28.64999961853,87.029998779297,49.909999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-29.969999313354,86.23999786377,49.930000305176),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-31.510000228882,85.769996643066,50.279998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-32.900001525879,84.440002441406,50.209999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-34.25,83.580001831055,50.630001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-35.229999542236,82.319999694824,51.439998626709),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-35.880001068115,81.169998168945,52.650001525879),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-36.759998321533,79.5,53.569999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				BlinkerLeft	=	true,
				Pos	=	Vector(-36.580001831055,78.080001831055,55.819999694824),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				BlinkerLeft	=	true,
				Pos	=	Vector(-39.959999084473,-118.05999755859,53.840000152588),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Pos	=	Vector(-36.709999084473,-119.12000274658,53.720001220703),
				UseReverse	=	true,
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				UseBrake	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-38.430000305176,-119.13999938965,48.939998626709),
				UseDynamic	=	true,
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				UseBrake	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-38.200000762939,-119.08999633789,58.439998626709),
				UseDynamic	=	true,
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-27.790000915527,82.900001525879,51.529998779297),
					Pos2	=	Vector(-33.139999389648,82.430000305176,57.180000305176),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-27.879999160767,82.349998474121,56.979999542236),
					Pos3	=	Vector(-33.389999389648,82.98999786377,51.849998474121),
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-30.620000839233,82.48999786377,54.369998931885),
				UseDynamic	=	true,
				RenderInner	=	true,
				UsePrjTex	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				UseRunning	=	true,
				Pos	=	Vector(23.979999542236,38.069999694824,67.569999694824),
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				SpecMat	=	{
					Select	=	30,
					New	=	"models\crskautos\shared\vmt\white_illum_on",
					Use	=	true,
						},
					},
				{
				UseRunning	=	true,
				Pos	=	Vector(28.620000839233,38.069999694824,67.569999694824),
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				SpecMat	=	{
					Select	=	31,
					New	=	"models\crskautos\shared\vmt\red_illum_on",
					Use	=	true,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.135,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_Size	=	1.1882,
				UseSprite	=	true,
				Pos	=	Vector(20.14999961853,88.940002441406,53.189998626709),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	14,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(20.829999923706,89.26000213623,51.740001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(21.920000076294,89.480003356934,50.290000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(23.389999389648,89.319999694824,49.729999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(25.129999160767,88.690002441406,49.75),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(27,87.949996948242,49.950000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(28.64999961853,87.029998779297,49.909999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(29.969999313354,86.23999786377,49.930000305176),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(31.510000228882,85.769996643066,50.279998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(32.900001525879,84.440002441406,50.209999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(34.25,83.580001831055,50.630001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(35.229999542236,82.319999694824,51.439998626709),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(35.880001068115,81.169998168945,52.650001525879),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(36.759998321533,79.5,53.569999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				BlinkerRight	=	true,
				UseBlinkers	=	true,
				Pos	=	Vector(36.580001831055,78.080001831055,55.819999694824),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				BlinkerRight	=	true,
				UseBlinkers	=	true,
				Pos	=	Vector(39.959999084473,-118.05999755859,53.840000152588),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Pos	=	Vector(36.709999084473,-119.12000274658,53.720001220703),
				UseReverse	=	true,
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				UseBrake	=	true,
				UseSprite	=	true,
				Pos	=	Vector(38.430000305176,-119.13999938965,48.939998626709),
				UseDynamic	=	true,
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				UseBrake	=	true,
				UseSprite	=	true,
				Pos	=	Vector(38.200000762939,-119.08999633789,58.439998626709),
				UseDynamic	=	true,
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(27.790000915527,82.900001525879,51.529998779297),
					Pos2	=	Vector(33.139999389648,82.430000305176,57.180000305176),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(27.879999160767,82.349998474121,56.979999542236),
					Pos3	=	Vector(33.389999389648,82.98999786377,51.849998474121),
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseSprite	=	true,
				Pos	=	Vector(30.620000839233,82.48999786377,54.369998931885),
				UseDynamic	=	true,
				RenderInner	=	true,
				UsePrjTex	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				Dynamic	=	{
					Size	=	0.8,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				Pos	=	Vector(34.029998779297,87.349998474121,34.069999694824),
				FogColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				UseFog	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				Dynamic	=	{
					Size	=	0.8,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				Pos	=	Vector(-34.029998779297,87.349998474121,34.069999694824),
				FogColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				UseFog	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-21.370000839233,85.519996643066,50.630001068115),
					Pos2	=	Vector(-28.159999847412,84.940002441406,57.400001525879),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-21.489999771118,85.019996643066,57.299999237061),
					Pos3	=	Vector(-28.379999160767,85.559997558594,50.889999389648),
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				RenderInner	=	true,
				Pos	=	Vector(-24.979999542236,85.029998779297,54.130001068115),
				UseSprite	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(21.370000839233,85.519996643066,50.630001068115),
					Pos2	=	Vector(28.159999847412,84.940002441406,57.400001525879),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(21.489999771118,85.019996643066,57.299999237061),
					Pos3	=	Vector(28.379999160767,85.559997558594,50.889999389648),
						},
				UsePrjTex	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseSprite	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Pos	=	Vector(24.979999542236,85.029998779297,54.130001068115),
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				},
		HealthEnginePosOvr	=	true,
		Fuel	=	{
			FuelLidPos	=	Vector(44.569999694824,-82.23999786377,53.950000762939),
			FuelTypeUse	=	true,
			FuelType	=	0,
			Capacity	=	72,
			Override	=	true,
			FuelLidUse	=	true,
				},
		Author	=	"CrushingSkirmish (76561198017348899)",
}