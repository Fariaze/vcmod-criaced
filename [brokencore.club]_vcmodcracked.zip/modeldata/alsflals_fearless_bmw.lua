VCModels['models/alsflals_fearless_bmw.mdl']	=	{
		em_state	=	5236594467,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Copyright	=	"DurkaTeam @ 2025 No rights reserved",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-45,0),
				Pos	=	Vector(41.799999237061,-16.909999847412,13.140000343323),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-45,0),
				Pos	=	Vector(41.799999237061,-11.539999961853,13.140000343323),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(17,10.060000419617,28.10000038147),
				RadioControl	=	true,
					},
				},
		DLT	=	3491062978,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseReverse	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				UseDynamic	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-20.989999771118,-105.08000183105,40.060001373291),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(-31.440000534058,-103.75,43.560001373291),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				RenderInner_Size	=	1.2,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				UseRunning	=	true,
				UseSprite	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				Pos	=	Vector(-31.420000076294,-104.31999969482,39.619998931885),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				UseRunning	=	true,
				UseSprite	=	true,
				RunningColor	=	{
						209.86,
						191.05,
						235.58,
						},
				Pos	=	Vector(-21.579999923706,96.730003356934,31.319999694824),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseHead	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-28.64999961853,95.639999389648,31.079999923706),
				UseDynamic	=	true,
				HeadColor	=	{
						199,
						202,
						255,
						},
				UsePrjTex	=	true,
				ProjTexture	=	{
					Forward	=	30,
					Size	=	2000,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(-35.389999389648,92.860000610352,30.770000457764),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				RenderInner_Size	=	1.2,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(-41.270000457764,45.740001678467,26.870000839233),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				RenderInner_Size	=	1.2,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseReverse	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				UseDynamic	=	true,
				UseSprite	=	true,
				Pos	=	Vector(20.989999771118,-105.08000183105,40.060001373291),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(31.440000534058,-103.75,43.560001373291),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				RenderInner_Size	=	1.2,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				UseRunning	=	true,
				UseSprite	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				Pos	=	Vector(31.420000076294,-104.31999969482,39.619998931885),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				UseRunning	=	true,
				UseSprite	=	true,
				RunningColor	=	{
						209.86,
						191.05,
						235.58,
						},
				Pos	=	Vector(21.579999923706,96.730003356934,31.319999694824),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseHead	=	true,
				UsePrjTex	=	true,
				Pos	=	Vector(28.64999961853,95.639999389648,31.079999923706),
				UseDynamic	=	true,
				HeadColor	=	{
						199,
						202,
						255,
						},
				ProjTexture	=	{
					Forward	=	30,
					Size	=	2000,
					Angle	=	Angle(0,90,0),
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(35.389999389648,92.860000610352,30.770000457764),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				RenderInner_Size	=	1.2,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(41.270000457764,45.740001678467,26.870000839233),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				RenderInner_Size	=	1.2,
				Beta_Inner3D	=	true,
					},
				},
		Date	=	"07/08/15 00:38:27",
		Author	=	"freemmaann (STEAM_0:1:14528726)",
}