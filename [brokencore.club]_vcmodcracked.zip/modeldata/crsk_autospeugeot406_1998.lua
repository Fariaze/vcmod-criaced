VCModels['models/crsk_autospeugeot406_1998.mdl']	=	{
		em_state	=	5236594602,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Copyright	=	"Copyright © 2012-2018 VCMod (freemmaann). All Rights Reserved.",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-23.760000228882,-111.81999969482,14.890000343323),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(15,0,0),
				Pos	=	Vector(16.799999237061,18.090000152588,31.129999160767),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(15,0,0),
				Pos	=	Vector(-20.190000534058,-29.229999542236,33.040000915527),
					},
				{
				Ang	=	Angle(15,0,0),
				Pos	=	Vector(19.930000305176,-29.229999542236,33.040000915527),
					},
				{
				Ang	=	Angle(15,0,0),
				Pos	=	Vector(0,-29.229999542236,33.040000915527),
					},
				},
		DLT	=	3491063068,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				RunningColor	=	{
					r	=	247,
					b	=	255,
					a	=	255,
					g	=	243,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(23.60000038147,111.08000183105,31.64999961853),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				UseRunning	=	true,
				RunningColor	=	{
					r	=	247,
					b	=	255,
					a	=	255,
					g	=	243,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-23.049999237061,111.08000183105,31.64999961853),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				Beta_Inner3D	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Pos	=	Vector(-31.75,105.70999908447,32.380001068115),
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	247,
					b	=	255,
					a	=	255,
					g	=	243,
						},
				UseDynamic	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseSprite	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Pos	=	Vector(32.349998474121,105.70999908447,32.380001068115),
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	247,
					b	=	255,
					a	=	255,
					g	=	243,
						},
				UseDynamic	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-38.159999847412,102.05999755859,34.590000152588),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-37.720001220703,102.91000366211,32.909999847412),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-37.759998321533,103.51000213623,31.459999084473),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(38.159999847412,103.51000213623,31.459999084473),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(38.299999237061,102.91000366211,32.909999847412),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(38.470001220703,102.05999755859,34.590000152588),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-25.090000152588,-107.20999908447,38.119998931885),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	11,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-29.610000610352,-105.76999664307,37.909999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.459999084473,-104.83000183105,37.990001678467),
								},
							},
						},
				UseRunning	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(25.090000152588,-107.20999908447,38.119998931885),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	11,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(29.610000610352,-105.76999664307,37.909999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.459999084473,-104.83000183105,37.990001678467),
								},
							},
						},
				UseRunning	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(37.119998931885,-104.44000244141,42.270000457764),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-37.119998931885,-104.44000244141,42.270000457764),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.08,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-25.860000610352,-106.58999633789,41.029998779297),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	9,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-29.889999389648,-105.98999786377,41.509998321533),
								},
							},
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.08,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(25.860000610352,-106.58999633789,41.029998779297),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	9,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(29.889999389648,-105.98999786377,41.509998321533),
								},
							},
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-33.400001525879,-105.73000335693,42.349998474121),
				UseDynamic	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(33.400001525879,-105.73000335693,42.349998474121),
				UseDynamic	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				UsePrjTex	=	true,
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RenderMLCenter	=	true,
				FogColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-25.489999771118,111.37999725342,17.010000228882),
				RenderInner	=	true,
				RenderInner_Size	=	3,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-27.889999389648,110.0299987793,17.040000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.85000038147,108.16000366211,17.129999160767),
								},
							{
							Pos	=	Vector(-33.990001678467,107.18000030518,17.14999961853),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseFog	=	true,
				RenderHD_Adv	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				UsePrjTex	=	true,
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RenderMLCenter	=	true,
				FogColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderHD_Adv	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(25.489999771118,111.37999725342,17.010000228882),
				RenderInner	=	true,
				RenderInner_Size	=	3,
				UseFog	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(27.889999389648,110.0299987793,17.040000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.85000038147,108.16000366211,17.129999160767),
								},
							{
							Pos	=	Vector(33.990001678467,107.18000030518,17.14999961853),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseSprite	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				Beta_Inner3D	=	true,
				SpecMat	=	{
						},
				HBeamColor	=	{
					r	=	247,
					b	=	255,
					a	=	255,
					g	=	243,
						},
				ReducedVis	=	true,
				RenderInner	=	true,
				UsePrjTex	=	true,
				Pos	=	Vector(23.60000038147,111.08000183105,31.64999961853),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				UseSprite	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				UsePrjTex	=	true,
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				HBeamColor	=	{
					r	=	247,
					b	=	255,
					a	=	255,
					g	=	243,
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-23.049999237061,111.08000183105,31.64999961853),
				RenderInner_Size	=	1,
				SpecMat	=	{
						},
				UseSprite	=	true,
				RenderInner	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.01,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					Use	=	true,
					Pos2	=	Vector(-15.439999580383,38.209999084473,45.689998626709),
					Pos4	=	Vector(-15.439999580383,38.209999084473,45.689998626709),
					Pos1	=	Vector(-15.439999580383,38.209999084473,45.689998626709),
					Pos3	=	Vector(-15.439999580383,38.209999084473,45.689998626709),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				IsInterior	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-15.449999809265,38.209999084473,45.720001220703),
				UseBlinkers	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-15.109999656677,38.080001831055,45.360000610352),
					UseColor	=	true,
					Pos2	=	Vector(-15.770000457764,38.340000152588,46.020000457764),
					Color	=	{
						r	=	55,
						b	=	0,
						a	=	255,
						g	=	255,
							},
					Use	=	true,
					Pos1	=	Vector(-15.109999656677,38.340000152588,46.020000457764),
					Pos3	=	Vector(-15.770000457764,38.080001831055,45.360000610352),
						},
				Beta_Inner3D	=	true,
				BlinkersColor	=	{
					r	=	55,
					b	=	0,
					a	=	255,
					g	=	255,
						},
				BlinkerRight	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.01,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-17.329999923706,38.080001831055,45.360000610352),
					UseColor	=	true,
					Pos2	=	Vector(-17.989999771118,38.340000152588,46.020000457764),
					Color	=	{
						r	=	55,
						b	=	0,
						a	=	255,
						g	=	255,
							},
					Use	=	true,
					Pos1	=	Vector(-17.329999923706,38.340000152588,46.020000457764),
					Pos3	=	Vector(-17.989999771118,38.080001831055,45.360000610352),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				IsInterior	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-17.670000076294,38.209999084473,45.720001220703),
				UseBlinkers	=	true,
				UseSprite	=	true,
				BlinkersColor	=	{
					r	=	55,
					b	=	0,
					a	=	255,
					g	=	255,
						},
				SpecRec	=	{
					Pos4	=	Vector(-17.659999847412,38.209999084473,45.689998626709),
					Pos2	=	Vector(-17.659999847412,38.209999084473,45.689998626709),
					Use	=	true,
					Pos1	=	Vector(-17.659999847412,38.209999084473,45.689998626709),
					Pos3	=	Vector(-17.659999847412,38.209999084473,45.689998626709),
						},
					},
				},
		Date	=	"Wed Jan 24 22:55:45 2018",
		Fuel	=	{
			FuelLidPos	=	Vector(41.729999542236,-70.779998779297,42.229999542236),
			FuelType	=	0,
			Capacity	=	70,
			FuelLidUse	=	true,
			Override	=	true,
				},
		Author	=	"CreeperTv (76561198051637331)",
}