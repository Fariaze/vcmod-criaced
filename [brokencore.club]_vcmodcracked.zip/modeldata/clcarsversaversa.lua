VCModels['models/clcarsversaversa.mdl']	=	{
		em_state	=	5236595046,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Copyright	=	"Copyright © 2012-2018 VCMod (freemmaann). All Rights Reserved.",
		Exhaust	=	{
				{
				Ang	=	Angle(38.099998474121,-90,0),
				Pos	=	Vector(-15.539999961853,-91.839996337891,11.930000305176),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(16.559999465942,15,31.659999847412),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(-16.559999465942,-30.370000839233,29.659999847412),
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(16.559999465942,-30.370000839233,29.659999847412),
					},
				},
		DLT	=	3491063364,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/stadium_2x4",
					Pos4	=	Vector(35.299999237061,80.860000610352,28.659999847412),
					Pos2	=	Vector(24.729999542236,83.449996948242,36.549999237061),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(34.040000915527,80.25,36.860000610352),
					Pos3	=	Vector(25.739999771118,84.5,29.030000686646),
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Pos	=	Vector(30.120000839233,82.199996948242,32.909999847412),
				UseSprite	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/stadium_2x4",
					Pos4	=	Vector(35.229999542236,80.860000610352,28.659999847412),
					Pos2	=	Vector(24.659999847412,83.449996948242,36.549999237061),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(33.970001220703,80.25,36.860000610352),
					Pos3	=	Vector(25.670000076294,84.5,29.030000686646),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(30.049999237061,82.199996948242,32.909999847412),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
					r	=	195,
					b	=	225,
					a	=	255,
					g	=	195,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/stadium_2x4_texture",
					Pos4	=	Vector(29.620000839233,77.069999694824,38.389999389648),
					Pos2	=	Vector(32.700000762939,77.040000915527,36.409999847412),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(29.620000839233,76.870002746582,36.409999847412),
					Pos3	=	Vector(32.700000762939,77.309997558594,38.240001678467),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(31.159999847412,77.160003662109,37.950000762939),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/stadium_2x4_texture",
					Pos4	=	Vector(22.979999542236,87.76000213623,32.389999389648),
					Pos2	=	Vector(26.969999313354,89.98999786377,28.870000839233),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(20.409999847412,91.430000305176,28.620000839233),
					Pos3	=	Vector(25.010000228882,88.209999084473,32.580001831055),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(23.979999542236,89.580001831055,30.229999542236),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(32.639999389648,86.559997558594,15.85000038147),
					Pos2	=	Vector(27.719999313354,86.559997558594,20.770000457764),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(32.639999389648,86.559997558594,20.770000457764),
					Pos3	=	Vector(27.719999313354,86.559997558594,15.85000038147),
						},
				FogColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UsePrjTex	=	true,
				Pos	=	Vector(30.180000305176,86.559997558594,18.309999465942),
				UseDynamic	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseFog	=	true,
				Dynamic	=	{
					Size	=	0.8,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(32.349998474121,-87.720001220703,38.639999389648),
					Pos2	=	Vector(26.489999771118,-87.360000610352,44.520000457764),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(32.360000610352,-86.709999084473,44.419998168945),
					Pos3	=	Vector(26.479999542236,-88.370002746582,38.740001678467),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(29.420000076294,-87.540000915527,41.580001831055),
				UseDynamic	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				Beta_Inner3D	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(23.840000152588,-89.309997558594,41.490001678467),
					Pos2	=	Vector(28.799999237061,-88.970001220703,36.450000762939),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(23.889999389648,-90.129997253418,36.560001373291),
					Pos3	=	Vector(28.75,-88.150001525879,41.380001068115),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(26.319999694824,-89.139999389648,38.970001220703),
				UseDynamic	=	true,
				ReverseColor	=	{
					r	=	255,
					b	=	149,
					a	=	255,
					g	=	185,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(35.680000305176,-84.589996337891,40.229999542236),
					Pos2	=	Vector(29.60000038147,-84.269996643066,46.389999389648),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(35.520000457764,-82.400001525879,45.909999847412),
					Pos3	=	Vector(29.760000228882,-86.459999084473,40.709999084473),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(32.639999389648,-84.430000305176,43.310001373291),
				UseDynamic	=	true,
				UseSprite	=	true,
				UseRunning	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/stadium_2x4",
					Pos4	=	Vector(-35.299999237061,80.860000610352,28.659999847412),
					Pos2	=	Vector(-24.729999542236,83.449996948242,36.549999237061),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-34.040000915527,80.25,36.860000610352),
					Pos3	=	Vector(-25.739999771118,84.5,29.030000686646),
						},
				SpecMat	=	{
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				ReducedVis	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Pos	=	Vector(-30.120000839233,82.199996948242,32.909999847412),
				Beta_Inner3D	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/stadium_2x4",
					Pos4	=	Vector(-35.229999542236,80.860000610352,28.659999847412),
					Pos2	=	Vector(-24.659999847412,83.449996948242,36.549999237061),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-33.970001220703,80.25,36.860000610352),
					Pos3	=	Vector(-25.670000076294,84.5,29.030000686646),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-30.049999237061,82.199996948242,32.909999847412),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseSprite	=	true,
				RunningColor	=	{
					r	=	195,
					b	=	225,
					a	=	255,
					g	=	195,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/stadium_2x4_texture",
					Pos4	=	Vector(-29.620000839233,77.069999694824,38.389999389648),
					Pos2	=	Vector(-32.700000762939,77.040000915527,36.409999847412),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-29.620000839233,76.870002746582,36.409999847412),
					Pos3	=	Vector(-32.700000762939,77.309997558594,38.240001678467),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-31.159999847412,77.160003662109,37.950000762939),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseSprite	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-23.979999542236,89.580001831055,30.229999542236),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/stadium_2x4_texture",
					Pos4	=	Vector(-22.979999542236,87.76000213623,32.389999389648),
					Pos2	=	Vector(-26.969999313354,89.98999786377,28.870000839233),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-20.409999847412,91.430000305176,28.620000839233),
					Pos3	=	Vector(-25.010000228882,88.209999084473,32.580001831055),
						},
				UseBlinkers	=	true,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-32.639999389648,86.559997558594,15.85000038147),
					Pos2	=	Vector(-27.719999313354,86.559997558594,20.770000457764),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-32.639999389648,86.559997558594,20.770000457764),
					Pos3	=	Vector(-27.719999313354,86.559997558594,15.85000038147),
						},
				FogColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UsePrjTex	=	true,
				Pos	=	Vector(-30.180000305176,86.559997558594,18.309999465942),
				UseDynamic	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseFog	=	true,
				Dynamic	=	{
					Size	=	0.8,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-29.420000076294,-87.540000915527,41.580001831055),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-32.349998474121,-87.720001220703,38.639999389648),
					Pos2	=	Vector(-26.489999771118,-87.360000610352,44.520000457764),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-32.360000610352,-86.709999084473,44.419998168945),
					Pos3	=	Vector(-26.479999542236,-88.370002746582,38.740001678467),
						},
				UseSprite	=	true,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(-23.840000152588,-89.309997558594,41.490001678467),
					Pos2	=	Vector(-28.799999237061,-88.970001220703,36.450000762939),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-23.889999389648,-90.129997253418,36.560001373291),
					Pos3	=	Vector(-28.75,-88.150001525879,41.380001068115),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-26.319999694824,-89.139999389648,38.970001220703),
				UseDynamic	=	true,
				ReverseColor	=	{
					r	=	255,
					b	=	149,
					a	=	255,
					g	=	185,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(-35.680000305176,-84.589996337891,40.229999542236),
					Pos2	=	Vector(-29.60000038147,-84.269996643066,46.389999389648),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-35.520000457764,-82.400001525879,45.909999847412),
					Pos3	=	Vector(-29.760000228882,-86.459999084473,40.709999084473),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseRunning	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-32.639999389648,-84.430000305176,43.310001373291),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				Beta_Inner3D	=	true,
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBrake	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-3.0899999141693,-71.680000305176,66.51000213623),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	6,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(3.0899999141693,-71.680000305176,66.51000213623),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				},
		Date	=	"Tue Mar  6 20:29:24 2018",
		Fuel	=	{
			FuelLidPos	=	Vector(37.220001220703,-63.049999237061,40.680000305176),
			FuelTypeUse	=	true,
			FuelLidUse	=	true,
			FuelType	=	0,
				},
		Author	=	"cynaraos (76561198047818115)",
}