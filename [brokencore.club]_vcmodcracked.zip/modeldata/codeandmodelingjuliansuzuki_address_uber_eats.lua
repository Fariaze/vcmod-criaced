VCModels['models/codeandmodelingjuliansuzuki_address_uber_eats.mdl']	=	{
		em_state	=	5236594932,
		DLT	=	3491063288,
		Date	=	"Sat Mar 28 00:23:48 2020",
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(0,23.370000839233,28.090000152588),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				PosAtc	=	{
					type	=	"Bone",
					offset	=	Vector(35.200000762939,-17.799999237061,0),
					id	=	17,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				PosAtc	=	{
					type	=	"Bone",
					offset	=	Vector(36.400001525879,-13.10000038147,6.0999999046326),
					id	=	17,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseSprite	=	true,
				Pos	=	Vector(0,23.370000839233,28.090000152588),
				UseDynamic	=	true,
				RenderInner_Size	=	4,
				RenderInner	=	true,
				UseBlinkers	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				PosAtc	=	{
					type	=	"Bone",
					offset	=	Vector(36.400001525879,-13.10000038147,-6.0999999046326),
					id	=	17,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				UseSprite	=	true,
				Pos	=	Vector(0,23.370000839233,28.090000152588),
				UseDynamic	=	true,
				RenderInner_Size	=	4,
				RenderInner	=	true,
				UseBlinkers	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				PosAtc	=	{
					type	=	"Bone",
					offset	=	Vector(13.10000038147,0,25.89999961853),
					id	=	15,
						},
				UseSprite	=	true,
				Pos	=	Vector(0,23.370000839233,28.090000152588),
				UseDynamic	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseRunning	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseSprite	=	true,
				Pos	=	Vector(0,23.370000839233,28.090000152588),
				UseDynamic	=	true,
				PosAtc	=	{
					type	=	"Bone",
					offset	=	Vector(14,4.0999999046326,24.60000038147),
					id	=	15,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseSprite	=	true,
				Pos	=	Vector(0,23.370000839233,28.090000152588),
				UseDynamic	=	true,
				PosAtc	=	{
					type	=	"Bone",
					offset	=	Vector(14,-4.0999999046326,24.60000038147),
					id	=	15,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseBlinkers	=	true,
					},
				},
		Copyright	=	"Copyright © 2020 VCMod (freemmaann). All Rights Reserved.",
		Author	=	"Azok30 - CODEMODELING.fr (76561198183398967)",
}