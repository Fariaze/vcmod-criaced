VCModels['models/azok30renault_midlum_pse_2.mdl']	=	{
		IsBig	=	true,
		em_state	=	5236594431,
		animDriverPosUse	=	true,
		Siren	=	{
			Sounds	=	{
					{
					Pitch	=	100,
					Volume	=	1,
					Distance	=	95,
					Name	=	"Hi-Lo",
					Sound	=	"emv/sirens/french/fr_vsav-ar.wav",
						},
					},
			Sections	=	{
					{
						true,
						true,
						},
					},
			Lights	=	{
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.2,
							},
					Dynamic	=	{
						Size	=	1,
						Brightness	=	2,
							},
					RenderInner_Size	=	1,
					SpecModel	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
						scale	=	1,
						scaleVector	=	Vector(1000,1000,1000),
						glow	=	{
							Color	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
					UseSprite	=	true,
					Pos	=	Vector(-19.409999847412,124.62000274658,46.970001220703),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
						r	=	0,
						b	=	255,
						a	=	255,
						g	=	55,
							},
					SpecMLine	=	{
						Amount	=	6,
						Use	=	true,
						LTbl	=	{
								{
								Pos	=	Vector(-15.029999732971,124.9700012207,46.979999542236),
								UseClr	=	false,
								Clr	=	{
									r	=	0,
									b	=	0,
									a	=	255,
									g	=	0,
										},
									},
								},
							},
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner_ClrUse	=	false,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.2,
							},
					Dynamic	=	{
						Size	=	1,
						Brightness	=	2,
							},
					RenderInner	=	true,
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					UseSprite	=	true,
					Pos	=	Vector(18.409999847412,124.62000274658,46.970001220703),
					UseDynamic	=	true,
					RenderInner_Size	=	1,
					SpecMLine	=	{
						Amount	=	6,
						Use	=	true,
						LTbl	=	{
								{
								Pos	=	Vector(14.029999732971,124.9700012207,46.979999542236),
								UseClr	=	false,
								Clr	=	{
									r	=	0,
									b	=	0,
									a	=	255,
									g	=	0,
										},
									},
								},
							},
					Color	=	{
						r	=	0,
						b	=	255,
						a	=	255,
						g	=	55,
							},
					SpecModel	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
						scale	=	1,
						scaleVector	=	Vector(1000,1000,1000),
						glow	=	{
							Color	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
					RenderInner_ClrUse	=	false,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.2,
							},
					SpecSpin	=	{
						Intensity	=	1,
						Offset	=	0,
						Use	=	true,
						Speed	=	500,
							},
					Spec3D	=	{
						Mat	=	"vcmod/circle",
						Pos4	=	Vector(-25.389999389648,95.720001220703,99.669998168945),
						Pos2	=	Vector(-27.389999389648,95.720001220703,101.66999816895),
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
						Use	=	true,
						Pos1	=	Vector(-25.389999389648,95.720001220703,101.66999816895),
						Pos3	=	Vector(-27.389999389648,95.720001220703,99.669998168945),
							},
					Dynamic	=	{
						Size	=	1,
						Brightness	=	2,
							},
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					UseSprite	=	true,
					Pos	=	Vector(-26.389999389648,95.720001220703,100.66999816895),
					UseDynamic	=	true,
					RenderInner_Size	=	1,
					Color	=	{
						r	=	0,
						b	=	255,
						a	=	255,
						g	=	55,
							},
					RenderInner	=	true,
					SpecModel	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
						scale	=	1,
						scaleVector	=	Vector(1000,1000,1000),
						glow	=	{
							Color	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
					RenderInner_ClrUse	=	false,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.2,
							},
					SpecSpin	=	{
						Intensity	=	1,
						Offset	=	90,
						Use	=	true,
						Speed	=	500,
							},
					Spec3D	=	{
						Mat	=	"vcmod/circle",
						Pos4	=	Vector(25.010000228882,95.720001220703,99.669998168945),
						Pos2	=	Vector(27.010000228882,95.720001220703,101.66999816895),
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
						Use	=	true,
						Pos1	=	Vector(25.010000228882,95.720001220703,101.66999816895),
						Pos3	=	Vector(27.010000228882,95.720001220703,99.669998168945),
							},
					Dynamic	=	{
						Size	=	1,
						Brightness	=	2,
							},
					SpecModel	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
						scale	=	1,
						scaleVector	=	Vector(1000,1000,1000),
						glow	=	{
							Color	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
					UseSprite	=	true,
					Pos	=	Vector(26.010000228882,95.720001220703,100.66999816895),
					UseDynamic	=	true,
					RenderInner_Size	=	1,
					Color	=	{
						r	=	0,
						b	=	255,
						a	=	255,
						g	=	55,
							},
					RenderInner	=	true,
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner_ClrUse	=	false,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.2,
							},
					SpecSpin	=	{
						Intensity	=	1,
						Offset	=	0,
						Use	=	true,
						Speed	=	500,
							},
					Spec3D	=	{
						Mat	=	"vcmod/circle",
						Pos4	=	Vector(15.800000190735,95.720001220703,99.669998168945),
						Pos2	=	Vector(13.800000190735,95.720001220703,101.66999816895),
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
						Use	=	true,
						Pos1	=	Vector(15.800000190735,95.720001220703,101.66999816895),
						Pos3	=	Vector(13.800000190735,95.720001220703,99.669998168945),
							},
					Dynamic	=	{
						Size	=	1,
						Brightness	=	2,
							},
					SpecModel	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
						scale	=	1,
						scaleVector	=	Vector(1000,1000,1000),
						glow	=	{
							Color	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
					UseSprite	=	true,
					Pos	=	Vector(14.800000190735,95.720001220703,100.66999816895),
					UseDynamic	=	true,
					RenderInner_Size	=	1,
					Color	=	{
						r	=	0,
						b	=	255,
						a	=	255,
						g	=	55,
							},
					RenderInner	=	true,
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner_ClrUse	=	false,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.2,
							},
					SpecSpin	=	{
						Intensity	=	1,
						Offset	=	-90,
						Use	=	true,
						Speed	=	500,
							},
					Spec3D	=	{
						Mat	=	"vcmod/circle",
						Pos4	=	Vector(-15.800000190735,95.720001220703,99.669998168945),
						Pos2	=	Vector(-13.800000190735,95.720001220703,101.66999816895),
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
						Use	=	true,
						Pos1	=	Vector(-15.800000190735,95.720001220703,101.66999816895),
						Pos3	=	Vector(-13.800000190735,95.720001220703,99.669998168945),
							},
					Dynamic	=	{
						Size	=	1,
						Brightness	=	2,
							},
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					UseSprite	=	true,
					Pos	=	Vector(-14.800000190735,95.720001220703,100.66999816895),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
						r	=	0,
						b	=	255,
						a	=	255,
						g	=	55,
							},
					RenderInner_Size	=	1,
					SpecModel	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
						scale	=	1,
						scaleVector	=	Vector(1000,1000,1000),
						glow	=	{
							Color	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
					RenderInner_ClrUse	=	false,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.2,
							},
					SpecSpin	=	{
						Intensity	=	1,
						Offset	=	0,
						Use	=	true,
						Speed	=	500,
							},
					Spec3D	=	{
						Mat	=	"vcmod/circle",
						Pos4	=	Vector(32.720001220703,-113.48000335693,105.83999633789),
						Pos2	=	Vector(34.720001220703,-113.48000335693,107.83999633789),
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
						Use	=	true,
						Pos1	=	Vector(32.720001220703,-113.48000335693,107.83999633789),
						Pos3	=	Vector(34.720001220703,-113.48000335693,105.83999633789),
							},
					Dynamic	=	{
						Size	=	1,
						Brightness	=	2,
							},
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					UseSprite	=	true,
					Pos	=	Vector(33.720001220703,-113.48000335693,106.83999633789),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
						r	=	0,
						b	=	255,
						a	=	255,
						g	=	55,
							},
					RenderInner_Size	=	1,
					SpecModel	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
						scale	=	1,
						scaleVector	=	Vector(1000,1000,1000),
						glow	=	{
							Color	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
					RenderInner_ClrUse	=	false,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.2,
							},
					SpecSpin	=	{
						Intensity	=	1,
						Offset	=	-90,
						Use	=	true,
						Speed	=	500,
							},
					Spec3D	=	{
						Mat	=	"vcmod/circle",
						Pos4	=	Vector(-3.75,-113.48000335693,105.83999633789),
						Pos2	=	Vector(-5.75,-113.48000335693,107.83999633789),
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
						Use	=	true,
						Pos1	=	Vector(-3.75,-113.48000335693,107.83999633789),
						Pos3	=	Vector(-5.75,-113.48000335693,105.83999633789),
							},
					Dynamic	=	{
						Size	=	1,
						Brightness	=	2,
							},
					SpecModel	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
						scale	=	1,
						scaleVector	=	Vector(1000,1000,1000),
						glow	=	{
							Color	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
					UseSprite	=	true,
					Pos	=	Vector(-4.75,-113.48000335693,106.83999633789),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
						r	=	0,
						b	=	255,
						a	=	255,
						g	=	55,
							},
					RenderInner_Size	=	1,
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner_ClrUse	=	false,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.2,
							},
					Dynamic	=	{
						Size	=	0.6,
						Brightness	=	2.1,
							},
					Spec3D	=	{
						Mat	=	"vcmod/lights/3d/rectangle_rounded_2x8",
						Pos4	=	Vector(29.659999847412,-117.90000152588,105.18000030518),
						Pos2	=	Vector(25.920000076294,-117.90000152588,109.11000061035),
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
						Use	=	true,
						Pos1	=	Vector(29.659999847412,-117.90000152588,109.12000274658),
						Pos3	=	Vector(25.920000076294,-117.90000152588,105.18000030518),
							},
					RenderInner_Size	=	1,
					SpecModel	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
						scale	=	1,
						scaleVector	=	Vector(1000,1000,1000),
						glow	=	{
							Color	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(27.790000915527,-117.90000152588,107.15000152588),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	155,
							},
					UseSprite	=	true,
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner_ClrUse	=	false,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.2,
							},
					Dynamic	=	{
						Size	=	0.6,
						Brightness	=	2.1,
							},
					Spec3D	=	{
						Mat	=	"vcmod/lights/3d/rectangle_rounded_2x8",
						Pos4	=	Vector(24.309999465942,-117.90000152588,105.18000030518),
						Pos2	=	Vector(20.569999694824,-117.90000152588,109.11000061035),
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
						Use	=	true,
						Pos1	=	Vector(24.309999465942,-117.90000152588,109.12000274658),
						Pos3	=	Vector(20.569999694824,-117.90000152588,105.18000030518),
							},
					RenderInner_Size	=	1,
					SpecModel	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
						scale	=	1,
						scaleVector	=	Vector(1000,1000,1000),
						glow	=	{
							Color	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
					UseSprite	=	true,
					Pos	=	Vector(22.440000534058,-117.90000152588,107.15000152588),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	155,
							},
					RenderHD_Adv	=	true,
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner_ClrUse	=	false,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.2,
							},
					Dynamic	=	{
						Size	=	0.6,
						Brightness	=	2.1,
							},
					Spec3D	=	{
						Mat	=	"vcmod/lights/3d/rectangle_rounded_2x8",
						Pos4	=	Vector(18.909999847412,-117.90000152588,105.18000030518),
						Pos2	=	Vector(15.170000076294,-117.90000152588,109.11000061035),
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
						Use	=	true,
						Pos1	=	Vector(18.909999847412,-117.90000152588,109.12000274658),
						Pos3	=	Vector(15.170000076294,-117.90000152588,105.18000030518),
							},
					RenderInner	=	true,
					SpecModel	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
						scale	=	1,
						scaleVector	=	Vector(1000,1000,1000),
						glow	=	{
							Color	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(17.040000915527,-117.90000152588,107.15000152588),
					UseDynamic	=	true,
					RenderInner_Size	=	1,
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	155,
							},
					UseSprite	=	true,
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner_ClrUse	=	false,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.2,
							},
					Dynamic	=	{
						Size	=	0.6,
						Brightness	=	2.1,
							},
					Spec3D	=	{
						Mat	=	"vcmod/lights/3d/rectangle_rounded_2x8",
						Pos4	=	Vector(13.569999694824,-117.90000152588,105.18000030518),
						Pos2	=	Vector(9.8299999237061,-117.90000152588,109.11000061035),
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
						Use	=	true,
						Pos1	=	Vector(13.569999694824,-117.90000152588,109.12000274658),
						Pos3	=	Vector(9.8299999237061,-117.90000152588,105.18000030518),
							},
					RenderInner	=	true,
					SpecModel	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
						scale	=	1,
						scaleVector	=	Vector(1000,1000,1000),
						glow	=	{
							Color	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
					UseSprite	=	true,
					Pos	=	Vector(11.699999809265,-117.90000152588,107.15000152588),
					UseDynamic	=	true,
					RenderInner_Size	=	1,
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	155,
							},
					RenderHD_Adv	=	true,
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner_ClrUse	=	false,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.2,
							},
					Dynamic	=	{
						Size	=	0.6,
						Brightness	=	2.1,
							},
					Spec3D	=	{
						Mat	=	"vcmod/lights/3d/rectangle_rounded_2x8",
						Pos4	=	Vector(8.3699998855591,-117.90000152588,105.18000030518),
						Pos2	=	Vector(4.6300001144409,-117.90000152588,109.11000061035),
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
						Use	=	true,
						Pos1	=	Vector(8.3699998855591,-117.90000152588,109.12000274658),
						Pos3	=	Vector(4.6300001144409,-117.90000152588,105.18000030518),
							},
					RenderInner_Size	=	1,
					SpecModel	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
						scale	=	1,
						scaleVector	=	Vector(1000,1000,1000),
						glow	=	{
							Color	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(6.5,-117.90000152588,107.15000152588),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	155,
							},
					UseSprite	=	true,
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner_ClrUse	=	false,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.2,
							},
					Dynamic	=	{
						Size	=	0.6,
						Brightness	=	2.1,
							},
					Spec3D	=	{
						Mat	=	"vcmod/lights/3d/rectangle_rounded_2x8",
						Pos4	=	Vector(3.0499999523163,-117.90000152588,105.18000030518),
						Pos2	=	Vector(-0.68999999761581,-117.90000152588,109.11000061035),
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
						Use	=	true,
						Pos1	=	Vector(3.0499999523163,-117.90000152588,109.12000274658),
						Pos3	=	Vector(-0.68999999761581,-117.90000152588,105.18000030518),
							},
					RenderInner_Size	=	1,
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(1.1799999475479,-117.90000152588,107.15000152588),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	155,
							},
					UseSprite	=	true,
					SpecModel	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
						scale	=	1,
						scaleVector	=	Vector(1000,1000,1000),
						glow	=	{
							Color	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
					RenderInner_ClrUse	=	false,
						},
					},
			Sounds_Horn	=	{
				Use	=	true,
				Volume	=	1,
				Distance	=	95,
				Pitch	=	100,
				Sound	=	"vcmod/els/smartsiren/horn.wav",
					},
			Sequences	=	{
					{
					SubSeq	=	{
							{
							ovr_clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Stages	=	{
									{
									Lights	=	{
											1,
											},
									Time	=	0.5,
										},
									{
									Lights	=	{
											2,
											},
									Time	=	0.5,
									ovr_clr	=	{
										r	=	0,
										b	=	0,
										a	=	255,
										g	=	0,
											},
									ovr_clr_use	=	false,
										},
									},
							Time	=	5,
							Type	=	"Each side",
							ovr_clr_use	=	false,
								},
							},
					Codes	=	{
							true,
							},
					Lights_Sel	=	{
							true,
							true,
							},
						},
					{
					SubSeq	=	{
							{
							ovr_clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Stages	=	{
									{
									Lights	=	{
											1,
											},
									Time	=	0.3,
									ovr_clr	=	{
										r	=	0,
										b	=	0,
										a	=	255,
										g	=	0,
											},
									ovr_clr_use	=	false,
										},
									{
									Lights	=	{
											2,
											},
									Time	=	0.3,
									ovr_clr	=	{
										r	=	0,
										b	=	0,
										a	=	255,
										g	=	0,
											},
									ovr_clr_use	=	false,
										},
									},
							Time	=	5,
							Type	=	"Each side",
							ovr_clr_use	=	false,
								},
							},
					Codes	=	{
						[2]	=	true,
							},
					Lights_Sel	=	{
							true,
							true,
							},
						},
					{
					SubSeq	=	{
							{
							ovr_clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Stages	=	{
									{
									Lights	=	{
											1,
											},
									Time	=	0.1,
										},
									{
									Lights	=	{
											2,
											},
									Time	=	0.1,
									ovr_clr	=	{
										r	=	0,
										b	=	0,
										a	=	255,
										g	=	0,
											},
									ovr_clr_use	=	false,
										},
									},
							Time	=	5,
							Type	=	"Each side",
							ovr_clr_use	=	false,
								},
							},
					Codes	=	{
						[3]	=	true,
							},
					Lights_Sel	=	{
							true,
							true,
							},
						},
					{
					SubSeq	=	{
							{
							ovr_clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Stages	=	{
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.3,
											},
									Lights	=	{
											3,
											4,
											5,
											6,
											7,
											8,
											},
									Time	=	0.01,
									ovr_clr	=	{
										r	=	0,
										b	=	0,
										a	=	255,
										g	=	0,
											},
									ovr_clr_use	=	false,
										},
									},
							Time	=	0.5,
							Type	=	"Custom",
							ovr_clr_use	=	false,
								},
							},
					Codes	=	{
							true,
							true,
							true,
							},
					Lights_Sel	=	{
						[3]	=	true,
						[4]	=	true,
						[5]	=	true,
						[6]	=	true,
						[7]	=	true,
						[8]	=	true,
							},
						},
					{
					SubSeq	=	{
							{
							ovr_clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Stages	=	{
									{
									Lights	=	{
											},
									Time	=	0.2,
										},
									{
									Lights	=	{
											9,
											},
									Time	=	0.2,
										},
									{
									Lights	=	{
											9,
											10,
											},
									Time	=	0.2,
										},
									{
									Lights	=	{
											9,
											10,
											11,
											},
									Time	=	0.2,
										},
									{
									Lights	=	{
											9,
											10,
											11,
											12,
											},
									Time	=	0.2,
										},
									{
									Lights	=	{
											9,
											10,
											11,
											12,
											13,
											},
									Time	=	0.2,
										},
									{
									Lights	=	{
											9,
											10,
											11,
											12,
											13,
											14,
											},
									Time	=	0.2,
									ovr_clr	=	{
										r	=	0,
										b	=	0,
										a	=	255,
										g	=	0,
											},
									ovr_clr_use	=	false,
										},
									},
							Time	=	2,
							Type	=	"Traffic left",
							ovr_clr_use	=	false,
								},
							},
					Codes	=	{
						[10]	=	true,
							},
					Lights_Sel	=	{
						[9]	=	true,
						[10]	=	true,
						[11]	=	true,
						[12]	=	true,
						[13]	=	true,
						[14]	=	true,
							},
						},
					{
					SubSeq	=	{
							{
							ovr_clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Stages	=	{
									{
									Lights	=	{
											},
									Time	=	0.2,
									ovr_clr	=	{
										r	=	0,
										b	=	0,
										a	=	255,
										g	=	0,
											},
									ovr_clr_use	=	false,
										},
									{
									Lights	=	{
											12,
											11,
											},
									Time	=	0.2,
									ovr_clr	=	{
										r	=	0,
										b	=	0,
										a	=	255,
										g	=	0,
											},
									ovr_clr_use	=	false,
										},
									{
									Lights	=	{
											12,
											11,
											10,
											13,
											},
									Time	=	0.2,
									ovr_clr	=	{
										r	=	0,
										b	=	0,
										a	=	255,
										g	=	0,
											},
									ovr_clr_use	=	false,
										},
									{
									Lights	=	{
											12,
											11,
											10,
											13,
											9,
											14,
											},
									Time	=	0.2,
									ovr_clr	=	{
										r	=	0,
										b	=	0,
										a	=	255,
										g	=	0,
											},
									ovr_clr_use	=	false,
										},
									},
							Time	=	2,
							Type	=	"Custom",
							ovr_clr_use	=	false,
								},
							},
					Codes	=	{
						[11]	=	true,
							},
					Lights_Sel	=	{
						[9]	=	true,
						[10]	=	true,
						[11]	=	true,
						[12]	=	true,
						[13]	=	true,
						[14]	=	true,
							},
						},
					{
					SubSeq	=	{
							{
							ovr_clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Stages	=	{
									{
									Lights	=	{
											},
									Time	=	0.2,
										},
									{
									Lights	=	{
											14,
											},
									Time	=	0.2,
										},
									{
									Lights	=	{
											14,
											13,
											},
									Time	=	0.2,
										},
									{
									Lights	=	{
											14,
											13,
											12,
											},
									Time	=	0.2,
										},
									{
									Lights	=	{
											14,
											13,
											12,
											11,
											},
									Time	=	0.2,
										},
									{
									Lights	=	{
											14,
											13,
											12,
											11,
											10,
											},
									Time	=	0.2,
										},
									{
									Lights	=	{
											14,
											13,
											12,
											11,
											10,
											9,
											},
									Time	=	0.2,
									ovr_clr	=	{
										r	=	0,
										b	=	0,
										a	=	255,
										g	=	0,
											},
									ovr_clr_use	=	false,
										},
									},
							Time	=	2,
							Type	=	"Traffic right",
							ovr_clr_use	=	false,
								},
							},
					Codes	=	{
						[12]	=	true,
							},
					Lights_Sel	=	{
						[9]	=	true,
						[10]	=	true,
						[11]	=	true,
						[12]	=	true,
						[13]	=	true,
						[14]	=	true,
							},
						},
					{
					SubSeq	=	{
							{
							ovr_clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Stages	=	{
									{
									Lights	=	{
											1,
											},
									Time	=	0.3,
									ovr_clr	=	{
										r	=	0,
										b	=	0,
										a	=	255,
										g	=	0,
											},
									ovr_clr_use	=	false,
										},
									{
									Lights	=	{
											2,
											},
									Time	=	0.3,
									ovr_clr	=	{
										r	=	0,
										b	=	0,
										a	=	255,
										g	=	0,
											},
									ovr_clr_use	=	false,
										},
									},
							Time	=	5,
							Type	=	"Each side",
							ovr_clr_use	=	false,
								},
							},
					Codes	=	{
						[11]	=	true,
						[10]	=	true,
						[12]	=	true,
							},
					Lights_Sel	=	{
							true,
							true,
							},
						},
					{
					SubSeq	=	{
							{
							ovr_clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Stages	=	{
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.3,
											},
									Lights	=	{
											3,
											4,
											5,
											6,
											7,
											8,
											},
									Time	=	0.01,
									ovr_clr	=	{
										r	=	0,
										b	=	0,
										a	=	255,
										g	=	0,
											},
									ovr_clr_use	=	false,
										},
									},
							Time	=	0.5,
							Type	=	"Custom",
							ovr_clr_use	=	false,
								},
							},
					Codes	=	{
						[11]	=	true,
						[10]	=	true,
						[12]	=	true,
							},
					Lights_Sel	=	{
						[3]	=	true,
						[4]	=	true,
						[5]	=	true,
						[6]	=	true,
						[7]	=	true,
						[8]	=	true,
							},
						},
					},
			Sounds_Manual	=	{
				Use	=	true,
				Volume	=	1,
				Distance	=	95,
				Pitch	=	100,
				Sound	=	"vcmod/els/smartsiren/manual.wav",
					},
				},
		Date	=	"Mon Feb 27 12:29:59 2023",
		Exhaust	=	{
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(-45.340000152588,25.219999313354,13.10000038147),
				EffectStress	=	"VC_Exhaust_Truck_Stress",
				EffectIdle	=	"VC_Exhaust_Truck",
					},
				},
		animDriverPos	=	Vector(0,0,7),
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseSprite	=	true,
				HBeamColor	=	{
					r	=	195,
					b	=	225,
					a	=	255,
					g	=	195,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				RenderInner	=	true,
				UsePrjTex	=	true,
				Pos	=	Vector(-31.629999160767,121.30999755859,23.450000762939),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Size	=	0.9483,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseLowBeams	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				RenderInner_Size	=	0.9483,
				HBeamColor	=	{
					r	=	195,
					b	=	225,
					a	=	255,
					g	=	195,
						},
				RenderInner	=	true,
				Pos	=	Vector(-37.659999847412,119.98999786377,23.450000762939),
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	225,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				UseSprite	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-41.700000762939,118,23.450000762939),
				UseDynamic	=	true,
				RenderInner_Size	=	0.9483,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseSprite	=	true,
				HBeamColor	=	{
					r	=	195,
					b	=	225,
					a	=	255,
					g	=	195,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_Size	=	0.9483,
				UsePrjTex	=	true,
				Pos	=	Vector(31.629999160767,121.30999755859,23.450000762939),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseLowBeams	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				RenderInner	=	true,
				HBeamColor	=	{
					r	=	195,
					b	=	225,
					a	=	255,
					g	=	195,
						},
				RenderInner_Size	=	0.9483,
				Pos	=	Vector(37.659999847412,119.98999786377,23.450000762939),
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	225,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				UseSprite	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(41.700000762939,118,23.450000762939),
				UseDynamic	=	true,
				RenderInner_Size	=	0.9483,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				UseSprite	=	true,
				Pos	=	Vector(-37.389999389648,-114.01000213623,71.599998474121),
				UseDynamic	=	true,
				RenderInner_Size	=	0.9483,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				RenderInner	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				UseSprite	=	true,
				Pos	=	Vector(-37.389999389648,-114.01000213623,64.099998474121),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderInner_Size	=	0.9483,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseReverse	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-37.389999389648,-114.01000213623,66.099998474121),
				UseDynamic	=	true,
				RenderInner_Size	=	0.9483,
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-37.389999389648,-114.01000213623,74.099998474121),
				UseDynamic	=	true,
				RenderInner_Size	=	0.9483,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseSprite	=	true,
				Pos	=	Vector(37.389999389648,-114.01000213623,67.599998474121),
				UseDynamic	=	true,
				RenderInner_Size	=	0.9483,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				UseSprite	=	true,
				Pos	=	Vector(37.389999389648,-114.01000213623,60.599998474121),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderInner_Size	=	0.9483,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseReverse	=	true,
				RenderInner_Size	=	0.9483,
				UseSprite	=	true,
				Pos	=	Vector(37.389999389648,-114.01000213623,63.099998474121),
				UseDynamic	=	true,
				RenderInner	=	true,
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(37.389999389648,-114.01000213623,71.099998474121),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_Size	=	0.9483,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				RenderInner_ClrUse	=	false,
					},
				},
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		ExtraSeats	=	{
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(23.190000534058,98.120002746582,54.450000762939),
				noBendLegs	=	true,
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(26.690000534058,52.119998931885,60),
				noBendLegs	=	true,
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(8.6899995803833,52.119998931885,60),
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(-10.810000419617,52.119998931885,60),
				noBendLegs	=	true,
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(-30.309999465942,52.119998931885,60),
				noBendLegs	=	true,
					},
				{
				Ang	=	Angle(0,180,0),
				Pos	=	Vector(1.6900000572205,-16.879999160767,63.5),
				noBendLegs	=	true,
					},
				{
				Ang	=	Angle(0,90,0),
				Pos	=	Vector(19.690000534058,-69.379997253418,59.200000762939),
				noBendLegs	=	true,
					},
				{
				Ang	=	Angle(5,0,180),
				Pos	=	Vector(0,-140.61000061035,80.029998779297),
				Lay	=	true,
					},
				},
		DLT	=	3491062954,
		Sound_Airbrake	=	true,
		Copyright	=	"Copyright © 2023 VCMod (freemmaann). All Rights Reserved.",
		Fuel	=	{
			FuelType	=	0,
			FuelLidPos	=	Vector(0,0,0),
				},
		Author	=	"TheCarson116 (76561198123551419)",
}