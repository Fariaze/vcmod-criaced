VCModels['models/caterhamcaterham.mdl']	=	{
		Light_DD_Int	=	true,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Date	=	"07/14/15 15:20:53",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-150,0),
				Pos	=	Vector(-30.5,-31.059999465942,10.420000076294),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Pos	=	Vector(15,-27.299999237061,26.139999389648),
				DoorSounds	=	true,
				Ang	=	Angle(0,0,0),
				EnterRange	=	80,
				RadioControl	=	true,
					},
				},
		DLT	=	3491062914,
		Lights	=	{
				{
				UseBlinkers	=	true,
				UseBrake	=	true,
				BlinkersColor	=	{
						255,
						55,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(-25.030000686646,-66.529998779297,24.25),
				UseDynamic	=	true,
				Sprite	=	{
					Size	=	0.3,
						},
				UseRunning	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.3,
						},
					},
				{
				UseBlinkers	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.3,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(-15.210000038147,60.400001525879,27.39999961853),
				UseDynamic	=	true,
				RenderInner	=	true,
				Sprite	=	{
					Size	=	0.3,
						},
				RenderInner_Size	=	1.2,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					Size	=	1.2,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.6,
						},
				UseHead	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-15.390000343323,60.029998779297,33.029998779297),
				UseDynamic	=	true,
				HeadColor	=	{
						221,
						191,
						255,
						},
				UsePrjTex	=	true,
				ProjTexture	=	{
					Forward	=	30,
					Size	=	2024,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				UseBlinkers	=	true,
				UseBrake	=	true,
				BlinkersColor	=	{
						255,
						55,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(30.030000686646,-66.529998779297,24.25),
				UseDynamic	=	true,
				Sprite	=	{
					Size	=	0.3,
						},
				UseRunning	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.3,
						},
					},
				{
				UseBlinkers	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.3,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(19.209999084473,60.400001525879,27.39999961853),
				UseDynamic	=	true,
				RenderInner	=	true,
				Sprite	=	{
					Size	=	0.3,
						},
				RenderInner_Size	=	1.2,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	1.2,
						},
				ProjTexture	=	{
					Forward	=	30,
					Size	=	2024,
					Angle	=	Angle(0,90,0),
						},
				UseHead	=	true,
				UsePrjTex	=	true,
				Pos	=	Vector(19.389999389648,60.029998779297,33.029998779297),
				UseDynamic	=	true,
				HeadColor	=	{
						221,
						191,
						255,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.6,
						},
				UseSprite	=	true,
					},
				},
		Copyright	=	"DurkaTeam @ 2025 No rights reserved",
		em_state	=	5236594371,
		Author	=	"freemmaann (STEAM_0:1:14528726)",
}