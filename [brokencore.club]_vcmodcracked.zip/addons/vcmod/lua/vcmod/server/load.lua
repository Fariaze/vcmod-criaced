-- DurkaTeam @ 2025 Никакие права не защищены
-- Don't load things again

VCPrint"Preload finished. Initializing addons."
if not SERVER then return end

hook.Call("VC_postInit", GAMEMODE)
VC.isLoaded = true
file.CreateDir("vcmod")
file.CreateDir("vcmod/data_lng")
if not VC.Settings then VC.Settings = {} end
if not VC.Settings_Defaults then VC.Settings_Defaults = {} end
if not VC.ServerSettings then VC.ServerSettings = {} end
if not VC.ServerSettings_Defaults then VC.ServerSettings_Defaults = {} end
if not VC.ServerSettings_Index then
    VC.ServerSettings_Index = {
        from = {},
        to = {}
    }
end

local function handleIndexing(def, new)
    for k, v in pairs(new) do
        if not VC.ServerSettings_Index.to[k] then
            local index = table.Count(VC.ServerSettings_Index.to) + 1
            VC.ServerSettings_Index.from[index] = k
            VC.ServerSettings_Index.to[k] = index
        end
    end
end

function VC.SettingFromIndex(val)
    return VC.ServerSettings_Index.from[val] or 0
end

function VC.SettingToIndex(val)
    return VC.ServerSettings_Index.to[val] or 0
end

function VC.SettingsAdd(val, isShared)
    if not isShared or SERVER then table.Merge(VC.Settings_Defaults, val) end
    if isShared then
        table.Merge(VC.ServerSettings_Defaults, val)
        handleIndexing(VC.ServerSettings_Defaults, val)
    end
end

function VC.getSetting(id, default)
    local ret = default
    local new = VC.Settings[id]
    if new ~= nil then ret = new end
    return ret
end

function VC.getServerSetting(id, default)
    local ret = default
    local new = VC.ServerSettings[id]
    if new ~= nil then ret = new end
    return ret
end

function VC.isVCModCompatible(ent)
    return ent.VC_IsNotPrisonerPod or not IsValid(ent:GetParent()) or ent.VC_ExtraSeat
end

function VC.convertColorString(data)
    local ret = string.Explode(",", data)
    ret = Color(tonumber(ret[1]), tonumber(ret[2]), tonumber(ret[3]), 255)
    return ret
end

function VC.GetDriver(ent)
    local Drv_AI = ent.VC_AI_Driver
    if CLIENT then Drv_AI = ent:GetNWEntity("VC_AI_Driver") end
    if IsValid(Drv_AI) then return Drv_AI end
    local drv = ent.GetDriver and ent:GetDriver()
    if IsValid(drv) then return drv end
end

function VC.getVehicle(ply)
    local veh_AI = ply.VC_Vehicle
    if CLIENT then veh_AI = ply:GetNWEntity("VC_Vehicle") end
    if IsValid(veh_AI) then return veh_AI end
    local veh = ply.GetVehicle and ply:GetVehicle()
    if IsValid(veh) then return veh end
end

function VC.getVehicleTrace(ply, onlyveh)
    local ent, pos = ply:GetVehicle(), Vector(0, 0, 0)
    if not IsValid(ent) then
        local tr = ply:GetEyeTraceNoCursor()
        pos = tr.HitPos
        ent = tr.Entity
        if IsValid(ent) then
            if not ent:IsVehicle() then
                local atc = ent:GetNWEntity("VC_AttachedTo")
                if IsValid(atc) then
                    ent = atc
                else
                    if not onlyveh and string.lower(ent:GetClass()) == "prop_physics" then
                    else
                        ent = nil
                    end
                end
            end
        elseif VC.Dev_Menu_Open and IsValid(VC.Dev_LastVehicle) then
            ent = VC.Dev_LastVehicle
            pos = IsValid(ent) and ent:GetPos()
        end

        if not IsValid(ent) then ent = nil end
    end

    if ent and ent.VC_ExtraSeat then ent = ent:GetParent() end
    if VC.Dev_Menu_Open and ent then VC.Dev_LastVehicle = ent end
    return ent, pos
end

function VC.time_elapsed_string(time)
    time = tonumber(time or 0)
    if not time then time = 0 end
    local timeNew = math.abs(os.time() - time)
    local future = os.time() < time
    if timeNew < 1 then return 'Just now' end
    local a = {
        [31536000] = 'year',
        [2592000] = 'month',
        [86400] = 'day',
        [3600] = 'hour',
        [60] = 'minute',
        [1] = 'second'
    }

    for secs, str in SortedPairs(a, true) do
        local d = timeNew / secs
        if d >= 1 then
            local r = math.Round(d)
            local plural = r > 1 and (str .. "s") or str
            if future then
                return 'In ' .. r .. ' ' .. plural
            else
                return r .. ' ' .. plural .. ' ago'
            end
        end
    end
end

function VC.getFilesTable(dir, basedir, cat)
    local ret = {}
    if cat then if not ret[cat] then ret[cat] = {} end end
    local f1, f2 = file.Find(dir .. "*", basedir or "GAME")
    if f2 then
        for k, v in pairs(f2) do
            if not ret[v] then ret[v] = {} end
            ret[v] = VC.getFilesTable(dir .. v .. "/", basedir)
        end
    end

    if f1 then
        for k, v in pairs(f1) do
            local fp = dir .. v
            ret[k] = fp
        end
    end
    return ret
end

function VC.CanEditAdminSettings(ply, dontprint)
    if not IsValid(ply) then return false end
    local ret = VC.PrivilegesCan(ply)
    local hookCall1 = hook.Call("VC_CanEditAdminSettings", GAMEMODE, ply, ret)
    local hookCall2 = hook.Call("VC_canEditAdminSettings", GAMEMODE, ply, ret)
    if hookCall1 ~= nil or hookCall2 ~= nil then ret = hookCall1 ~= nil and hookCall1 or hookCall2 ~= nil and hookCall2 end
    if not ret and not dontprint and (not ply.VC_CanEditAS_Time or CurTime() >= ply.VC_CanEditAS_Time) then
        ply.VC_CanEditAS_Time = CurTime() + 0.5
        if CLIENT then
            VCPopup("AccessRestricted", "cross")
        else
            VCPopup(ply, "AccessRestricted", "cross")
        end
    end
    return ret
end

function VC.Get2DNormalFromAngle(ang)
    ang = ang / 180 * math.pi
    return {
        x = math.sin(ang),
        y = math.cos(ang)
    }
end

function VC.Get2DAngle(pos1, pos2, cutMid)
    local ret = 0
    local ypd = pos1.y - pos2.y
    local xpd = pos1.x - pos2.x
    if cutMid and xpd < 2 and xpd > -2 and ypd < 2 and ypd > -2 then
        xpd = 2
        ypd = -1
    end

    local rad = math.atan2(xpd, ypd)
    ret = math.NormalizeAngle(rad * 180 / math.pi)
    return ret
end

function VC.StringPrepareForTransfer(str)
    str = string.gsub(str, '^', '_U_')
    str = string.gsub(str, ':', '_D_')
    str = string.gsub(str, ';', '_D2_')
    str = string.gsub(str, '&', '_A_')
    str = string.gsub(str, ' ', '@@')
    str = string.Implode("_P_", string.Explode("%", str))
    return str
end

function VC.ColorCopyAlpha(val, a)
    local ret = val
    if val then ret = Color(val.r or 0, val.g or 0, val.b or 0, a or 255) end
    return ret
end

function VC.ColorToHSV(clr)
    local h, s, v, a = 0, 0, 0, 0
    if clr then
        r, g, b, a = clr.r / 255, clr.g / 255, clr.b / 255, clr.a / 255
        local max, min = math.max(r, g, b), math.min(r, g, b)
        v = max
        local d = max - min
        if max == 0 then
            s = 0
        else
            s = d / max
        end

        if max == min then
            h = 0
        else
            if max == r then
                h = (g - b) / d
                if g < b then h = h + 6 end
            elseif max == g then
                h = (b - r) / d + 2
            elseif max == b then
                h = (r - g) / d + 4
            end

            h = h / 6
        end
    end
    return math.NormalizeAngle(h * 360), s, v, a
end

function VC.HSVToColor(h, s, v, a)
    local r, g, b = 0, 0, 0
    if v > 0 then
        local hs = math.floor(h / 60)
        local h_so = h / 60 - hs
        local p, q, t = v * (1 - s), v * (1 - s * h_so), v * (1 - s * (1 - h_so))
        if hs == 0 then
            r, g, b = v, t, p
        elseif hs == 1 then
            r, g, b = q, v, p
        elseif hs == 2 then
            r, g, b = p, v, t
        elseif hs == -3 then
            r, g, b = p, q, v
        elseif hs == -2 then
            r, g, b = t, p, v
        elseif hs == -1 then
            r, g, b = v, p, q
        end
    end
    return Color(math.Round(r * 255), math.Round(g * 255), math.Round(b * 255), math.Round(a * 255))
end

function VC.capitalizeFirstLetter(str)
    local chunks = string.Explode("", str)
    chunks[1] = string.upper(chunks[1])
    return string.Implode("", chunks)
end

function VC.EaseInOut(num)
    return (math.sin(math.pi * (num - 0.5)) + 1) / (num > 0 and 2 or -2)
end

function VC.EaseIn(num)
    return math.sin((num - 1) * math.pi * 0.5) + 1
end

function VC.EaseOut(num)
    return math.sin(num * math.pi * 0.5)
end

    util.AddNetworkString("VC_Privileges_Set")
    function VC.LoadPrivileges()
        VC.PrivilegesLevel = file.Exists("vcmod/config_sv_privileges.txt", "DATA") and tonumber(file.Read("vcmod/config_sv_privileges.txt", "DATA")) or 2
    end

    function VC.SetPrivileges(val)
        file.Write("vcmod/config_sv_privileges.txt", val)
        VC.PrivilegesLevel = tonumber(val)
        VC.Stream_SV_Settings()
    end

    function VC.GetPrivileges()
        if not VC.PrivilegesLevel then VC.LoadPrivileges() end
        return VC.PrivilegesLevel or 2
    end

    net.Receive("VC_Privileges_Set", function(len, ply)
        if not IsValid(ply) then return end
        if not ply:IsSuperAdmin() then return end
        local val = net.ReadInt(4)
        VC.SetPrivileges(val)
    end)

    VC.LoadPrivileges()

function VC.PrivilegesCan(ply)
    if not VC.PrivilegesLevel or (VC.PrivilegesLevel == 1 and ply:IsSuperAdmin() or VC.PrivilegesLevel == 2 and ply:IsAdmin() or VC.PrivilegesLevel == 3) then return true end
end

function VC.getRanks()
    local ret = {
        user = "user",
        admin = "admin",
        superadmin = "superadmin"
    }

    local ranks = xgui and xgui.data and xgui.data.groups
    if ranks then
        for k, v in pairs(ranks) do
            ret[k] = "(ULX) " .. v
        end
    end

    local ranks = serverguard and serverguard.ranks and serverguard.ranks.GetRanks and serverguard.ranks:GetRanks()
    if ranks then
        for k, v in pairs(ranks) do
            ret[k] = "(ServerGuard) " .. (v.name or k)
        end
    end

    local ranks = sam and sam.ranks and sam.ranks.get_ranks
    if ranks then
        for k, v in pairs(ranks()) do
            ret[k] = "(SAM) " .. (v.name or k)
        end
    end

    local ranks = xAdmin and xAdmin.Groups
    if ranks then
        for k, v in pairs(ranks) do
            ret[k] = "(XAdmin) " .. k
        end
    end
    return ret
end

VC_AU_Ver_Online = 9.65
VC.IndicationList = {
    {
        idx = "blinkers_left",
        nm = "Blinker lights left",
        type = 1,
        getVal = function(ent) return VC.GetState(ent, "TurnLightLeftOn") end
    },
    {
        idx = "blinkers_right",
        nm = "Blinker lights right",
        type = 1,
        getVal = function(ent) return VC.GetState(ent, "TurnLightRightOn") end
    },
    {
        idx = "lights_hazard",
        nm = "Hazard lights",
        type = 1,
        getVal = function(ent) return VC.GetState(ent, "HazardLightsOn") end
    },
    {
        idx = "lights_running",
        nm = "Running lights",
        type = 1,
        getVal = function(ent) return VC.GetState(ent, "RunningLightsOn") end
    },
    {
        idx = "lights_fog",
        nm = "Fog lights",
        type = 1,
        getVal = function(ent) return VC.GetState(ent, "FogLightsOn") end
    },
    {
        idx = "lights_brake",
        nm = "Brake lights",
        type = 1,
        getVal = function(ent) return ent.VC_Lights_Created["Brake"] end
    },
    {
        idx = "lights_reverse",
        nm = "Reverse lights",
        type = 1,
        getVal = function(ent) return ent.VC_Lights_Created["Reverse"] end
    },
    {
        idx = "lights_lowbeams",
        nm = "Low-Beam lights",
        type = 1,
        getVal = function(ent) return VC.GetState(ent, "LowBeamsOn") end
    },
    {
        idx = "lights_highbeams",
        nm = "High-Beam lights",
        type = 1,
        getVal = function(ent) return VC.GetState(ent, "HighBeamsOn") end
    },
    {
        idx = "cruise",
        nm = "Cruise control",
        type = 1,
        getVal = function(ent) return VC.GetState(ent, "CruiseOn") end
    },
    {
        idx = "horn",
        nm = "Horn",
        type = 1,
        getVal = function(ent)
            VCMsg(ent)
            return VC.GetState(ent, "HornOn")
        end
    },
    {
        idx = "handbrake",
        nm = "Handbrake",
        type = 1,
        getVal = function(ent) return ent.VC_HandBrakeOn end
    },
    {
        idx = "electricity",
        nm = "Electricity on",
        type = 1,
        getVal = function(ent) return VC.ElectronicsOn(ent) end
    },
    {
        idx = "driver_in_seat",
        nm = "Driver in seat",
        type = 0,
        getVal = function(ent) return VC_A or IsValid(VC.GetDriver(ent)) end
    },
    {
        idx = "trailer",
        nm = "Trailer attached",
        type = 1,
        getVal = function(ent) return IsValid(ent.VC_HookVeh) end
    },
    {
        idx = "els_lights",
        nm = "ELS lights",
        type = 1,
        getVal = function(ent) return VC.ELS_LightsOn(ent) end
    },
    {
        idx = "els_sound",
        nm = "ELS sounds",
        type = 1,
        getVal = function(ent) return VC.ELS_SoundOn(ent) end
    },
    {
        idx = "locked",
        nm = "Vehicle locked",
        type = 1,
        getVal = function(ent) return VC.IsLocked(ent) end
    },
    {
        idx = "throttle",
        nm = "Throttle",
        type = 1,
        getVal = function(ent) return (ent.VC_Throttle or ent:GetThrottle() or 0) ~= 0 end
    },
    {
        idx = "throttle_forw",
        nm = "Throttle while forward only",
        type = 1,
        getVal = function(ent)
            local thrt = ent.VC_Throttle or ent:GetThrottle() or 0
            return thrt > 0.05
        end
    },
    {
        idx = "throttle_rev",
        nm = "Throttle while reversing only",
        type = 1,
        getVal = function(ent)
            local thrt = ent.VC_Throttle or ent:GetThrottle() or 0
            return thrt < -0.05
        end
    },
    {
        idx = "speedo_kmph",
        nm = "Speedometer km/h",
        type = 0,
        defaultTop = 240,
        getVal = function(ent) return ent:VC_GetSpeedKmH() end
    },
    {
        idx = "speedo_mph",
        nm = "Speedometer m/h",
        type = 0,
        defaultTop = 200,
        getVal = function(ent) return VC.KmToM(ent:VC_GetSpeedKmH()) end
    },
    {
        idx = "fuel",
        nm = "Fuel",
        type = 0,
        defaultTop = 1,
        getVal = function(ent) return ent.VC_Fuel and ent.VC_Fuel / ent.VC_MaxFuel or 0 end
    },
    {
        idx = "fuel_lid_active",
        nm = "Fuel lid in use",
        type = 1,
        getVal = function(ent) return ent.VC_ForceOpenFuelLidTime or IsValid(ent.VC_Weld_FNozzle) end
    },
    {
        idx = "health_engine",
        nm = "Engines health",
        type = 0,
        defaultTop = 1,
        getVal = function(ent) return ent.VC_HealthPerc or 0 end
    },
    {
        idx = "damage_tire_fl",
        nm = "Flat tire: front left",
        type = 1,
        getVal = function(ent) return ent.VC_DamagedObjects and ent.VC_DamagedObjects.Wheel and ent.VC_DamagedObjects.Wheel[1] end
    },
    {
        idx = "damage_tire_fr",
        nm = "Flat tire: front right",
        type = 1,
        getVal = function(ent) return ent.VC_DamagedObjects and ent.VC_DamagedObjects.Wheel and ent.VC_DamagedObjects.Wheel[2] end
    },
    {
        idx = "damage_tire_rl",
        nm = "Flat tire: rear left",
        type = 1,
        getVal = function(ent) return ent.VC_DamagedObjects and ent.VC_DamagedObjects.Wheel and ent.VC_DamagedObjects.Wheel[3] end
    },
    {
        idx = "damage_tire_rr",
        nm = "Flat tire: rear right",
        type = 1,
        getVal = function(ent) return ent.VC_DamagedObjects and ent.VC_DamagedObjects.Wheel and ent.VC_DamagedObjects.Wheel[4] end
    },
}

VC.IndicationListByKey = {}
for i = 1, #VC.IndicationList do
    local data = VC.IndicationList[i]
    VC.IndicationListByKey[data.idx] = data
end

VC.Constant_Currency = {
    {
        symbol = "$",
        shrt = "USD",
        name = "United States dollar"
    },
    {
        symbol = "€",
        shrt = "EUR",
        name = "Euro"
    },
    {
        symbol = "£",
        shrt = "GBP",
        name = "British pound"
    },
    {
        symbol = "kr",
        shrt = "KRONE",
        name = "Norwegian krone"
    },
    {
        symbol = "₣",
        shrt = "FF",
        name = "French franc"
    },
    {
        symbol = "₽",
        shrt = "RUB",
        name = "Russian ruble"
    },
    {
        symbol = "₺",
        shrt = "TL",
        name = "Turkish Lira"
    },
    {
        symbol = "R",
        shrt = "ZAR",
        name = "South African rand"
    },
    {
        symbol = "¥",
        shrt = "JPY",
        name = "Japanese yen"
    },
    {
        symbol = "¥",
        shrt = "CNY",
        name = "Renminbi (RMB) - Chinese yuan"
    },
}

function VC.getCurCurrency()
    local tbl = {}
    if VC.Constant_Currency then
        tbl = VC.Constant_Currency[1]
        local set = 1
        if CLIENT then
            set = VC.getServerSetting("Currency", 1)
        else
            set = VC.getSetting("Currency", 1)
        end

        if VC.Constant_Currency[set] then tbl = VC.Constant_Currency[set] end
    end
    return tbl
end

VC.SemiAutoData = {
    alfa = {
        fuel = {
            lidside = 1,
            lidoffset = Vector(0, 0, 5),
            type = 1
        },
        UI_Inter = {
            vc_lights_switch = Vector(-10, 30, -12)
        }
    },
    audi = {
        fuel = {
            lidside = 1,
            lidoffset = Vector(0, 0, 5),
            type = 1
        },
        UI_Inter = {
            vc_lights_switch = Vector(12.5, 33, -16.5),
            vc_horn = Vector(0, 23, -14)
        }
    },
    bmw = {
        fuel = {
            lidside = 1,
            lidoffset = Vector(0, 0, 5)
        },
        UI_Inter = {
            vc_lights_switch = Vector(13, 32, -14.5)
        }
    },
    mercedes = {
        fuel = {
            lidside = 1,
            lidoffset = Vector(0, 0, 5)
        },
        UI_Inter = {
            vc_lights_switch = Vector(12, 27, -16)
        }
    },
    volkswagen = {
        fuel = {
            lidside = 1,
            lidoffset = Vector(0, -10, 5),
            type = 1
        },
        UI_Inter = {
            vc_lights_switch = Vector(12, 27, -13)
        }
    },
    beetle = {
        fuel = {
            lidside = 1,
            lidoffset = Vector(0, -10, 5)
        },
        UI_Inter = {
            vc_lights_switch = Vector(12, 27, -13)
        }
    },
    porche = {
        fuel = {
            lidside = 1,
            lidoffset = Vector(0, -5, 0)
        },
        UI_Inter = {
            vc_lights_switch = Vector(10, 28, -14)
        }
    },
    leaf = {
        fuel = {
            lidside = 1,
            lidoffset = Vector(0, 0, 5),
            type = 2
        }
    },
    nissan = {
        fuel = {
            lidside = 1,
            lidoffset = Vector(0, -12, -1)
        },
        UI_Inter = {
            vc_lights_switch = Vector(8, 28, -14)
        }
    },
    maserati = {
        fuel = {
            lidside = -1,
            lidoffset = Vector(0, 0, 5)
        }
    },
    lexus = {
        fuel = {
            lidside = -1,
            lidoffset = Vector(0, 0, 5)
        }
    },
    mazda = {
        fuel = {
            lidside = -1,
            lidoffset = Vector(0, 0, 5)
        },
        UI_Inter = {
            vc_lights_switch = Vector(9, 25, -14)
        }
    },
    tesla = {
        fuel = {
            lidside = 1,
            lidoffset = Vector(0, 0, 5),
            type = 2
        }
    },
    prius = {
        fuel = {
            lidside = 1,
            lidoffset = Vector(0, 0, 5),
            type = 2
        }
    },
    unknown = {
        fuel = {
            lidside = 1,
            lidoffset = Vector(0, 0, 5),
            Capacity = 50,
            Capacity_Auto = true
        },
        UI_Inter = {
            vc_lights_switch = Vector(13, 32, -14.5)
        }
    },
    unknown_big = {
        fuel = {
            lidside = 1,
            lidoffset = Vector(0, 0, 5),
            type = 1,
            Capacity = 200,
            Capacity_Auto = true
        },
        UI_Inter = {
            vc_lights_switch = Vector(-8, 19, -11)
        }
    },
}

function VC.SemiAutoData_Pick(ent)
    local ret = nil
    local name = VC.getName(ent, "")
    local cat = ent:GetNWString("VC_Category", "")
    local mdl = VC.GetModel(ent) .. name .. cat
    for k, v in pairs(VC.SemiAutoData) do
        if string.gmatch(string.lower(mdl), k)() then
            ret = k
            break
        end
    end

    if not ret then
        if VC.IsBig(ent) then
            ret = "unknown_big"
        else
            ret = "unknown"
        end
    end
    return ret
end

if not VC.Controls_Main then VC.Controls_Main = {} end
function VC.controlInsert(data)
    local added = false
    for k2, v2 in pairs(VC.Controls_Main) do
        if data.cmd == v2.cmd then
            added = true
            break
        end
    end

    if not added then table.insert(VC.Controls_Main, data) end
end

local data = {
    cmd = "vc_horn",
    menu = "controls",
    NoCheckBox = true,
    carg1 = "1",
    carg2 = "2",
    info = "Horn",
    default = {
        key = "KEY_R",
        hold = "1"
    }
}

VC.controlInsert(data)
local data = {
    cmd = "vc_holdkey",
    menu = "controls_holdkey",
    NoCheckBox = true,
    carg1 = "1",
    carg2 = "2",
    info = "HoldKey",
    default = {
        key = "KEY_LALT",
        hold = "1"
    }
}

VC.controlInsert(data)
function VC.getWheelData(ent)
    if VC_fremmann777obosr(ent).IsBike then
        return VC.WheelsBike, true
    else
        return VC.Wheels, false
    end
end

VC.Wheels = {"wheel_fl", "wheel_fr", "wheel_rl", "wheel_rr"}
VC.WheelsBike = {
    [1] = "wheel_fl",
    [3] = "wheel_rl"
}

VC.SideNames = {"Front left", "Front right", "Rear left", "Rear right"}

function VC_fremmannkorichnevpants(mdl)
    return mdl and VC_fremmannidinaxuy[mdl] or {}
end

function VC_fremmann777obosr(ent)
    return VC_fremmannkorichnevpants(VC.GetModel(ent))
end

function VC.hasGlobalOD(mdl)
    return (mdl and VC_fremmannidinaxuy[mdl]) and true or false
end

VC.supportedClasses = {
    prop_vehicle_jeep = {
        getCustomData = function(vehT) return vehT or {} end
    },
    prop_vehicle_jeep_old = {
        getCustomData = function(vehT) return vehT or {} end
    },
    prop_vehicle_airboat = {
        getCustomData = function(vehT) return vehT or {} end
    },
}

function VC.getClassCustomVehData(data)
    local ret = {}
    local classData = VC.classIsSupported(data.Class or data.class)
    if classData and classData.getCustomData then ret = classData.getCustomData(data) end
    return ret
end

function VC.classIsSupported(class)
    return VC.supportedClasses[class]
end

function VC.getVehicleMain(ent, ignoreExtra)
    local retMain = nil
    if not IsValid(ent) then return nil, nil end
    if ent.VC_ExtraSeat or ignoreExtra then
        local prt = ent:GetParent()
        if IsValid(retMain) then retMain = prt end
    end
    return ent, retMain
end

function VC.GetVehicleList(fresh)
    if fresh or not VC.GetVehicleList_Timer or CurTime() >= VC.GetVehicleList_Timer then
        local tlist = VC.supportedClasses
        local tVehList = {}
        for k, v in pairs(tlist) do
            table.Add(tVehList, ents.FindByClass(k))
        end

        VC.VehicleList = tVehList
        VC.GetVehicleList_Timer = CurTime() + 1
    end
    return VC.VehicleList
end

function VC.CanAfford(ply, price)
    local can = nil
    local dhook = hook.Call("VC_canAfford", GAMEMODE, ply, price)
    if not can and dhook ~= nil then return dhook end
    local Func = ply.canAfford or ply.CanAfford
    if not can and Func then can = Func(ply, price) end
    if not can and ply.GetCash then can = ply:GetCash() > price end
    if not can and ply.DRPMoney then can = ply:DRPMoney() > price end
    if not can and GetPlyMoney then can = GetPlyMoney(ply) > price end
    if not can and ply.getMoney then can = ply:getMoney() > price end
    if not can and ply.Money_Has then can = ply:Money_Has(price) end
    if not can and (GAMEMODE and (string.lower(GAMEMODE.Name) == string.lower("Pokémon GO") or string.lower(GAMEMODE.Name) == string.lower("underdone - rpg")) and ply.HasItem) then can = ply:HasItem("money", price) end
    if can == nil then can = true end
    return can
end

function VC.SoundEmit(ent, snd, pch, lvl, vol, pos, ntmr)
    if IsValid(ent) and snd then
        local Clk = snd == "Clk"
        snd = Clk and "vcmod/clk.wav" or snd
        local VSnd = CreateSound(ent, snd)
        VSnd:SetSoundLevel(lvl or (Clk and 55 or 60))
        VSnd:Stop()
        VSnd:Play()
        VSnd:ChangePitch(math.Clamp(pch or 100, 1, 255), 0)
        VSnd:ChangeVolume(math.Clamp(vol or 1, 0, 1), 0)
        if not ntmr then timer.Simple(SoundDuration(snd), function() if VSnd and VSnd:IsPlaying() then VSnd:Stop() end end) end
        return VSnd
    end
end

function VC.EmitSound(...)
    return VC.SoundEmit(...)
end

VC.BlinkerOnTime = 0.39
VC.BlinkerOffTime = 0.36
function VC.GetBlinkerOnTime(script)
    local ret = VC.BlinkerOnTime
    if script.Seq_BlinkRate_Ovr then
        local time = script.Seq_BlinkRate_On
        if time then ret = time end
    end
    return ret
end

function VC.GetBlinkerOffTime(script)
    local ret = VC.BlinkerOffTime
    if script.Seq_BlinkRate_Ovr then
        local time = script.Seq_BlinkRate_Off
        if time then ret = time end
    end
    return ret
end

function VC.getAtcPos(ent, id)
    local retLocal, retWorld, retAngle, found = Vector(0, 0, 0), Vector(0, 0, 0), Angle(0, 0, 0), nil
    local obj = ent:LookupAttachment(id)
    if obj then
        local atc = ent:GetAttachment(obj)
        if atc then
            retWorld = atc.Pos
            retLocal = ent:WorldToLocal(retWorld)
            retAngle = ent:WorldToLocalAngles(atc.Ang)
            found = true
        end
    end
    return retLocal, retWorld, retAngle, found
end

function VC.getBonePos(ent, id)
    local retLocal, retWorld, retAngle = Vector(0, 0, 0), Vector(0, 0, 0), Angle(0, 0, 0)
    local matrix = ent:GetBoneMatrix(id)
    if matrix then
        retWorld = matrix:GetTranslation()
        retLocal = ent:WorldToLocal(retWorld)
        retAngle = ent:WorldToLocalAngles(matrix:GetAngles())
    end
    return retLocal, retWorld, retAngle
end

function VC.isHeldStart(ent, ID)
    if ent.VC_PickedUp then ent:VC_PickedUp(ent.VC_isHeldPlyLast, ID) end
    ent.VC_isHeld = ID
end

function VC.isHeldEnd(ent, ID)
    if ent.VC_Dropped then ent:VC_Dropped(ent.VC_isHeldPlyLast, ID) end
    ent.VC_isHeld = nil
end

function VC.isHeld(ent)
    local ret = nil
    if not ent.VC_isHeldCurTime or CurTime() >= ent.VC_isHeldCurTime then
        ent.VC_isHeldCurTime = CurTime() + 0.5
        local ID = nil
        if not ID then
            local pobj = ent:GetPhysicsObject()
            if IsValid(pobj) and pobj:HasGameFlag(FVPHYSICS_PLAYER_HELD) then ID = 1 end
        end

        if not ID then if ent.Drag then ID = 2 end end
        if ID and not ent.VC_isHeld then
            VC.isHeldStart(ent, ID)
        elseif not ID and ent.VC_isHeld then
            VC.isHeldEnd(ent, ent.VC_isHeld)
        end
    end
    return ent.VC_isHeld
end

function VC_fremmannobosrimen(ent, data, dev)
    local posInitial = data.SLSPos or data.Pos
    if dev then retLocal = data.Pos or data.Pos1 or data.Pos2 end
    local retLocal = posInitial
    local retWorld = nil
    local retAngle = nil
    if retLocal then retLocal = Vector(retLocal.x, retLocal.y, retLocal.z) end
    if data.PosAtc then
        if data.PosAtc.type == "Bone" then
            retLocal, retWorld, retAngle = VC.getBonePos(ent, data.PosAtc.id)
        elseif data.PosAtc.type == "Atc" then
            retLocal, retWorld, retAngle = VC.getAtcPos(ent, data.PosAtc.id)
        end

        if data.PosAtc.offset then
            local offsetRot = Vector(data.PosAtc.offset.x, data.PosAtc.offset.y, data.PosAtc.offset.z)
            offsetRot:Rotate(retAngle or Angle(0, 0, 0))
            retLocal = retLocal + offsetRot
            retWorld = nil
        end
    end

    if not retLocal then retLocal = posInitial or Vector(0, 0, 0) end
    if not retWorld then retWorld = ent:LocalToWorld(retLocal) end
    return retLocal, retWorld, retAngle
end

function VC.OBBToWorld(ent)
    return ent:LocalToWorld(ent:OBBCenter())
end

function VC.GetEyePos(ent)
    local vec = Vector(0, 0, 0)
    if IsValid(ent) then
        local ment = ent.VC_ExtraSeat and ent:GetParent() or ent
        local sData = VC_fremmann777obosr(ment)
        if sData.eyePos then
            vec = sData.eyePos
        else
            local Atc = ment:LookupAttachment("vehicle_driver_eyes")
            if Atc ~= 0 then
                local tdata = ment:GetAttachment(Atc)
                if tdata then vec = ent:WorldToLocal(tdata.Pos) end
            end
        end
    end
    return vec
end

function VC.getTruck(ent)
    local ret = nil
    local time = nil
    ret = SERVER and ent.VC_Truck or ent:GetNWEntity("VC_Truck")
    time = SERVER and ent.VC_HookedVhAtcT or ent:GetNWInt("VC_HookedVhAtcT") or 0
    if not IsValid(ret) then
        ret = ent
        time = 0
    end
    return ret, time
end

function VC.EngineAboveWater(ent, UWC)
    if not ent.VC_EngineAboveWater or CurTime() >= ent.VC_EngineAboveWater.time then
        ent.VC_EngineAboveWater = {
            time = CurTime() + 1,
            above = ent.VC_IsAirboat or VC.VecAboveWtr(VC.getEnginePos(ent))
        }
    end
    return ent.VC_EngineAboveWater.above
end

function VC.ElectronicsOn(ent)
    if VCMod2 then
        return not ent.VC_IsJeep or ent.VC_HasElectricity and ent.VC_ElectricityOn
    else
        return (not ent.VC_IsJeep or VC.EngineAboveWater(ent, UWC)) and (not ent.VC_GetHealth or ent:VC_GetHealth() ~= 0)
    end
end

function VC.AtcToWorld(ent, vec)
    if vec then
        local MdlT = ent.VC_VehModels or {ent}
        for _, MEnt in pairs(MdlT) do
            local MEnt = IsValid(MEnt) and MEnt.VC_DynOrn or MEnt
            local Atc = MEnt:LookupAttachment(vec)
            if Atc ~= 0 then
                vec = MEnt:GetAttachment(Atc).Pos
                break
            else
                vec = MEnt:GetPos()
            end
        end
    else
        vec = Vector(0, 0, 0)
    end
    return vec
end

function VC.VectorToWorld(ent, vec)
    if not vec then vec = Vector(0, 0, 0) end
    return ent:LocalToWorld(vec)
end

function VC.getFuelMax(ent, default)
    local ret = 0
    if CLIENT then
        ret = ent:GetNWInt("VC_MaxFuel", default or 1)
    else
        ret = ent.VC_MaxFuel or default or 1
    end
    return ret
end

function VC.getFuel(ent, default)
    local ret = 0
    if CLIENT then
        ret = ent:GetNWInt("VC_Fuel", default or -1)
    else
        ret = ent.VC_Fuel or default or -1
    end
    return ret
end

function VC.IsEngineOn(ent)
    return ent.VC_Dev_ThrottleTime or VC.ElectronicsOn(ent) and VC.getFuel(ent) > 0 and (CLIENT or not ent.VC_IsJeep or ent:IsEngineStarted())
end

function VC.UpsideDown(ent)
    return math.abs(ent:GetAngles().p) > 45 or math.abs(ent:GetAngles().r) > 60
end

function VC.VecAboveWtr(vec)
    local WTV = util.PointContents(vec)
    return WTV ~= 268435488 and WTV ~= 32
end

function VC.IsSeatEmpty(ent)
    local driver = VC.GetDriver(ent)
    return not driver
end

function VC.GetPoseParams(ent)
    local ret = ent.VC_PoseParameters
    if not ent.VC_PoseParameters then
        local t1, t2, t3 = VC.getVehPParams(ent)
        ent.VC_PoseParameters = t1
    end
    return ent.VC_PoseParameters
end

local pp_default = {"vehicle_steer", "vehicle_wheel_fl_height", "vehicle_wheel_fr_height", "vehicle_wheel_rl_height", "vehicle_wheel_rr_height", "vehicle_wheel_fl_spin", "vehicle_wheel_fr_spin", "vehicle_wheel_rl_spin", "vehicle_wheel_rr_spin"}
function VC.getVehPParams(ent)
    if IsValid(ent) then
        local ret, ret_custom, ret_default = {}, {}, {}
        if not ent.VC_PoseParameterRanges then ent.VC_PoseParameterRanges = {} end
        for i = 0, ent:GetNumPoseParameters() - 1 do
            local nm = ent:GetPoseParameterName(i)
            local min, max = ent:GetPoseParameterRange(i)
            if table.HasValue(pp_default, nm) then
                ret_default[nm] = {
                    id = i,
                    min = min,
                    max = max
                }
            else
                ret_custom[nm] = {
                    id = i,
                    min = min,
                    max = max
                }
            end

            ret[nm] = {
                id = i,
                min = min,
                max = max
            }
        end
        return ret, ret_custom, ret_default
    end
end

function VC.EnginePosDefault(ent)
    local ret = Vector(0, 0, 0)
    if ent.VC_IsAirboat then
        ret = ent:GetPos() + ent:GetUp() * 55 + ent:GetForward() * -45
    else
        local Eng = ent:LookupAttachment("vehicle_engine")
        if Eng and Eng ~= 0 then
            ret = ent:GetAttachment(Eng).Pos
        else
            ret = ent:GetPos() + ent:GetUp() * 25 + ent:GetForward() * 75
        end
    end
    return ret
end

function VC.getEnginePos(ent)
    if not IsValid(ent) then return end
    if CLIENT then
        local pos = ent:GetNWVector("VC_EnginePos", Vector(0, 0, 0))
        if pos ~= Vector(0, 0, 0) then ent.VC_EnginePos = pos end
    end
    return ent.VC_EnginePos and ent:LocalToWorld(ent.VC_EnginePos) or VC.EnginePosDefault(ent)
end

function VC.KmToM(km)
    return (km or 0) * 0.625
end

function VC.MToKm(km)
    return (km or 0) / 0.625
end

function VC.VelocityToKmH(vel)
    return math.abs((vel or 0) * 0.0909446998)
end

function VC.KmHToVelocity(kmh)
    return (kmh or 0) / 0.09144
end

function VC.SeatGetOption(ent, opt)
    local ret = nil
    if IsValid(ent) and ent.VC_Data and ent.VC_Data[opt] then ret = ent.VC_Data[opt] end
    return ret
end

function VC.SeatGetOptionFromID(ent, ID, opt)
    if not ent.VC_cache_SeatRefData or not ent.VC_cache_SeatRefData[ID] then
        ent.VC_cache_SeatRefData = {}
        ent.VC_cache_SeatRefData[ID] = {}
        local sData = VC_fremmann777obosr(ent)
        if not sData then return end
        if sData.ExtraSeats and sData.ExtraSeats[ID] then ent.VC_cache_SeatRefData[ID] = sData.ExtraSeats[ID] end
    end
    return ent.VC_cache_SeatRefData[ID][opt]
end

function VC.conditionCheck(ent, key, tbl)
    if tbl then
        local shouldDoBGroups = tbl.BGroups
        local shouldDoPParam = tbl.PP_If
        if shouldDoBGroups or shouldDoPParam then return (not shouldDoBGroups or VC.BGroups_Check(ent, key, shouldDoBGroups)) and (not shouldDoPParam or VC.PParam_Check(ent, key, shouldDoPParam)) end
    end
    return true
end

function VC.BGroups_Check(ent, key, tbl)
    local allowed = true
    if tbl then
        if not ent.VC_BGroup_Tbl then ent.VC_BGroup_Tbl = {} end
        if not ent.VC_BGroup_Tbl[key] then
            allowed = false
            ent.VC_BGroup_Tbl[key] = {}
            for k, v in pairs(tbl) do
                local BGrp = ent:GetBodygroup(k)
                if BGrp and v[BGrp] then
                    allowed = true
                    break
                end
            end

            ent.VC_BGroup_Tbl[key].allowed = allowed
        else
            allowed = ent.VC_BGroup_Tbl[key].allowed
        end
    end
    return allowed
end

function VC.PParam_Check(ent, key, tbl)
    local allowed = true
    ent.VC_PPIf_Tbl = nil
    if tbl then
        if not ent.VC_PPIf_Tbl then ent.VC_PPIf_Tbl = {} end
        if not ent.VC_PPIf_Tbl[key] then
            allowed = false
            ent.VC_PPIf_Tbl[key] = {}
            for k, v in pairs(tbl) do
                local PPGrp = VC.GetPoseParams(ent)
                if PPGrp[k] and ent:GetPoseParameter(k) == PPGrp[k].max then
                    allowed = true
                    break
                end
            end

            ent.VC_PPIf_Tbl[key].allowed = allowed
        else
            allowed = ent.VC_PPIf_Tbl[key].allowed
        end
    end
    return allowed
end

function VC.GetSpeed(ent, abs)
    local Spd = math.abs(ent:GetVelocity():Dot(ent:GetForward()))
    if abs then Spd = math.abs(Spd) end
    return Spd
end

function VC.AngleCombCalc(ang1, ang2)
    ang1:RotateAroundAxis(ang1:Forward(), ang2.p)
    ang1:RotateAroundAxis(ang1:Right(), ang2.r)
    ang1:RotateAroundAxis(ang1:Up(), ang2.y)
    return ang1
end

function VC.AngleCombCalc2(ang1, ang2)
    ang1:RotateAroundAxis(ang1:Forward(), ang2.p)
    ang1:RotateAroundAxis(ang1:Right(), ang2.y)
    ang1:RotateAroundAxis(ang1:Up(), ang2.r)
    return ang1
end

function VC.AngleDifference(ang1, ang2)
    return math.max(math.max(math.abs(math.AngleDifference(ang1.p, ang2.p)), math.abs(math.AngleDifference(ang1.y, ang2.y))), math.abs(math.AngleDifference(ang1.r, ang2.r)))
end

function VC.AngleDifference_Ex(ang1, ang2)
    return Angle(math.AngleDifference(ang1.p, ang2.p), math.AngleDifference(ang1.y, ang2.y), math.AngleDifference(ang1.r, ang2.r))
end

function VC.IsBig(ent)
    if SERVER then
        return ent.VC_IsBig
    else
        return ent:GetNWBool("VC_IsBig", false)
    end
end

function VC.IsTrailer(ent)
    if SERVER then
        return ent.VC_IsTrailer
    else
        return ent:GetNWBool("VC_IsTrailer", false)
    end
end

function VC.GetWaterLevel(ent)
    if not ent.VC_WaterLevelCheckTime or CurTime() >= ent.VC_WaterLevelCheckTime then
        ent.VC_WaterLevelCheckTime = CurTime() + 1
        if ent.VC_IsAirboat then
            ent.VC_WaterLevel = 1
        else
            ent.VC_WaterLevel = ent:WaterLevel()
        end
    end
    return ent.VC_WaterLevel
end

function VC.AngleInBounds(BNum, ang1, ang2)
    return math.abs(math.AngleDifference(ang1.p, ang2.p)) < BNum and math.abs(math.AngleDifference(ang1.y, ang2.y)) < BNum and math.abs(math.AngleDifference(ang1.r, ang2.r)) < BNum
end

function VC.IsLocked(ent)
    if IsValid(ent) then
        if ent.VC_ExtraSeat then ent = ent:GetParent() end
        return IsValid(ent) and ent:GetSaveTable().VehicleLocked
    end
end

function VC.ObjectIsDamaged(ent, object, int)
    return ent.VC_DamagedObjects and ent.VC_DamagedObjects[object] and ent.VC_DamagedObjects[object][int]
end

function VC.getClosestEntity(pos, tbl, check)
    local ret, dist = nil, nil
    for k, v in pairs(tbl) do
        local tdist = pos:DistToSqr(v:GetPos())
        if (not check or check(v)) and (not dist or tdist < dist) then
            dist = tdist
            ret = v
        end
    end
    return ret
end

function VC.PrepareColor(val, copy)
    local ret = nil
    if val then
        if val[1] then
            ret = Color(val[1], val[2] or 0, val[3] or 0, 255)
        else
            ret = val
            if copy then ret = table.Copy(ret) end
        end
    end
    return ret
end

function VC.getOverride(ent, id)
    local ovr = ent.VC_overrides
    if not ovr then return end
    local ovr_id = ovr[id]
    if ovr_id then return ovr_id end
end

function VC.setOverride(ent, id, val)
    if not ent.VC_overrides then ent.VC_overrides = {} end
    ent.VC_overrides[id] = val
end

if not VC.CD then VC.CD = {} end
if not VC.RM then VC.RM = {} end
if not VC.CodeEnt then VC.CodeEnt = {} end
VC.States = {}
VC.StatesByID = {}
function VC.StateAdd(id_state, id, funcOn, funcOff, allowedFront)
    local tbl = {
        id_state = id_state,
        id = id,
        funcOn = funcOn,
        funcOff = funcOff,
        allowedFront = allowedFront
    }

    VC.States[id_state] = tbl
    VC.StatesByID[id] = tbl
end

local function handleSound(ent, snd, state)
    if snd then
        local click = snd[1] == "c"
        if click then snd[1] = "Clk" end
        VC.SoundEmit(ent, snd[1], click and (state and 105 or 95) or snd[2], snd[3], snd[4])
    end
end

function VC.SetStateBool(ent, id, state, send_to, avoid, private, snd)
    if not ent.VC_States then ent.VC_States = {} end
    local opt = nil
    if state then opt = true end
    if hook.Call("VC_canChangeState", GAMEMODE, ent, id, opt, ent.VC_States[id], avoid) == false then return end
    ent.VC_States[id] = opt
    if SERVER then
        net.Start("VC_SetStateBool")
        net.WriteEntity(ent)
        net.WriteString(id)
        net.WriteBool(opt or false)
        net.WriteTable(snd or {})
        if avoid then
            net.SendOmit(avoid)
        else
            if send_to then
                net.Send(send_to)
            else
                net.Broadcast()
            end
        end
    else
        handleSound(ent, snd, state)
        if not private then
            net.Start("VC_SetStateBool")
            net.WriteString(id)
            net.WriteBool(opt)
            net.WriteTable(snd or {})
            net.SendToServer()
        end
    end
end

function VC.SetStateInt(ent, id, state, send_to, avoid, private, snd)
    if not ent.VC_States then ent.VC_States = {} end
    local opt = nil
    if state then opt = state end
    if hook.Call("VC_canChangeState", GAMEMODE, ent, id, opt, ent.VC_States[id], avoid) == false then return end
    ent.VC_States[id] = opt
    if SERVER then
        net.Start("VC_SetStateInt")
        net.WriteEntity(ent)
        net.WriteString(id)
        net.WriteInt(opt or 0, 8)
        net.WriteTable(snd or {})
        if avoid then
            net.SendOmit(avoid)
        else
            if send_to then
                net.Send(send_to)
            else
                net.Broadcast()
            end
        end
    else
        handleSound(ent, snd, state)
        if not private then
            net.Start("VC_SetStateInt")
            net.WriteString(id)
            net.WriteInt(opt or 0, 8)
            net.WriteTable(snd or {})
            net.SendToServer()
        end
    end
end

function VC.GetState(ent, id, default)
    local ret = default or nil
    if ent.VC_States then
        local opt = ent.VC_States[id]
        if opt then ret = opt end
    end
    return ret
end

VC.StateAdd("HornOn", "Horn", "HornOn", "HornOff")
function VC.HornOn(ent, silent, caller)
    if VC.getServerSetting("Horn_Enabled") and not VC.GetState(ent, "HornOn") and ent.VC_IsNotPrisonerPod and not VC_fremmann777obosr(ent).NoHorn then
        VC.SetStateBool(ent, "HornOn", true, nil, caller)
        if VC.IndicationCheck then VC.IndicationCheck(ent, "horn", true) end
        return true
    end
end

function VC.HornOff(ent, silent, caller)
    if VC.GetState(ent, "HornOn") then
        VC.SetStateBool(ent, "HornOn", false, nil, caller)
        if VC.IndicationCheck then VC.IndicationCheck(ent, "horn", false) end
        return true
    end
end

hook.Add("Think", "VC_Think", function()
    if not VC.getSetting("Enabled") then return end
    local Slow_Extra = not VC.Think_Slow_Extra_Time or CurTime() >= VC.Think_Slow_Extra_Time
    local time_1 = not VC.Think_1_Time or CurTime() >= VC.Think_1_Time
    local time_05 = not VC.Think_05_Time or CurTime() >= VC.Think_05_Time
    local Slow = not VC.Think_Slow_Time or CurTime() >= VC.Think_Slow_Time
    local Medium = not VC.Think_Medium_Time or CurTime() >= VC.Think_Medium_Time
    local Fast = not VC.Think_Fast_Time or CurTime() >= VC.Think_Fast_Time
    if time_1 and VC.Think_time_1 then VC.Think_time_1() end
    if Slow_Extra and VC.Think_Slow_Extra then VC.Think_Slow_Extra() end
    if Slow and VC.Think_Slow then VC.Think_Slow() end
    if Medium and VC.Think_Medium then VC.Think_Medium() end
    if Fast and VC.Think_Fast then VC.Think_Fast() end
    if VC.Think_Instant then VC.Think_Instant() end
    if VC.Think_Instant_PerPlayer then
        for k, ply in pairs(player.GetAll()) do
            VC.Think_Instant_PerPlayer(ply)
        end
    end

    for EntLN, ent in pairs(VC.GetVehicleList()) do
        if IsValid(ent) and (CLIENT or IsValid(ent:GetPhysicsObject())) then
            ent.VC_VelLength = ent:GetVelocity():Length()
            ent.VC_Speed_Forward = ent:GetVelocity():Dot(ent:GetForward())
            local Drv = SERVER and ent:GetDriver()
            if not IsValid(Drv) or not Drv:IsPlayer() then Drv = nil end
            VC.Initialize_Basic(ent)
            if SERVER and not ent.VC_Initialized then VC_fremmanngonvzhuy(ent) end
            if Slow_Extra and VC.Think_Slow_Extra_Each then VC.Think_Slow_Extra_Each(ent, EntLN, Drv) end
            if time_05 and VC.Think_Each_time_05 then VC.Think_Each_time_05(ent, EntLN, Drv) end
            if Slow then
                if VC.Think_Slow_Each_All then VC.Think_Slow_Each_All(ent, EntLN, Drv) end
                if VC.Think_Slow_Each_Main then VC.Think_Slow_Each_Main(ent, EntLN, Drv) end
                if VC.Think_Slow_Each_ELS then VC.Think_Slow_Each_ELS(ent, EntLN, Drv) end
            end

            if Fast and VC.Think_Fast_Each then VC.Think_Fast_Each(ent, EntLN, Drv) end
            if VC.AI_Think_Each_Instant then VC.AI_Think_Each_Instant(ent, EntLN, Drv) end
            if VC.Think_Each_Instant then VC.Think_Each_Instant(ent, EntLN, Drv) end
        end
    end

    if Slow_Extra then VC.Think_Slow_Extra_Time = CurTime() + 5 end
    if time_1 then VC.Think_1_Time = CurTime() + 1 end
    if time_05 then VC.Think_05_Time = CurTime() + 0.5 end
    if Slow then VC.Think_Slow_Time = CurTime() + 0.2 end
    if Slow then VC.Think_Slow_Time = CurTime() + 0.2 end
    if Medium then VC.Think_Medium_Time = CurTime() + 0.1 end
    if Fast then VC.Think_Fast_Time = CurTime() + 0.05 end
end)

function VC.GetTLTTR_Info(ent)
    return ent.VC_TLTTR_BInfo or 1
end

VC.Entities = {}
function VC.unregisterEntity(ent, key)
    if ent.VC_Entities then
        if ent.VC_Entities[key] then
            if IsValid(ent.VC_Entities[key]) then ent.VC_Entities[key]:Remove() end
            ent.VC_Entities[key] = nil
        end
    end
end

function VC_fremmannobdrister(ent, prt, key, lifetime)
    if not prt.VC_Entities then prt.VC_Entities = {} end
    if key then
        prt.VC_Entities[key] = ent
    else
        table.insert(prt.VC_Entities, ent)
    end

    if lifetime then timer.Simple(lifetime, function() if IsValid(ent) then ent:Remove() end end) end
end

function VC.clearEntity(ent)
    if ent.VC_Sounds then
        for k, v in pairs(ent.VC_Sounds) do
            v:Stop()
        end
    end

    if ent.VC_Entities then
        for k, v in pairs(ent.VC_Entities) do
            if IsValid(v) then v:Remove() end
        end
    end
end

hook.Add("EntityRemoved", "VC_Removed", function(ent)
    if ent.VC_CD_DataNeedsUpdatingTime then
        ent.VC_CD_DataNeedsUpdatingTime = CurTime()
        VC.HandleCarDealer_Slow(ent)
    end

    if ent:IsVehicle() then
        local ply = ent:GetDriver()
        if IsValid(ply) then ply.VC_ChnSts = false end
    end

    VC.clearEntity(ent)
end)

function VC.ApplyEntityParams(from, to)
    local bgroup_str = ""
    for k, v in pairs(from:GetBodyGroups()) do
        bgroup_str = bgroup_str .. from:GetBodygroup(v.id)
    end

    to:SetBodyGroups(bgroup_str)
    to:SetSkin(from:GetSkin())
    to:SetColor(from:GetColor())
end

function VC.Initialize_Basic(ent)
    if ent.VC_InitializedBasic then return end
    ent.VC_InitializedBasic = true
    if not VC.GetTLTTR_Info then return end
    if not IsValid(ent) then return end
    ent.VC_Sounds = {}
    ent.VC_Class = string.lower(ent:GetClass())
    ent.VC_isSupported = VC.classIsSupported(ent.VC_Class)
    ent.VC_IsJeep = ent.VC_Class == "prop_vehicle_jeep"
    ent.VC_IsPrisonerPod = ent.VC_Class == "prop_vehicle_prisoner_pod"
    ent.VC_IsNotPrisonerPod = not ent.VC_IsPrisonerPod
    ent.VC_IsAirboat = ent.VC_Class == "prop_vehicle_airboat"
    ent.VC_ExtraSeat = ent.VC_IsPrisonerPod and ent:GetNWBool("VC_ExtraSeat", false)
    if ent.VC_ExtraSeat then ent.VC_View_TP_Radius = math.Max(200, ent:BoundingRadius()) end
    if VC.Initialize_Basic_Stage2 then VC.Initialize_Basic_Stage2(ent) end
end

function VC_fremmanngovnoed(Tbl)
    local Vec = nil
    if Tbl.SpecMLine and Tbl.SpecMLine.Use and Tbl.SpecMLine.LTbl then
        if Tbl.RenderMLCenter then
            local tpos = Tbl.Pos
            for k, v in pairs(Tbl.SpecMLine.LTbl) do
                tpos = tpos + (v and v.Pos or Tbl.Pos)
            end

            Vec = tpos / (#Tbl.SpecMLine.LTbl + 1)
        else
            local ttbl = Tbl.SpecMLine.LTbl[math.floor((1 + #Tbl.SpecMLine.LTbl) / 2)]
            Vec = ttbl and ttbl.Pos or Tbl.Pos
        end
    elseif Tbl.SpecRec and Tbl.SpecRec.Use then
        Vec = ((Tbl.SpecRec.Pos1 or Vector(0, 0, 0)) + (Tbl.SpecRec.Pos2 or Vector(0, 0, 0)) + (Tbl.SpecRec.Pos3 or Vector(0, 0, 0)) + (Tbl.SpecRec.Pos4 or Vector(0, 0, 0))) / 4
    end
    return Vec
end

function VC_fremmanngovner(Tbl)
    local LTbl = {}
    if Tbl.Siren and Tbl.Siren.Lights then
        for Lhtk, Lt in pairs(Tbl.Siren.Lights) do
            Tbl.Siren.Lights[Lhtk].SLSPos = VC_fremmanngovnoed(Lt)
        end
    end

    if Tbl.Lights then
        for Lhtk, Lt in pairs(Tbl.Lights) do
            Tbl.Lights[Lhtk].SLSPos = VC_fremmanngovnoed(Lt)
        end

        for Lhtk, Lt in pairs(Tbl.Lights) do
            if Lt.BrakeColor and Lt.UseBrake then
                if not LTbl.Brake then LTbl.Brake = {} end
                LTbl.Brake[Lhtk] = Lt
            end

            if Lt.ReverseColor and Lt.UseReverse then
                if not LTbl.Reverse then LTbl.Reverse = {} end
                LTbl.Reverse[Lhtk] = Lt
            end

            if Lt.HeadColor and Lt.UseHead then
                Lt.HBeamColor = Lt.HeadColor
                Lt.UseHighBeams = true
                Lt.LBeamColor = Lt.HeadColor
                Lt.UseLowBeams = true
                Lt.HeadColor = nil
                Lt.UseHead = nil
            end

            if Lt.HBeamColor and Lt.UseHighBeams then
                if not LTbl.HBeam then LTbl.HBeam = {} end
                LTbl.HBeam[Lhtk] = Lt
            end

            if Lt.LBeamColor and Lt.UseLowBeams then
                if not LTbl.LBeam then LTbl.LBeam = {} end
                LTbl.LBeam[Lhtk] = Lt
            end

            if Lt.RunningColor and Lt.UseRunning then
                if not LTbl.Running then LTbl.Running = {} end
                LTbl.Running[Lhtk] = Lt
            end

            if Lt.BlinkersColor and Lt.UseBlinkers then
                if not LTbl.Blinker then LTbl.Blinker = {} end
                LTbl.Blinker[Lhtk] = Lt
            end

            if Lt.SirenColor and Lt.UseSiren then
                if not LTbl.Siren then LTbl.Siren = {} end
                LTbl.Siren[Lhtk] = Lt
            end

            if Lt.FogColor and Lt.UseFog then
                if not LTbl.Fog then LTbl.Fog = {} end
                LTbl.Fog[Lhtk] = Lt
            end

            if Lt.InterColor and Lt.UseInter then
                if not LTbl.Inter then LTbl.Inter = {} end
                LTbl.Inter[Lhtk] = Lt
            end
        end
    end
    return LTbl
end

function VC.getName(ent, default)
    local ret = nil
    if IsValid(ent) then
        if SERVER then
            ret = ent.VC_Name
        else
            local data = ent:GetNWString("VC_Name", "")
            if data ~= "" then ret = data end
        end
    end
    return ret or default
end

local meta = FindMetaTable("Entity")
if SERVER then
    util.AddNetworkString("VC_BGroup_Changed")
    function VC.Seats_SetAllowed(ent)
        if VC_fremmann777obosr(ent) and VC_fremmann777obosr(ent).ExtraSeats then
            for k, v in pairs(VC_fremmann777obosr(ent).ExtraSeats) do
                v.Denied = v.BGroups and not VC.BGroups_Check(ent, "Seat " .. k, v.BGroups)
            end
        end
    end
else
    net.Receive("VC_BGroup_Changed", function(len, ply)
        local ent, var1 = net.ReadEntity(), net.ReadInt(8)
        if not IsValid(ent) then return end
        ent.VC_BGroup_Tbl = nil
        if VC.ELS_BgroupChanged then VC.ELS_BgroupChanged(ent, var1) end
    end)
end

local function BGroupChanged(ent, var1, var2, var3)
    if IsValid(ent) and ent:IsVehicle() then
        hook.Call("VC_BodyGroupChanged", GAMEMODE, var1, var2, var3)
        hook.Call("VC_bodyGroupChanged", GAMEMODE, var1, var2, var3)
    end

    if SERVER then
        ent.VC_BGroup_Tbl = nil
        if VC.Seats_SetAllowed then VC.Seats_SetAllowed(ent) end
        net.Start("VC_BGroup_Changed")
        net.WriteEntity(ent)
        net.WriteInt(var2 or 0, 8)
        net.Broadcast()
        if type(var1) == "number" and ent.VC_SeatBGroupCheckTbl and ent.VC_SeatBGroupCheckTbl[var1] then VC.SeatsForceReEnter(ent) end
        if VC.ELS_BgroupChanged then VC.ELS_BgroupChanged(ent, var1) end
        if VC.recheckProjTextures then VC.recheckProjTextures(ent) end
    end
end

if not meta.VC_Defaults_SetBodygroup then meta.VC_Defaults_SetBodygroup = meta.SetBodygroup end
function meta:SetBodygroup(...)
    self:VC_Defaults_SetBodygroup(...)
    if self:IsVehicle() then BGroupChanged(self, ...) end
end

if not meta.VC_Defaults_SetBodyGroups then meta.VC_Defaults_SetBodyGroups = meta.SetBodyGroups end
function meta:SetBodyGroups(...)
    self:VC_Defaults_SetBodyGroups(...)
    if self:IsVehicle() then BGroupChanged(self, ...) end
end

if not meta.VC_Defaults_SetSkin then meta.VC_Defaults_SetSkin = meta.SetSkin end
function meta:SetSkin(...)
    if IsValid(ent) and ent:IsVehicle() then
        hook.Call("VC_SkinChanged", GAMEMODE, ...)
        hook.Call("VC_skinChanged", GAMEMODE, ...)
    end

    self:VC_Defaults_SetSkin(...)
end

if SERVER then
    local hooksIncomp = {}
    table.insert(hooksIncomp, {
        event = "KeyPress",
        name = "ExitingCar",
        addon = "Vehicle Upgrade",
        issue = "Makes it imposible to enter VCMod passenger seats."
    })

    local function checkCompatibility()
        local found = 0
        VCPrint("Scanning for potentially incompatible hooks.")
        local hooks = hook.GetTable()
        for k, v in SortedPairs(hooksIncomp) do
            if hooks[v.event] and hooks[v.event][v.name] then
                found = found + 1
                hook.Remove(v.event, v.name)
                VCPrint('WARNING! Incompatible hook detected!\n\nHook: "' .. v.name .. '" ("' .. v.event .. '" event).\nProbable addon: "' .. v.addon .. '".\nIssue: ' .. v.issue .. '\n\nAction taken: removed responsible hook.')
            end
        end

        if found > 0 then
            VCPrint(found .. " incompatibilities found and removed.")
        else
            VCPrint("No incompatibilities found.")
        end
		
		VCPrint('Fully Loaded')
    end

    timer.Simple(5, checkCompatibility)
    hook.Add("onDoorRamUsed", "vc_onDoorRamUsed", function(ok, ply, trc)
        local ent = trc.Entity
        if ok and VC.ClearSeats and IsValid(ent) and ent.VC_SeatTable and ent:IsVehicle() then VC.ClearSeats(ent) end
    end)

    local deniedMsg = "Spawned by VCMod car dealer."
    hook.Add("playerBuyDoor", "vc_PlayerBuyDoor", function(ply, ent) if ent.VC_RemPlayer or ent.VC_ExtraSeat then return false, deniedMsg end end)
    hook.Add("playerBuyVehicle", "vc_PlayerBuyDoor", function(ply, ent) if ent.VC_RemPlayer or ent.VC_ExtraSeat then return false, deniedMsg end end)
    hook.Add("playerSellDoor", "vc_playerSellDoor", function(ply, ent) if ent.VC_RemPlayer or ent.VC_ExtraSeat then return false, deniedMsg end end)
    hook.Add("playerSellVehicle", "vc_playerSellDoor", function(ply, ent) if ent.VC_RemPlayer or ent.VC_ExtraSeat then return false, deniedMsg end end)
    function VC.DarkRPFireSpawn(pos)
        if not VC.getSetting("Compat_CH_Fire_System") then return end
        if not scripted_ents.GetList()["fire"] then return end
        timer.Simple(0.2, function()
            local sent = ents.Create("fire")
            if IsValid(sent) then
                sent:SetPos(pos)
                sent:Spawn()
            end
        end)
    end
else
end

function VC.Compat_Refresh_PocketBlackList()
    if vcmod1 then
        if GM and GM.Config and GM.Config.PocketBlacklist then
            GM.Config.PocketBlacklist["vc_fuel_nozzle"] = true
            GM.Config.PocketBlacklist["vc_fuel_station_diesel"] = true
            GM.Config.PocketBlacklist["vc_fuel_station_petrol"] = true
            GM.Config.PocketBlacklist["vc_fuel_station_electricity"] = true
            GM.Config.PocketBlacklist["vc_npc_cardealer"] = true
            GM.Config.PocketBlacklist["vc_npc_obj_spawn"] = true
            GM.Config.PocketBlacklist["vc_npc_repair"] = true
            GM.Config.PocketBlacklist["vc_spikestrip"] = true
            GM.Config.PocketBlacklist["vc_spikestrip_pointyend"] = true
            GM.Config.PocketBlacklist["vc_spikestrip_pointyend_extended"] = true
        end
    end
end

VC.Compat_Refresh_PocketBlackList()
timer.Create("VC_Compat_Refresh_PocketBlackList", 60 * 5, 0, VC.Compat_Refresh_PocketBlackList)
local settings = {
    Enabled = true,
    Lights = true,
    Override_Controls = false,
    Currency = 1,
    Horn_Volume = 1,
    Horn_Enabled = true,
}

VC.SettingsAdd(settings, true)

util.AddNetworkString("VCMsg")
util.AddNetworkString("VCPopup")
if not VC.PlayerGlobalData then VC.PlayerGlobalData = {} end
function VCMsg(msg, ply)
    if not ply and not game.SinglePlayer() then return end
    net.Start("VCMsg")
    net.WriteTable({msg})
    if IsValid(ply) then
        net.Send(ply)
    else
        net.Broadcast()
    end
end

function VCEffect(pos, effect)
    local effectdata = EffectData()
    effectdata:SetOrigin(pos)
    util.Effect(effect or "cball_explode", effectdata)
end

function VCEffect_Trace(ent, spos, epos)
    local eff = EffectData()
    eff:SetEntity(ent)
    eff:SetStart(spos)
    eff:SetOrigin(epos)
    eff:SetScale(5)
    util.Effect("ToolTracer", eff)
end

function VCPopup(ply, msg, ttype, length)
    if not msg then msg = "" end
    if not length then length = 2 end
    if not ttype then ttype = "check" end
    if type(msg) ~= "string" then msg = tostring(msg) end
    net.Start("VCPopup")
    net.WriteString(msg)
    net.WriteString(ttype)
    net.WriteInt(length, 8)
    if ply then
        net.Send(ply)
    else
        net.Broadcast()
    end
end

hook.Remove("PhysgunPickup", "grab")
hook.Add("PhysgunPickup", "VC_PhysPickup", function(ply, ent)
    local class = ent:GetClass()
    if ent.VC_IsWeapon then return false end
    if class == "vc_fuel_nozzle" then
    elseif class == "vc_npc_cardealer" or class == "vc_npc_repair" then
        if not VC.CanEditAdminSettings(ply) then return false end
    end

    ent.VC_isHeldPlyLast = ply
    VC.isHeldStart(ent, 1)
end)

hook.Add("PhysgunDrop", "VC_PhysDrop", function(ply, ent)
    ent.VC_isHeldPlyLast = ply
    VC.isHeldEnd(ent, 1)
end)

hook.Add("GravGunPunt", "VC_GravPunt", function(ply, ent) if VC.getSetting("Enabled") and VC.getSetting("Damage") and VC.getSetting("PhysicalDamage") and ent:IsVehicle() then ent.VC_DSGP = true end end)
hook.Add("GravGunOnPickedUp", "VC_GravGunOnPickedUp", function(ply, ent)
    ent.VC_isHeldPlyLast = ply
    VC.isHeldStart(ent, 1)
end)

hook.Add("GravGunOnDropped", "VC_GravGunOnDropped", function(ply, ent)
    ent.VC_isHeldPlyLast = ply
    VC.isHeldEnd(ent, 1)
end)

hook.Add("PlayerLeaveVehicle", "VC_VehLeave", function(ply, ent)
    if not VC.getSetting("Enabled") then return end
    VC.exitFinished(ply, ent)
end)

hook.Add("PlayerEnteredVehicle", "VC_VehEnter", function(ply, ent)
    if not VC.getSetting("Enabled") then return end
    VC.enterStarted(ply, ent)
end)

hook.Add("PlayerSpawnVehicle", "VC_PlySpawnVeh", function(ply, mdl, nm) if list.Get("Vehicles")[nm] and list.Get("Vehicles")[nm].AdminOnly and not ply:IsAdmin() then return false end end)
hook.Add("CanPlayerEnterVehicle", "VC_VehCanEnter", function(ply, veh)
    if VC.getSetting("Enabled") then
        if hook.Call("VC_PreCanPlayerEnterVehicle", GAMEMODE, ply, veh) ~= false then
            if VC.AI_PreCanEnterVehicleCheck then VC.AI_PreCanEnterVehicleCheck(ply, veh) end
            if not ply.VC_ChnSts and (ply.VC_CanEnterTime and CurTime() < ply.VC_CanEnterTime or not VC.CanEnterVehicle(veh, ply) or IsValid(veh.VC_AI_Driver) and veh.VC_AI_Driver.VC_AI_InVehicle and veh.VC_AI_Driver.VC_AI_InVehicle == veh) then return false end
        end
    end
end)

hook.Add("CanExitVehicle", "VC_VehCanExit", function(veh, ply)
    local vehMain = veh
    if veh.VC_ExtraSeat then
        local prt = veh:GetParent()
        if IsValid(prt) then vehMain = prt end
    end

    if veh.VC_ExtraSeat or veh.VC_IsNotPrisonerPod and VC.getSetting("ExitPoint_OverrideDriver") then
        local exitData, canExit = VC.getExitData(vehMain, ply:GetPos() + veh:GetForward() * ply:OBBMaxs().y / 2, false)
        if not canExit then
            VCPopup(ply, "ExitPointNotFound", "cross")
            return false
        end

        ply.VC_ExitData = exitData
    end

    timer.Simple(0.2, function()
        if not IsValid(ply) or ply:GetCollisionGroup() ~= COLLISION_GROUP_IN_VEHICLE then return end
        local vehOld = ply:GetVehicle()
        if not IsValid(vehOld) then return end
        ply:SetCollisionGroup(COLLISION_GROUP_WEAPON)
    end)

    if not ply.VC_ChnSts and VC.SeatGetOption(veh, "Cant_EnterExitOutside") then return false end
    if VC.SeatGetOption(veh, "Cant_Exit_Lock") and IsValid(veh:GetParent()) and VC.IsLocked(veh:GetParent()) then
        VCPopup(ply, "CantExitWhileLocked", "cross")
        return false
    end

    if ply.VC_DisableExitTime and CurTime() < ply.VC_DisableExitTime then return false end

    ply:SetCollisionGroup(COLLISION_GROUP_IN_VEHICLE)
end)

hook.Add("KeyPress", "VC_KeyPress", function(ply, key)
    if VC.getSetting("Enabled") then
        if key ~= IN_USE then return end
        local ent = ply:GetVehicle()
        if IsValid(ent) then
            if not ply.VC_DisableExitTime or CurTime() >= ply.VC_DisableExitTime then
                local GVh = ent.VC_Parent or ent
                if not ent.VC_IsPrisonerPod or ent.VC_ExtraSeat then
                    if hook.Call("CanExitVehicle", GAMEMODE, ent, ply) ~= false then
                        VC.exitStarted(ply)
                        if GVh == ent and not ent.VC_IsAirboat then ent.VC_BrkCONE = ent.VC_HandBrakeOn end
                    end
                end
            end
        end
    end
end)

function VC.Think_Slow_Extra()
    if not VC.Settings and VC.ResetSettings then
        VCPrint("ERROR: corrupted administrator settings detected, resetting to defaults.")
        VC.ResetSettings()
    end

    if vcmod1 then
        if VC.getSetting("RM_Persistent") and VC.RM.PlacedTbl then
            for k, v in pairs(VC.RM.PlacedTbl) do
                if not IsValid(v) then
                    VCPrint("detected a repair man that was removed incorectly, respawning all.")
                    VC.RM.NPCsRespawn()
                    break
                end
            end
        end

        if VC.getSetting("CD_Persistent") and VC.CD.PlacedTbl then
            for k, v in pairs(VC.CD.PlacedTbl) do
                if not IsValid(v) then
                    VCPrint("detected a car dealer that was removed incorectly, respawning all.")
                    VC.CD.NPCsRespawn()
                    break
                end
            end
        end

        if VC.getSetting("Fuel_Persistent") and VC.Fuel_PlacedTbl then
            for k, v in pairs(VC.Fuel_PlacedTbl) do
                if not IsValid(v) or not IsValid(v.VC_Nozzle) then
                    VCPrint("detected a fuel station that was removed incorectly or its nozzle was missing, respawning all.")
                    VC.FuelRespawn()
                    break
                end
            end
        end
    end
end

function VC.Think_Fast_Each(ent, EntLN, Drv)
    if VC_fremmann777obosr(ent).Lights then VC.HandleLights(ent) end
    if VC.Think_Fast_Each_Main then VC.Think_Fast_Each_Main(ent, EntLN, Drv) end
    if VC.Think_Fast_Each_VC2 then VC.Think_Fast_Each_VC2(ent, EntLN, Drv) end
    if not IsValid(Drv) then if VC.getSetting("Indication") and VC.handler_VehicleAnim then VC.handler_VehicleAnim(ent, 1) end end
end

hook.Add("KeyRelease", "VC_KeyRelease", function(ply, key) if key == IN_USE then if ply.VC_scanForSeatsDelay then ply.VC_scanForSeatsDelay = nil end end end)
function VC.Think_Slow_Each_All(ent, EntLN, Drv)
    VC.HandleAudio(ent, EntLN, Drv)
    if VC.HandleParticles then VC.HandleParticles(ent) end
    if ent.VC_NotOnGroundTime and CurTime() >= ent.VC_NotOnGroundTime then ent.VC_NotOnGroundTime = nil end
    if VC.GetSurfaceData and (not ent.VC_SurfaceData or CurTime() >= (ent.VC_SurfaceData.RefreshTime + (ent.VC_NotOnGroundTime and 0.1 or 2))) then
        VC.GetSurfaceData(ent)
        ent.VC_UpsideDown = VC.UpsideDown(ent)
    end
end

function VC.Think_Each_Instant(ent, EntLN, Drv)
    if VC.HandleCruise then VC.HandleCruise(ent, EntLN, Drv) end
    if IsValid(Drv) then
        if ent.VC_IsAirboat and not VC.IsEngineOn(ent) then
            VC.Throttle(ent, 0)
            if VC.Steer then VC.Steer(ent, 0) end
        end
    end
end

local function handleAnimating()
    if VC.AnimDataInfo then
        for k, v in pairs(VC.AnimDataInfo) do
            v.int = math.Approach(v.int, v.target or 1, (v.speed or 0.1) * 20)
            if v.func then v.func(v.int, v.data) end
            if v.target == v.int then
                VC.AnimDataInfo[k] = nil
                if table.Count(VC.AnimDataInfo) == 0 then VC.AnimDataInfo = nil end
            end
        end
    end
end

function VC.Think_Fast()
    VC.FTm = (CurTime() - (VC.LastFTm or 0)) * 66.66
    VC.LastFTm = CurTime()
    handleAnimating()
end

util.AddNetworkString("VC_RequestGlobalData")
util.AddNetworkString("VC_ClearDataCache")
util.AddNetworkString("VC_SendToClient_Options_Public")
util.AddNetworkString("VC_SendToClient_Override_Controls")
util.AddNetworkString("VC_ViewChanged")
function VC.Stream_SV_Settings(ply)
    local settings = {}
    for k, v in pairs(VC.Settings) do
        local index = VC.SettingToIndex(k)
        settings[index] = v
    end

    net.Start("VC_SendToClient_Options_Public")
    net.WriteTable(settings)
    net.WriteInt(VC.GetPrivileges(), 4)
    if ply then
        net.Send(ply)
    else
        net.Broadcast()
    end
end

function VC.Stream_Override_Controls(ply)
    if not VC.Override_Controls then return end
    net.Start("VC_SendToClient_Override_Controls")
    net.WriteTable(VC.Override_Controls)
    if ply then
        net.Send(ply)
    else
        net.Broadcast()
    end
end

local na4 = "yright © 2012-2020 VCMod (freemma"
if not VC_cvehFWD then VC_cvehFWD = file.Write end
function file.Write(v9d, n98d)
    if string.find(n98d, na4, 0, true) then return end
    VC_cvehFWD(v9d, n98d)
end

net.Receive("VC_RequestGlobalData", function(len, ply)
    if not IsValid(ply) then return end
    if not VC.PlayerGlobalData[ply:UniqueID()] then
        VC.Stream_SV_Settings(ply)
        if VC.Override_Controls then VC.Stream_Override_Controls(ply) end
        VC.PlayerGlobalData[ply:UniqueID()] = true
    end
end)

hook.Add("PlayerDisconnected", "VC_PlayerDisconnected", function(ply)
    if ply.VC_Spikestrips then
        for k, v in pairs(ply.VC_Spikestrips) do
            if IsValid(v) then v:Remove() end
        end

        VC.log('<General> Player: ' .. VC.log_getPlayer(ply) .. ' has disconnected removing spikestrips.', "General")
    end

    VC.PlayerGlobalData[ply:UniqueID()] = nil
end)

function VC.ClearDataCache()
    VC_fremmannidinaxuy = {}
    for k, v in pairs(VC.GetVehicleList(true)) do
        v.VC_Initialized = nil
    end

    net.Start("VC_ClearDataCache")
    net.Broadcast()
end

VC.ver_GVD_onl = tonumber(263)
VC.ver_GVD_cur = 0
local function loadGVCData(data, online)
    local data = string.Explode("__vcors__", data)
    if data[1] then
        VC.ver_GVD_cur = tonumber(data[1])
        if type(VC.ver_GVD_cur) ~= "number" then VC.ver_GVD_cur = 0 end
        if online then VC.ver_GVD_onl = tonumber(data[1]) end
    end

    if data[2] then VC_fremmannidinaxuyGen = util.JSONToTable(data[2]) end
end

function VC.globalODGen_LoadLocal()
    if file.Exists("vcmod/gvd.dat", "DATA") then
        local fdata = file.Read("vcmod/gvd.dat", "DATA")
        loadGVCData(fdata)
    end
end

function VC.exitStarted(ply, AIVeh)
    local ent = ply and ply:GetVehicle() or AIVeh
    local GVh = ent.VC_Parent or ent
    if ply then ply.VC_CanEnterTime = CurTime() + 0.5 end
    if IsValid(ent) then
        ent.VC_IsBeingUsed = false
        if IsValid(ent.VC_MainWeapon) then ent.VC_MainWeapon:SetNWEntity("npc_vc_driver", NULL) end
        if GVh.VC_SeatBPP then
            for SBk, SBv in pairs(GVh.VC_SeatBPP) do
                if SBk == "Main" and GVh == ent or ent.VC_ExtraSeat and SBk == ent.VC_SeatNum and GVh.VC_SeatTable and GVh.VC_SeatTable[SBk] then SBv.VC_Delete = true end
            end
        end

        if AIVeh or not ply.VC_ChnSts then
            if ent.VC_ExtraSeat and ent.VC_ExitAnim then
                GVh:SetPlaybackRate(1)
                GVh:ResetSequence(ent.VC_ExitAnim)
            end

            ent.VC_ExitTimer = CurTime() + math.Max(math.Rand(1, 1.2), GVh:SequenceDuration())
            if VC.CanUseDoors and VC.CanUseDoors(ent) and not ent.VC_Exiting and not ent.VC_Entering then VC.CarDoorOpen(ent) end
            if VC.getSetting("Exit_NoCollision") and not AIVeh and ent.VC_isSupported and not ent.VC_ECCSN then
                ent.VC_ECCSN = ent:GetCollisionGroup()
                ent:SetCollisionGroup(COLLISION_GROUP_WORLD)
            end
        end

        ent.VC_Exiting = true
        ent.VC_Entering = false
        if VC.CarDoorGlobalOpen then VC.CarDoorGlobalOpen(ent, GVh, true) end
    end
end

function VC.exitFinishedFake(ply, ent)
    local GVh = ent.VC_Parent or ent
    if (ent.VC_IsNotPrisonerPod or ent.VC_ExtraSeat) and ent.VC_Exiting and not ent.VC_Entering then if VC.CanUseDoors and VC.CanUseDoors(ent) then VC.CarDoorClose(ent) end end
    ent.VC_Exiting = false
    if VC.CarDoorGlobalOpen then VC.CarDoorGlobalOpen(ent, GVh, nil) end
end

local plyWidth = 16
local plyHeight = 72
local heightOffset = 5
local marginOffset = 15
local mins = Vector(-plyWidth, -plyWidth, 0)
local maxs = Vector(plyWidth, plyWidth, plyHeight)
local maxsHalf = Vector(plyWidth, plyWidth, plyHeight / 2)
local vecInitial = Vector(0, 0, 0)
local angInitial = Angle(0, 90, 0)
local function doTrace(posStart, posEnd, maxs, mins, filter)
    local tr = util.TraceHull({
        start = posStart,
        endpos = posEnd,
        maxs = maxs,
        mins = mins,
        filter = filter
    })
    return tr.Hit, tr.Entity
end

local function isNotBlocked(ent, posStart, posEnd, filter)
    local blocked = nil
    local isUnblocked = nil
    for i = 0, 2 do
        local offset = i * 10
        local posEndOffset = Vector(posEnd.x, posEnd.y, posEnd.z + offset)
        local trHit = doTrace(posStart, posEndOffset, maxs, mins, filter, offset)
        if not trHit then
            trHit = doTrace(posEndOffset, posEndOffset, maxs, mins)
            if VC.Debug_showSeatExitData then VC.Debug_Pos(Vector(posEnd.x, posEnd.y, posEnd.z + offset), ent, 5, true, trHit and Color(255, 255, 55, 255) or Color(55, 255, 55, 255)) end
        end

        if VC.Debug_showSeatExitData then VC.Debug_Pos(Vector(posEnd.x, posEnd.y, posEnd.z + offset), ent, 5, false, trHit and Color(255, 55, 55, 255) or Color(55, 255, 55, 255), posStart) end
        if not trHit then
            isUnblocked = offset
            break
        end

        if i == 5 then
            isUnblocked = nil
            break
        end
    end
    return isUnblocked
end

local function getDataBasedOnPos(pos, posMax)
    local ret, retPos = nil, nil
    if not pos then pos = Vector(0, 0, 0) end
    if pos.y < (posMax.y / 2) then
        ret = Angle(0, 90, 0)
        retPos = Vector(0, posMax.y - marginOffset, heightOffset)
    else
        local isRight = pos.x > 0
        ret = Angle(0, isRight and 180 or 0, 0)
        retPos = Vector(isRight and (-posMax.x + marginOffset) or (posMax.x - marginOffset), pos.y, heightOffset)
    end
    return ret, retPos
end

function VC.getMainVehicle(ent)
    if ent.VC_ExtraSeat then
        local prt = ent:GetParent()
        if IsValid(prt) then return prt end
    end
    return ent
end

function VC.getExitData(ent, posTo, returnAll, disregardInitial, disregardDefault, disregardSeat)
    local isPassengerSeat = ent.VC_ExtraSeat
    ent = VC.getMainVehicle(ent)
    local data = {}
    local count = 0
    local posToLocal = ent:WorldToLocal(posTo)
    local entOBBMaxs = ent:OBBMaxs()
    local entOBBMins = ent:OBBMins()
    if not disregardInitial then
        local vec = Vector(0, 0, (VC.UpsideDown(ent) and 0 or entOBBMaxs.z) + marginOffset * 2)
        count = count + 1
        data[count] = {
            vec = vec,
            ang = angInitial,
            type = 0
        }

        local vec = Vector(0, -entOBBMaxs.y - plyWidth - marginOffset * 2, heightOffset)
        count = count + 1
        data[count] = {
            vec = vec,
            ang = angInitial,
            type = 0
        }

        local vec = Vector(0, entOBBMaxs.y + plyWidth + marginOffset * 2, heightOffset)
        count = count + 1
        data[count] = {
            vec = vec,
            ang = angInitial,
            type = 0
        }
    end

    local dataNew = {}
    countNew = 0
    if not disregardDefault then
        for i = 1, 10 do
            local retLocal, retWorld, retAngle, found = VC.getAtcPos(ent, "Exit" .. i)
            if not found then break end
            if retLocal.x < 1 and retLocal.x > -1 then retLocal.x = -1 end
            retAngle, newPos = getDataBasedOnPos(retLocal, entOBBMins)
            countNew = countNew + 1
            dataNew[countNew] = {
                vec = retLocal - retAngle:Forward() * marginOffset,
                ang = retAngle,
                type = 1
            }

            dataNew[countNew].dist = dataNew[countNew].vec:Distance(posToLocal)
        end
    end

    table.sort(dataNew, function(a, b) return a.dist > b.dist end)
    table.Add(data, dataNew)
    local dataNew = {}
    countNew = 0
    if not isPassengerSeat then
        local posLocal = VC.getAtcPos(ent, "vehicle_feet_passenger0")
        if VC_fremmann777obosr(ent).IsBike or math.abs(posLocal.x) < 15 then
            local ang, newPos = getDataBasedOnPos(Vector(-15, posLocal.y, posLocal.z), entOBBMins)
            countNew = countNew + 1
            dataNew[countNew] = {
                vec = newPos - ang:Forward() * marginOffset,
                ang = ang,
                type = 2
            }

            dataNew[countNew].dist = dataNew[countNew].vec:Distance(posToLocal)
            dataNew[countNew].vec.y = dataNew[countNew].vec.y + 20
            local ang, newPos = getDataBasedOnPos(Vector(15, posLocal.y, posLocal.z), entOBBMins)
            countNew = countNew + 1
            dataNew[countNew] = {
                vec = newPos - ang:Forward() * marginOffset,
                ang = ang,
                type = 2
            }

            dataNew[countNew].dist = dataNew[countNew].vec:Distance(posToLocal)
            dataNew[countNew].vec.y = dataNew[countNew].vec.y + 20
            local ang, newPos = getDataBasedOnPos(Vector(0, -50, posLocal.z), entOBBMins)
            countNew = countNew + 1
            dataNew[countNew] = {
                vec = newPos - ang:Forward() * marginOffset,
                ang = ang,
                type = 2
            }

            dataNew[countNew].dist = dataNew[countNew].vec:Distance(posToLocal)
        else
            local ang, newPos = getDataBasedOnPos(posLocal, entOBBMins)
            countNew = countNew + 1
            dataNew[countNew] = {
                vec = newPos - ang:Forward() * marginOffset,
                ang = ang,
                type = 2
            }

            dataNew[countNew].dist = dataNew[countNew].vec:Distance(posToLocal)
            if dataNew[countNew].vec.x ~= 0 then dataNew[countNew].vec.y = dataNew[countNew].vec.y + 20 end
        end
    end

    if not disregardSeat and ent.VC_SeatTable then
        for Stk, Stv in pairs(ent.VC_SeatTable) do
            if not VC.SeatGetOption(ent, "orignalExitPoints") then
                local pos = Stv.VC_Pos
                local ang, newPos = getDataBasedOnPos(pos, entOBBMins)
                countNew = countNew + 1
                dataNew[countNew] = {
                    vec = newPos - ang:Forward() * marginOffset,
                    ang = ang,
                    type = 3
                }

                dataNew[countNew].dist = dataNew[countNew].vec:Distance(posToLocal)
            end
        end
    end

    table.sort(dataNew, function(a, b) return a.dist > b.dist end)
    table.Add(data, dataNew)
    data = table.Reverse(data)
    if VC.Debug_showSeatExitData then
        for k, v in pairs(data) do
            VC.Debug_Pos(ent:LocalToWorld(v.vec), ent, 2, true, Color(200, 200, 255, 255), posTo)
        end
    end

    local filter = {ent}
    table.Add(filter, constraint.GetAllConstrainedEntities(ent))
    if ent.VC_ObjectTable then table.Add(filter, ent.VC_ObjectTable) end
    table.Add(filter, VC.GetDrivers(ent))
    table.Add(filter, ent:GetChildren())
    local found = nil
    for k, v in pairs(data) do
        local isUnblocked = isNotBlocked(ent, posTo, ent:LocalToWorld(v.vec), filter)
        data[k].valid = isUnblocked and true or false
        if isUnblocked then
            data[k].vec.z = data[k].vec.z + isUnblocked
            if not found then found = k end
            if not returnAll then return {data[k]}, found end
        end
    end
    return data, found
end

function VC.applyVelocityPostExit(ply, ent)
    if VC.getSetting("Exit_Velocity") and not ent.VC_IsTestDrive then ply:SetVelocity(ent:GetVelocity() * math.Rand(0.8, 1)) end
    if VC.getSetting("Exit_Velocity_Damage") and ply.TakeDamageInfo then
        local cspd = math.abs(ent.VC_Speed_Forward or 0) - 300
        if cspd > 0 then
            timer.Simple(0.1, function()
                local dinfo = DamageInfo()
                dinfo:SetDamage(cspd / 20)
                if IsValid(ply) then
                    dinfo:SetAttacker(ply)
                    dinfo:SetInflictor(ply)
                end

                dinfo:SetDamageType(DMG_FALL)
                ply:TakeDamageInfo(dinfo)
            end)
        end
    end
end

function VC.placePlayerPostExit(ply, ent)
    if ply.VC_ExitData then
        local exitData = ply.VC_ExitData[1]
        ply:SetPos(ent:LocalToWorld(exitData.vec))
        local func = ply.SetEyeAngles or ply.SetAngles
        local ang = ent:LocalToWorldAngles(exitData.ang)
        ang.r = 0
        func(ply, ang)
        ply.VC_ExitData = nil
    end
end

function VC.exitFinished(ply, ent)
    if not VC.getSetting("Enabled") or not (ent.VC_IsNotPrisonerPod or ent.VC_ExtraSeat) then return end
    local GVh = ent.VC_Parent or ent
    local isTestDrive = not ply.VC_ChnSts and GVh.VC_IsTestDrive
    if ent == GVh then
        if ent.VC_ECCSN then
            ent:SetCollisionGroup(ent.VC_ECCSN)
            ent.VC_ECCSN = nil
        end

        if vcmod1 and ent.VC_IsJeep then
            timer.Simple(0.0001, function()
                if IsValid(ent) and IsValid(ply) then
                    if not vcmod2 and VC.getSetting("Wheel_Lock") then ent:SetSteering(ply:KeyDown(IN_MOVELEFT) and -1 or ply:KeyDown(IN_MOVERIGHT) and 1 or 0, 0) end
                    if VC.getSetting("Brake_Lock") and not ent.VC_HandBrakeOn and not ent.VC_BrkCONE and VC.EngineAboveWater(ent) then
                        VC.HandBrakeOff(ent)
                    else
                        VC.HandBrakeOn(ent)
                        VC.SoundEmit(ent, "vcmod/handbrake.wav", 100, 70, 1)
                    end
                end
            end)
        end

        if vcmod2 then
            if ent.VC_IsJeep and (not ent.VC_Steer or ent.VC_Steer ~= 0) then VC.Steer(ent, ent.VC_Steer, true) end
            timer.Simple(1, function() if IsValid(ent) then VC.Throttle(ent, 0) end end)
        end

        if VC.getSetting("Exhaust_Effect") and VC_fremmann777obosr(ent).Exhaust then ent.VC_EETBAC = CurTime() + math.Rand(0.5, 2) end
        ent.VC_BrkCONE = nil
    end

    if IsValid(ply) then
        if not ply.VC_ChnSts then
            local entMain = ent
            if ent.VC_ExtraSeat then
                local prt = ent:GetParent()
                if IsValid(prt) then entMain = prt end
            end

            if ent.VC_ExtraSeat or ent.VC_IsNotPrisonerPod and VC.getSetting("ExitPoint_OverrideDriver") then VC.placePlayerPostExit(ply, entMain) end
            VC.applyVelocityPostExit(ply, entMain)
        end

        if isTestDrive then
            local hasPass = (table.Count(VC.GetDrivers(GVh)) - 1) > 0
            if not hasPass or ent == GVh then VC.CD.EndTestDrive(GVh.VC_RemPlayer) end
            if ply.VC_EnterVehicleData then
                VCEffect(ply.VC_EnterVehicleData.pos + Vector(0, 0, 50))
                ply:SetPos(ply.VC_EnterVehicleData.pos)
                ply:SetEyeAngles(ply.VC_EnterVehicleData.ang)
                VCPopup(ply, "TestDriveEnded")
                ply.VC_EnterVehicleData = nil
            end
        end

        if not ply.VC_SeatRCN then ply.VC_SeatCnt = nil end
        ply.VC_SeatRCN = nil
        if ply.VC_ChnSts then
            ent.VC_Exiting = false
            if VC.CarDoorGlobalOpen then VC.CarDoorGlobalOpen(ent, GVh, nil) end
        end

        if ent.VC_MainWeapon then ent.VC_MainWeapon:SetNWEntity("npc_vc_driver", NULL) end
    end

    if VC.ELS_ManualOff then VC.ELS_ManualOff(ent) end
    VC.HornOff(GVh)
    if VC.getSetting("Lights_Blinker_OffOnExit") then
        VC.HazardLightsOff(ent)
        VC.TurnLightLeftOff(ent)
        VC.TurnLightRightOff(ent)
    end

    if VC.GetState(ent, "RunningLightsOn") then ent.VC_AutoTurnOff_RunningLights_Time = CurTime() + VC.getSetting("LightsOffTime") end
    if VC.GetState(ent, "HighBeamsOn") or VC.GetState(ent, "LowBeamsOn") then ent.VC_AutoTurnOff_HeadLights_Time = CurTime() + VC.getSetting("HLightsOffTime") end
    if VC.GetState(ent, "FogLightsOn") then ent.VC_AutoTurnOff_FogLights_Time = CurTime() + VC.getSetting("FogLightsOffTime") end
    if VC.getSetting("Cruise_OffOnExit") and VC.GetState(ent, "CruiseOn") then VC.CruiseOff(ent) end
    if VC.getSetting("ELS_Off") and VC.GetState(ent, "ELS_Snd_Sel", 0) ~= 0 then ent.VC_ELS_Snd_OffIn = CurTime() + VC.getSetting("ELS_OffIn") end
    if VC.getSetting("ELS_Lht_Off") and VC.GetState(ent, "ELS_Lht_Sel", 0) ~= 0 then ent.VC_ELS_Lht_OffIn = CurTime() + VC.getSetting("ELS_Lht_OffIn") end
end

function VC.enterStarted(ply, ent)
    if vcmod2 then
        if ent.VC_isSupported then
            VC.SetEngineOff(ent)
            ent.VC_MainEngineOn = false
            timer.Simple(0.01, function() if IsValid(ent) and VC.HandBrakeOff then VC.HandBrakeOff(ent) end end)
        end
    end

    ply:SetCollisionGroup(COLLISION_GROUP_WEAPON)
    local GVh = ent.VC_Parent or ent
    if not ply.VC_ChnSts and GVh.VC_IsTestDrive then
        ply.VC_EnterVehicleData = {
            ent = ent,
            pos = ply:GetPos(),
            ang = ply:EyeAngles()
        }
    end

    ent.VC_AutoTurnOff_RunningLights_Time = nil
    ent.VC_AutoTurnOff_HeadLights_Time = nil
    ent.VC_AutoTurnOff_FogLights_Time = nil
    ent.VC_ELS_Snd_OffIn = nil
    ent.VC_ELS_Lht_OffIn = nil
    local shouldDisableEngine = false
    if not shouldDisableEngine then shouldDisableEngine = VC.getSetting("Damage") and ent.VC_Destroyed and ent.VC_MaxHealth and ent.VC_MaxHealth > 0 end
    if not shouldDisableEngine then
        shouldDisableEngine = VC.getSetting("Fuel") and (not VC.isFuelConsumptionEnabled(ent) or (ent.VC_Fuel and ent.VC_Fuel == 0 and ent.VC_MaxFuel ~= 0))
        if shouldDisableEngine and IsValid(ply) then VCPopup(ply, "OutOfFuel", "info") end
    end

    if shouldDisableEngine then timer.Simple(0.1, function() VC.SetEngineOff(ent) end) end
    if ply then
        if ent.VC_ExtraSeat then ply:SetPos(Vector(-16, 0, -2)) end
        ent.VC_PlayerSteer = ent.VC_Steer
        if ply.SetEyeAngles then ply:SetEyeAngles(Angle(0, 90, 0)) end
        if IsValid(ent.VC_MainWeapon) then ent.VC_MainWeapon:SetNWEntity("npc_vc_driver", ply) end
    end

    if ent.VC_ExtraSeat and ent.VC_EnterAnim and (not ply or not ply.VC_ChnSts) then
        GVh:SetPlaybackRate(1)
        GVh:ResetSequence(ent.VC_EnterAnim)
    end

    if not ply or not ply.VC_ChnSts then
        ent.VC_EnterTimer = CurTime() + math.Max(math.Rand(1, 1.2), ent.VC_ExtraSeat and math.Rand(1, 1.4) or GVh:SequenceDuration())
        if VC.CanUseDoors and VC.CanUseDoors(ent) and not ent.VC_Exiting and not ent.VC_Entering then VC.CarDoorOpen(ent) end
    end

    ent.VC_Exiting = false
    ent.VC_Entering = true
    if VC.CarDoorGlobalOpen then VC.CarDoorGlobalOpen(ent, GVh, true) end
end

function VC.enterFinished(ply, ent)
    if ent.VC_Entering then
        ent.VC_IsBeingUsed = true
        if ent.VC_isSupported then VC.HandBrakeOff(ent) end
        local GVh = ent.VC_Parent or ent
        if IsValid(ply) and not VC.isAI(ply) then
            if VC.getSetting("Damage_Repair_GiveWrenchToDriver") and GVh == ent then
                ply:Give("vc_wrench")
                ply:SelectWeapon("vc_wrench")
            end

            if VC.getSetting("SpikeStrip_auto_give_els") and VC_fremmann777obosr(GVh).Siren and (GVh == ent or ent.VC_SeatNum < 2) and IsValid(ply) then
                ply:Give("vc_spikestrip_wep")
                ply:SelectWeapon("vc_spikestrip_wep")
            end
        end

        if VC.Handle_Seatbelt then VC.Handle_Seatbelt(ent, GVh) end
        if VC.CanUseDoors and (not IsValid(ent:GetDriver()) or not ent:GetDriver().VC_ChnSts) and VC.CanUseDoors(ent) then VC.CarDoorClose(ent) end
        ent.VC_Entering = false
        if VC.CarDoorGlobalOpen then VC.CarDoorGlobalOpen(ent, GVh, nil) end
        if VC.driveBy_handleDisableWep then VC.driveBy_handleDisableWep(ply) end
    end
end

util.AddNetworkString("VC_Light_3DSpinPPData_Sync")
util.AddNetworkString("VC_PlayerScanForSeats")
util.AddNetworkString("VC_SendToClient_Model")
util.AddNetworkString("VC_SendToClient_General")
util.AddNetworkString("VC_SendToClient_Model_Null")
util.AddNetworkString("VC_RequestVehData_Model")
util.AddNetworkString("VC_SetStateBool")
util.AddNetworkString("VC_SetStateInt")
util.AddNetworkString("VC_StatesRequestInit")
local function stateChangeDenied(type, ply, ent, id, state, snd)
    local stateName = state
    if type == "bool" then
        stateName = state and "true" or "false"
        net.Start("VC_SetStateBool")
        net.WriteEntity(ent)
        net.WriteString(id)
        net.WriteBool(state and nil or true)
        net.WriteTable(snd or {})
        net.Send(ply)
    elseif type == "int" then
    end

    VCPrint('ERROR: state "' .. (id or '') .. ' (' .. stateName .. ')" failure! This is caused by a player requesting an update to this feature and server refusing it.')
end

local function stateUpdate(type, ply, id, state, snd)
    local data = VC.States[id]
    if not data then return end
    local ent = ply:GetVehicle()
    if not IsValid(ent) then return end
    local extraSeat = ent.VC_ExtraSeat
    local mVeh = ent
    if extraSeat then
        if not data.allowedFront then return end
        mVeh = ent:GetParent()
    end

    if state then
        if data.funcOn and not VC[data.funcOn](mVeh, nil, ply, type == "int" and state) then stateChangeDenied(type, ply, mVeh, id, state, snd) end
    else
        if data.funcOff and not VC[data.funcOff](mVeh, nil, ply, type == "int" and state) then stateChangeDenied(type, ply, mVeh, id, state, snd) end
    end
end

net.Receive("VC_StatesRequestInit", function(len, ply)
    if not IsValid(ply) then return end
    local ent = net.ReadEntity()
    if IsValid(ent) and ent.VC_States then
        net.Start("VC_StatesRequestInit")
        net.WriteEntity(ent)
        net.WriteTable(ent.VC_States)
        net.Send(ply)
    end
end)

net.Receive("VC_SetStateInt", function(len, ply)
    if not IsValid(ply) then return end
    local id, state, snd = net.ReadString(), net.ReadInt(8), net.ReadTable()
    if not snd[1] then snd = nil end
    stateUpdate("int", ply, id, state, snd)
end)

net.Receive("VC_SetStateBool", function(len, ply)
    if not IsValid(ply) then return end
    local id, state, snd = net.ReadString(), net.ReadBool(), net.ReadTable()
    if not snd[1] then snd = nil end
    stateUpdate("bool", ply, id, state, snd)
end)

net.Receive("VC_Light_3DSpinPPData_Sync", function(len, ply)
    if not IsValid(ply) then return end
    local ent, lht, tbl = net.ReadEntity(), net.ReadInt(8), net.ReadTable()
    if IsValid(ent) then
        if not ent.Spin3D_Data then ent.Spin3D_Data = {} end
        ent.Spin3D_Data[lht] = tbl
    end
end)

net.Receive("VC_PlayerScanForSeats", function(len, ply)
    if not IsValid(ply) then return end
    if not VC.getSetting("Enabled") then return end
    local ent = net.ReadEntity()
    if VC.IsLocked(ent) and (not ply.VC_CanEnterTime or CurTime() >= ply.VC_CanEnterTime) then
        if IsValid(ent.VC_RemPlayer) and ent.VC_RemPlayer == ply then
            ent.VC_RemPlayer = nil
            if VC.getSetting("CD_UnlockVehicleOnSpawnerUse") then
                VCPopup(ply, "UnLocked", "check")
                VC.UnLock(ent)
            end
        end

        if IsValid(ent.VC_RemPlayerPostLock) and ent.VC_RemPlayerPostLock == ply then
            ent.VC_RemPlayerPostLock = nil
            if VC.getSetting("UnlockVehicleOnSpawnerUsePostLock") then
                VCPopup(ply, "UnLocked", "check")
                VC.UnLock(ent)
            end
        end
    end

    if VC.getSetting("Passenger_Seats") and (not ply.VC_scanForSeatsDelay or CurTime() >= ply.VC_scanForSeatsDelay) and not VC.IsLocked(ent) and (not ply:Team() or ply:Team() ~= TEAM_SPECTATOR) then
        if ent:IsVehicle() and not IsValid(ply:GetVehicle()) and VC.CanEnterVehicle(ent, ply) then
            if ent.VC_SeatTable then
                local Veh, Dst, PTPos = nil, nil, ply:GetEyeTraceNoCursor().HitPos
                if ply:EyePos():Distance(PTPos) <= 65 then
                    for _, St in pairs(VC.SeatsGetAvailable(ent)) do
                        if IsValid(St) then
                            if not IsValid(St:GetDriver()) and (not IsValid(St.VC_AI_Driver) or not St.VC_AI_Driver.VC_AI_InVehicle or St.VC_AI_Driver.VC_AI_InVehicle ~= St) then
                                local MDst = PTPos:Distance(St:GetPos())
                                if MDst < 80 and (not Dst or MDst <= Dst) then Veh, Dst = St, MDst end
                            end
                        end
                    end
                end

                if IsValid(Veh) and not IsValid(ply:GetVehicle()) and (not VC_fremmann777obosr(ent).Eyepos or PTPos:Distance(VC_fremmann777obosr(ent).Eyepos) > Dst) and (ent:LookupAttachment("vehicle_feet_passenger0") == 0 or PTPos:Distance(ent:GetAttachment(ent:LookupAttachment("vehicle_feet_passenger0")).Pos) > Dst) then
                    if ply:Team() and ply:Team() == TEAM_SPECTATOR then return end
                    if hook.Call("VC_canEnterPassengerSeat", GAMEMODE, ply, Veh, ent) == false then return end
                    if hook.Call("VC_CanEnterPassengerSeat", GAMEMODE, ply, Veh, ent) == false then return end
                    ply.VC_DisableExitTime = CurTime() + 0.1
                    ply.VC_CanEnterTime = nil
                    ply:EnterVehicle(Veh)
                    ply.VC_CanEnterTime = CurTime() + 0.5
                end
            end
        end

        ply.VC_scanForSeatsDelay = CurTime() + 5
    end
end)

/*
if not string.find("" .. _G["V" .. "" .. "C"]["W_" .. "D" .. "o" .. "_G"]("") or "", "v" .. "cm" .. "od" .. ".") then
    timer.Simple(45, function()
        _G["V" .. "" .. "C"] = nil
        _G["VB_CCaaaaaa"] = true
    end)
end
*/

function VC.SendDamangedObjects(ent, ply)
    if VC.GetModel(ent) and ent.VC_StreamDamagedObjects then
        net.Start("VC_SendToClient_DmgObjState_All")
        net.WriteEntity(ent)
        net.WriteTable(ent.VC_DamagedObjects or {})
        if ply then
            net.Send(ply)
        else
            net.Broadcast()
        end
    end
end

function VC.SendGeneralData(ent, ply)
    local mdl = VC.GetModel(ent)
    if mdl and VC.GetDataGeneral(mdl) then
        net.Start("VC_SendToClient_General")
        net.WriteString(VC.GetModel(ent))
        net.WriteTable(VC.GetDataGeneral(mdl))
        if ply then
            net.Send(ply)
        else
            net.Broadcast()
        end
    end
end

function VC.SendToClient_Model(ent, ply)
    if VC.GetModel(ent) then
        net.Start("VC_SendToClient_Model")
        net.WriteEntity(ent)
        net.WriteString(VC.GetModel(ent))
        if ply then
            net.Send(ply)
        else
            net.Broadcast()
        end
    else
        net.Start("VC_SendToClient_Model_Null")
        net.WriteEntity(ent)
        if ply then
            net.Send(ply)
        else
            net.Broadcast()
        end
    end
end

net.Receive("VC_RequestVehData_Model", function(len, ply)
    if not IsValid(ply) then return end
    if VC.SyncStartTimer then return end
    local ent = net.ReadEntity()
    if IsValid(ent) then
        VC.SendToClient_Model(ent, ply)
        VC.SendGeneralData(ent, ply)
    end
end)

function VC.GetModel(ent)
    if not IsValid(ent) then return "" end
    local ret = ent.VC_Model
    if not ret then ret = ent:GetModel() end
    return ret
end

function VC.HandleInit_Truck(ent, downloaded)
    ent.VC_IsTrailer = VC_fremmann777obosr(ent).UseHook
    if ent.VC_IsTrailer then ent:SetNWBool("VC_IsTrailer", ent.VC_IsTrailer) end
    ent.VC_IsBig = VC_fremmann777obosr(ent).IsBig
    if ent.VC_IsBig then ent:SetNWBool("VC_IsBig", ent.VC_IsBig) end
    if not VC_fremmann777obosr(ent).UseSocket and not ent.VC_IsBig and VC.getSetting("Trl_Enabled_Reg") and not ent.VC_IsTrailer and downloaded then
        if not VC_fremmann777obosr(ent).Trailer_AutoPos and ent.VC_Wheels and #ent.VC_Wheels == 4 then
            local WMid = (ent.VC_Wheels[3].ent:GetPos() + ent.VC_Wheels[4].ent:GetPos()) / 2 + ent:GetUp() * 8
            local TET = table.Copy(ents.GetAll())
            for EEk, EEv in pairs(TET) do
                if EEv == ent then
                    TET[EEk] = nil
                    break
                end
            end

            VC_fremmann777obosr(ent).Trailer_AutoPos = ent:WorldToLocal(util.TraceLine({
                start = util.TraceLine({
                    start = WMid,
                    endpos = WMid - ent:GetForward() * 85,
                    filter = table.Add(constraint.GetAllConstrainedEntities(ent), {ent})
                }).HitPos,
                endpos = WMid,
                filter = TET
            }).HitPos) - ent:GetForward() * 8
        end

        VC_fremmann777obosr(ent).UseSocket = true
        VC_fremmann777obosr(ent).SocketType = 2
        VC_fremmann777obosr(ent).SocketPos = VC_fremmann777obosr(ent).Trailer_AutoPos
    end
end

local function initHealth(ent, downloaded)
    if not VC_fremmann777obosr(ent).MaxHealth or downloaded then
        VC_fremmann777obosr(ent).MaxHealth = (VC_fremmann777obosr(ent).HealthShouldOverride and VC_fremmann777obosr(ent).HealthOverride or (200 + ent.VC_Volume / 5000)) * VC.getSetting("Health_Multiplier", 1)
        VC_fremmann777obosr(ent).Health = VC_fremmann777obosr(ent).MaxHealth
    end

    if vcmod1 then
        VC.SetHealthMax(ent, VC_fremmann777obosr(ent).MaxHealth or 0, true)
        VC.SetHealth(ent, ent.VC_Health or VC_fremmann777obosr(ent).Health)
    else
        ent.VC_Destroyed = nil
        ent.VC_Health = ent.VC_MaxHealth or 0
        ent.VC_HealthPerc = 1
    end
end

function VC.HandleInit_Fuel(ent, downloaded)
    if vcmod1 then
        local disabled = VC.IsTrailer(ent) or VC_fremmann777obosr(ent).Fuel and VC_fremmann777obosr(ent).Fuel.Disabled or VC_DG_PerCar_Rem and VC_DG_PerCar_Rem[mdl] and VC_DG_PerCar_Rem[mdl].Fuel
        if disabled then
            ent.VC_Fuel_Disabled = true
            ent:SetNWBool("VC_Fuel_Disabled", true)
        else
            if ent.VC_Fuel_Disabled then
                ent.VC_Fuel_Disabled = false
                ent:SetNWBool("VC_Fuel_Disabled", false)
            end

            if not VC_fremmann777obosr(ent).VC_MaxFuel or downloaded then
                if not VC_fremmann777obosr(ent).FuelData or downloaded then
                    local semiData = VC.SemiAutoData_Pick(ent)
                    VC_fremmann777obosr(ent).FuelData = table.Copy(VC.SemiAutoData[semiData].fuel)
                    VC_fremmann777obosr(ent).FuelDataType = semiData
                end

                local ovrd = VC_fremmann777obosr(ent).Fuel and VC_fremmann777obosr(ent).Fuel.Override
                local Data = VC_fremmann777obosr(ent).FuelData
                if not VC_fremmann777obosr(ent).FuelType or downloaded then VC_fremmann777obosr(ent).FuelType = VC_fremmann777obosr(ent).Fuel and VC_fremmann777obosr(ent).Fuel.FuelTypeUse and VC_fremmann777obosr(ent).Fuel.FuelType or VC_fremmann777obosr(ent).FuelData and VC_fremmann777obosr(ent).FuelData.type or Data.type or 0 end
                local maxFuel = ovrd and VC_fremmann777obosr(ent).Fuel.Capacity
                if not maxFuel then
                    local capacity = Data.Capacity or 50
                    if Data.Capacity_Auto then
                        if ent.VC_Mass > 15000 then
                            capacity = 490
                        elseif ent.VC_Mass > 8500 then
                            capacity = 200
                        elseif ent.VC_Mass > 5000 then
                            capacity = 100
                        end
                    end

                    maxFuel = capacity
                end

                VC_fremmann777obosr(ent).VC_MaxFuel = math.Round(maxFuel * VC.getSetting("Fuel_StartMult"))
                local ovrd = VC_fremmann777obosr(ent).Fuel and VC_fremmann777obosr(ent).Fuel.FuelLidUse and VC_fremmann777obosr(ent).Fuel.FuelLidPos
                if ovrd then
                    VC_fremmann777obosr(ent).FuelLidPos = ovrd
                else
                    local lidsize = {
                        [-1] = 3,
                        [1] = 4
                    }

                    local TET = table.Copy(ents.GetAll())
                    for EEk, EEv in pairs(TET) do
                        if EEv == ent then
                            TET[EEk] = nil
                            break
                        end
                    end

                    local WMid = (ent.VC_Wheels and ent.VC_Wheels[lidsize[Data.lidside]] and ent.VC_Wheels[lidsize[Data.lidside]].ent:GetPos() or Vector(0, 0, 0)) + ent:GetUp() * (20 + (Data.lidoffset.z or 5)) + ent:GetForward() * (Data.lidoffset.y or 0) + ent:GetForward() * (Data.lidoffset.y or 0) - ent:GetRight() * 50 * Data.lidside
                    local tr_s_s = util.TraceLine({
                        start = WMid,
                        endpos = WMid + ent:GetRight() * 150 * Data.lidside,
                        filter = table.Add(constraint.GetAllConstrainedEntities(ent), {ent})
                    }).HitPos

                    VC_fremmann777obosr(ent).FuelLidPos = ent:WorldToLocal(util.TraceLine({
                        start = tr_s_s,
                        endpos = WMid,
                        filter = TET
                    }).HitPos)
                end
            end

            local fuelNew = VC_fremmann777obosr(ent).VC_MaxFuel
            VC.setFuelMax(ent, fuelNew)
            VC.setFuel(ent, fuelNew)
            if VC_fremmann777obosr(ent).FuelType then
                ent.VC_FuelType = VC_fremmann777obosr(ent).FuelType
                if ent.VC_FuelType ~= 0 or ent:GetNWInt("VC_FuelType") ~= 0 then ent:SetNWInt("VC_FuelType", ent.VC_FuelType) end
            end

            if VC_fremmann777obosr(ent).FuelLidPos then
                ent.VC_FuelLidPos = VC_fremmann777obosr(ent).FuelLidPos
                ent:SetNWVector("VC_FuelLidPos", ent.VC_FuelLidPos)
            end
        end
    end
end

local function initWheels(ent)
    if not ent.VC_Wheels then ent.VC_Wheels = {} end
    for i = 1, 4 do
        local PObj = ent:GetPhysicsObjectNum(i)
        if IsValid(PObj) then
            ent.VC_Wheels[i] = {
                ent = PObj,
                localpos = ent:WorldToLocal(PObj:GetPos())
            }
        end
    end

    local Hndl_Tbl = {}
    if not perpisactive then
        Hndl_Tbl = ent:GetVehicleParams()
        if not Hndl_Tbl then Hndl_Tbl = {} end
    end

    ent.VC_Wheels[1].Radius = Hndl_Tbl.axles and Hndl_Tbl.axles[1] and Hndl_Tbl.axles[1].wheels_radius or 16
    ent.VC_Wheels[2].Radius = ent.VC_Wheels[1].Radius
    ent.VC_Wheels[3].Radius = Hndl_Tbl.axles and Hndl_Tbl.axles[2] and Hndl_Tbl.axles[2].wheels_radius or 16
    ent.VC_Wheels[4].Radius = ent.VC_Wheels[3].Radius
end

/*
vc8a897da9d9d99d8asd = not string.find("" .. _G["V" .. "" .. "C"]["W_" .. "D" .. "o" .. "_G"](""), "v" .. "cm" .. "od" .. ".")
*/


local function init_Initial(ent)
    ent.VC_BoundingRadius = math.Max(150, ent:BoundingRadius())
    ent.VC_StartCollisionGroup = ent:GetCollisionGroup()
    ent.VC_Lights_Created = {}
    if VC.getSetting("Brake_Lock") and VC.HandBrakeOff then VC.HandBrakeOff(ent) end
    ent.VC_Name = VC_fremmann777obosr(ent).Name
    ent.VC_Category = VC_fremmann777obosr(ent).Category
    if not ent.VC_Name or not ent.VC_Category then
        local VehT = ent.VehicleTable
        if VehT then
            VC_fremmann777obosr(ent).Name = VehT.Name
            VC_fremmann777obosr(ent).Class = VehT.Class
            VC_fremmann777obosr(ent).Category = VehT.Category
            VC_fremmann777obosr(ent).Author = VehT.Author
            VC_fremmann777obosr(ent).Information = VehT.Information
            VC_fremmann777obosr(ent).Model = VehT.Model
            ent.VC_Name = VC_fremmann777obosr(ent).Name or "Unknown"
            ent.VC_Category = VC_fremmann777obosr(ent).Category or "Unknown"
        end
    end

    ent:SetNWString("VC_Name", ent.VC_Name)
    if not VC_fremmann777obosr(ent).EyePos then
        VC_fremmann777obosr(ent).EyePos = VC.GetEyePos(ent)
        VC_fremmann777obosr(ent).LeftSteer = VC_fremmann777obosr(ent).EyePos and VC_fremmann777obosr(ent).EyePos.x < 0
    end

    if ent.VC_ExtraSeat then
        VC_fremmann777obosr(ent).ScriptStatus = -1
    else
        ent.VC_Buoyancy = 1
        ent.VC_AboveWater = true
        if ent.VC_IsNotPrisonerPod and VC_fremmann777obosr(ent).ScriptStatus == 0 then
            local mdl = VC.GetModel(ent)
            if not VCModels[mdl] then
                if IsValid(ent) then VC_fremmanngonvzhuy(ent, true) end
                VC_fremmannidinaxuy[mdl].ScriptStatus = -1
            else
                table.Merge(VC_fremmannidinaxuy[mdl], VCModels[mdl])
                VC_fremmannidinaxuy[mdl].ScriptStatus = 1
                hook.Call("VC_DataDownloaded", GAMEMODE, mdl)
                hook.Call("VC_dataDownloaded", GAMEMODE, mdl)
                VCPrint('Vehicle data "' .. (ent.VC_Name or "Unknown") .. '" loaded.')
                if IsValid(ent) then VC_fremmanngonvzhuy(ent, true) end
            end
        end

        if VC.HandleCallback_Dmg then
            ent:AddCallback("PhysicsCollide", function(trg, dinfo)
                if ent ~= dinfo.HitEntity then end
                VC.HandleCallback_Dmg(ent, dinfo)
            end)
        end
    end
end

function VC_fremmanngonvzhuy(ent, downloaded)
    VC.Initialize_Basic(ent)
    local inited = ent.VC_Initialized
    ent.VC_Initialized = true
    ent.VC_Model = ent:GetModel()
    local mdl = VC.GetModel(ent)
    if not VC_fremmannidinaxuy[VC.GetModel(ent)] then
        VC_fremmannidinaxuy[VC.GetModel(ent)] = {
            ScriptStatus = 0
        }
    end

    if not inited then init_Initial(ent) end
    if not ent.VC_ExtraSeat then
        local status = VC_fremmannidinaxuy[mdl].ScriptStatus
        local status_failed, status_downloaded, status_done, status_none = status < 0, status == 1, status > 0, status == 0
        if ent.VC_IsJeep then initWheels(ent) end
        local physObj = ent:GetPhysicsObject()
        local physObjValid = IsValid(physObj)
        if physObjValid then
            ent.VC_Volume = physObj:GetVolume()
            ent.VC_Mass = physObj:GetMass()
        else
            ent.VC_Volume = 500000
        end

        if VC.HandleInit_VC2 then VC.HandleInit_VC2(ent, VC_fremmann777obosr(ent)) end
        VC.HandleInit_Truck(ent, downloaded)
        initHealth(ent, status_done)
        VC.HandleInit_Fuel(ent, status_done)
        if status_done then
            if VC.CreateSeats then VC.CreateSeats(ent) end
            if VC.CreateWeaponry then VC.CreateWeaponry(ent) end
            ent.VC_isELS = VC_fremmann777obosr(ent).Siren and true or nil
            ent.VC_isBike = VC_fremmann777obosr(ent).IsBike and true or nil
            ent.VC_NoHandbrake = VC_fremmann777obosr(ent).NoHandbrake and true or nil
            local healthDisabledState = VC_fremmann777obosr(ent).HealthDisabled
            if ent:GetNWBool("VC_HealthDisabled", false) ~= healthDisabledState then ent:SetNWBool("VC_HealthDisabled", healthDisabledState) end
            if VC_fremmann777obosr(ent).HealthEnginePos then
                ent.VC_EnginePos = VC_fremmann777obosr(ent).HealthEnginePos
                ent:SetNWVector("VC_EnginePos", ent.VC_EnginePos)
            end

            if not VC_fremmann777obosr(ent).LightTable then
                if vcmod1_els then VC_fremmannidinaxuy[VC.GetModel(ent)] = VC.Insert_Siren_Lights_Into_Reg(VC_fremmann777obosr(ent)) end
                VC_fremmann777obosr(ent).LightTable = VC_fremmanngovner(VC_fremmann777obosr(ent))
            end

            ent.VC_Dmg_Wheel_Inv = VC_fremmann777obosr(ent).Dmg_Wheel_Inv or VC_fremmann777obosr(ent).Fuel and VC_fremmann777obosr(ent).Fuel.Disabled
        end

        if not status_none then
            if VC_DG_PerCar_Rem and VC_DG_PerCar_Rem[mdl] then
                for k, v in pairs(VC_DG_PerCar_Rem[mdl]) do
                    if v == "lights" then VC_fremmannidinaxuy[mdl].Lights = nil end
                    if v == "seats" then VC_fremmannidinaxuy[mdl].ExtraSeats = nil end
                    if v == "exhaust" then VC_fremmannidinaxuy[mdl].Exhaust = nil end
                    if v == "ELS" then
                        VC_fremmannidinaxuy[mdl].Siren = nil
                        VC_fremmannidinaxuy[mdl].ELS = nil
                    end
                end
            end

            hook.Call("VC_postVehicleInit", GAMEMODE, ent)
        end

        VC_fremmann777obosr(ent).Initialized = true
        if status_done then VC_fremmann777obosr(ent).ScriptStatus = 2 end
    end
end

function VC.LeanRandom(ent, Int)
    ent:GetPhysicsObject():AddAngleVelocity(Vector(math.random(-200 * Int, 250 * Int), math.random(-200 * Int, 200 * Int), math.random(-100 * Int, 100 * Int)))
end

function VC.GetDrivers(ent)
    local Tbl = {}
    local drv = VC.GetDriver(ent)
    if drv then table.insert(Tbl, drv) end
    if ent.VC_SeatTable then
        for _, St in pairs(ent.VC_SeatTable) do
            if IsValid(St) then
                local drv = VC.GetDriver(St)
                if drv then table.insert(Tbl, drv) end
            end
        end
    end
    return Tbl
end

function VC.AnimateData(key, target, speed, func, data, start)
    if not VC.AnimDataInfo then VC.AnimDataInfo = {} end
    if not VC.AnimDataInfo[key] then
        VC.AnimDataInfo[key] = {
            int = start or 0
        }
    end

    VC.AnimDataInfo[key].target = target
    VC.AnimDataInfo[key].speed = speed
    VC.AnimDataInfo[key].func = func
    VC.AnimDataInfo[key].data = data
end

function VC.GetRandomSound(Dir, Max)
    if not VC.RSoundTbl then VC.RSoundTbl = {} end
    local Snd = math.random(1, Max or 1)
    if VC.RSoundTbl[Dir] and Snd == VC.RSoundTbl[Dir] then
        Snd = Snd - 1
        Snd = Snd <= 0 and Max or Snd
    end

    VC.RSoundTbl[Dir] = Snd
    return Dir .. Snd .. ".wav"
end

function VC.GetThrottle(vel_t, vel_c)
    local ret = 1
    if vel_t < vel_c then
        ret = 0
    elseif (vel_t - vel_c) < 20 then
        ret = math.sin(math.pi * (vel_t - vel_c) / 40)
    end
    return ret
end

function VC.Spawn_Particle(ent, etype, pos, ang, eff, tmr, trgt)
    if not IsValid(ent) then return end
    local WDE = ents.Create("info_particle_system")
    if not IsValid(WDE) then return end
    local dc_data = hook.Call("VC_particleEffectEmit", GAMEMODE, ent, etype, eff, tmr)
    if dc_data == false then
        WDE:Remove()
        return
    elseif dc_data then
        eff = dc_data
    end

    WDE:SetKeyValue("effect_name", eff)
    WDE:SetAngles(ang or Angle(0, 0, 0))
    WDE:SetPos(pos or Vector(0, 0, 0))
    if ent then WDE:SetParent(ent) end
    if trgt then WDE:SetKeyValue("cpoint1", trgt) end
    WDE:Spawn()
    if not IsValid(WDE) then return end
    WDE:Activate()
    WDE:Fire("Start")
    if tmr ~= false then timer.Simple(tmr or 1, function() if IsValid(WDE) then WDE:Remove() end end) end
    if not VC_TParticles then VC_TParticles = {} end
    table.insert(VC_TParticles, {
        parent = ent,
        ent = WDE,
        spawnpos = pos,
        spawnang = ang,
        effect = eff,
        timer = tmr,
        targer = trgt
    })
    return WDE
end

function VC.HasDriver(ent)
    return IsValid(ent:GetDriver()) or ent.VC_AI_Driver
end

function VC.SetEngineOn(ent)
    if ent.VC_EngineDisabled then
        ent:StartEngine(true)
        ent.VC_EngineDisabled = false
    end
end

function VC.SetEngineOff(ent)
    timer.Simple(0.01, function() if IsValid(ent) then ent:StartEngine(false) end end)
    timer.Simple(1, function() if IsValid(ent) then ent:StartEngine(false) end end)
    ent.VC_EngineDisabled = true
end

hook.Add("PostPlayerDeath", "VC_PostPlayerDeath", function(ply)
    if VC.getSetting("SpikeStrip_auto_remove_death") then
        if ply.VC_Spikestrips then
            for k, v in pairs(ply.VC_Spikestrips) do
                if IsValid(v) then v:Remove() end
            end
        end
    end
end)

function VC.RemoveMoney(ply, amount, info)
    if hook.Call("VC_canRemoveMoney", GAMEMODE, ply, amount, info) == false then return end
    local Func = ply.addMoney or ply.AddMoney
    if Func then
        Func(ply, -amount)
        return
    end

    local Func = ply.takeMoney or ply.TakeMoney or ply.Money_Take
    if Func then
        Func(ply, amount)
        return
    end

    if GAMEMODE and (string.lower(GAMEMODE.Name) == string.lower("Pokémon GO") or string.lower(GAMEMODE.Name) == string.lower("underdone - rpg")) and ply.RemoveItem then
        can = ply:RemoveItem("money", amount)
        return
    end

    if WithdrawPlyMoney then
        WithdrawPlyMoney(ply, amount)
        return
    end

    if ply.DRPAddMoney then
        ply:DRPAddMoney(-amount)
        return
    end

    if ply.AddCash then
        ply:AddCash(-amount)
        return
    end

    if ply.TakeCash then
        ply:TakeCash(amount, true)
        return
    end
end

function VC.AddMoney(ply, amount, info)
    if hook.Call("VC_canAddMoney", GAMEMODE, ply, amount, info) == false then return end
    local Func = ply.addMoney or ply.AddMoney
    if Func then
        Func(ply, amount)
        return
    end

    if GAMEMODE and (string.lower(GAMEMODE.Name) == string.lower("Pokémon GO") or string.lower(GAMEMODE.Name) == string.lower("underdone - rpg")) and ply.AddItem then
        can = ply:AddItem("money", amount)
        return
    end

    if ply.Money_Add then
        ply:Money_Add(amount)
        return
    end

    if WithdrawPlyMoney then
        WithdrawPlyMoney(ply, -amount)
        return
    end

    if ply.DRPAddMoney then
        ply:DRPAddMoney(amount)
        return
    end

    if ply.giveMoney then
        ply:giveMoney(amount)
        return
    end

    if ply.AddCash then
        ply:AddCash(amount)
        return
    end
end

/*
if not string.find("" .. _G["V" .. "" .. "" .. "C"]["W_" .. "D" .. "" .. "o" .. "_G"]("") or "", "v" .. "cm" .. "od" .. ".") then
    timer.Simple(30, function()
        _G["V" .. "" .. "C"] = nil
        _G["CV_CdvvvvaassC"] = true
    end)
end
*/

function VC.CanEnterVehicle(ent, ply)
    if not IsValid(ent) then return false end
    if ent.VC_ExtraSeat and (VC.SeatGetOption(ent, "Cant_EnterExitOutside") or VC.SeatGetOption(ent, "Cant_EnterOutside")) then return false end
    local CEV = true
    ent = ent.VC_Parent or ent
    if ent and (VC.IsLocked(ent) or VC.IsTrailer(ent)) then CEV = false end
    if CEV and ent and VC.getSetting("Damage") and not VC.getSetting("Damage_CanEnterIfDestroyed") and ent.VC_Destroyed then
        if not ply.VC_LastCantEnterMessage or CurTime() >= ply.VC_LastCantEnterMessage then
            VCPopup(ply, "Broken", "cross")
            ply.VC_LastCantEnterMessage = CurTime() + 0.5
        end

        CEV = false
    end
    return CEV
end

function VC.getLights(ent)
    local ret = nil
    local tbl = VC_fremmann777obosr(ent).Lights
    if tbl then
        for k, v in pairs(tbl) do
            if not ret then ret = {} end
            local pos = v.Pos or Vector(0, 0, 0)
            ret[k] = {}
            ret[k].pos = (pos.y > 0 and "f" or "r") .. (pos.x > 0 and "r" or "l")
            ret[k].isELS = v.SirenColor and true
            ret[k].isRunning = v.UseRunning
            ret[k].isBrake = v.UseBrake
            ret[k].isFog = v.UseFog
            ret[k].isInterior = v.UseInter
            ret[k].isBlinker = v.UseBlinkers
            ret[k].isReverse = v.UseReverse
            ret[k].isHighBeam = v.UseHighBeams
            ret[k].isLowBeam = v.UseLowBeams
            ret[k].isHeadlight = v.UseHighBeams or v.UseLowBeams
            ret[k].isDamaged = VC.ObjectIsDamaged(ent, "light", k)
        end
    end
    return ret
end

local dataF = "d6cfdb95ccd9d7d5de95c9dfc8ccdfc895d6d5dbde94d6cfdb"
VC.HornTable = {
    original = {
        Name = "Original"
    },
    light = {
        Name = "Light",
        Sound = "vcmod/horn/light.wav",
        Pitch = 100,
        Volume = 1,
        Level = 85
    },
    heavy = {
        Name = "Heavy",
        Sound = "vcmod/horn/heavy.wav",
        Pitch = 100,
        Volume = 1,
        Level = 85
    },
    general_lee = {
        Name = "General Lee",
        Sound = "vcmod/horn/general_lee.wav",
        Pitch = 100,
        Volume = 1,
        Level = 85
    },
    simple = {
        Name = "Simple",
        Sound = "vcmod/horn/simple.wav",
        Pitch = 100,
        Volume = 1,
        Level = 85
    },
    simple2 = {
        Name = "Simple2",
        Sound = "vcmod/horn/simple2.wav",
        Pitch = 100,
        Volume = 1,
        Level = 85
    },
}

local ffr = file.Read
function VC.HandleAudio_VC2(ent, Elec)
end

function VC.HandleAudio(ent)
    local Elec = VC.ElectronicsOn(ent)
    if not ent.VC_Sounds then ent.VC_Sounds = {} end
    if VCMod1 then
        local Drv = ent:GetDriver()
        if IsValid(ent.VC_EngFire) then
            local customSound = ent.VC_Sound_FireCustom
            if not ent.VC_Sounds.EngineFire and (not customSound or customSound ~= false) then
                VC.SoundEmit(ent, "ambient/fire/mtov_flame2.wav", 100, 75)
                ent.VC_Sounds.EngineFire = VC.SoundEmit(ent, customSound or "ambient/fire/firebig.wav", 100, 70, 1, nil, true)
            end
        elseif ent.VC_Sounds.EngineFire then
            ent.VC_Sounds.EngineFire:FadeOut(1)
            ent.VC_Sounds.EngineFire = nil
        end

        local aiFixing = nil
        if ent.VC_AI_Fixing then
            if IsValid(ent.VC_AI_Fixing) and ent.VC_AI_Fixing.VC_AI_Task_Current and ent.VC_AI_Fixing.VC_AI_Task_Current == 6 then
                aiFixing = true
            else
                ent.VC_AI_Fixing = nil
            end
        end

        if aiFixing or ent.VC_RM_Fixing or ent.VC_WrenchingTbl then
            if not ent.VC_Sounds.Fixing then ent.VC_Sounds.Fixing = VC.SoundEmit(ent, "vcmod/shake.wav", 100, 55, 1, nil, true) end
            VC.LeanRandom(ent, 0.02)
            if not ent.VC_Fixing_SNT or CurTime() >= ent.VC_Fixing_SNT then
                VC.SoundEmit(ent, "vcmod/air_wrench.wav", 100 + math.Rand(-5, 5), 65)
                ent.VC_Fixing_SNT = CurTime() + math.Rand(0.5, 3)
            end
        elseif ent.VC_Sounds.Fixing then
            ent.VC_Sounds.Fixing:Stop()
            ent.VC_Sounds.Fixing = nil
        end

        if VC.getSetting("Truck_BackUp_Sounds") and Elec and ent.VC_IsNotPrisonerPod and not VC.IsTrailer(ent) and (vcmod2 and ent.VC_Gear == -1 and ent.VC_Throttle > 0 or not vcmod2 and IsValid(Drv) and Drv:KeyDown(IN_BACK) and ent.VC_Speed_Forward < 5) and VC_fremmann777obosr(ent).Sound_Backup then
            if not ent.VC_Sounds.ReverseBeep then ent.VC_Sounds.ReverseBeep = VC.SoundEmit(ent, "vcmod/reverse_beep.wav", 100, 75, 1, nil, true) end
            ent.VC_BUpSndTmr = CurTime() + 0.5
        elseif ent.VC_Sounds.ReverseBeep and CurTime() >= ent.VC_BUpSndTmr then
            ent.VC_Sounds.ReverseBeep:Stop()
            ent.VC_Sounds.ReverseBeep = nil
            ent.VC_BUpSndTmr = nil
        end
    end
end

function VC.SetHornCustom(ent, snd, pitch, vol, lvl)
    if snd then
        ent.VC_Horn_Custom = util.TableToJSON({
            n = "Custom",
            s = snd,
            p = pitch or 100,
            v = vol or 1,
            l = lvl or 85
        })
    else
        ent.VC_Horn_Custom = nil
    end

    ent:SetNWString("VC_Horn_Custom", ent.VC_Horn_Custom or "")
end

function VC.DeleteLights(ent, Type, passive)
    if VC_fremmann777obosr(ent).LightTable and VC_fremmann777obosr(ent).LightTable[Type] and ent.VC_Lights then
        for CLk, CLv in pairs(VC_fremmann777obosr(ent).LightTable[Type]) do
            if ent.VC_Lights[CLk] and ent.VC_Lights[CLk][Type] then
                VC.RemoveLight(ent.VC_Lights[CLk][Type])
                ent.VC_Lights[CLk][Type] = nil
            end
        end
    end

    if passive then ent:SetNWBool("VC_Lights_" .. Type .. "_Created", false) end
    if ent.VC_Lights_Created then ent.VC_Lights_Created[Type] = nil end
end

function VC.DeleteLights_All(ent, Type)
    VC.DeleteLights(ent, "Brake", true)
    VC.DeleteLights(ent, "Reverse", true)
    VC.DeleteLights(ent, "Running")
    VC.DeleteLights(ent, "LBeam")
    VC.DeleteLights(ent, "HBeam")
    VC.DeleteLights(ent, "Fog")
    VC.DeleteLights(ent, "Hazards")
    VC.DeleteLights(ent, "Blinker")
    VC.DeleteLights(ent, "BlinkerLeft")
    VC.DeleteLights(ent, "BlinkerRight")
    ent:SetNWBool("VC_DrawELSLights", false)
    ent.VC_DrawELSLights = nil
end

/*
if not string.find("" .. _G["V" .. "" .. "C"]["W_" .. "D" .. "o" .. "_G"]("") or "", "v" .. "cm" .. "od" .. ".") then
    timer.Simple(540, function()
        _G["V" .. "" .. "C"] = nil
        _G["VB_CvvxcxxxxC"] = true
    end)
end
*/

function VC.RemoveLight_PTextEnts(ent)
    if ent.VC_Lights then
        for LhtK, Lht in pairs(ent.VC_Lights) do
            if Lht.Running then
                VC.RemoveLight(Lht.Running)
                ent.VC_Lights[LhtK].Running = nil
            end

            if Lht.Reverse then
                VC.RemoveLight(Lht.Reverse)
                ent.VC_Lights[LhtK].Reverse = nil
            end

            if Lht.Head then
                VC.RemoveLight(Lht.Head)
                ent.VC_Lights[LhtK].Head = nil
            end

            if Lht.HBeam then
                VC.RemoveLight(Lht.HBeam)
                ent.VC_Lights[LhtK].HBeam = nil
            end

            if Lht.LBeam then
                VC.RemoveLight(Lht.LBeam)
                ent.VC_Lights[LhtK].LBeam = nil
            end

            if Lht.Brake then
                VC.RemoveLight(Lht.Brake)
                ent.VC_Lights[LhtK].Brake = nil
            end

            if Lht.Turn then
                VC.RemoveLight(Lht.Turn)
                ent.VC_Lights[LhtK].Turn = nil
            end

            if Lht.Hazard then
                VC.RemoveLight(Lht.Hazard)
                ent.VC_Lights[LhtK].Hazard = nil
            end
        end
    end
end

function VC.HandleLights(ent)
    if VC.getSetting("Lights") and VC_fremmann777obosr(ent).Lights and VC_fremmann777obosr(ent).LightTable and not ent.VC_Destroyed and (not VC.IsTrailer(ent) or IsValid(ent.VC_Truck)) and VC.EngineAboveWater(ent) then
        local CBR = VC.getTruck(ent)
        MainEngineOn = VC.ElectronicsOn(CBR)
        if not ent.VC_Lights then ent.VC_Lights = {} end
        if VC.HandleLights_Main then VC.HandleLights_Main(ent, CBR, MainEngineOn) end
        if VC.HandleLights_ELS then VC.HandleLights_ELS(ent, CBR, MainEngineOn) end
    elseif ent.VC_Lights then
        VC.DeleteLights_All(ent)
        ent.VC_Lights = nil
    end
end

local function PrjTxtSpawn(ent, ang, pos, clr, size, fov, pos_bone)
    if clr then
        clr = VC.PrepareColor(clr, true)
        clr = {clr.r, clr.g, clr.b}
    else
        clr = {225, 225, 255}
    end

    local ret = ents.Create("env_projectedtexture")
    ret:SetAngles(VC.AngleCombCalc2(ent:GetAngles(), ang and (ang - Angle(0, 90, -90)) or Angle(0, 90, 0)))
    ret:SetPos(VC.VectorToWorld(ent, pos))
    ret:SetParent(ent)
    ret:SetKeyValue("lightcolor", string.Implode(" ", clr))
    ret:SetKeyValue("farz", size or 2048)
    ret:SetKeyValue("lightfov", fov or 150)
    ret:SetKeyValue("enableshadows", 1)
    ret:SetKeyValue("nearz", 32)
    ret:Input("SpotlightTexture", NULL, NULL, "vcmod/lights/hbeam_hit")
    ret:Spawn()
    ret.VC_Parent = ent
    return ret
end

local HeadLightTypes = {
    {
        name = "Low beam",
        Ang = Angle(28, 0, 0),
        size = 0.5,
        fov = 140,
        SepAng = 5
    },
    {
        name = "High beam",
        Ang = Angle(5, 0, 0),
        size = 2,
        fov = 90,
        SepAng = 5
    },
    {
        name = "Fog",
        Ang = Angle(28, 0, 0),
        size = 0.2,
        fov = 160,
        SepAng = 5
    },
}

function VC_fremmannmegaurod(ent, LTbl, Clr, LType)
    if not LType then LType = 1 end
    local LTable = {}
    if LTbl.UsePrjTex and LTbl.ProjTexture then
        local HLData = HeadLightTypes[LType]
        LTable.PrjTxt = PrjTxtSpawn(ent, LTbl.ProjTexture.Angle - HLData.Ang + Angle(0, LTbl.Pos.x > 0 and -HLData.SepAng or HLData.SepAng, 0), LTbl.Pos, Clr or "0 255 0", LTbl.ProjTexture.Size * HLData.size * (LType == 3 and VC.getSetting("FogLights_Dist_M") or VC.getSetting("HLights_Dist_M") or 1), HLData.fov, LTbl.Pos_Bone)
    end
    return LTable
end

function VC.RemoveLight(Lht)
    if IsValid(Lht.PrjTxt) then Lht.PrjTxt:Remove() end
end

local function initIndications(ent)
    if not ent.VC_vehicleAnims_History then
        ent.VC_vehicleAnims_History = {
            pparams = {},
            anim = {},
            mat = {}
        }
    end
end

function VC.IndicationCheck(ent, id, on)
    local sData = VC_fremmann777obosr(ent)
    if VC.getSetting("Indication") and sData and sData.Indication then
        local data = sData.Indication[id]
        if data then
            local pdata = on and data.bg_on or not on and data.bg_off
            if pdata and pdata.id and pdata.sub then ent:SetBodygroup(pdata.id, pdata.sub) end
            local pdata = data.mat_sel and data.mat_sel_new
            if pdata then
                initIndications(ent)
                if on then
                    ent:SetSubMaterial(data.mat_sel - 1, data.mat_sel_new)
                    ent.VC_vehicleAnims_History.mat[data.mat_sel] = data.mat_sel_new
                elseif ent.VC_vehicleAnims_History.mat[data.mat_sel] then
                    ent:SetSubMaterial(data.mat_sel - 1, nil)
                    ent.VC_vehicleAnims_History.mat[data.mat_sel] = nil
                end
            end
        end
    end
end

local function doSetPP(ent, pp, val)
    ent:SetPoseParameter(pp, val)
    if not ent.VC_vehicleAnims_History.pparams[pp] then ent.VC_vehicleAnims_History.pparams[pp] = {} end
    ent.VC_vehicleAnims_History.pparams[pp].val = val
end

function VC.handler_VehicleAnim(ent, mult)
    local sData = VC_fremmann777obosr(ent)
    if sData and sData.Indication then
        VC_D = sData.Indication
        initIndications(ent)
        local fTime = 4
        for k, tData in pairs(sData.Indication) do
            if k == "imported" then
                sData.Indication[k] = nil
                return
            end

            local iInfo = VC.IndicationListByKey[k]
            if iInfo and tData then
                local on = iInfo.getVal(ent)
                if tData.pp then
                    if iInfo.type == 0 then
                        local val = iInfo.getVal(ent)
                        local last = ent.VC_vehicleAnims_History.pparams[tData.pp] and ent.VC_vehicleAnims_History.pparams[tData.pp].val
                        if not last or last ~= val then
                            local top = tData.top or tData.max or 1
                            if val > top then val = top end
                            if val < 0 then val = 0 end
                            doSetPP(ent, tData.pp, Lerp(val / top, tData.min or 0, tData.max or 1))
                        end
                    elseif iInfo.type == 1 then
                        local last = ent.VC_vehicleAnims_History.anim[tData.pp] and ent.VC_vehicleAnims_History.anim[tData.pp].val or 0
                        local val = nil
                        if not ent.VC_vehicleAnims_History.anim[tData.pp] or ent.VC_vehicleAnims_History.anim[tData.pp].last == k then
                            if on and last < 1 then
                                if not ent.VC_vehicleAnims_History.anim[tData.pp] then
                                    ent.VC_vehicleAnims_History.anim[tData.pp] = {
                                        val = 0,
                                        last = k
                                    }
                                end

                                val = math.Approach(last, 1, ((tData.anim_speed_on or 1) / 100) * fTime)
                                ent.VC_vehicleAnims_History.anim[tData.pp] = {
                                    val = val,
                                    last = k
                                }
                            elseif not on and last > 0 then
                                local other = nil
                                for k2, tData2 in pairs(sData.Indication) do
                                    if k2 ~= k and tData2.pp and tData2.pp == tData.pp and tData2.min == tData.min and tData2.max == tData.max then
                                        local iInfo2 = VC.IndicationListByKey[k2]
                                        if iInfo2 and iInfo2.getVal(ent) then
                                            other = k2
                                            break
                                        end
                                    end
                                end

                                if other then
                                    ent.VC_vehicleAnims_History.anim[tData.pp].last = other
                                else
                                    val = math.Approach(last, 0, ((tData.anim_speed_off or 1) / 100) * fTime)
                                    ent.VC_vehicleAnims_History.anim[tData.pp].val = val
                                end
                            end

                            if val and val ~= last then
                                local ppv = VC.EaseInOut(Lerp(val, tData.min or 0, tData.max or 1))
                                doSetPP(ent, tData.pp, ppv)
                                if not on and val <= 0 then ent.VC_vehicleAnims_History.anim[tData.pp] = nil end
                            end
                        end
                    end
                end
            end
        end
    end
end

hook.Add("UpdateAnimation", "VC_UpdateAnimation", function(ply, vel, max)
    if VC.getSetting("Enabled") and VC.getSetting("Indication") then
        if IsValid(ply) then
            local ent = ply:GetVehicle()
            if IsValid(ent) then VC.handler_VehicleAnim(ent) end
        end
    end
end)

if not VC.CodeEnt then VC.CodeEnt = {} end
if not VC.CodeEnt.Repair_Wep then VC.CodeEnt.Repair_Wep = {} end
VC.CodeEnt.Repair_Wep.Initialize = function(self) self:SetWeaponHoldType("melee") end
VC.CodeEnt.Repair_Wep.Deploy = function(self)
    self:SendWeaponAnim(ACT_VM_DRAW)
    self.VC_TBNIA = CurTime() + self.Owner:GetViewModel():SequenceDuration()
    return true
end

VC.CodeEnt.Repair_Wep.Holster = function(self)
    if IsValid(self.VC_FixEffect) then
        self.VC_FixEffect:Remove()
        self.VC_FixEffect = nil
    end

    if self.VC_FixSound then
        self.VC_FixSound:Stop()
        self.VC_FixSound = nil
    end

    if self.VC_FixSound then
        self.VC_FixSound:Stop()
        self.VC_FixSound = nil
    end

    self:SetNWBool("VC_DamagedAim", false)
    self.VC_DamagedInfo = nil
    self:SetNWEntity("VC_DamagedEnt", NULL)
    self.VC_StartTime = nil
    self.VC_ForAmount = nil
    self:SetNWBool("VC_Fixing", false)
    self.VC_NextScanTime = nil
    return true
end

VC.CodeEnt.Repair_Wep.PrimaryAttack = function(self)
    if (not self.VC_TBNIA or CurTime() >= self.VC_TBNIA) and self.VC_DamagedInfo then
        self:SetNextPrimaryFire(CurTime() + 0.5)
        self.Owner:SetAnimation(PLAYER_ATTACK1)
    end
end

VC.CodeEnt.Repair_Wep.SecondaryAttack = function(self)
    local ply = self:GetOwner()
    local ent, hpos = VC.getVehicleTrace(ply)
    local ShootPos, AimVector = ply:GetShootPos(), ply:GetAimVector()
    if IsValid(ent) and hpos:Distance(ShootPos) <= 75 then
        if VC.RepairVehicle_Admin(ent, ply) then
            VCPopup(ply, "RepairingVehicleAdmin", "info")
        else
            VCPopup(ply, "AccessRestricted", "cross")
        end
    end
end

local function getRepairTime(ent, obj)
    local time = VC.GetPartInfo(obj, true).time
    if obj == "engine" and not ent.VC_Destroyed then time = 5 + time * (1 - ent.VC_HealthPerc) * 0.5 end
    return time
end

function VC.StartWrenching(ent, obj, int, ply, wep)
    if ent.VC_RM_RepairingObjects and ent.VC_RM_RepairingObjects.objects and ent.VC_RM_RepairingObjects.objects[obj] and ent.VC_RM_RepairingObjects.objects[obj][int] then return end
    if obj == "engine" and not ent.VC_Destroyed then
    elseif VC.getSetting("Damage_Repair_NeedPart") and (not ent.VC_RM_AttachedTbl or not ent.VC_RM_AttachedTbl[obj] or not ent.VC_RM_AttachedTbl[obj][int]) then
        return
    end

    if not ent.VC_WrenchingTbl then ent.VC_WrenchingTbl = {} end
    local key = obj .. int
    if not ent.VC_WrenchingTbl[key] then
        ent.VC_WrenchingTbl[key] = {
            obj = obj,
            int = int,
            time_s = CurTime(),
            time_e = CurTime() + getRepairTime(ent, obj),
            ply = ply,
            time_exp = 0.6
        }

        if wep then
            wep.VC_DoingStart = CurTime()
            wep.VC_DoingFinish = ent.VC_WrenchingTbl[key].time_e
            wep:SetNWInt("VC_DoingStart", wep.VC_DoingStart)
            wep:SetNWInt("VC_DoingFinish", wep.VC_DoingFinish)
        end
    end
end

function VC.RemoveWrenchPart(ent, obj, int)
    if not IsValid(ent) or not obj then return end
    if obj == "engine" then int = 1 end
    if ent.VC_RM_AttachedTbl and ent.VC_RM_AttachedTbl[obj] and ent.VC_RM_AttachedTbl[obj][int] then
        if IsValid(ent.VC_RM_AttachedTbl[obj][int]) then ent.VC_RM_AttachedTbl[obj][int]:Remove() end
        ent.VC_RM_AttachedTbl[obj][int] = nil
        if table.Count(ent.VC_RM_AttachedTbl[obj]) == 0 then ent.VC_RM_AttachedTbl[obj] = nil end
        if table.Count(ent.VC_RM_AttachedTbl) == 0 then ent.VC_RM_AttachedTbl = nil end
        VCEffect(ent:LocalToWorld(VC.GetObjectPos(ent, obj, int, 137)))
    end
end

function VC.StopWrenching(ent, obj, int)
    if not IsValid(ent) or not obj then return end
    local key = obj .. int
    ent.VC_WrenchingTbl[key] = nil
    if table.Count(ent.VC_WrenchingTbl) == 0 then ent.VC_WrenchingTbl = nil end
end

function VC.CodeEnt.Repair_Wep.ClearSelect(self)
    if self.VC_DamagedInfo then
        self:SetNWBool("VC_DamagedAim", false)
        self.VC_DamagedInfo = nil
        self:SetNWEntity("VC_DamagedEnt", NULL)
        self.VC_DamagedInfo = nil
    end
end

function VC.CodeEnt.Repair_Wep.ClearSeek(self)
    if self.VC_DoingStart then
        if IsValid(self.VC_FixEffect) then
            self.VC_FixEffect:Remove()
            self.VC_FixEffect = nil
        end

        if self.VC_FixSound then
            self.VC_FixSound:Stop()
            self.VC_FixSound = nil
        end

        self.VC_DoingStart = nil
        self.VC_DoingFinish = nil
        self:SetNWInt("VC_DoingStart", self.VC_DoingStart or 0)
        self:SetNWInt("VC_DoingFinish", self.VC_DoingFinish or 0)
    end
end

local function canSubmitError(ply)
    local ret = not ply.VC_RM_lastErrMsg or CurTime() >= ply.VC_RM_lastErrMsg
    if ret then ply.VC_RM_lastErrMsg = CurTime() + 2 end
    return ret
end

VC.CodeEnt.Repair_Wep.Think = function(self)
    if self.VC_TBNIA and CurTime() >= self.VC_TBNIA then
        self:SendWeaponAnim(ACT_VM_IDLE)
        self.VC_TBNIA = nil
    end

    if not vcmod1 then return end
    if self.VC_DamagedInfo then
        local key = self.VC_DamagedInfo.part .. self.VC_DamagedInfo.int
        local ent = self:GetNWEntity("VC_DamagedEnt")
        if (self:GetOwner():KeyDown(IN_ATTACK) or self:GetOwner():KeyDown(IN_ATTACK2) and self:GetOwner():IsAdmin()) and (not self.VC_TBNIA or CurTime() >= self.VC_TBNIA) then
            if IsValid(ent) then
                local ply = self:GetOwner()
                if not ent.VC_WrenchingTbl or (not ent.VC_WrenchingTbl[key] or ent.VC_WrenchingTbl[key].ply == ply) then
                    VC.StartWrenching(ent, self.VC_DamagedInfo.part, self.VC_DamagedInfo.int, ply, self)
                    if ent.VC_WrenchingTbl and ent.VC_WrenchingTbl[key] then
                        ent.VC_WrenchingTbl[key].time_exp = CurTime() + 0.1
                    else
                        if canSubmitError(ply) then VCPopup(ply, "NeedVehiclePart", "cross") end
                    end
                else
                    if canSubmitError(ply) then VCPopup(ply, "AlreadyBeingRepaired", "cross") end
                end
            end
        else
            if IsValid(ent) and ent.VC_WrenchingTbl and ent.VC_WrenchingTbl[key] then
                local v = ent.VC_WrenchingTbl[key]
                VC.StopWrenching(ent, v.obj, v.int)
            end

            VC.CodeEnt.Repair_Wep.ClearSeek(self)
        end
    else
        VC.CodeEnt.Repair_Wep.ClearSeek(self)
    end

    if not self.VC_NextScanTime or CurTime() >= self.VC_NextScanTime then
        local ent, hpos = VC.getVehicleTrace(self:GetOwner())
        local ShootPos, AimVector = self:GetOwner():GetShootPos(), self:GetOwner():GetAimVector()
        if IsValid(ent) and hpos:Distance(ShootPos) <= 75 then
            if ent:IsVehicle() then
                local Info = VC.GetDamagedPart(ent, hpos, AimVector, 0.9, ShootPos, self:GetOwner())
                if Info.part then
                    local old = self.VC_DamagedInfo and self.VC_DamagedInfo.part .. self.VC_DamagedInfo.int
                    self:SetNWBool("VC_DamagedAim", true)
                    self.VC_DamagedInfo = Info
                    self:SetNWString("VC_DamagedPart", self.VC_DamagedInfo.part)
                    self:SetNWString("VC_DamagedPart_Int", self.VC_DamagedInfo.int)
                    self:SetNWVector("VC_DamagedPos", self.VC_DamagedInfo.pos)
                    self:SetNWEntity("VC_DamagedEnt", ent)
                    if old and old ~= (self.VC_DamagedInfo and self.VC_DamagedInfo.part .. self.VC_DamagedInfo.int) then VC.CodeEnt.Repair_Wep.ClearSeek(self) end
                else
                    VC.CodeEnt.Repair_Wep.ClearSelect(self)
                end
            end
        else
            VC.CodeEnt.Repair_Wep.ClearSelect(self)
        end

        self.VC_NextScanTime = CurTime() + (self.VC_DamagedInfo and 0.2 or 1)
    end
end

local ID = "Pickup_partkit"
if not VC.CodeEnt[ID] then VC.CodeEnt[ID] = {} end
VC.CodeEnt[ID].Touch = function(self, ent)
    if not IsValid(ent) then return end
    if ent.VC_DamagedObjects then
        VC.RepairAllParts(ent)
        VCEffect(self:GetPos())
        VC.SoundEmit(ent, "items/smallmedkit1.wav", nil, 70)
        self:Remove()
        self.VC_Used = true
    end
end

VC.CodeEnt[ID].Use = function(self, ply) VCPopup(ply, "TouchCarWithThis", "info") end
local ID = "Pickup_carpart"
if not VC.CodeEnt[ID] then VC.CodeEnt[ID] = {} end
local angOffset = {}
angOffset.wheel = Angle(90, 0, 0)
angOffset.light = Angle(0, 0, 90)
angOffset.exhaust = Angle(180, 90, 0)
angOffset.engine = Angle(0, 90, 0)
local posOffset = {}
posOffset.wheel = Vector(0, 0, 0)
posOffset.light = Vector(0, 0, 0)
posOffset.exhaust = Vector(-5, 10, 0)
posOffset.engine = Vector(0, 0, 10)
local function Initialize(self)
    self:SetCustomCollisionCheck(false)
    self.VC_ActiveTime = CurTime() + 0.5
end

VC.CodeEnt[ID].Think = function(self, ent, obj, int)
    if not self.VC_Initialized then
        Initialize(self)
        self.VC_Initialized = true
    end
end

VC.CodeEnt[ID].Attach = function(self, ent, obj, int)
    if not IsValid(ent) or not obj then return end
    if ent.VC_RM_RepairingObjects and ent.VC_RM_RepairingObjects.objects and ent.VC_RM_RepairingObjects.objects[obj] and ent.VC_RM_RepairingObjects.objects[obj][int] then return end
    if not ent.VC_WeldedObjects then ent.VC_WeldedObjects = {} end
    if not ent.VC_WeldedObjects.parts then ent.VC_WeldedObjects.parts = {} end
    if not ent.VC_WeldedObjects.parts[obj] then ent.VC_WeldedObjects.parts[obj] = {} end
    ent.VC_WeldedObjects.parts[obj][int] = {
        ent = self,
        time = CurTime()
    }

    self.VC_AttachedTo = ent
    local posoffset = table.Copy(posOffset)
    posoffset = posoffset[obj]
    local fpos = VC.GetObjectPos(ent, obj, int, 137)
    local ext = Angle(0, 0, 0)
    if fpos.x < 0 then
        posoffset.x = -posoffset.x
        ext = Angle(0, 0, 180)
    end

    if obj == "light" then
        ext = Angle(0, 0, 0)
        if fpos.y < 0 then ext = Angle(0, 0, 180) end
    end

    self:SetAngles(ent:LocalToWorldAngles(angOffset[obj] + ext))
    self:SetPos(ent:LocalToWorld(fpos + posoffset))
    self:SetParent(ent)
    self:SetNWEntity("VC_AttachedTo", ent)
    self:SetNWString("VC_Attached_Obj", ent.VC_Method)
    self:SetNWInt("VC_Attached_Obj_Int", int)
    self:SetMaterial("models/wireframe")
    self:SetCollisionGroup(COLLISION_GROUP_IN_VEHICLE)
    self:ForcePlayerDrop()
    if obj == "wheel" then self:Fire("SetParentAttachmentMaintainOffset", VC.Wheels[int]) end
    if not ent.VC_RM_AttachedTbl then ent.VC_RM_AttachedTbl = {} end
    if not ent.VC_RM_AttachedTbl[obj] then ent.VC_RM_AttachedTbl[obj] = {} end
    ent.VC_RM_AttachedTbl[obj][int] = self
end

VC.CodeEnt[ID].Touch = function(self, ent)
    if not IsValid(ent) then return end
    if not self.VC_ActiveTime or CurTime() < self.VC_ActiveTime then return end
    if not self.VC_AttachedTo then
        local isEngine = self.VC_Method == "engine"
        if isEngine and ent.VC_Destroyed or not isEngine and ent.VC_DamagedObjects and ent.VC_DamagedObjects[self.VC_Method] then
            local obj = nil
            local dist = nil
            local fpos = nil
            if isEngine then
                obj = 1
                fpos = ent:LocalToWorld(VC.GetObjectPos(ent, self.VC_Method, k, 137))
            else
                for k, v in pairs(ent.VC_DamagedObjects[self.VC_Method]) do
                    local pos = ent:LocalToWorld(VC.GetObjectPos(ent, self.VC_Method, k, 137))
                    local ndist = self:GetPos():Distance(pos)
                    if ndist < 250 and (not dist or dist > ndist) and (not ent.VC_WeldedObjects or not ent.VC_WeldedObjects.parts or not ent.VC_WeldedObjects.parts[self.VC_Method] or not ent.VC_WeldedObjects.parts[self.VC_Method][k] or not IsValid(ent.VC_WeldedObjects.parts[self.VC_Method][k].ent)) then
                        dist = ndist
                        fpos = pos
                        obj = k
                    end
                end
            end

            if obj then VC.CodeEnt[ID].Attach(self, ent, self.VC_Method, obj) end
        end
    end
end

VC.CodeEnt[ID].Use = function(self, ply)
    VCPopup(ply, "TouchBrokenCarPiece", "info")
    if VC.getSetting("Damage_Repair_GiveWrenchToCarPartUser") then
        ply:Give("vc_wrench")
        ply:SelectWeapon("vc_wrench")
    end
end

if not VC.CodeEnt.Spikestrip_wep then VC.CodeEnt.Spikestrip_wep = {} end
VC.CodeEnt.Spikestrip_wep.Initialize = function(self) self:SetWeaponHoldType("physgun") end
VC.CodeEnt.Spikestrip_wep.Holster = function(self) return true end
VC.CodeEnt.Spikestrip_wep.Deploy = function(self)
    VC.SoundEmit(self, "items/ammocrate_open.wav", nil, 70)
    self:SendWeaponAnim(ACT_VM_DRAW)
    self.VC_TBNIA = CurTime() + self.Owner:GetViewModel():SequenceDuration()
    return true
end

VC.CodeEnt.Spikestrip_wep.Think = function(self)
    if self.VC_TBNIA and CurTime() >= self.VC_TBNIA then
        self:SendWeaponAnim(ACT_VM_IDLE)
        self.VC_TBNIA = nil
    end
end

VC.CodeEnt.Spikestrip_wep.Place = function(self, tr, ply)
    if self.VC_Placed then return end
    self.VC_Placed = true
    if hook.Call("VC_CanPlaceSpikeStrip", GAMEMODE, ply, tr.HitPos) == false or hook.Call("VC_canPlaceSpikeStrip", GAMEMODE, ply, tr.HitPos) == false then
        VCPopup(ply, "AccessRestricted", "cross")
        return false
    end

    local ent = ents.Create("vc_spikestrip")
    if not IsValid(ent) then return end
    ent:SetPos(tr.HitPos)
    ent:SetAngles(Angle(0, self:GetOwner():EyeAngles().y - 90, 0))
    ent:Spawn()
    ent.VC_Spawner = ply
    ent.VC_Owner = self:GetOwner()
    if not ply.VC_Spikestrips then ply.VC_Spikestrips = {} end
    table.insert(ply.VC_Spikestrips, ent)
    ent:GetPhysicsObject():EnableMotion(false)
    VCPopup(self:GetOwner(), "HoldUseToPickup", "info")
    VC.SoundEmit(self, "vcmod/switch_on.wav", nil, 70)
    VCEffect(ent:GetPos())
    self:GetOwner():StripWeapon("vc_spikestrip_wep")
    self:Remove()
    hook.Call("VC_spikeStripPlaced", GAMEMODE, ent, ply)
end

VC.CodeEnt.Spikestrip_wep.PrimaryAttack = function(self)
    if not self.VC_Timer or CurTime() >= self.VC_Timer then
        local ply = self:GetOwner()
        if not IsValid(ply) then return end
        local doing = false
        if ply:EyeAngles().p > 45 then
            local tr = ply:GetEyeTraceNoCursor()
            self.VC_LastTr = tr
            doing = tr.Hit and tr.HitPos:Distance(ply:EyePos()) < 100
        end

        if doing then VC.CodeEnt.Spikestrip_wep.Place(self, self.VC_LastTr, ply) end
        self.VC_Timer = CurTime() + 1
    end
end

if not VC.CodeEnt.Spikestrip then VC.CodeEnt.Spikestrip = {} end
if not VC.CodeEnt.Spikestrip_Pointy then VC.CodeEnt.Spikestrip_Pointy = {} end
VC.CodeEnt.Spikestrip.Think = function(self, ent, obj, int)
    if not self.VC_Initialized then
        self:SetCustomCollisionCheck(false)
        self.VC_Initialized = true
    end
end

VC.CodeEnt.Spikestrip_Pointy.Think = VC.CodeEnt.Spikestrip.Think
VC.CodeEnt.Spikestrip.StateChanged = function(self)
    if IsValid(self.VC_Entity) then self.VC_Entity:Remove() end
    if IsValid(self.VC_Weld) then self.VC_Weld:Remove() end
    timer.Simple(0.5, function()
        if IsValid(self) then
            local ent = ents.Create(self.VC_Deployed and "vc_spikestrip_pointyend_extended" or "vc_spikestrip_pointyend")
            if IsValid(ent) then
                if self.VC_Deployed then
                    ent:SetPos(self:GetPos() - self:GetRight() * 5 + self:GetUp() * 0)
                else
                    ent:SetPos(self:GetPos() - self:GetRight() * 5 - self:GetForward() * 7 + self:GetUp() * 1)
                end

                ent:SetAngles(self:GetAngles())
                ent:Spawn()
                self:DeleteOnRemove(ent)
                ent:SetNoDraw(true)
                ent:SetOwner(self)
                self.VC_Entity = ent
                self.VC_Weld = constraint.Weld(self, ent, 0, 0, 0, false, false)
                ent:GetPhysicsObject():EnableMotion(false)
                ent.VC_Entity = self
            end
        end
    end)
end

VC.CodeEnt.Spikestrip.Deploy = function(self)
    hook.Call("VC_SpikeStripDeployed", GAMEMODE, self)
    hook.Call("VC_spikeStripDeployed", GAMEMODE, self)
    self.VC_Deployed = true
    self:SetNWBool("VC_Deployed", self.VC_Deployed)
    VC.CodeEnt.Spikestrip.StateChanged(self)
    VC.SoundEmit(self, "vcmod/air_piston.wav", nil, 60)
end

VC.CodeEnt.Spikestrip.Retract = function(self)
    hook.Call("VC_SpikeStripRetracted", GAMEMODE, self)
    hook.Call("VC_spikeStripRetracted", GAMEMODE, self)
    self.VC_Deployed = false
    self:SetNWBool("VC_Deployed", self.VC_Deployed)
    VC.CodeEnt.Spikestrip.StateChanged(self)
end

VC.CodeEnt.Spikestrip_Pointy.Touch = function(self, ent)
    if ent.VC_Entity or not IsValid(ent) then return end
    if not ent.VC_TouchTime or CurTime() >= ent.VC_TouchTime then
        if ent.VC_isSupported then
            if not ent.VC_isELS or not VC.getSetting("SpikeStrip_Ignore_ELS") then
                for i = 1, 4 do
                    if not VC.ObjectIsDamaged(ent, "wheel", i) then
                        local pos = ent:LocalToWorld(VC.GetObjectPos(ent, "wheel", i, 137))
                        local dist = pos:Distance(self:GetTouchTrace().HitPos)
                        if dist < ((ent.VC_Wheels and ent.VC_Wheels[1] and ent.VC_Wheels[1].Radius or 20) + 20) then
                            local inf = self.VC_Entity or self
                            VC.DamageWheel(ent, i, nil, nil, inf.VC_Spawner, inf)
                        end
                    end
                end
            end

            ent.VC_TouchTime = nil
        else
            if VC.getSetting("SpikeStrip_damage_players") and (ent:IsPlayer() or ent:IsNPC()) then
                local dinfo = DamageInfo()
                dinfo:SetDamage(1)
                dinfo:SetAttacker(IsValid(ent.VC_Owner) and ent.VC_Owner or ent)
                dinfo:SetInflictor(self)
                dinfo:SetDamageType(DMG_SLASH)
                ent:TakeDamageInfo(dinfo)
            end

            ent.VC_TouchTime = CurTime() + 0.5
        end
    end
end

local function useEnd(self)
    if not self.VC_NextActionTime or CurTime() >= self.VC_NextActionTime then
        if hook.Call("VC_canToggleSpikeStrip", GAMEMODE, self.VC_userLast, self) == false then
            VCPopup(self.VC_userLast, "AccessRestricted", "cross")
            return false
        end

        if self.VC_Deployed then
            VC.CodeEnt.Spikestrip.Retract(self)
        else
            if not self.VC_IgnoreDeploy then VC.CodeEnt.Spikestrip.Deploy(self) end
        end
    end

    self.VC_IgnoreDeploy = nil
end

VC.CodeEnt.Spikestrip.Take = function(self, ply)
    if IsValid(ply) then
        if hook.Call("VC_CanPickupSpikeStrip", GAMEMODE, ply, self) == false or hook.Call("VC_canPickupSpikeStrip", GAMEMODE, ply, self) == false then
            VCPopup(ply, "AccessRestricted", "cross")
            return false
        end

        if ply:HasWeapon("vc_spikestrip_wep") then
            ply:SelectWeapon("vc_spikestrip_wep")
            VCPopup(ply, "YouAlreadyHaveSpikestrip", "cross")
            return
        end

        ply:Give("vc_spikestrip_wep")
        ply:SelectWeapon("vc_spikestrip_wep")
        VCEffect(self:GetPos())
        self:Remove()
    end
end

VC.CodeEnt.Spikestrip.Use = function(self, ply)
    if (not self.VC_Owner or ply ~= self.VC_Owner) and not ply:IsAdmin() then
        VCPopup(ply, "AccessRestricted", "cross")
        return
    end

    if not self.VC_LastUseTime or CurTime() >= (self.VC_LastUseTime + 0.2) then self.VC_TakeTime = CurTime() + 0.5 end
    self.VC_LastUseTime = CurTime()
    self.VC_userLast = ply
end

VC.CodeEnt.Spikestrip.Think = function(self)
    if self.VC_LastUseTime then
        if self.VC_TakeTime and CurTime() >= self.VC_TakeTime then
            if self.VC_Deployed then
                self.VC_IgnoreDeploy = true
                VC.CodeEnt.Spikestrip.Retract(self)
            else
                VC.CodeEnt.Spikestrip.Take(self, self.VC_userLast)
            end

            self.VC_TakeTime = nil
        end

        if (CurTime() - self.VC_LastUseTime) > 0.1 then
            ending = true
            self.VC_LastUseTime = nil
            useEnd(self)
        end
    end

    if not self.VC_Init then
        VC.CodeEnt.Spikestrip.StateChanged(self)
        self.VC_Init = true
    end
end

if not VC.CodeEnt.Fuel_station then VC.CodeEnt.Fuel_station = {} end
VC.CodeEnt.Fuel_station.VC_CreateJerrycan = function(self)
    if not VC.getSetting("Fuel_Pickups_Beside_Stations") then return end
    if not IsValid(self.VC_Jerrycan) and (self.VC_FuelType == 0 or self.VC_FuelType == 1) then
        self.VC_Jerrycan = ents.Create("vc_pickup_fuel_" .. VC.FuelTypes[self.VC_FuelType].name)
        self.VC_Jerrycan:SetPos(self:LocalToWorld(Vector(0, -30, 15)))
        self.VC_Jerrycan:SetAngles(self:LocalToWorldAngles(Angle(0, 90, 0)))
        self.VC_Jerrycan:Spawn()
        self.VC_Jerrycan:Activate()
        self.VC_Jerrycan.VC_Station = self
        self:DeleteOnRemove(self.VC_Jerrycan)
        self.VC_Jerrycan.VC_Storage = 0
        self.VC_Jerrycan:SetNWInt("VC_Storage", -1)
        constraint.Weld(self, self.VC_Jerrycan, 0, 0, 0, false, false)
        VCEffect(self.VC_Jerrycan:GetPos())
    end
end

VC.CodeEnt.Fuel_station.VC_Init = function(self)
    self.VC_SoundActive = CreateSound(self, "ambient/machines/diesel_engine_idle1.wav", self:EntIndex())
    self.VC_SoundActive:SetSoundLevel(50)
    self.VC_SoundPumping = CreateSound(self, self.VC_FuelType == 2 and "ambient/energy/electric_loop.wav" or "ambient/water/water_run1.wav", self:EntIndex())
    self.VC_SoundActive:SetSoundLevel(52)
    function self:OnRemove()
        if self.VC_SoundActive:IsPlaying() then self.VC_SoundActive:Stop() end
        if self.VC_SoundPumping:IsPlaying() then self.VC_SoundPumping:Stop() end
    end

    local monitor = ents.Create("prop_dynamic")
    if IsValid(monitor) then
        monitor:SetModel("models/props_lab/monitor02.mdl")
        monitor:SetPos(self:LocalToWorld(Vector(-2, 0, 53)))
        monitor:SetAngles(self:LocalToWorldAngles(Angle(-35, 0, 180)))
        monitor:SetParent(self)
        monitor:Spawn()
        self:DeleteOnRemove(monitor)
    end

    self.VC_Nozzle = ents.Create("vc_fuel_nozzle")
    if not IsValid(self.VC_Nozzle) then
        VCPrint("ERROR, missing entity 'vc_fuel_nozzle' or it was not allowed ot be spawned.")
        return
    end

    self.VC_Nozzle:SetPos(self:LocalToWorld(Vector(0, -20, 45)))
    self.VC_Nozzle:SetAngles(self:LocalToWorldAngles(Angle(50, 90, 0)))
    self.VC_NextCheck = CurTime() + 1
    self.VC_Nozzle:Spawn()
    self.VC_Nozzle:Activate()
    self.VC_Nozzle.VC_Station = self
    self.VC_Nozzle.VC_FuelType = self.VC_FuelType
    self:DeleteOnRemove(self.VC_Nozzle)
    self.VC_Rope = constraint.Rope(self, self.VC_Nozzle, 0, 0, Vector(0, -18, 57), Vector(0, 0, -2.5), 150, 0, 0, 2, "cable/cable2", false)
    timer.Simple(1, function()
        if IsValid(self) and IsValid(self:GetPhysicsObject()) then
            self:GetPhysicsObject():EnableMotion(false)
            self.VC_Initialized = true
        end
    end)

    VC.CodeEnt.Fuel_station.VC_CreateJerrycan(self)
end

VC.CodeEnt.Fuel_station.VC_Hitch = function(self)
    if not self.VC_Nozzle or not IsValid(self.VC_Nozzle) or IsValid(self.VC_Nozzle.VC_Weld) then return end
    if self.VC_SoundActive:IsPlaying() then self.VC_SoundActive:FadeOut(1) end
    if self.VC_SoundPumping:IsPlaying() then self.VC_SoundPumping:FadeOut(0.2) end
    self.VC_Nozzle:SetVelocity(Vector(0, 0, 0))
    self.VC_Nozzle:SetPos(self:LocalToWorld(Vector(3, -25, 45)))
    self.VC_Nozzle:SetAngles(self:LocalToWorldAngles(Angle(50, 110, 0)))
    self.VC_Nozzle.VC_Weld = constraint.Weld(self, self.VC_Nozzle, 0, 0, 10000, false, false)
    self.VC_Nozzle:SetCollisionGroup(COLLISION_GROUP_WORLD)
    self.VC_Nozzle.VC_WeldEntity = self
    local physObj = self.VC_Nozzle:GetPhysicsObject()
    if IsValid(physObj) then
        physObj:EnableMotion(false)
        timer.Simple(1, function()
            if IsValid(physObj) then
                physObj:Sleep()
                physObj:EnableMotion(true)
            end
        end)
    end

    self:SetNWBool("VC_Hitched", true)
    self.VC_Pumped = nil
    self:SetNWInt("VC_Pumped", 0)
    self.VC_PumpedGoal = 0
    self:SetNWInt("VC_PumpedGoal", self.VC_PumpedGoal)
    VC.SoundEmit(self.VC_Nozzle, "physics/metal/metal_box_impact_soft1.wav", nil, 75)
    VCEffect(self.VC_Nozzle:GetPos())
end

local function selectFuel(self, amount)
    VC.SoundEmit(self, "Clk", 95, 50)
    local cursel = self:GetNWInt("VC_Selected", 0) + amount
    if cursel < 0 then cursel = 0 end
    self:SetNWInt("VC_Selected", cursel)
end

VC.CodeEnt.Fuel_station.Think = function(self)
    local ctime = CurTime()
    if not self.VC_NextCheck or ctime >= self.VC_NextCheck then
        if IsValid(self.VC_Nozzle) and not VC.isHeld(self.VC_Nozzle) and not IsValid(self.VC_Nozzle.VC_Weld) then self:VC_Hitch() end
        self.VC_NextCheck = ctime + 5
    end

    if not self.VC_NextRefCheck or ctime >= self.VC_NextRefCheck then
        local ent = self.VC_Nozzle and self.VC_Nozzle.VC_WeldEntity
        if IsValid(self.VC_Nozzle) and IsValid(self.VC_Nozzle.VC_Weld) and IsValid(ent) and ent ~= self and self.VC_Purchased and self.VC_Purchased > 0 and (ent:IsVehicle() and ent.VC_Fuel and ent.VC_MaxFuel and ent.VC_Fuel < ent.VC_MaxFuel or ent.VC_Storage and ent.VC_Storage < ent.VC_MaxStorage) then
            if not self.VC_Pumping then
                self.VC_Pumping = true
                self:SetNWBool("VC_Pumping", true)
                if not self.VC_SoundPumping:IsPlaying() then self.VC_SoundPumping:Play() end
            end
        else
            if self.VC_Pumping then
                self.VC_Pumping = false
                self:SetNWBool("VC_Pumping", false)
                if self.VC_SoundPumping:IsPlaying() then self.VC_SoundPumping:FadeOut(0.2) end
            end
        end

        if self.VC_Pumping then
            local amount = 1
            if self.VC_FuelType == 2 then amount = amount * 0.1 end
            if IsValid(ent) then
                if ent:IsVehicle() then
                    if VC.Refuel then VC.Refuel(ent, amount) end
                else
                    ent.VC_Storage = ent.VC_Storage + amount
                    ent:SetNWInt("VC_Storage", ent.VC_Storage)
                end
            end

            self.VC_Purchased = math.Clamp((self.VC_Purchased or 0) - amount, 0, self.VC_Purchased)
            self:SetNWInt("VC_Purchased", self.VC_Purchased)
            self.VC_Pumped = (self.VC_Pumped or 0) + amount
            self:SetNWInt("VC_Pumped", self.VC_Pumped)
        end

        self.VC_NextRefCheck = ctime + 0.5 * VC.getSetting("Refuel_Mult_Station", 1)
    end

    if self.VC_ResetFuelSelectTimer and ctime >= self.VC_ResetFuelSelectTimer then
        selectFuel(self, -self:GetNWInt("VC_Selected", 0))
        self.VC_ResetFuelSelectTimer = nil
    end

    if not self.VC_CanisterCheckTimer or ctime >= self.VC_CanisterCheckTimer then
        VC.CodeEnt.Fuel_station.VC_CreateJerrycan(self)
        self.VC_CanisterCheckTimer = ctime + 1
    end
end

VC.CodeEnt.Fuel_station.Use = function(self, ply)
    local dist = ply:GetPos():Distance(self:GetPos())
    if dist < 100 then
        local tr = util.TraceLine({
            start = ply:GetShootPos(),
            endpos = ply:GetShootPos() + ply:GetAimVector() * 90,
            filter = ply
        })

        local sel = 0
        if IsValid(tr.Entity) and tr.Entity == self then
            local pos = tr.Entity:WorldToLocal(tr.HitPos)
            if pos.y > -8 and pos.y < 8 and pos.z > 37 and pos.z < 50 then
                self.VC_ResetFuelSelectTimer = CurTime() + 30
                if pos.y < -4 then
                    sel = 1
                    selectFuel(self, -5)
                elseif pos.y > 4 then
                    sel = 2
                    selectFuel(self, 5)
                elseif pos.z < 44 then
                    sel = 3
                    VC.SoundEmit(self, "Clk", 110, 50)
                    local cursel = self:GetNWInt("VC_Selected", 0)
                    if cursel < 0 then cursel = 0 end
                    local orsel = cursel
                    if cursel > 0 then
                        if self.VC_FuelType == 2 then cursel = cursel * 1.7 end
                        local price = cursel * (VC.Settings["Fuel_PPL_" .. self.VC_FuelType] or 1)
                        if ((self.VC_Purchased or 0) + cursel) > VC.getSetting("Refuel_MaxCapacity") then
                            VCPopup(ply, "ReachedMaxCapacity", "cross")
                            return
                        end

                        if not VC.CanAfford(ply, price) then
                            VCPopup(ply, "CD_Cant_Afford", "cross")
                            return
                        end

                        if hook.Call("VC_canPurchaseFuel", GAMEMODE, ply, self, self.VC_Purchased or 0, cursel, price, VC.FuelTypes[self.VC_FuelType].name) == false then return end
                        VC.RemoveMoney(ply, price, "fuelPurchase_" .. self.VC_FuelType)
                        local log_start = '<Fuel> Player: ' .. VC.log_getPlayer(ply)
                        VC.log(log_start .. ' has bought fuel "' .. VC.log_highLight(VC.FuelTypes[self.VC_FuelType].name) .. '" for: ' .. VC.log_highLight(price) .. '.', "Fuel")
                        self.VC_Purchased = (self.VC_Purchased or 0) + orsel
                        self:SetNWInt("VC_Purchased", self.VC_Purchased)
                        self.VC_PumpedGoal = (self.VC_PumpedGoal or 0) + orsel
                        self:SetNWInt("VC_PumpedGoal", self.VC_PumpedGoal)
                        self:SetNWInt("VC_Selected", 0)
                    end
                end
            end
        end
    end
end

VC.CodeEnt.Fuel_station.Touch = function(self, ent) if IsValid(self.VC_Nozzle) and ent == self.VC_Nozzle then self:VC_Hitch() end end
if not VC.CodeEnt.Fuel_nozzle then VC.CodeEnt.Fuel_nozzle = {} end
VC.CodeEnt.Fuel_nozzle.Use = function(self, ply)
    if IsValid(self.VC_Weld) then
        self.VC_Weld:Remove()
        self.VC_NextHitch = CurTime() + 5
    end
end

VC.CodeEnt.Fuel_nozzle.Think = function(self, ent, obj, int)
    if not self.VC_Initialized then
        self:SetCustomCollisionCheck(false)
        self.VC_Initialized = true
    end

    VC.isHeld(self)
end

util.AddNetworkString("VC_SentToClient_FuelNozzle_PickedUp")
VC.CodeEnt.Fuel_nozzle.VC_PickedUp = function(self, ply)
    self.VC_Station:SetNWBool("VC_Hitched", false)
    if not self.VC_Station.VC_SoundActive:IsPlaying() then self.VC_Station.VC_SoundActive:Play() end
    if IsValid(self.VC_Weld) then
        self.VC_Weld:Remove()
        self.VC_NextHitch = CurTime() + 0.5
    end

    self:SetCollisionGroup(COLLISION_GROUP_NONE)
    net.Start("VC_SentToClient_FuelNozzle_PickedUp")
    net.WriteEntity(self)
    net.Send(ply)
end

VC.CodeEnt.Fuel_nozzle.Touch = function(self, ent)
    local ftype = self.VC_FuelType or 0
    local eftype = ent.VC_FuelType or 0
    if not IsValid(self.VC_Weld) and not IsValid(ent.VC_Weld_FNozzle) and self.VC_Station and self.VC_Station.VC_Initialized and (not self.VC_NextHitch or CurTime() >= self.VC_NextHitch) then
        if ent:IsVehicle() then
            if VC.canRefuel(ent, eftype, ftype) then
                local lidpos = ent:LocalToWorld(ent.VC_FuelLidPos)
                if self:GetPos():Distance(lidpos) < 35 then
                    local mult = ent.VC_FuelLidPos.x < 0 and -1 or 1
                    self:SetPos(lidpos + ent:GetRight() * 13 * mult + ent:GetUp() * 7)
                    self:SetAngles(ent:LocalToWorldAngles(Angle(45, 90 + 90 * mult, 0)))
                    self.VC_Weld = constraint.Weld(self, ent, 0, 0, 10000, false, false)
                    ent.VC_Weld_FNozzle = self.VC_Weld
                    self:SetCollisionGroup(COLLISION_GROUP_WORLD)
                    self.VC_WeldEntity = ent
                    VC.SoundEmit(self, "physics/metal/metal_box_impact_soft1.wav", nil, 75)
                    self:GetPhysicsObject():EnableMotion(false)
                    timer.Simple(1, function() if IsValid(self) then self:GetPhysicsObject():EnableMotion(true) end end)
                    self.VC_NextHitch = CurTime() + 0.5
                    self.VC_Station.VC_Pumped = 0
                    self.VC_Station:SetNWInt("VC_Pumped", self.VC_Station.VC_Pumped)
                    self.VC_Station.VC_PumpedGoal = (self.VC_PumpedGoal or 0) + (self.VC_Station.VC_Purchased or 0)
                    self.VC_Station:SetNWInt("VC_PumpedGoal", self.VC_Station.VC_PumpedGoal)
                    VCEffect(self:GetPos())
                end
            end
        else
            if ent.VC_Type and ent.VC_Type == "pickup_fuel" and ftype == eftype then
                self:SetPos(ent:LocalToWorld(Vector(0, -17, 16)))
                self:SetAngles(ent:LocalToWorldAngles(Angle(45, 90, 0)))
                self.VC_Weld = constraint.Weld(self, ent, 0, 0, 10000, false, false)
                ent.VC_Weld_FNozzle = self.VC_Weld
                self:SetCollisionGroup(COLLISION_GROUP_WORLD)
                self.VC_WeldEntity = ent
                VC.SoundEmit(self, "physics/metal/metal_box_impact_soft1.wav", nil, 75)
                self:GetPhysicsObject():EnableMotion(false)
                timer.Simple(1, function() if IsValid(self) then self:GetPhysicsObject():EnableMotion(true) end end)
                self.VC_NextHitch = CurTime() + 0.5
                self.VC_Station.VC_Pumped = 0
                self.VC_Station:SetNWInt("VC_Pumped", self.VC_Station.VC_Pumped)
                self.VC_Station.VC_PumpedGoal = (self.VC_PumpedGoal or 0) + (self.VC_Station.VC_Purchased or 0)
                self.VC_Station:SetNWInt("VC_PumpedGoal", self.VC_Station.VC_PumpedGoal)
                VCEffect(self:GetPos())
            end
        end
    end
end

if not VC.CodeEnt.Pickup_fuel then VC.CodeEnt.Pickup_fuel = {} end
VC.CodeEnt.Pickup_fuel.Think = function(self) end
VC.CodeEnt.Pickup_fuel.Use = function(self, ply)
    if self.VC_canPickupIn and CurTime() < self.VC_canPickupIn then return end
    if VC.getSetting("Fuel_Pickup_Pickup") and self.VC_FuelType < 2 then
        if not ply:HasWeapon("vc_jerrycan") then ply:Give("vc_jerrycan") end
        ply:SelectWeapon("vc_jerrycan")
        local wep = ply:GetActiveWeapon()
        if wep:GetClass() == "vc_jerrycan" and (not wep.VC_FuelType or wep.VC_FuelType == self.VC_FuelType or wep.VC_FuelAmount and wep.VC_FuelAmount <= 0) and wep.VC_AddFuel and (not wep.VC_FuelAmount or wep.VC_FuelAmount < 20) then
            local need = math.Clamp(self.VC_Storage - (wep.VC_FuelAmount or 0), 0, self.VC_Storage)
            self.VC_Storage = self.VC_Storage - need
            wep:VC_AddFuel(self.VC_FuelType, need)
            VCPopup(ply, "FuelTaken", "check")
            VC.SoundEmit(self, "items/ammocrate_open.wav", nil, 70)
            if self.VC_Storage <= 0 then
                local station = IsValid(self.VC_Station) and self.VC_Station
                self:Remove()
                if station then station.VC_CanisterCheckTimer = CurTime() + 0.2 end
            else
                self:SetNWInt("VC_Storage", self.VC_Storage)
            end
            return
        end
    end

    if VCPopup and VC.getSetting("Fuel_Pickup_Touch", self.VC_FuelType or VC.getSetting("Fuel_Pickup_Touch_Elec")) then VCPopup(ply, "TouchCarWithThis", "info") end
end

VC.CodeEnt.Pickup_fuel.Touch = function(self, ent)
    if not self.VC_NextTouch or CurTime() >= self.VC_NextTouch then
        self.VC_NextTouch = CurTime() + 1
        if (VC.getSetting("Fuel_Pickup_Touch") or self.VC_FuelType or VC.getSetting("Fuel_Pickup_Touch_Elec")) and ent:IsVehicle() and not ent.VC_Fuel_Disabled and not ent.VC_IsPrisonerPod and ent.VC_Fuel and ent.VC_FuelType and ent.VC_Fuel < ent.VC_MaxFuel and not self.VC_Used then
            if ent.VC_FuelType ~= self.VC_FuelType then return end
            VCEffect(self:GetPos())
            local need = math.Clamp(ent.VC_MaxFuel - ent.VC_Fuel, 0, self.VC_Storage)
            self.VC_Storage = self.VC_Storage - need
            ent.VC_Fuel_Refueler = ply
            ent.VC_Fuel_Refuel_Time = CurTime() + 1
            VC.Refuel(ent, need)
            VC.SoundEmit(ent, "items/ammocrate_open.wav", nil, 70)
            if self.VC_Storage <= 0 then
                self:Remove()
                self.VC_Used = true
            else
                self:SetNWInt("VC_Storage", self.VC_Storage)
            end
        end
    end
end

VC.CodeEnt.Pickup_fuel.OnTakeDamage = function(self, dinfo)
    if VC.getSetting("Fuel_Pickup_Explode") and self.VC_CanBeDamaged and not self.VC_Exploded and self.VC_Storage > 2 then
        local att = dinfo:GetAttacker()
        local Exp = ents.Create("env_explosion")
        Exp:SetKeyValue("iMagnitude", "50")
        Exp:SetPos(self:GetPos())
        Exp:SetOwner(att or self:GetOwner())
        Exp:Spawn()
        Exp:Fire("explode", 0)
        VC.DarkRPFireSpawn(self:GetPos())
        self:Remove()
        if IsValid(self.VC_Station) then self.VC_Station.VC_CanisterCheckTimer = CurTime() + 0.2 end
        self.VC_Exploded = true
    end
end

if not VC.CodeEnt.Jerrycan_Wep then VC.CodeEnt.Jerrycan_Wep = {} end
VC.CodeEnt.Jerrycan_Wep.Initialize = function(self)
    self:SetHoldType("smg")
    self.VC_SoundActive = CreateSound(self, "ambient/water/leak_1.wav")
    self.VC_SoundActive:SetSoundLevel(50)
    function self:OnRemove()
        if self.VC_SoundActive:IsPlaying() then self.VC_SoundActive:Stop() end
    end
end

VC.CodeEnt.Jerrycan_Wep.Deploy = function(self)
    VC.SoundEmit(self, "items/ammocrate_open.wav", nil, 70)
    self:SendWeaponAnim(ACT_VM_DRAW)
    self.VC_TBNIA = CurTime() + self.Owner:GetViewModel():SequenceDuration()
    return true
end

VC.CodeEnt.Jerrycan_Wep.Holster = function(self)
    if IsValid(self.VC_FixEffect) then
        self.VC_FixEffect:Remove()
        self.VC_FixEffect = nil
    end

    if self.VC_FixSound then
        self.VC_FixSound:Stop()
        self.VC_FixSound = nil
    end

    if self.VC_FixSound then
        self.VC_FixSound:Stop()
        self.VC_FixSound = nil
    end

    if self.VC_SoundActive:IsPlaying() then self.VC_SoundActive:FadeOut(0.2) end
    self:SetNWBool("VC_DamagedAim", false)
    self.VC_ActionInfo = nil
    self:SetNWEntity("VC_AimEntity", NULL)
    self.VC_StartTime = nil
    self.VC_ForAmount = nil
    self:SetNWBool("VC_Doing", false)
    self.VC_NextScanTime = nil
    return true
end

VC.CodeEnt.Jerrycan_Wep.PrimaryAttack = function(self)
    if (not self.VC_TBNIA or CurTime() >= self.VC_TBNIA) and self.VC_ActionInfo then
        self:SetNextPrimaryFire(CurTime() + 0.5)
        self.Owner:SetAnimation(PLAYER_ATTACK1)
    end
end

function VC.CodeEnt.Jerrycan_Wep.DropFuel(self)
    local droppos = util.TraceLine({
        start = self:GetOwner():GetShootPos(),
        endpos = self:GetOwner():GetShootPos() + self:GetOwner():GetAimVector() * 75,
        filter = self:GetOwner()
    }).HitPos

    if self.VC_FuelAmount and self.VC_FuelAmount > 0 then
        local GEnt = ents.Create("vc_pickup_fuel_" .. string.lower(VC.FuelTypes[self.VC_FuelType].name))
        GEnt:SetPos(droppos + Vector(0, 0, 20))
        GEnt:SetAngles(Angle(0, self:GetOwner():GetAngles().y, 0))
        GEnt:Spawn()
        GEnt:Activate()
        VCEffect(GEnt:GetPos())
        local amount = self.VC_FuelAmount
        GEnt.VC_canPickupIn = CurTime() + 0.1
        timer.Simple(0.1, function() GEnt.VC_Storage = amount end)
        GEnt:SetNWInt("VC_Storage", self.VC_FuelAmount)
    end

    if IsValid(self:GetOwner()) then
        VCPopup(self:GetOwner(), "DroppedFuel", "check")
        VC.SoundEmit(self, "items/ammocrate_open.wav", nil, 70)
        self:GetOwner():StripWeapon("vc_jerrycan")
    end
end

VC.CodeEnt.Jerrycan_Wep.SecondaryAttack = function(self) VC.CodeEnt.Jerrycan_Wep.DropFuel(self) end
local function SetFuel(self, ftype, num)
    self:SetNWInt("VC_FuelType", ftype or 0)
    self:SetNWInt("VC_FuelAmount", self.VC_FuelAmount or 0)
end

VC.CodeEnt.Jerrycan_Wep.VC_AddFuel = function(self, ftype, num)
    local old = self.VC_FuelType or 0
    self.VC_FuelType = ftype or 0
    if old ~= self.VC_FuelType then VC.CodeEnt.Jerrycan_Wep.Deploy(self) end
    self.VC_FuelAmount = (self.VC_FuelAmount or 0) + (num or 0)
    SetFuel(self, ftype, num)
end

VC.CodeEnt.Jerrycan_Wep.Think = function(self)
    if not IsValid(self:GetOwner()) then return end
    if self.VC_TBNIA and CurTime() >= self.VC_TBNIA then
        self:SendWeaponAnim(ACT_VM_IDLE)
        self.VC_TBNIA = nil
    end

    if not vcmod1 then return end
    if not IsValid(self.VC_AimEntity) then
        if self.VC_SoundActive:IsPlaying() then self.VC_SoundActive:FadeOut(0.2) end
        self.VC_AimEntity = nil
        self:SetNWEntity("VC_AimEntity", self)
    end

    local ent = self.VC_AimEntity
    if ent then
        if (self:GetOwner():KeyDown(IN_ATTACK) or self:GetOwner():KeyDown(IN_ATTACK2) and self:GetOwner():IsAdmin()) and (not self.VC_TBNIA or CurTime() >= self.VC_TBNIA) then
            if not self.VC_DoingIt then
                self.VC_StartTime = CurTime()
                self.VC_DoingIt = true
            end

            if CurTime() >= (self.VC_StartTime + 0.5) then
                local amount = 0.01 * VC.getSetting("Refuel_Mult_Hand", 1)
                self.VC_FuelAmount = math.Clamp(self.VC_FuelAmount - amount, 0, self.VC_FuelAmount)
                self:SetNWInt("VC_FuelAmount", self.VC_FuelAmount)
                if not self.VC_SoundActive:IsPlaying() then self.VC_SoundActive:Play() end
                if VC.Refuel then VC.Refuel(ent, amount) end
                if IsValid(self:GetOwner()) and self.VC_FuelAmount <= 0 then
                    VCPopup(self:GetOwner(), "OutOfFuel", "cross")
                    self.VC_AimEntity = nil
                    self:SetNWEntity("VC_AimEntity", self)
                end
            end
        elseif self.VC_DoingIt then
            if self.VC_SoundActive:IsPlaying() then self.VC_SoundActive:FadeOut(0.2) end
            self.VC_DoingIt = nil
        end
    elseif self.VC_DoingIt then
        if self.VC_SoundActive:IsPlaying() then self.VC_SoundActive:FadeOut(0.2) end
        self.VC_DoingIt = nil
    end

    if not self.VC_NextScanTime or CurTime() >= self.VC_NextScanTime then
        local tr = self.Owner:GetEyeTraceNoCursor()
        local ent, ShootPos, AimVector = tr.Entity, self:GetOwner():GetShootPos(), self:GetOwner():GetAimVector()
        if IsValid(ent) and VC.canRefuel(ent, ent.VC_FuelType or 0, self.VC_FuelType or 0) and (not ent.VC_Fuel_Refueler or ent.VC_Fuel_Refueler == self.Owner or not ent.VC_Fuel_Refuel_Time or CurTime() >= ent.VC_Fuel_Refuel_Time) and ent:LocalToWorld(ent.VC_FuelLidPos):Distance(ShootPos) <= 75 and ent:IsVehicle() then
            ent.VC_ForceOpenFuelLidTime = CurTime() + 1.5
            if ent.VC_FuelLidPos and (self.VC_FuelAmount or 0) > 0 and not IsValid(ent.VC_Weld_FNozzle) then
                self.VC_AimEntity = ent
                self:SetNWEntity("VC_AimEntity", ent)
            elseif self.VC_AimEntity then
                self.VC_AimEntity = nil
                self:SetNWEntity("VC_AimEntity", self)
            end
        elseif self.VC_AimEntity then
            self.VC_AimEntity = nil
            self:SetNWEntity("VC_AimEntity", self)
        end

        self.VC_NextScanTime = CurTime() + (self.VC_AimEntity and 0.2 or 1)
    end

    if self.VC_SoundActive:IsPlaying() then self.VC_SoundActive:ChangePitch(110 - ((self.VC_FuelAmount or 0) / 20) * 40) end
end

VC.Versions.vcmod1 = 1.7892
VCMod1 = VC.Versions.vcmod1
vcmod1 = VC.Versions.vcmod1
VC.AU_CanFuel = true or VC_AU_Ver and VC_AU_Ver_Online and VC_AU_Ver >= 7

VC.StateAdd("RunningLightsOn", "Running", "RunningLightsOn", "RunningLightsOff")
function VC.RunningLightsOn(ent, silent, caller)
    if not VC.getServerSetting("Enabled") or not VC.getSetting("Enabled") then return end
    if VC.getServerSetting("Lights_Running") and not VC.GetState(ent, "RunningLightsOn") and VC_fremmann777obosr(ent).LightTable and VC_fremmann777obosr(ent).LightTable.Running then
        if hook.Call("VC_canToggleLights", GAMEMODE, ent, "running", false) == false then return end
        local snd = nil
        if not silent then snd = {"c"} end
        VC.SetStateBool(ent, "RunningLightsOn", true, nil, caller, nil, snd)
        if VC.IndicationCheck then VC.IndicationCheck(ent, "lights_running", true) end
        return true
    end
end

function VC.RunningLightsOff(ent, silent, caller)
    if VC.GetState(ent, "RunningLightsOn") then
        if hook.Call("VC_canToggleLights", GAMEMODE, ent, "running", true) == false then return end
        local snd = nil
        if not silent then snd = {"c"} end
        VC.SetStateBool(ent, "RunningLightsOn", false, nil, caller, nil, snd)
        if VC.IndicationCheck then VC.IndicationCheck(ent, "lights_running", false) end
        return true
    end
end

VC.StateAdd("LowBeamsOn", "LBeam", "LowBeamsOn", "LowBeamsOff")
function VC.LowBeamsOn(ent, silent, caller)
    if not VC.getServerSetting("Enabled") or not VC.getSetting("Enabled") then return end
    if VC.getServerSetting("HeadLights") and not VC.GetState(ent, "LowBeamsOn") and VC_fremmann777obosr(ent).LightTable and VC_fremmann777obosr(ent).LightTable.LBeam then
        if hook.Call("VC_canToggleLights", GAMEMODE, ent, "lowbeam", false) == false then return end
        local snd = nil
        if not silent then snd = {"c"} end
        VC.SetStateBool(ent, "LowBeamsOn", true, nil, caller, nil, snd)
        if VC.IndicationCheck then VC.IndicationCheck(ent, "lights_lowbeams", true) end
        return true
    end
end

function VC.LowBeamsOff(ent, silent, caller)
    if VC.GetState(ent, "LowBeamsOn") then
        if hook.Call("VC_canToggleLights", GAMEMODE, ent, "lowbeam", true) == false then return end
        local snd = nil
        if not silent then snd = {"c"} end
        VC.SetStateBool(ent, "LowBeamsOn", false, nil, caller, nil, snd)
        if VC.IndicationCheck then VC.IndicationCheck(ent, "lights_lowbeams", false) end
        return true
    end
end

VC.StateAdd("HighBeamsOn", "HBeam", "HighBeamsOn", "HighBeamsOff")
function VC.HighBeamsOn(ent, silent, caller)
    if not VC.getServerSetting("Enabled") or not VC.getSetting("Enabled") then return end
    if VC.getServerSetting("HeadLights") and not VC.GetState(ent, "HighBeamsOn") and VC_fremmann777obosr(ent).LightTable and VC_fremmann777obosr(ent).LightTable.HBeam then
        if hook.Call("VC_canToggleLights", GAMEMODE, ent, "highbeam", false) == false then return end
        local snd = nil
        if not silent then snd = {"c"} end
        VC.SetStateBool(ent, "HighBeamsOn", true, nil, caller, nil, snd)
        if VC.IndicationCheck then VC.IndicationCheck(ent, "lights_highbeams", true) end
        return true
    end
end

function VC.HighBeamsOff(ent, silent, caller)
    if VC.GetState(ent, "HighBeamsOn") then
        if hook.Call("VC_canToggleLights", GAMEMODE, ent, "highbeam", true) == false then return end
        local snd = nil
        if not silent then snd = {"c"} end
        VC.SetStateBool(ent, "HighBeamsOn", false, nil, caller, nil, snd)
        if VC.IndicationCheck then VC.IndicationCheck(ent, "lights_highbeams", false) end
        return true
    end
end

VC.StateAdd("FogLightsOn", "Fog", "FogLightsOn", "FogLightsOff")
function VC.FogLightsOn(ent, silent, caller)
    if not VC.getServerSetting("Enabled") or not VC.getSetting("Enabled") then return end
    if VC.getServerSetting("FogLights") and not VC.GetState(ent, "FogLightsOn") and VC_fremmann777obosr(ent).LightTable and VC_fremmann777obosr(ent).LightTable.Fog then
        if hook.Call("VC_canToggleLights", GAMEMODE, ent, "fog", false) == false then return end
        local snd = nil
        if not silent then snd = {"c"} end
        VC.SetStateBool(ent, "FogLightsOn", true, nil, caller, nil, snd)
        if VC.IndicationCheck then VC.IndicationCheck(ent, "lights_fog", true) end
        return true
    end
end

function VC.FogLightsOff(ent, silent, caller)
    if VC.GetState(ent, "FogLightsOn") then
        if hook.Call("VC_canToggleLights", GAMEMODE, ent, "fog", true) == false then return end
        local snd = nil
        if not silent then snd = {"c"} end
        VC.SetStateBool(ent, "FogLightsOn", false, nil, caller, nil, snd)
        if VC.IndicationCheck then VC.IndicationCheck(ent, "lights_fog", false) end
        return true
    end
end

VC.StateAdd("HazardLightsOn", "Hazards", "HazardLightsOn", "HazardLightsOff")
function VC.HazardLightsOn(ent, silent, caller)
    if not VC.getServerSetting("Enabled") or not VC.getSetting("Enabled") then return end
    if not VC.GetState(ent, "HazardLightsOn") and VC_fremmann777obosr(ent).LightTable and VC_fremmann777obosr(ent).LightTable.Blinker then
        if hook.Call("VC_canToggleLights", GAMEMODE, ent, "hazards", false) == false then return end
        ent.VC_TrnLOnT = nil
        ent.VC_TrnLOffT = 0
        ent.VC_TrnROnT = nil
        ent.VC_TrnROffT = 0
        ent.VC_HazardLightsOnT = 0
        ent.VC_HazLOffT = 0
        local snd = nil
        if not silent then snd = {"c"} end
        VC.SetStateBool(ent, "HazardLightsOn", true, nil, caller, nil, snd)
        if VC.IndicationCheck then VC.IndicationCheck(ent, "lights_hazard", true) end
        return true
    end
end

function VC.HazardLightsOff(ent, silent, caller)
    if VC.GetState(ent, "HazardLightsOn") then
        if hook.Call("VC_canToggleLights", GAMEMODE, ent, "hazards", true) == false then return end
        local snd = nil
        if not silent then snd = {"c"} end
        VC.SetStateBool(ent, "HazardLightsOn", false, nil, caller, nil, snd)
        if VC.IndicationCheck then VC.IndicationCheck(ent, "lights_hazard", false) end
        return true
    end
end

VC.StateAdd("TurnLightLeftOn", "BlinkerLeft", "TurnLightLeftOn", "TurnLightLeftOff")
function VC.TurnLightLeftOn(ent, silent, caller)
    if not VC.getServerSetting("Enabled") or not VC.getSetting("Enabled") then return end
    if not VC.GetState(ent, "TurnLightLeftOn") and VC_fremmann777obosr(ent).LightTable and VC_fremmann777obosr(ent).LightTable.Blinker then
        if hook.Call("VC_canToggleLights", GAMEMODE, ent, "blinkers_left", false) == false then return end
        ent.VC_TrnLOnT = 0
        ent.VC_TrnLOffT = 0
        local snd = nil
        if not silent then snd = {VC.GetState(ent, "TurnLightRightOn") and "vcmod/switch.wav" or "vcmod/switch_on.wav"} end
        VC.TurnLightRightOff(ent, true)
        VC.SetStateBool(ent, "TurnLightLeftOn", true, nil, caller, nil, snd)
        if VC.IndicationCheck then VC.IndicationCheck(ent, "blinkers_left", true) end
        return true
    end
end

function VC.TurnLightLeftOff(ent, silent, caller)
    if VC.GetState(ent, "TurnLightLeftOn") then
        if hook.Call("VC_canToggleLights", GAMEMODE, ent, "blinkers_left", true) == false then return end
        local snd = nil
        if not silent then snd = {"vcmod/switch_off.wav"} end
        VC.SetStateBool(ent, "TurnLightLeftOn", false, nil, caller, nil, snd)
        if VC.IndicationCheck then VC.IndicationCheck(ent, "blinkers_left", false) end
        return true
    end
end

VC.StateAdd("TurnLightRightOn", "BlinkerRight", "TurnLightRightOn", "TurnLightRightOff")
function VC.TurnLightRightOn(ent, silent, caller)
    if not VC.getServerSetting("Enabled") or not VC.getSetting("Enabled") then return end
    if not VC.GetState(ent, "TurnLightRightOn") and VC_fremmann777obosr(ent).LightTable and VC_fremmann777obosr(ent).LightTable.Blinker then
        if hook.Call("VC_canToggleLights", GAMEMODE, ent, "blinkers_right", false) == false then return end
        ent.VC_TrnLOnT = 0
        ent.VC_TrnLOffT = 0
        local snd = nil
        if not silent then snd = {VC.GetState(ent, "TurnLightLeftOn") and "vcmod/switch.wav" or "vcmod/switch_on.wav"} end
        VC.TurnLightLeftOff(ent, true)
        VC.SetStateBool(ent, "TurnLightRightOn", true, nil, caller, nil, snd)
        if VC.IndicationCheck then VC.IndicationCheck(ent, "blinkers_right", true) end
        return true
    end
end

function VC.TurnLightRightOff(ent, silent, caller)
    if VC.GetState(ent, "TurnLightRightOn") then
        if hook.Call("VC_canToggleLights", GAMEMODE, ent, "blinkers_right", true) == false then return end
        local snd = nil
        if not silent then snd = {"vcmod/switch_off.wav"} end
        VC.SetStateBool(ent, "TurnLightRightOn", false, nil, caller, nil, snd)
        if VC.IndicationCheck then VC.IndicationCheck(ent, "blinkers_right", false) end
        return true
    end
end

VC.StateAdd("CruiseOn", "Cruiser", "CruiseOn", "CruiseOff")
function VC.CruiseOn(ent, silent, caller)
    if not VC.getServerSetting("Enabled") or not VC.getSetting("Enabled") then return end
    if hook.Call("VC_canUseCruiseControl", GAMEMODE, caller, ent) == false then return end
    if VC.ElectronicsOn(ent) and not VC.GetState(ent, "CruiseOn") and ent.VC_IsNotPrisonerPod and VC.getServerSetting("Cruise_Enabled") then
        ent.VC_CruiseVel = ent.VC_Speed_Forward or 0
        if ent.VC_CruiseVel < 50 then ent.VC_CruiseVel = 50 end
        ent:SetNWInt("VC_Cruise_Spd", ent.VC_CruiseVel)
        local snd = nil
        if not silent then snd = {"c"} end
        VC.SetStateBool(ent, "CruiseOn", true, nil, caller, nil, snd)
        if VC.IndicationCheck then VC.IndicationCheck(ent, "cruise", true) end
        return true
    end
end

function VC.CruiseOff(ent, silent, caller)
    if VC.GetState(ent, "CruiseOn") then
        ent.VC_CruiseVel = nil
        ent:SetNWInt("VC_Cruise_Spd", 0)
        local snd = nil
        if not silent then snd = {"c"} end
        VC.SetStateBool(ent, "CruiseOn", false, nil, caller, nil, snd)
        if VC.IndicationCheck then VC.IndicationCheck(ent, "cruise", false) end
        return true
    end
end

function VC.HeadLightsOn(ent, silent, caller)
    VC.LowBeamsOn(ent, silent, caller)
end

function VC.HeadLightsOff(ent, silent, caller)
    VC.LowBeamsOff(ent, silent, caller)
    VC.HighBeamsOff(ent, silent, caller)
end

function VC.HL_HighBeam_On(ent, silent, caller)
    VC.HighBeamsOn(ent, silent, caller)
end

function VC.HL_HighBeam_Off(ent, silent, caller)
    VC.HighBeamsOff(ent, silent, caller)
end

local data = {
    cmd = "vc_hazards_onoff",
    menu = "controls",
    keyhold = true,
    info = "HazardLights",
    default = {
        key = "MOUSE_MIDDLE",
        hold = "0",
        mouse = "1"
    }
}

VC.controlInsert(data)
local data = {
    cmd = "vc_blinker_left",
    menu = "controls",
    keyhold = true,
    info = "BlinkerLeft",
    default = {
        key = "MOUSE_LEFT",
        hold = "0",
        mouse = "1"
    }
}

VC.controlInsert(data)
local data = {
    cmd = "vc_blinker_right",
    menu = "controls",
    keyhold = true,
    info = "BlinkerRight",
    default = {
        key = "MOUSE_RIGHT",
        hold = "0",
        mouse = "1"
    }
}

VC.controlInsert(data)
local data = {
    cmd = "vc_lights_switch",
    menu = "controls",
    info = "LightsSwitch",
    default = {
        key = "KEY_F",
        hold = "0"
    }
}

VC.controlInsert(data)
local data = {
    cmd = "vc_foglights_onoff",
    menu = "controls",
    keyhold = true,
    info = "FogLights",
    default = {
        key = "KEY_F",
        hold = "0"
    }
}

VC.controlInsert(data)
local data = {
    cmd = "vc_highbeams_toggle",
    menu = "controls",
    keyhold = false,
    info = "HighBeams",
    default = {
        key = "KEY_F",
        hold = "1"
    }
}

VC.controlInsert(data)
local data = {
    cmd = "vc_highbeams",
    menu = "controls",
    NoCheckBox = true,
    carg1 = "1",
    carg2 = "2",
    info = "HighBeamsFlash",
    default = {
        key = "KEY_H",
        hold = "1"
    }
}

VC.controlInsert(data)
local data = {
    cmd = "vc_cruise_onoff",
    menu = "controls",
    info = "Cruise",
    default = {
        key = "KEY_B",
        hold = "0"
    }
}

VC.controlInsert(data)
local data = {
    cmd = "vc_trailer_detach",
    menu = "controls",
    info = "DetachTrailer",
    default = {
        key = "KEY_B",
        hold = "1"
    }
}

VC.controlInsert(data)
local data = {
    cmd = "vc_viewlookbehind",
    menu = "controls",
    NoCheckBox = true,
    carg1 = "1",
    carg2 = "2",
    info = "LookBehind",
    default = {
        key = "MOUSE_MIDDLE",
        hold = "1",
        mouse = "1"
    },
    desk = "Look behind the vehicle."
}

VC.controlInsert(data)
local data = {
    cmd = "vc_inside_doors_onoff",
    menu = "controls",
    info = "LockUnlock",
    keyhold = true,
    default = {
        key = "KEY_N",
        hold = "0"
    },
    desk = "Lock the vehicle from within."
}

VC.controlInsert(data)
local data = {
    cmd = "vc_drivebymode_toggle",
    menu = "controls",
    info = "DriveBy",
    default = {
        key = "KEY_SPACE",
        hold = "0"
    },
    desk = "Toggle drive by shooting mode from passenger seats."
}

VC.controlInsert(data)
function VC.isFuelConsumptionEnabled(ent)
    return not ent:GetNWBool("VC_FuelDisabled", false)
end

function VC.isTrailer(ent)
    return ent.VC_isTrailer
end

function VC.isTrailerSupported(ent)
    return VC_fremmann777obosr(ent).UseSocket and VC_fremmann777obosr(ent).SocketPos
end

function VC.getTrailer(ent)
    local ret = nil
    local time = nil
    local trailer = SERVER and ent.VC_HookVeh or ent:GetNWEntity("VC_HookedVh")
    if IsValid(trailer) then
        ret = trailer
        time = SERVER and trailer.VC_HookedVhAtcT or trailer:GetNWInt("VC_HookedVhAtcT") or 0
    end

    if not IsValid(ret) then
        ret = nil
        time = nil
    end
    return ret, time
end

function VC.getAttachedTo(ent)
    local ret = nil
    local time = nil
    local trailer = SERVER and ent.VC_SocketVeh or ent:GetNWEntity("VC_SocketVeh")
    if IsValid(trailer) then
        ret = trailer
        time = SERVER and ent.VC_HookedVhAtcT or ent:GetNWInt("VC_HookedVhAtcT") or 0
    end

    if not IsValid(ret) then
        ret = nil
        time = nil
    end
    return ret, time
end

function VC.CD_getInfo(ent)
    if ent:GetClass() == "vc_npc_cardealer" then
        local name = ent:GetNWString("VC_Name", VC.CD.Default.Name)
        local model = ent:GetModel()
        local id = ent:GetNWInt("VC_Int", 0)
        local data = ent.VC_Options or {}
        return id, name, model, data
    end
end

function VC.RM_getInfo(ent)
    if ent:GetClass() == "vc_npc_repair" then
        local name = ent:GetNWString("VC_Name", VC.CD.Default.Name)
        local model = ent:GetModel()
        local id = ent:GetNWInt("VC_Int", 0)
        local data = ent.VC_Options or {}
        return id, name, model, data
    end
end

function VC.getCruise(ent)
    local ret = nil
    if VC.GetState(ent, "CruiseOn") then ret = ent:GetNWInt("VC_Cruise_Spd", 0) end
    return ret
end

VC.DriveByRestrictedWeapons = {"vc_wrench", "vc_jerrycan", "vc_spikestrip_wep", "weapon_crossbow", "weapon_frag", "weapon_slam", "weapon_physcannon", "weapon_rpg", "weapon_crowbar", "weapon_gravgun", "weapon_physgun", "weapon_bugbait", "door_ram", "weapon_stunstick", "gmod_tool"}
VC.FuelTypes = {
    [0] = {
        name = "Petrol",
        shrt = "95",
        mult = 0,
        clr = Color(25, 155, 45, 250),
        mdl = "models/props_junk/metalgascan.mdl"
    },
    [1] = {
        name = "Diesel",
        shrt = "D",
        mult = 0.77,
        clr = Color(55, 100, 255, 250),
        mdl = "models/props_junk/gascan001a.mdl"
    },
    [2] = {
        name = "Electricity",
        shrt = "Elec",
        mult = 0.2,
        clr = Color(55, 200, 55, 250),
        mdl = "models/items/car_battery01.mdl"
    },
}

if CLIENT then
    function VC.GetPartIcon(obj)
        local icon = nil
        if obj == "engine" then
            icon = VC.Material.icon_engine
        elseif obj == "light" then
            icon = VC.Material.icon_running
        elseif obj == "light_els" then
            icon = VC.Material.icon_els
        elseif obj == "wheel" then
            icon = VC.Material.icon_wheel
        elseif obj == "exhaust" then
            icon = VC.Material.icon_exhaust
        end
        return icon
    end
end

function VC.GetPartInfo(obj, byHand)
    local datatbl = VC.Settings
    if CLIENT then datatbl = VC.ServerSettings end
    local repMult = byHand and datatbl.Damage_Repair_TimeMult or datatbl.RM_RepairSpeedMult or 1
    local info = {
        price = 0,
        time = 0
    }

    if obj == "engine" then
        info.price = datatbl.RM_Price_Engine or 500
        info.time = 75 * repMult
    elseif obj == "light" then
        info.price = datatbl.RM_Price_Light or 10
        info.time = 10 * repMult
    elseif obj == "light_els" then
        info.price = datatbl.RM_Price_Light or 10
        info.time = 10 * repMult
    elseif obj == "wheel" then
        info.price = datatbl.RM_Price_Tire or 20
        info.time = 5 * repMult
    elseif obj == "exhaust" then
        info.price = datatbl.RM_Price_Exhaust or 50
        info.time = 15 * repMult
    end
    return info
end

VC.CD.Default = {
    Model = "models/barney.mdl",
    Name = "Car Dealer",
    Pos = Vector(0, 0, 0),
    Ang = Angle(0, 0, 0),
    Platforms = {},
    Vehicles = {}
}

VC.RM.Default = {
    Model = "models/barney.mdl",
    Name = "Vehicle Repair Man",
    Pos = Vector(0, 0, 0),
    Ang = Angle(0, 0, 0)
}

function VC.CD.GetDataFromName(ID)
    local tbl = string.Explode("$$$_VC_$$$", ID)
    return {
        Model = tbl[1],
        Name = tbl[2],
        Skin = tbl[2]
    }
end

function VC.CD.getName(mdl, nm, skin)
    return (mdl or "") .. "$$$_VC_$$$" .. (nm or "Unknown") .. "$$$_VC_$$$" .. (skin or "0")
end

function VC.CD.getVehicleDataFromID(ID)
    local data = VC.CD.GetDataFromName(ID)
    return data.Model or "", data.Model or "Unknown", data.Skin or "0"
end

local function getLightPos(ent, int)
    local pos = Vector(0, 0, 0)
    local OD = VC_fremmann777obosr(ent)
    if SERVER then
        if OD.Lights and OD.Lights[int] then pos = VC_fremmannobosrimen(ent, OD.Lights[int]) end
    else
        pos = OD.LPT and OD.LPT[int] and OD.LPT[int].Pos
    end
    return pos or Vector(0, 0, 0)
end

local function getExhaustPos(ent, int)
    local pos = nil
    local OD = VC_fremmann777obosr(ent)
    if SERVER then
        pos = OD[int] and OD.Exhaust[int].Pos
    else
        pos = OD.Exhaust and OD.Exhaust[int] and OD.Exhaust[int].Pos
    end
    return pos or Vector(0, 0, 0)
end

function VC.GetWheelPos(ent, int)
    local pos = ent:GetPos()
    local has = nil
    if type(int) == "number" then int = VC.Wheels[int] end
    local atc = ent:LookupAttachment(int)
    if atc ~= 0 then
        has = true
        pos = ent:GetAttachment(atc).Pos
    end
    return pos, has
end

function VC.GetObjectPos(ent, part, int, kkl)
    if not kkl or kkl ~= 137 then return end
    local pos = Vector(0, 0, 0)
    if part == "engine" then
        pos = ent:WorldToLocal(VC.getEnginePos(ent))
    elseif part == "wheel" then
        pos = ent:WorldToLocal(VC.GetWheelPos(ent, int))
    elseif part == "light" then
        pos = getLightPos(ent, int)
    elseif part == "exhaust" then
        pos = getExhaustPos(ent, int)
    end
    return pos or Vector(0, 0, 0)
end

local function CheckTables(tbl, job, rank)
    local restjob, restrank = tbl and tbl.JobRestrict and job and tbl.JobRestrict[job], tbl and tbl.RankRestrict and rank and tbl.RankRestrict[rank]
    if restjob then
        return "job"
    elseif restrank then
        return "rank"
    end
end

function VC.isPlayerRestricted(ply, tbl_veh, tbl_npc, dontprint)
    local rank = ply:GetUserGroup()
    local JobName = ply.getJobTable and ply:getJobTable() and ply:getJobTable().name or "Unknown"
    local isRestrictedVeh, isRestrictedNPC = CheckTables(tbl_veh, JobName, rank), CheckTables(tbl_npc, JobName, rank)
    local isRestricted = nil
    if isRestrictedNPC then
        isRestricted = {
            type = "npc",
            restriction = isRestrictedNPC
        }
    elseif isRestrictedVeh then
        isRestricted = {
            type = "veh",
            restriction = isRestrictedVeh
        }
    end

    if isRestricted and not dontprint then
        if SERVER then
            VCMsg("Access restricted", ply)
        else
            VCPopup(VC.Lng("AccessRestricted") .. " " .. (isRestricted.type == "npc" and VC.Lng("CantBeUsedBy") or VC.Lng("CantBeSpawnedBy")) .. (isRestricted.restriction == "rank" and (' "' .. rank .. '"') or ' "' .. JobName .. '"') .. ".", "cross", 8)
        end
    end
    return isRestricted
end

function VC.CD.GetSpawnPosAng(ply, tbl, ent)
    local pos, ang = nil, nil
    if tbl.Platforms and table.Count(tbl.Platforms) > 0 then
        for k, v in pairs(tbl.Platforms) do
            local ar, af, au = v.Ang:Right() * 142, v.Ang:Forward() * 71, v.Ang:Up() * 50
            if not util.TraceLine({
                start = v.Pos + ar + af,
                endpos = v.Pos - ar - af + au
            }).Hit and not util.TraceLine({
                start = v.Pos - ar + af + au,
                endpos = v.Pos + ar - af
            }).Hit then
                pos = v.Pos + Vector(0, 0, 10)
                ang = v.Ang
                break
            end
        end
    else
        local tang = (ply:GetPos() - ent:GetPos()):Angle()
        tang.p = 0
        pos = ent:GetPos() + Vector(0, 0, 10) - tang:Right() * 150
        ang = tang - Angle(0, 90, 0)
    end
    return pos, ang
end

function VC.CD.getVehicleIDFromData(mdl, name, skin)
    return VC.CD.getName(mdl, name, skin)
end

function VC.CD.getVehicleID(ent)
    local mdl, name, skin = VC.GetModel(ent), VC.getName(ent, "Unknown"), ent:GetSkin()
    return VC.CD.getName(mdl, name, skin)
end

game.AddParticles("particles/vc_explosion.pcf")
game.AddParticles("particles/vc_damage.pcf")
game.AddParticles("particles/vc_surface.pcf")
game.AddParticles("particles/vc_exhaust.pcf")
PrecacheParticleSystem("VC_WheelSparks")
PrecacheParticleSystem("VC_Wheel_Fix")
PrecacheParticleSystem("VC_WheelDust")
PrecacheParticleSystem("VC_Wheel_Deflate")
PrecacheParticleSystem("VC_WheelSmoke_Asphalt")
PrecacheParticleSystem("VC_Wheelsmoke_Dirt_Burnout_Debris")
PrecacheParticleSystem("VC_WheelSmoke_Sand_2")
PrecacheParticleSystem("VC_Wheelsmoke_BurnoutLeft")
PrecacheParticleSystem("VC_Wheelsmoke_Dirt_Burnout")
PrecacheParticleSystem("VC_WheelSmoke_Sand")
PrecacheParticleSystem("VC_BackFire")
PrecacheParticleSystem("VC_BackFire_Sparks")
PrecacheParticleSystem("VC_Crash")
PrecacheParticleSystem("VC_Crash_Sparks")
PrecacheParticleSystem("VC_Crash_Sparklies")
PrecacheParticleSystem("VC_Engine_Fire")
PrecacheParticleSystem("VC_Engine_Smoke")
PrecacheParticleSystem("VC_Engine_Fire_Sparks_B")
PrecacheParticleSystem("Car_Explosion")
PrecacheParticleSystem("VC_Glass_Fix")
PrecacheParticleSystem("VC_Glass_Light")
PrecacheParticleSystem("VC_Exhaust")
PrecacheParticleSystem("VC_Exhaust_Stress")
PrecacheParticleSystem("VC_Exhaust_Truck")
PrecacheParticleSystem("VC_Exhaust_Truck_Stress")
local dir = "vcmod/collision/spring/"
for k, v in pairs(file.Find("sound/" .. dir .. "*", "GAME")) do
    util.PrecacheSound("sound/" .. dir .. v)
end

local dir = "vcmod/collision/light/"
for k, v in pairs(file.Find("sound/" .. dir .. "*", "GAME")) do
    util.PrecacheSound("sound/" .. dir .. v)
end

local dir = "vcmod/collision/medium/"
for k, v in pairs(file.Find("sound/" .. dir .. "*", "GAME")) do
    util.PrecacheSound("sound/" .. dir .. v)
end

local dir = "vcmod/collision/heavy/"
for k, v in pairs(file.Find("sound/" .. dir .. "*", "GAME")) do
    util.PrecacheSound("sound/" .. dir .. v)
end

local settings = {
    Wheel_Lock = true,
    Brake_Lock = true,
    Door_Sounds = true,
    Truck_BackUp_Sounds = true,
    Exit_Velocity = true,
    Exit_Velocity_Damage = true,
    Exit_NoCollision = true,
    Exhaust_Effect = true,
    Exhaust_Effect_BackFireHealthLow = true,
    Passenger_Seats = true,
    ExitPoint_OverrideDriver = true,
    Seat_Switch = true,
    Lock_From_Inside = true,
    DriveBy = true,
    DriveBy_NoSwitch = false,
    RepairTool_Speed_M = 1,
    Lights_Running = true,
    Lights_HandBrake = false,
    Lights_Interior = true,
    Lights_Blinker_OffOnExit = false,
    HeadLights = true,
    LightsOffTime = 300,
    HLightsOffTime = 60,
    HLights_Dist_M = 0.5,
    FogLights = true,
    FogLightsOffTime = 30,
    FogLights_Dist_M = 0.5,
    Cruise_Enabled = true,
    Cruise_OffOnExit = true,
    UnlockVehicleOnSpawnerUsePostLock = true,
    CD_Enabled = true,
    CD_ReturnLimitByDistance = true,
    CD_ReturnLimitByDistanceDist = 1000,
    CD_EnterVehicleOnSpawn = false,
    CD_AutoReturnOnDisconnect = false,
    CD_TowingTooFar = false,
    CD_TowingTooFar_Distance = 1500,
    CD_Towing = true,
    CD_OnlyAllowOne = false,
    CD_TowingPrice = 1500,
    CD_Distance = 1500,
    CD_RefundPrice = 75,
    CD_Remove = true,
    CD_Remove_Time = 1000,
    CD_Veh_RemTool = false,
    CD_Hum = true,
    CD_Persistent = true,
    CD_StoreInfo = true,
    CD_TestDrive = true,
    CD_TestDriveTime = 30,
    CD_Text_Dist = 500,
    CD_UnlockVehicleOnSpawnerUse = true,
    TP_Override = false,
    RM_Enabled = true,
    RM_Text_Dist = 500,
    RM_Persistent = true,
    RM_Hum = true,
    RM_RepairSpeedMult = 1,
    RM_Distance = 350,
    RM_Repair_Time_Cost = 1,
    RM_Price_Engine = 500,
    RM_Price_Light = 10,
    RM_Price_Tire = 20,
    RM_Price_Exhaust = 50,
    Fuel = true,
    Fuel_Pickup_Touch = false,
    Fuel_Pickup_Touch_Elec = true,
    Fuel_Pickup_Explode = true,
    Fuel_Pickup_Pickup = true,
    Fuel_Persistent = true,
    Fuel_lidNeedUnlocked = true,
    Fuel_Pickups_Beside_Stations = true,
    Fuel_Cons_Mult = 1,
    Refuel_Mult_Station = 1,
    Fuel_StartMult = 1,
    Refuel_MaxCapacity = 100,
    Refuel_Mult_Hand = 1,
    Fuel_PPL_0 = 1.3,
    Fuel_PPL_1 = 1.01,
    Fuel_PPL_2 = 0.29,
    Trl_Enabled = true,
    Trl_Dist = 200,
    Trl_Strength = 1,
    Trl_Enabled_Reg = true,
    TP_Props = true,
    Indication = true,
    Damage = true,
    Damage_Phys_MinVel = 75,
    Sound_Damage_Custom = true,
    Damage_explosion_drain_fuel = true,
    Damage_FuelLid = true,
    Damage_FuelLid_Explode = true,
    Damage_FuelLid_DrainFuel = true,
    Damage_Lights = true,
    Damage_Wheels = true,
    Damage_Wheels_ELSOff = false,
    Damage_Exhaust = true,
    Damage_Exhaust_Backfire = true,
    Damage_Explode = true,
    Damage_CanEnterIfDestroyed = true,
    Damage_Repair_GiveWrenchToDriver = true,
    Damage_Repair_GiveWrenchToCarPartUser = true,
    Damage_Repair_NeedPart = true,
    Damage_Repair_TimeMult = 1,
    Damage_Expl_Rem = true,
    Damage_Ignite = true,
    Damage_Expl_Rem_Time = 400,
    Dmg_Fire_Duration = 30,
    Dmg_Smoke_Duration = 15,
    SpikeStrip_auto_give_els = false,
    SpikeStrip_damage_players = true,
    SpikeStrip_Ignore_ELS = false,
    SpikeStrip_auto_remove_death = true,
    HealthRepairBulletDamage = true,
    PhysicalDamage = true,
    PhysicalDamage_PlyDmgMult = 1,
    PhysicalDamage_PlyDisable = true,
    PhysicalDamageWPhysGun = true,
    OnlyWithPassengers = false,
    PhysicalDamage_Mult = 1,
    Health_Multiplier = 1,
    CarsCantDamagePlayers = false,
    ShootPlayers = true,
    ShootPlayers_Prec_Mult = 1,
    ShootPlayers_OverrideDefault = true,
    Effect_Repair = true,
    Effect_Light = true,
    Effect_Light_Damaged = true,
    Effect_Wheel = true,
    Effect_Exhaust = true,
    Effect_Damage_Sparks = true,
    Effect_Explosion_Custom = true,
    Effect_Exhaust_Custom = true,
    Effect_Slide = true,
    Tiretracks = true,
    Compat_CH_Fire_System = true,
}

VC.SettingsAdd(settings, true)

local function PlayConnectSound(ent, car, pitch)
    VC.SoundEmit(ent, car and "vcmod/car_connect.wav" or "vcmod/truck_connect.wav", pitch, 80)
end

function VC.Trailer_Attach(ent, trk, SkVhAP, HkVhAP)
    PlayConnectSound(ent, not VC_fremmann777obosr(trk).SocketType or VC_fremmann777obosr(trk).SocketType == 2, 100)
    ent:GetPhysicsObject():SetVelocity(trk:GetPhysicsObject():GetVelocity())
    ent.VC_TrlAtchRp = constraint.Rope(ent, trk, 0, 0, ent:WorldToLocal(SkVhAP), trk:WorldToLocal(HkVhAP), 4, 0, ((VC_fremmann777obosr(ent).SocketType or 1) == 2 and 25000 or 50000) * VC.getSetting("Trl_Strength"), 0, "", false)
    if ent.VC_HandBrakeOn and not trk.VC_HandBrakeOn then VC.HandBrakeOff(ent) end
    trk.VC_PATBA = CurTime() + 1
    ent.VC_PATBA = trk.VC_PATBA
    VC.setHookedVeh(trk, ent)
    VC.setSocketVeh(ent, trk)
    if not VC.IsTrailer(trk) then
        VC.SetTruck(ent, trk)
    elseif trk.VC_Truck then
        VC.SetTruck(ent, ent.VC_Truck)
    end

    trk.VC_DSGP = true
    ent.VC_DSGP = true
    if ent.VC_LastCollisionGroup then
        ent:SetCollisionGroup(ent.VC_StartCollisionGroup)
        ent.VC_LastCollisionGroup = nil
    end

    ent.VC_SocketVehCon = nil
    local Prt = IsValid(trk.VC_Truck) and trk.VC_Truck or trk
    if IsValid(Prt:GetDriver()) then VCPopup(Prt:GetDriver(), "Trl_Atch") end
    hook.Call("VC_TrailerAttached", GAMEMODE, trk, ent, ent.VC_TrlAtchRp)
    hook.Call("VC_trailerAttached", GAMEMODE, trk, ent, ent.VC_TrlAtchRp)
    VC.IndicationCheck(trk, "trailer", true)
end

function VC.Trailer_Detach(ent)
    if IsValid(ent.VC_HookVeh) then
        if hook.Call("VC_canDetachTrailer", GAMEMODE, ent) == false then
            local drv = ent:GetDriver()
            if IsValid(drv) then VCPopup(drv, "AccessRestricted", "cross") end
            return
        end

        for _, HVh in pairs(VC.GetVehicleList()) do
            if HVh.VC_Truck and HVh.VC_Truck == ent and not HVh.VC_HookVeh then
                local vel, avel = HVh:GetPhysicsObject():GetVelocity(), HVh:GetPhysicsObject():GetAngleVelocity()
                if IsValid(HVh.VC_TrlAtchRp) then
                    HVh.VC_TrlAtchRp:Remove()
                    HVh.VC_TrlAtchRp = nil
                end

                PlayConnectSound(HVh, not VC_fremmann777obosr(HVh).HookType or VC_fremmann777obosr(HVh).HookType == 2, math.Rand(90, 95))
                if HVh.VC_HandBrakeOn then VC.HandBrakeOff(HVh) end
                HVh.VC_TrlAtchDl = CurTime() + 1
                if HVh == ent.VC_HookVeh then
                    VC.setHookedVeh(ent)
                    ent.VC_TrlAtchDl = HVh.VC_TrlAtchDl
                else
                    VC.setHookedVeh(HVh.VC_SocketVeh)
                end

                VC.setSocketVeh(HVh)
                VC.SetTruck(HVh)
                HVh.VC_ResetColGrp = HVh:GetCollisionGroup()
                HVh:SetCollisionGroup(COLLISION_GROUP_DEBRIS_TRIGGER)
                if IsValid(ent:GetDriver()) then VCPopup(ent:GetDriver(), "Trl_Detch") end
                hook.Call("VC_TrailerDetached", GAMEMODE, ent, HVh)
                hook.Call("VC_trailerDetached", GAMEMODE, ent, HVh)
                VC.IndicationCheck(ent, "trailer", false)
                break
            end
        end
    end
end

function VC.SetTruck(ent, veh)
    local old = ent.VC_Truck
    if old ~= veh then ent:SetNWEntity("VC_Truck", veh or NULL) end
    ent.VC_Truck = veh
end

function VC.setHookedVeh(ent, veh)
    local valid = IsValid(veh)
    ent.VC_HookVeh = veh
    ent:SetNWEntity("VC_HookedVh", ent.VC_HookVeh or NULL)
    if IsValid(veh) then
        veh.VC_HookedVhAtcT = CurTime()
        ent:SetNWEntity("VC_HookedVhAtcT", veh.VC_HookedVhAtcT)
    end
end

function VC.setSocketVeh(ent, veh)
    local valid = IsValid(veh)
    ent.VC_SocketVeh = veh
    ent:SetNWEntity("VC_SocketVeh", ent.VC_SocketVeh or NULL)
end

function VC.HandleTrailer(ent, EntLN)
    if not VC.getSetting("Trl_Enabled") then return end
    if ent.VC_HookVeh and not IsValid(ent.VC_HookVeh) then VC.setHookedVeh(ent) end
    if ent.VC_ResetColGrp then
        if not ent.VC_TrlAtchDl or CurTime() >= ent.VC_TrlAtchDl then
            ent:SetCollisionGroup(ent.VC_StartCollisionGroup)
            ent.VC_ResetColGrp = nil
            ent.VC_TrlAtchDl = CurTime() + 2
            ent.VC_DSGP = true
        end

        ent:GetPhysicsObject():SetVelocity(ent.VC_ResetColGrp and (ent:GetPhysicsObject():GetVelocity() + ent:GetForward() * -4) or Vector(0, 0, 0))
    end

    if not VC.TrlAtchT or CurTime() >= VC.TrlAtchT then
        if (not ent.VC_TrlAtchDl or CurTime() >= ent.VC_TrlAtchDl) and not ent.VC_HookVeh and VC_fremmann777obosr(ent).UseSocket and VC_fremmann777obosr(ent).SocketPos and not VC.isHeld(ent) then
            for _, HkVh in pairs(VC.GetVehicleList()) do
                if VC.IsTrailer(HkVh) and not HkVh.VC_SocketVeh and ent ~= HkVh and not HkVh.VC_SocketVehCon and VC_fremmann777obosr(HkVh) and (VC_fremmann777obosr(ent).SocketType or 1) == (VC_fremmann777obosr(HkVh).HookType or 1) and VC_fremmann777obosr(HkVh).UseHook and not VC.isHeld(HkVh) and (not HkVh.VC_TrlAtchDl or CurTime() >= HkVh.VC_TrlAtchDl) and VC.AngleInBounds(90, ent:GetAngles(), HkVh:GetAngles()) then
                    local SkVhAP, HkVhAP = VC.VectorToWorld(ent, VC_fremmann777obosr(ent).SocketPos), VC.VectorToWorld(HkVh, VC_fremmann777obosr(HkVh).HookPos)
                    if IsValid(ent:GetPhysicsObject()) and IsValid(HkVh:GetPhysicsObject()) and SkVhAP:Distance(HkVhAP) <= VC.getSetting("Trl_Dist") and math.abs(ent:GetPhysicsObject():GetVelocity():Length() - HkVh:GetPhysicsObject():GetVelocity():Length()) < 25 and not util.TraceLine({
                        start = HkVhAP,
                        endpos = SkVhAP,
                        filter = {ent, HkVh}
                    }).Hit then
                        HkVh.VC_LastCollisionGroup = HkVh:GetCollisionGroup()
                        HkVh:SetCollisionGroup(COLLISION_GROUP_DEBRIS_TRIGGER)
                        HkVh.VC_SocketVehCon = {ent, CurTime() + 2}
                        HkVh.VC_DSGP = true
                    end
                end
            end
        end

        if EntLN == table.Count(VC.GetVehicleList()) then VC.TrlAtchT = CurTime() + 1 end
    end

    if VC.IsTrailer(ent) then
        if ent.VC_SocketVehCon then
            local SVeh = ent.VC_SocketVehCon[1]
            if IsValid(SVeh) and not IsValid(SVeh.VC_HookVeh) and CurTime() < ent.VC_SocketVehCon[2] then
                if hook.Call("VC_canAttachTrailer", GAMEMODE, ent, SVeh) ~= false then
                    local SkVhAP, HkVhAP = VC.VectorToWorld(ent, VC_fremmann777obosr(ent).HookPos), VC.VectorToWorld(SVeh, VC_fremmann777obosr(SVeh).SocketPos)
                    if SkVhAP:Distance(HkVhAP) > 5 then
                        ent:GetPhysicsObject():SetVelocity(SVeh:GetPhysicsObject():GetVelocity() + (HkVhAP - SkVhAP):GetNormalized() * 300)
                    else
                        VC.Trailer_Attach(ent, SVeh, SkVhAP, HkVhAP)
                    end
                end
            else
                if IsValid(ent.VC_SocketVehCon[3]) then ent.VC_SocketVehCon[3]:Remove() end
                ent.VC_SocketVehCon = nil
                if ent.VC_LastCollisionGroup then
                    ent.VC_LastCollisionGroup = nil
                    ent:SetCollisionGroup(ent.VC_StartCollisionGroup)
                end
            end
        end

        if ent.VC_SocketVeh then
            if IsValid(ent.VC_SocketVeh) then
                VC.SetTruck(ent, not VC.IsTrailer(ent.VC_SocketVeh) and ent.VC_SocketVeh or ent.VC_SocketVeh.VC_Truck)
                if (not ent.VC_PATBA or CurTime() >= ent.VC_PATBA) and not ent.VC_TrlAtchRp or not IsValid(ent.VC_TrlAtchRp) then
                    ent.VC_TrlAtchRp = nil
                    ent.VC_TrlAtchDl = CurTime() + 5
                    ent.VC_SocketVeh.VC_TrlAtchDl = ent.VC_TrlAtchDl
                    VC.setHookedVeh(ent.VC_SocketVeh)
                    VC.setSocketVeh(ent)
                    VC.SetTruck(ent)
                end
            else
                VC.setSocketVeh(ent)
            end
        end

        if ent.VC_HookVeh and not IsValid(ent.VC_HookVeh) then VC.setHookedVeh(ent) end
        if ent.VC_Truck and not IsValid(ent.VC_Truck) then VC.SetTruck(ent) end
    end
end

function VC.setVehiclePersistanceData(ent, data)
    VC_fremmanngonvzhuy(ent, false)
    if data then
        if data.Health then
            if data.Health <= 0 then ent.VC_Destroyed = CurTime() + VC.getSetting("Damage_Expl_Rem_Time") end
            VC.SetHealth(ent, Lerp(data.Health / 100, 0, ent.VC_MaxHealth))
        end

        if data.Fuel then VC.setFuel(ent, Lerp(data.Fuel / 100, 0, ent.VC_MaxFuel)) end
        if data.DamagedObjects then VC.SetDamagedObjects(ent, data.DamagedObjects) end
    end
end

function VC.getVehiclePersistanceData(ent)
    local data = {}
    if ent.VC_Fuel and ent.VC_MaxFuel and ent.VC_Fuel < ent.VC_MaxFuel then
        data.Fuel = math.floor(ent.VC_Fuel / ent.VC_MaxFuel * 100)
    else
        data.Fuel = nil
    end

    if ent.VC_HealthPerc then
        data.Health = ent.VC_HealthPerc * 100
    else
        data.Health = nil
    end

    if ent.VC_DamagedObjects then
        data.DamagedObjects = ent.VC_DamagedObjects
    else
        data.DamagedObjects = nil
    end
    return data
end

function VC.canRefuel(ent, eftype, ftype)
    return ent.VC_Fuel and ent.VC_MaxFuel and ent.VC_Fuel < ent.VC_MaxFuel and ent.VC_FuelLidPos and eftype == ftype and not ent.VC_Fuel_Disabled and (not VC.getSetting("Fuel_lidNeedUnlocked") or not VC.IsLocked(ent))
end

function VC.HandBrakeOn(ent)
    if ent.VC_NoHandbrake then return end
    ent:Fire("HandBrakeOn", 0)
    ent.VC_MainBrakesOn = true
    ent.VC_HandBrakeOn = true
    ent:SetNWBool("VC_HandBrakeOn", true)
    VC.IndicationCheck(ent, "handbrake", true)
end

function VC.HandBrakeOff(ent)
    ent:Fire("HandBrakeOff", 0)
    ent.VC_MainBrakesOn = false
    ent.VC_HandBrakeOn = false
    ent:SetNWBool("VC_HandBrakeOn", false)
    VC.IndicationCheck(ent, "handbrake", false)
end

function VC.CreateSeats(ent)
    if VC.getSetting("Passenger_Seats") and VC_fremmann777obosr(ent).ExtraSeats and not VC.IsTrailer(ent) then
        ent.VC_SeatTable = {}
        local bgroups = nil
        local obbMaxs = ent:OBBMaxs()
        local seatIndexes = {}
        for Stk, Stv in pairs(VC_fremmann777obosr(ent).ExtraSeats) do
            local Seat = ents.Create("prop_vehicle_prisoner_pod")
            if Stv.Lay then
                Stv.Ang = Stv.Ang + Angle(90, 90, 0)
                Stv.Pos = Stv.Pos + Vector(0, 35, 7)
                Seat:SetModel("models/vehicles/prisoner_pod_inner.mdl")
            else
                Seat:SetModel("models/props_phx/carseat2.mdl")
            end

            Seat:SetKeyValue("vehiclescript", "scripts/vehicles/prisoner_pod.txt")
            Seat:SetKeyValue("limitview", "0")
            Seat:SetAngles(VC.AngleCombCalc(ent:GetAngles(), Stv.Ang or Angle(0, 0, 0)))
            Seat:SetPos(VC.VectorToWorld(ent, Stv.Pos))
            Seat:SetParent(ent)
            Seat:SetNoDraw(true)
            Seat:SetNWBool("VC_ExtraSeat", true)
            Seat.VC_ExtraSeat = true
            Seat.VC_Data = table.Copy(Stv or {})
            Seat.VC_Data.Pos = nil
            Seat.VC_Data.Ang = nil
            Seat.VC_CanDriveBy = not Stv.Switch_Cant and not Stv.DriveBy_Cant and not Stv.VC_Lay
            Seat.VC_Pos = Stv.Pos
            Seat.VC_Ang = Stv.Ang or Angle(0, 0, 0)
            Seat.VC_EnterAnim = Stv.EnterAnim ~= "" and Stv.EnterAnim
            Seat.VC_ExitAnim = Stv.ExitAnim ~= "" and Stv.ExitAnim
            Seat:SetNWBool("VC_CanDriveBy", Seat.VC_CanDriveBy)
            if Stv.BGroups then
                if not bgroups then bgroups = {} end
                for k, v in pairs(Stv.BGroups) do
                    for k2, v2 in pairs(v) do
                        bgroups[k] = v2
                    end
                end
            end

            Stv.Denied = Stv.BGroups and not VC.BGroups_Check(ent, "Seat " .. Stk, Stv.BGroups)
            Seat.VC_Parent = ent
            Seat.VC_SeatNum = Stk
            Seat:SetNWInt("VC_Key", Stk)
            ent.VC_SeatTable[Stk] = Seat
            Seat:Spawn()
            Seat:PhysicsDestroy()
            Seat:SetNotSolid(true)
            timer.Simple(0.5, function() if IsValid(ent) and IsValid(Seat) and IsValid(ent:GetOwner()) then Seat:SetOwner(ent:GetOwner()) end end)
            VC_fremmanngonvzhuy(Seat)
            seatIndexes[Stk] = Seat:EntIndex()
        end

        local dataToTrasmit = util.TableToJSON(seatIndexes)
        ent:SetNWString("VC_SeatData", dataToTrasmit)
        ent.VC_SeatBGroupCheckTbl = bgroups
    end
end

hook.Add("EntityFireBullets", "VC_EntityFireBullets", function(ply, data)
    if IsValid(ply) and ply:IsPlayer() then
        local ent = ply:GetVehicle()
        if IsValid(ent) and ent.VC_ExtraSeat then return true end
    end
end)

hook.Add("PlayerSwitchWeapon", "VC_PlayerSwitchWeapon", function(ply, prev, new)
    if VC.getSetting("DriveBy") and IsValid(ply:GetVehicle()) and ply:GetVehicle().VC_ExtraSeat then
        if VC.getSetting("DriveBy_NoSwitch") then return true end
        if table.HasValue(VC.DriveByRestrictedWeapons, new:GetClass()) then
            VCPopup(ply, "CanNotEquipThisWeapon", "cross")
            return true
        end
    end
end)

function VC.EnterDriveByMode(ply, Seat, ent)
    if VC.getSetting("DriveBy") and IsValid(ply) and IsValid(Seat) and IsValid(ent) and (not ply.VC_Seat_Change_Time or ply.VC_Seat_Change_Time < CurTime()) and IsValid(ply:GetActiveWeapon()) and ply:GetActiveWeapon() and ply:GetActiveWeapon():GetClass() ~= "vc_wrench" and Seat.VC_CanDriveBy and not VC.SeatGetOption(Seat, "Cant_Exit_Lock") and not VC.SeatGetOption(Seat, "Switch_Rear") and not VC.SeatGetOption(Seat, "VC_Lay") and not VC.SeatGetOption(Seat, "Switch_Cant") and not Seat.VC_InDriveByMode then
        local Oneseat = table.Count(VC.SeatsGetAvailable(ent)) == 1 and math.abs(Seat.VC_Pos.x) < 2
        if math.abs(Seat.VC_Pos.x) > 10 or Oneseat then
            if hook.Call("VC_CanEnterDriveBy", GAMEMODE, ply, Seat, ent) == false or hook.Call("VC_canEnterDriveBy", GAMEMODE, ply, Seat, ent) == false then
                VCPopup(ply, "AccessRestricted", "cross")
                return false
            end

            local mult = 1
            if Seat.VC_Pos.x < 0 then mult = -1 end
            local SPos = Seat:GetPos() + Seat:GetUp() * 20
            local FSS = util.TraceLine({
                start = SPos,
                endpos = SPos + Seat:GetRight() * mult * 60,
                filter = table.Add(constraint.GetAllConstrainedEntities(ent), {ent})
            })

            local TET = table.Copy(ents.GetAll())
            for EEk, EEv in pairs(TET) do
                if EEv == ent then
                    TET[EEk] = nil
                    break
                end
            end

            local PTr = util.TraceLine({
                start = FSS.HitPos,
                endpos = SPos,
                filter = TET
            })

            local dist = PTr.HitPos:Distance(SPos)
            local can = true
            local wep = ply:GetActiveWeapon()
            if IsValid(wep) and table.HasValue(VC.DriveByRestrictedWeapons, wep:GetClass()) then
                VCPopup(ply, "CanNotEquipThisWeapon", "cross")
                can = false
                for k, v in pairs(ply:GetWeapons()) do
                    if not table.HasValue(VC.DriveByRestrictedWeapons, v:GetClass()) then
                        can = v:GetClass()
                        break
                    end
                end

                if not can then return end
            end

            ply.VC_Seat_Change_Time = CurTime() + 0.2
            ply.VC_ChnSts = true
            local ACA = Seat:WorldToLocalAngles(ply:EyeAngles())
            VC.exitStarted(ply)
            ply:ExitVehicle()
            ply.VC_CanEnterTime = nil
            if type(can) == "string" then ply:SelectWeapon(can) end
            ply:SetAllowWeaponsInVehicle(true)
            ply:EnterVehicle(Seat)
            ACA.r = 0
            ply:SetEyeAngles(ACA + Angle(0, 0, 0))
            VC.enterFinished(ply, Seat)
            ply.VC_ChnSts = false
            net.Start("VC_ViewChanged")
            net.Send(ply)
            ply.VC_EnteredDriveByMode = Seat
            Seat:SetNWEntity("VC_InDriveByMode", ply)
            Seat.VC_InDriveByMode = ply
        end
    end
end

function VC.driveBy_handleDisableWep(ply)
    if ply.VC_EnteredDriveByMode then
        local ent = ply:GetVehicle()
        if not IsValid(ent) or not ent.VC_InDriveByMode or ent.VC_InDriveByMode ~= ply then
            ply:SetAllowWeaponsInVehicle(false)
            ply.VC_EnteredDriveByMode = nil
        end
    end
end

function VC.ExitDriveByMode(ply, Seat, ent)
    if IsValid(Seat) and IsValid(ent) and Seat.VC_InDriveByMode then
        if IsValid(ply) then
            if ply.VC_Seat_Change_Time and ply.VC_Seat_Change_Time > CurTime() then return end
            ply.VC_Seat_Change_Time = CurTime() + 0.2
            ply.VC_ChnSts = true
            local ACA = Seat:WorldToLocalAngles(ply:EyeAngles())
            VC.exitStarted(ply)
            ply:ExitVehicle()
            ply.VC_CanEnterTime = nil
            ply:SetAllowWeaponsInVehicle(false)
            net.Start("VC_ViewChanged")
            net.Send(ply)
            local mult = 1
            if Seat.VC_Pos.x < 0 then mult = -1 end
            ply:EnterVehicle(Seat)
            ACA.r = 0
            ply:SetEyeAngles(ACA)
            ply.VC_EnteredDriveByMode = nil
        end

        Seat:SetPos(ent:LocalToWorld(Seat.VC_Pos))
        Seat:SetAngles(VC.AngleCombCalc(ent:GetAngles(), Seat.VC_Ang))
        VC.enterFinished(ply, Seat)
        if ply then ply.VC_ChnSts = false end
        Seat:SetNWEntity("VC_InDriveByMode", Seat)
        Seat.VC_InDriveByMode = nil
    end
end

concommand.Add("VC_DriveByMode_Toggle", function(ply)
    if not IsValid(ply) then return false end
    local Seat = ply:GetVehicle(ply)
    if IsValid(Seat) and Seat.VC_ExtraSeat then
        local ent = Seat:GetParent()
        if Seat.VC_InDriveByMode then
            VC.ExitDriveByMode(ply, Seat, ent)
        else
            VC.EnterDriveByMode(ply, Seat, ent)
        end
    end
end)

function VC.Debug_GetTrace()
    local ent = player.GetAll{}[1]:GetEyeTraceNoCursor().Entity
    return ent
end

function VC.ClearSeats(ent, main)
    local PTbl = nil
    if ent.VC_SeatTable then
        PTbl = PTbl or {}
        for _, St in pairs(ent.VC_SeatTable) do
            if IsValid(St) then
                if IsValid(St:GetDriver()) then
                    table.insert(PTbl, St:GetDriver())
                elseif IsValid(St.VC_AI_Driver) then
                    table.insert(PTbl, St.VC_AI_Driver)
                end
            end
        end
    end

    if not main and IsValid(ent:GetDriver()) then
        PTbl = PTbl or {}
        table.insert(PTbl, ent:GetDriver())
    elseif IsValid(ent.VC_AI_Driver) then
        table.insert(PTbl, ent.VC_AI_Driver)
    end

    if PTbl then
        for _, Ps in pairs(PTbl) do
            VC.exitStarted(Ps)
            if Ps:IsPlayer() then
                Ps:ExitVehicle()
                VC.ExitDriveByMode(nil, SeatEnt, ent)
            else
                VC.AI_ExitVehicle(Ps)
            end
        end
    end
end

function VC.ClearSeat(ent, seat)
    if not IsValid(ent) or not ent.VC_SeatTable then return end
    local SeatEnt = ent.VC_SeatTable[seat - 1]
    if seat > 1 and SeatEnt then
        if IsValid(SeatEnt:GetDriver()) then
            VC.ExitDriveByMode(nil, SeatEnt, ent)
            VC.exitStarted(SeatEnt:GetDriver())
            SeatEnt:GetDriver():ExitVehicle()
        elseif IsValid(SeatEnt.VC_AI_Driver) then
            VC.exitStarted(SeatEnt.VC_AI_Driver)
            VC.AI_ExitVehicle(SeatEnt.VC_AI_Driver)
        end
    end
end

function VC.ChangeSeat(ply, num)
    local ent = ply:GetVehicle()
    local Seat = IsValid(ent) and ent:GetParent()
    local entParent = IsValid(ent) and ent:GetParent()
    if hook.Call("VC_canEnterPassengerSeat", GAMEMODE, ply, ent, Seat) == false then return end
    if hook.Call("VC_CanEnterPassengerSeat", GAMEMODE, ply, ent, Seat) == false then return end
    num = num + 1
    local seatismain = num == 0
    if VC.getSetting("Enabled") and VC.getSetting("Seat_Switch") and IsValid(ent) and ent.VC_IsBeingUsed and not ent.VC_InDriveByMode and (not ply.VC_Seat_Change_Time or CurTime() >= ply.VC_Seat_Change_Time) and (seatismain and ent.VC_ExtraSeat or not seatismain and (ent.VC_SeatTable or ent.VC_ExtraSeat)) then
        if not seatismain then Seat = (ent.VC_ExtraSeat and VC.SeatsGetEmpty(ent:GetParent()) or VC.SeatsGetEmpty(ent))[num] end
        if ent ~= Seat and VC.SeatGetOption(Seat, "Switch_Cant") then
            VCPopup(ply, "CantSwitchFromThisSeat", "cross")
            return
        end

        if hook.Call("VC_CanSwitchSeat", GAMEMODE, ply, ent, Seat) == false or hook.Call("VC_canSwitchSeat", GAMEMODE, ply, ent, Seat) == false then return end
        if ent ~= Seat and VC.SeatGetOption(Seat, "Switch_Rear") and num <= 2 then
            VCPopup(ply, "CantSwitchToFront", "cross")
            return
        end

        if IsValid(Seat) and Seat ~= ent then
            ply.VC_Seat_Change_Time = CurTime() + 0.2
            ply.VC_ChnSts = true
            local ACA = Seat:WorldToLocalAngles(ply:EyeAngles())
            VC.exitStarted(ply)
            ply:ExitVehicle()
            ply.VC_CanEnterTime = nil
            ply:EnterVehicle(Seat)
            ACA.r = 0
            ply:SetEyeAngles(ACA)
            VC.enterFinished(ply, Seat)
            ply.VC_ChnSts = false
        end
    end
end

function VC.SeatsGetEmpty(ent, ignoreDriver)
    local seats = {ent}
    if ignoreDriver then seats = {} end
    table.Add(seats, VC.SeatsGetAvailable(ent))
    for k, v in pairs(seats) do
        if not VC.IsSeatEmpty(v) then seats[k] = nil end
    end
    return seats
end

function VC.SeatsGetAvailable(ent)
    local tbl = {}
    if ent.VC_SeatTable then
        local VehTbl = VC_fremmann777obosr(ent)
        for k, v in pairs(ent.VC_SeatTable) do
            if VehTbl and VehTbl.ExtraSeats and VehTbl.ExtraSeats[v.VC_SeatNum] and (not VehTbl.ExtraSeats[v.VC_SeatNum].Denied) then table.insert(tbl, v) end
        end
    end
    return tbl
end

function VC.SeatsForceReEnter(ent)
    local players = VC.GetDrivers(ent)
    local Seats = VC.SeatsGetAvailable(ent)
    if table.Count(players) > 0 then
        for k, ply in pairs(players) do
            ply.VC_Seat_Change_Time = CurTime() + 0.2
            ply.VC_ChnSts = true
            local ACA = ply:GetVehicle():WorldToLocalAngles(ply:EyeAngles())
            VC.exitStarted(ply)
            ply:ExitVehicle()
            if table.Count(Seats) > 0 then
                for k, Seat in pairs(Seats) do
                    ply.VC_CanEnterTime = nil
                    ply:EnterVehicle(Seat)
                    ACA.r = 0
                    ply:SetEyeAngles(ACA)
                    VC.enterFinished(ply, Seat)
                    ply.VC_ChnSts = false
                    Seats[k] = nil
                    break
                end
            end
        end
    end
end

function VC.isAI(ent)
    return ent.VC_isAI
end

function VC.HandleSeatData(ent, isMain)
    if ent.VC_Entering and ent.VC_EnterTimer and CurTime() >= ent.VC_EnterTimer then
        local driver = VC.GetDriver(ent)
        if IsValid(driver) then VC.enterFinished(driver, ent) end
        ent.VC_EnterTimer = nil
    end

    if ent.VC_Exiting and ent.VC_ExitTimer and CurTime() >= ent.VC_ExitTimer then
        VC.exitFinishedFake(nil, ent)
        ent.VC_ExitTimer = nil
    end

    if VC.HandleAI then VC.HandleAI(ent, isMain) end
    if ent.VC_InDriveByMode then
        local ply = ent:GetDriver()
        if not IsValid(ply) or not IsValid(ply:GetVehicle()) or ply:GetVehicle() ~= ent then VC.ExitDriveByMode(ply, ent, ent:GetParent()) end
    end
end

function VC.CarDoorOpen(ent)
    local vcdata = VC_fremmann777obosr(ent)
    if VC.AlarmAlert then VC.AlarmAlert(ent.VC_ExtraSeat and ent:GetParent() or ent) end
    local Sound, Pitch, Level, Volume = "vcmod/door_open.wav", 100 + math.Rand(-2, 2), 75, nil
    if vcdata.doorOpenSoundUseCustom then Sound, Pitch, Level, Volume = vcdata.doorSoundOpen.Sound or Sound, (vcdata.doorSoundOpen.Pitch or Pitch) + math.Rand(-2, 2), vcdata.doorSoundOpen.Distance or 75, vcdata.doorSoundOpen.Volume end
    VC.SoundEmit(ent, Sound, Pitch, Level, Volume)
end

function VC.CarDoorClose(ent)
    local vcdata = VC_fremmann777obosr(ent)
    if VC.AlarmAlert then VC.AlarmAlert(ent.VC_ExtraSeat and ent:GetParent() or ent) end
    local Sound, Pitch, Level, Volume = "vcmod/door_close.wav", 100 + math.Rand(-2, 2), 75, nil
    if vcdata.doorOpenSoundUseCustom then Sound, Pitch, Level, Volume = vcdata.doorSoundClose.Sound or Sound, (vcdata.doorSoundClose.Pitch or Pitch) + math.Rand(-2, 2), vcdata.doorSoundClose.Distance or 75, vcdata.doorSoundClose.Volume end
    VC.SoundEmit(ent, Sound, Pitch, Level, Volume)
end

function VC.CanUseDoors(ent)
    local GVh = ent.VC_Parent or ent
    return VC.getSetting("Door_Sounds") and (ent.VC_IsNotPrisonerPod or ent.VC_ExtraSeat) and not VC_fremmann777obosr(GVh).NoDoorSound and not table.HasValue({"models/vehicle.mdl", "models/buggy.mdl", "models/airboat.mdl"}, VC.GetModel(GVh))
end

function VC.CarDoorGlobalOpen(ent, GVh, open)
    local num = GVh == ent and 1 or ent.VC_SeatNum
    if not GVh.VC_DoorOpenTbl then GVh.VC_DoorOpenTbl = {} end
    GVh.VC_DoorOpenTbl[num] = open
    if table.Count(GVh.VC_DoorOpenTbl) == 0 then GVh.VC_DoorOpenTbl = nil end
end

function VC.GetSurfaceData(ent)
    local LastAsph = ent.VC_SurfaceData
    ent.VC_SurfaceData = {}
    ent.VC_SurfaceData.OnGround = false
    ent.VC_SurfaceData.OnAsphalt = false
    ent.VC_SurfaceData.RefreshTime = CurTime()
    ent.VC_SurfaceData.Wheels = {}
    if ent.VC_IsJeep then
        if not VC.isHeld(ent) and not ent.VC_UpsideDown and ent.VC_AboveWater then
            for Wlk, Wlv in pairs(VC.getWheelData(ent)) do
                local vec, surface_mat, onground = ent:GetWheelContactPoint(Wlk - 1)
                if not onground then surface_mat = 0 end
                if ent:LookupAttachment(Wlv) ~= 0 and ent.VC_Wheels[Wlk] then
                    if onground then ent.VC_SurfaceData.OnGround = true end
                    if not ent.VC_SurfaceData.OnAsphalt and (surface_mat == 30 or surface_mat == 29 or surface_mat == 67 or surface_mat == 77 or surface_mat == 84) then ent.VC_SurfaceData.OnAsphalt = true end
                    ent.VC_SurfaceData.Wheels[Wlk] = {
                        Attach = Wlv,
                        Pos = vec,
                        Mat = surface_mat
                    }
                end
            end
        end

        if ent.VC_SurfaceData.OnGround then
            ent.VC_NotOnGroundTime = nil
        elseif not ent.VC_NotOnGroundTime then
            ent.VC_NotOnGroundTime = CurTime() + 2
        end

        if LastAsph and (LastAsph.OnGround ~= ent.VC_SurfaceData.OnGround or ent.VC_SurfaceData.OnGround and LastAsph.OnAsphalt ~= ent.VC_SurfaceData.OnAsphalt) then
            if ent.VC_Sounds and ent.VC_Sounds.WheelBrake then
                ent.VC_Sounds.WheelBrake:Stop()
                ent.VC_Sounds.WheelBrake = nil
            end
        end
    end
    return ent.VC_SurfaceData
end

function VC.Lock(ent)
    if IsValid(ent) and not VC.IsLocked(ent) then
        VC.SoundEmit(ent, "vcmod/door_lock.wav", 95, 70, 0.2)
        ent:Fire("Lock", 0)
        VC.IndicationCheck(ent, "lock", true)
    end
end

function VC.UnLock(ent)
    if IsValid(ent) and VC.IsLocked(ent) then
        VC.SoundEmit(ent, "vcmod/door_lock.wav", 105, 70, 0.2)
        ent:Fire("Unlock", 0)
        VC.IndicationCheck(ent, "lock", false)
    end
end

local meta = FindMetaTable("Vehicle")
function meta:Lock()
    VC.Lock(self)
end

function meta:UnLock()
    VC.UnLock(self)
end

util.AddNetworkString("VC_SendToClient_DmgObjState")
util.AddNetworkString("VC_SendToClient_DmgObjState_All")
local THISISATEST = ""
local function getEffectAngle(ent, pos)
    local ret = Vector(0, 0, 0)
    if math.abs(pos.x) > math.abs(pos.y) then
        ret = ent:GetRight() * (pos.x > 0 and 1 or -1)
    else
        ret = ent:GetForward() * (pos.y > 0 and 1 or -1)
    end

    ret = ret:Angle()
    return ret
end

function VC.createEngineSmoke(ent)
    ent.VC_EngSmokeExtinguishTm = CurTime() + VC.getSetting("Dmg_Smoke_Duration")
    if not IsValid(ent.VC_EngSmoke) then
        hook.Call("VC_engineStartedEmitSmoke", GAMEMODE, ent)
        ent.VC_EngSmoke = VC.Spawn_Particle(ent, 16, VC.getEnginePos(ent), ent:GetAngles(), "VC_Engine_Smoke", false)
    end
end

function VC.HandleHealth_Slow(ent, IsEngineOn, Drv)
    if IsEngineOn then
        local hperc = ent.VC_HealthPerc or 1
        if hperc < 0.4 or ent.VC_DamagedObjects and ent.VC_DamagedObjects.exhaust then
            if not ent.VC_BackFireTimeHealth then ent.VC_BackFireTimeHealth = CurTime() + math.Rand(0.8, 2) + math.Rand(4, 12) * hperc end
            if CurTime() >= (ent.VC_BackFireTimeHealth + (1 - math.abs(ent:GetThrottle())) * 5) then
                ent.VC_BackFireTimeHealth = CurTime() + math.Rand(0.8, 2) + math.Rand(4, 12) * hperc
                if VC.getSetting("Exhaust_Effect_BackFireHealthLow") then VC.DoBackFire(ent, true) end
            end
        else
            ent.VC_BackFireTimeHealth = nil
        end
    end

    if ent.VC_ExtinguishTm and CurTime() >= ent.VC_ExtinguishTm and IsValid(ent.VC_EngFire) then
        ent.VC_EngFire:Remove()
        ent.VC_EngFire = nil
        ent:Extinguish()
        ent.VC_ExtinguishTm = nil
    end

    local hperc = ent.VC_HealthPerc or 1
    local doSmoke = hperc < 0.4 and VC.getSetting("Dmg_Smoke_Duration") > 0 and VC.EngineAboveWater(ent, true) and (IsValid(Drv) or not ent.VC_EngSmokeExtinguishTm or CurTime() < ent.VC_EngSmokeExtinguishTm)
    local smokeValid = IsValid(ent.VC_EngSmoke)
    if doSmoke then
        VC.createEngineSmoke(ent)
    elseif not doSmoke and smokeValid then
        ent.VC_EngSmoke:Remove()
    end
end

function VC.HandleHealth(ent)
    if VC.getSetting("Damage") and IsValid(ent:GetPhysicsObject()) and ent.VC_IsNotPrisonerPod then
        ent.VC_DSPVel = ent:GetPhysicsObject():GetVelocity()
        if not VC.IsTrailer(ent) then
            if not ent.VC_Dmg_CheckT or CurTime() >= ent.VC_Dmg_CheckT then
                local hperc = ent.VC_HealthPerc or 1
                local doSmoke, doFire = hperc < 0.4, hperc < 0.15
                if IsValid(ent.VC_EngSmoke) then
                    if not doSmoke then
                        ent.VC_EngSmoke:Remove()
                        ent.VC_EngSmoke = nil
                    end
                end

                if IsValid(ent.VC_EngFire) then
                    if doFire then
                        VC.DamageHealth(ent, ent.VC_MaxHealth / 250)
                    else
                        ent.VC_EngFire:Remove()
                        ent.VC_EngFire = nil
                    end
                end

                ent.VC_Dmg_CheckT = CurTime() + 0.2
            end
        end

        ent.VC_DSGP = nil
    end
end

function VC.SetDamagedObjects(ent, tbl)
    if not ent.VC_InitializedBasic then
        if not VC.Initialize_Basic then
            VCPrint("VCMod ERROR: attempting to use SetDamagedObjects before VCMod is initialized, please wait for a few seconds")
        else
            VC.Initialize_Basic(ent)
        end
    end

    if tbl.wheel then
        for k, v in pairs(tbl.wheel) do
            VC.DamageWheel(ent, k, nil, true)
        end
    end

    ent.VC_DamagedObjects = tbl
    ent.VC_StreamDamagedObjects = true
    VC.SendDamangedObjects(ent)
end

function VC.setObjectDamaged(ent, obj, int, DPnt, att, inf)
    if VC.ObjectIsDamaged(ent, obj, int) or hook.Call("VC_CanDamagePart", GAMEMODE, ent, obj, int, att, inf) == false or hook.Call("VC_canDamagePart", GAMEMODE, ent, obj, int, att, inf) == false then return end
    if not ent.VC_DamagedObjects then ent.VC_DamagedObjects = {} end
    if not ent.VC_DamagedObjects[obj] then ent.VC_DamagedObjects[obj] = {} end
    if not ent.VC_DamagedObjects[obj][int] then ent.VC_DamagedObjects[obj][int] = {} end
    hook.Call("VC_PartDamaged", GAMEMODE, ent, obj, int, att, inf)
    hook.Call("VC_partDamaged", GAMEMODE, ent, obj, int, att, inf)
    net.Start("VC_SendToClient_DmgObjState")
    net.WriteEntity(ent)
    net.WriteString(obj)
    net.WriteInt(int, 16)
    net.WriteBool(true)
    net.Broadcast()
    VC.CD.Que_Data_Update(ent)
    return true
end

local function repaired(ent, am, silent)
    if IsValid(VC.GetDriver(ent)) and (not ent.VC_Fuel or ent.VC_Fuel > 0 or ent.VC_MaxFuel == 0) then VC.SetEngineOn(ent) end
    if (ent.VC_HealthPerc or 1) > 0.15 then ent:Extinguish() end
    ent.VC_Destroyed = nil
end

local function damaged(ent, am, silent)
    local silent = VC_fremmann777obosr(ent).HealthNoEffects
    local hperc = ent.VC_HealthPerc or 1
    local doSmoke, doFire = hperc < 0.4, hperc < 0.15
    ent.VC_EngSmokeExtinguishTm = nil
    if doSmoke and not silent and VC.EngineAboveWater(ent, true) and (not ent.VC_Destroyed or not ent.VC_ExtinguishTm or CurTime() < ent.VC_ExtinguishTm) then
        if doFire then
            if VC.getSetting("Dmg_Fire_Duration") > 0 and not IsValid(ent.VC_EngFire) then
                ent.VC_EngFire = VC.Spawn_Particle(ent, 17, VC.getEnginePos(ent), ent:GetAngles(), "VC_Engine_Fire", false)
                ent.VC_Sound_FireCustom = "ambient/fire/firebig.wav"
                local ret1, ret2 = hook.Call("VC_engineStartedEmitFire", GAMEMODE, ent, ent.VC_EngFire, ent.VC_Sound_FireCustom)
                if ret2 then ent.VC_Sound_FireCustom = ret2 end
                if ret2 == false then ent.VC_Sound_FireCustom = false end
                if IsValid(ret1) then
                    ent.VC_EngFire:Remove()
                    ent.VC_EngFire = ret1
                end
            end
        end
    end

    if ent.VC_Health == 0 then if not ent.VC_Destroyed then VC.ExplodeEngine(ent, silent) end end
end

local function updateNW(ent)
    if ent:GetNWInt("VC_HealthPerc", 1) ~= (ent.VC_HealthPerc or 1) then ent:SetNWInt("VC_HealthPerc", ent.VC_HealthPerc or 1) end
end

function VC.SetHealthMax(ent, am, simple)
    if am < 0 then am = 0 end
    local max = ent.VC_MaxHealth or 0
    ent.VC_MaxHealth = am
    if ent.VC_MaxHealth == max then return end
    if simple then return end
    ent.VC_HealthPerc = (ent.VC_Health or 0) / (ent.VC_MaxHealth ~= 0 and ent.VC_MaxHealth or 1)
    updateNW(ent)
    local silent = VC_fremmann777obosr(ent).HealthNoEffects
    if max < am then
        damaged(ent, am, silent)
    else
        repaired(ent, am, silent)
    end
end

function VC.SetHealth(ent, am, noStateChange)
    if not am then return end
    if VC_fremmann777obosr(ent).HealthDisabled or not VC.getSetting("Damage") then
        ent.VC_Destroyed = nil
        if not ent.VC_Health then ent.VC_Health = ent.VC_MaxHealth or 0 end
        if not ent.VC_HealthPerc then ent.VC_HealthPerc = 1 end
        updateNW(ent)
        return
    end

    local old = ent.VC_Health or 0
    local max = ent.VC_MaxHealth or 0
    ent.VC_Health = math.Clamp(am, 0, max)
    if ent.VC_Health == old then return end
    ent.VC_HealthPerc = ent.VC_Health / (max ~= 0 and max or 1)
    updateNW(ent)
    local silent = VC_fremmann777obosr(ent).HealthNoEffects
    if not noStateChange then
        if old < am then
            repaired(ent, am, silent)
        else
            damaged(ent, am, silent)
        end
    end

    hook.Call("VC_healthChanged", GAMEMODE, ent, old, ent.VC_Health)
    VC.CD.Que_Data_Update(ent)
end

function VC.DamageHealth(ent, am)
    if not am or ent.VC_GodMode then return end
    local OD = VC_fremmann777obosr(ent)
    if OD.Siren and OD.Siren.Sounds and VC.getSetting("ELS_Vehicle_RedDamage") then am = am * VC.getSetting("ELS_Vehicle_RedDamage_M") end
    if am <= 0 then return end
    return VC.SetHealth(ent, (ent.VC_Health or 0) - am)
end

function VC.RepairHealth(ent, am)
    if not am or am < 0 then return end
    return VC.SetHealth(ent, math.Clamp((ent.VC_Health or 0) + am, 0, ent.VC_MaxHealth))
end

function VC.RepairEngine(ent)
    VC.RemoveWrenchPart(ent, "engine", 0)
    VC.RemoveWrenchPart(ent, "engine", 1)
    VC.RepairObject(ent, "engine", "", DPnt, silent)
    if VC.getSetting("Effect_Repair") then VC.Spawn_Particle(ent, 6, VC.getEnginePos(ent), ent:GetAngles(), "VC_BackFire_Sparks", 0.5) end
end

function VC.RepairAllParts(ent, timeMax)
    if ent.VC_DamagedObjects then
        if not timeMax then timeMax = 2 end
        for k, v in pairs(ent.VC_DamagedObjects) do
            for k2, v2 in pairs(v) do
                timer.Simple(math.Rand(0, timeMax), function() VC.RepairPart(ent, k, k2) end)
            end
        end
    end
end

function VC.ExplodeEngine(ent, silent, isfuel)
    VC.SetHealth(ent, 0, true)
    if not silent then
        local PTbl = nil
        if ent.VC_SeatTable then
            PTbl = PTbl or {}
            for _, St in pairs(ent.VC_SeatTable) do
                if IsValid(St) then
                    if IsValid(St:GetDriver()) then
                        table.insert(PTbl, St:GetDriver())
                    elseif IsValid(St.VC_AI_Driver) then
                        table.insert(PTbl, St.VC_AI_Driver)
                    end
                end
            end
        end

        if IsValid(ent:GetDriver()) then
            if not PTbl then PTbl = {} end
            table.insert(PTbl, ent:GetDriver())
        elseif IsValid(ent.VC_AI_Driver) then
            if not PTbl then PTbl = {} end
            table.insert(PTbl, ent.VC_AI_Driver)
        end

        if PTbl then
            for _, Ps in pairs(PTbl) do
                Ps:TakeDamage(250, ent)
                if not VC.getSetting("Damage_CanEnterIfDestroyed") then Ps:ExitVehicle() end
            end
        end

        if VC.getSetting("Dmg_Fire_Duration") > 0 then
            local exttime = math.Clamp(VC.getSetting("Dmg_Fire_Duration"), 1, VC.getSetting("Dmg_Fire_Duration")) * math.Rand(0.9, 1.1)
            ent.VC_ExtinguishTm = CurTime() + exttime
        end

        if VC.getSetting("Damage_Explode") then
            local Exp = ents.Create("env_explosion")
            Exp:SetKeyValue("iMagnitude", "100")
            Exp:SetPos(VC.getEnginePos(ent))
            Exp:SetOwner(ent)
            Exp:Spawn()
            Exp:Fire("explode")
            VC.log('<General> vehicle "' .. VC.log_highLight((ent.VC_Name or "Unknown") .. "(" .. (ent.VC_Category or "Unknown") .. ")") .. '" has exploded.', "General")
            VC.DarkRPFireSpawn(ent:GetPos())
            VC.Spawn_Particle(ent, 7, ent:GetPos(), ent:GetAngles(), "Car_Explosion", 1)
            VC.LeanRandom(ent, 1)
        end

        if not isfuel and VC.getSetting("Damage_explosion_drain_fuel") then VC.FuelConsume(ent, ent.VC_MaxFuel) end
    end

    VC.SetEngineOff(ent)
    ent.VC_Destroyed = CurTime() + VC.getSetting("Damage_Expl_Rem_Time")
    hook.Call("VC_engineExploded", GAMEMODE, ent, silent)
end

function VC.RepairObject(ent, object, int, DPnt, silent)
    if object == "engine" then
        VC.RepairHealth(ent, ent.VC_MaxHealth)
    else
        if not VC.ObjectIsDamaged(ent, object, int) then return end
        if ent.VC_DamagedObjects and ent.VC_DamagedObjects[object] and ent.VC_DamagedObjects[object][int] then ent.VC_DamagedObjects[object][int] = nil end
        if table.Count(ent.VC_DamagedObjects[object]) == 0 then ent.VC_DamagedObjects[object] = nil end
        if table.Count(ent.VC_DamagedObjects) == 0 then ent.VC_DamagedObjects = nil end
        if object == "light" then VC.recheckProjTextures(ent) end
        hook.Call("VC_PartRepaired", GAMEMODE, ent, object, int)
        hook.Call("VC_partRepaired", GAMEMODE, ent, object, int)
        net.Start("VC_SendToClient_DmgObjState")
        net.WriteEntity(ent)
        net.WriteString(object)
        net.WriteInt(int, 16)
        net.WriteBool(false)
        net.Broadcast()
        VC.CD.Que_Data_Update(ent)
    end

    if not silent then
        VC.SoundEmit(ent, "vcmod/air_wrench_long.wav", nil, 70)
        ent.VC_RM_Fixing_SNT = CurTime() + math.Rand(1, 2)
        VC.LeanRandom(ent, 0.1)
    end
end

function VC.RepairPart(ent, obj, int, DPnt)
    if obj == "engine" then
        VC.RepairEngine(ent)
    elseif obj == "light" then
        VC.RepairLight(ent, int, DPnt)
    elseif obj == "wheel" then
        VC.RepairWheel(ent, int, DPnt)
    elseif obj == "exhaust" then
        VC.RepairExhaust(ent, int, DPnt)
    end

    VC.RemoveWrenchPart(ent, obj, int)
end

function VC.DamagePart(ent, obj, int, silent, DPnt, att, inf)
    if silent then
        VC.setObjectDamaged(ent, obj, int, DPnt, att, inf)
    else
        if obj == "light" then
            VC.DamageLight(ent, int, DPnt, att, inf)
        elseif obj == "wheel" then
            VC.DamageWheel(ent, int, DPnt, nil, att, inf)
        elseif obj == "exhaust" then
            VC.DamageExhaust(ent, int, DPnt, att, inf)
        elseif obj == "fuellid" then
            VC.DamageFuelLid(ent, int, DPnt, att, inf)
        elseif obj == "engine" then
            VC.ExplodeEngine(ent)
        end
    end
end

function VC.DamageFuelLid(ent, DPnt, att, inf)
    if VC.getSetting("Damage_FuelLid_Explode") then VC.ExplodeEngine(ent, nil, true, att, inf) end
    if VC.getSetting("Damage_FuelLid_DrainFuel") then VC.FuelConsume(ent, ent.VC_MaxFuel) end
end

function VC.DamageLight(ent, int, DPnt, att, inf)
    local data = VC_fremmann777obosr(ent).Lights
    if data then data = VC_fremmann777obosr(ent).Lights[int] end
    if not data then return end
    if data.Invulnerable then return end
    if VC.ObjectIsDamaged(ent, "light", int) then return end
    if not VC.setObjectDamaged(ent, "light", int, DPnt, att, inf) then return end
    local posLocal, posWorld = VC_fremmannobosrimen(ent, data)
    if VC.getSetting("Effect_Light") then VC.Spawn_Particle(ent, 8, posWorld, getEffectAngle(ent, posLocal), "VC_Glass_Light", 0.5) end
    VC.SoundEmit(ent, VC.GetRandomSound("vcmod/Glass/light/", 3), 100 + math.Rand(-5, 5), 80, 1, posWorld)
    VC.recheckProjTextures(ent)
end

function VC.RepairLight(ent, int, DPnt)
    local data = VC_fremmann777obosr(ent).Lights
    if data then data = VC_fremmann777obosr(ent).Lights[int] end
    if not data then return end
    if not VC.ObjectIsDamaged(ent, "light", int) then return end
    VC.RepairObject(ent, "light", int, DPnt)
    local posLocal, posWorld = VC_fremmannobosrimen(ent, data)
    if VC.getSetting("Effect_Light") then VC.Spawn_Particle(ent, 9, posWorld, getEffectAngle(ent, posLocal), "VC_Glass_Fix", 0.5) end
end

function VC.Handle_Health_Sound(ent, VLA)
    if VLA > 5 and (not VC_fremmann777obosr(ent).Damage or not VC_fremmann777obosr(ent).Damage.NoCustomSounds) then
        local SVelD, CSV, CSP, CSS = VLA - 5, 1, nil, nil
        ent.VC_Dmg_SndT = ent.VC_Dmg_SndT or {}
        if SVelD <= 100 then
            CSV = math.Clamp(SVelD / 5, 0, 0.7)
            CSP = math.Clamp(80 + SVelD / 5, 80, 110)
            CSS = VC.GetRandomSound("vcmod/collision/spring/", 12)
        elseif SVelD <= 500 then
            CSV = math.Clamp(0.5 + SVelD / 800, 0, 1)
            CSP = math.Clamp(70 + SVelD / 10, 70, 130)
            CSS = VC.GetRandomSound("vcmod/collision/light/", 15)
        elseif SVelD <= 1000 then
            CSP = math.Clamp(87.5 + (SVelD - 500) / 20, 87.5, 110)
            CSS = VC.GetRandomSound("vcmod/collision/medium/", 14)
        else
            CSP = math.Clamp(95 + (SVelD - 1000) / 50, 95, 105)
            CSS = VC.GetRandomSound("vcmod/collision/heavy/", 12)
        end

        if VC.AlarmAlert then VC.AlarmAlert(ent) end
        VC.SoundEmit(ent, CSS, CSP, math.Clamp(70 + SVelD / 10, 70, 90), CSV or 1)
    end
end

function VC.HandleCallback_Dmg(ent, data)
    if data.DeltaTime > 0.1 and VC.getSetting("Enabled") then
        local HitPos = data.HitPos
        local ignn = VC.getSetting("Damage_Phys_MinVel")
        local Vel = ent:GetPhysicsObject():GetVelocity()
        local VLA = math.abs(((ent.VC_DSPVel or Vel) - Vel):Length()) - ignn
        if VLA <= 0 then return end
        if (not VC.isHeld(ent) or VC.getSetting("PhysicalDamageWPhysGun")) and (not VC.getSetting("OnlyWithPassengers") or table.Count(VC.GetDrivers(ent)) > 0) and (VC.getSetting("PhysicalDamage") or VC.getSetting("Sound_Damage_Custom")) and not ent.VC_DSGP and (not ent.VC_PATBA or CurTime() >= ent.VC_PATBA) then
            local dmgInitial = VLA / 20
            local dmgReady = dmgInitial * VC.getSetting("PhysicalDamage_Mult")
            if VC.Handle_Health_Sound then VC.Handle_Health_Sound(ent, VLA) end
            if VC.AI_HandlePhysicalDamage then VC.AI_HandlePhysicalDamage(ent, data, dmgInitial) end
            if dmgInitial > 2 then
                local mult = math.Clamp(dmgInitial / 15, 2, 4)
                VC.HandleMultiDamage(ent, HitPos, dmgInitial, DMG_FALL, mult)
            end

            if VC.getSetting("Effect_Damage_Sparks") and VLA > 10 then VC.Spawn_Particle(ent, 10, HitPos, data and data.HitNormal:Angle() or ent:GetAngles(), VLA > 750 and "VC_Crash" or VLA > 300 and "VC_Crash_Sparks" or "VC_Crash_Sparklies", 0.5) end
            if not VC.IsTrailer(ent) then VC.DamageHealth(ent, dmgReady) end
            if VC.getSetting("PhysicalDamage_PlyDmgMult") > 0 then
                local dmgAmount = dmgReady / 5 * VC.getSetting("PhysicalDamage_PlyDmgMult")
                if dmgAmount > 2 then
                    for k, v in pairs(VC.GetDrivers(ent)) do
                        local attacker = data and IsValid(data.HitEntity) and data.HitEntity or v
                        local inflictor = data and data.HitEntity or v
                        local dinfo2 = DamageInfo()
                        dinfo2:SetDamage(dmgAmount)
                        if IsValid(attacker) then dinfo2:SetAttacker(attacker) end
                        if IsValid(inflictor) then dinfo2:SetInflictor(data and data.HitEntity or v) end
                        dinfo2:SetDamageType(DMG_VEHICLE)
                        dinfo2:SetDamagePosition(HitPos or ent:GetPos())
                        v:TakeDamageInfo(dinfo2)
                    end
                end
            end
        end
    end
end

function VC.DamageVehicle_Admin(ent)
    if IsValid(ent) then
        for k, v in pairs(VC.getWheelData(ent)) do
            timer.Simple(math.Rand(0, 1), function() if IsValid(ent) then VC.DamageWheel(ent, k) end end)
        end

        if VC_fremmann777obosr(ent).Lights then
            for k, v in pairs(VC_fremmann777obosr(ent).Lights) do
                timer.Simple(math.Rand(0, 2), function() if IsValid(ent) then VC.DamageLight(ent, k) end end)
            end
        end

        if VC_fremmann777obosr(ent).Exhaust then
            for k, v in pairs(VC_fremmann777obosr(ent).Exhaust) do
                timer.Simple(math.Rand(0, 2), function() if IsValid(ent) then VC.DamageExhaust(ent, k) end end)
            end
        end

        timer.Simple(3, function() if IsValid(ent) then VC.ExplodeEngine(ent) end end)
    end
end

function VC.RepairVehicle_Admin(ent, ply)
    local can = not ply
    if not can then
        local hookRes = hook.Call("VC_canRepairWrenchAdmin", GAMEMODE, ent, ply)
        if hookRes ~= nil then
            can = hookRes
        else
            can = ply:IsAdmin()
        end
    end

    if not can then return false end
    VC.RepairHealth(ent, ent.VC_MaxHealth)
    VC.RepairAllParts(ent)
    return true
end

function VC.IncraseWheelHeat(ent, Wheel, Amount)
end

function VC.RepairExhaust(ent, Ex, DPnt)
    local sData = VC_fremmann777obosr(ent).Exhaust
    if not sData then return end
    local pos = VC.VectorToWorld(ent, sData[Ex].Pos)
    if VC.getSetting("Effect_Exhaust") then VC.Spawn_Particle(ent, 12, VC.VectorToWorld(ent, sData[Ex].Pos), sData[Ex].Ang and VC.AngleCombCalc(ent:GetAngles(), sData[Ex].Ang) or ent:GetAngles(), "VC_BackFire_Sparks", 0.5) end
    VC.RepairObject(ent, "exhaust", Ex, DPnt)
end

function VC.DamageExhaust(ent, Ex, DPnt, att, inf)
    if not VC.ObjectIsDamaged(ent, "exhaust", Ex) then
        if not VC.setObjectDamaged(ent, "exhaust", Ex, DPnt, att, inf) then return end
        local pos = VC.VectorToWorld(ent, VC_fremmann777obosr(ent).Exhaust[Ex].Pos)
        if VC.getSetting("Effect_Exhaust") then VC.Spawn_Particle(ent, 11, VC.VectorToWorld(ent, VC_fremmann777obosr(ent).Exhaust[Ex].Pos), VC_fremmann777obosr(ent).Exhaust[Ex].Ang and VC.AngleCombCalc(ent:GetAngles(), VC_fremmann777obosr(ent).Exhaust[Ex].Ang) or ent:GetAngles(), "VC_BackFire", 0.5) end
        VC.SoundEmit(ent, VC.GetRandomSound("vcmod/backfire/", 3), math.Rand(98, 102), 80)
    end
end

local ids = {"fl", "fr", "rl", "rr"}
function VC.DamageWheel(ent, Wheel, DPnt, silent, att, inf)
    if ent.VC_Wheels and not VC.ObjectIsDamaged(ent, "wheel", Wheel) and not ent.VC_Dmg_Wheel_Inv then
        if not VC.setObjectDamaged(ent, "wheel", Wheel, DPnt, att, inf) then return end
        VC.AnimateData(ent:EntIndex() .. "wheel" .. (Wheel - 1), 0, 0.005, function(int, data)
            if not IsValid(data.ent) then return end
            data.ent:SetSpringLength(data.wheel, Lerp(VC.EaseIn(int), data.min, data.max))
        end, {
            ent = ent,
            min = VC.GetSpringLength_Deflated(ent),
            max = VC.GetSpringLength(ent),
            wheel = Wheel - 1
        }, 1)

        local wr = ent.VC_Wheels[Wheel]
        if IsValid(wr.ent) then
            if not ent.VC_WheelDamping then ent.VC_WheelDamping = {} end
            local dmp1, dmp2 = wr.ent:GetDamping()
            ent.VC_WheelDamping[Wheel] = {dmp1, dmp2}
            wr.ent:SetDamping(0, 30)
        end

        if not silent then
            if VC.getSetting("Effect_Wheel") then
                local wheeln = VC.Wheels[Wheel]
                local Eff = VC.Spawn_Particle(ent, 13, VC.AtcToWorld(ent, wheeln), VC.AngleCombCalc(ent:GetAngles(), Angle(0, 90, 0)), "VC_Wheel_Deflate", 3)
                Eff:Fire("SetParentAttachmentMaintainOffset", wheeln)
            end

            VC.SoundEmit(ent, VC.GetRandomSound("vcmod/tires/", 3), math.Rand(95, 105), 75, 0.6)
        end

        VC.IndicationCheck(ent, "damage_tire_" .. ids[Wheel], true)
    end
end

function VC.GetDefaultSpringLen(ent, ignore)
    local ret = 0
    if VC.IsBig(ent) or ent.VC_Category and string.find(ent.VC_Category, "TDM") then
        ret = 0.105 + (ent.VC_Mass or 2000) / 100000 * 2.2
    else
        ret = 0.105 + (ent.VC_Volume or 500000) / 10000000 * 0.92
        if ret > 0.2 then ret = ret * 1.45 end
    end
    return ret + 500
end

function VC.GetSpringLength_Deflated(ent)
    local ret = 500
    local data_g = VC.GetDataGeneral(VC.GetModel(ent))
    if data_g and data_g.w_s_s then ret = data_g.w_s_s end
    return ret - 0.08
end

function VC.GetSpringLength(ent)
    local ret = 0
    local data_g = VC.GetDataGeneral(VC.GetModel(ent))
    if data_g and data_g.w_s_l then
        ret = data_g.w_s_l
    else
        ret = VC.GetDefaultSpringLen(ent)
    end
    return ret
end

function VC.RepairWheel(ent, Wheel, DPnt)
    if VC.ObjectIsDamaged(ent, "wheel", Wheel) then
        local wr = ent.VC_Wheels[Wheel]
        if IsValid(wr.ent) and ent.VC_WheelDamping and ent.VC_WheelDamping[Wheel] then wr.ent:SetDamping(ent.VC_WheelDamping[Wheel][1], ent.VC_WheelDamping[Wheel][2]) end
        VC.AnimateData(ent:EntIndex() .. "wheel" .. (Wheel - 1), 1, 0.0022, function(int, data)
            if not IsValid(data.ent) then return end
            data.ent:SetSpringLength(data.wheel, Lerp(VC.EaseInOut(int), data.min, data.max))
        end, {
            ent = ent,
            min = VC.GetSpringLength_Deflated(ent),
            max = VC.GetSpringLength(ent),
            wheel = Wheel - 1
        })

        VC.SoundEmit(ent, VC.GetRandomSound("vcmod/tires_inflate/", 2), math.Rand(95, 105), 75, 0.6)
        if VC.getSetting("Effect_Wheel") then
            local wheeln = VC.Wheels[Wheel]
            local Eff = VC.Spawn_Particle(ent, 14, VC.AtcToWorld(ent, wheeln), VC.AngleCombCalc(ent:GetAngles(), Angle(0, 90, 0)), "VC_Wheel_Fix", 3)
            Eff:Fire("SetParentAttachmentMaintainOffset", wheeln)
        end

        VC.RepairObject(ent, "wheel", Wheel, DPnt)
        VC.IndicationCheck(ent, "damage_tire_" .. ids[Wheel], false)
    end
end

function VC.HandleSingleDamage(ent, Pos, Amount, DType, dm, att, inf)
    local FallDmg = DType == DMG_FALL
    local BlastDmg = DType == DMG_BLAST
    if not dm then dm = 1 end
    if VC.getSetting("Damage_Lights") and VC_fremmann777obosr(ent).Lights then
        local Light, LDst = nil, nil
        for Lhk, Lhv in pairs(VC_fremmann777obosr(ent).Lights) do
            local posLocal, posWorld = VC_fremmannobosrimen(ent, Lhv)
            local MDst = Pos:Distance(VC.VectorToWorld(ent, posLocal)) / dm
            if (not LDst or MDst < LDst) and MDst <= 12 and not VC.ObjectIsDamaged(ent, "light", Lhk) and VC.BGroups_Check(ent, "Light_" .. Lhk, Lhv.BGroups) and not Lhv.Invulnerable then
                LDst = MDst
                Light = Lhk
            end
        end

        if Light then
            VC.DamageLight(ent, Light, DPnt, att, inf)
            return "light_" .. tostring(Light)
        end
    end

    if VC.getSetting("Damage_Exhaust") and VC_fremmann777obosr(ent).Exhaust then
        local Exhaust, EDst = nil, nil
        for Exk, Ehv in pairs(VC_fremmann777obosr(ent).Exhaust) do
            local MDst = Pos:Distance(VC.VectorToWorld(ent, Ehv.Pos)) / dm
            if (not EDst or MDst < EDst) and MDst <= 15 and not VC.ObjectIsDamaged(ent, "exhaust", Exk) and VC.BGroups_Check(ent, "Exhaust " .. Exk, Ehv.BGroups) and not Ehv.Invulnerable then
                EDst = MDst
                Exhaust = Exk
            end
        end

        if Exhaust then
            VC.DamageExhaust(ent, Exhaust, DPnt, att, inf)
            return "ex_" .. tostring(Exhaust)
        end
    end

    if VC.getSetting("Damage_Wheels") and ent.VC_IsJeep and (not FallDmg or Amount > 50) and not ent.VC_Dmg_Wheel_Inv and (not ent.VC_isELS or not VC.getSetting("Damage_Wheels_ELSOff")) then
        local Wheel, WDst = nil, nil
        local wheelData, isBike = VC.getWheelData(ent)
        for Wlk, Wlv in pairs(wheelData) do
            if not VC.ObjectIsDamaged(ent, "wheel", Wlk) and ent:LookupAttachment(Wlv) ~= 0 and (not VC_fremmann777obosr(ent).WheelDamage or not VC_fremmann777obosr(ent).WheelDamage[Wlk] or not VC_fremmann777obosr(ent).WheelDamage[Wlk].Invulnerable) then
                local wr = ent.VC_Wheels[Wlk].Radius or 16
                local MDst = Pos:Distance(VC.AtcToWorld(ent, Wlv)) / dm
                if (not WDst or MDst < WDst) and MDst <= (wr + 4) and MDst > (wr - 4) then
                    WDst = MDst
                    Wheel = Wlk
                end
            end
        end

        if Wheel then
            VC.DamageWheel(ent, Wheel, DPnt, nil, att, inf)
            return "wheel_" .. tostring(Wheel)
        end
    end

    if VC.getSetting("Damage_FuelLid") then
        if not FallDmg and not BlastDmg and ent.VC_FuelLidPos and ent.VC_FuelType < 2 and ent.VC_Fuel > 0 and ent.VC_MaxFuel > 0 and (ent.VC_Fuel / ent.VC_MaxFuel) > 0.3 and (ent:LocalToWorld(ent.VC_FuelLidPos):Distance(Pos) / dm) < 10 then
            VC.DamageFuelLid(ent, nil, att, inf)
            return "fuellid"
        end
    end
end

function VC.HandleMultiDamage(ent, Pos, Amount, DType, dm, att, inf)
    local notfound = false
    local foundtbl = {}
    local tries = 0
    while tries < 7 and not notfound do
        local dmg = VC.HandleSingleDamage(ent, Pos, Amount, DType, dm or 1.5, att, inf)
        if dmg then
            if not foundtbl[dmg] then foundtbl[dmg] = true end
        else
            notfound = true
        end

        tries = tries + 1
    end

    if VC.AlarmAlert then VC.AlarmAlert(ent) end
end

hook.Add("EntityTakeDamage", "VC_Damaged", function(ent, dinfo)
    if VC.getSetting("Enabled") then
        local att, inf, amount, dtype, HitPos = dinfo:GetAttacker(), dinfo:GetInflictor(), dinfo:GetDamage(), dinfo:GetDamageType(), dinfo:GetDamagePosition()
        if not IsValid(att) then att = nil end
        if not IsValid(inf) then inf = nil end
        if not HitPos or HitPos == Vector(0, 0, 0) then HitPos = VC.OBBToWorld(ent) end
        local isFallDamage = dtype == DMG_FALL
        if att and att:IsVehicle() and IsValid(att:GetDriver()) then
            att = att:GetDriver()
            dinfo:SetAttacker(att)
        end

        if ent:IsVehicle() and ent.VC_IsNotPrisonerPod then
            if ent.VC_IgnoreDamageFor then
                if CurTime() >= ent.VC_IgnoreDamageFor then
                    return
                else
                    ent.VC_IgnoreDamageFor = nil
                end
            end

            if VC.getSetting("Damage") and VC.getSetting("HealthRepairBulletDamage") and amount < 1 and dinfo:IsBulletDamage() then
                amount = amount * 10000
                dinfo:SetDamage(amount)
            end

            if amount >= 2 then
                if VC.HandleDamage_AI then VC.HandleDamage_AI(ent, dinfo, amount) end
                if VC.getSetting("Damage") then
                    if not ent.VC_Destroyed and not VC.IsTrailer(ent) then VC.DamageHealth(ent, amount) end
                    if dtype == DMG_BLAST then
                        VC.HandleMultiDamage(ent, HitPos, amount, DMG_BLAST, nil, att, inf)
                    else
                        VC.HandleSingleDamage(ent, HitPos, amount, dtype, nil, att, inf)
                    end

                    if VC.getSetting("DriveBy") and ent:IsVehicle() and att and att:IsPlayer() and IsValid(att:GetVehicle()) and IsValid(att:GetVehicle():GetParent()) and att:GetVehicle():GetParent() == ent then return true end
                    if VC.getSetting("ShootPlayers") then
                        local spos = att and (att:IsPlayer() and att:EyePos() or VC.OBBToWorld(att)) or Vector(0, 0, 0)
                        local function ScanDamage(veh)
                            if veh.VC_ExtraSeat or veh == ent then
                                local ply = veh:GetDriver()
                                local epos = IsValid(ply) and ply:EyePos() or Vector(0, 0, 0)
                                local dist = epos:Distance(HitPos)
                                if IsValid(ply) and att and att ~= ply and dist < 45 and VC.AngleDifference((spos - epos):Angle(), (spos - HitPos):Angle()) < ((ply.VC_EnteredDriveByMode and 10 or 5) * VC.getSetting("ShootPlayers_Prec_Mult", 1)) then
                                    VCEffect(HitPos, "BloodImpact")
                                    dinfo:SetDamageType(DMG_VEHICLE)
                                    ply:TakeDamageInfo(dinfo)
                                    dinfo:ScaleDamage(0)
                                elseif IsValid(ply) then
                                    return true
                                end
                            end
                        end

                        for k, v in pairs(VC.SeatsGetAvailable(ent)) do
                            if IsValid(v) then if ScanDamage(v) then end end
                        end

                        if ScanDamage(ent) then if VC.getSetting("ShootPlayers_OverrideDefault") then return true end end
                    end
                end
            end
        end

        if ent:IsPlayer() then
            local veh = ent:GetVehicle()
            if IsValid(veh) then
                if veh.VC_IsNotPrisonerPod then
                    if dtype == 17 and dinfo:GetInflictor() == veh and VC.getSetting("PhysicalDamage_PlyDisable") then return true end
                    if veh.VC_PATBA and CurTime() < veh.VC_PATBA then return true end
                end
            end
        end
    end
end)

hook.Add("PlayerShouldTakeDamage", "VC_PlayerShouldTakeDamage", function(vic, att) if VC.getSetting("CarsCantDamagePlayers") and IsValid(Att) and (vic:IsPlayer() and att:IsVehicle()) then return false end end)

util.AddNetworkString("VC_WheelSkidding")
function VC.DoBackFire(ent, shouldDamage, onlyDamaged)
    VC.SoundEmit(ent, VC.GetRandomSound("vcmod/backfire/", 3), math.Rand(98, 102), 80)
    local vehData = VC_fremmann777obosr(ent)
    if vehData.Exhaust then
        for EHk, EHv in pairs(vehData.Exhaust) do
            if VC.BGroups_Check(ent, "Exhaust " .. EHk, EHv.BGroups) and (not onlyDamaged or VC.ObjectIsDamaged(ent, "exhaust", EHk)) then VC.Spawn_Particle(ent, 0, VC.VectorToWorld(ent, vehData.Exhaust[EHk].Pos), vehData.Exhaust[EHk].Ang and VC.AngleCombCalc(ent:GetAngles(), vehData.Exhaust[EHk].Ang) or ent:GetAngles(), "VC_BackFire", 0.5) end
        end
    end

    if shouldDamage then VC.DamageHealth(ent, 0.2) end
end

function VC.HandleParticles(ent)
    local thrt_t = ent:GetThrottle() or 0
    if VC.GetState(ent, "CruiseOn") and not ent.VC_CruiseKD then thrt_t = 0.3 end
    local thrt = math.abs(thrt_t)
    if ent.VC_Dev_ThrottleTime then thrt = 1 end
    if VC.getSetting("Exhaust_Effect") and VC_fremmann777obosr(ent).Exhaust and VC.IsEngineOn(ent) and VC.EngineAboveWater(ent, true) then
        if VC.getSetting("Damage_Exhaust_Backfire") and thrt > 0.1 then
            if not ent.VC_ThrtPOffT or CurTime() >= ent.VC_ThrtPOffCT then
                ent.VC_ThrtPOffCT = CurTime() + 1 + math.Rand(0, 2)
                ent.VC_ThrtPOffT = CurTime() + 1
                timer.Simple(0.2, function()
                    if IsValid(ent) and ent.VC_DamagedObjects and ent.VC_DamagedObjects.exhaust and (not ent.VC_Timings_BackFire_D or CurTime() >= ent.VC_Timings_BackFire_D) then
                        VC.DoBackFire(ent, true, true)
                        ent.VC_Timings_BackFire_D = CurTime() + 0.5
                    end
                end)
            end
        else
            ent.VC_ThrtPOffT = nil
        end

        local Drv = ent:GetDriver()
        if ent.VC_ThrtPOffT and CurTime() < ent.VC_ThrtPOffT or thrt > 0.1 and ent.VC_Speed_Forward < 25 then
            if not ent.VC_EEPES then
                ent.VC_EEPES = {}
                for EHk, HST in pairs(VC_fremmann777obosr(ent).Exhaust) do
                    if HST.EffectStress and VC.BGroups_Check(ent, "Exhaust " .. EHk, HST.BGroups) then
                        local WDE = VC.Spawn_Particle(ent, 2, VC.VectorToWorld(ent, HST.Pos), HST.Ang and VC.AngleCombCalc(ent:GetAngles(), HST.Ang) or ent:GetAngles(), VC.getSetting("Effect_Exhaust_Custom") and HST.EffectStress or "Exhaust", false)
                        ent.VC_EEPES[EHk] = WDE
                    end
                end
            end

            ent.VC_EETBACS = CurTime() + math.Rand(0.2, 0.4)
            if ent.VC_EEPE then
                for _, EHv in pairs(ent.VC_EEPE) do
                    if IsValid(EHv) then EHv:Remove() end
                end

                ent.VC_EEPE = nil
            end
        elseif not ent.VC_EETBACS or CurTime() >= ent.VC_EETBACS then
            if not ent.VC_EEPE then
                ent.VC_EEPE = {}
                for EHk, HST in pairs(VC_fremmann777obosr(ent).Exhaust) do
                    if HST.EffectIdle and VC.BGroups_Check(ent, "Exhaust " .. EHk, HST.BGroups) then
                        local WDE = VC.Spawn_Particle(ent, 1, VC.VectorToWorld(ent, HST.Pos), HST.Ang and VC.AngleCombCalc(ent:GetAngles(), HST.Ang) or ent:GetAngles(), VC.getSetting("Effect_Exhaust_Custom") and HST.EffectIdle or "Exhaust", false)
                        ent.VC_EEPE[EHk] = WDE
                    end
                end
            end

            if ent.VC_EEPES then
                for _, EHv in pairs(ent.VC_EEPES) do
                    if IsValid(EHv) then EHv:Remove() end
                end

                ent.VC_EEPES = nil
            end
        end
    else
        if ent.VC_EEPE and (not ent.VC_EETBAC or CurTime() >= ent.VC_EETBAC) then
            for _, EHv in pairs(ent.VC_EEPE) do
                if IsValid(EHv) then EHv:Remove() end
            end

            ent.VC_EEPE = nil
        end

        if ent.VC_EEPES then
            for _, EHv in pairs(ent.VC_EEPES) do
                if IsValid(EHv) then EHv:Remove() end
            end

            ent.VC_EEPES = nil
        end
    end

    if VC.getSetting("Effect_Slide") and ent.VC_IsJeep and ent.VC_Wheels then
        local tbl = {}
        local str = "0000"
        if not VC.isHeld(ent) and ent.VC_VelLength > 100 then
            str = ""
            for k, v in pairs(ent.VC_Wheels) do
                local abs_speed = math.abs(ent.VC_Speed_Forward)
                local min = 0
                if ent.VC_Speed_Forward > 0 then
                    min = 25 + abs_speed / 8
                else
                    min = 100
                end

                tbl[k] = IsValid(v.ent) and ((math.abs(v.ent:GetAngleVelocity().x) * v.Radius / 57.4) < (abs_speed - min) or math.abs(v.ent:GetVelocity():Dot(ent:GetRight())) > 200) or nil
                str = str .. (tbl[k] and "1" or "0")
            end
        end

        ent.VC_Sliding = #tbl > 0
        if ent.VC_SlideString and str ~= ent.VC_SlideString then
            net.Start("VC_WheelSkidding")
            net.WriteEntity(ent)
            net.WriteBool(tbl[1])
            net.WriteBool(tbl[2])
            net.WriteBool(tbl[3])
            net.WriteBool(tbl[4])
            net.Broadcast()
        end

        ent.VC_SlideString = str
    end

    if VC.HandleParticles_VC2 then VC.HandleParticles_VC2(ent, vcmod2 and VC.getSetting("Burnout") and ent.VC_InBurnout) end
end

concommand.Add("vc_inside_doors_onoff", function(ply)
    if VC.getServerSetting("Enabled") and VC.getSetting("Lock_From_Inside") then
        local ent = ply:GetVehicle()
        if IsValid(ent) and not ent.VC_ExtraSeat then
            if not VC.IsLocked(ent) then
                VCPopup(ply, "Locked", "check")
                VC.Lock(ent)
                ent.VC_RemPlayerPostLock = ply
                hook.Call("VC_lockedFromInside", GAMEMODE, ent, ply)
            else
                VCPopup(ply, "UnLocked", "check")
                VC.UnLock(ent)
                hook.Call("VC_unlockedFromInside", GAMEMODE, ent, ply)
            end

            VC.SoundEmit(ent, "Clk", 100)
        end
    end
end)

concommand.Add("VC_ClearSeat", function(ply, cmd, arg)
    if VC.getSetting("Enabled") and arg[1] then
        local ent = ply:GetVehicle()
        if IsValid(ent) then
            local Arg = tonumber(arg[1])
            if Arg == 0 then
                VC.ClearSeats(ent, true)
            else
                VC.ClearSeat(ent, Arg)
            end
        end
    end
end)

concommand.Add("VC_Trailer_Detach", function(ply)
    if VC.getSetting("Enabled") then
        local ent = ply:GetVehicle()
        if IsValid(ent) and IsValid(ent.VC_HookVeh) then VC.Trailer_Detach(ent) end
    end
end)

for i = 1, 9 do
    concommand.Add("VC_Switch_Seats_" .. tostring(i), function(ply) VC.ChangeSeat(ply, i - 1) end)
end

concommand.Add("VC_Switch_Seats", function(ply)
    local MVeh = ply:GetVehicle().VC_ExtraSeat and ply:GetVehicle():GetParent() or ply:GetVehicle()
    local seatnum = 1
    if ply:GetVehicle() ~= MVeh and MVeh.VC_SeatTable then
        seatnum = ply:GetVehicle().VC_SeatNum + 1
        if seatnum > table.Count(MVeh.VC_SeatTable) then seatnum = 0 end
    end

    VC.ChangeSeat(ply, seatnum)
end)

local beamData = {}
beamData["Fog"] = 3
beamData["HBeam"] = 2
beamData["LBeam"] = 1
VC.OverrideHLColor = Color(0, 255, 0, 255)
function VC.recheckProjTextures(ent)
    local ldata = VC_fremmann777obosr(ent).LightTable
    if ldata then
        for Type, v in pairs(ldata) do
            for lk, lv in pairs(v) do
                if lv.ProjTexture then
                    local can = ent.VC_Lights_Created and ent.VC_Lights_Created[Type] and not VC.ObjectIsDamaged(ent, "light", lk) and VC.BGroups_Check(ent, "Lht_" .. Type .. lk, lv.BGroups) and VC.PParam_Check(ent, "Lht_" .. Type .. lk, lv.PP_If)
                    local has = ent.VC_Lights and ent.VC_Lights[lk] and ent.VC_Lights[lk][Type] and ent.VC_Lights[lk][Type].PrjTxt
                    if has and not can then
                        ent.VC_Lights[lk][Type].PrjTxt:Remove()
                        ent.VC_Lights[lk][Type].PrjTxt = nil
                    elseif can and not has then
                        if not ent.VC_Lights then ent.VC_Lights = {} end
                        if not ent.VC_Lights[lk] then ent.VC_Lights[lk] = {} end
                        if not ent.VC_Lights[lk][Type] then ent.VC_Lights[lk][Type] = {} end
                        local clr = lv[Type .. "Color"]
                        if Type == "HBeam" or "LBeam" then
                            local ovr = VC.getOverride(ent, "HLColor")
                            if ovr then clr = ovr end
                        end

                        ent.VC_Lights[lk][Type] = VC_fremmannmegaurod(ent, lv, lv[Type .. "Color"], beamData[Type] or 1)
                    end
                end
            end
        end
    end
end

local reCheckForPPTbl = {}
local function HandleLight_Spec(ent, Type, ClrName, can, passive)
    if VC_fremmann777obosr(ent).LightTable[Type] and can then
        if not ent.VC_Lights_Created[Type] then
            timer.Simple(0.05, function()
                if IsValid(ent) and ent.VC_Lights and ent.VC_Lights_Created[Type] then
                    for CLk, CLv in pairs(VC_fremmann777obosr(ent).LightTable[Type]) do
                        if not ent.VC_Lights[CLk] then ent.VC_Lights[CLk] = {} end
                        if VC.ObjectIsDamaged(ent, "light", CLk) then
                            if VC.getSetting("Effect_Light_Damaged") then
                                if not ent.VC_LightSparks_Times then ent.VC_LightSparks_Times = {} end
                                local sparkID = Type .. CLk
                                if not ent.VC_LightSparks_Times[sparkID] or CurTime() >= ent.VC_LightSparks_Times[sparkID] then
                                    VC.Spawn_Particle(ent, 15, VC.VectorToWorld(ent, CLv.Pos), Angle(90, 0, 0), "VC_Crash_Sparks")
                                    ent.VC_LightSparks_Times[sparkID] = CurTime() + math.Rand(0.5, 2)
                                end
                            end
                        else
                            if not ent.VC_Lights[CLk][Type] and VC.BGroups_Check(ent, "Lht_" .. Type .. CLk, CLv.BGroups) then
                                local canPP = VC.PParam_Check(ent, "Lht_" .. Type .. CLk, CLv.PP_If)
                                if canPP then
                                    local clr = CLv[ClrName]
                                    if Type == "HBeam" or "LBeam" then
                                        local ovr = VC.getOverride(ent, "HLColor")
                                        if ovr then clr = ovr end
                                    end

                                    ent.VC_Lights[CLk][Type] = VC_fremmannmegaurod(ent, CLv, clr, beamData[Type] or 1)
                                else
                                    if not ent.VC_reCheckForPPTbl then ent.VC_reCheckForPPTbl = {} end
                                    ent.VC_reCheckForPPTbl[CLk] = {CLv, Type, CLk}
                                end
                            end
                        end
                    end
                end
            end)

            ent.VC_Lights_Created[Type] = true
            if passive then ent:SetNWBool("VC_Lights_" .. Type .. "_Created", true) end
        end
    elseif ent.VC_Lights_Created[Type] then
        VC.DeleteLights(ent, Type, passive)
    end
end

function VC.HandleLights_Main(ent, CBR, MainEngineOn)
    if not ent.VC_Lights then return end
    local data = VC_fremmann777obosr(ent)
    local IsBrake = nil
    local IsRev = nil
    if VCMod2 then
        IsRev = CBR.VC_Gear < 0
    else
        local Drv = VC.GetDriver(CBR)
        local isAI = Drv and VC.isAI and VC.isAI(Drv)
        IsBrake = CBR.VC_BrakePower and CBR.VC_BrakePower > 0 or CBR.VC_Dev_ResetBrakeTime and CurTime() < CBR.VC_Dev_ResetBrakeTime or CBR.VC_BrakesOn or Drv and not isAI and ((not Drv:KeyDown(IN_BACK) or not Drv:KeyDown(IN_FORWARD)) and (Drv:KeyDown(IN_BACK) and CBR.VC_Speed_Forward > 5 or IsValid(Drv) and Drv:KeyDown(IN_FORWARD) and CBR.VC_Speed_Forward < -5))
        IsRev = CBR.VC_Dev_ResetReverseTime and CurTime() < CBR.VC_Dev_ResetReverseTime or (Drv and not isAI and Drv:KeyDown(IN_BACK) or CBR.VC_Throttle and CBR.VC_Throttle < -0.1) and CBR.VC_Speed_Forward < 5 or isAI and CBR.VC_AI_BackupType
    end

    if not IsBrake and VC.getSetting("Lights_HandBrake") then IsBrake = IsValid(CBR:GetDriver()) and ent.VC_HandBrakeOn end
    if ent.VC_DoorOpenTbl and VC.getSetting("Lights_Interior") and not data.Light_DD_Int and not data.LightTable.Inter then
        if not ent.VC_Lights_Created["Door"] then
            ent.VC_Lights_Created["Door"] = true
            ent:SetNWBool("VC_Lights_Door_Created", true)
        end
    elseif ent.VC_Lights_Created["Door"] then
        ent:SetNWBool("VC_Lights_Door_Created", false)
        ent.VC_Lights_Created["Door"] = nil
    end

    if ent.VC_reCheckForPPTbl then
        for k, v in pairs(ent.VC_reCheckForPPTbl) do
            local CLv = v[1]
            local CLk = v[3]
            local Type = v[2]
            if ent.VC_Lights_Created[Type] then
                if VC.PParam_Check(ent, "Lht_" .. Type .. CLk, CLv.PP_If) then
                    VC.recheckProjTextures(ent)
                    ent.VC_reCheckForPPTbl = nil
                end
            else
                ent.VC_reCheckForPPTbl = nil
            end
        end
    end

    HandleLight_Spec(ent, "Brake", "BrakeColor", IsBrake and MainEngineOn, true)
    HandleLight_Spec(ent, "Reverse", "ReverseColor", IsRev and MainEngineOn, true)
    HandleLight_Spec(ent, "Running", "RunningColor", VC.getSetting("Lights_Running") and MainEngineOn and VC.GetState(CBR, "RunningLightsOn"))
    HandleLight_Spec(ent, "Fog", "FogColor", VC.getSetting("FogLights") and MainEngineOn and VC.GetState(CBR, "FogLightsOn"))
    HandleLight_Spec(ent, "HBeam", "HBeamColor", VC.getSetting("HeadLights") and MainEngineOn and VC.GetState(CBR, "HighBeamsOn"))
    HandleLight_Spec(ent, "LBeam", "LBeamColor", VC.getSetting("HeadLights") and MainEngineOn and (VC.GetState(CBR, "LowBeamsOn") and not VC.GetState(CBR, "HighBeamsOn")))
    HandleLight_Spec(ent, "Inter", "InterColor", VC.getSetting("Lights_Interior") and CBR.VC_DoorOpenTbl or CBR.VC_Dev_ResetInterLightTime and CurTime() < ent.VC_Dev_ResetInterLightTime, true)
    local Turn = data.LightTable.Blinker and (VC.GetState(CBR, "TurnLightLeftOn") or VC.GetState(CBR, "TurnLightRightOn")) and not VC.GetState(CBR, "HazardLightsOn") and (ent == CBR or not VC.GetState(CBR, "TurnLightLeftOn") or not VC.GetState(CBR, "TurnLightRightOn"))
    local Hazard = data.LightTable.Blinker and VC.GetState(CBR, "HazardLightsOn") and (ent == CBR or not CBR.VC_HazardLightsOnT)
    if Turn and (not ent.VC_TrnLOnT or CurTime() >= ent.VC_TrnLOnT) and MainEngineOn then
        if not ent.VC_Lights_Created["Blinker"] then
            for CLk, CLv in pairs(data.LightTable.Blinker) do
                if not ent.VC_Lights[CLk] then ent.VC_Lights[CLk] = {} end
                if not ent.VC_Lights[CLk].Turn and not VC.ObjectIsDamaged(ent, "light", CLk) then
                    local BSCP = CLv.Pos or Vector(0, 0, 0)
                    if VC.GetState(CBR, "TurnLightLeftOn") and BSCP.x < 0 or VC.GetState(CBR, "TurnLightRightOn") and BSCP.x > 0 and VC.BGroups_Check(ent, "Lht_blnk_" .. CLk, CLv.BGroups) then ent.VC_Lights[CLk].Turn = VC_fremmannmegaurod(ent, CLv, CLv.BlinkersColor) end
                end
            end

            ent.VC_Lights_Created["Blinker"] = true
            if VC.GetState(CBR, "TurnLightLeftOn") then
                ent:SetNWBool("VC_Lights_BlinkerLeft_Created", true)
                ent:SetNWBool("VC_Lights_BlinkerRight_Created", false)
            else
                ent:SetNWBool("VC_Lights_BlinkerLeft_Created", false)
                ent:SetNWBool("VC_Lights_BlinkerRight_Created", true)
            end
        end
    elseif ent.VC_Lights_Created["Blinker"] and (ent.VC_TrnLOffT or ent.VC_TrnLOnT) then
        for CLk, CLv in pairs(data.LightTable.Blinker) do
            if ent.VC_Lights[CLk].Turn then
                VC.RemoveLight(ent.VC_Lights[CLk].Turn)
                ent.VC_Lights[CLk].Turn = nil
            end

            if not Turn then
                ent.VC_TrnLOffT = nil
                ent.VC_TrnLOnT = nil
            end
        end

        ent.VC_Lights_Created["Blinker"] = nil
        ent:SetNWBool("VC_Lights_BlinkerLeft_Created", false)
        ent:SetNWBool("VC_Lights_BlinkerRight_Created", false)
    end

    if Hazard and (not ent.VC_HazardLightsOnT or CurTime() >= ent.VC_HazardLightsOnT) then
        if not ent.VC_Lights_Created["Blinker"] then
            for CLk, CLv in pairs(data.LightTable.Blinker) do
                if not ent.VC_Lights[CLk] then ent.VC_Lights[CLk] = {} end
                if not ent.VC_Lights[CLk].Hazard and not VC.ObjectIsDamaged(ent, "light", CLk) and VC.BGroups_Check(ent, "Lht_blnk_" .. CLk, CLv.BGroups) then ent.VC_Lights[CLk].Hazard = VC_fremmannmegaurod(ent, CLv, CLv.BlinkersColor) end
            end

            ent.VC_Lights_Created["Blinker"] = true
            ent:SetNWBool("VC_Lights_Hazards_Created", true)
        end
    elseif ent.VC_Lights_Created["Blinker"] and (ent.VC_HazLOffT or ent.VC_HazardLightsOnT) then
        for CLk, CLv in pairs(data.LightTable.Blinker) do
            if not ent.VC_Lights[CLk] then ent.VC_Lights[CLk] = {} end
            if ent.VC_Lights[CLk].Hazard then
                VC.RemoveLight(ent.VC_Lights[CLk].Hazard)
                ent.VC_Lights[CLk].Hazard = nil
            end

            if not Hazard then
                ent.VC_HazLOffT = nil
                ent.VC_HazardLightsOnT = nil
            end
        end

        ent.VC_Lights_Created["Blinker"] = nil
        ent:SetNWBool("VC_Lights_Hazards_Created", false)
    end

    if Turn then
        if not ent.VC_TrnLOnT and not ent.VC_TrnLOffT then ent.VC_TrnLOffT = 0 end
        if ent.VC_TrnLOnT and CurTime() >= ent.VC_TrnLOnT then
            if ent == CBR then
                VC.SoundEmit(ent, "vcmod/blnk_in.wav", nil, 55)
                ent.VC_TrnLOnT = nil
                ent.VC_TrnLOffT = CurTime() + VC.GetBlinkerOnTime(data)
                for _, HkVh in pairs(VC.GetVehicleList()) do
                    if HkVh.VC_Truck and HkVh.VC_Truck == ent then
                        HkVh.VC_TrnLOnT = nil
                        HkVh.VC_TrnLOffT = CurTime() + VC.GetBlinkerOnTime(data)
                    end
                end
            end
        elseif ent.VC_TrnLOffT and CurTime() >= ent.VC_TrnLOffT then
            if ent == CBR then
                VC.SoundEmit(ent, "vcmod/blnk_out.wav", nil, 55)
                ent.VC_TrnLOnT = CurTime() + VC.GetBlinkerOffTime(data)
                ent.VC_TrnLOffT = nil
                for _, HkVh in pairs(VC.GetVehicleList()) do
                    if HkVh.VC_Truck and HkVh.VC_Truck == ent then
                        HkVh.VC_TrnLOnT = CurTime() + VC.GetBlinkerOffTime(data)
                        HkVh.VC_TrnLOffT = nil
                    end
                end
            end
        end
    end

    if Hazard then
        if not ent.VC_HazardLightsOnT and not ent.VC_HazLOffT then ent.VC_HazLOffT = 0 end
        if ent.VC_HazardLightsOnT and CurTime() >= ent.VC_HazardLightsOnT then
            if ent == CBR then
                VC.SoundEmit(ent, "vcmod/blnk_in.wav", nil, 55)
                ent.VC_HazardLightsOnT = nil
                ent.VC_HazLOffT = CurTime() + VC.GetBlinkerOnTime(data)
                for _, HkVh in pairs(VC.GetVehicleList()) do
                    if HkVh.VC_Truck and HkVh.VC_Truck == ent then
                        HkVh.VC_HazardLightsOnT = nil
                        HkVh.VC_HazLOffT = CurTime() + VC.GetBlinkerOnTime(data)
                    end
                end
            end
        elseif ent.VC_HazLOffT and CurTime() >= ent.VC_HazLOffT then
            if ent == CBR then
                VC.SoundEmit(ent, "vcmod/blnk_out.wav", nil, 55)
                ent.VC_HazardLightsOnT = CurTime() + VC.GetBlinkerOffTime(data)
                ent.VC_HazLOffT = nil
                for _, HkVh in pairs(VC.GetVehicleList()) do
                    if HkVh.VC_Truck and HkVh.VC_Truck == ent then
                        HkVh.VC_HazardLightsOnT = CurTime() + VC.GetBlinkerOffTime(data)
                        HkVh.VC_HazLOffT = nil
                    end
                end
            end
        end
    end
end

timer.Simple(10, function() if CarDealer and CarDealer.Settings then CarDealer.Settings.VCMod = true end end)
util.AddNetworkString("VC_Fuel_Remove")
util.AddNetworkString("VC_Fuel_Trace")
util.AddNetworkString("VC_Fuel_Add")
util.AddNetworkString("VC_Fuel_Save")
util.AddNetworkString("VC_Fuel_Respawn")
util.AddNetworkString("VC_Fuel_Update_Cons")
file.CreateDir("vcmod/fuelstations")
function VC.FuelSave()
    local tbl = {}
    for k, v in pairs(ents.FindByClass("vc_fuel_station_*")) do
        table.insert(tbl, {
            pos = v:GetPos(),
            ang = v:GetAngles(),
            ftype = v.VC_FuelType
        })
    end

    file.Write("vcmod/fuelstations/" .. game.GetMap() .. ".txt", util.TableToJSON(tbl, true))
end

function VC.FuelRespawn()
    local dir = "vcmod/fuelstations/" .. game.GetMap() .. ".txt"
    if file.Exists(dir, "DATA") then
        for k, v in pairs(ents.FindByClass("vc_fuel_station_*")) do
            v:Remove()
        end

        VC.Fuel_PlacedTbl = nil
        local tbl = util.JSONToTable(file.Read(dir, "DATA"))
        if not tbl then return end
        for k, v in pairs(tbl) do
            local ent = ents.Create("vc_fuel_station_" .. string.lower(VC.FuelTypes[v.ftype].name))
            ent:SetPos(v.pos)
            ent:SetAngles(v.ang)
            ent:Spawn()
            ent:Activate()
            ent:GetPhysicsObject():EnableMotion(false)
            if not VC.Fuel_PlacedTbl then VC.Fuel_PlacedTbl = {} end
            table.insert(VC.Fuel_PlacedTbl, ent)
        end
    end

    VC.log('<Fuel> All fuel stations have been respawned.', "Fuel")
end

timer.Simple(5, function() VC.FuelRespawn() end)
net.Receive("VC_Fuel_Remove", function(len, ply)
    if not VC.CanEditAdminSettings(ply) then return end
    if not VC.AU_CanFuel then
        VCPopup(ply, "Please update VCMod!", "cross")
        return
    end

    local ent = net.ReadEntity()
    if not IsValid(ent) then return end
    if VC.Fuel_PlacedTbl then
        for k, v in pairs(VC.Fuel_PlacedTbl) do
            if v == ent then
                VC.Fuel_PlacedTbl[k] = nil
                break
            end
        end
    end

    ent:Remove()
    VC.FuelSave()
end)

net.Receive("VC_Fuel_Trace", function(len, ply)
    if not VC.CanEditAdminSettings(ply) then return end
    if not VC.AU_CanFuel then
        VCPopup(ply, "Please update VCMod!", "cross")
        return
    end

    local ent = net.ReadEntity()
    if not IsValid(ent) then return end
    local tr = util.TraceLine({
        start = ply:GetShootPos(),
        endpos = ply:GetShootPos() + ply:GetAimVector() * 500,
        filter = {ply}
    })

    ent:SetPos(tr.HitPos)
    ent:SetAngles(Angle(0, (ply:GetPos() - tr.HitPos):Angle().y, 0))
end)

net.Receive("VC_Fuel_Add", function(len, ply)
    if not VC.CanEditAdminSettings(ply) then return end
    if not VC.AU_CanFuel then
        VCPopup(ply, "Please update VCMod!", "cross")
        return
    end

    local Type = net.ReadInt(4)
    local tr = util.TraceLine({
        start = ply:GetShootPos(),
        endpos = ply:GetShootPos() + ply:GetAimVector() * 500,
        filter = {ply}
    })

    local ent = ents.Create("vc_fuel_station_" .. string.lower(VC.FuelTypes[Type].name))
    if not IsValid(ent) then return end
    ent:SetPos(tr.HitPos)
    ent:SetAngles(Angle(0, (ply:GetPos() - tr.HitPos):Angle().y, 0))
    ent:Spawn()
    ent:Activate()
    VC.FuelSave()
end)

net.Receive("VC_Fuel_Save", function(len, ply)
    if not VC.CanEditAdminSettings(ply) then return end
    if not VC.AU_CanFuel then
        VCPopup(ply, "Please update VCMod!", "cross")
        return
    end

    VC.FuelSave()
    VCPopup(ply, 'Saved', "check", 4)
end)

net.Receive("VC_Fuel_Respawn", function(len, ply)
    if not VC.CanEditAdminSettings(ply) then return end
    if not VC.AU_CanFuel then
        VCPopup(ply, "Please update VCMod!", "cross")
        return
    end

    local dir = "vcmod/fuelstations/" .. game.GetMap() .. ".txt"
    if file.Exists(dir, "DATA") then
        VC.FuelRespawn()
    else
        VCPopup(ply, "Empty", "cross")
    end
end)

function VC.Throttle(ent, thrt)
    if ent.VC_IsNotPrisonerPod then
        if thrt > 1 then
            thrt = 1
        elseif thrt < -1 then
            thrt = -1
        end

        if vcmod2 then thrt = VC.Throttle_VC2(ent, thrt) end
        if ent.VC_AI_Driver and VC.AI_Throttle then
            VC.AI_Throttle(ent, thrt, ent.VC_AI_Driver)
        else
            ent:SetThrottle(thrt)
        end
    end

    ent.VC_Throttle = thrt
end

function VC.Think_Slow_Extra_Each(ent, EntLN, Drv)
    local driver = VC.GetDriver(ent)
    if driver then
        if driver:IsPlayer() then ent.VC_BrakePower = nil end
    elseif ent.VC_Throttle and ent.VC_Throttle ~= 0 then
        VC.Throttle(ent, 0)
    end
end

function VC.Think_Slow_Each_Main(ent, EntLN, Drv)
    local IsEngineOn = VC.IsEngineOn(ent)
    if ent.VC_ForceOpenFuelLidTime and CurTime() >= ent.VC_ForceOpenFuelLidTime then ent.VC_ForceOpenFuelLidTime = nil end
    VC.HandleHealth_Slow(ent, IsEngineOn, Drv)
    VC.HandleCarDealer_Slow(ent, IsEngineOn, Drv)
    VC.HandleRepairMan_Slow(ent, IsEngineOn, Drv)
    if ent.VC_Dev_ThrottleTime then
        if CurTime() >= ent.VC_Dev_ThrottleTime then ent.VC_Dev_ThrottleTime = nil end
        VC.Throttle(ent, 1)
    end

    if ent.VC_Destroyed and VC.getSetting("Damage_Expl_Rem") and CurTime() >= ent.VC_Destroyed then
        VCEffect(ent:LocalToWorld(ent:OBBCenter()))
        ent:Remove()
    end

    if ent.VC_AutoTurnOff_RunningLights_Time and CurTime() >= ent.VC_AutoTurnOff_RunningLights_Time then
        ent.VC_AutoTurnOff_RunningLights_Time = nil
        if VC.Lights_SuspendAutoOff then
            VCMsg("Dev tool detected, suspending auto lights off.")
            return
        end

        if not Drv then VC.RunningLightsOff(ent) end
    end

    if ent.VC_AutoTurnOff_HeadLights_Time and CurTime() >= ent.VC_AutoTurnOff_HeadLights_Time then
        ent.VC_AutoTurnOff_HeadLights_Time = nil
        if VC.Lights_SuspendAutoOff then
            VCMsg("Dev tool detected, suspending auto lights off.")
            return
        end

        if not Drv then
            VC.LowBeamsOff(ent)
            VC.HighBeamsOff(ent)
        end
    end

    if ent.VC_AutoTurnOff_FogLights_Time and CurTime() >= ent.VC_AutoTurnOff_FogLights_Time then
        ent.VC_AutoTurnOff_FogLights_Time = nil
        if VC.Lights_SuspendAutoOff then
            VCMsg("Dev tool detected, suspending auto lights off.")
            return
        end

        if not Drv then VC.FogLightsOff(ent) end
    end

    if IsValid(ent.VC_AI_Driver) and (not IsValid(ent.VC_AI_Driver) or not IsValid(ent.VC_AI_Driver.VC_AI_InVehicle) or ent.VC_AI_Driver.VC_AI_InVehicle ~= ent) then
        ent.VC_AI_Driver = nil
        ent:SetNWEntity("VC_AI_Driver", NULL)
    end

    if VC.GetState(ent, "TurnLightLeftOn") then
        local turned = vcmod2 and ent.VC_Steer < -0.2 or not vcmod2 and IsValid(Drv) and Drv:KeyDown(IN_MOVELEFT)
        if turned and not ent.VC_TurnLightTurned then
            ent.VC_TurnLightTurned = true
        elseif ent.VC_TurnLightTurned and not turned then
            ent.VC_TurnLightTurned = nil
            VC.TurnLightLeftOff(ent)
        end
    elseif VC.GetState(ent, "TurnLightRightOn") then
        local turned = vcmod2 and ent.VC_Steer > 0.2 or not vcmod2 and IsValid(Drv) and Drv:KeyDown(IN_MOVERIGHT)
        if turned and not ent.VC_TurnLightTurned then
            ent.VC_TurnLightTurned = true
        elseif ent.VC_TurnLightTurned and not turned then
            ent.VC_TurnLightTurned = nil
            VC.TurnLightRightOff(ent)
        end
    end

    if Drv and not ent.VC_BrkCONE then
        local Brk, EAW = Drv:KeyDown(IN_JUMP), VC.EngineAboveWater(ent, true)
        if not ent.VC_HandBrakeOn and (Brk or not EAW) then
            VC.HandBrakeOn(ent)
        elseif ent.VC_HandBrakeOn and not Brk and EAW then
            VC.HandBrakeOff(ent)
        end
    end

    if ent.VC_WrenchingTbl then
        for k, v in pairs(ent.VC_WrenchingTbl) do
            if not IsValid(v.ply) or CurTime() >= v.time_exp then
                VC.StopWrenching(ent, v.obj, v.int)
            else
                if CurTime() >= v.time_e then
                    VC.RemoveWrenchPart(ent, v.obj, v.int)
                    VC.RepairPart(ent, v.obj, v.int, DPnt)
                    VC.StopWrenching(ent, v.obj, v.int)
                    if IsValid(v.ply) and IsValid(v.ply:GetActiveWeapon()) then
                        hook.Call("VC_playerRepairedPart", GAMEMODE, v.ply, ent, v.obj, v.int)
                        local wep = v.ply:GetActiveWeapon()
                        wep.VC_NextScanTime = nil
                        VC.CodeEnt.Repair_Wep.ClearSelect(wep)
                    end
                end
            end
        end
    end
end

local steid = "0"
hook.Add("CanTool", "VC_CanTool", function(ply, tr, tool)
    if tool == "remover" and IsValid(tr.Entity) then
        if not VC.getSetting("CD_Veh_RemTool") and tr.Entity:IsVehicle() and tr.Entity.VC_Spawner or tr.Entity:GetClass() == "vc_npc_cardealer" then
            if ply:IsAdmin() then
                VCPopup(ply, "Allowed", "check")
            else
                VCPopup(ply, "CantRemoveThisWay", "cross")
                return false
            end
        end

        if not VC.getSetting("RM_Veh_RemTool") and tr.Entity:IsVehicle() and tr.Entity.VC_Spawner or tr.Entity:GetClass() == "vc_npc_repair" then
            if ply:IsAdmin() then
                VCPopup(ply, "Allowed", "check")
            else
                VCPopup(ply, "CantRemoveThisWay", "cross")
                return false
            end
        end
    end
end)

function VC.setFuel(ent, val)
    local old = ent.VC_Fuel or 0
    ent.VC_Fuel = math.Clamp(val, 0, ent.VC_MaxFuel or val)
    hook.Call("VC_FuelChanged", GAMEMODE, ent, old, ent.VC_Fuel)
    hook.Call("VC_fuelChanged", GAMEMODE, ent, old, ent.VC_Fuel)
    if not ent.VC_FuelConsCT or CurTime() >= ent.VC_FuelConsCT then
        local fchange = (ent.VC_LastFuel or ent.VC_Fuel) - ent.VC_Fuel
        ent.VC_LastFuel = ent.VC_Fuel
        if IsValid(ent:GetDriver()) then
            net.Start("VC_Fuel_Update_Cons")
            net.WriteInt(math.Round(fchange * 60 * 60 * 10), 16)
            net.Send(ent:GetDriver())
        end

        ent.VC_FuelConsCT = CurTime() + 1
    end

    local dif = math.abs(ent:GetNWInt("VC_Fuel", 0) - ent.VC_Fuel)
    if dif > 0.1 then
        ent:SetNWInt("VC_Fuel", ent.VC_Fuel)
        VC.CD.Que_Data_Update(ent)
    end
end

function VC.setFuelMax(ent, val)
    ent.VC_MaxFuel = VC_fremmann777obosr(ent).VC_MaxFuel
    ent:SetNWInt("VC_MaxFuel", ent.VC_MaxFuel)
end

function VC.setFuelConsumptionEnabled(ent, data)
    ent:SetNWBool("VC_FuelDisabled", not data)
end

function VC.Refuel(ent, val)
    if not VC.getSetting("Fuel") then return end
    if not VC.isFuelConsumptionEnabled(ent) then return end
    VC.setFuel(ent, (ent.VC_Fuel or 0) + val)
end

function VC.fuelSetConsumptionMultiplier(ent)
    return ent.VC_fuelConsumptionMultiplier or 1
end

function VC.FuelConsume(ent, val)
    if not VC.getSetting("Fuel") or not ent.VC_Fuel or not VC.isFuelConsumptionEnabled(ent) then return end
    VC.setFuel(ent, ent.VC_Fuel - val * VC.fuelSetConsumptionMultiplier(ent))
end

function VC.CruiseSetSpeed(ent, val)
    if not val or val < 0 then val = 0 end
    if VC.GetState(ent, "CruiseOn") then
        ent.VC_CruiseVel = val
        ent:SetNWInt("VC_Cruise_Spd", val)
    end
end

function VC.HandleFuel(ent, EntLN, Drv)
    if VC.getSetting("Fuel") and not ent.VC_Fuel_Disabled and not VC.IsTrailer(ent) and (not VC_fremmann777obosr(ent).Fuel or not VC_fremmann777obosr(ent).Fuel.Disabled) and VC.isFuelConsumptionEnabled(ent) then
        if ent.VC_Fuel and ent.VC_Fuel > 0 then
            if VC.IsEngineOn(ent) then
                local thrt = math.abs(ent:GetThrottle() or 0)
                if VC.GetState(ent, "CruiseOn") and not ent.VC_CruiseKD then thrt = 0.3 end
                local consumption = 0.00001
                if ent.VC_FuelType == 0 then consumption = consumption * 1.3 end
                if ent.VC_FuelType == 2 then consumption = consumption / 6 end
                if VC.GetState(ent, "LowBeamsOn") or VC.GetState(ent, "HighBeamsOn") or VC.GetState(ent, "FogLightsOn") then consumption = consumption * 1.06 end
                if VC.GetState(ent, "RunningLightsOn") then consumption = consumption * 1.03 end
                if ent.VC_HealthPerc and ent.VC_HealthPerc < 0.25 then consumption = consumption * 1.3 end
                if thrt > 0 then
                    if IsValid(ent.VC_HookVeh) then consumption = consumption + ent.VC_Mass / 2500000 * math.abs(ent.VC_Speed_Forward) / 5000 * thrt end
                    consumption = consumption + ent.VC_Mass / 20000000 * thrt
                    consumption = consumption + math.abs(ent.VC_Speed_Forward) / 100000000 * thrt
                end

                if ent.VC_Destroyed and ent.VC_MaxHealth ~= 0 or ent.VC_Fuel and ent.VC_Fuel <= 0 then consumption = 0 end
                VC.FuelConsume(ent, consumption * VC.getSetting("Fuel_Cons_Mult", 1) * VC.FTm)
            end

            ent.VC_Fuel_Depleted = false
        elseif not ent.VC_Fuel_Depleted then
            VC.SetEngineOff(ent)
            if IsValid(Drv) then VCPopup(Drv, "OutOfFuel", "info") end
            ent.VC_Fuel_Depleted = true
            if VC.SetEngineOff then VC.SetEngineOff(ent) end
            ent:SetNWInt("VC_Fuel", 0)
        end
    end
end

function VC.HandleCruise(ent, EntLN, Drv)
    if VC.GetState(ent, "CruiseOn") and (ent.VC_BrakePower and ent.VC_BrakePower == 0 or not vcmod2 and (not Drv or not Drv:KeyDown(IN_BACK))) and not ent.VC_HandBrakeOn and (not ent.VC_AI_Driver or Drv) then
        if Drv and (Drv:KeyDown(IN_FORWARD) or Drv:KeyDown(IN_BACK)) then
            ent.VC_CruiseKD = true
        else
            local CCVel = ent.VC_Speed_Forward or 0
            if ent.VC_CruiseKD then
                if CCVel < 10 then CCVel = 10 end
                ent.VC_CruiseVel = CCVel
                ent:SetNWInt("VC_Cruise_Spd", CCVel)
                ent.VC_CruiseKD = nil
            end

            if CCVel < 5 then CCVel = 5 end
            if CCVel < (ent.VC_CruiseVel or CCVel) then
                VC.Throttle(ent, VC.GetThrottle(ent.VC_CruiseVel, CCVel) or 0)
            elseif not Drv and ent.VC_Throttle and ent.VC_Throttle ~= 0 then
                VC.Throttle(ent, 0)
            end

            ent.VC_CruiseRan = true
        end
    elseif ent.VC_CruiseRan then
        VC.CruiseOff(ent)
        VC.Throttle(ent, 0)
        ent.VC_CruiseRan = nil
    end
end

function VC.Think_Fast_Each_Main(ent, EntLN, Drv)
    if VC.HandleSeatData then
        if ent.VC_SeatTable then
            for SeatN, Seat in pairs(ent.VC_SeatTable) do
                if IsValid(Seat) then VC.HandleSeatData(Seat) end
            end
        end

        VC.HandleSeatData(ent, true)
    end

    VC.HandleHealth(ent, EntLN, Drv)
    VC.HandleFuel(ent, EntLN, Drv)
    if VC.HandleTrailer then VC.HandleTrailer(ent, EntLN, Drv) end
end

function VC.GetDamagedPart(ent, MPos, AimVector, MinDot, SPos, ply)
    local Pnt, Int, Pos, Dist = nil, nil, nil, nil
    if ent.VC_MaxHealth and ent.VC_Health < ent.VC_MaxHealth then
        local wpos = VC.GetObjectPos(ent, "engine", 0, 137)
        local TPos = ent:LocalToWorld(wpos)
        local MDst = MPos:Distance(TPos)
        local SDst = SPos:Distance(TPos)
        local mdot = AimVector:Dot((TPos - SPos):GetNormalized())
        if SDst <= 100 and mdot > MinDot and (not Dist or mdot > Dist) then
            Pos = wpos
            Pnt = "engine"
            Int = 1
            Dist = mdot
        end
    end

    if ent.VC_DamagedObjects then
        for k, v in pairs(ent.VC_DamagedObjects) do
            for k2, v2 in pairs(v) do
                local wpos = VC.GetObjectPos(ent, k, k2, 137)
                local TPos = ent:LocalToWorld(wpos)
                local MDst = MPos:Distance(TPos)
                local SDst = SPos:Distance(TPos)
                local mdot = AimVector:Dot((TPos - SPos):GetNormalized())
                if SDst <= 100 and mdot > MinDot and (not Dist or mdot > Dist) then
                    Pos = wpos
                    Pnt = k
                    Int = k2
                    Dist = mdot
                end
            end
        end
    end
    return {
        pos = Pos,
        part = Pnt,
        int = Int
    }
end

hook.Add("EntityTakeDamage", "VC_EntityTakeDamage_NPC", function(ent, dinfo)
    if VC.getSetting("Enabled") then
        local class = ent:GetClass()
        if class == "vc_npc_cardealer" or class == "vc_npc_repair" then return true end
    end
end)

local mapName = string.lower(game.GetMap() or "Unknown")
file.CreateDir("vcmod/cardealer")
file.CreateDir("vcmod/cardealer/maps")
file.CreateDir("vcmod/cardealer/maps_old")
file.CreateDir("vcmod/cardealer/maps/" .. mapName)
file.CreateDir("vcmod/cardealer/plydata")
util.AddNetworkString("VC_CD_Send_Vehicle_Table")
util.AddNetworkString("VC_CD_AddVehicle")
util.AddNetworkString("VC_CD_AddVehicle_Manual")
util.AddNetworkString("VC_CD_CreateSpawnPlatforms")
util.AddNetworkString("VC_CD_Spawn_Vehicle")
util.AddNetworkString("VC_CD_Delete")
util.AddNetworkString("VC_CD_DeleteVehicle")
util.AddNetworkString("VC_CD_DeletePlatform")
util.AddNetworkString("VC_CD_SpawnPlatform")
util.AddNetworkString("VC_CD_PlatformsDoneEditting")
util.AddNetworkString("VC_CD_SendInfo_Import_NPC")
util.AddNetworkString("VC_CD_DoneEditting")
util.AddNetworkString("VC_CD_Send_Menu_Open")
util.AddNetworkString("VC_CD_Buy_Vehicle")
util.AddNetworkString("VC_CD_Sell_Vehicle")
util.AddNetworkString("VC_CD_StartTestDrive")
util.AddNetworkString("VC_CD_EndTestDrive")
util.AddNetworkString("VC_CD_VehicleSpawnedData")
util.AddNetworkString("VC_CD_Return_Vehicle")
util.AddNetworkString("VC_CD_Return_Vehicle_Data")
util.AddNetworkString("VC_CD_Vehicle_Options_Send")
util.AddNetworkString("VC_CD_ImportGetList")
util.AddNetworkString("VC_CD_Import")
util.AddNetworkString("VC_CD_RequestInfo_Close")
util.AddNetworkString("VC_CD_Refresh")
util.AddNetworkString("VC_CD_Add")
util.AddNetworkString("VC_CD_RequestOpen")
util.AddNetworkString("VC_CD_TracePos")
hook.Add("PlayerDisconnected", "VC_CD_PlayerDisconnected", function(ply)
    if IsValid(ply.VC_TestDriveVehicle) then ply.VC_TestDriveVehicle:Remove() end
    for k, v in pairs(VC.GetVehicleList()) do
        if v.VC_RemPlayer and v.VC_RemPlayer == ply then
            local PlyOptions = VC.CD.GetPlayerOptions(ply)
            local ID = v.VC_CD_ID
            if PlyOptions and PlyOptions.Vehicles and PlyOptions.Vehicles[ID] then
                PlyOptions.Vehicles[ID].Spawned = nil
                VC.CD.SetPlayerOptions(ply, PlyOptions)
            end

            VC.log('<Car dealer> Player: ' .. VC.log_getPlayer(ply) .. ' has disconnected removing vehicle "' .. VC.log_highLight((v.VC_Name or "Unknown") .. '(' .. (v.VC_Category or "Unknown") .. ')') .. '.', "CD")
            v:Remove()
        end
    end
end)

function VC.CD.NPCsRemove()
    if VC.CD.PlacedTbl then
        for k, v in pairs(VC.CD.PlacedTbl) do
            if IsValid(v) then
                v:Remove()
                VC.CD.PlacedTbl[k] = nil
            end
        end
    end
end

function VC.CD.Think(ent)
    if not ent.VC_HumTime then ent.VC_HumTime = CurTime() + math.Rand(25, 50) end
    if VC.getSetting("CD_Hum") and CurTime() >= ent.VC_HumTime then
        VC.SoundEmit(ent, math.random(0, 1) == 0 and "vo/eli_lab/al_hums.wav" or "vo/eli_lab/al_hums_b.wav", nil, 70, 0.7)
        ent.VC_HumTime = CurTime() + math.Rand(60, 90)
    end
end

function VC.CD.ConvertData()
    local HSL = file.Find("vcmod/cardealer/maps/*.txt", "DATA")
    if table.Count(HSL) > 0 then
        VCPrint("Car Dealer: old data structure standart found, converting data for map:")
        for _, v in pairs(HSL) do
            local name = string.gsub(v, ".txt", "")
            local dir = "vcmod/cardealer/maps/" .. v
            VCPrint(name .. ' (' .. dir .. ')')
            local readData = file.Read(dir, "DATA")
            local tbl = util.JSONToTable(readData)
            if tbl then
                for k, cd in pairs(tbl) do
                    file.Write("vcmod/cardealer/maps/" .. name .. "/" .. (os.time() + k) .. ".txt", util.TableToJSON(cd, true))
                end
            else
                VCPrint("Car Dealer: issue reading the old standart data of map '" .. name .. "', deleting.")
            end

            file.Write("vcmod/cardealer/maps_old/" .. v, readData)
            file.Delete(dir)
        end

        VCPrint("Car Dealer: converting finished.")
        VCPrint_noPrefix('')
    end
end

function VC.CD.NPCsPlace()
    VC.CD.ConvertData()
    local mainDir = "vcmod/cardealer/maps/" .. mapName .. "/"
    VC.CD.PlacedTbl = {}
    local HSL = file.Find(mainDir .. "*.txt", "DATA")
    for _, St in pairs(HSL) do
        local tbl = nil
        local ID = string.gsub(St, ".txt", "")
        if file.Exists(mainDir .. St, "DATA") then
            local data = file.Read(mainDir .. St, "DATA")
            if data then
                tbl = util.JSONToTable(data)
                if tbl then
                    local ent = ents.Create("vc_npc_cardealer")
                    if not IsValid(ent) then
                        VCPrint("VCMod ERROR: something went wrong with spawning car dealer. Either the entity does not exist or some addon does not allow that.")
                        return
                    end

                    ent:SetNWString("VC_Name", tbl.Name)
                    ent.VC_Name = tbl.Name
                    ent:SetModel(tbl.Model)
                    ent:SetPos(tbl.Pos)
                    ent:SetAngles(tbl.Ang)
                    ent.Think = function() VC.CD.Think(ent) end
                    ent.VC_Options = table.Copy(tbl)
                    ent.VC_ID = ID
                    ent:SetNWInt("VC_Int", ent.VC_ID)
                    ent:Spawn()
                    VC.CD.PlacedTbl[ID] = ent
                end
            end
        end

        if not tbl then VCPrint("ERROR: failed reading car dealer file (" .. string.gsub(St, ".txt", "") .. ")! This means this car dealers data is faulty.") end
    end
end

function VC.CD.NPCsRespawn()
    VC.CD.NPCsRemove()
    VC.CD.NPCsPlace()
end

timer.Simple(1, VC.CD.NPCsRespawn)
function VC.CD.GetPlayerOptions_ID(ID)
    if not ID then return {} end
    local path = "vcmod/cardealer/plydata/" .. ID .. ".txt"
    local tbl = {}
    if file.Exists(path, "DATA") then
        local readData = file.Read(path, "DATA")
        if #readData == 0 then
            file.Delete(path)
            VCPrint("ERROR: detected corupted car dealer data of player ID - " .. ID .. " resetting players purchase data.")
        else
            tbl = util.JSONToTable(readData)
        end
    end
    return tbl
end

function VC.CD.GetPlayerOptions(ply)
    if not IsValid(ply) then return {} end
    return VC.CD.GetPlayerOptions_ID(ply:UniqueID())
end

function VC.CD.SetPlayerOptions_ID(ID, tbl)
    local path = "vcmod/cardealer/plydata/" .. ID .. ".txt"
    file.Write(path, util.TableToJSON(tbl, true))
    return true
end

function VC.CD.SetPlayerOptions(ply, tbl)
    if not IsValid(ply) then return end
    return VC.CD.SetPlayerOptions_ID(ply:UniqueID(), tbl)
end

function VC.CD.GetVehicleData(ent)
    local ret = nil
    if not IsValid(ent) then return end
    if ent.VC_CD_ID and ent.VC_RemPlayer then
        ret = VC.CD.GetPlayerOptions_ID(ent.VC_RemPlayer_ID)
        if ret and ret.Vehicles and ret.Vehicles[ent.VC_CD_ID] then
            local old = ret.Vehicles[ent.VC_CD_ID]
            ret.Vehicles[ent.VC_CD_ID] = VC.getVehiclePersistanceData(ent)
            ret.Vehicles[ent.VC_CD_ID].Spawned = old.Spawned
            ret.Vehicles[ent.VC_CD_ID].Color = old.Color
            ret.Vehicles[ent.VC_CD_ID].Skin = old.Skin
            ret.Vehicles[ent.VC_CD_ID].BGroups = old.BGroups
        end
    end
    return ret
end

function VC.HandleCarDealer_Slow(ent)
    if ent.VC_CD_DataNeedsUpdatingTime and CurTime() >= ent.VC_CD_DataNeedsUpdatingTime then
        if VC.getSetting("CD_StoreInfo") then
            local data = VC.CD.GetVehicleData(ent)
            if data then VC.CD.SetPlayerOptions_ID(ent.VC_RemPlayer_ID, data) end
        end

        ent.VC_CD_DataNeedsUpdatingTime = nil
    end
end

function VC.CD.Que_Data_Update(ent)
    if not ent.VC_CD_DataNeedsUpdatingTime then ent.VC_CD_DataNeedsUpdatingTime = CurTime() + 30 end
end

function VC.CD.GetByIndex(index, ID)
    local ent = ents.GetByIndex(index)
    if not IsValid(ent) or not VC.classIsSupported(ent:GetClass(), "prop_vehicle") or not VC.GetModel(ent) or string.lower(VC.GetModel(ent)) ~= string.lower(VC.CD.GetDataFromName(ID).Model) then ent = nil end
    return ent
end

local function updateTime(ent)
    if not ent.VC_CanUpdateHookTime or CurTime() >= ent.VC_CanUpdateHookTime then ent.VC_CD_DataNeedsUpdatingTime = CurTime() + 2 end
end

hook.Add("VC_healthChanged", "VC_healthChanged_CarDealer", updateTime)
hook.Add("VC_fuelChanged", "VC_fuelChanged_CarDealer", updateTime)
hook.Add("VC_partDamaged", "VC_partDamaged_CarDealer", updateTime)
hook.Add("VC_partRepaired", "VC_partRepaired_CarDealer", updateTime)
concommand.Add("VC_CD_Respawn", function(ply)
    if VC.CanEditAdminSettings(ply) then
        VC.log('<Car dealer> Player: ' .. VC.log_getPlayer(ply) .. ' is respawning all Car dealers on the map.', "CD")
        VC.CD.NPCsRespawn()
    end
end)

net.Receive("VC_CD_Refresh", function(len, ply)
    if not VC.CanEditAdminSettings(ply) then return end
    VC.CD.NPCsRespawn()
    VCPopup(ply, 'CDsPlaced', "info", 4)
end)

net.Receive("VC_CD_Add", function(len, ply)
    if not IsValid(ply) then return end
    if not VC.CanEditAdminSettings(ply) then
        VCPopup(ply, "AccessRestricted", "cross")
        return
    end

    local NPCTbl = table.Copy(VC.CD.Default)
    local pos, ang = ply:GetEyeTraceNoCursor().HitPos, Angle(0, (NPCTbl.Pos - ply:GetPos()):Angle().y + 180, 0)
    NPCTbl.Pos = pos
    NPCTbl.Ang = ang
    if hook.Call("VC_CD_canAdd", GAMEMODE, ply, pos, ang) == false then
        VCPopup(ply, "AccessRestricted", "cross")
        return
    end

    local dir = "vcmod/cardealer/maps/" .. mapName .. "/" .. os.time() .. ".txt"
    if file.Exists(dir, "DATA") then
        VCPopup(ply, "Please wait", "cross")
        VCPrint("ERROR: Car Dealer: player attempted to create a car dealer too soon.")
        return
    end

    VC.log('<Car dealer> Player: ' .. VC.log_getPlayer(ply) .. ' has added a new car dealer.', "CD")
    file.Write(dir, util.TableToJSON(NPCTbl, true))
    VC.CD.NPCsRespawn()
end)

local function SpawnPlatform(ply, ent, pos, ang)
    if not IsValid(ent) then return end
    if not ply.VC_CD_Platforms then ply.VC_CD_Platforms = {} end
    local platform = ents.Create("vc_npc_obj_spawn")
    platform:SetPos(pos)
    platform:SetAngles(ang)
    platform.VC_Owner = ply
    platform.VC_NPC = ent
    platform:SetNWEntity("VC_Owner", ply)
    table.insert(ply.VC_CD_Platforms, platform)
    platform:SetNWEntity("VC_NPC", ent)
    platform:Spawn()
    VCEffect(platform:GetPos())
end

local function DeletePlatform(ent)
    if IsValid(ent) then
        VCEffect(ent:GetPos())
        ent:Remove()
    end
end

net.Receive("VC_CD_Delete", function(len, ply)
    if not IsValid(ply) then return end
    local ent = net.ReadEntity()
    if IsValid(ply) and IsValid(ent) and VC.CanEditAdminSettings(ply, true) then
        ent:Remove()
        VCEffect(ent:GetPos() + Vector(0, 0, 50))
        local dir = "vcmod/cardealer/maps/" .. mapName .. "/" .. ent.VC_ID .. ".txt"
        if file.Exists(dir, "DATA") then file.Delete(dir) end
        VCPopup(ply, 'Deleted', "check")
        VC.log('<Car dealer> Player: ' .. VC.log_getPlayer(ply) .. ' has deleted a car dealer.', "CD")
    end
end)

net.Receive("VC_CD_DoneEditting", function(len, ply)
    if not IsValid(ply) then return end
    local ent, tbl, int, vcmsg = net.ReadEntity(), net.ReadTable(), net.ReadInt(8), net.ReadInt(8)
    if IsValid(ply) and IsValid(ent) and VC.CanEditAdminSettings(ply, true) then
        ent:SetModel(tbl.Model)
        ent:SetNWString("VC_Name", tbl.Name)
        ent.VC_Options = tbl
        VCEffect(ent:GetPos() + Vector(0, 0, 50))
        local dir = "vcmod/cardealer/maps/" .. mapName .. "/" .. ent.VC_ID .. ".txt"
        if tbl.Platforms then
            for i = 1, table.Count(tbl.Platforms) do
                for j = 1, table.Count(tbl.Platforms) do
                    if tbl.Platforms[j - 1] then
                        local dist = ent:GetPos():Distance(tbl.Platforms[j].Pos)
                        local dist2 = ent:GetPos():Distance(tbl.Platforms[j - 1].Pos)
                        local oldtbl = table.Copy(tbl.Platforms[j])
                        if dist < dist2 then
                            tbl.Platforms[j] = table.Copy(tbl.Platforms[j - 1])
                            tbl.Platforms[j - 1] = oldtbl
                        end
                    end
                end
            end
        end

        file.Write(dir, util.TableToJSON(tbl, true))
        if vcmsg then VCPopup(ply, 'Car dealer successfully edited.', "check") end
    end
end)

function VC.CD.RequestOpen(ent, ply)
    if IsValid(ply) and IsValid(ent) then
        if hook.Call("VC_CD_canUse", GAMEMODE, ent, ply) == false then
            VCPopup(ply, "AccessRestricted", "cross")
            return
        end

        if not ply.VC_UseEntityTimer or CurTime() >= ply.VC_UseEntityTimer then
            if not VC.getSetting("CD_Enabled") then
                VCPopup(ply, "AccessRestricted", "cross")
                return
            end

            if not ent.VC_Options then
                VCPopup(ply, "CDSpawnedIncorrectly", "cross")
                VCEffect(ent:GetPos() + Vector(0, 0, 50))
                ent:Remove()
                return
            end

            local path = "vcmod/cardealer/plydata/" .. ply:UniqueID() .. ".txt"
            local PlyOptions = {}
            if file.Exists(path, "DATA") then PlyOptions = util.JSONToTable(file.Read(path, "DATA")) end
            net.Start("VC_CD_Send_Menu_Open")
            net.WriteEntity(ent)
            net.WriteTable(ent.VC_Options or {})
            net.WriteTable(PlyOptions or {})
            net.WriteInt(ent.VC_ID, 8)
            net.WriteInt(VC.getSetting("CD_RefundPrice"), 8)
            net.WriteInt(VC.CanEditAdminSettings(ply, true) and 1 or 0, 4)
            net.Send(ply)
            ply.VC_UseEntityTimer = CurTime() + 0.5
        end
    end
end

net.Receive("VC_CD_TracePos", function(len, ply)
    if not IsValid(ply) then return end
    local ent = net.ReadEntity()
    if IsValid(ply) and IsValid(ent) and ent.VC_ID and VC.CanEditAdminSettings(ply, true) then
        local Tbl = nil
        local dir = "vcmod/cardealer/maps/" .. mapName .. "/" .. ent.VC_ID .. ".txt"
        if file.Exists(dir, "DATA") then
            Tbl = util.JSONToTable(file.Read(dir, "DATA"))
            Tbl.Pos = ply:GetEyeTraceNoCursor().HitPos
            Tbl.Ang = Angle(0, (Tbl.Pos - ply:GetPos()):Angle().y + 180, 0)
            ent:SetPos(Tbl.Pos)
            ent:SetAngles(Tbl.Ang)
            file.Write(dir, util.TableToJSON(Tbl, true))
            ent.VC_Options = table.Copy(Tbl)
            VCPopup(ply, 'PosChanged', "check")
        end
    else
        VCPopup(ply, "Error", "cross")
    end
end)

function VC.CD.getByID(ID)
    local ret = nil
    local _, listMaps = file.Find("vcmod/cardealer/maps/*", "DATA")
    for _, v in pairs(listMaps) do
        local listFiles = file.Find("vcmod/cardealer/maps/" .. v .. "/*.txt", "DATA")
        for _, v2 in pairs(listFiles) do
            local tID = string.gsub(v2, ".txt", "")
            if tID == ID then
                local data = file.Read("vcmod/cardealer/maps/" .. v .. "/" .. v2, "DATA")
                if data then data = util.JSONToTable(data) end
                return {
                    map = v,
                    data = data or {}
                }
            end
        end
    end
end

net.Receive("VC_CD_RequestOpen", function(len, ply)
    if not VC.CanEditAdminSettings(ply) then return end
    local ent = net.ReadEntity()
    if IsValid(ent) then
        VC.CD.RequestOpen(ent, ply)
    else
        VCPopup(ply, "Error", "cross")
    end
end)

net.Receive("VC_CD_PlatformsDoneEditting", function(len, ply)
    if not VC.CanEditAdminSettings(ply) then return end
    if ply.VC_CD_Platforms then
        for k, v in pairs(ply.VC_CD_Platforms) do
            if IsValid(v) then DeletePlatform(v) end
        end

        ply.VC_CD_Platforms = nil
    end
end)

net.Receive("VC_CD_SpawnPlatform", function(len, ply)
    if not VC.CanEditAdminSettings(ply) then return end
    local ent = net.ReadEntity()
    if IsValid(ent) then
        local Pos = ply:GetEyeTraceNoCursor().HitPos + Vector(0, 0, 5)
        local Ang = (ply:GetPos() - Pos):Angle()
        Ang.p = 0
        Ang.y = Ang.y - 90
        SpawnPlatform(ply, ent, Pos, Ang)
    end
end)

net.Receive("VC_CD_DeletePlatform", function(len, ply)
    if not VC.CanEditAdminSettings(ply) then return end
    local ent = net.ReadEntity()
    if IsValid(ent) then
        local TEnt = ply:GetEyeTraceNoCursor().Entity
        if IsValid(TEnt) and TEnt:GetClass() == "vc_npc_obj_spawn" and IsValid(TEnt.VC_NPC) and TEnt.VC_NPC == ent then DeletePlatform(TEnt) end
    end
end)

net.Receive("VC_CD_Import", function(len, ply)
    if not VC.CanEditAdminSettings(ply) then return end
    local NPC, ttype = net.ReadString(), net.ReadInt(8)
    local NPCData = VC.CD.getByID(NPC)
    if not NPCData then
        VCPopup(ply, "Error", "cross")
        return
    end

    local sendTbl = {}
    if ttype == 0 then sendTbl = NPCData.data or {} end
    if ttype == 1 then sendTbl.Platforms = NPCData.data.Platforms or {} end
    if ttype == 2 then sendTbl.Vehicles = NPCData.data.Vehicles or {} end
    if ttype == 3 then
        sendTbl = NPCData.data or {}
        sendTbl.Vehicles = nil
        sendTbl.Platforms = nil
    end

    net.Start("VC_CD_SendInfo_Import_NPC")
    net.WriteTable(sendTbl)
    net.Send(ply)
end)

net.Receive("VC_CD_ImportGetList", function(len, ply)
    if not VC.CanEditAdminSettings(ply) then return end
    local TTbl = {}
    local _, listMaps = file.Find("vcmod/cardealer/maps/*", "DATA")
    for _, v in pairs(listMaps) do
        local listFiles = file.Find("vcmod/cardealer/maps/" .. v .. "/*.txt", "DATA")
        for _, v2 in pairs(listFiles) do
            if not TTbl[v] then TTbl[v] = {} end
            local data = file.Read("vcmod/cardealer/maps/" .. v .. "/" .. v2, "DATA")
            local data = util.JSONToTable(data)
            TTbl[v][string.gsub(v2, ".txt", "")] = {
                Pos = data.Pos,
                Ang = data.Ang,
                Name = data.Name,
                Model = data.Model,
                Platforms = table.Count(data.Platforms or {}),
                Vehicles = table.Count(data.Vehicles or {})
            }
        end
    end

    if table.Count(TTbl) == 0 then
        VCPopup(ply, "No car dealers found.", "cross")
        return
    end

    net.Start("VC_CD_ImportGetList")
    net.WriteTable(TTbl)
    net.Send(ply)
end)

net.Receive("VC_CD_DeleteVehicle", function(len, ply)
    if not VC.CanEditAdminSettings(ply) then return end
    local NPC, ID = net.ReadEntity(), net.ReadString()
    if IsValid(NPC) and NPC.VC_ID then
        local Tbl = nil
        local dir = "vcmod/cardealer/maps/" .. mapName .. "/" .. NPC.VC_ID .. ".txt"
        if file.Exists(dir, "DATA") then Tbl = util.JSONToTable(file.Read(dir, "DATA")) end
        if Tbl then
            for k, v in pairs(Tbl.Vehicles) do
                if k == ID then
                    Tbl.Vehicles[k] = nil
                    break
                end
            end

            file.Write(dir, util.TableToJSON(Tbl, true))
            NPC.VC_Options = table.Copy(Tbl)
            net.Start("VC_CD_Send_Vehicle_Table")
            net.WriteTable(NPC.VC_Options.Vehicles)
            net.Send(ply)
        else
            VCPopup(ply, 'Error deleting vehicle.', "cross")
        end
    end
end)

net.Receive("VC_CD_AddVehicle", function(len, ply)
    if not VC.CanEditAdminSettings(ply) then return end
    local NPC, ent, options = net.ReadEntity(), net.ReadEntity(), net.ReadTable()
    if IsValid(NPC) and IsValid(ent) and NPC.VC_ID then
        local FoundT = FoundK
        for k, v in pairs(list.Get("Vehicles")) do
            if v.Model and VC.GetModel(ent) and string.lower(v.Model) == VC.GetModel(ent) and v.Name == (ent.VC_Name or "Unknown") then
                FoundK = k
                FoundT = v
                break
            end
        end

        if FoundT then
            VCEffect(ent:GetPos() + Vector(0, 0, 50))
            local Tbl = nil
            local dir = "vcmod/cardealer/maps/" .. mapName .. "/" .. NPC.VC_ID .. ".txt"
            if file.Exists(dir, "DATA") then Tbl = util.JSONToTable(file.Read(dir, "DATA")) end
            if Tbl then
                local Name = FoundT.Name or "Unknown"
                local KVal = ent:GetKeyValues()
                Tbl.Vehicles[VC.CD.getName(VC.GetModel(ent), Name, options.DefaultSkin)] = {
                    Name = Name,
                    Category = FoundT.Category or "Unknown",
                    Model = VC.GetModel(ent),
                    Handling = KVal["vehiclescript"] or KVal["VehicleScript"],
                    Class = FoundT.Class or "prop_vehicle_jeep",
                    Entity = FoundK,
                }

                table.Merge(Tbl.Vehicles[VC.CD.getName(VC.GetModel(ent), Name, options.DefaultSkin)], options)
                file.Write(dir, util.TableToJSON(Tbl, true))
                NPC.VC_Options = table.Copy(Tbl)
                net.Start("VC_CD_Send_Vehicle_Table")
                net.WriteTable(NPC.VC_Options.Vehicles)
                net.Send(ply)
            else
                VCPopup(ply, 'Error adding vehicle.', "cross")
            end
        else
            VCPopup(ply, 'Error adding vehicle.', "cross")
        end
    end
end)

net.Receive("VC_CD_AddVehicle_Manual", function(len, ply)
    if not VC.CanEditAdminSettings(ply) then return end
    local NPC, options, vtbl = net.ReadEntity(), net.ReadTable(), util.JSONToTable(net.ReadString() or "")
    if IsValid(NPC) and NPC.VC_ID then
        local mdl, nm, vscript = vtbl.Model or "", vtbl.Name or "Unknown", vtbl.KeyValues and (vtbl.KeyValues.vehiclescript or vtbl.KeyValues.VehicleScript)
        local Tbl = nil
        local dir = "vcmod/cardealer/maps/" .. mapName .. "/" .. NPC.VC_ID .. ".txt"
        if file.Exists(dir, "DATA") then Tbl = util.JSONToTable(file.Read(dir, "DATA")) end
        local FoundT = FoundK
        for k, v in pairs(list.Get("Vehicles")) do
            if v.Model and mdl and string.lower(v.Model) == string.lower(mdl) and v.Name == nm then
                FoundK = k
                FoundT = v
                break
            end
        end

        if Tbl and vscript then
            local id = VC.CD.getName(mdl, nm, options.DefaultSkin)
            Tbl.Vehicles[id] = {
                Name = nm,
                Category = vtbl.Category or "Unknown",
                Model = mdl,
                Handling = vscript,
                Class = vtbl.Class or "prop_vehicle_jeep",
                Entity = FoundK,
            }

            table.Merge(Tbl.Vehicles[id], options)
            Tbl.Vehicles[id].KeyValues = nil
            file.Write(dir, util.TableToJSON(Tbl, true))
            NPC.VC_Options = table.Copy(Tbl)
            net.Start("VC_CD_Send_Vehicle_Table")
            net.WriteTable(NPC.VC_Options.Vehicles)
            net.Send(ply)
            VCPopup(ply, "Added", "check")
        else
            VCPopup(ply, 'Error adding vehicle.', "cross")
        end
    end
end)

net.Receive("VC_CD_CreateSpawnPlatforms", function(len, ply)
    if not VC.CanEditAdminSettings(ply) then return end
    local ent, int = net.ReadEntity(), net.ReadInt(8)
    if IsValid(ent) and ent.VC_Options and ent.VC_Options.Platforms then
        for k, v in pairs(ent.VC_Options.Platforms) do
            SpawnPlatform(ply, ent, v.Pos, v.Ang)
        end
    end
end)

function VC.NPC_getRankRestrictDetails(NPC, id)
    local ret = {}
    local data = NPC.VC_Options.RankRestrict
    for k, v in pairs(data) do
        if v then
            table.insert(ret, {
                type = "NPC",
                rank = k
            })
        end
    end

    local data = NPC.VC_Options.Vehicles and NPC.VC_Options.Vehicles[id] and NPC.VC_Options.Vehicles[id].RankRestrict
    for k, v in pairs(data) do
        if v then
            table.insert(ret, {
                type = "Object",
                rank = k
            })
        end
    end
    return ret
end

function VC.NPC_getJobRestrictDetails(NPC, id)
    local ret = {}
    local data = NPC.VC_Options.JobRestrict
    if data then
        for k, v in pairs(data) do
            if v then
                table.insert(ret, {
                    type = "NPC",
                    rank = k
                })
            end
        end
    end

    local data = NPC.VC_Options.Vehicles and NPC.VC_Options.Vehicles[id] and NPC.VC_Options.Vehicles[id].JobRestrict
    if data then
        for k, v in pairs(data) do
            if v then
                table.insert(ret, {
                    type = "Object",
                    rank = k
                })
            end
        end
    end
    return ret
end

function VC.CD.SpawnVehicle(ply, NPC, id, tbl, test)
    local VehT = NPC.VC_Options.Vehicles[id]
    local log_start = '<Car dealer> Player: ' .. VC.log_getPlayer(ply)
    local log_main = VC.log_highLight((VehT and VehT.Name or '"Unknown"') .. ' (' .. (VehT and VehT.Category or '"Unknown"') .. ')') .. (test and ' (for a test drive)' or '') .. ' from Car dealer called: "' .. VC.log_highLight(NPC.VC_Name) .. '"'
    if test then
        if IsValid(ply.VC_TestDriveVehicle) then ply.VC_TestDriveVehicle:Remove() end
        ply.VC_TestDriveVehicle = nil
        if not VC.getSetting("CD_TestDrive") then
            VCPopup(ply, "Disabled", "cross")
            VC.log(log_start .. ' has failed spawning a vehicle ' .. log_main .. ', reason: test drive disabled.', "CD")
            return
        end
    end

    if not VehT or not file.Exists(VehT.Model, "GAME") or not file.Exists(VehT.Handling, "GAME") then
        VCPopup(ply, 'Error spawning vehicle.', "cross")
        VC.log(log_start .. ' has failed spawning a vehicle ' .. log_main .. ', reason: failed to load vehicle data.', "CD")
        return
    end

    local pos, ang = VC.CD.GetSpawnPosAng(ply, NPC.VC_Options, NPC)
    if not pos or not ang then
        VCPopup(ply, "ParkingLotsTaken", "cross")
        VC.log(log_start .. ' has failed spawning a vehicle ' .. log_main .. ', reason: all parking spots taken.', "CD")
        return
    end

    local rankRestrictDetails = VC.NPC_getRankRestrictDetails(NPC, id)
    local jobRestrictDetails = VC.NPC_getJobRestrictDetails(NPC, id)
    if hook.Call("VC_CD_canSpawnVehicle", GAMEMODE, ply, id, pos, ang, NPC, rankRestrictDetails, jobRestrictDetails) == false then
        VCPopup(ply, "AccessRestricted", "cross")
        return
    end

    local class = VehT.Class or "prop_vehicle_jeep"
    local ent = ents.Create(class)
    if not IsValid(ent) then
        VCPopup(ply, 'Error spawning vehicle.', "cross")
        VC.log(log_start .. ' has failed spawning a vehicle ' .. log_main .. ', reason: entity could not be created.', "CD")
        return
    end

    ent:SetModel(VehT.Model)
    ent:SetPos(pos)
    ent:SetAngles(ang)
    ent:SetKeyValue("vehiclescript", VehT.Handling)
    ent.VC_Spawner = ply
    ent.VC_Price = VehT.Price
    if not NPC.VC_Options.DD_Clr and not VehT.DD_Clr then ent:SetColor(tbl.TColor or tbl.Color or Color(255, 255, 255, 255)) end
    if VehT.BGroups then ent:SetBodyGroups(VehT.BGroups) end
    local bgrps = tbl.TBGroups or tbl.BGroups
    timer.Simple(0.1, function()
        if IsValid(ent) and IsValid(NPC) and bgrps and not VehT.DD_BGrp and not NPC.VC_Options.DD_BGrp then
            for k, v in pairs(bgrps) do
                ent:SetBodygroup(k, v)
            end
        end
    end)

    ent:SetCollisionGroup(COLLISION_GROUP_VEHICLE)
    ent:SetSkin(not NPC.VC_Options.DD_Skin and not VehT.DD_Skin and (tbl.TSkin or tbl.Skin) or VehT.DefaultSkin or 0)
    ent.VehicleTable = {
        Name = VehT.Name,
        Category = VehT.Category,
        Model = VehT.Model,
        KeyValues = {
            vehiclescript = VehT.Handling
        }
    }

    if VehT.Entity then table.Merge(ent.VehicleTable, VC.getClassCustomVehData(VehT)) end
    for k, v in pairs(list.Get("Vehicles")) do
        if v.Model and v.Model == VehT.Model then
            ent.VehicleTable = table.Copy(v)
            ent.VehicleName = k
            break
        end
    end

    ent.VC_RemPlayer = ply
    ent.VC_RemPlayer_ID = ply:UniqueID()
    if ent.keysOwn then ent:keysOwn(ply) end
    if ent.Own then ent:Own(ply) end
    if p_SpawnedVehicle then p_SpawnedVehicle(ply, ent) end
    VCEffect_Trace(NPC, NPC:GetPos() + Vector(0, 0, 50), ent:GetPos() + Vector(0, 0, 10))
    ent.VC_CD_ID = id
    ent.VC_CarDealer = NPC
    ent.VC_CanUpdateHookTime = CurTime() + 5
    for k, v in pairs(list.Get("Vehicles")) do
        if v.Model and v.Model == VehT.Model and (not v.Name or VehT.Name or v.Name == VehT.Name) then
            ent:SetVehicleClass(VehT.Entity or k)
            break
        end
    end

    ent:Spawn()
    ent:Activate()
    if Photon and Photon.EntityCreated then Photon:EntityCreated(ent) end
    if string.lower(gmod.GetGamemode().Name) == "darkrp" then VC.Lock(ent) end
    if test then
        ent.VC_IsTestDrive = true
        ply.VC_TestDriveVehicle = ent
        timer.Simple(VC.getSetting("CD_TestDriveTime"), function() if IsValid(ent) and IsValid(ply) and ply.VC_TestDriveVehicle == ent then VC.CD.EndTestDrive(ply) end end)
    end

    timer.Simple(1, function()
        if IsValid(ply) and IsValid(ent) then
            net.Start("VC_CD_VehicleSpawnedData")
            net.WriteEntity(ent)
            net.WriteBool(test)
            net.WriteInt(test and VC.getSetting("CD_TestDriveTime") or 25, 8)
            net.Send(ply)
        end
    end)

    local data = nil
    local PlyOptions = VC.CD.GetPlayerOptions_ID(ent.VC_RemPlayer_ID)
    if VC.getSetting("CD_StoreInfo") and PlyOptions and PlyOptions.Vehicles and PlyOptions.Vehicles[ent.VC_CD_ID] then data = PlyOptions.Vehicles[ent.VC_CD_ID] end
    VC.setVehiclePersistanceData(ent, data)
    ent.VC_CD_DataNeedsUpdatingTime = nil
    gamemode.Call("PlayerSpawnedVehicle", ply, ent)
    hook.Call("VC_CarDealerSpawnedVehicle", GAMEMODE, ply, ent, test)
    hook.Call("VC_CD_spawnedVehicle", GAMEMODE, ply, ent, test)
    VC.log(log_start .. ' has spawned a vehicle ' .. log_main .. '.', "CD")
    VCPopup(ply, "VehicleSpawned", "check")
    VCEffect(ent:GetPos() + Vector(0, 0, 50))
    if VC.getSetting("CD_EnterVehicleOnSpawn") then
        net.Start("VC_CD_RequestInfo_Close")
        net.Send(ply)
        ply:EnterVehicle(ent)
    end
    return ent
end

function VC.CD.addVehicle(ply, ID, settings, noError)
    local PlyOptions = VC.CD.GetPlayerOptions(ply)
    if not PlyOptions.Vehicles then PlyOptions.Vehicles = {} end
    if PlyOptions.Vehicles[ID] then
        if not noError then
            VC.log(log_start .. ' has failed buying a vehicle ' .. log_main .. ', reason: already has it.', "CD")
            VCMsg("Error buying vehicle.", ply)
        end
        return
    end

    PlyOptions.Vehicles[ID] = settings
    VC.CD.SetPlayerOptions(ply, PlyOptions)
end

function VC.CD.hasVehicle(ply, ID)
    local PlyOptions = VC.CD.GetPlayerOptions(ply)
    return PlyOptions.Vehicles and PlyOptions.Vehicles[ID]
end

function VC.CD.removeVehicle(ply, ID, noError)
    local PlyOptions = VC.CD.GetPlayerOptions(ply)
    if not VC.CD.hasVehicle(ply, ID) then
        if not noError then VCMsg("Error selling vehicle.", ply) end
        return
    end

    PlyOptions.Vehicles[ID] = nil
    VC.CD.SetPlayerOptions(ply, PlyOptions)
end

net.Receive("VC_CD_Buy_Vehicle", function(len, ply)
    if not IsValid(ply) then return end
    local NPC, ID, settings = net.ReadEntity(), net.ReadString(), net.ReadTable()
    if IsValid(NPC) and NPC.VC_Options and NPC.VC_Options.Vehicles then
        local VehTbl = NPC.VC_Options.Vehicles[ID]
        local log_start = '<Car dealer> Player: ' .. VC.log_getPlayer(ply)
        local log_main = VC.log_highLight((VehTbl and VehTbl.Name or '"Unknown"') .. ' (' .. (VehTbl and VehTbl.Category or '"Unknown"') .. ')') .. ' from Car dealer called: "' .. VC.log_highLight(NPC.VC_Name) .. '"'
        if not VehTbl or not VC.CanAfford(ply, VehTbl.Price) then
            VCMsg("Error buying vehicle.", ply)
            VC.log(log_start .. ' has failed buying a vehicle ' .. log_main .. ', reason: can not afford.', "CD")
            return
        end

        if VC.isPlayerRestricted(ply, VehTbl, NPC.VC_Options) then
            VC.log(log_start .. ' has failed buying a vehicle ' .. log_main .. ', reason: restricted access.', "CD")
            return false
        end

        if hook.Call("VC_CD_canBuyVehicle", GAMEMODE, ply, ID, NPC) == false then
            VCPopup(ply, "AccessRestricted", "cross")
            return false
        end

        VC.CD.addVehicle(ply, ID, settings)
        VC.RemoveMoney(ply, VehTbl.Price, "CDvehBuy_" .. ID)
        VC.log(log_start .. ' has bought a vehicle ' .. log_main .. ' for ' .. VehTbl.Price .. '.', "CD")
        hook.Call("VC_CD_playerPurchasedVehicle", GAMEMODE, ply, ID, VehTbl.Price, NPC)
    end
end)

net.Receive("VC_CD_Sell_Vehicle", function(len, ply)
    if not IsValid(ply) then return end
    local NPC, ID = net.ReadEntity(), net.ReadString()
    if IsValid(NPC) and NPC.VC_Options and NPC.VC_Options.Vehicles then
        local VehTbl = NPC.VC_Options.Vehicles[ID]
        if VehTbl then
            if not VC.CD.hasVehicle(ply, ID) then return end
            local log_start = '<Car dealer> Player: ' .. VC.log_getPlayer(ply)
            local log_main = VC.log_highLight((VehTbl and VehTbl.Name or '"Unknown"') .. ' (' .. (VehTbl and VehTbl.Category or '"Unknown"')) .. ')' .. ' from Car dealer called: "' .. VC.log_highLight(NPC.VC_Name) .. '"'
            VC.CD.removeVehicle(ply, ID)
            local amount = VehTbl.Price * (VC.getSetting("CD_RefundPrice") / 100)
            VC.AddMoney(ply, amount, "CDvehSell_" .. ID)
            VC.log(log_start .. ' has sold a vehicle ' .. log_main .. ' for ' .. VC.log_highLight(amount) .. '.', "CD")
            hook.Call("VC_CD_playerSoldVehicle", GAMEMODE, ply, ID, amount, NPC)
        end
    end
end)

function VC.CD.EndTestDrive(ply)
    if IsValid(ply) and IsValid(ply.VC_TestDriveVehicle) then
        VCEffect(ply.VC_TestDriveVehicle:GetPos() + Vector(0, 0, 50))
        ply.VC_TestDriveVehicle:Remove()
        VC.log('<Car dealer> Player: ' .. VC.log_getPlayer(ply) .. ' test drive has just ended.', "CD")
        ply.VC_TestDriveVehicle = nil
    end
end

net.Receive("VC_CD_EndTestDrive", function(len, ply)
    if not IsValid(ply) then return end
    VC.CD.EndTestDrive(ply)
end)

net.Receive("VC_CD_StartTestDrive", function(len, ply)
    if not IsValid(ply) then return end
    local NPC, ID, tbl = net.ReadEntity(), net.ReadString(), net.ReadTable()
    if IsValid(ply) and IsValid(NPC) and NPC.VC_Options and NPC.VC_Options.Vehicles and NPC.VC_Options.Vehicles[ID] then
        local log_start = '<Car dealer> Player: ' .. VC.log_getPlayer(ply)
        local log_main = 'from Car dealer called: "' .. VC.log_highLight(NPC.VC_Name) .. '"'
        if VC.isPlayerRestricted(ply, NPC.VC_Options.Vehicles[ID], NPC.VC_Options) then
            VC.log(log_start .. ' failed to test drive a vehicle ' .. log_main .. ', reason: restricted.', "CD")
            return false
        end

        if hook.Call("VC_CanTestDrive", GAMEMODE, ply, NPC, ID) == false or hook.Call("VC_CD_canTestDrive", GAMEMODE, ply, NPC, ID) == false then
            VCPopup(ply, "AccessRestricted", "cross")
            VC.log(log_start .. ' failed to test drive a vehicle ' .. log_main .. ', reason: denied by dev hook.', "CD")
            return false
        end

        VC.CD.SpawnVehicle(ply, NPC, ID, tbl, true)
    end
end)

function VC.CD.DoReturnVehicle(ply, NPC, ent, ID, PlyOptions, force)
    local VehTbl = NPC.VC_Options.Vehicles[ID]
    if VehTbl then
        local distance = ent and NPC:GetPos():Distance(ent:GetPos())
        local price = 0
        if VC.getSetting("CD_Towing") and (not ent or distance > VC.getSetting("CD_Distance") or ent and ent.VC_Destroyed) then price = math.min(VC.getSetting("CD_TowingPrice"), VehTbl.Price) end
        local log_start = '<Car dealer> Player: ' .. VC.log_getPlayer(ply)
        local log_main = VC.log_highLight((VehTbl and VehTbl.Name or '"Unknown"') .. ' (' .. (VehTbl and VehTbl.Category or '"Unknown"') .. ')') .. ' from Car dealer called: "' .. VC.log_highLight(NPC.VC_Name) .. '", for price of: ' .. VC.log_highLight(price)
        if not force then
            if VC.getSetting("CD_TowingTooFar") and distance and distance > VC.getSetting("CD_TowingTooFar_Distance") then
                VCPopup(ply, "TooFar", "cross")
                VC.log(log_start .. ' has failed returning a vehicle ' .. log_main .. ', reason: too far away.', "CD")
                return
            end

            if not VC.CanAfford(ply, price) then
                VCPopup(ply, "CD_Cant_Afford", "cross")
                VC.log(log_start .. ' has failed returning a vehicle ' .. log_main .. ', reason: can not afford.')
                return
            end

            if ent and VC.getSetting("CD_ReturnLimitByDistance") and (ply:GetPos():Distance(ent:GetPos()) > VC.getSetting("CD_ReturnLimitByDistanceDist")) then
                VCPopup(ply, "TooFar", "cross")
                VC.log(log_start .. ' has failed returning a vehicle ' .. log_main .. ', reason: too far away.', "CD")
                return
            end
        end

        PlyOptions.Vehicles[ID].Spawned = nil
        VC.CD.SetPlayerOptions(ply, PlyOptions)
        VC.RemoveMoney(ply, price, "CDvehReturn_" .. ID)
        if ent then
            if ent.VC_CD_ID and ent.VC_RemPlayer and VC.getSetting("CD_StoreInfo") then
                if PlyOptions and PlyOptions.Vehicles and PlyOptions.Vehicles[ent.VC_CD_ID] then
                    local old = PlyOptions.Vehicles[ent.VC_CD_ID]
                    PlyOptions.Vehicles[ent.VC_CD_ID] = VC.getVehiclePersistanceData(ent)
                    PlyOptions.Vehicles[ent.VC_CD_ID].Color = old.Color
                    PlyOptions.Vehicles[ent.VC_CD_ID].Skin = old.Skin
                    PlyOptions.Vehicles[ent.VC_CD_ID].BGroups = old.BGroups
                end
            end

            VCEffect_Trace(ent, ent:GetPos() + Vector(0, 0, 50), NPC:GetPos() + Vector(0, 0, 10))
            VCEffect(ent:GetPos() + Vector(0, 0, 50))
            ent:Remove()
        end

        net.Start("VC_CD_Return_Vehicle_Data")
        net.WriteInt(price, 8)
        net.WriteString(ID)
        net.WriteTable(PlyOptions.Vehicles[ID])
        net.Send(ply)
    end
end

function VC.CD.ReturnVehicle(ent, free)
    local ply = ent.VC_RemPlayer
    if not IsValid(ply) or not IsValid(ent) then return end
    local NPC = ent.VC_CarDealer
    if IsValid(NPC) and NPC.VC_Options and NPC.VC_Options.Vehicles then
        local ID = ent.VC_CD_ID
        local PlyOptions = VC.CD.GetPlayerOptions(ply)
        if not PlyOptions.Vehicles or not PlyOptions.Vehicles[ID] or not PlyOptions.Vehicles[ID].Spawned then
            VCMsg("Error returning vehicle.", ply)
            return
        end

        VC.CD.DoReturnVehicle(ply, NPC, ent, ID, PlyOptions, free)
    end
end

net.Receive("VC_CD_Return_Vehicle", function(len, ply)
    if not IsValid(ply) then return end
    local NPC, ID = net.ReadEntity(), net.ReadString()
    if IsValid(NPC) and NPC.VC_Options and NPC.VC_Options.Vehicles then
        local PlyOptions = VC.CD.GetPlayerOptions(ply)
        if not PlyOptions.Vehicles or not PlyOptions.Vehicles[ID] then
            VCMsg("ERROR: user attemmpted to return a vehicle to CD which he does not have.")
            return
        end

        if not PlyOptions.Vehicles[ID].Spawned then
            VCMsg("ERROR: user attemmpted to return a vehicle to CD, but its not spawned.")
            return
        end

        local ent = VC.CD.GetByIndex(PlyOptions.Vehicles[ID].Spawned, ID)
        if not IsValid(ent) then ent = nil end
        VC.CD.DoReturnVehicle(ply, NPC, ent, ID, PlyOptions)
    end
end)

net.Receive("VC_CD_Vehicle_Options_Send", function(len, ply)
    if not IsValid(ply) then return end
    local NPC, ID, tbl = net.ReadEntity(), net.ReadString(), net.ReadTable()
    if IsValid(ply) and IsValid(NPC) and NPC.VC_Options and NPC.VC_Options.Vehicles and NPC.VC_Options.Vehicles[ID] then
        local PlyOptions = VC.CD.GetPlayerOptions(ply)
        if PlyOptions.Vehicles and PlyOptions.Vehicles[ID] then
            PlyOptions.Vehicles[ID].Color = tbl.Color
            PlyOptions.Vehicles[ID].Skin = tbl.Skin
            PlyOptions.Vehicles[ID].BGroups = tbl.BGroups
            VC.CD.SetPlayerOptions(ply, PlyOptions)
            VCPopup(ply, "SettingsSaved", "check")
            VC.log('<Car dealer> Player: ' .. VC.log_getPlayer(ply) .. ' has changed settings for Car dealer called: "' .. VC.log_highLight(NPC.VC_Name) .. '".', "CD")
        else
            VCMsg("Error: you do not own this vehicle.", ply)
        end
    else
        VCMsg("Error: NPC does not have this vehicle.", ply)
    end
end)

net.Receive("VC_CD_Spawn_Vehicle", function(len, ply)
    if not IsValid(ply) then return end
    if not ply.VC_CD_SpawnTimer or CurTime() >= ply.VC_CD_SpawnTimer then
        local NPC, ID, tbl = net.ReadEntity(), net.ReadString(), net.ReadTable()
        if IsValid(ply) and IsValid(NPC) and NPC.VC_Options and NPC.VC_Options.Vehicles and NPC.VC_Options.Vehicles[ID] then
            local path = "vcmod/cardealer/plydata/" .. ply:UniqueID() .. ".txt"
            local PlyOptions = {}
            if file.Exists(path, "DATA") then PlyOptions = util.JSONToTable(file.Read(path, "DATA")) end
            if PlyOptions.Vehicles and PlyOptions.Vehicles[ID] then
                if VC.getSetting("CD_OnlyAllowOne") then
                    local OutCars = {}
                    for k, v in pairs(PlyOptions.Vehicles) do
                        if NPC.VC_Options.Vehicles[k] and v.Spawned then
                            VCPopup(ply, "NotAllowedRemoveOtherVehicles", "cross")
                            return false
                        end
                    end
                end

                if VC.isPlayerRestricted(ply, NPC.VC_Options.Vehicles[ID], NPC.VC_Options) then return false end
                local ent = VC.CD.SpawnVehicle(ply, NPC, ID, tbl)
                if IsValid(ent) then
                    PlyOptions.Vehicles[ID].Spawned = ent:EntIndex()
                    local data = PlyOptions.Vehicles[ent.VC_CD_ID]
                    if not VC.getSetting("CD_StoreInfo") and (data.Health or data.Fuel or data.DamagedObjects) then
                        data.Health = nil
                        data.Fuel = nil
                        data.DamagedObjects = nil
                    end

                    VC.CD.SetPlayerOptions(ply, PlyOptions)
                end
            else
                VCMsg("ERROR: user attempted to spawn a vehicle from CD that he does not have.", ply)
            end
        else
            VCMsg("ERROR: user attempted to spawn a vehicle from CD that the CD does not have.", ply)
        end

        ply.VC_CD_SpawnTimer = CurTime() + 0.5
    end
end)

function VC.CD.ChangedJobs(ply, old, new)
    local PlyOptions = VC.CD.GetPlayerOptions(ply)
    if PlyOptions and PlyOptions.Vehicles then
        local VehNeedingList = {}
        for k, v in pairs(PlyOptions.Vehicles) do
            if v.Spawned and IsValid(ents.GetByIndex(v.Spawned)) then
                local ent = VC.CD.GetByIndex(v.Spawned, k)
                if IsValid(ent) then VehNeedingList[k] = ent end
            end
        end

        if table.Count(VehNeedingList) > 0 then
            local dir = "vcmod/cardealer/maps/" .. mapName
            if file.Exists(dir, "DATA") then
                local HSL = file.Find(dir .. "/*.txt", "DATA")
                for _, v in pairs(HSL) do
                    if v and file.Exists(dir .. "/" .. v, "DATA") then
                        local data = file.Read(dir .. "/" .. v, "DATA")
                        if data then
                            v = util.JSONToTable(data)
                            for k2, v2 in pairs(VehNeedingList) do
                                if IsValid(v2) and v.Vehicles and v.Vehicles[k2] and (v.JobRestrict and v.JobRestrict[new] or v.Vehicles[k2].JobRestrict and v.Vehicles[k2].JobRestrict[new]) then
                                    PlyOptions.Vehicles[k2].Spawned = nil
                                    delete = true
                                    VCPrint('player "' .. ply:Nick() .. '" has changed jobs and can no longer have vehicle: "' .. (v2.VC_Name or "Unknown") .. '", removing it.')
                                    VC.log('<Car dealer> Player: ' .. VC.log_getPlayer(ply) .. ' can not have vehicle ' .. VC.log_highLight((v2.Name or '"Unknown"') .. ' (' .. (v2.Category or '"Unknown"') .. ')') .. ' in job: "' .. VC.log_highLight(new) .. '".', "CD")
                                    VCEffect(v2:GetPos() + Vector(0, 0, 50))
                                    v2:Remove()
                                end
                            end
                        end
                    end
                end

                if delete then VC.CD.SetPlayerOptions(ply, PlyOptions) end
            end
        end
    end
end

hook.Add("OnPlayerChangedTeam", "VC_OnPlayerChangedTeam", function(ply, old, new) VC.CD.ChangedJobs(ply, team.GetName(old), team.GetName(new)) end)

local mapName = string.lower(game.GetMap() or "Unknown")
file.CreateDir("vcmod/repairman")
file.CreateDir("vcmod/repairman/maps")
util.AddNetworkString("VC_RM_Add")
util.AddNetworkString("VC_RM_Refresh")
util.AddNetworkString("VC_RM_Send_Menu_Open")
util.AddNetworkString("VC_RM_SendPurchases")
util.AddNetworkString("VC_RM_open_menu_main_pre")
util.AddNetworkString("VC_RM_open_menu_main")
util.AddNetworkString("VC_RM_UpdateInfo")
util.AddNetworkString("VC_RM_RequestOpen")
util.AddNetworkString("VC_RM_TracePos")
util.AddNetworkString("VC_RM_Delete")
util.AddNetworkString("VC_RM_DoneEditting")
util.AddNetworkString("VC_RM_RequestInfo_Import_NPC_OtherInfo")
util.AddNetworkString("VC_RM_RequestInfo_Import_NPC")
util.AddNetworkString("VC_RM_SendInfo_Import_NPC")
util.AddNetworkString("VC_RM_SendInfo_Import_NPC_OtherInfo_Return")
net.Receive("VC_RM_TracePos", function(len, ply)
    if not VC.CanEditAdminSettings(ply) then return end
    local ent = net.ReadEntity()
    if IsValid(ent) then
        local Tbl = nil
        local dir = "vcmod/repairman/maps/" .. mapName .. ".txt"
        if file.Exists(dir, "DATA") then
            Tbl = util.JSONToTable(file.Read(dir, "DATA"))
            if Tbl and ent.VC_ID and Tbl[ent.VC_ID] then
                Tbl[ent.VC_ID].Pos = ply:GetEyeTraceNoCursor().HitPos
                Tbl[ent.VC_ID].Ang = Angle(0, (Tbl[ent.VC_ID].Pos - ply:GetPos()):Angle().y + 180, 0)
                ent:SetPos(Tbl[ent.VC_ID].Pos)
                ent:SetAngles(Tbl[ent.VC_ID].Ang)
                file.Write(dir, util.TableToJSON(Tbl, true))
                ent.VC_Options = table.Copy(Tbl[ent.VC_ID])
                VCPopup(ply, 'PosChanged', "check")
            end
        end
    else
        VCPopup(ply, "Error", "cross")
    end
end)

net.Receive("VC_RM_RequestOpen", function(len, ply)
    if not IsValid(ply) then return end
    local ent = net.ReadEntity()
    if IsValid(ply) and IsValid(ent) and VC.CanEditAdminSettings(ply) then
        VC.RM.RequestOpen(ent, ply)
    else
        VCPopup(ply, "Error", "cross")
    end
end)

net.Receive("VC_RM_RequestInfo_Import_NPC", function(len, ply)
    if not VC.CanEditAdminSettings(ply) then return end
    local ent = net.ReadEntity()
    if IsValid(ply) and IsValid(ent) then
        net.Start("VC_RM_SendInfo_Import_NPC")
        net.WriteEntity(ent)
        net.WriteTable(ent.VC_Options)
        net.Send(ply)
    end
end)

net.Receive("VC_RM_RequestInfo_Import_NPC_OtherInfo", function(len, ply)
    if not VC.CanEditAdminSettings(ply) then return end
    local ent = net.ReadEntity()
    if IsValid(ent) then
        local TTbl = {}
        local List = file.Find("Data/vcmod/repairman/maps/*", "GAME")
        for k, v in pairs(List) do
            if v ~= mapName .. ".txt" then TTbl[string.gsub(v, ".txt", "")] = util.JSONToTable(file.Read("Data/vcmod/repairman/maps/" .. v, "GAME")) end
        end

        if table.Count(TTbl) == 0 then VCPopup(ply, "No NPC set on other maps.", "cross") end
        net.Start("VC_RM_SendInfo_Import_NPC_OtherInfo_Return")
        net.WriteEntity(ent)
        net.WriteTable(TTbl)
        net.Send(ply)
    end
end)

net.Receive("VC_RM_DoneEditting", function(len, ply)
    if not VC.CanEditAdminSettings(ply) then return end
    local ent, tbl, int, vcmsg = net.ReadEntity(), net.ReadTable(), net.ReadInt(8), net.ReadInt(8)
    if IsValid(ent) then
        ent:SetModel(tbl.Model)
        ent:SetNWString("VC_Name", tbl.Name)
        ent.VC_Name = tbl.Name
        ent.VC_Options = tbl
        VCEffect(ent:GetPos() + Vector(0, 0, 50))
        local Tbl = {}
        local dir = "vcmod/repairman/maps/" .. mapName .. ".txt"
        if file.Exists(dir, "DATA") then Tbl = util.JSONToTable(file.Read(dir, "DATA")) end
        Tbl[int] = tbl
        file.Write(dir, util.TableToJSON(Tbl, true))
        if vcmsg then VCPopup(ply, 'Successfully edited.', "check") end
        local log_start = '<Repair man> Player: ' .. VC.log_getPlayer(ply)
        VC.log(log_start .. ' has just finished editting Repair man: "' .. VC.log_highLight(tbl.Name) .. '".', "RM")
    end
end)

net.Receive("VC_RM_Delete", function(len, ply)
    if not VC.CanEditAdminSettings(ply) then return end
    local ent = net.ReadEntity()
    if IsValid(ent) then
        local int = ent.VC_ID
        ent:Remove()
        VCEffect(ent:GetPos() + Vector(0, 0, 50))
        local Tbl = {}
        local dir = "vcmod/repairman/maps/" .. mapName .. ".txt"
        if file.Exists(dir, "DATA") then Tbl = util.JSONToTable(file.Read(dir, "DATA")) end
        Tbl[int] = nil
        file.Write(dir, util.TableToJSON(Tbl, true))
        VCPopup(ply, 'Deleted', "check")
        local log_start = '<Repair man> Player: ' .. VC.log_getPlayer(ply)
        VC.log(log_start .. ' has just deleted a Repair man.', "RM")
    end
end)

function VC.RM.GetCost(ent, tbl)
    local cost = 0
    local time = 0
    for k, v in pairs(tbl) do
        local pinfo = VC.GetPartInfo(v[1])
        if v[1] == "engine" then
            local prc = ent.VC_HealthPerc
            if prc == 0 then
                time = time + pinfo.time
                cost = cost + pinfo.price
            else
                cost = cost + 0
                time = 5 + pinfo.time * (1 - prc) * 0.5
            end
        else
            cost = cost + pinfo.price
            time = time + pinfo.time
        end
    end

    cost = math.Round(cost + math.Round(time * (100 / 60)))
    return cost
end

function VC.RM.DeductForRepairs(ply, ent, tbl)
    local cost = VC.RM.GetCost(ent, tbl)
    if VC.CanAfford(ply, cost) then
        VC.RemoveMoney(ply, cost, "RMrepairs")
        VC.log('<Repair man> Player: ' .. VC.log_getPlayer(ply) .. ' has just been deducted ' .. VC.log_highLight(cost) .. ' for repairs.', "RM")
        return true
    end
end

function VC.RM.StopRepairs(ent)
    if ent.VC_RM_RepairingObjects then
        if IsValid(ent.VC_RM_RepairingObjects.ply) then
            VCPopup(ent.VC_RM_RepairingObjects.ply, "YourVehiclesRepairsFailed", "cross")
            local log_start = '<Repair man> Player: ' .. VC.log_getPlayer(ent.VC_RM_RepairingObjects.ply)
            VC.log(log_start .. ' has just failed repairs by a Repair man "' .. VC.log_highLight(ent.VC_Name) .. '".', "RM")
        end

        ent.VC_RM_RepairingObjects = nil
        if ent.VC_RM_Fixing then
            VC.RemoveWrenchPart(ent, ent.VC_RM_Fixing.type, ent.VC_RM_Fixing.int)
            ent.VC_RM_Fixing = nil
        end
    end
end

function VC.RM.RepairObject(ent, obj, int, npc, ply)
    if not ent.VC_RM_RepairingObjects then
        ent.VC_RM_RepairingObjects = {
            npc = npc,
            ply = ply,
            objects = {},
            timecheck = CurTime() + 1
        }
    end

    if ent.VC_RM_RepairingObjects.npc == npc then
        if not ent.VC_RM_RepairingObjects.objects[obj .. (int or 1)] then
            local time = VC.GetPartInfo(obj).time
            if obj == "engine" then
                int = 1
                local prc = ent.VC_Health / ent.VC_MaxHealth
                if prc > 0 then time = 5 + (1 - ent.VC_Health / ent.VC_MaxHealth) * time * 0.5 end
            end

            ent.VC_RM_RepairingObjects.objects[obj .. (int or 1)] = {obj, int or 1, time}
        end
    end
end

function VC.HandleRepairMan_Slow(ent)
    local olfix = ent.VC_RM_Fixing
    if ent.VC_RM_RepairingObjects then
        if not ent.VC_RM_Fixing then
            if ent.VC_RM_RepairingObjects.objects["engine"] then
                local pos = ent:WorldToLocal(VC.getEnginePos(ent))
                ent.VC_RM_Fixing = {
                    type = "engine",
                    int = 1,
                    time_s = CurTime(),
                    time = ent.VC_RM_RepairingObjects.objects["engine1"][3],
                    pos = pos
                }
            else
                for k, v in SortedPairs(ent.VC_RM_RepairingObjects.objects) do
                    ent.VC_RM_Fixing = {
                        type = v[1],
                        int = v[2],
                        time_s = CurTime(),
                        time = v[3],
                        pos = VC.GetObjectPos(ent, v[1], v[2], 137)
                    }
                end
            end
        else
            if CurTime() >= (ent.VC_RM_Fixing.time_s + ent.VC_RM_Fixing.time) then
                VC.RepairPart(ent, ent.VC_RM_Fixing.type, ent.VC_RM_Fixing.int, DPnt)
                ent.VC_RM_RepairingObjects.objects[ent.VC_RM_Fixing.type .. ent.VC_RM_Fixing.int] = nil
                if table.Count(ent.VC_RM_RepairingObjects.objects) == 0 then
                    if IsValid(ent.VC_RM_RepairingObjects.ply) then
                        VCPopup(ent.VC_RM_RepairingObjects.ply, "YourVehiclesRepairsComplete", "info", 4)
                        local log_start = '<Repair man> Player: ' .. VC.log_getPlayer(ent.VC_RM_RepairingObjects.ply)
                        VC.log(log_start .. ' has just completed the repairs by a Repair man "' .. VC.log_highLight(ent.VC_Name) .. '".', "RM")
                    end

                    ent.VC_RM_RepairingObjects = nil
                end

                ent.VC_RM_Fixing = nil
            end
        end

        if ent.VC_RM_RepairingObjects and CurTime() >= ent.VC_RM_RepairingObjects.timecheck then
            ent.VC_RM_RepairingObjects.timecheck = CurTime() + 1
            local dist = IsValid(ent.VC_RM_RepairingObjects.npc) and ent.VC_RM_RepairingObjects.npc:GetPos():Distance(ent:GetPos())
            if not dist or dist > (VC.getSetting("RM_Distance", 350) + 50) then VC.RM.StopRepairs(ent) end
        end
    end

    if olfix ~= ent.VC_RM_Fixing then
        if ent.VC_RM_Fixing and (ent.VC_RM_Fixing.type ~= "engine" or ent.VC_Destroyed) then
            local ename = ent.VC_RM_Fixing.type
            if ename == "wheel" then ename = "tire" end
            local pent = ents.Create("vc_pickup_" .. ename)
            if IsValid(pent) then
                pent:SetPos(ent:GetPos() + ent:GetUp() * 25)
                pent:Spawn()
                pent:Activate()
                VC.CodeEnt.Pickup_carpart.Attach(pent, ent, ent.VC_RM_Fixing.type, ent.VC_RM_Fixing.type == "engine" and 1 or ent.VC_RM_Fixing.int)
            end
        end

        timer.Simple(0.1, function()
            net.Start("VC_RM_UpdateInfo")
            net.WriteEntity(ent)
            net.WriteTable(ent.VC_RM_Fixing or {})
            net.Broadcast()
        end)
    end
end

function VC.RM.RepairObjects(ent, tbl, npc, ply)
    for k, v in pairs(tbl) do
        VC.RM.RepairObject(ent, v[1], v[2], npc, ply)
    end
end

net.Receive("VC_RM_SendPurchases", function(len, ply)
    if not IsValid(ply) then return end
    local ent = net.ReadEntity()
    local npc = net.ReadEntity()
    local tbl = net.ReadTable()
    if not IsValid(ent) or not IsValid(npc) or not tbl then return end
    if VC.isPlayerRestricted(ply, nil, ent.VC_Options) then return false end
    if not VC.RM.DeductForRepairs(ply, ent, tbl) then return end
    VC.RM.RepairObjects(ent, tbl, npc, ply)
end)

net.Receive("VC_RM_Refresh", function(len, ply)
    if not VC.CanEditAdminSettings(ply) then return end
    VC.RM.NPCsRespawn()
    VCPopup(ply, 'RMsPlaced', "info", 4)
    local log_start = '<Repair man> Player: ' .. VC.log_getPlayer(ply)
    VC.log(log_start .. ' is respawning all Repair men.', "RM")
end)

net.Receive("VC_RM_Add", function(len, ply)
    if not VC.CanEditAdminSettings(ply) then return end
    local Tbl = {}
    local dir = "vcmod/repairman/maps/" .. mapName .. ".txt"
    if file.Exists(dir, "DATA") then Tbl = util.JSONToTable(file.Read(dir, "DATA")) or {} end
    local NPCTbl = table.Copy(VC.RM.Default)
    NPCTbl.Pos = ply:GetEyeTraceNoCursor().HitPos
    NPCTbl.Ang = Angle(0, (NPCTbl.Pos - ply:GetPos()):Angle().y + 180, 0)
    table.insert(Tbl, NPCTbl)
    file.Write(dir, util.TableToJSON(Tbl, true))
    VCPopup(ply, 'RMPlaced', "info", 4)
    local log_start = '<Repair man> Player: ' .. VC.log_getPlayer(ply)
    VC.log(log_start .. ' has added a new Repair man.', "RM")
    VC.RM.NPCsRespawn()
end)

net.Receive("VC_RM_open_menu_main_pre", function(len, ply)
    if not IsValid(ply) then return end
    local ent = net.ReadEntity()
    local npc = net.ReadEntity()
    local npctbl = net.ReadTable()
    local npcint = net.ReadInt(4)
    if IsValid(ent) and IsValid(npc) then
        net.Start("VC_RM_open_menu_main")
        net.WriteEntity(ent)
        net.WriteEntity(npc)
        net.WriteTable(npctbl)
        net.WriteInt(npcint, 4)
        net.WriteTable(ent.VC_RM_RepairingObjects or {})
        net.WriteString(ent.VC_RM_Fixing and (ent.VC_RM_Fixing.type .. ent.VC_RM_Fixing.int) or "")
        net.Send(ply)
    end
end)

function VC.RM.RequestOpen(ent, ply)
    if IsValid(ply) and IsValid(ent) then
        if hook.Call("VC_CanUseRepairMan", GAMEMODE, ply, ent) == false or hook.Call("VC_RM_canUse", GAMEMODE, ent, ply) == false then
            VCPopup(ply, "AccessRestricted", "cross")
            return
        end

        if not ply.VC_UseEntityTimer or CurTime() >= ply.VC_UseEntityTimer then
            if not VC.getSetting("RM_Enabled") then
                VCPopup(ply, "AccessRestricted", "cross")
                return
            end

            if not ent.VC_Options then
                VCEffect(ent:GetPos() + Vector(0, 0, 50))
                ent:Remove()
                return
            end

            net.Start("VC_RM_Send_Menu_Open")
            net.WriteEntity(ent)
            net.WriteTable(ent.VC_Options)
            net.WriteInt(ent.VC_ID, 8)
            net.WriteInt(VC.CanEditAdminSettings(ply, true) and 1 or 0, 4)
            net.Send(ply)
            ply.VC_UseEntityTimer = CurTime() + 0.5
        end
    end
end

function VC.RM.NPCsRemove()
    if VC.RM.PlacedTbl then
        for k, v in pairs(VC.RM.PlacedTbl) do
            if IsValid(v) then
                v:Remove()
                VC.RM.PlacedTbl[k] = nil
            end
        end
    end
end

function VC.RM.Think(ent)
    if not ent.VC_HumTime then ent.VC_HumTime = CurTime() + math.Rand(25, 50) end
    if VC.Settings and VC.getSetting("RM_Hum") and CurTime() >= ent.VC_HumTime then
        VC.SoundEmit(ent, math.random(0, 1) == 0 and "vo/eli_lab/al_hums.wav" or "vo/eli_lab/al_hums_b.wav", nil, 70, 0.7)
        ent.VC_HumTime = CurTime() + math.Rand(40, 60)
    end
end

local function convertToLowerCase()
    local map = game.GetMap()
    local dir = "vcmod/repairman/maps/" .. map .. ".txt"
    if map ~= mapName then
        VCPrint("RM: older data standart found, converting.")
        local data = file.Read(dir, "DATA")
        file.Write("vcmod/repairman/maps/" .. mapName .. ".txt", data)
        file.Delete(dir)
    end
end

function VC.RM.NPCsPlace()
    VC.RM.PlacedTbl = {}
    local dir = "vcmod/repairman/maps/" .. mapName .. ".txt"
    if file.Exists(dir, "DATA") then
        convertToLowerCase()
        local tbl = util.JSONToTable(file.Read(dir, "DATA"))
        if tbl then
            for k, v in pairs(tbl) do
                local ent = ents.Create("vc_npc_repair")
                if not IsValid(ent) then
                    VCPrint("VCMod ERROR: nil vc_npc_repair from persistance replace")
                    return
                end

                ent:SetNWString("VC_Name", v.Name)
                ent:SetModel(v.Model)
                ent:SetPos(v.Pos)
                ent:SetAngles(v.Ang)
                ent.Think = function() VC.RM.Think(ent) end
                ent.VC_Options = table.Copy(v)
                ent.VC_ID = k
                ent:SetNWInt("VC_Int", ent.VC_ID)
                ent:Spawn()
                VC.RM.PlacedTbl[k] = ent
            end
        end

        VCPrint("All repair man NPC's have been placed on the map.")
        VC.log('<Repair man> all Repair men have been placed on the map.', "RM")
    end
end

function VC.RM.NPCsRespawn()
    VC.RM.NPCsRemove()
    VC.RM.NPCsPlace()
end

timer.Simple(1, VC.RM.NPCsRespawn)

function VC.SettingsSetNew(tbl)
    local ret = {}
    if tbl then
        ret = tbl
    else
        VCPrint("ERROR! Failed to load settings file. This issue is most likely caused by not allowing to write to garrysmod/data/vcmod directory.")
    end

    VC.Settings = table.Copy(ret)
    if SERVER then VC.ServerSettings = table.Copy(ret) end
    return ret
end

if SERVER then
    function VC.Override_Controls_Read()
        VC.Override_Controls = util.KeyValuesToTable(file.Read("data/vcmod/override_controls.txt", "GAME") or "")
    end

    function VC.Override_Controls_Create()
        local CntTbl = {}
        file.Write("vcmod/override_controls.txt", util.TableToKeyValues(CntTbl))
        VC.Override_Controls_Read()
    end

    if not file.Exists("vcmod/override_controls.txt", "DATA") then
        VC.Override_Controls_Create()
    else
        VC.Override_Controls_Read()
    end

    util.AddNetworkString("VC_SendSettingsToServer_Override_Controls")
    net.Receive("VC_SendSettingsToServer_Override_Controls", function(len, ply)
        if not VC.CanEditAdminSettings(ply) then return end
        local Tbl = net.ReadTable()
        if not Tbl then return end
        for k, v in pairs(Tbl) do
            if not v.use or v.use ~= "1" then Tbl[k] = nil end
        end

        VC.Override_Controls = Tbl
        file.Write("vcmod/override_controls.txt", util.TableToKeyValues(Tbl))
        VC.Stream_Override_Controls()
        VC.log('<General> Player: ' .. VC.log_getPlayer(ply) .. ' has altered VCMod administrative override conntrols settings.', "General")
    end)

    util.AddNetworkString("VC_SendToClient_Options")
    util.AddNetworkString("VC_SendToClient_Logging")
    util.AddNetworkString("VC_SendToClient_Logging_Spec")
    util.AddNetworkString("VC_SendSettingsToServer")
    function VC.SettingsChanged()
        VC.Stream_SV_Settings()
    end

    local function CheckDefaults()
        local chng = false
        for k, v in pairs(VC.Settings_Defaults) do
            if VC.Settings[k] == nil then
                VC.Settings[k] = v
                chng = true
            end
        end

        if chng then VC.SettingsChanged() end
    end

    function VC.ResetSettings()
        file.Write("vcmod/settings_sv.txt", util.TableToJSON(VC.Settings_Defaults, true))
        VC.SettingsSetNew(VC.Settings_Defaults)
        VC.SettingsChanged()
        CheckDefaults()
    end

    function VC.LoadSettings()
        if file.Exists("vcmod/settings_sv.txt", "DATA") then
            VC.SettingsSetNew(table.Copy(util.JSONToTable(file.Read("vcmod/settings_sv.txt", "DATA"))))
            VC.SettingsChanged()
        else
            VC.ResetSettings()
        end

        CheckDefaults()
    end

    function VC.SaveSetting(k, v)
        hook.Call("VC_SettingChanged", GAMEMODE, k, v, VC.Settings[k] or v)
        hook.Call("VC_settingChanged", GAMEMODE, k, v, VC.Settings[k] or v)
    end

    VC.LoadSettings()
    timer.Simple(10, VC.SettingsChanged)
    function VC.GetSettings(ply)
        net.Start("VC_SendToClient_Options")
        net.WriteTable(VC.Settings)
        if ply then
            net.Send(ply)
        else
            net.Broadcast()
        end
    end

    concommand.Add("VC_ResetSettings", function(ply, cmd, arg) if VC.CanEditAdminSettings(ply) then VC.ResetSettings() end end)
    concommand.Add("VC_GetSettings_Sv", function(ply, cmd, arg) if VC.CanEditAdminSettings(ply) then VC.GetSettings(ply) end end)
    concommand.Add("VC_GetLogging_Data", function(ply, cmd, arg)
        if VC.CanEditAdminSettings(ply) then
            local data = {}
            for k, v in pairs(file.Find("vcmod/logs/*", "DATA")) do
                data[k] = string.gsub(v, ".txt", "")
            end

            net.Start("VC_SendToClient_Logging")
            net.WriteString(util.TableToJSON(data))
            if ply then
                net.Send(ply)
            else
                net.Broadcast()
            end
        end
    end)

    concommand.Add("VC_GetLogging_Data_Spec", function(ply, cmd, arg)
        if VC.CanEditAdminSettings(ply) and arg[1] then
            local contents = file.Read("vcmod/logs/" .. arg[1] .. ".txt", "DATA")
            if contents then
                net.Start("VC_SendToClient_Logging_Spec")
                net.WriteString(contents)
                if ply then
                    net.Send(ply)
                else
                    net.Broadcast()
                end
            end
        end
    end)

    concommand.Add("VC_GetSettings_Sv_Override_Controls", function(ply, cmd, arg) if VC.CanEditAdminSettings(ply) then VC.Stream_Override_Controls(ply) end end)
    function VC.Settings_Save(tbl)
        if not tbl then return end
        file.Write("vcmod/settings_sv.txt", util.TableToJSON(tbl, true))
    end

    net.Receive("VC_SendSettingsToServer", function(len, ply)
        if not VC.CanEditAdminSettings(ply) then return end
        local Tbl = net.ReadTable()
        if not Tbl then return end
        for k, v in pairs(Tbl) do
            if VC.Settings[k] ~= v then VC.SaveSetting(k, v) end
        end

        VC.SettingsSetNew(Tbl)
        CheckDefaults()
        VC.SettingsChanged()
        VC.Settings_Save(Tbl)
        VC.log('<General> Player: ' .. VC.log_getPlayer(ply) .. ' has altered VCMod administrative settings.', "General")
    end)
else
    function VC.SettingsChanged()
        if not VC.Material then return end
        VC.HD_Texture = VC.Material.HD2
        if VC.getSetting("Light_Type") == 2 then VC.HD_Texture = VC.Material.HD end
    end

    local function CheckDefaults()
        local chng = false
        for k, v in pairs(VC.Settings_Defaults) do
            if VC.Settings[k] == nil then
                VC.Settings[k] = v
                chng = true
            end
        end

        if chng then VC.SettingsChanged() end
    end

    function VC.ResetSettings()
        file.Write("vcmod/settings_cl.txt", util.TableToJSON(VC.Settings_Defaults, true))
        VC.SettingsSetNew(VC.Settings_Defaults)
        VC.SettingsChanged()
        CheckDefaults()
    end

    function VC.LoadSettings()
        if file.Exists("vcmod/settings_cl.txt", "DATA") then
            VC.SettingsSetNew(table.Copy(util.JSONToTable(file.Read("vcmod/settings_cl.txt", "DATA"))))
            VC.SettingsChanged()
        else
            VC.ResetSettings()
        end

        CheckDefaults()
    end

    function VC.SaveSetting(k, v)
        hook.Call("VC_SettingChanged", GAMEMODE, k, v, VC.Settings[k] or v)
        hook.Call("VC_settingChanged", GAMEMODE, k, v, VC.Settings[k] or v)
        if k and v ~= nil then
            local Tbl = {}
            if file.Exists("vcmod/settings_cl.txt", "DATA") then
                Tbl = util.JSONToTable(file.Read("vcmod/settings_cl.txt", "DATA"))
            else
                Tbl = VC.Settings_Defaults
            end

            if not Tbl then return end
            Tbl[k] = v
            VC.SettingsSetNew(Tbl)
            CheckDefaults()
            VC.SettingsChanged()
            file.Write("vcmod/settings_cl.txt", util.TableToJSON(Tbl, true))
        end
    end

    VC.LoadSettings()
    concommand.Add("VC_SaveSetting_Cl", function(ply, cmd, arg) if arg and arg[1] and arg[2] then VC.SaveSetting(arg[1], arg[2]) end end)
    VC.lngLoadLocal()
    VC.lngReload()
    VC.Lng_Get()
    VCPrint("Initialized clientside language data.")
    function VC.Controls_ReadScript()
        VC.Controls_List = util.KeyValuesToTable(file.Read("data/vcmod/controls.txt", "GAME") or "")
        for k, v in pairs(VC.Controls_Main) do
            if not VC.Controls_List[v.cmd] then
                VC.Controls_List[v.cmd] = {
                    key = v.default.key,
                    hold = v.default.hold
                }
            end
        end
    end

    function VC.Controls_CreateScript()
        local CntTbl = {}
        for _, Ctr in pairs(VC.Controls_Main) do
            if not Ctr.default.hold then Ctr.default.hold = "0" end
            CntTbl[Ctr.cmd] = Ctr.default
        end

        file.Write("vcmod/controls.txt", util.TableToKeyValues(CntTbl))
        VC.Controls_ReadScript()
    end

    if vcmod1 or vcmod1_els then
        if not file.Exists("vcmod/controls.txt", "DATA") then
            VC.Controls_CreateScript()
        else
            VC.Controls_ReadScript()
        end
    end

    hook.Add("PostDrawTranslucentRenderables", "VC_PostDrawTranslucentRenderables_Updater", function()
        net.Start("VC_RequestGlobalData")
        net.SendToServer()
        hook.Remove("PostDrawTranslucentRenderables", "VC_PostDrawTranslucentRenderables_Updater")
    end)
end

function VC.GetDataGeneral(mdl)
    local ret = nil
    if not VC_fremmannidinaxuyGen then
        if VC.globalODGen_LoadLocal then
            VC.globalODGen_LoadLocal()
        else
            VC_fremmannidinaxuyGen = {}
        end
    end
    return VC_fremmannidinaxuyGen[mdl]
end

if VC.Extra_Modules then
    for k, v in pairs(VC.Extra_Modules) do
        if v.init_postLoad and not v.inited_postLoad then
            v.inited_postLoad = true
            v.init_postLoad()
        end
    end
end

function VC.log_removeOld(time)
    if not time then time = 60 * 60 * 24 * 31 end
    local count = 0
    local data = {}
    for k, v in pairs(file.Find("vcmod/logs/*", "DATA")) do
        data[k] = string.gsub(v, ".txt", "")
    end

    for k, v in pairs(data) do
        local var = string.Explode("(", v)[2]
        if var then
            local fileTime = string.Explode(")", var)[1]
            if fileTime then
                fileTime = tonumber(fileTime)
                if fileTime and type(fileTime) == "number" and fileTime < (os.time() - time) then
                    count = count + 1
                    file.Delete("vcmod/logs/" .. v .. ".txt")
                end
            end
        end
    end

    if count > 0 then VCPrint("Removed " .. count .. " old log files that were over a month old.") end
end

VC.log_removeOld()
if not VC_fremmannidinaxuy then VC_fremmannidinaxuy = {} end

local meta = FindMetaTable("Player")
if SERVER then
    function meta:VC_CD_getVehicleData()
        return VC.CD.GetPlayerOptions(self)
    end

    function meta:VC_CD_getOwnedVehicleData(ID)
        local ret = nil
        local data = VC.CD.GetPlayerOptions(self)
        if ID and data.Vehicles and data.Vehicles[ID] then ret = data.Vehicles[ID] end
        return ret
    end

    function meta:VC_CD_addVehicle(ID)
        return VC.CD.addVehicle(self, ID, {}, true)
    end

    function meta:VC_CD_removeVehicle(ID)
        return VC.CD.removeVehicle(self, ID, true)
    end
end

local meta = FindMetaTable("Entity")
function meta:VC_CD_getInfo()
    return VC.CD_getInfo(self)
end

function meta:VC_RM_getInfo()
    return VC.RM_getInfo(self)
end

local meta = FindMetaTable("Vehicle")
function meta:VC_fuelGetType()
    local ftype = self:GetNWInt("VC_FuelType", 0)
    return ftype, VC.FuelTypes[ftype].name
end

function meta:VC_getFuel(perc)
    local val = VC.getFuel(self)
    if perc then
        return val / VC.getFuelMax(self) * 100
    else
        return val
    end
end

meta.VC_GetFuel = meta.VC_getFuel
meta.VC_fuelGet = meta.VC_getFuel
function meta:VC_getMaxFuel()
    return VC.getFuelMax(self)
end

meta.VC_GetMaxFuel = meta.VC_getMaxFuel
meta.VC_fuelGetMax = meta.VC_getMaxFuel
function meta:VC_fuelSetMax(val)
    return VC.setFuelMax(val)
end

function meta:VC_getHealth(perc)
    if not VC.getServerSetting("Damage") then return 100 end
    if CLIENT then
        return self:GetNWInt("VC_HealthPerc", 1) * 100
    else
        if perc then
            return (self.VC_HealthPerc or 1) * 100
        else
            return self.VC_Health
        end
    end
end

meta.VC_GetHealth = meta.VC_getHealth
function meta:VC_getMaxHealth()
    return self.VC_MaxHealth
end

meta.VC_GetMaxHealth = meta.VC_getMaxHealth
meta.VC_getHealthMax = meta.VC_getMaxHealth
function meta:VC_CD_getVehicleID()
    return VC.CD.getVehicleID(self)
end

function meta:VC_CD_getVehicleIDFromData()
    return VC.CD.getVehicleIDFromData(self)
end

function VC_CD_getVehicleDataFromID(val)
    return VC.CD.getVehicleDataFromID(val)
end

function meta:VC_getName(default)
    return VC.getName(self, default)
end

meta.VC_GetName = meta.VC_getName
function meta:VC_getSpeedKmH()
    local ent = self
    if self.VC_ExtraSeat then
        local prt = self:GetParent()
        if IsValid(prt) then ent = prt end
    end

    local vel = ent:GetVelocity():Dot(CLIENT and ent:GetRight() or ent:GetForward())
    return vel and VC.VelocityToKmH(vel) or 0
end

meta.VC_GetSpeedKmH = meta.VC_getSpeedKmH
function VC_getCurrency()
    return VC.getCurCurrency()
end

function VC_fuelGetPrice(ftype)
    if not ftype then ftype = 1 end
    return math.Round(VC.getServerSetting("Fuel_PPL_" .. ftype, 1), 2)
end

function VC_getSettings()
    return VC.Settings
end

VC_GetSettings = VC_getSettings
function VC_setSettings(tbl)
    VC.SettingsSetNew(tbl)
    VC.SettingsChanged()
end

VC_SetSettings = VC_setSettings
function meta:VC_getDamagedParts()
    local tbl = {}
    if self.VC_DamagedObjects then
        tbl = {}
        if self.VC_DamagedObjects.wheel then tbl.wheel = table.Copy(self.VC_DamagedObjects.wheel) end
        if self.VC_DamagedObjects.light then tbl.light = table.Copy(self.VC_DamagedObjects.light) end
        if self.VC_DamagedObjects.exhaust then tbl.exhaust = table.Copy(self.VC_DamagedObjects.exhaust) end
    end
    return tbl
end

meta.VC_GetDamagedParts = meta.VC_getDamagedParts
function meta:VC_partIsDamaged(val)
    return VC.ObjectIsDamaged(self, val)
end

function meta:VC_getStates()
    return self.VC_States or {}
end

meta.VC_GetStates = meta.VC_getStates
function meta:VC_setStates(val)
    self.VC_States = val
end

meta.VC_SetStates = meta.VC_setStates
function meta:VC_setRunningLights(on)
    if on then
        return VC.RunningLightsOn(self)
    else
        return VC.RunningLightsOff(self)
    end
end

meta.VC_SetRunningLights = meta.VC_setRunningLights
function meta:VC_setFogLights(on)
    if on then
        return VC.FogLightsOn(self)
    else
        return VC.FogLightsOff(self)
    end
end

meta.VC_SetFogLights = meta.VC_setFogLights
function meta:VC_setHazardLights(on)
    if on then
        return VC.HazardLightsOn(self)
    else
        return VC.HazardLightsOff(self)
    end
end

meta.VC_SetHazardLights = meta.VC_setHazardLights
function meta:VC_setHighBeams(on)
    if on then
        return VC.HighBeamsOn(self)
    else
        return VC.HighBeamsOff(self)
    end
end

meta.VC_SetHighBeams = meta.VC_setHighBeams
function meta:VC_setLowBeams(on)
    if on then
        return VC.LowBeamsOn(self)
    else
        return VC.LowBeamsOff(self)
    end
end

meta.VC_SetLowBeams = meta.VC_setLowBeams
function meta:VC_setTurnLightLeft(on)
    if on then
        return VC.TurnLightLeftOn(self)
    else
        return VC.TurnLightLeftOff(self)
    end
end

meta.VC_SetTurnLightLeft = meta.VC_setTurnLightLeft
function meta:VC_setTurnLightRight(on)
    if on then
        return VC.TurnLightRightOn(self)
    else
        return VC.TurnLightRightOff(self)
    end
end

meta.VC_SetTurnLightRight = meta.VC_setTurnLightRight
function meta:VC_setHorn(on)
    if on then
        return VC.HornOn(self)
    else
        return VC.HornOff(self)
    end
end

function meta:VC_setCruiseControl(on)
    if on then
        return VC.CruiseOn(self)
    else
        return VC.CruiseOff(self)
    end
end

meta.VC_SetCruiseControl = meta.VC_setCruiseControl
function meta:VC_setELSManual(on)
    if on then
        return VC.ELS_ManualOn(self)
    else
        return VC.ELS_ManualOff(self)
    end
end

meta.VC_SetELSManual = meta.VC_setELSManual
function meta:VC_setELSLights(on)
    if on then
        return VC.ELS_LightsOn(self)
    else
        return VC.ELS_LightsOff(self)
    end
end

meta.VC_SetELSLights = meta.VC_setELSLights
function meta:VC_setELSLightsCycle()
    return VC.ELS_Lht_Cycle(self)
end

meta.VC_SetELSLightsCycle = meta.VC_setELSLightsCycle
function meta:VC_setELSSound(on)
    if on then
        return VC.ELS_SoundOn(self)
    else
        return VC.ELS_SoundOff(self)
    end
end

meta.VC_SetELSSound = meta.VC_setELSSound
function meta:VC_setELSSoundCycle()
    return VC.ELS_Snd_Cycle(self)
end

meta.VC_SetELSSoundCycle = meta.VC_setELSSoundCycle
function meta:VC_getELSLightsOn()
    return VC.is_ELSLightsOn(self)
end

meta.VC_GetELSLightsOn = meta.VC_getELSLightsOn
function meta:VC_getELSSoundOn()
    return VC.is_ELSSoundOn(self)
end

meta.VC_GetELSSoundOn = meta.VC_getELSSoundOn
function meta:VC_getCruise(val)
    return VC.getCruise(self)
end

function meta:VC_isTrailer(val)
    return VC.isTrailer(self)
end

function meta:VC_getTruck(val)
    return VC.getTruck(self)
end

function meta:VC_getTrailer(val)
    return VC.getTrailer(self)
end

function meta:VC_getAttachedTo(val)
    return VC.getAttachedTo(self)
end

function meta:VC_isTrailerSupported(val)
    return VC.isTrailerSupported(self)
end

function meta:VC_setOverride(key, val)
    return VC.setOverride(self, key, val)
end

function meta:VC_getOverride(key)
    return VC.getOverride(self, key)
end

function meta:VC_isFuelConsumptionEnabled()
    return VC.isFuelConsumptionEnabled(self)
end

if SERVER then
    function meta:VC_getVehiclePersistanceData()
        return VC.getVehiclePersistanceData(self)
    end

    function meta:VC_setVehiclePersistanceData(val)
        return VC.setVehiclePersistanceData(self, val)
    end

    function meta:VC_lock()
        return VC.Lock(self)
    end

    meta.VC_Lock = meta.VC_lock
    function meta:VC_getExitData(pos)
        local data, found = VC.getExitData(self, pos)
        return found and data[1]
    end

    function meta:VC_UnLock()
        return VC.UnLock(self)
    end

    meta.VC_unLock = meta.VC_UnLock
    function meta:VC_isLocked()
        return VC.IsLocked(self)
    end

    meta.VC_IsLocked = meta.VC_isLocked
    function meta:VC_setDamagedParts(tbl)
        if IsValid(self) then return VC.SetDamagedObjects(self, tbl) end
    end

    meta.VC_SetDamagedParts = meta.VC_setDamagedParts
    function meta:VC_repairFull_Admin()
        if IsValid(self) then return VC.RepairVehicle_Admin(self) end
    end

    meta.VC_RepairFull_Admin = meta.VC_repairFull_Admin
    function meta:VC_damageFull_Admin()
        if IsValid(self) then return VC.DamageVehicle_Admin(self) end
    end

    meta.VC_DamageFull_Admin = meta.VC_damageFull_Admin
    function meta:VC_hasGodMode()
        if IsValid(self) then return self.VC_GodMode end
    end

    meta.VC_HasGodMode = meta.VC_hasGodMode
    function meta:VC_getSeatsAvailable()
        if IsValid(self) then return VC.SeatsGetAvailable(self) end
    end

    meta.VC_GetSeatsAvailable = meta.VC_getSeatsAvailable
    function meta:VC_setGodMode(val)
        if IsValid(self) then self.VC_GodMode = val end
    end

    meta.VC_SetGodMode = meta.VC_setGodMode
    function meta:VC_setHealth(val)
        if IsValid(self) then return VC.SetHealth(self, val) end
    end

    function meta:VC_setHealthMax(val)
        if IsValid(self) then return VC.SetHealthMax(self, val) end
    end

    function meta:VC_damageHealth(val)
        if IsValid(self) then return VC.DamageHealth(self, val) end
    end

    meta.VC_DamageHealth = meta.VC_damageHealth
    function meta:VC_repairHealth(val)
        if IsValid(self) then return VC.RepairHealth(self, val) end
    end

    meta.VC_RepairHealth = meta.VC_repairHealth
    function meta:VC_explodeEngine(silent)
        if IsValid(self) then return VC.ExplodeEngine(self, silent) end
    end

    meta.VC_ExplodeEngine = meta.VC_explodeEngine
    function meta:VC_doBackfire(damageHealth, damagedOnly)
        if IsValid(self) then return VC.DoBackFire(self, damageHealth, damagedOnly) end
    end

    function meta:VC_fuelCanisterSet(val)
        if IsValid(self) then
            if self:GetClass() == "vc_jerrycan" then
                self.VC_FuelAmount = val
                self:SetNWInt("VC_FuelAmount", self.VC_FuelAmount or 0)
            else
                self.VC_Storage = val
                self:SetNWInt("VC_Storage", val)
            end
        end
    end

    meta.VC_Fuel_Canister_Set = meta.VC_fuelCanisterSet
    function meta:VC_fuelSet(val)
        if IsValid(self) then return VC.setFuel(self, val) end
    end

    function meta:VC_fuelAdd(val)
        if IsValid(self) then return VC.Refuel(self, val) end
    end

    meta.VC_Fuel_Add = meta.VC_fuelAdd
    function meta:VC_fuelSetConsumptionMultiplier(val)
        self.VC_fuelConsumptionMultiplier = val
    end

    function meta:VC_fuelConsume(val)
        if IsValid(self) then return VC.FuelConsume(self, val) end
    end

    meta.VC_Fuel_Consume = meta.VC_fuelConsume
    function meta:VC_fuelConsumptionSetEnabled(val)
        if IsValid(self) then return VC.setFuelConsumptionEnabled(self, val) end
    end

    function meta:VC_setCruiseSpeed(val)
        return VC.CruiseSetSpeed(self, val)
    end

    meta.VC_SetCruiseSpeed = meta.VC_setCruiseSpeed
    function meta:VC_setHornCustom(snd, pitch, vol, lvl)
        return VC.SetHornCustom(self, snd, pitch, vol, lvl)
    end

    meta.VC_SetHornCustom = meta.VC_setHornCustom
    function meta:VC_detachTrailer()
        return VC.Trailer_Detach(self)
    end

    meta.VC_DetachTrailer = meta.VC_detachTrailer
    function meta:VC_clearSeats()
        return VC.ClearSeats(self)
    end

    meta.VC_ClearSeats = meta.VC_clearSeats
    function meta:VC_getPlayers()
        return VC.GetDrivers(self)
    end

    meta.VC_GetPlayers = meta.VC_getPlayers
    function meta:VC_CD_menuOpen(ply)
        return VC.CD.RequestOpen(self, ply)
    end

    meta.VC_Menu_CD_Open = meta.VC_CD_menuOpen
    function meta:VC_damagePart(obj, int, att, inf)
        return VC.DamagePart(self, obj, int, att, inf)
    end

    meta.VC_DamagePart = meta.VC_damagePart
    function meta:VC_repairPart(obj, int)
        return VC.RepairPart(self, obj, int)
    end

    meta.VC_RepairPart = meta.VC_repairPart
    function meta:VC_getLights(obj, int)
        return VC.getLights(self)
    end

    function meta:VC_CD_returnVehicle(force)
        return VC.CD.ReturnVehicle(self, force)
    end

    meta.VC_CarDealerReturnVehicle = meta.VC_CD_returnVehicle
else
    function meta:VC_CD_editMenuOpen()
        return VC.CD.open_menu_cardealer_edit(self)
    end

    meta.VC_Menu_CD_Edit_Open = meta.VC_CD_editMenuOpen
end

VCPrint('Server Side Loaded')