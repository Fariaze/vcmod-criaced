VCModels['models/crsk_autosporsche911_gt2_993_1995.mdl']	=	{
		em_state	=	5236594683,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		HealthEnginePosOvr	=	true,
		Date	=	"Sat Feb  9 10:08:28 2019",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-25.35000038147,-103.01000213623,11.300000190735),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(25.35000038147,-103.01000213623,11.300000190735),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		Indication	=	{
			fuel	=	{
				max	=	1,
				pp	=	"fuel_needle",
				top	=	1,
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(25,0,0),
				Pos	=	Vector(15.289999961853,3.4800000190735,26.709999084473),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(20,0,0),
				Pos	=	Vector(-14.520000457764,-33.150001525879,27.639999389648),
					},
				{
				Ang	=	Angle(20,0,0),
				Pos	=	Vector(14.520000457764,-33.150001525879,27.639999389648),
					},
				},
		HealthEnginePos	=	Vector(0,-83.400001525879,36.979999542236),
		DLT	=	3491063122,
		Lights	=	{
				{
				UseRunning	=	true,
				Pos	=	Vector(-14.439999580383,16.360000610352,47.150001525879),
				SpecMat	=	{
					Select	=	18,
					New	=	"models\crskautos\porsche\911_gt2_993_1995\interior_lod0_illum_on",
					Use	=	true,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				RunningColor	=	{
					r	=	195,
					b	=	210,
					a	=	255,
					g	=	255,
						},
					},
				{
				UseRunning	=	true,
				Pos	=	Vector(-9.2200002670288,16.360000610352,47.150001525879),
				SpecMat	=	{
					Select	=	26,
					New	=	"models\crskautos\shared\vmt\orange_illum_on",
					Use	=	true,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				RunningColor	=	{
					r	=	195,
					b	=	210,
					a	=	255,
					g	=	255,
						},
					},
				{
				UseRunning	=	true,
				Pos	=	Vector(-12.14999961853,16.360000610352,47.150001525879),
				SpecMat	=	{
					Select	=	27,
					New	=	"models\crskautos\porsche\911_gt2_993_1995\priborka_on",
					Use	=	true,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				RunningColor	=	{
					r	=	195,
					b	=	210,
					a	=	255,
					g	=	255,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-27.690000534058,87.879997253418,32.450000762939),
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseLowBeams	=	true,
				UseSprite	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Pos	=	Vector(27.690000534058,87.879997253418,32.450000762939),
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UsePrjTex	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UsePrjTex	=	true,
				Pos	=	Vector(-27.5,87.839996337891,28.64999961853),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseHighBeams	=	true,
				UseSprite	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				UsePrjTex	=	true,
				Pos	=	Vector(27.5,87.839996337891,28.64999961853),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseHighBeams	=	true,
				UseSprite	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseRunning	=	true,
				UseSprite	=	true,
				Pos	=	Vector(21.959999084473,102.44999694824,18.590000152588),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseRunning	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-21.959999084473,102.44999694824,18.590000152588),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				Dynamic	=	{
					Size	=	0.8,
					Brightness	=	2,
						},
				FogColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				UsePrjTex	=	true,
				Pos	=	Vector(25.450000762939,101.30999755859,18.469999313354),
				UseDynamic	=	true,
				UseFog	=	true,
				UseSprite	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				Dynamic	=	{
					Size	=	0.8,
					Brightness	=	2,
						},
				FogColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				UsePrjTex	=	true,
				Pos	=	Vector(-25.450000762939,101.30999755859,18.469999313354),
				UseDynamic	=	true,
				UseFog	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(35.700000762939,91.339996337891,16.420000076294),
					Pos2	=	Vector(31.889999389648,97.419998168945,19.709999084473),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(35.479999542236,91.309997558594,19.969999313354),
					Pos3	=	Vector(31.409999847412,97.660003662109,16.579999923706),
						},
				UseSprite	=	true,
				Pos	=	Vector(33.869998931885,93.51000213623,18.280000686646),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseSprite	=	true,
				Pos	=	Vector(-33.869998931885,93.51000213623,18.280000686646),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-35.700000762939,91.339996337891,16.420000076294),
					Pos2	=	Vector(-31.889999389648,97.419998168945,19.709999084473),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-35.479999542236,91.309997558594,19.969999313354),
					Pos3	=	Vector(-31.409999847412,97.660003662109,16.579999923706),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				Pos	=	Vector(38.840000152588,37.560001373291,34.430000305176),
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				Pos	=	Vector(-38.840000152588,37.560001373291,34.430000305176),
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(26.549999237061,-97.029998779297,25.299999237061),
					Pos2	=	Vector(20.540000915527,-97.139999389648,30.579999923706),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(26.930000305176,-95.809997558594,30.170000076294),
					Pos3	=	Vector(19.860000610352,-99.639999389648,25.520000457764),
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseBrake	=	true,
				UseSprite	=	true,
				Pos	=	Vector(23.840000152588,-98.470001220703,28.239999771118),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseRunning	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				UseBrake	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-26.549999237061,-97.029998779297,25.299999237061),
					Pos2	=	Vector(-20.540000915527,-97.139999389648,30.579999923706),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-26.930000305176,-95.809997558594,30.170000076294),
					Pos3	=	Vector(-19.860000610352,-99.639999389648,25.520000457764),
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-23.840000152588,-98.470001220703,28.239999771118),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseRunning	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(28.729999542236,-95.25,30.319999694824),
					Pos2	=	Vector(33.819999694824,-89.75,26.409999847412),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(28.079999923706,-98,26.35000038147),
					Pos3	=	Vector(32.310001373291,-89.819999694824,30.020000457764),
						},
				UseSprite	=	true,
				Pos	=	Vector(31.930000305176,-91.819999694824,28.25),
				UseDynamic	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-28.729999542236,-95.25,30.319999694824),
					Pos2	=	Vector(-33.819999694824,-89.75,26.409999847412),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-28.079999923706,-98,26.35000038147),
					Pos3	=	Vector(-32.310001373291,-89.819999694824,30.020000457764),
						},
				UseSprite	=	true,
				Pos	=	Vector(-31.930000305176,-91.819999694824,28.25),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseReverse	=	true,
				Pos	=	Vector(17,-100.81999969482,28.530000686646),
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseDynamic	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseReverse	=	true,
				Pos	=	Vector(-17,-100.81999969482,28.530000686646),
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseDynamic	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseSprite	=	true,
					},
				},
		Copyright	=	"Copyright © 2012-2019 VCMod (freemmaann). All Rights Reserved.",
		Fuel	=	{
			FuelLidPos	=	Vector(5.6300001144409,83.629997253418,29.680000305176),
			FuelLidUse	=	true,
			FuelType	=	0,
			Capacity	=	67,
			FuelTypeUse	=	true,
			Override	=	true,
				},
		Author	=	"DangerKiddy(DK) (76561198132964487)",
}