VCModels['models/bmwm3.mdl']	=	{
		em_state	=	5236594833,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Copyright	=	"DurkaTeam @ 2025 No rights reserved",
		Exhaust	=	{
				{
				Ang	=	Angle(35,-90,0),
				Pos	=	Vector(25.920000076294,-81.919998168945,12.340000152588),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(18.387300491333,5.534900188446,23.73690032959),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(-18.387300491333,-17.494600296021,23.73690032959),
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(18.389999389648,-17.489999771118,23.739999771118),
					},
				},
		DLT	=	3491063222,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				UseReverse	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				Pos	=	Vector(-20.489999771118,-85.980003356934,35.689998626709),
				UseSprite	=	true,
				UseDynamic	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				Pos	=	Vector(-28.069999694824,-86.180000305176,34.319999694824),
				UseSprite	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				FogColor	=	{
						255,
						55,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(-19.530000686646,-86.930000305176,33.200000762939),
				UseDynamic	=	true,
				UseFog	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(-28.280000686646,-85.569999694824,38.479999542236),
				UseDynamic	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1.2,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				FogColor	=	{
						220,
						225,
						255,
						},
				UsePrjTex	=	true,
				Pos	=	Vector(-28.209999084473,86.919998168945,15.699999809265),
				UseDynamic	=	true,
				UseFog	=	true,
				UseSprite	=	true,
				ProjTexture	=	{
					Size	=	2000,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				ProjTexture	=	{
					Forward	=	30,
					Size	=	2000,
					Angle	=	Angle(0,90,0),
						},
				UseHead	=	true,
				UsePrjTex	=	true,
				Pos	=	Vector(-25.719999313354,85.48999786377,28.290000915527),
				UseDynamic	=	true,
				HeadColor	=	{
						221,
						231,
						255,
						},
				UseSprite	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				Pos	=	Vector(-19.440000534058,87.419998168945,28.319999694824),
				UseSprite	=	true,
				RunningColor	=	{
						224.25,
						225.44,
						205.74,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(-30.520000457764,83.540000915527,27.89999961853),
				UseDynamic	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1.2,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				UseReverse	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				Pos	=	Vector(20.489999771118,-85.980003356934,35.689998626709),
				UseSprite	=	true,
				UseDynamic	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				Pos	=	Vector(28.069999694824,-86.180000305176,34.319999694824),
				UseSprite	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				FogColor	=	{
						255,
						55,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(19.530000686646,-86.930000305176,33.200000762939),
				UseDynamic	=	true,
				UseFog	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(28.280000686646,-85.569999694824,38.479999542236),
				UseDynamic	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1.2,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				FogColor	=	{
						220,
						225,
						255,
						},
				UsePrjTex	=	true,
				Pos	=	Vector(28.209999084473,86.919998168945,15.699999809265),
				UseDynamic	=	true,
				UseFog	=	true,
				UseSprite	=	true,
				ProjTexture	=	{
					Size	=	2000,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				ProjTexture	=	{
					Forward	=	30,
					Size	=	2000,
					Angle	=	Angle(0,90,0),
						},
				UseHead	=	true,
				UsePrjTex	=	true,
				Pos	=	Vector(25.719999313354,85.48999786377,28.290000915527),
				UseDynamic	=	true,
				HeadColor	=	{
						221,
						231,
						255,
						},
				UseSprite	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				Pos	=	Vector(19.440000534058,87.419998168945,28.319999694824),
				UseSprite	=	true,
				RunningColor	=	{
						224.25,
						225.44,
						205.74,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(30.520000457764,83.540000915527,27.89999961853),
				UseDynamic	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1.2,
				UseBlinkers	=	true,
					},
				},
		Date	=	"03/06/15 00:05:21",
		Author	=	"freemmaann",
}