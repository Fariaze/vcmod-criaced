VCModels['models/crsk_autosbmwi8_2015.mdl']	=	{
		em_state	=	5236594380,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		HealthEnginePosOvr	=	true,
		Date	=	"Thu Dec 28 15:05:31 2017",
		Copyright	=	"Copyright © 2012-2017 VCMod (freemmaann). All Rights Reserved.",
		ExtraSeats	=	{
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(21.170000076294,3.1800000667572,25.940000534058),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(-21.170000076294,-37.009998321533,23.940000534058),
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(21.170000076294,-37.009998321533,23.940000534058),
					},
				},
		DLT	=	3491062920,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(35.459999084473,-104.63999938965,44.759998321533),
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	45,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(35.369998931885,-107.30999755859,44.709999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.340000152588,-108.09999847412,44.380001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.330001831055,-108.79000091553,43.869998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.189998626709,-109.5299987793,43.060001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35,-110.29000091553,42.290000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.770000457764,-111.33999633789,41.279998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.569999694824,-111.81999969482,40.849998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.189998626709,-112.33000183105,40.470001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.610000610352,-112.98999786377,40.090000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.75,-113.59999847412,39.909999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.379999160767,-114.5,39.840000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.969999313354,-116.19999694824,39.950000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.35000038147,-117.80999755859,40.020000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(22.930000305176,-118.43000030518,40.159999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(21.770000457764,-118.81999969482,40.5),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(20.819999694824,-119.12000274658,41.060001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(19.969999313354,-119.34999847412,41.709999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(19.409999847412,-119.48999786377,42.220001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(18.739999771118,-119.66999816895,42.939998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(18.440000534058,-119.69000244141,43.380001068115),
								},
							{
							Pos	=	Vector(18.129999160767,-119.45999908447,43.860000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseSprite	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseBrake	=	true,
				Beta_Inner3D	=	true,
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(33.709999084473,-107.51000213623,43.479999542236),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	45,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(33.560001373291,-108.40000152588,42.520000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.409999847412,-109.06999969482,41.979999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.229999542236,-109.61000061035,41.639999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.950000762939,-110.18000030518,41.209999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.560001373291,-110.66999816895,40.799999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.049999237061,-111.12999725342,40.689998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.280000686646,-111.66000366211,40.540000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.110000610352,-112.37999725342,40.419998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.25,-113.31999969482,40.380001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.290000915527,-114.23999786377,40.419998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.020000457764,-114.86000061035,40.490001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(23.889999389648,-115.36000061035,40.610000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(23.090000152588,-115.76000213623,40.790000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(22.39999961853,-116.09999847412,41.130001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(21.780000686646,-116.41000366211,41.549999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(21.370000839233,-116.59999847412,41.919998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(21.059999465942,-116.69999694824,42.430000305176),
								},
							{
							Pos	=	Vector(20.780000686646,-116.65000152588,43.220001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
						},
				DD_Blnk_Run	=	true,
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	200,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(25.020000457764,99.419998168945,29.459999084473),
				RenderMLCenter	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	40,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(25.680000305176,99.279998779297,28.670000076294),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.25,99.069999694824,27.920000076294),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.760000228882,98.830001831055,27.530000686646),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.659999847412,98.400001525879,27.120000839233),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.450000762939,97.949996948242,26.950000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.39999961853,97.400001525879,26.950000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.870000839233,96.480003356934,27.079999923706),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.479999542236,95.23999786377,27.239999771118),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.830001831055,93.370002746582,27.489999771118),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.340000152588,92.019996643066,27.729999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.689998626709,90.819999694824,28),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(38.650001525879,89.800003051758,28.309999465942),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(39.330001831055,88.919998168945,28.590000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(39.939998626709,88.029998779297,29.059999465942),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(40.290000915527,87.470001220703,29.559999465942),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(40.669998168945,86.800003051758,30.200000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(40.930000305176,86.129997253418,30.85000038147),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(41.060001373291,85.459999084473,31.420000076294),
								},
							{
							Pos	=	Vector(41.200000762939,84.540000915527,32.240001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseSprite	=	true,
				RunningColor	=	{
					r	=	165,
					b	=	255,
					a	=	255,
					g	=	165,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
						},
				DD_Blnk_Run	=	true,
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	200,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(24.809999465942,100.06999969482,29.329999923706),
				UseBlinkers	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	40,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(25.469999313354,99.930000305176,28.540000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.129999160767,99.680000305176,27.670000076294),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.559999465942,99.51000213623,27.309999465942),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.280000686646,99.190002441406,26.930000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.139999389648,98.769996643066,26.690000534058),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.110000610352,98.209999084473,26.639999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.969999313354,97.599998474121,26.659999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.159999847412,96.089996337891,26.870000839233),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.5,94.25,27.129999160767),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.180000305176,92.75,27.280000686646),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.479999542236,91.610000610352,27.540000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(38.5,90.5,27.89999961853),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(39.279998779297,89.650001525879,28.10000038147),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(40.060001373291,88.610000610352,28.459999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(40.569999694824,87.769996643066,28.85000038147),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(41,87,29.430000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(41.400001525879,86,30.389999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(41.639999389648,85.069999694824,31.200000762939),
								},
							{
							Pos	=	Vector(41.810001373291,83.800003051758,32.349998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
					r	=	165,
					b	=	255,
					a	=	255,
					g	=	165,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(38.180000305176,88.720001220703,27.920000076294),
					UseColor	=	true,
					Pos2	=	Vector(33.720001220703,88.720001220703,32.380001068115),
					Color	=	{
						r	=	200,
						b	=	255,
						a	=	255,
						g	=	225,
							},
					Use	=	true,
					Pos1	=	Vector(38.180000305176,88.720001220703,32.380001068115),
					Pos3	=	Vector(33.720001220703,88.720001220703,27.920000076294),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				UsePrjTex	=	true,
				Pos	=	Vector(35.950000762939,88.720001220703,30.14999961853),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseSprite	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(32.599998474121,91.339996337891,27.409999847412),
					UseColor	=	true,
					Pos2	=	Vector(28.139999389648,91.339996337891,31.870000839233),
					Color	=	{
						r	=	200,
						b	=	255,
						a	=	255,
						g	=	225,
							},
					Use	=	true,
					Pos1	=	Vector(32.599998474121,91.339996337891,31.870000839233),
					Pos3	=	Vector(28.139999389648,91.339996337891,27.409999847412),
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(30.370000839233,91.339996337891,29.639999389648),
				RenderMLCenter	=	true,
				UseHighBeams	=	true,
				SpecMat	=	{
						},
				UsePrjTex	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(33.840000152588,-105.44000244141,44.520000457764),
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	45,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(33.790000915527,-108.13999938965,44.479999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.740001678467,-108.91999816895,44.290000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.560001373291,-109.63999938965,43.819999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.319999694824,-110.43000030518,43.209999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.110000610352,-111.12000274658,42.639999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.950000762939,-111.5299987793,42.310001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.709999084473,-112.04000091553,41.869998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.360000610352,-112.45999908447,41.569999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.889999389648,-112.83000183105,41.400001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.450000762939,-113.76000213623,41.209999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.590000152588,-114.69999694824,41.169998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.629999160767,-115.62000274658,41.209999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.360000610352,-116.23999786377,41.279998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.229999542236,-116.73999786377,41.400001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(23.430000305176,-117.13999938965,41.580001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(22.739999771118,-117.48000335693,41.919998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(21.989999771118,-117.81999969482,42.459999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(21.5,-118.01000213623,42.919998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(21.110000610352,-118.08999633789,43.340000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(20.889999389648,-118.0299987793,43.619998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(20.799999237061,-117.84999847412,43.779998779297),
								},
							{
							Pos	=	Vector(20.700000762939,-117.68000030518,43.849998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseSprite	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(20.409999847412,-118.76999664307,45.159999847412),
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	35,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(21.260000228882,-118,45.470001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(22.340000152588,-117.11000061035,45.700000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(23.530000686646,-116.16000366211,45.819999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.670000076294,-115.12999725342,45.930000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.940000534058,-113.98000335693,46.049999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.290000915527,-112.62000274658,46.209999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.489999771118,-111.51000213623,46.310001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.14999961853,-109.79000091553,46.439998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.510000228882,-107.98999786377,46.630001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.409999847412,-106.55000305176,46.759998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.830001831055,-105.12999725342,46.889999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.150001525879,-103.62000274658,47.080001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.25,-102.11000061035,47.240001678467),
								},
							{
							Pos	=	Vector(33.110000610352,-100,47.529998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseSprite	=	true,
				RenderMLCenter	=	true,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				SpecRec	=	{
					Pos4	=	Vector(28.729999542236,-117.73000335693,33.580001831055),
					AmountV	=	2,
					Pos2	=	Vector(19.270000457764,-120.93000030518,34.729999542236),
					AmountH	=	7,
					Use	=	true,
					Pos1	=	Vector(27.389999389648,-118.62000274658,34.919998168945),
					Pos3	=	Vector(20.920000076294,-120.08999633789,33.130001068115),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(24.159999847412,-119.31999969482,34.270000457764),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				ReverseColor	=	{
					r	=	200,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(28.729999542236,-117.73000335693,33.580001831055),
					UseColor	=	true,
					Pos2	=	Vector(19.270000457764,-120.93000030518,34.729999542236),
					Color	=	{
						r	=	200,
						b	=	255,
						a	=	255,
						g	=	225,
							},
					Use	=	true,
					Pos1	=	Vector(27.389999389648,-118.62000274658,34.919998168945),
					Pos3	=	Vector(20.920000076294,-120.08999633789,33.130001068115),
						},
				RenderMLCenter	=	true,
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-35.650001525879,-104.63999938965,44.790000915527),
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	45,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-35.560001373291,-107.30999755859,44.740001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.529998779297,-108.09999847412,44.409999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.520000457764,-108.79000091553,43.900001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.380001068115,-109.5299987793,43.090000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.189998626709,-110.29000091553,42.319999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.959999084473,-111.33999633789,41.310001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.759998321533,-111.81999969482,40.880001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.380001068115,-112.33000183105,40.5),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.799999237061,-112.98999786377,40.119998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.939998626709,-113.59999847412,39.939998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.569999694824,-114.5,39.869998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.159999847412,-116.19999694824,39.979999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.540000915527,-117.80999755859,40.049999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-23.120000839233,-118.43000030518,40.189998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-21.959999084473,-118.81999969482,40.529998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-21.010000228882,-119.12000274658,41.090000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-20.159999847412,-119.34999847412,41.740001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-19.60000038147,-119.48999786377,42.25),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-18.930000305176,-119.66999816895,42.970001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-18.629999160767,-119.69000244141,43.409999847412),
								},
							{
							Pos	=	Vector(-18.319999694824,-119.45999908447,43.889999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseBrake	=	true,
				Beta_Inner3D	=	true,
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-33.979999542236,-107.51000213623,43.360000610352),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	45,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-33.830001831055,-108.40000152588,42.400001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.680000305176,-109.06999969482,41.860000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.5,-109.61000061035,41.520000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.220001220703,-110.18000030518,41.090000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.830001831055,-110.66999816895,40.680000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.319999694824,-111.12999725342,40.569999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.549999237061,-111.66000366211,40.419998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.379999160767,-112.37999725342,40.299999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.520000457764,-113.31999969482,40.259998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.559999465942,-114.23999786377,40.299999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.290000915527,-114.86000061035,40.369998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.159999847412,-115.36000061035,40.490001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-23.360000610352,-115.76000213623,40.669998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-22.670000076294,-116.09999847412,41.009998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-22.049999237061,-116.41000366211,41.430000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-21.639999389648,-116.59999847412,41.799999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-21.329999923706,-116.69999694824,42.310001373291),
								},
							{
							Pos	=	Vector(-21.049999237061,-116.65000152588,43.099998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
						},
				DD_Blnk_Run	=	true,
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	200,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-24.409999847412,99.419998168945,29.440000534058),
				UseBlinkers	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	40,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-25.069999694824,99.279998779297,28.64999961853),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.639999389648,99.069999694824,27.89999961853),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.14999961853,98.830001831055,27.510000228882),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.049999237061,98.400001525879,27.10000038147),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.840000152588,97.949996948242,26.930000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.790000915527,97.400001525879,26.930000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.260000228882,96.480003356934,27.059999465942),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.870000839233,95.23999786377,27.219999313354),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.220001220703,93.370002746582,27.469999313354),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.729999542236,92.019996643066,27.709999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.080001831055,90.819999694824,27.979999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.040000915527,89.800003051758,28.290000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.720001220703,88.919998168945,28.569999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-39.330001831055,88.029998779297,29.040000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-39.680000305176,87.470001220703,29.540000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-40.060001373291,86.800003051758,30.180000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-40.319999694824,86.129997253418,30.829999923706),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-40.450000762939,85.459999084473,31.39999961853),
								},
							{
							Pos	=	Vector(-40.590000152588,84.540000915527,32.220001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
					r	=	165,
					b	=	255,
					a	=	255,
					g	=	165,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
						},
				DD_Blnk_Run	=	true,
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	200,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-23.940000534058,100.06999969482,29.319999694824),
				RenderMLCenter	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	40,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-24.60000038147,99.930000305176,28.530000686646),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.260000228882,99.680000305176,27.659999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.690000534058,99.51000213623,27.299999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.409999847412,99.190002441406,26.920000076294),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.270000457764,98.769996643066,26.680000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.239999771118,98.209999084473,26.629999160767),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.10000038147,97.599998474121,26.64999961853),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.290000915527,96.089996337891,26.860000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.630001068115,94.25,27.120000839233),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.310001373291,92.75,27.270000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.610000610352,91.610000610352,27.530000686646),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.630001068115,90.5,27.889999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.409999847412,89.650001525879,28.090000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-39.189998626709,88.610000610352,28.450000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-39.700000762939,87.769996643066,28.840000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-40.130001068115,87,29.420000076294),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-40.529998779297,86,30.379999160767),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-40.770000457764,85.069999694824,31.190000534058),
								},
							{
							Pos	=	Vector(-40.939998626709,83.800003051758,32.340000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
					r	=	165,
					b	=	255,
					a	=	255,
					g	=	165,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-37.799999237061,88.819999694824,28.010000228882),
					UseColor	=	true,
					Pos2	=	Vector(-33.340000152588,88.819999694824,32.470001220703),
					Color	=	{
						r	=	200,
						b	=	255,
						a	=	255,
						g	=	225,
							},
					Use	=	true,
					Pos1	=	Vector(-37.799999237061,88.819999694824,32.470001220703),
					Pos3	=	Vector(-33.340000152588,88.819999694824,28.010000228882),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				RenderMLCenter	=	true,
				Pos	=	Vector(-35.569999694824,88.819999694824,30.239999771118),
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseSprite	=	true,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-32.189998626709,91.480003356934,27.549999237061),
					UseColor	=	true,
					Pos2	=	Vector(-27.729999542236,91.480003356934,32.009998321533),
					Color	=	{
						r	=	200,
						b	=	255,
						a	=	255,
						g	=	225,
							},
					Use	=	true,
					Pos1	=	Vector(-32.189998626709,91.480003356934,32.009998321533),
					Pos3	=	Vector(-27.729999542236,91.480003356934,27.549999237061),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-29.969999313354,91.480003356934,29.780000686646),
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseHighBeams	=	true,
				UseSprite	=	true,
				UsePrjTex	=	true,
				RenderMLCenter	=	true,
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-34.080001831055,-105.44000244141,44.619998931885),
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	45,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-34.029998779297,-108.13999938965,44.580001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.979999542236,-108.91999816895,44.389999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.799999237061,-109.63999938965,43.919998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.560001373291,-110.43000030518,43.310001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.349998474121,-111.12000274658,42.740001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.189998626709,-111.5299987793,42.409999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.950000762939,-112.04000091553,41.970001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.599998474121,-112.45999908447,41.669998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.130001068115,-112.83000183105,41.5),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.690000534058,-113.76000213623,41.310001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.829999923706,-114.69999694824,41.270000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.870000839233,-115.62000274658,41.310001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.60000038147,-116.23999786377,41.380001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.469999313354,-116.73999786377,41.5),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-23.670000076294,-117.13999938965,41.680000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-22.979999542236,-117.48000335693,42.020000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-22.229999542236,-117.81999969482,42.560001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-21.739999771118,-118.01000213623,43.020000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-21.35000038147,-118.08999633789,43.439998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-21.129999160767,-118.0299987793,43.720001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-21.040000915527,-117.84999847412,43.880001068115),
								},
							{
							Pos	=	Vector(-20.940000534058,-117.68000030518,43.950000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-20.690000534058,-118.76999664307,45.25),
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	35,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-21.540000915527,-118,45.560001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-22.620000839233,-117.11000061035,45.790000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-23.809999465942,-116.16000366211,45.909999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.950000762939,-115.12999725342,46.020000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.219999313354,-113.98000335693,46.139999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.569999694824,-112.62000274658,46.299999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.770000457764,-111.51000213623,46.400001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.430000305176,-109.79000091553,46.529998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.790000915527,-107.98999786377,46.720001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.689998626709,-106.55000305176,46.849998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.110000610352,-105.12999725342,46.979999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.430000305176,-103.62000274658,47.169998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.529998779297,-102.11000061035,47.330001831055),
								},
							{
							Pos	=	Vector(-33.389999389648,-100,47.619998931885),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseSprite	=	true,
				UseBlinkers	=	true,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				SpecRec	=	{
					Pos4	=	Vector(-29.39999961853,-117.73000335693,33.75),
					AmountV	=	2,
					Pos2	=	Vector(-19.940000534058,-120.93000030518,34.900001525879),
					AmountH	=	7,
					Use	=	true,
					Pos1	=	Vector(-28.059999465942,-118.62000274658,35.090000152588),
					Pos3	=	Vector(-21.590000152588,-120.08999633789,33.299999237061),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-24.829999923706,-119.31999969482,34.439998626709),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				ReverseColor	=	{
					r	=	200,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-29.39999961853,-117.73000335693,33.75),
					UseColor	=	true,
					Pos2	=	Vector(-19.940000534058,-120.93000030518,34.900001525879),
					Color	=	{
						r	=	200,
						b	=	255,
						a	=	255,
						g	=	225,
							},
					Use	=	true,
					Pos1	=	Vector(-28.059999465942,-118.62000274658,35.090000152588),
					Pos3	=	Vector(-21.590000152588,-120.08999633789,33.299999237061),
						},
				RenderMLCenter	=	true,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				UseBrake	=	true,
				Beta_Inner3D	=	true,
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(8.0699996948242,-121.88999938965,43.540000915527),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-8.0699996948242,-121.88999938965,43.540000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				RenderMLCenter	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				Beta_Inner3D	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-54.060001373291,9.5900001525879,47.240001678467),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-54.040000915527,10.210000038147,47.25),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-53.930000305176,10.829999923706,47.270000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-53.490001678467,12.060000419617,47.310001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-52.919998168945,13.090000152588,47.310001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-52.189998626709,14.119999885559,47.310001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-51.279998779297,15.14999961853,47.310001373291),
								},
							{
							Pos	=	Vector(-50.009998321533,16.180000305176,47.310001373291),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				UseBlinkers	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				Beta_Inner3D	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				UseSprite	=	true,
				Pos	=	Vector(54.060001373291,9.4700002670288,46.990001678467),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(54.040000915527,10.090000152588,47),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(53.930000305176,10.710000038147,47.020000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(53.490001678467,11.939999580383,47.060001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(52.919998168945,12.970000267029,47.060001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(52.189998626709,14,47.060001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(51.279998779297,15.029999732971,47.060001373291),
								},
							{
							Pos	=	Vector(50.009998321533,16.059999465942,47.060001373291),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				},
		HealthEnginePos	=	Vector(0,70.220001220703,38.849998474121),
		Fuel	=	{
			FuelLidPos	=	Vector(45.009998321533,-55.540000915527,31.909999847412),
			FuelLidUse	=	true,
			FuelTypeUse	=	true,
			FuelType	=	2,
				},
		Author	=	"CrushingSkirmish (76561198017348899)",
}