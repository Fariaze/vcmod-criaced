VCModels['models/crsk_autosmitsubishilancer_evo_ix.mdl']	=	{
		em_state	=	5236594446,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		HealthEnginePosOvr	=	true,
		Date	=	"Mon Jan 29 15:27:05 2018",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(24.930000305176,-99.150001525879,14.60000038147),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Pos	=	Vector(16.920000076294,14.5,29.5),
				DoorSounds	=	true,
				Ang	=	Angle(22,0,0),
				EnterRange	=	80,
				RadioControl	=	true,
					},
				{
				Pos	=	Vector(17,-25.360000610352,30.790000915527),
				DoorSounds	=	true,
				Ang	=	Angle(19,0,0),
				EnterRange	=	80,
				Switch_Rear	=	true,
					},
				{
				Pos	=	Vector(-20.219999313354,-25.360000610352,31.120000839233),
				DoorSounds	=	true,
				Ang	=	Angle(19,0,0),
				EnterRange	=	80,
				Switch_Rear	=	true,
					},
				{
				Pos	=	Vector(-2.7000000476837,-25.360000610352,30.790000915527),
				DoorSounds	=	true,
				Ang	=	Angle(19,0,0),
				EnterRange	=	80,
				Switch_Rear	=	true,
					},
				},
		HealthEnginePos	=	Vector(4.2600002288818,78.51000213623,34.580001831055),
		DLT	=	3491062964,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(-26.60000038147,-91.910003662109,35.259998321533),
					UseColor	=	true,
					Pos2	=	Vector(-31.700000762939,-91.410003662109,40.369998931885),
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	55,
							},
					Use	=	true,
					Pos1	=	Vector(-26.5,-91.910003662109,40.430000305176),
					Pos3	=	Vector(-31.719999313354,-91.410003662109,35.25),
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-29.209999084473,-91.410003662109,37.819999694824),
				UseDynamic	=	true,
				UseBrake	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.35,
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					Size	=	0.1,
						},
				UseBrake	=	true,
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-3.0999999046326,-67.519996643066,49.830001831055),
					UseColor	=	true,
					Pos2	=	Vector(2.9400000572205,-67.019996643066,51.740001678467),
					Color	=	{
						r	=	172,
						b	=	0,
						a	=	255,
						g	=	55,
							},
					Use	=	true,
					Pos1	=	Vector(3.0099999904633,-67.389999389648,49.720001220703),
					Pos3	=	Vector(-3.0799999237061,-66.940002441406,51.75),
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecMat	=	{
						},
				Pos	=	Vector(0,-67.330001831055,50.650001525879),
				UseSprite	=	true,
					},
				{
				UseBlinkers	=	true,
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	150,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
				SpecMat	=	{
						},
				Sprite	=	{
					Size	=	0.07,
						},
				RenderInner_Size	=	1,
				UseSprite	=	true,
				Pos	=	Vector(-36.990001678467,-87.839996337891,34.279998779297),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	48,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-36,-89.809997558594,34.279998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33,-91.809997558594,34.279998779297),
								},
							{
							Pos	=	Vector(-28,-94.309997558594,34.369998931885),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Beta_Inner3D	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	150,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				UseBlinkers	=	true,
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	150,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
				SpecMat	=	{
						},
				Sprite	=	{
					Size	=	0.07,
						},
				RenderInner_Size	=	1,
				Beta_Inner3D	=	true,
				Pos	=	Vector(36.139999389648,-87.839996337891,34.279998779297),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	48,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(35.150001525879,-89.809997558594,34.279998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.150001525879,-91.809997558594,34.279998779297),
								},
							{
							Pos	=	Vector(27.14999961853,-94.309997558594,34.369998931885),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseSprite	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	150,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				UseBlinkers	=	true,
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(-38.869998931885,51.790000915527,29.520000457764),
					Pos2	=	Vector(-38.869998931885,48.290000915527,31.520000457764),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-38.869998931885,51.790000915527,31.520000457764),
					Pos3	=	Vector(-38.869998931885,48.290000915527,29.520000457764),
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				Sprite	=	{
					Size	=	0.1,
						},
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-38.869998931885,49.790000915527,30.520000457764),
				UseDynamic	=	true,
				RenderInner_Size	=	1.2,
				RenderInner	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				UseBlinkers	=	true,
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(39.400001525879,51.790000915527,29.329999923706),
					Pos2	=	Vector(39.400001525879,48.290000915527,31.329999923706),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(39.400001525879,51.790000915527,31.329999923706),
					Pos3	=	Vector(39.400001525879,48.290000915527,29.329999923706),
						},
				SpecMat	=	{
						},
				Sprite	=	{
					Size	=	0.1,
						},
				Beta_Inner3D	=	true,
				UseSprite	=	true,
				Pos	=	Vector(39.400001525879,49.790000915527,30.329999923706),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderInner_Size	=	1.2,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(-22.940000534058,97.419998168945,24.370000839233),
					UseColor	=	true,
					Pos2	=	Vector(-28.639999389648,95.589996337891,29.930000305176),
					Color	=	{
						r	=	220,
						b	=	255,
						a	=	255,
						g	=	225,
							},
					Use	=	true,
					Pos1	=	Vector(-23.129999160767,96.319999694824,30.090000152588),
					Pos3	=	Vector(-28.510000228882,96.839996337891,24.60000038147),
						},
				SpecMat	=	{
						},
				ProjTexture	=	{
					Size	=	2024,
					Angle	=	Angle(0,90,0),
						},
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	231,
					b	=	187,
					a	=	255,
					g	=	211,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Pos	=	Vector(-25.950000762939,96.919998168945,27.540000915527),
				HBeamColor	=	{
					r	=	231,
					b	=	187,
					a	=	255,
					g	=	211,
						},
				UseSprite	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.3,
						},
					},
				{
				UseBlinkers	=	true,
				SpecSpin	=	{
						},
				SpecRec	=	{
					AmountV	=	3,
					Pos4	=	Vector(-36.470001220703,89.470001220703,25.299999237061),
					Mid	=	true,
					Pos2	=	Vector(-33.970001220703,92.970001220703,27.299999237061),
					AmountH	=	5,
					Use	=	true,
					Pos1	=	Vector(-36.470001220703,87.470001220703,27.299999237061),
					Pos3	=	Vector(-32.970001220703,95.970001220703,25.299999237061),
						},
				SpecMat	=	{
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-35.139999389648,91.75,26.360000610352),
				UseDynamic	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseSprite	=	true,
				Sprite	=	{
					Size	=	0.1,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
					},
				{
				UseBlinkers	=	true,
				SpecSpin	=	{
						},
				SpecRec	=	{
					AmountV	=	3,
					Pos4	=	Vector(36.779998779297,89.569999694824,25.299999237061),
					Mid	=	true,
					Pos2	=	Vector(34.279998779297,93.069999694824,27.299999237061),
					AmountH	=	5,
					Use	=	true,
					Pos1	=	Vector(36.779998779297,87.569999694824,27.299999237061),
					Pos3	=	Vector(33.279998779297,96.069999694824,25.299999237061),
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(35.220001220703,91.75,26.5),
				UseDynamic	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
				Sprite	=	{
					Size	=	0.1,
						},
				Beta_Inner3D	=	true,
					},
				{
				UseBlinkers	=	true,
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(33.080001831055,96.389999389648,25.299999237061),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	15,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(28.079999923706,100.2200012207,25.299999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
				UseSprite	=	true,
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.05,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Use	=	true,
					UseColor	=	true,
					Pos2	=	Vector(-32.819999694824,92.639999389648,30.239999771118),
					Color	=	{
						r	=	255,
						b	=	255,
						a	=	255,
						g	=	255,
							},
					Pos4	=	Vector(-28.780000686646,92.910003662109,26.020000457764),
					Pos1	=	Vector(-28.420000076294,92.540000915527,30.139999389648),
					Pos3	=	Vector(-33.290000915527,92.690002441406,26.209999084473),
						},
				SpecMat	=	{
					Use	=	true,
					New	=	"models\crskautos\mitsubishi\lancer_evo_ix\newillum_on",
					Select	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-30.879999160767,93.019996643066,28.209999084473),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	200,
					b	=	187,
					a	=	255,
					g	=	211,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.25,
						},
					},
				{
				UseBlinkers	=	true,
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-33.099998474121,95.680000305176,25.299999237061),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	15,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-28.10000038147,98.680000305176,25.299999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
				Beta_Inner3D	=	true,
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.05,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Use	=	true,
					UseColor	=	true,
					Pos2	=	Vector(-23.569999694824,99.23999786377,28.770000457764),
					Color	=	{
						r	=	255,
						b	=	100,
						a	=	255,
						g	=	175,
							},
					Pos4	=	Vector(-18.809999465942,100.80000305176,24.610000610352),
					Pos1	=	Vector(-18.979999542236,99.769996643066,28.840000152588),
					Pos3	=	Vector(-23.409999847412,100.26000213623,24.39999961853),
						},
				SpecMat	=	{
					Select	=	26,
					New	=	"models\crskautos\mitsubishi\lancer_evo_ix\newilluminter_translucent_on",
					Use	=	true,
						},
				UseSprite	=	true,
				Pos	=	Vector(-21.14999961853,99.330001831055,26.520000457764),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.3,
						},
					},
				{
				Sprite	=	{
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(-31.440000534058,-88.889999389648,35.110000610352),
					UseColor	=	true,
					Pos2	=	Vector(-36.860000610352,-88.940002441406,40.830001831055),
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	55,
							},
					Use	=	true,
					Pos1	=	Vector(-31.680000305176,-89,40.900001525879),
					Pos3	=	Vector(-37.119998931885,-88.940002441406,35.220001220703),
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-34.409999847412,-88.940002441406,37.970001220703),
				UseDynamic	=	true,
				UseBrake	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.35,
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(-23.260000228882,-93.589996337891,33.830001831055),
					Pos2	=	Vector(-26.979999542236,-93.150001525879,37.229999542236),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-23.190000534058,-93.650001525879,37.25),
					Pos3	=	Vector(-27.079999923706,-93.120002746582,33.560001373291),
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-25.280000686646,-93.150001525879,35.310001373291),
				UseDynamic	=	true,
				ReverseColor	=	{
					r	=	200,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Use	=	true,
					UseColor	=	true,
					Pos2	=	Vector(33.319999694824,92.48999786377,30.239999771118),
					Color	=	{
						r	=	255,
						b	=	255,
						a	=	255,
						g	=	250,
							},
					Pos4	=	Vector(29.280000686646,92.76000213623,26.020000457764),
					Pos1	=	Vector(28.920000076294,92.389999389648,30.139999389648),
					Pos3	=	Vector(33.790000915527,92.540000915527,26.209999084473),
						},
				SpecMat	=	{
					Use	=	true,
					New	=	"models\crskautos\mitsubishi\lancer_evo_ix\newredprib_on",
					Select	=	6,
						},
				UseSprite	=	true,
				Pos	=	Vector(31.379999160767,92.870002746582,28.209999084473),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	200,
					b	=	187,
					a	=	255,
					g	=	211,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.25,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Use	=	true,
					UseColor	=	true,
					Pos2	=	Vector(24.25,99.129997253418,28.709999084473),
					Color	=	{
						r	=	255,
						b	=	100,
						a	=	255,
						g	=	175,
							},
					Pos4	=	Vector(19.489999771118,100.69000244141,24.549999237061),
					Pos1	=	Vector(19.659999847412,99.660003662109,28.780000686646),
					Pos3	=	Vector(24.090000152588,100.15000152588,24.340000152588),
						},
				SpecMat	=	{
					Select	=	26,
					New	=	"models\crskautos\mitsubishi\lancer_evo_ix\newilluminter_translucent_on",
					Use	=	true,
						},
				UseSprite	=	true,
				Pos	=	Vector(21.829999923706,99.220001220703,26.459999084473),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.2,
						},
					},
				{
				Sprite	=	{
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(23.549999237061,97.349998474121,24.180000305176),
					UseColor	=	true,
					Pos2	=	Vector(29.25,95.519996643066,29.739999771118),
					Color	=	{
						r	=	220,
						b	=	255,
						a	=	255,
						g	=	225,
							},
					Use	=	true,
					Pos1	=	Vector(23.739999771118,96.25,29.89999961853),
					Pos3	=	Vector(29.120000839233,96.769996643066,24.409999847412),
						},
				HBeamColor	=	{
					r	=	231,
					b	=	187,
					a	=	255,
					g	=	211,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.3,
						},
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	231,
					b	=	187,
					a	=	255,
					g	=	211,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				SpecMat	=	{
						},
				Pos	=	Vector(26.559999465942,96.849998474121,27.35000038147),
				UseSprite	=	true,
				ProjTexture	=	{
					Size	=	2024,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(31.180000305176,-89.050003051758,34.900001525879),
					UseColor	=	true,
					Pos2	=	Vector(36.599998474121,-89.099998474121,40.619998931885),
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	55,
							},
					Use	=	true,
					Pos1	=	Vector(31.420000076294,-89.160003662109,40.689998626709),
					Pos3	=	Vector(36.860000610352,-89.099998474121,35.009998321533),
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(34.150001525879,-89.099998474121,37.759998321533),
				UseDynamic	=	true,
				UseBrake	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.35,
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(26.260000228882,-92.099998474121,35.169998168945),
					UseColor	=	true,
					Pos2	=	Vector(31.360000610352,-91.599998474121,40.279998779297),
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	55,
							},
					Use	=	true,
					Pos1	=	Vector(26.159999847412,-92.099998474121,40.340000152588),
					Pos3	=	Vector(31.379999160767,-91.599998474121,35.159999847412),
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(28.870000839233,-91.599998474121,37.729999542236),
				UseDynamic	=	true,
				UseBrake	=	true,
				UseRunning	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.35,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(22.89999961853,-93.650001525879,33.590000152588),
					Pos2	=	Vector(26.729999542236,-93.150001525879,37.159999847412),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(22.930000305176,-93.650001525879,37.189998626709),
					Pos3	=	Vector(26.799999237061,-93.150001525879,33.430000305176),
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(24.780000686646,-93.150001525879,35.340000152588),
				UseDynamic	=	true,
				ReverseColor	=	{
					r	=	200,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
					},
				},
		Copyright	=	"Copyright © 2012-2018 VCMod (freemmaann). All Rights Reserved.",
		Fuel	=	{
			FuelLidPos	=	Vector(-38.75,-67.25,39.560001373291),
			FuelType	=	0,
			Capacity	=	52,
			Override	=	true,
			FuelLidUse	=	true,
				},
		Author	=	"CrushingSkirmish (76561198017348899)",
}