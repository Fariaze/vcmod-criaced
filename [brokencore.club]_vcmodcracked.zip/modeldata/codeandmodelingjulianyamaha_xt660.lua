VCModels['models/codeandmodelingjulianyamaha_xt660.mdl']	=	{
		em_state	=	5236594821,
		DLT	=	3491063214,
		Date	=	"Sat Apr  4 00:40:05 2020",
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(0.10000000149012,28.260000228882,26.940000534058),
				UseDynamic	=	true,
				PosAtc	=	{
					type	=	"Bone",
					offset	=	Vector(-18.5,6.5999999046326,3.7000000476837),
					id	=	23,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseSprite	=	true,
				Pos	=	Vector(0.10000000149012,28.260000228882,26.940000534058),
				UseDynamic	=	true,
				PosAtc	=	{
					type	=	"Bone",
					offset	=	Vector(-23.799999237061,8.1000003814697,-6.3000001907349),
					id	=	23,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseSprite	=	true,
				Pos	=	Vector(0.10000000149012,28.260000228882,26.940000534058),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				PosAtc	=	{
					type	=	"Bone",
					offset	=	Vector(-23.799999237061,-1.3999999761581,9.3999996185303),
					id	=	23,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				UseBrake	=	true,
				PosAtc	=	{
					type	=	"Bone",
					offset	=	Vector(-6.4000000953674,0,28.89999961853),
					id	=	21,
						},
				UseSprite	=	true,
				Pos	=	Vector(0.10000000149012,28.260000228882,26.940000534058),
				UseDynamic	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				UseRunning	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseSprite	=	true,
				Pos	=	Vector(0.10000000149012,28.260000228882,26.940000534058),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				PosAtc	=	{
					type	=	"Bone",
					offset	=	Vector(-6.4000000953674,6.6999998092651,25.39999961853),
					id	=	21,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseSprite	=	true,
				Pos	=	Vector(0.10000000149012,28.260000228882,26.940000534058),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				PosAtc	=	{
					type	=	"Bone",
					offset	=	Vector(-6.4000000953674,-6.6999998092651,25.39999961853),
					id	=	21,
						},
					},
				},
		Copyright	=	"Copyright © 2020 VCMod (freemmaann). All Rights Reserved.",
		Author	=	"Azok30 - CODEMODELING.fr (76561198183398967)",
}