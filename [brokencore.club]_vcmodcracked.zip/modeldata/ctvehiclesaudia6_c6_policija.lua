VCModels['models/ctvehiclesaudia6_c6_policija.mdl']	=	{
		em_state	=	5236594824,
		HealthEnginePosOvr	=	true,
		Date	=	"Thu Dec  6 02:57:29 2018",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-24.799999237061,-117.73999786377,17.85000038147),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(24.840000152588,-117.73999786377,17.85000038147),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		HealthEnginePos	=	Vector(0,74,34),
		Fuel	=	{
			FuelLidPos	=	Vector(40.439998626709,-68.769996643066,47.729999542236),
			FuelTypeUse	=	true,
			FuelType	=	0,
			Capacity	=	65,
			FuelLidUse	=	true,
			Override	=	true,
				},
		Author	=	"𝓒𝓣𝓥 (76561198051637331)",
		Light_DD_Int	=	true,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Siren	=	{
			Sounds	=	{
					{
					Volume	=	1,
					Pitch	=	100,
					Distance	=	95,
					Name	=	"Wail",
					Sound	=	"vehicles\ctvehicles\c6\wail.wav",
						},
					{
					Volume	=	1,
					Pitch	=	100,
					Distance	=	95,
					Name	=	"Yelp",
					Sound	=	"vehicles\ctvehicles\c6\yelp.wav",
						},
					{
					Volume	=	1,
					Pitch	=	100,
					Distance	=	95,
					Name	=	"Two-Tone",
					Sound	=	"vehicles\ctvehicles\c6\hilo.wav",
						},
					},
			Codes	=	{
				[13]	=	{
					Include	=	true,
						},
					},
			Sections	=	{
				[3]	=	{
					[1]	=	true,
					[4]	=	true,
						},
					},
			Lights	=	{
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.1,
							},
					SpecSpin	=	{
						Intensity	=	1,
							},
					SpecRec	=	{
						Use	=	true,
						AmountV	=	2,
						Pos1	=	Vector(13.829999923706,-16.489999771118,78.050003051758),
						Pos2	=	Vector(24.760000228882,-16.489999771118,78.050003051758),
						AmountH	=	25,
						Pos4	=	Vector(13.829999923706,-16.489999771118,74.25),
						Mid_Full	=	true,
						Pos3	=	Vector(24.760000228882,-16.489999771118,74.25),
							},
					SpecMat	=	{
						Select	=	28,
						New	=	"models/ctvehicles/audi/a6_c6_regular/blue_els_on",
						Use	=	true,
							},
					BGroups	=	{
							{
							[0]	=	"lightbar",
								},
							},
					UseSprite	=	true,
					Pos	=	Vector(13.550000190735,-16.620000839233,76.050003051758),
					Color	=	{
						r	=	0,
						b	=	255,
						a	=	255,
						g	=	55,
							},
					RenderHD_Adv	=	true,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.1,
							},
					SpecSpin	=	{
						Intensity	=	1,
							},
					SpecRec	=	{
						AmountV	=	2,
						Use	=	true,
						Mid_Full	=	true,
						Pos2	=	Vector(24.760000228882,-27.540000915527,78.050003051758),
						AmountH	=	25,
						Pos4	=	Vector(13.829999923706,-27.540000915527,74.25),
						Pos1	=	Vector(13.829999923706,-27.540000915527,78.050003051758),
						Pos3	=	Vector(24.760000228882,-27.540000915527,74.25),
							},
					SpecMat	=	{
						Select	=	28,
						New	=	"models/ctvehicles/audi/a6_c6_regular/blue_els_on",
						Use	=	true,
							},
					BGroups	=	{
							{
							[0]	=	"lightbar",
								},
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(13.550000190735,-27.670000076294,76.050003051758),
					Color	=	{
						r	=	0,
						b	=	255,
						a	=	255,
						g	=	55,
							},
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.1,
							},
					SpecSpin	=	{
						Intensity	=	1,
							},
					SpecRec	=	{
						Use	=	true,
						AmountV	=	2,
						Pos1	=	Vector(25.959999084473,-27.290000915527,74.23999786377),
						Pos2	=	Vector(25.889999389648,-16.870000839233,74.23999786377),
						AmountH	=	15,
						Pos4	=	Vector(25.959999084473,-27.290000915527,77.779998779297),
						Mid_Full	=	true,
						Pos3	=	Vector(25.889999389648,-16.870000839233,77.779998779297),
							},
					SpecMat	=	{
						Select	=	30,
						New	=	"models/ctvehicles/audi/a6_c6_regular/blue_els_on",
						Use	=	true,
							},
					BGroups	=	{
							{
							[0]	=	"lightbar",
								},
							},
					UseSprite	=	true,
					Pos	=	Vector(20.180000305176,-22.209999084473,75.910003662109),
					Color	=	{
						r	=	0,
						b	=	255,
						a	=	255,
						g	=	55,
							},
					RenderHD_Adv	=	true,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.1,
							},
					SpecSpin	=	{
						Intensity	=	1,
							},
					SpecRec	=	{
						Use	=	true,
						AmountV	=	2,
						Pos1	=	Vector(-25.959999084473,-27.290000915527,74.23999786377),
						Pos2	=	Vector(-25.889999389648,-16.870000839233,74.23999786377),
						AmountH	=	15,
						Pos4	=	Vector(-25.959999084473,-27.290000915527,77.779998779297),
						Mid_Full	=	true,
						Pos3	=	Vector(-25.889999389648,-16.870000839233,77.779998779297),
							},
					SpecMat	=	{
						Select	=	31,
						New	=	"models/ctvehicles/audi/a6_c6_regular/red_els_on",
						Use	=	true,
							},
					BGroups	=	{
							{
							[0]	=	"lightbar",
								},
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-20.229999542236,-22.209999084473,75.910003662109),
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	55,
							},
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.1,
							},
					SpecSpin	=	{
						Intensity	=	1,
							},
					SpecRec	=	{
						Use	=	true,
						AmountV	=	2,
						Pos1	=	Vector(-13.829999923706,-16.489999771118,78.050003051758),
						Pos2	=	Vector(-24.760000228882,-16.489999771118,78.050003051758),
						AmountH	=	25,
						Pos4	=	Vector(-13.829999923706,-16.489999771118,74.25),
						Mid_Full	=	true,
						Pos3	=	Vector(-24.760000228882,-16.489999771118,74.25),
							},
					SpecMat	=	{
						Select	=	29,
						New	=	"models/ctvehicles/audi/a6_c6_regular/red_els_on",
						Use	=	true,
							},
					BGroups	=	{
							{
							[0]	=	"lightbar",
								},
							},
					UseSprite	=	true,
					Pos	=	Vector(-15.010000228882,-16.620000839233,76.050003051758),
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	55,
							},
					RenderHD_Adv	=	true,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.1,
							},
					SpecSpin	=	{
						Intensity	=	1,
							},
					SpecRec	=	{
						Use	=	true,
						AmountV	=	2,
						Pos1	=	Vector(-13.829999923706,-27.540000915527,78.050003051758),
						Pos2	=	Vector(-24.760000228882,-27.540000915527,78.050003051758),
						AmountH	=	25,
						Pos4	=	Vector(-13.829999923706,-27.540000915527,74.25),
						Mid_Full	=	true,
						Pos3	=	Vector(-24.760000228882,-27.540000915527,74.25),
							},
					SpecMat	=	{
						Select	=	29,
						New	=	"models/ctvehicles/audi/a6_c6_regular/red_els_on",
						Use	=	true,
							},
					BGroups	=	{
							{
							[0]	=	"lightbar",
								},
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-15.39999961853,-27.670000076294,76.050003051758),
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	55,
							},
					UseSprite	=	true,
						},
					},
			Sounds_Horn	=	{
				Use	=	true,
				Volume	=	1,
				Distance	=	95,
				Pitch	=	100,
				Sound	=	"vehicles\ctvehicles\c6\bullhorn.wav",
					},
			Sequences	=	{
					{
					SubSeq	=	{
							{
							Stages	=	{
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											1,
											2,
											3,
											},
									Time	=	0.18,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											4,
											5,
											6,
											},
									Time	=	0.3,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											1,
											2,
											3,
											},
									Time	=	0.18,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											4,
											5,
											6,
											},
									Time	=	0.3,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											1,
											2,
											3,
											},
									Time	=	0.18,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											4,
											5,
											6,
											},
									Time	=	0.3,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											1,
											2,
											3,
											},
									Time	=	0.18,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											4,
											5,
											6,
											},
									Time	=	0.3,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											1,
											2,
											3,
											},
									Time	=	0.06,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											},
									Time	=	0.06,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											1,
											2,
											3,
											},
									Time	=	0.06,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											4,
											5,
											6,
											},
									Time	=	0.3,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											1,
											2,
											3,
											},
									Time	=	0.06,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											},
									Time	=	0.06,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											1,
											2,
											3,
											},
									Time	=	0.06,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											4,
											5,
											6,
											},
									Time	=	0.3,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											1,
											2,
											3,
											},
									Time	=	0.06,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											},
									Time	=	0.06,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											1,
											2,
											3,
											},
									Time	=	0.06,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											4,
											5,
											6,
											},
									Time	=	0.3,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											1,
											2,
											3,
											},
									Time	=	0.06,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											},
									Time	=	0.06,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											1,
											2,
											3,
											},
									Time	=	0.06,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											4,
											5,
											6,
											},
									Time	=	0.3,
										},
									},
							Time	=	20,
							Type	=	"Custom",
								},
							{
							Stages	=	{
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											4,
											5,
											6,
											},
									Time	=	0.18,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											1,
											2,
											3,
											},
									Time	=	0.3,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											4,
											5,
											6,
											},
									Time	=	0.18,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											1,
											2,
											3,
											},
									Time	=	0.3,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											4,
											5,
											6,
											},
									Time	=	0.18,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											1,
											2,
											3,
											},
									Time	=	0.3,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											4,
											5,
											6,
											},
									Time	=	0.18,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											1,
											2,
											3,
											},
									Time	=	0.3,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											4,
											5,
											6,
											},
									Time	=	0.06,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											},
									Time	=	0.06,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											4,
											5,
											6,
											},
									Time	=	0.06,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											1,
											2,
											3,
											},
									Time	=	0.3,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											4,
											5,
											6,
											},
									Time	=	0.06,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											},
									Time	=	0.06,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											4,
											5,
											6,
											},
									Time	=	0.06,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											1,
											2,
											3,
											},
									Time	=	0.3,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											4,
											5,
											6,
											},
									Time	=	0.06,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											},
									Time	=	0.06,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											4,
											5,
											6,
											},
									Time	=	0.06,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											1,
											2,
											3,
											},
									Time	=	0.3,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											4,
											5,
											6,
											},
									Time	=	0.06,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											},
									Time	=	0.06,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											4,
											5,
											6,
											},
									Time	=	0.06,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											1,
											2,
											3,
											},
									Time	=	0.3,
										},
									},
							Time	=	20,
							Type	=	"Custom",
								},
							},
					Codes	=	{
							true,
							},
					Lights_Sel	=	{
							true,
							true,
							true,
							true,
							true,
							true,
							},
						},
					},
			Sounds_Manual	=	{
				Use	=	true,
				Volume	=	1,
				Distance	=	95,
				Pitch	=	100,
				Sound	=	"vehicles\ctvehicles\c6\wail.wav",
					},
				},
		Copyright	=	"Copyright © 2012-2018 VCMod (freemmaann). All Rights Reserved.",
		ExtraSeats	=	{
				{
				Ang	=	Angle(7,0,0),
				Pos	=	Vector(18.579999923706,8.1899995803833,34.200000762939),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(6,0,0),
				Pos	=	Vector(-19.079999923706,-38.040000915527,35.759998321533),
					},
				{
				Ang	=	Angle(6,0,0),
				Pos	=	Vector(19.920000076294,-38.040000915527,35.759998321533),
					},
				{
				Ang	=	Angle(6,0,0),
				Pos	=	Vector(0.11999999731779,-38.040000915527,35.759998321533),
					},
				},
		Seq_BlinkRate_On	=	0.36,
		DLT	=	3491063216,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-22.920000076294,96.129997253418,30.989999771118),
					UseColor	=	true,
					Pos2	=	Vector(-29.659999847412,96.129997253418,37.729999542236),
					Color	=	{
						r	=	255,
						b	=	233,
						a	=	255,
						g	=	250,
							},
					Use	=	true,
					Pos1	=	Vector(-22.920000076294,96.129997253418,37.729999542236),
					Pos3	=	Vector(-29.659999847412,96.129997253418,30.989999771118),
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-26.290000915527,94.339996337891,34.360000610352),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				HBeamColor	=	{
					r	=	255,
					b	=	156,
					a	=	255,
					g	=	204,
						},
				RunningColor	=	{
					r	=	255,
					b	=	156,
					a	=	255,
					g	=	204,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(22.920000076294,96.129997253418,30.989999771118),
					UseColor	=	true,
					Pos2	=	Vector(29.659999847412,96.129997253418,37.729999542236),
					Color	=	{
						r	=	255,
						b	=	233,
						a	=	255,
						g	=	250,
							},
					Use	=	true,
					Pos1	=	Vector(22.920000076294,96.129997253418,37.729999542236),
					Pos3	=	Vector(29.659999847412,96.129997253418,30.989999771118),
						},
				HBeamColor	=	{
					r	=	255,
					b	=	156,
					a	=	255,
					g	=	204,
						},
				UseSprite	=	true,
				Pos	=	Vector(26.290000915527,94.339996337891,34.360000610352),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				SpecMat	=	{
						},
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	156,
					a	=	255,
					g	=	204,
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.25,
						},
				inner_AsSpheres	=	true,
				UseLowBeams	=	true,
				LBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseHighBeams	=	true,
				RenderGlow_Size	=	0,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				RenderType	=	2,
				SpecMat	=	{
						},
				DD_HD	=	true,
				HBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseSprite	=	true,
				Pos	=	Vector(-32.569999694824,91.819999694824,34.470001220703),
				DD_Glow	=	true,
				RenderInner_Size	=	4,
				RenderHD_Size	=	0,
				RenderInner	=	true,
				DD_Main	=	true,
				SpecSpin	=	{
					Intensity	=	1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.25,
						},
				inner_AsSpheres	=	true,
				UseLowBeams	=	true,
				LBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseHighBeams	=	true,
				RenderGlow_Size	=	0,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				RenderType	=	2,
				SpecMat	=	{
						},
				DD_HD	=	true,
				HBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseSprite	=	true,
				Pos	=	Vector(32.569999694824,91.819999694824,34.470001220703),
				DD_Glow	=	true,
				RenderInner	=	true,
				RenderHD_Size	=	0,
				RenderInner_Size	=	4,
				DD_Main	=	true,
				SpecSpin	=	{
					Intensity	=	1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.15,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseLowBeams	=	true,
				SpecMat	=	{
						},
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseHighBeams	=	true,
				RenderHD_Size	=	5,
				Pos	=	Vector(32.569999694824,92.540000915527,34.470001220703),
				UseSprite	=	true,
				HBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.15,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseLowBeams	=	true,
				SpecMat	=	{
						},
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				HBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseHighBeams	=	true,
				RenderHD_Size	=	5,
				Pos	=	Vector(-32.569999694824,92.540000915527,34.470001220703),
				UseSprite	=	true,
				SpecSpin	=	{
					Intensity	=	1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.7,
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					Use	=	true,
					New	=	"models\ctvehicles\audi\a6_c6_regular\blinker_on",
					Select	=	20,
						},
				UseSprite	=	true,
				Pos	=	Vector(36.720001220703,86.25,34.650001525879),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				SpecSpin	=	{
					Intensity	=	1,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.7,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					Use	=	true,
					New	=	"models\ctvehicles\audi\a6_c6_regular\blinker_on",
					Select	=	21,
						},
				UseSprite	=	true,
				Pos	=	Vector(-36.709999084473,86.25,34.650001525879),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
				UseBlinkers	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RenderInner_Size	=	1,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-30.549999237061,101.37000274658,21.709999084473),
					UseColor	=	true,
					Pos2	=	Vector(-35.529998779297,96.940002441406,17.010000228882),
					Color	=	{
						r	=	255,
						b	=	233,
						a	=	255,
						g	=	250,
							},
					Use	=	true,
					Pos1	=	Vector(-30.719999313354,101.33000183105,16.840000152588),
					Pos3	=	Vector(-35.799999237061,96.639999389648,21.680000305176),
						},
				FogColor	=	{
					r	=	255,
					b	=	135,
					a	=	255,
					g	=	193,
						},
				SpecMat	=	{
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseSprite	=	true,
				UsePrjTex	=	true,
				Pos	=	Vector(-33.049999237061,97.839996337891,19.340000152588),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseFog	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RenderInner	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(30.549999237061,101.37000274658,21.709999084473),
					UseColor	=	true,
					Pos2	=	Vector(35.529998779297,96.940002441406,17.010000228882),
					Color	=	{
						r	=	255,
						b	=	233,
						a	=	255,
						g	=	250,
							},
					Use	=	true,
					Pos1	=	Vector(30.719999313354,101.33000183105,16.840000152588),
					Pos3	=	Vector(35.799999237061,96.639999389648,21.680000305176),
						},
				FogColor	=	{
					r	=	255,
					b	=	135,
					a	=	255,
					g	=	193,
						},
				SpecMat	=	{
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseSprite	=	true,
				UsePrjTex	=	true,
				Pos	=	Vector(33.049999237061,97.839996337891,19.340000152588),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				UseFog	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(42.590000152588,39.740001678467,40.509998321533),
					Pos2	=	Vector(42.200000762939,42.819999694824,41.669998168945),
					Color	=	{
						r	=	255,
						b	=	233,
						a	=	255,
						g	=	250,
							},
					Use	=	true,
					Pos1	=	Vector(42.25,39.790000915527,41.819999694824),
					Pos3	=	Vector(42.529998779297,42.759998321533,40.369998931885),
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(42.340000152588,41.279998779297,41.080001831055),
				UseDynamic	=	true,
				RenderInner_Size	=	0.6034,
				RenderInner	=	true,
				inner_AsSpheres	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-42.590000152588,39.740001678467,40.509998321533),
					Pos2	=	Vector(-42.200000762939,42.819999694824,41.669998168945),
					Color	=	{
						r	=	255,
						b	=	233,
						a	=	255,
						g	=	250,
							},
					Use	=	true,
					Pos1	=	Vector(-42.25,39.790000915527,41.819999694824),
					Pos3	=	Vector(-42.529998779297,42.759998321533,40.369998931885),
						},
				inner_AsSpheres	=	true,
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseSprite	=	true,
				Pos	=	Vector(-42.340000152588,41.279998779297,41.080001831055),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderInner_Size	=	0.6034,
				UseBlinkers	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-35.729999542236,-109.94999694824,41.229999542236),
					Pos2	=	Vector(-30.5,-115.11000061035,39.950000762939),
					Color	=	{
						r	=	255,
						b	=	233,
						a	=	255,
						g	=	250,
							},
					Use	=	true,
					Pos1	=	Vector(-35.720001220703,-110.33999633789,40.060001373291),
					Pos3	=	Vector(-30.690000534058,-114.83000183105,41.200000762939),
						},
				FogColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-33.229999542236,-111.9700012207,40.669998168945),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				UseFog	=	true,
				RenderHD_Size	=	2,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	145,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(32.959999084473,-111.40000152588,42.009998321533),
				UseDynamic	=	true,
				RenderInner	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(35.720001220703,-109.29000091553,42.930000305176),
					Pos2	=	Vector(30.719999313354,-114.81999969482,41.209999084473),
					Color	=	{
						r	=	255,
						b	=	233,
						a	=	255,
						g	=	250,
							},
					Use	=	true,
					Pos1	=	Vector(35.770000457764,-109.88999938965,41.229999542236),
					Pos3	=	Vector(31,-114.33999633789,43.009998321533),
						},
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-30.979999542236,-114.34999847412,42.990001678467),
					UseColor	=	true,
					Pos2	=	Vector(-24,-117.37999725342,41.220001220703),
					Color	=	{
						r	=	255,
						b	=	233,
						a	=	255,
						g	=	250,
							},
					Use	=	true,
					Pos1	=	Vector(-30.670000076294,-114.83999633789,41.310001373291),
					Pos3	=	Vector(-24.569999694824,-116.88999938965,43.040000915527),
						},
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-27.569999694824,-114.86000061035,42.080001831055),
				UseDynamic	=	true,
				RenderInner	=	true,
				ReverseColor	=	{
					r	=	255,
					b	=	156,
					a	=	255,
					g	=	204,
						},
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(30.979999542236,-114.34999847412,42.990001678467),
					UseColor	=	true,
					Pos2	=	Vector(24,-117.37999725342,41.220001220703),
					Color	=	{
						r	=	255,
						b	=	233,
						a	=	255,
						g	=	250,
							},
					Use	=	true,
					Pos1	=	Vector(30.670000076294,-114.83999633789,41.310001373291),
					Pos3	=	Vector(24.569999694824,-116.88999938965,43.040000915527),
						},
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(27.569999694824,-114.86000061035,42.080001831055),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				ReverseColor	=	{
					r	=	255,
					b	=	156,
					a	=	255,
					g	=	204,
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-32.970001220703,-111.76999664307,46.130001068115),
					UseColor	=	true,
					Pos2	=	Vector(-28.930000305176,-115.41999816895,43.009998321533),
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	100,
							},
					Use	=	true,
					Pos1	=	Vector(-32.810001373291,-112.91000366211,43),
					Pos3	=	Vector(-29.510000228882,-114.40000152588,46.200000762939),
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-30.940000534058,-112.73999786377,44.509998321533),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				RenderHD_Size	=	0.7,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-36.020000457764,-107.01000213623,45.830001831055),
					UseColor	=	true,
					Pos2	=	Vector(-32.830001831055,-112.87999725342,42.979999542236),
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	100,
							},
					Use	=	true,
					Pos1	=	Vector(-36.430000305176,-108.01999664307,42.810001373291),
					Pos3	=	Vector(-33.020000457764,-111.70999908447,46.110000610352),
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-34.229999542236,-108.61000061035,44.340000152588),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				RenderHD_Size	=	0.7,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(36.020000457764,-107.01000213623,45.830001831055),
					UseColor	=	true,
					Pos2	=	Vector(32.830001831055,-112.87999725342,42.979999542236),
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	100,
							},
					Use	=	true,
					Pos1	=	Vector(36.430000305176,-108.01999664307,42.810001373291),
					Pos3	=	Vector(33.020000457764,-111.70999908447,46.110000610352),
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_Size	=	1,
				UseSprite	=	true,
				Pos	=	Vector(34.229999542236,-108.61000061035,44.340000152588),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderHD_Size	=	0.7,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(32.970001220703,-111.76999664307,46.130001068115),
					UseColor	=	true,
					Pos2	=	Vector(28.930000305176,-115.41999816895,43.009998321533),
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	100,
							},
					Use	=	true,
					Pos1	=	Vector(32.810001373291,-112.91000366211,43),
					Pos3	=	Vector(29.510000228882,-114.40000152588,46.200000762939),
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_Size	=	1,
				UseSprite	=	true,
				Pos	=	Vector(30.940000534058,-112.73999786377,44.509998321533),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderHD_Size	=	0.7,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-29.510000228882,-114.36000061035,46.200000762939),
					UseColor	=	true,
					Pos2	=	Vector(-24.610000610352,-116.83999633789,43.069999694824),
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	100,
							},
					Use	=	true,
					Pos1	=	Vector(-29,-115.41000366211,43.080001831055),
					Pos3	=	Vector(-25.520000457764,-115.80000305176,46.330001831055),
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_Size	=	1,
				UseSprite	=	true,
				Pos	=	Vector(-27.110000610352,-114.55000305176,44.810001373291),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderHD_Size	=	0.7,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(29.510000228882,-114.36000061035,46.200000762939),
					UseColor	=	true,
					Pos2	=	Vector(24.610000610352,-116.83999633789,43.069999694824),
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	100,
							},
					Use	=	true,
					Pos1	=	Vector(29,-115.41000366211,43.080001831055),
					Pos3	=	Vector(25.520000457764,-115.80000305176,46.330001831055),
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(27.110000610352,-114.55000305176,44.810001373291),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				RenderHD_Size	=	0.7,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RenderMLCenter	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				UseBrake	=	true,
				RenderHD_Adv	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-35.130001068115,-107.13999938965,46.819999694824),
				UseDynamic	=	true,
				RenderInner_Size	=	1.6,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-34.330001831055,-108.30000305176,46.919998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-33.430000305176,-109.43000030518,47.029998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-32.290000915527,-110.62000274658,47.110000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-31.129999160767,-111.63999938965,47.189998626709),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-30.010000228882,-112.51999664307,47.25),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-28.799999237061,-113.33999633789,47.310001373291),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-27.510000228882,-114.08999633789,47.349998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-26.190000534058,-114.80000305176,47.380001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	131,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RenderMLCenter	=	true,
				RenderInner_Size	=	1.6,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				UseBrake	=	true,
				RenderHD_Adv	=	true,
				UseSprite	=	true,
				Pos	=	Vector(35.130001068115,-107.13999938965,46.819999694824),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(34.330001831055,-108.30000305176,46.919998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(33.430000305176,-109.43000030518,47.029998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(32.290000915527,-110.62000274658,47.110000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(31.129999160767,-111.63999938965,47.189998626709),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(30.010000228882,-112.51999664307,47.25),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(28.799999237061,-113.33999633789,47.310001373291),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(27.510000228882,-114.08999633789,47.349998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(26.190000534058,-114.80000305176,47.380001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	131,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.11,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseSprite	=	true,
				SpecMat	=	{
						},
				UseBrake	=	true,
				RenderMLCenter	=	true,
				RenderHD_Adv	=	true,
				Pos	=	Vector(-8.1899995803833,-63.630001068115,67.150001525879),
				RenderInner	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-4.0900001525879,-63.869998931885,67.339996337891),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-2.0499999523163,-63.970001220703,67.400001525879),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(0,-64.080001831055,67.430000305176),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(2.0499999523163,-63.970001220703,67.400001525879),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(4.0900001525879,-63.869998931885,67.339996337891),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(8.1899995803833,-63.630001068115,67.150001525879),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	131,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-35.720001220703,-109.29000091553,42.930000305176),
					Pos2	=	Vector(-30.719999313354,-114.81999969482,41.209999084473),
					Color	=	{
						r	=	255,
						b	=	233,
						a	=	255,
						g	=	250,
							},
					Use	=	true,
					Pos1	=	Vector(-35.770000457764,-109.88999938965,41.229999542236),
					Pos3	=	Vector(-31,-114.33999633789,43.009998321533),
						},
				SpecMat	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-32.959999084473,-111.40000152588,42.009998321533),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				RenderInner	=	true,
				UseBlinkers	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(35.729999542236,-109.94999694824,41.229999542236),
					Pos2	=	Vector(30.5,-115.11000061035,39.950000762939),
					Color	=	{
						r	=	255,
						b	=	233,
						a	=	255,
						g	=	250,
							},
					Use	=	true,
					Pos1	=	Vector(35.720001220703,-110.33999633789,40.060001373291),
					Pos3	=	Vector(30.690000534058,-114.83000183105,41.200000762939),
						},
				FogColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				RenderInner_Size	=	1,
				UseSprite	=	true,
				Pos	=	Vector(33.229999542236,-111.9700012207,40.669998168945),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderHD_Size	=	2,
				UseFog	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	145,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-30.64999961853,-114.84999847412,41.220001220703),
					Pos2	=	Vector(-23.690000534058,-117.68000030518,39.979999542236),
					Color	=	{
						r	=	255,
						b	=	233,
						a	=	255,
						g	=	250,
							},
					Use	=	true,
					Pos1	=	Vector(-30.479999542236,-115.16000366211,39.939998626709),
					Pos3	=	Vector(-24.059999465942,-117.37999725342,41.189998626709),
						},
				FogColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-27.35000038147,-115.08000183105,40.650001525879),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				UseFog	=	true,
				RenderHD_Size	=	2,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	145,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(30.64999961853,-114.84999847412,41.220001220703),
					Pos2	=	Vector(23.690000534058,-117.68000030518,39.979999542236),
					Color	=	{
						r	=	255,
						b	=	233,
						a	=	255,
						g	=	250,
							},
					Use	=	true,
					Pos1	=	Vector(30.479999542236,-115.16000366211,39.939998626709),
					Pos3	=	Vector(24.059999465942,-117.37999725342,41.189998626709),
						},
				FogColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				RenderInner_Size	=	1,
				UseSprite	=	true,
				Pos	=	Vector(27.35000038147,-115.08000183105,40.650001525879),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseFog	=	true,
				RenderHD_Size	=	2,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	145,
						},
				RenderInner_ClrUse	=	false,
					},
				},
		Seq_BlinkRate_Ovr	=	true,
		Seq_BlinkRate_Off	=	0.36,
		Indication	=	{
			speedo_mph	=	{
				max	=	1,
				pp	=	"vehicle_guage",
				top	=	155,
					},
				},
}