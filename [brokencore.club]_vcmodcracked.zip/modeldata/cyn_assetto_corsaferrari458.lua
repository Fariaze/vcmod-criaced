VCModels['models/cyn_assetto_corsaferrari458.mdl']	=	{
		em_state	=	5236594785,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Copyright	=	"Copyright © 2012-2018 VCMod (freemmaann). All Rights Reserved.",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(0,-113.08999633789,17.319999694824),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(5.1799998283386,-113.08999633789,17.319999694824),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-5.1799998283386,-113.08999633789,17.319999694824),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(15,0,0),
				Pos	=	Vector(17.059999465942,9.6199998855591,24.049999237061),
				RadioControl	=	true,
					},
				},
		DLT	=	3491063190,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4323,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(35.650001525879,92.199996948242,25.790000915527),
					UseColor	=	true,
					Pos2	=	Vector(31.64999961853,92.199996948242,29.790000915527),
					Color	=	{
						r	=	177,
						b	=	255,
						a	=	255,
						g	=	188,
							},
					Use	=	true,
					Pos1	=	Vector(35.650001525879,92.199996948242,29.790000915527),
					Pos3	=	Vector(31.64999961853,92.199996948242,25.790000915527),
						},
				SpecMat	=	{
						},
				UsePrjTex	=	true,
				Pos	=	Vector(33.650001525879,92.199996948242,27.790000915527),
				UseHighBeams	=	true,
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseSprite	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.1602,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(38.080001831055,87.98999786377,30.079999923706),
				SpecMat	=	{
						},
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.1602,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(37.700000762939,89.430000305176,29.139999389648),
				SpecMat	=	{
						},
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.1602,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(38.5,85.76000213623,31.030000686646),
				SpecMat	=	{
						},
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.1602,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(38.900001525879,83.48999786377,31.969999313354),
				SpecMat	=	{
						},
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.1602,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(39.330001831055,81.040000915527,32.919998168945),
				SpecMat	=	{
						},
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.1602,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(39.729999542236,78.540000915527,33.860000610352),
				SpecMat	=	{
						},
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.1602,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(40.119998931885,75.959999084473,34.830001831055),
				SpecMat	=	{
						},
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.1602,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(40.560001373291,73.099998474121,35.729999542236),
				SpecMat	=	{
						},
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4323,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-35.650001525879,92.199996948242,25.790000915527),
					UseColor	=	true,
					Pos2	=	Vector(-31.64999961853,92.199996948242,29.790000915527),
					Color	=	{
						r	=	177,
						b	=	255,
						a	=	255,
						g	=	188,
							},
					Use	=	true,
					Pos1	=	Vector(-35.650001525879,92.199996948242,29.790000915527),
					Pos3	=	Vector(-31.64999961853,92.199996948242,25.790000915527),
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseHighBeams	=	true,
				SpecMat	=	{
						},
				Pos	=	Vector(-33.650001525879,92.199996948242,27.790000915527),
				UseSprite	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.1602,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-38.080001831055,87.98999786377,30.079999923706),
				SpecMat	=	{
						},
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.1602,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-37.700000762939,89.430000305176,29.139999389648),
				SpecMat	=	{
						},
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.1602,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-38.5,85.76000213623,31.030000686646),
				SpecMat	=	{
						},
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.1602,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-38.900001525879,83.48999786377,31.969999313354),
				SpecMat	=	{
						},
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.1602,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-39.330001831055,81.040000915527,32.919998168945),
				SpecMat	=	{
						},
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.1602,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-39.729999542236,78.540000915527,33.860000610352),
				SpecMat	=	{
						},
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.1602,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-40.119998931885,75.959999084473,34.830001831055),
				SpecMat	=	{
						},
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.1602,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-40.560001373291,73.099998474121,35.729999542236),
				SpecMat	=	{
						},
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.1602,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				Pos	=	Vector(39.549999237061,74.319999694824,35.810001373291),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.1602,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				Pos	=	Vector(38.540000915527,75.169998168945,35.810001373291),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.1602,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				Pos	=	Vector(39.119998931885,77.199996948242,34.889999389648),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.1602,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				Pos	=	Vector(38.080001831055,78.050003051758,34.889999389648),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.1602,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				Pos	=	Vector(38.720001220703,79.790000915527,33.939998626709),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.1602,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				Pos	=	Vector(37.669998168945,80.629997253418,33.939998626709),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.1602,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				Pos	=	Vector(38.299999237061,82.290000915527,32.990001678467),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.1602,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				Pos	=	Vector(37.220001220703,83.129997253418,32.990001678467),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.1602,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				Pos	=	Vector(37.869998931885,84.730003356934,32.020000457764),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.1602,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				Pos	=	Vector(36.779998779297,85.569999694824,32.020000457764),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.1602,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				Pos	=	Vector(36.299999237061,87.860000610352,31.090000152588),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.1602,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				Pos	=	Vector(37.400001525879,87.019996643066,31.090000152588),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.1602,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				Pos	=	Vector(-37.400001525879,87.019996643066,31.090000152588),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.1602,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				Pos	=	Vector(-36.299999237061,87.860000610352,31.090000152588),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.1602,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				Pos	=	Vector(-36.779998779297,85.569999694824,32.020000457764),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.1602,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				Pos	=	Vector(-37.869998931885,84.730003356934,32.020000457764),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.1602,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				Pos	=	Vector(-37.220001220703,83.129997253418,32.990001678467),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.1602,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				Pos	=	Vector(-38.299999237061,82.290000915527,32.990001678467),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.1602,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				Pos	=	Vector(-37.669998168945,80.629997253418,33.939998626709),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.1602,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				Pos	=	Vector(-38.720001220703,79.790000915527,33.939998626709),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.1602,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				Pos	=	Vector(-38.080001831055,78.050003051758,34.889999389648),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.1602,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				Pos	=	Vector(-39.119998931885,77.199996948242,34.889999389648),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.1602,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				Pos	=	Vector(-38.540000915527,75.169998168945,35.810001373291),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.1602,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				Pos	=	Vector(-39.549999237061,74.319999694824,35.810001373291),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.1602,
					Size	=	0.1031,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				Pos	=	Vector(47.459999084473,39.580001831055,29.5),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.1602,
					Size	=	0.1031,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				Pos	=	Vector(-47.459999084473,39.580001831055,29.5),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1963,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-37.209999084473,-102.19999694824,39.150001525879),
					UseColor	=	true,
					Pos2	=	Vector(-39.830001831055,-102.37999725342,41.770000457764),
					Color	=	{
						r	=	211,
						b	=	211,
						a	=	255,
						g	=	211,
							},
					Use	=	true,
					Pos1	=	Vector(-37.209999084473,-102.19999694824,41.770000457764),
					Pos3	=	Vector(-39.830001831055,-102.31999969482,39.150001525879),
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-38.520000457764,-102.19999694824,40.459999084473),
				UseDynamic	=	true,
				ReverseColor	=	{
					r	=	155,
					b	=	155,
					a	=	255,
					g	=	155,
						},
				RenderGlow_Size	=	0.4,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1963,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(37.209999084473,-102.19999694824,39.150001525879),
					UseColor	=	true,
					Pos2	=	Vector(39.830001831055,-102.37999725342,41.770000457764),
					Color	=	{
						r	=	211,
						b	=	211,
						a	=	255,
						g	=	211,
							},
					Use	=	true,
					Pos1	=	Vector(37.209999084473,-102.19999694824,41.770000457764),
					Pos3	=	Vector(39.830001831055,-102.31999969482,39.150001525879),
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(38.520000457764,-102.19999694824,40.459999084473),
				UseDynamic	=	true,
				ReverseColor	=	{
					r	=	155,
					b	=	155,
					a	=	255,
					g	=	155,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				RenderGlow_Size	=	0.4,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	9.1051,
					Size	=	0.0397,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	176,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-38.450000762939,-102.15000152588,40.479999542236),
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	20,
					Use	=	true,
					Radius	=	1.73,
						},
				RenderGlow_Size	=	0.4,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/ring",
					Pos4	=	Vector(-35.799999237061,-102.06999969482,37.830001831055),
					UseColor	=	true,
					Pos2	=	Vector(-41.099998474121,-102.44000244141,43.130001068115),
					Color	=	{
						r	=	219,
						b	=	0,
						a	=	255,
						g	=	98,
							},
					Use	=	true,
					Pos1	=	Vector(-35.799999237061,-102.15000152588,43.130001068115),
					Pos3	=	Vector(-41.099998474121,-102.33999633789,37.830001831055),
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	9.1051,
					Size	=	0.0397,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/ring",
					Pos4	=	Vector(35.799999237061,-102.06999969482,37.830001831055),
					UseColor	=	true,
					Pos2	=	Vector(41.099998474121,-102.44000244141,43.130001068115),
					Color	=	{
						r	=	219,
						b	=	0,
						a	=	255,
						g	=	98,
							},
					Use	=	true,
					Pos1	=	Vector(35.799999237061,-102.15000152588,43.130001068115),
					Pos3	=	Vector(41.099998474121,-102.33999633789,37.830001831055),
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(38.450000762939,-102.15000152588,40.479999542236),
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	20,
					Use	=	true,
					Radius	=	1.73,
						},
				RenderGlow_Size	=	0.4,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	176,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.0399,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(9.1000003814697,-106.91999816895,44.209999084473),
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(0,-107.05000305176,44.470001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-9.1000003814697,-106.91999816895,44.209999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	42,
					a	=	255,
					g	=	93,
						},
				RenderGlow_Size	=	0.5828,
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	9.1051,
					Size	=	0.0395,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/ring",
					Pos4	=	Vector(-33.979999542236,-102.11000061035,36.009998321533),
					UseColor	=	true,
					Pos2	=	Vector(-42.919998168945,-102.70999908447,44.950000762939),
					Color	=	{
						r	=	102,
						b	=	0,
						a	=	255,
						g	=	9,
							},
					Use	=	true,
					Pos1	=	Vector(-33.979999542236,-102.25,44.950000762939),
					Pos3	=	Vector(-42.919998168945,-102.48000335693,36.009998321533),
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-38.450000762939,-102.26999664307,40.479999542236),
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	24,
					Use	=	true,
					Radius	=	2.94,
						},
				RenderGlow_Size	=	0.45,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	63,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	9.1051,
					Size	=	0.0395,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/ring",
					Pos4	=	Vector(33.979999542236,-102.11000061035,36.009998321533),
					UseColor	=	true,
					Pos2	=	Vector(42.919998168945,-102.70999908447,44.950000762939),
					Color	=	{
						r	=	102,
						b	=	0,
						a	=	255,
						g	=	9,
							},
					Use	=	true,
					Pos1	=	Vector(33.979999542236,-102.25,44.950000762939),
					Pos3	=	Vector(42.919998168945,-102.48000335693,36.009998321533),
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(38.450000762939,-102.26999664307,40.479999542236),
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	24,
					Use	=	true,
					Radius	=	2.94,
						},
				RenderGlow_Size	=	0.45,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	63,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	9.1051,
					Size	=	0.06,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/ring",
					Pos4	=	Vector(-33.979999542236,-102.11000061035,36.009998321533),
					UseColor	=	true,
					Pos2	=	Vector(-42.919998168945,-102.70999908447,44.950000762939),
					Color	=	{
						r	=	197,
						b	=	0,
						a	=	255,
						g	=	15,
							},
					Use	=	true,
					Pos1	=	Vector(-33.979999542236,-102.25,44.950000762939),
					Pos3	=	Vector(-42.919998168945,-102.48000335693,36.009998321533),
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-38.450000762939,-102.26999664307,40.479999542236),
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	24,
					Use	=	true,
					Radius	=	2.94,
						},
				RenderGlow_Size	=	0.45,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	114,
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	9.1051,
					Size	=	0.06,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/ring",
					Pos4	=	Vector(33.979999542236,-102.11000061035,36.009998321533),
					UseColor	=	true,
					Pos2	=	Vector(42.919998168945,-102.70999908447,44.950000762939),
					Color	=	{
						r	=	197,
						b	=	0,
						a	=	255,
						g	=	15,
							},
					Use	=	true,
					Pos1	=	Vector(33.979999542236,-102.25,44.950000762939),
					Pos3	=	Vector(42.919998168945,-102.48000335693,36.009998321533),
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(38.450000762939,-102.26999664307,40.479999542236),
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	24,
					Use	=	true,
					Radius	=	2.94,
						},
				RenderGlow_Size	=	0.45,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	114,
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				},
		Date	=	"Sat Jan 27 15:31:53 2018",
		Fuel	=	{
			FuelType	=	0,
			FuelLidPos	=	Vector(0,0,0),
				},
		Author	=	"cynaraos (76561198047818115)",
}