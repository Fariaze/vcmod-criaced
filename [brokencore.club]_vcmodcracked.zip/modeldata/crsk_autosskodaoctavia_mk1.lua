VCModels['models/crsk_autosskodaoctavia_mk1.mdl']	=	{
		em_state	=	5236595070,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Date	=	"06/30/17 00:11:38",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(15.340000152588,-119.44000244141,11.39999961853),
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(16,0,0),
				Pos	=	Vector(16.870000839233,0.0099999997764826,31.559999465942),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(16,0,0),
				Pos	=	Vector(-20.139999389648,-39.220001220703,31.590000152588),
					},
				{
				Ang	=	Angle(16,0,0),
				Pos	=	Vector(20.139999389648,-39.220001220703,31.590000152588),
					},
				{
				Ang	=	Angle(16,0,0),
				Pos	=	Vector(0,-35.909999847412,31.579999923706),
					},
				},
		DLT	=	3491063380,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-30.209999084473,82.720001220703,31.39999961853),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
						195,
						195,
						255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(30.510000228882,82.830001831055,31.270000457764),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
						195,
						195,
						255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-33.830001831055,81.099998474121,30.85000038147),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(33.680000305176,81.040000915527,30.879999160767),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-41.459999084473,31.709999084473,32.669998168945),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(41.529998779297,31.379999160767,32.509998321533),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				SpecMat	=	{
						},
				HBeamColor	=	{
						195,
						195,
						255,
						},
				UsePrjTex	=	true,
				LBeamColor	=	{
						195,
						195,
						255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Pos	=	Vector(-21.89999961853,84.639999389648,30.829999923706),
				UseSprite	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				HBeamColor	=	{
						195,
						195,
						255,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UsePrjTex	=	true,
				LBeamColor	=	{
						195,
						195,
						255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseSprite	=	true,
				SpecMat	=	{
						},
				Pos	=	Vector(21.959999084473,84.639999389648,30.030000686646),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-33.220001220703,-117.01999664307,41.779998779297),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	11,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-26.75,-119.55000305176,41.680000305176),
								},
							},
						},
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(32.209999084473,-117.26000213623,41.810001373291),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	11,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(26.75,-120.58000183105,41.990001678467),
								},
							},
						},
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-32.700000762939,-118.40000152588,44.689998626709),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	14,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-27.360000610352,-120.19000244141,44.430000305176),
								},
							},
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(31.809999465942,-118.30999755859,45.040000915527),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	11,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(27.10000038147,-120.08000183105,44.830001831055),
								},
							},
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(33.529998779297,-117.76000213623,36.209999084473),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	6,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(24.950000762939,-120.20999908447,36.209999084473),
								},
							},
						},
				UseRunning	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-33.729999542236,-117.98000335693,37.009998321533),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	9,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-25.110000610352,-119.68000030518,36.759998321533),
								},
							},
						},
				UseRunning	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseReverse	=	true,
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-33.299999237061,-117.90000152588,39.680000305176),
				UseDynamic	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				SpecMLine	=	{
					Amount	=	11,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-27.040000915527,-121.12000274658,39.639999389648),
								},
							},
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseReverse	=	true,
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(32.610000610352,-118.08999633789,39.560001373291),
				UseDynamic	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				SpecMLine	=	{
					Amount	=	11,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(26.719999313354,-121.12000274658,39.400001525879),
								},
							},
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
					},
				},
		Copyright	=	"Copyright © 2012-2017 VCMod (freemmaann). All Rights Reserved.",
		Fuel	=	{
			FuelLidPos	=	Vector(38.080001831055,-68.650001525879,43.610000610352),
			Capacity	=	55,
			Override	=	true,
			FuelType	=	0,
				},
		Author	=	"CrushingSkirmish (76561198017348899)",
}