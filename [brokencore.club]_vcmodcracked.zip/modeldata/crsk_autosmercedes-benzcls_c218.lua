VCModels['models/crsk_autosmercedes-benzcls_c218.mdl']	=	{
		em_state	=	5236594635,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		HealthEnginePosOvr	=	true,
		Date	=	"Wed May  2 17:12:21 2018",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(29.030000686646,-102.94999694824,17.629999160767),
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(-29.760000228882,-102.69999694824,17.840000152588),
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(23.420000076294,-103.94000244141,17.569999694824),
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(-23.790000915527,-103.84999847412,17.85000038147),
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(7,0,0),
				Pos	=	Vector(20.340000152588,27.059999465942,30.840000152588),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(20,0,0),
				Pos	=	Vector(18.340000152588,-15.85000038147,34),
					},
				{
				Ang	=	Angle(20,0,0),
				Pos	=	Vector(-17.340000152588,-16.85000038147,33.799999237061),
					},
				},
		HealthEnginePos	=	Vector(-0.5,99.5,38.5),
		DLT	=	3491063090,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.09,
						},
				SpecSpin	=	{
					Speed	=	0,
					Intensity	=	1,
						},
				UseDynamic	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						255,
						100,
						0,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						55,
						0,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(38.720001220703,-84.080001831055,41.650001525879),
				RenderInner	=	true,
				RenderInner_Size	=	1.2,
				SpecMLine	=	{
					Amount	=	100,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(36.75,-89.089996337891,41.330001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.5,-91.339996337891,41.099998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.150001525879,-93.370002746582,40.720001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.650001525879,-95.180000305176,40.310001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.989999771118,-96.769996643066,39.75),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.139999389648,-98.150001525879,39),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.170000076294,-99.180000305176,38.080001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(23.64999961853,-100.63999938965,35.979999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.430000305176,-100.04000091553,36.159999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.89999961853,-99.589996337891,36.229999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.239999771118,-99.040000915527,36.279998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.079999923706,-98.029998779297,36.330001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.810001373291,-96.769996643066,36.419998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.400001525879,-95.269996643066,36.740001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.700000762939,-93.610000610352,37.150001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.669998168945,-92,37.759998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.430000305176,-90.290000915527,38.560001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(38.139999389648,-88.040000915527,39.790000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(38.680000305176,-84.970001220703,41.599998474121),
								},
							},
						},
				UseBlinkers	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.04,
						},
				SpecSpin	=	{
					dd_beam	=	true,
					Offset	=	0,
					Speed	=	2000,
					Double	=	true,
					Intensity	=	0,
						},
				UseDynamic	=	true,
				RenderHD_Size	=	0.4,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						255,
						155,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/turnsig_cinque",
					Pos4	=	Vector(-9.0200004577637,-105.31999969482,19.370000839233),
					Pos2	=	Vector(-8.9200000762939,-105.31999969482,19.270000457764),
					Use	=	true,
					Pos1	=	Vector(-9.0200004577637,-105.31999969482,19.270000457764),
					Pos3	=	Vector(-8.9200000762939,-105.31999969482,19.370000839233),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				RenderHD_Adv	=	true,
				Pos	=	Vector(-8.9700002670288,-105.5,19.319999694824),
				UseSprite	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	50,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-0.25999999046326,-105.80000305176,19.309999465942),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(8.4499998092651,-105.59999847412,19.299999237061),
								},
							},
						},
				RenderInner_Size	=	2,
				Beta_Inner3D	=	true,
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					dd_beam	=	true,
					Offset	=	0,
					Speed	=	2000,
					Double	=	true,
					Intensity	=	0,
						},
				UseReverse	=	true,
				UseDynamic	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				RenderInner_Clr	=	{
						225,
						225,
						255,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderHD_Size	=	0.3,
				UseSprite	=	true,
				Pos	=	Vector(28.340000152588,-99.120002746582,37.459999084473),
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(30.659999847412,-97.76000213623,37.919998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.340000152588,-96.419998168945,38.270000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.779998779297,-94.970001220703,38.619998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.790000915527,-93.800003051758,38.900001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.549999237061,-92.819999694824,39.150001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.049999237061,-92.019996643066,39.380001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.540000915527,-91.190002441406,39.639999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.889999389648,-90.389999389648,39.919998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.159999847412,-89.629997253418,40.310001373291),
								},
							},
						},
				RenderInner_Size	=	1.2,
				RenderHD_Adv	=	true,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					dd_beam	=	true,
					Offset	=	0,
					Speed	=	2000,
					Double	=	true,
					Intensity	=	0,
						},
				UseReverse	=	true,
				UseDynamic	=	true,
				RenderHD_Size	=	0.3,
				RenderInner_Clr	=	{
						225,
						225,
						255,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-28.64999961853,-98.900001525879,37.610000610352),
				RenderHD_Adv	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-30.969999313354,-97.540000915527,38.069999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.650001525879,-96.199996948242,38.419998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.090000152588,-94.75,38.770000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.099998474121,-93.580001831055,39.049999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.860000610352,-92.599998474121,39.299999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.360000610352,-91.800003051758,39.529998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.849998474121,-90.970001220703,39.790000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.200000762939,-90.169998168945,40.069999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.470001220703,-89.410003662109,40.459999084473),
								},
							},
						},
				RenderInner_Size	=	1.2,
				UseSprite	=	true,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
					dd_beam	=	true,
					Offset	=	0,
					Speed	=	2000,
					Double	=	true,
					Intensity	=	0,
						},
				UseLowBeams	=	true,
				LBeamColor	=	{
						255,
						255,
						255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
						225,
						225,
						255,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				HBeamColor	=	{
						255,
						255,
						255,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-26.030000686646,123.4700012207,29.829999923706),
				RenderMLCenter	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	40,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-31.700000762939,120.66999816895,30.510000228882),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.959999084473,118.75,31.020000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.950000762939,117.9700012207,31.190000534058),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.880001068115,117.16999816895,31.340000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.759998321533,116.19000244141,31.540000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.459999084473,115.30999755859,31.729999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.889999389648,114.62999725342,31.920000076294),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-39.209999084473,113.9700012207,32.119998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-39.580001831055,112.61000061035,32.790000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-39.75,110.15000152588,34.979999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.319999694824,112.95999908447,34.810001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.810001373291,115.05999755859,34.669998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.990001678467,116.7799987793,34.529998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.380001068115,118.2799987793,34.470001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.040000915527,119.51000213623,34.439998626709),
								},
							},
						},
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1.2,
				SpecMat	=	{
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
					dd_beam	=	true,
					Offset	=	0,
					Speed	=	2000,
					Double	=	true,
					Intensity	=	0,
						},
				UseLowBeams	=	true,
				LBeamColor	=	{
						255,
						255,
						255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
						225,
						225,
						255,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				HBeamColor	=	{
						255,
						255,
						255,
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(26.739999771118,123.44999694824,29.709999084473),
				UseSprite	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	40,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(32.409999847412,120.65000152588,30.389999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.669998168945,118.73000335693,30.89999961853),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.659999847412,117.94999694824,31.069999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.590000152588,117.15000152588,31.219999313354),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(38.470001220703,116.16999816895,31.420000076294),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(39.169998168945,115.29000091553,31.610000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(39.599998474121,114.61000061035,31.799999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(39.919998168945,113.94999694824,32),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(40.290000915527,112.58999633789,32.669998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(40.459999084473,110.12999725342,34.860000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(39.029998779297,112.94000244141,34.689998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.520000457764,115.04000091553,34.549999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.700000762939,116.76999664307,34.430000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.060001373291,118.26000213623,34.349998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.75,119.48999786377,34.319999694824),
								},
							},
						},
				RenderInner_Size	=	1.2,
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
					dd_beam	=	true,
					Offset	=	0,
					Speed	=	2000,
					Double	=	true,
					Intensity	=	0,
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	255,
					b	=	255,
					a	=	255,
					g	=	255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderHD_Size	=	3,
				RenderInner_Clr	=	{
					r	=	225,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/stadium_2x6",
					Pos4	=	Vector(37.020000457764,115.09999847412,30.209999084473),
					Pos2	=	Vector(32.139999389648,115.09999847412,35.110000610352),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(37.049999237061,115.09999847412,35.110000610352),
					Pos3	=	Vector(32.389999389648,115.15000152588,29.89999961853),
						},
				HBeamColor	=	{
					r	=	255,
					b	=	255,
					a	=	255,
					g	=	255,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(34.610000610352,115.09999847412,32.619998931885),
				SpecMat	=	{
						},
				RenderInner_Size	=	1,
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				RenderMLCenter	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
					dd_beam	=	true,
					Offset	=	0,
					Speed	=	2000,
					Double	=	true,
					Intensity	=	0,
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	255,
					b	=	255,
					a	=	255,
					g	=	255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderHD_Size	=	3,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/stadium_2x6",
					Pos4	=	Vector(-36.360000610352,115.23000335693,30.35000038147),
					Pos2	=	Vector(-31.479999542236,115.23000335693,35.25),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-36.389999389648,115.23000335693,35.25),
					Pos3	=	Vector(-31.729999542236,115.2799987793,30.040000915527),
						},
				HBeamColor	=	{
					r	=	255,
					b	=	255,
					a	=	255,
					g	=	255,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-33.950000762939,115.23000335693,32.759998321533),
				Beta_Inner3D	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
					dd_beam	=	true,
					Offset	=	0,
					Speed	=	2000,
					Double	=	true,
					Intensity	=	0,
						},
				RenderMLCenter	=	true,
				RunningColor	=	{
						255,
						255,
						254,
						},
				UseSprite	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner_Size	=	1,
				Beta_Inner3D	=	true,
				Pos	=	Vector(38.979999542236,118.16000366211,18.450000762939),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	3,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(37.849998474121,119.73999786377,18.360000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.430000305176,120.9700012207,18.270000457764),
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
						225,
						225,
						255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
					dd_beam	=	true,
					Offset	=	0,
					Speed	=	2000,
					Double	=	true,
					Intensity	=	0,
						},
				RenderMLCenter	=	true,
				RunningColor	=	{
						255,
						255,
						254,
						},
				Beta_Inner3D	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-38.369998931885,118.34999847412,18.629999160767),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	3,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-37.240001678467,119.93000030518,18.540000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.819999694824,121.16000366211,18.450000762939),
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
						225,
						225,
						255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
					dd_beam	=	true,
					Offset	=	0,
					Speed	=	2000,
					Double	=	true,
					Intensity	=	0,
						},
				RenderMLCenter	=	true,
				RunningColor	=	{
						255,
						255,
						254,
						},
				Beta_Inner3D	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner_Size	=	1,
				UseSprite	=	true,
				Pos	=	Vector(34.840000152588,122,18.14999961853),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	4,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(29.590000152588,124.36000061035,17.75),
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
						225,
						225,
						255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
					dd_beam	=	true,
					Offset	=	0,
					Speed	=	2000,
					Double	=	true,
					Intensity	=	0,
						},
				RenderMLCenter	=	true,
				RunningColor	=	{
						255,
						255,
						254,
						},
				Beta_Inner3D	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-34.220001220703,122.16999816895,18.309999465942),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	4,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-28.969999313354,124.5299987793,17.909999847412),
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
						225,
						225,
						255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
					dd_beam	=	true,
					Offset	=	0,
					Speed	=	2000,
					Double	=	true,
					Intensity	=	0,
						},
				UseLowBeams	=	true,
				LBeamColor	=	{
						255,
						255,
						255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
						225,
						225,
						255,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(34.130001068115,114.5299987793,30.25),
					Pos2	=	Vector(27.020000457764,112.44999694824,34.720001220703),
					Use	=	true,
					Pos1	=	Vector(33.729999542236,113.91999816895,34.810001373291),
					Pos3	=	Vector(26.299999237061,116.55999755859,29.840000152588),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(30.729999542236,113.30999755859,32.400001525879),
				RenderInner	=	true,
				UseSprite	=	true,
				RenderInner_Size	=	1,
				HBeamColor	=	{
						255,
						255,
						255,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
					dd_beam	=	true,
					Offset	=	0,
					Speed	=	2000,
					Double	=	true,
					Intensity	=	0,
						},
				UseLowBeams	=	true,
				LBeamColor	=	{
						255,
						255,
						255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
						225,
						225,
						255,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-33.470001220703,114.66999816895,30.35000038147),
					Pos2	=	Vector(-26.360000610352,112.58999633789,34.819999694824),
					Use	=	true,
					Pos1	=	Vector(-33.069999694824,114.05999755859,34.909999847412),
					Pos3	=	Vector(-25.639999389648,116.69999694824,29.940000534058),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-30.069999694824,113.44999694824,32.5),
				RenderInner	=	true,
				HBeamColor	=	{
						255,
						255,
						255,
						},
				RenderInner_Size	=	1,
				RenderMLCenter	=	true,
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
					dd_beam	=	true,
					Offset	=	0,
					Speed	=	2000,
					Double	=	true,
					Intensity	=	0,
						},
				UseLowBeams	=	true,
				LBeamColor	=	{
						255,
						255,
						255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
						225,
						225,
						255,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(40.200000762939,111.16000366211,31.829999923706),
					Pos2	=	Vector(35.709999084473,111.62000274658,34.759998321533),
					Use	=	true,
					Pos1	=	Vector(40.270000457764,111.19000244141,34.740001678467),
					Pos3	=	Vector(36.290000915527,111.61000061035,30.819999694824),
						},
				HBeamColor	=	{
						255,
						255,
						255,
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(38.299999237061,110.13999938965,32.860000610352),
				RenderInner_Size	=	1,
				UseSprite	=	true,
				RenderInner	=	true,
				SpecMat	=	{
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
					dd_beam	=	true,
					Offset	=	0,
					Speed	=	2000,
					Double	=	true,
					Intensity	=	0,
						},
				UseLowBeams	=	true,
				LBeamColor	=	{
						255,
						255,
						255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
						225,
						225,
						255,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-39.549999237061,111.33999633789,31.979999542236),
					Pos2	=	Vector(-35.060001373291,111.80000305176,34.909999847412),
					Use	=	true,
					Pos1	=	Vector(-39.619998931885,111.37000274658,34.889999389648),
					Pos3	=	Vector(-35.639999389648,111.79000091553,30.969999313354),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-37.650001525879,110.31999969482,33.009998321533),
				RenderInner_Size	=	1,
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				HBeamColor	=	{
						255,
						255,
						255,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
					dd_beam	=	true,
					Offset	=	0,
					Speed	=	2000,
					Double	=	true,
					Intensity	=	0,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
						225,
						225,
						255,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(35.389999389648,113.15000152588,28.14999961853),
					Pos2	=	Vector(41.180000305176,110.63999938965,32.020000457764),
					Use	=	true,
					Pos1	=	Vector(36.310001373291,112.30000305176,31.14999961853),
					Pos3	=	Vector(40.099998474121,111.08000183105,28.659999847412),
						},
				HBeamColor	=	{
						255,
						255,
						255,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(38.049999237061,110.81999969482,30.120000839233),
				RenderInner	=	true,
				RenderMLCenter	=	true,
				RenderInner_Size	=	1,
				Beta_Inner3D	=	true,
				SpecMat	=	{
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
					dd_beam	=	true,
					Offset	=	0,
					Speed	=	2000,
					Double	=	true,
					Intensity	=	0,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
						225,
						225,
						255,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-34.729999542236,113.31999969482,28.340000152588),
					Pos2	=	Vector(-40.520000457764,110.80999755859,32.209999084473),
					Use	=	true,
					Pos1	=	Vector(-35.650001525879,112.4700012207,31.340000152588),
					Pos3	=	Vector(-39.439998626709,111.25,28.85000038147),
						},
				HBeamColor	=	{
						255,
						255,
						255,
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-37.389999389648,110.98999786377,30.309999465942),
				RenderInner_Size	=	1,
				RenderMLCenter	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				SpecMat	=	{
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
					dd_beam	=	true,
					Offset	=	0,
					Speed	=	2000,
					Double	=	true,
					Intensity	=	0,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
						225,
						225,
						255,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(31.049999237061,115.79000091553,27.459999084473),
					Pos2	=	Vector(36.650001525879,112.98000335693,31.14999961853),
					Use	=	true,
					Pos1	=	Vector(32.020000457764,114.87000274658,30.530000686646),
					Pos3	=	Vector(36,113.2200012207,28.309999465942),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(34.099998474121,113.56999969482,29.370000839233),
				RenderInner_Size	=	1,
				RenderMLCenter	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				HBeamColor	=	{
						255,
						255,
						255,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
					dd_beam	=	true,
					Offset	=	0,
					Speed	=	2000,
					Double	=	true,
					Intensity	=	0,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
						225,
						225,
						255,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-30.389999389648,115.94000244141,27.670000076294),
					Pos2	=	Vector(-35.990001678467,113.12999725342,31.360000610352),
					Use	=	true,
					Pos1	=	Vector(-31.360000610352,115.01999664307,30.739999771118),
					Pos3	=	Vector(-35.340000152588,113.37000274658,28.520000457764),
						},
				HBeamColor	=	{
						255,
						255,
						255,
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-33.439998626709,113.7200012207,29.579999923706),
				RenderInner	=	true,
				RenderMLCenter	=	true,
				RenderInner_Size	=	1,
				UseSprite	=	true,
				SpecMat	=	{
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
					dd_beam	=	true,
					Offset	=	0,
					Speed	=	2000,
					Double	=	true,
					Intensity	=	0,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
						225,
						225,
						255,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(24.889999389648,118.68000030518,26.379999160767),
					Pos2	=	Vector(32.389999389648,115.48000335693,30.39999961853),
					Use	=	true,
					Pos1	=	Vector(26.049999237061,117.88999938965,29.860000610352),
					Pos3	=	Vector(31.469999313354,115.94999694824,27.190000534058),
						},
				HBeamColor	=	{
						255,
						255,
						255,
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(29.030000686646,116.01000213623,28.629999160767),
				RenderInner_Size	=	1,
				RenderMLCenter	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				SpecMat	=	{
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
					dd_beam	=	true,
					Offset	=	0,
					Speed	=	2000,
					Double	=	true,
					Intensity	=	0,
						},
				UseDynamic	=	true,
				RenderHD_Size	=	0.1,
				RenderInner_Clr	=	{
						255,
						155,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(33.840000152588,114.33999633789,35.259998321533),
				UseSprite	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	4,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(36.759998321533,112.55999755859,35.310001373291),
								},
							},
						},
				RenderInner	=	true,
				UseBlinkers	=	true,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
					dd_beam	=	true,
					Offset	=	0,
					Speed	=	2000,
					Double	=	true,
					Intensity	=	0,
						},
				UseDynamic	=	true,
				RenderHD_Size	=	0.1,
				RenderInner_Clr	=	{
						255,
						155,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-33.200000762939,114.48000335693,35.419998168945),
				UseSprite	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	4,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-36.119998931885,112.69999694824,35.470001220703),
								},
							},
						},
				RenderInner_Size	=	1,
				RenderMLCenter	=	true,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
					dd_beam	=	true,
					Offset	=	0,
					Speed	=	2000,
					Double	=	true,
					Intensity	=	0,
						},
				UseDynamic	=	true,
				RenderHD_Size	=	0.1,
				RenderInner_Clr	=	{
						255,
						155,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(37.729999542236,111.73999786377,35.340000152588),
				UseSprite	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	2,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(38.720001220703,110.5,35.430000305176),
								},
							},
						},
				RenderInner_Size	=	1,
				RenderMLCenter	=	true,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
					dd_beam	=	true,
					Offset	=	0,
					Speed	=	2000,
					Double	=	true,
					Intensity	=	0,
						},
				UseDynamic	=	true,
				RenderHD_Size	=	0.1,
				RenderInner_Clr	=	{
						255,
						155,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(39.680000305176,109.08999633789,35.560001373291),
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	2,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(40.659999847412,106.44999694824,35.75),
								},
							},
						},
				RenderInner	=	true,
				UseBlinkers	=	true,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
					dd_beam	=	true,
					Offset	=	0,
					Speed	=	2000,
					Double	=	true,
					Intensity	=	0,
						},
				UseDynamic	=	true,
				RenderHD_Size	=	0.1,
				RenderInner_Clr	=	{
						255,
						155,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-37.069999694824,111.94999694824,35.529998779297),
				UseSprite	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	2,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-38.060001373291,110.70999908447,35.619998931885),
								},
							},
						},
				RenderInner_Size	=	1,
				UseBlinkers	=	true,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
					dd_beam	=	true,
					Offset	=	0,
					Speed	=	2000,
					Double	=	true,
					Intensity	=	0,
						},
				UseDynamic	=	true,
				RenderHD_Size	=	0.1,
				RenderInner_Clr	=	{
						255,
						155,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-39.029998779297,109.26999664307,35.759998321533),
				UseSprite	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	2,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-40.009998321533,106.62999725342,35.950000762939),
								},
							},
						},
				RenderInner	=	true,
				RenderMLCenter	=	true,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
					dd_beam	=	true,
					Offset	=	0,
					Speed	=	2000,
					Double	=	true,
					Intensity	=	0,
						},
				UseDynamic	=	true,
				RenderHD_Size	=	0.1,
				RenderInner_Clr	=	{
						255,
						155,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(36.349998474121,111.40000152588,36.669998168945),
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	2,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(37.319999694824,110.69999694824,36.700000762939),
								},
							},
						},
				RenderInner	=	true,
				UseBlinkers	=	true,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
					dd_beam	=	true,
					Offset	=	0,
					Speed	=	2000,
					Double	=	true,
					Intensity	=	0,
						},
				UseDynamic	=	true,
				RenderHD_Size	=	0.1,
				RenderInner_Clr	=	{
						255,
						155,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-35.669998168945,111.58000183105,36.819999694824),
				UseSprite	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	2,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-36.639999389648,110.87999725342,36.849998474121),
								},
							},
						},
				RenderInner_Size	=	1,
				RenderMLCenter	=	true,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
					dd_beam	=	true,
					Offset	=	0,
					Speed	=	2000,
					Double	=	true,
					Intensity	=	0,
						},
				UseDynamic	=	true,
				RenderHD_Size	=	0.1,
				RenderInner_Clr	=	{
						255,
						155,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(38.270000457764,109.41000366211,36.830001831055),
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	3,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(40.209999084473,106.12000274658,37.020000457764),
								},
							},
						},
				RenderInner_Size	=	1,
				RenderMLCenter	=	true,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
					dd_beam	=	true,
					Offset	=	0,
					Speed	=	2000,
					Double	=	true,
					Intensity	=	0,
						},
				UseDynamic	=	true,
				RenderHD_Size	=	0.1,
				RenderInner_Clr	=	{
						255,
						155,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-37.599998474121,109.59999847412,37),
				UseSprite	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	3,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-39.540000915527,106.30999755859,37.189998626709),
								},
							},
						},
				RenderInner_Size	=	1,
				RenderMLCenter	=	true,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					dd_beam	=	true,
					Offset	=	0,
					Speed	=	2000,
					Double	=	true,
					Intensity	=	0,
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						255,
						155,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(46.049999237061,41.639999389648,51.009998321533),
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	26,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(48.080001831055,40.020000457764,50.909999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(49.319999694824,38.840000152588,50.840000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(49.799999237061,38.189998626709,50.810001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(50.25,37.340000152588,50.790000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(50.389999389648,36.610000610352,50.790000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(50.400001525879,35.619998931885,50.779998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(50.479999542236,35.580001831055,50.020000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(50.439998626709,36.560001373291,50),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(50.25,37.659999847412,49.979999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(49.409999847412,38.930000305176,49.930000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(45.130001068115,42.360000610352,49.830001831055),
								},
							},
						},
				UseBlinkers	=	true,
				RenderInner	=	true,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					dd_beam	=	true,
					Offset	=	0,
					Speed	=	2000,
					Double	=	true,
					Intensity	=	0,
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						255,
						155,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-45.630001068115,41.889999389648,51.200000762939),
				UseSprite	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	26,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-47.659999847412,40.270000457764,51.099998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-48.900001525879,39.090000152588,51.029998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-49.380001068115,38.439998626709,51),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-49.830001831055,37.590000152588,50.979999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-49.970001220703,36.860000610352,50.979999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-49.979999542236,35.869998931885,50.970001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-50.060001373291,35.830001831055,50.209999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-50.020000457764,36.810001373291,50.189998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-49.830001831055,37.909999847412,50.169998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-48.950000762939,39.240001678467,50.130001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-44.709999084473,42.610000610352,50.020000457764),
								},
							},
						},
				UseBlinkers	=	true,
				RenderInner_Size	=	1,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
					dd_beam	=	true,
					Offset	=	0,
					Speed	=	2000,
					Double	=	true,
					Intensity	=	0,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
						225,
						225,
						255,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-24.260000228882,118.79000091553,26.5),
					Pos2	=	Vector(-31.760000228882,115.58999633789,30.520000457764),
					Use	=	true,
					Pos1	=	Vector(-25.420000076294,118,29.979999542236),
					Pos3	=	Vector(-30.840000152588,116.05999755859,27.309999465942),
						},
				HBeamColor	=	{
						255,
						255,
						255,
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-28.39999961853,116.12000274658,28.75),
				RenderInner_Size	=	1,
				RenderMLCenter	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				SpecMat	=	{
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.09,
						},
				SpecSpin	=	{
					Intensity	=	1,
					Speed	=	0,
						},
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	100,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-38.930000305176,-83.870002746582,41.849998474121),
				RenderInner_Size	=	1.2,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	100,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-36.959999084473,-88.879997253418,41.529998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.709999084473,-91.129997253418,41.299999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.360000610352,-93.160003662109,40.919998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.860000610352,-94.970001220703,40.509998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.200000762939,-96.559997558594,39.950000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.35000038147,-97.940002441406,39.200000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.379999160767,-98.970001220703,38.279998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-23.860000610352,-100.43000030518,36.180000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.639999389648,-99.830001831055,36.360000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.110000610352,-99.379997253418,36.430000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.450000762939,-98.830001831055,36.479999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.290000915527,-97.819999694824,36.529998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.020000457764,-96.559997558594,36.619998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.610000610352,-95.059997558594,36.939998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.909999847412,-93.400001525879,37.349998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.880001068115,-91.790000915527,37.959999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.639999389648,-90.080001831055,38.759998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.349998474121,-87.830001831055,39.990001678467),
								},
							{
							Pos	=	Vector(-38.889999389648,-84.76000213623,41.799999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseBrake	=	true,
					},
				},
		Copyright	=	"Copyright © 2012-2018 VCMod (freemmaann). All Rights Reserved.",
		Fuel	=	{
			FuelLidPos	=	Vector(42,-57.099998474121,44.970001220703),
			FuelType	=	0,
			Capacity	=	80,
			FuelLidUse	=	true,
			Override	=	true,
				},
		Author	=	"𝓒𝓣𝓥𝟏𝟐𝟐𝟓 (76561198051637331)",
}