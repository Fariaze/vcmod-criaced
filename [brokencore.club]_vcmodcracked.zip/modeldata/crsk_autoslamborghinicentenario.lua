VCModels['models/crsk_autoslamborghinicentenario.mdl']	=	{
		em_state	=	5236594431,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Date	=	"05/10/17 22:18:08",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-6.7300000190735,-107.12000274658,16.860000610352),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(6.7300000190735,-107.12000274658,16.860000610352),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-0.37999999523163,-107.12000274658,17.370000839233),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				RadioControl	=	true,
				Pos	=	Vector(17.659999847412,9.6300001144409,21.35000038147),
					},
				},
		DLT	=	3491062954,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.17,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
						193.93,
						229.45,
						254.76,
						},
				RenderInner	=	true,
				SpecMat	=	{
						},
				UseRunning	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(41.549999237061,88.279998779297,29.530000686646),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(39.950000762939,94.540000915527,25.809999465942),
								},
							{
							Pos	=	Vector(28.229999542236,102.81999969482,24.75),
							UseClr	=	false,
							Clr	=	{
									0,
									0,
									0,
									},
								},
							},
					Use	=	true,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
						195,
						195,
						255,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.17,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
						193.93,
						229.45,
						254.76,
						},
				RenderInner	=	true,
				SpecMat	=	{
						},
				UseRunning	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-41.159999847412,88.279998779297,29.530000686646),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					LTbl	=	{
							{
							Pos	=	Vector(-39.560001373291,94.540000915527,25.629999160767),
							UseClr	=	false,
							Clr	=	{
									0,
									0,
									0,
									},
								},
							{
							Pos	=	Vector(-27.840000152588,102.81999969482,24.75),
							UseClr	=	true,
							Clr	=	{
									195,
									195,
									255,
									},
								},
							},
					Use	=	true,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
						195,
						195,
						255,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
						190,
						226,
						255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
						195,
						195,
						255,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-37.369998931885,90.559997558594,27.780000686646),
				RenderInner	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseSprite	=	true,
				HBeamColor	=	{
						214,
						217,
						255,
						},
				RenderInner_Size	=	1,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
						190,
						226,
						255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
						195,
						195,
						255,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(37.369998931885,90.559997558594,27.780000686646),
				RenderInner	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseSprite	=	true,
				HBeamColor	=	{
						214,
						217,
						255,
						},
				RenderInner_Size	=	1,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.17,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
						193.93,
						229.45,
						254.76,
						},
				RenderInner	=	true,
				SpecMat	=	{
						},
				UseRunning	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(41.959999084473,92.01000213623,24.760000228882),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	2,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(39.759998321533,94.440002441406,25.780000686646),
							UseClr	=	false,
							Clr	=	{
									0,
									0,
									0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
						195,
						195,
						255,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.17,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseSprite	=	true,
				RunningColor	=	{
						193.93,
						229.45,
						254.76,
						},
				RenderInner_Size	=	1,
				SpecMat	=	{
						},
				UseRunning	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-41.959999084473,92.01000213623,24.409999847412),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					LTbl	=	{
							{
							Pos	=	Vector(-39.590000152588,94.440002441406,25.639999389648),
							UseClr	=	false,
							Clr	=	{
									0,
									0,
									0,
									},
								},
							},
					Use	=	true,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
						195,
						195,
						255,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.15,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseSprite	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				RenderInner	=	true,
				SpecMat	=	{
						},
				UseRunning	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-40.819999694824,-104.38999938965,34.659999847412),
				UseBrake	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-37.5,-106.61000061035,34.759998321533),
							UseClr	=	true,
							Clr	=	{
									255,
									55,
									0,
									},
								},
							{
							Pos	=	Vector(-28.739999771118,-111.87999725342,34.919998168945),
							UseClr	=	true,
							Clr	=	{
									255,
									55,
									0,
									},
								},
							{
							Pos	=	Vector(-21.659999847412,-114.2200012207,35.169998168945),
							UseClr	=	true,
							Clr	=	{
									255,
									55,
									0,
									},
								},
							},
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						255,
						55,
						0,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.15,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseSprite	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				RenderInner	=	true,
				SpecMat	=	{
						},
				UseRunning	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(40.819999694824,-103.98999786377,34.680000305176),
				UseBrake	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(37.5,-106.20999908447,34.779998779297),
							UseClr	=	true,
							Clr	=	{
									255,
									55,
									0,
									},
								},
							{
							Pos	=	Vector(28.739999771118,-111.48000335693,34.939998626709),
							UseClr	=	true,
							Clr	=	{
									255,
									55,
									0,
									},
								},
							{
							Pos	=	Vector(21.659999847412,-113.81999969482,35.189998626709),
							UseClr	=	true,
							Clr	=	{
									255,
									55,
									0,
									},
								},
							},
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						255,
						55,
						0,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.15,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseBrake	=	true,
				SpecMat	=	{
						},
				Beta_Inner3D	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-8.8299999237061,-111.94000244141,37.669998168945),
				RenderInner_Size	=	1,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	7,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-0.60000002384186,-111.83000183105,37.520000457764),
							UseClr	=	false,
							Clr	=	{
									0,
									0,
									0,
									},
								},
							{
							Pos	=	Vector(8.4099998474121,-110.9700012207,37.5),
							UseClr	=	false,
							Clr	=	{
									0,
									0,
									0,
									},
								},
							},
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						255,
						55,
						0,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.3,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(28.989999771118,101.05000305176,25.559999465942),
				RenderInner_Size	=	1,
				RenderInner	=	true,
				UseBlinkers	=	true,
				RenderInner_Clr	=	{
						255,
						55,
						0,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.3,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-28.989999771118,101.05000305176,25.559999465942),
				RenderInner_Size	=	1,
				RenderInner	=	true,
				UseBlinkers	=	true,
				RenderInner_Clr	=	{
						255,
						55,
						0,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-43.700000762939,-97.660003662109,36.479999542236),
				UseSprite	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	2,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-41.869998931885,-102.2799987793,34.740001678467),
								},
							},
						},
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
						255,
						155,
						0,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(43.189998626709,-98.290000915527,36.720001220703),
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	2,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(41.020000457764,-102.91000366211,34.810001373291),
								},
							},
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
						255,
						155,
						0,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.16,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseReverse	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-11.079999923706,-112.94999694824,32.299999237061),
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
						255,
						155,
						0,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.16,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseReverse	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(11.079999923706,-112.94999694824,32.299999237061),
				UseSprite	=	true,
				RenderInner_Size	=	1,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
						255,
						155,
						0,
						},
				RenderInner_ClrUse	=	true,
					},
				},
		Copyright	=	"Copyright © 2012-2017 VCMod (freemmaann). All Rights Reserved.",
		Fuel	=	{
			FuelLidPos	=	Vector(-40.259998321533,-35.459999084473,44.080001831055),
			FuelType	=	0,
			Capacity	=	100,
			Override	=	true,
			FuelLidUse	=	true,
				},
		Author	=	"CrushingSkirmish (76561198017348899)",
}