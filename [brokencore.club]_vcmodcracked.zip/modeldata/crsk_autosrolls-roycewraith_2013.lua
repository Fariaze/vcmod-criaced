VCModels['models/crsk_autosrolls-roycewraith_2013.mdl']	=	{
		em_state	=	5236594896,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Date	=	"05/18/17 14:42:15",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-26.440000534058,-112.83999633789,15.890000343323),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-21.889999389648,-113.54000091553,16.14999961853),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(26.440000534058,-112.83999633789,15.890000343323),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(21.889999389648,-113.54000091553,16.14999961853),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(18.120000839233,7.8800001144409,33.639999389648),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(-18.120000839233,-29.559999465942,31.139999389648),
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(18.120000839233,-30.559999465942,32.139999389648),
					},
				},
		DLT	=	3491063264,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Use	=	true,
					AmountV	=	4,
					Pos2	=	Vector(-33.729999542236,-110.19999694824,42.459999084473),
					AmountH	=	4,
					Pos4	=	Vector(-28.909999847412,-113.41999816895,37.680000305176),
					Pos1	=	Vector(-30.85000038147,-111.08000183105,43.400001525879),
					Pos3	=	Vector(-34.869998931885,-110.34999847412,37.819999694824),
						},
				UseDynamic	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-28.790000915527,-113.66000366211,37.349998474121),
					UseColor	=	true,
					Pos2	=	Vector(-33.709999084473,-110.09999847412,43.200000762939),
					Color	=	{
							255,
							100,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(-31.200000762939,-110.87000274658,43.450000762939),
					Pos3	=	Vector(-34.970001220703,-110.40000152588,37.110000610352),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-32.040000915527,-110.5299987793,39.939998626709),
				UseBrake	=	true,
				RenderInner	=	true,
				BlinkersColor	=	{
						255,
						55,
						0,
						},
				UseBlinkers	=	true,
				RenderInner_Size	=	2,
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.075,
						},
				SpecSpin	=	{
						},
				UseRunning	=	true,
				Beta_Inner3D	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-28.790000915527,-114.16000366211,37.020000457764),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	50,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-29.520000457764,-113.48999786377,39.229999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.25,-112.83999633789,40.970001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.799999237061,-112.16999816895,42.180000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.360000610352,-111.62999725342,42.959999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.559999465942,-111.44000244141,43.139999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.110000610352,-111.06999969482,43.169998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.930000305176,-110.59999847412,42.990001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.159999847412,-110.44000244141,42.889999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.450000762939,-110.34999847412,42.639999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.900001525879,-110.19000244141,42.110000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.430000305176,-110.19000244141,40.830001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.830001831055,-110.26000213623,39.240001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35,-110.37000274658,37.970001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.970001220703,-110.51000213623,37.209999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.669998168945,-110.80000305176,36.819999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.889999389648,-112.33000183105,36.759998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.030000686646,-113.36000061035,36.770000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.059999465942,-114.15000152588,36.869998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.840000152588,-114.13999938965,37.049999237061),
								},
							},
						},
				RenderInner	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-33.529998779297,-110.33999633789,37.590000152588),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	5,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-30,-112.29000091553,37.599998474121),
								},
							},
						},
				RenderInner_Size	=	1,
				UseSprite	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				RenderMLCenter	=	true,
				UseRunning	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-40.529998779297,96.099998474121,35.729999542236),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	3,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-40.779998779297,95.050003051758,35.720001220703),
								},
							},
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
						255,
						155,
						0,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-21.739999771118,109.87000274658,28.870000839233),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	7,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-31.770000457764,105.87000274658,28.760000228882),
								},
							},
						},
				UseSprite	=	true,
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
						195,
						195,
						255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-29.309999465942,102.44999694824,34.040000915527),
					Pos2	=	Vector(-34.130001068115,102.44999694824,38.860000610352),
					Color	=	{
							255,
							100,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(-29.309999465942,102.44999694824,38.860000610352),
					Pos3	=	Vector(-34.130001068115,102.44999694824,34.040000915527),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-31.719999313354,102.44999694824,36.450000762939),
				RenderMLCenter	=	true,
				UseSprite	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				HBeamColor	=	{
						195,
						195,
						255,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-28.680000305176,101.81999969482,37.490001678467),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-26.590000152588,103.73999786377,37.490001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.239999771118,104.87000274658,37.380001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-23.219999313354,105.55999755859,37.270000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-22.969999313354,105.95999908447,36.990001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-22.690000534058,106.5299987793,35.680000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.309999465942,105.31999969482,35.669998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.5,103.61000061035,35.639999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.64999961853,102.51999664307,35.639999389648),
								},
							},
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
						195,
						195,
						255,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Use	=	true,
					AmountV	=	4,
					Pos2	=	Vector(33.360000610352,-110.19999694824,42.180000305176),
					AmountH	=	4,
					Pos4	=	Vector(28.540000915527,-113.41999816895,37.400001525879),
					Pos1	=	Vector(30.479999542236,-111.08000183105,43.119998931885),
					Pos3	=	Vector(34.5,-110.34999847412,37.540000915527),
						},
				UseDynamic	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						55,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(31.670000076294,-110.5299987793,39.659999847412),
				UseBrake	=	true,
				RenderInner	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(28.420000076294,-113.66000366211,37.069999694824),
					UseColor	=	true,
					Pos2	=	Vector(33.340000152588,-110.09999847412,42.919998168945),
					Color	=	{
							255,
							100,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(30.829999923706,-110.87000274658,43.169998168945),
					Pos3	=	Vector(34.599998474121,-110.40000152588,36.830001831055),
						},
				UseBlinkers	=	true,
				RenderInner_Size	=	2,
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.075,
						},
				SpecSpin	=	{
						},
				UseRunning	=	true,
				Beta_Inner3D	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(28.35000038147,-114.16000366211,37.090000152588),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	50,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(29.079999923706,-113.48999786377,39.299999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.809999465942,-112.83999633789,41.040000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.360000610352,-112.16999816895,42.25),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.920000076294,-111.62999725342,43.029998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.120000839233,-111.44000244141,43.209999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.670000076294,-111.06999969482,43.240001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.490001678467,-110.59999847412,43.060001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.720001220703,-110.44000244141,42.959999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.009998321533,-110.34999847412,42.709999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.459999084473,-110.19000244141,42.180000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.990001678467,-110.19000244141,40.900001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.389999389648,-110.26000213623,39.310001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.560001373291,-110.37000274658,38.040000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.529998779297,-110.51000213623,37.279998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.229999542236,-110.80000305176,36.889999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.450000762939,-112.33000183105,36.830001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.590000152588,-113.36000061035,36.840000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.620000839233,-114.15000152588,36.939998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.39999961853,-114.13999938965,37.119998931885),
								},
							},
						},
				RenderInner_Size	=	1,
				RunningColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				UseSprite	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				SpecMLine	=	{
					Amount	=	5,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(29.540000915527,-112.36000061035,37.5),
								},
							},
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(33.069999694824,-110.41000366211,37.490001678467),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				RenderMLCenter	=	true,
				UseRunning	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(41.080001831055,96.050003051758,35.540000915527),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	3,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(41.330001831055,95,35.529998779297),
								},
							},
						},
				UseSprite	=	true,
				RunningColor	=	{
						255,
						155,
						0,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner_Size	=	1,
				UseSprite	=	true,
				Pos	=	Vector(22.510000228882,109.73999786377,28.819999694824),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	7,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(32.470001220703,105.75,28.719999313354),
								},
							},
						},
				Beta_Inner3D	=	true,
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
						195,
						195,
						255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(29.829999923706,102.33000183105,34.110000610352),
					Pos2	=	Vector(34.650001525879,102.33000183105,38.930000305176),
					Color	=	{
							255,
							100,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(29.829999923706,102.33000183105,38.930000305176),
					Pos3	=	Vector(34.650001525879,102.33000183105,34.110000610352),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(32.240001678467,102.33000183105,36.520000457764),
				RenderMLCenter	=	true,
				Beta_Inner3D	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				HBeamColor	=	{
						195,
						195,
						255,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(29.25,101.7200012207,37.310001373291),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(27.159999847412,103.63999938965,37.310001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.809999465942,104.76999664307,37.200000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(23.790000915527,105.45999908447,37.090000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(23.540000915527,105.86000061035,36.810001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(23.260000228882,106.43000030518,35.5),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.879999160767,105.2200012207,35.490001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.069999694824,103.51000213623,35.459999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.219999313354,102.41999816895,35.459999084473),
								},
							},
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
						195,
						195,
						255,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseBrake	=	true,
				UseSprite	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-12.949999809265,-63.639999389648,63.110000610352),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	35,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-6.4699997901917,-63.639999389648,63.590000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(0,-63.639999389648,63.639999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(6.4699997901917,-63.639999389648,63.540000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(12.949999809265,-63.639999389648,63.110000610352),
								},
							},
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderMLCenter	=	true,
					},
				},
		Copyright	=	"Copyright © 2012-2017 VCMod (freemmaann). All Rights Reserved.",
		Fuel	=	{
			FuelType	=	0,
			FuelLidUse	=	true,
			FuelLidPos	=	Vector(41.360000610352,-72.019996643066,44.950000762939),
				},
		Author	=	"freemmaann (76561197989323181)",
}