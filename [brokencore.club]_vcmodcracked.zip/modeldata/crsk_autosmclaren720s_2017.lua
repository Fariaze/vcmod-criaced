VCModels['models/crsk_autosmclaren720s_2017.mdl']	=	{
		em_state	=	5236594614,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		HealthEnginePosOvr	=	true,
		Date	=	"Sun Jul 23 16:20:28 2017",
		Exhaust	=	{
				{
				Ang	=	Angle(-5,-100,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(-13.470000267029,-96.699996948242,30.670000076294),
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(-5,-80,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(13.180000305176,-96.730003356934,30.579999923706),
				EffectIdle	=	"VC_Exhaust",
					},
				},
		Copyright	=	"Copyright © 2012-2017 VCMod (freemmaann). All Rights Reserved.",
		HealthEnginePos	=	Vector(-0.5,-74,13),
		DLT	=	3491063076,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						200,
						225,
						255,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseBrake	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(36.569999694824,-83.23999786377,33.119998931885),
				RenderInner_Size	=	1,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	100,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(34.900001525879,-85.48999786377,33.849998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.819999694824,-86.910003662109,34.279998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.979999542236,-87.879997253418,34.549999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.049999237061,-88.889999389648,34.830001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.14999961853,-89.75,35),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.200000762939,-90.540000915527,35.110000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.170000076294,-91.319999694824,35.180000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.25,-91.940002441406,35.200000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.079999923706,-92.610000610352,35.180000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.389999389648,-93,35.150001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.659999847412,-93.339996337891,35.090000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(23.969999313354,-94.080001831055,34.919998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(21.819999694824,-94.900001525879,34.650001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(19.959999084473,-95.519996643066,34.430000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(17.60000038147,-96.190002441406,34.180000305176),
								},
							},
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.06,
						},
				SpecSpin	=	{
						},
				DD_Blnk_Run	=	true,
				UseDynamic	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						255,
						180,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						55,
						0,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-35.779998779297,-84.150001525879,32.720001220703),
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	40,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-34.959999084473,-85.290000915527,33.130001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.720001220703,-86.819999694824,33.669998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.860000610352,-87.839996337891,33.979999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.200000762939,-88.559997558594,34.189998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.559999465942,-89.209999084473,34.369998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.030000686646,-89.730003356934,34.490001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.409999847412,-90.25,34.599998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.659999847412,-90.819999694824,34.689998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.860000610352,-91.370002746582,34.770000457764),
								},
							},
						},
				UseBrake	=	true,
				RenderInner	=	true,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.06,
						},
				SpecSpin	=	{
						},
				DD_Blnk_Run	=	true,
				UseDynamic	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						255,
						180,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						55,
						0,
						},
				UseBrake	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(35.450000762939,-84.300003051758,32.549999237061),
				UseSprite	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	40,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(34.630001068115,-85.440002441406,32.959999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.389999389648,-86.970001220703,33.5),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.529998779297,-87.98999786377,33.810001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.870000839233,-88.709999084473,34.020000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.229999542236,-89.360000610352,34.200000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.700000762939,-89.870002746582,34.330001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.10000038147,-90.400001525879,34.450000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.35000038147,-90.959999084473,34.549999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.530000686646,-91.51000213623,34.630001068115),
								},
							},
						},
				RenderMLCenter	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.07,
						},
				SpecSpin	=	{
						},
				DD_Blnk_Run	=	true,
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						200,
						225,
						255,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-38.549999237061,82.080001831055,22.14999961853),
				UseBlinkers	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	40,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-37.669998168945,83.410003662109,21.989999771118),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.759998321533,84.690002441406,21.840000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.130001068115,85.540000915527,21.729999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.470001220703,86.360000610352,21.620000839233),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.790000915527,87.180000305176,21.510000228882),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.139999389648,87.940002441406,21.39999961853),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.740001678467,88.379997253418,21.340000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.380001068115,88.73999786377,21.291999816895),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.979999542236,89.120002746582,21.239999771118),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.909999847412,90.089996337891,21.079999923706),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.459999084473,90.480003356934,21.010000228882),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.129999160767,92.419998168945,20.690000534058),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.35000038147,93.839996337891,20.430000305176),
								},
							},
						},
				RenderInner	=	true,
				RunningColor	=	{
						200,
						225,
						255,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.07,
						},
				SpecSpin	=	{
						},
				DD_Blnk_Run	=	true,
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						200,
						225,
						255,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(39,81.910003662109,21.979999542236),
				RenderMLCenter	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	40,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(38.119998931885,83.290000915527,21.840000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.209999084473,84.559997558594,21.690000534058),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.580001831055,85.400001525879,21.590000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.919998168945,86.220001220703,21.479999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.240001678467,87.040000915527,21.370000839233),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.590000152588,87.800003051758,21.260000228882),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.189998626709,88.23999786377,21.200000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.830001831055,88.599998474121,21.152000427246),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.430000305176,88.980003356934,21.10000038147),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.360000610352,89.949996948242,20.940000534058),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.909999847412,90.339996337891,20.870000839233),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.579999923706,92.279998779297,20.549999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.860000610352,93.669998168945,20.309999465942),
								},
							},
						},
				UseSprite	=	true,
				RunningColor	=	{
						200,
						225,
						255,
						},
				RenderInner	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				LBeamColor	=	{
						195,
						195,
						255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderHD_Size	=	0.5,
				RenderInner_Clr	=	{
						200,
						225,
						255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-37.630001068115,76.819999694824,26.709999084473),
				RenderInner	=	true,
				RenderInner_Size	=	1,
				UseSprite	=	true,
				HBeamColor	=	{
						195,
						195,
						255,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				LBeamColor	=	{
						195,
						195,
						255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderHD_Size	=	0.5,
				RenderInner_Clr	=	{
						200,
						225,
						255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(38.580001831055,76.319999694824,26.629999160767),
				RenderInner_Size	=	1,
				RenderInner	=	true,
				UseSprite	=	true,
				HBeamColor	=	{
						195,
						195,
						255,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				LBeamColor	=	{
						195,
						195,
						255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderHD_Size	=	0.5,
				RenderInner_Clr	=	{
						200,
						225,
						255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				HBeamColor	=	{
						195,
						195,
						255,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-35.549999237061,77.830001831055,26.370000839233),
				RenderInner	=	true,
				RenderInner_Size	=	1,
				Beta_Inner3D	=	true,
				SpecMat	=	{
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				LBeamColor	=	{
						195,
						195,
						255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderHD_Size	=	0.5,
				RenderInner_Clr	=	{
						200,
						225,
						255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				HBeamColor	=	{
						195,
						195,
						255,
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-33.619998931885,79.029998779297,25.809999465942),
				RenderInner	=	true,
				RenderInner_Size	=	1,
				UseSprite	=	true,
				SpecMat	=	{
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				LBeamColor	=	{
						195,
						195,
						255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderHD_Size	=	0.5,
				RenderInner_Clr	=	{
						200,
						225,
						255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				HBeamColor	=	{
						195,
						195,
						255,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-32.540000915527,79.800003051758,25.479999542236),
				RenderInner	=	true,
				RenderInner_Size	=	1,
				Beta_Inner3D	=	true,
				SpecMat	=	{
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				LBeamColor	=	{
						195,
						195,
						255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderHD_Size	=	0.5,
				RenderInner_Clr	=	{
						200,
						225,
						255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				HBeamColor	=	{
						195,
						195,
						255,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-31.170000076294,80.970001220703,25.069999694824),
				RenderInner	=	true,
				RenderInner_Size	=	1,
				Beta_Inner3D	=	true,
				SpecMat	=	{
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
						195,
						195,
						255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderHD_Size	=	0.5,
				RenderInner_Clr	=	{
						200,
						225,
						255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-29.889999389648,82.019996643066,24.709999084473),
				RenderInner	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseSprite	=	true,
				RenderInner_Size	=	1,
				HBeamColor	=	{
						195,
						195,
						255,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				LBeamColor	=	{
						195,
						195,
						255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderHD_Size	=	0.5,
				RenderInner_Clr	=	{
						200,
						225,
						255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				HBeamColor	=	{
						195,
						195,
						255,
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(36,77.839996337891,26.209999084473),
				RenderInner_Size	=	1,
				SpecMat	=	{
						},
				UseSprite	=	true,
				RenderInner	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				LBeamColor	=	{
						195,
						195,
						255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderHD_Size	=	0.5,
				RenderInner_Clr	=	{
						200,
						225,
						255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				HBeamColor	=	{
						195,
						195,
						255,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(34.119998931885,79.040000915527,25.690000534058),
				RenderInner_Size	=	1,
				SpecMat	=	{
						},
				Beta_Inner3D	=	true,
				RenderInner	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				LBeamColor	=	{
						195,
						195,
						255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderHD_Size	=	0.5,
				RenderInner_Clr	=	{
						200,
						225,
						255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				HBeamColor	=	{
						195,
						195,
						255,
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(32.979999542236,79.800003051758,25.329999923706),
				RenderInner_Size	=	1,
				SpecMat	=	{
						},
				UseSprite	=	true,
				RenderInner	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				LBeamColor	=	{
						195,
						195,
						255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderHD_Size	=	0.5,
				RenderInner_Clr	=	{
						200,
						225,
						255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				HBeamColor	=	{
						195,
						195,
						255,
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(31.670000076294,80.970001220703,24.930000305176),
				RenderInner	=	true,
				SpecMat	=	{
						},
				UseSprite	=	true,
				RenderInner_Size	=	1,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
						195,
						195,
						255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderHD_Size	=	0.5,
				RenderInner_Clr	=	{
						200,
						225,
						255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(30.360000610352,82.019996643066,24.559999465942),
				RenderInner_Size	=	1,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				HBeamColor	=	{
						195,
						195,
						255,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.07,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderHD_Size	=	0.5,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						200,
						225,
						255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBrake	=	true,
				RenderHD_Adv	=	true,
				Pos	=	Vector(-4.1300001144409,-58.830001831055,40.659999847412),
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	19,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(4,-58.849998474121,40.659999847412),
								},
							},
						},
				RenderInner_Size	=	1,
				UseSprite	=	true,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						200,
						225,
						255,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-36.900001525879,-83.120002746582,33.310001373291),
				RenderInner_Size	=	1,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	100,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-35.220001220703,-85.389999389648,34.029998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.159999847412,-86.779998779297,34.459999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.330001831055,-87.75,34.740001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.389999389648,-88.769996643066,35),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.510000228882,-89.629997253418,35.169998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.540000915527,-90.419998168945,35.290000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.489999771118,-91.209999084473,35.369998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.559999465942,-91.819999694824,35.369998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.389999389648,-92.5,35.340000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.709999084473,-92.870002746582,35.290000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.010000228882,-93.220001220703,35.229999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.299999237061,-93.959999084473,35.029998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-22.139999389648,-94.779998779297,34.740001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-20.280000686646,-95.410003662109,34.509998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-17.89999961853,-96.080001831055,34.25),
								},
							},
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				UseDynamic	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				RenderInner_Clr	=	{
						200,
						225,
						255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-1.1100000143051,-95.230003356934,14.090000152588),
				RenderMLCenter	=	true,
				RenderInner_Size	=	0.5,
				SpecMLine	=	{
					Amount	=	4,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(0.68999999761581,-95.25,14.090000152588),
								},
							},
						},
				RenderHD_Adv	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(20,0,0),
				Pos	=	Vector(15.539999961853,14.590000152588,20.639999389648),
				RadioControl	=	true,
					},
				},
		Fuel	=	{
			FuelLidPos	=	Vector(-41.580001831055,-52.700000762939,36.819999694824),
			FuelType	=	0,
			Capacity	=	72,
			Override	=	true,
			FuelLidUse	=	true,
				},
		Author	=	"CгεερεгƬv (76561198051637331)",
}