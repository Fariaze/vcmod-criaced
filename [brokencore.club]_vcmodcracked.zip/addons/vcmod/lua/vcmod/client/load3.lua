
local El = {}
function El:Init()
    if self:GetTall() == 24 then self:SetTall(43) end
end

net.Receive("VC_RM_Send_Menu_Open", function(len)
    local ent, tbl, plytbl, int, admin = net.ReadEntity(), net.ReadTable(), net.ReadTable(), net.ReadInt(8), net.ReadInt(4)
    if IsValid(ent) then
        if admin and admin == 1 then
            VC.RM.open_menu_choice(ent, tbl, plytbl, int)
        else
            VC.RM.open_menu_main(ent, tbl, plytbl, int)
        end
    end
end)

net.Receive("VC_RM_SendInfo_Import_NPC", function(len)
    local ent, tbl = net.ReadEntity(), net.ReadTable()
    VC.RM.Import_NPC_Tbl = {ent, tbl}
end)

function El:Paint(Sx, Sy)
    local nSx = Sx - 40
    local hov = self:IsHovered()
    local selected = self:GetSelected()
    local working = self.VC_Working
    local current = self:GetCurrent() and IsValid(self.VC_Ent) and self.VC_Ent.VC_RM_LastFixing
    local prc = 0
    if current then prc = (CurTime() - self.VC_Ent.VC_RM_LastFixing.time_s) / self:GetTime() end
    local fdv = VC.FadeW / 2
    if selected or working then VC.DrawFadeRect(fdv, 0, Sx - VC.FadeW, Sy, current and Color(Lerp(prc, 155, 0), Lerp(prc, 0, 100), Lerp(prc, 0, 0), 150 - math.sin(CurTime() * 10) * 55) or working and Color(100, 0, 0, 150) or Color(0, 55, 0, 100)) end
    if hov then VC.DrawFadeRect(fdv, 0, Sx - VC.FadeW, Sy, Color(155, 155, 155, 45)) end
    local clr = VC.Color.White
    if selected then clr = VC.Color.Good end
    if working then clr = VC.Color.Bad end
    if hov then clr = VC.Color.Neutral end
    draw.RoundedBox(0, 20, Sy - 4, Sx - 40, 2, clr)
    if self.VC_Icon then
        local isx, isy = Sx, Sy * 0.65
        surface.SetDrawColor(selected and VC.Color.Good or Color(255, 255, 255, 255 * self:GetAlpha()))
        surface.SetMaterial(self.VC_Icon)
        surface.DrawTexturedRect(20 + Sy / 2 - isy / 2, isy / 5, isy, isy)
    end

    local symbol = VC.getCurCurrency().symbol
    if self.VC_Cost and not working then draw.SimpleText(symbol .. VC.PreparePrice(self.VC_Cost), "VC_Regular_Ms", Sx - 2 - 20, Sy - 15, VC.Color.Good, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER) end
    if self.VC_Time then
        local time = math.Round(self.VC_Time - self.VC_Time * prc)
        if time < 0 then time = 0 end
        draw.SimpleText(time .. " " .. VC.Lng("sec"), "VC_Regular_Ms", Sx - 2 - 20, Sy - 30, VC.Color.Blue, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
    end

    if self.VC_Text then draw.SimpleText(self.VC_Text, "VC_Dev_Text", 60, 10, self.VC_Clr_Base or VC.Color.White, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER) end
    if working then
        local rclr = VC.Color.Blue
        if current then
            rclr = Color(Lerp(prc, rclr.r, VC.Color.Good.r), Lerp(prc, rclr.g, VC.Color.Good.g), Lerp(prc, rclr.b, VC.Color.Good.b), 255)
            prc = math.Clamp(math.Round(prc * 100), 0, 100)
        end

        draw.SimpleText(VC.Lng("Repairing") .. " " .. prc .. "%", "VC_Regular_Ms", 60, Sy - 15, rclr, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    end
end

function El:OnMousePressed(MB)
    self:SetSelected(not self:GetSelected())
end

function El:SetIcon(val)
    self.VC_Icon = val
end

function El:GetIcon()
    return self.VC_Icon
end

function El:SetCost(val)
    self.VC_Cost = val
end

function El:GetCost()
    return self.VC_Cost
end

function El:SetTime(val)
    self.VC_Time = val
end

function El:GetTime()
    return self.VC_Time
end

function El:SetSelected(val)
    if self:GetParent() and self:GetParent():GetParent() and self:GetParent():GetParent():GetParent() then self:GetParent():GetParent():GetParent().VC_Refresh_Total = true end
    self.VC_Selected = not self:GetWorking() and val
end

function El:GetSelected()
    return self.VC_Selected
end

function El:SetData(val)
    self.VC_Data = val
end

function El:GetData(val)
    return self.VC_Data
end

function El:SetCurrent(val)
    self.VC_Current = self:GetWorking() and val
end

function El:GetCurrent()
    return self.VC_Current
end

function El:SetVCText(val)
    self:SetText("")
    self.VC_Text = VC.Lng(val or "")
end

function El:GetVCText()
    return self.VC_Text
end

function El:SetBaseColor(val)
    self.VC_Clr_Base = val
end

function El:GetBaseColor()
    return self.VC_Clr_Base
end

function El:SetWorking(val)
    self.VC_Working = val
end

function El:GetWorking()
    return self.VC_Working
end

derma.DefineControl("VC_Repair_Obj", "VCMod's repair object.", El, "DButton")
local function getHealthColor(prc)
    local clr = VC.Color.White
    if prc <= 0.15 then
        clr = VC.Color.Bad
    elseif prc < 0.4 then
        clr = VC.Color.Neutral
    end
    return clr
end

function VC.RM.open_menu_main_pre(ent, npc, npctbl, npcint)
    net.Start("VC_RM_open_menu_main_pre")
    net.WriteEntity(ent)
    net.WriteEntity(npc)
    net.WriteTable(npctbl)
    net.WriteInt(npcint, 4)
    net.SendToServer()
end

net.Receive("VC_RM_UpdateInfo", function()
    local ent = net.ReadEntity()
    if not IsValid(ent) then return end
    local tbl = net.ReadTable()
    if table.Count(tbl) == 0 then tbl = nil end
    if IsValid(VC.RM.Menu) then VC_RM_Refresh_Objects = true end
    ent.VC_RM_LastFixing = tbl
end)

net.Receive("VC_RM_open_menu_main", function()
    local ent, npc, npctbl, npcint, tbl, cur = net.ReadEntity(), net.ReadEntity(), net.ReadTable(), net.ReadInt(4), net.ReadTable(), net.ReadString()
    VC.RM.open_menu_main(ent, npc, npctbl, npcint, tbl, cur)
end)

function VC.DamagedLightIsELS(ent, key)
    local isELS = false
    local side = 1
    local OD = VC_suckfreemmann(ent)
    local mdl = VC.GetModel(ent)
    if OD.LPT and OD.LPT[key] and ent.VC_DamagedObjects then
        if OD.LPT[key].els then isELS = true end
        local pos = OD.LPT[key].Pos
        if pos.x < 0 then
            if pos.y < 0 then side = 3 end
        else
            if pos.y < 0 then
                side = 4
            else
                side = 2
            end
        end
    end
    return {
        side = side,
        isELS = isELS
    }
end

function VC.RM.open_menu_main(ent, npc, npctbl, npcint, tbl, cur)
    local MPx = ScrW() * 0.7
    local MPy = ScrH() * 0.6
    local Objects = {}
    local CreatedObjects = {}
    local function ReinitObjects()
        Objects = {}
        local prc = ent:GetNWInt("VC_HealthPerc", 1)
        if prc < 1 then
            if prc > 0 then
                Objects[1] = {
                    var = "engine",
                    varint = 1,
                    name = VC.Lng("Engine") .. " " .. math.Round(prc * 100) .. "%",
                    side = 0,
                    working = tbl and tbl.objects and tbl.objects["engine1"],
                    cost = 0,
                    time = math.Round(5 + VC.GetPartInfo("engine").time * (1 - prc) * 0.5),
                    icon = VC.GetPartIcon("engine"),
                    clr_base = getHealthColor(prc)
                }
            else
                Objects[1] = {
                    var = "engine",
                    varint = 1,
                    name = "EngineNew",
                    side = 0,
                    cost = VC.GetPartInfo("engine").price,
                    working = tbl and tbl.objects and tbl.objects["engine1"],
                    time = VC.GetPartInfo("engine").time,
                    icon = VC.GetPartIcon("engine"),
                    clr_base = getHealthColor(prc)
                }
            end
        end

        if ent.VC_DamagedObjects then
            for k, v in pairs(ent.VC_DamagedObjects) do
                if k ~= "L_ELS" then
                    for k2, v2 in pairs(v) do
                        if k == "wheel" then
                            table.insert(Objects, {
                                var = k,
                                varint = k2,
                                side = k2,
                                name = VC.SideNames[k2],
                                cost = VC.GetPartInfo(k).price,
                                working = tbl and tbl.objects and tbl.objects[k .. k2],
                                time = VC.GetPartInfo(k).time,
                                icon = VC.GetPartIcon(k)
                            })
                        end

                        if k == "light" then
                            local ELSData = VC.DamagedLightIsELS(ent, k2)
                            local isELS = ELSData.isELS
                            local side = ELSData.side
                            table.insert(Objects, {
                                var = k,
                                varint = k2,
                                side = side,
                                name = VC.SideNames[side],
                                cost = VC.GetPartInfo(k).price,
                                working = tbl and tbl.objects and tbl.objects[k .. k2],
                                time = VC.GetPartInfo(k).time,
                                icon = VC.GetPartIcon(k .. (isELS and "_els" or ""))
                            })
                        end

                        if k == "exhaust" then
                            table.insert(Objects, {
                                var = k,
                                varint = k2,
                                side = side,
                                name = "Exhaust",
                                cost = VC.GetPartInfo(k).price,
                                working = tbl and tbl.objects and tbl.objects[k .. k2],
                                time = VC.GetPartInfo(k).time,
                                icon = VC.GetPartIcon(k)
                            })
                        end
                    end
                end
            end
        end
    end

    ReinitObjects()
    local Pnl = vgui.Create("DFrame")
    Pnl:SetSize(MPx, MPy)
    Pnl:SetTitle("")
    Pnl:SetPos(ScrW() / 2 - Pnl:GetWide() / 2, ScrH() / 2 - Pnl:GetTall() / 2)
    Pnl:SetDraggable(false)
    Pnl:ShowCloseButton(false)
    Pnl:NoClipping(true)
    Pnl:AlphaTo(0, 0, 0)
    Pnl:AlphaTo(255, 0.2, 0)
    VC.RM.Main_Pnl = Pnl
    Pnl.FrameRate = 0
    Pnl:SizeTo(0, MPy, 0)
    Pnl:SizeTo(MPx, MPy, 0.2, 0.2, 1)
    local clr = table.Copy(VC.Color.Main)
    clr.a = 200
    VC.RM.Menu = Pnl
    Pnl.Paint = function(obj, Sx, Sy)
        local tclr = VC.Color.Main
        tclr = tclr and table.Copy(tclr)
        if not fade then fade = VC.FadeW end
        Sx = math.Round(Sx)
        Sy = math.Round(Sy)
        local Px = 0
        local Py = 0
        local Sy2 = math.Round(Sy / 2)
        draw.RoundedBox(0, math.Round(Px + fade / 2), Py, Sx - fade, Sy, tclr)
        surface.SetDrawColor(tclr)
        surface.SetMaterial(VC.Material.Fade)
        surface.DrawTexturedRectRotated(Px + Sx, Py + Sy2, fade, Sy, 0)
        surface.DrawTexturedRectRotated(Px, Py + Sy2, fade, Sy, 180)
    end

    local RepairPanel = VC.Add_El_List(20, 0, 200, Pnl:GetTall())
    RepairPanel.StartPos_X, RepairPanel.StartPos_Y = RepairPanel:GetPos()
    RepairPanel:SetParent(Pnl)
    RepairPanel:AlphaTo(0, 0, 0)
    RepairPanel:AlphaTo(255, 0.2, 0.2)
    RepairPanel:NoClipping(true)
    RepairPanel.Paint = function(obj, Sx, Sy)
        draw.RoundedBox(0, 0, 0, Sx - 10, Sy, clr)
        surface.SetDrawColor(clr)
        surface.SetMaterial(VC.Material.Fade)
        surface.DrawTexturedRectRotated(Sx + VC.FadeW / 2 - 10, Sy / 2, VC.FadeW, Sy, 0)
        surface.DrawTexturedRectRotated(-VC.FadeW / 2, Sy / 2, VC.FadeW, Sy, 180)
        draw.RoundedBox(0, -10, Sy - 70, Sx + 20, 1, VC.Color.Blue)
    end

    local Lbl1 = vgui.Create("DLabel")
    Lbl1:SetTall(30)
    Lbl1:SetText("")
    RepairPanel:AddItem(Lbl1)
    local ModelView_sel = vgui.Create("DModelPanel", Pnl)
    ModelView_sel:SetSize(MPx - RepairPanel:GetWide() - 50, MPy)
    ModelView_sel:SetPos(RepairPanel:GetWide() + 50, MPy / 2 - ModelView_sel:GetTall() / 2)
    ModelView_sel:SetModel("")
    ModelView_sel.ModelLength = 0
    ModelView_sel.RBounds = Vector(0, 0, 0)
    ModelView_sel.VC_RotX = 0
    ModelView_sel.VC_RotY = 0
    ModelView_sel.FarZ = ModelView_sel.FarZ / 1
    local ModelView = vgui.Create("DModelPanel", Pnl)
    ModelView:SetSize(MPx - RepairPanel:GetWide() - 50, MPy)
    ModelView:SetPos(RepairPanel:GetWide() + 50, MPy / 2 - ModelView:GetTall() / 2)
    ModelView:SetModel("")
    ModelView.ModelLength = 0
    ModelView.RBounds = Vector(0, 0, 0)
    ModelView.VC_RotX = 0
    ModelView.VC_RotY = 0
    ModelView.FarZ = ModelView.FarZ / 1
    local Close = vgui.Create("DImageButton")
    Close:SetMaterial(VC.Material.Cross)
    Close:SetSize(30, 30)
    Close:SetPos(Pnl:GetWide() - Close:GetWide() - 5, 5)
    Close:SetParent(Pnl)
    Close:SetText("")
    Close.DoClick = function() Pnl:Close() end
    Pnl:AlphaTo(0, 0, 0)
    Pnl:AlphaTo(255, 0.2, 0.2)
    Pnl.PaintOver = function(obj, Sx, Sy)
        surface.SetFont("VC_Big")
        local name = VC.getName(ent, VC.Lng("Unknown"))
        local extra = RepairPanel:GetWide() / 2
        local tsize = surface.GetTextSize(name)
        local Py = -math.abs(ModelView.VC_Progress / 15)
        local start = math.Round(Sx / 2 - tsize / 2 + ModelView.VC_Progress * 1.2 + extra)
        local tclr = table.Copy(VC.Color.Good)
        tclr.a = 500 - math.abs(ModelView.VC_Progress) * 2
        local dclr = table.Copy(clr)
        dclr.a = tclr.a
        draw.DrawText(VC.getName(ent, VC.Lng("Unknown")), "VC_Big", Sx / 2 + ModelView.VC_Progress * 1.25 + extra, 75 + Py, tclr, TEXT_ALIGN_CENTER)
        local text = npctbl.Name
        surface.SetFont("VC_Name")
        local tz = surface.GetTextSize(text) + 20
        local PSx, PSy = tz, 50
        local tclr = table.Copy(VC.Color.Blue)
        draw.SimpleText(text, "VC_Name", 250 + 40, 25 + 2, tclr, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        surface.SetDrawColor(tclr)
        surface.SetMaterial(VC.Material.icon_repair)
        surface.DrawTexturedRect(250, 8 + 2, 35, 35)
        draw.SimpleText(VC.Lng("DamagedParts") .. ":", "VC_Menu_Side", 15, 25, VC.Color.Blue, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    end

    local angData = {
        [0] = -80,
        [1] = -50,
        [2] = -140,
        [3] = 50,
        [4] = 140,
    }

    local function getSelAng(int)
        local ang = nil
        local obj = nil
        for k, v in pairs(CreatedObjects) do
            if v:IsHovered() then
                ang = angData[v.side]
                obj = v:GetData().obj
                Pnl.VC_LastObj = obj
                Pnl.VC_LastInt = v:GetData().int
                break
            end
        end

        local nmld = ang and "models/dav0r/hoverball.mdl" or ""
        if ang then ModelView.VC_RotX = ang end
        local mdl = ModelView_sel:GetModel()
        if (mdl or "") ~= nmld then
            ModelView_sel:SetModel(nmld)
            local ment = ModelView_sel:GetEntity()
            if IsValid(ment) then ment:SetMaterial("models/wireframe") end
        end
        return ang
    end

    function ModelView_sel:LayoutEntity()
        return
    end

    function ModelView:LayoutEntity()
        local tvec = Vector(0, 1500, 0)
        tvec:Rotate(Angle(0, math.Clamp(ModelView.VC_Progress, -3000, 3000) / (50 - math.abs(ModelView.VC_Progress / 10)), 0))
        tvec = tvec - Vector(0, 1500, 0)
        Pnl.VC_SelAngX = not ModelView.VC_IsCapturing_Right and getSelAng()
        ModelView.R_Ang_Rot_X = Lerp(angx and 0.12 or 0.05, ModelView.R_Ang_Rot_X or ModelView.VC_RotX, Pnl.VC_SelAngX or ModelView.VC_RotX)
        ModelView.R_Ang_Rot_Y = Lerp(0.05, ModelView.R_Ang_Rot_Y or ModelView.VC_RotY, ModelView.VC_RotY)
        local ang = Angle(ModelView.R_Ang_Rot_Y + 15, ModelView.R_Ang_Rot_X, 0)
        local offset = ModelView.RBounds.y
        local pos = -ang:Forward() * (250 - tvec.y * 2) + ang:Up() * 35 + ang:Right() * tvec.x - ang:Forward() * 50 - ang:Up() * ang.p / 2 - ang:Forward() * (-200 - offset * 1.6)
        ModelView.VC_LookAng = ang
        ModelView.VC_LookPos = pos
        ModelView:SetLookAng(ang)
        ModelView:SetCamPos(pos)
        local epos = Vector(0, 0, 0)
        if IsValid(ent) and Pnl.VC_LastObj then epos = VC.GetObjectPos(ent, Pnl.VC_LastObj, Pnl.VC_LastInt, 137) end
        ModelView_sel:SetLookAng(ang)
        ModelView_sel:SetCamPos(pos - epos)
        return
    end

    ModelView.R_Ang_Rot_X = 50
    ModelView.VC_Progress = -400
    ModelView.VC_LastSpeed = -20
    function ModelView:OnMousePressed(code)
        local Mx, My = gui.MousePos()
        ModelView.VC_IsCapturing_Right = {
            x = Mx,
            y = My
        }
    end

    function ModelView:OnMouseReleased(code)
        ModelView.VC_IsCapturing_Right = false
        ModelView.VC_LastRight_X = nil
        ModelView.VC_LastRight_Y = nil
    end

    ModelView.Think = function()
        local limit = 200
        if not ModelView:IsHovered() then
            if ModelView.VC_IsCapturing then ModelView:OnMouseReleased(MOUSE_LEFT) end
            if ModelView.VC_IsCapturing_Right then ModelView:OnMouseReleased(MOUSE_RIGHT) end
        end

        if not ModelView.VC_Progress then ModelView.VC_Progress = 0 end
        if ModelView.VC_IsCapturing_Right then
            local Mx, My = gui.MousePos()
            ModelView.VC_RotX = ModelView.VC_RotX + ((ModelView.VC_LastRight_X or Mx) - Mx)
            ModelView.VC_RotY = math.Clamp(ModelView.VC_RotY - ((ModelView.VC_LastRight_Y or My) - My), -15, 25)
            ModelView.VC_LastRight_X = Mx
            ModelView.VC_LastRight_Y = My
        else
            if not Pnl.VC_SelAngX then ModelView.VC_RotX = ModelView.VC_RotX + 0.04 end
            ModelView.VC_RotY = math.Approach(ModelView.VC_RotY, 0, 0.01)
        end

        if ModelView.VC_IsCapturing then
            local Mx, My = gui.MousePos()
            ModelView.VC_LastSpeed = ModelView.VC_Progress - (Mx - ModelView.VC_IsCapturing.x)
            ModelView.VC_Progress = Mx - ModelView.VC_IsCapturing.x
        else
            ModelView.VC_Progress = Lerp(0.02, ModelView.VC_Progress, 0)
            ModelView.VC_LastSpeed = Lerp(0.09, ModelView.VC_LastSpeed or 0, 0)
            ModelView.VC_Progress = ModelView.VC_Progress - ModelView.VC_LastSpeed
        end
    end

    ModelView:SetModel(VC.GetModel(ent))
    local mvent = ModelView:GetEntity()
    ModelView.ModelLength = mvent:GetRenderBounds():Length() * 1.5 - 200
    ModelView.RBounds = mvent:GetRenderBounds()
    VC.ApplyEntityParams(ent, mvent)
    mvent:SetPoseParameter("vehicle_steer", -1)
    mvent:SetPoseParameter("vehicle_wheel_rl_height", 0.5)
    mvent:SetPoseParameter("vehicle_wheel_rr_height", 0.5)
    mvent:SetPoseParameter("vehicle_wheel_fl_height", 0.5)
    mvent:SetPoseParameter("vehicle_wheel_fr_height", 0.5)
    local ofst = Lbl1:GetTall() + 10
    local ObjectPanel = VC.Add_El_List(0, ofst, 240, Pnl:GetTall() - ofst - 80)
    ObjectPanel.StartPos_X, ObjectPanel.StartPos_Y = ObjectPanel:GetPos()
    ObjectPanel:SetParent(Pnl)
    local sbar = ObjectPanel.VBar
    sbar:SetWide(2)
    sbar.btnUp:SetWide(2)
    sbar.btnDown:SetWide(2)
    sbar.btnGrip:SetWide(2)
    function sbar:Paint(w, h)
    end

    function sbar.btnUp:Paint(w, h)
    end

    function sbar.btnDown:Paint(w, h)
    end

    sbar.btnGrip:NoClipping(true)
    function sbar.btnGrip:Paint(w, h)
        draw.RoundedBox(0, w - 2, -sbar.btnDown:GetTall(), 2, h + sbar.btnDown:GetTall() * 2, VC.Color.Blue)
    end

    local function RefreshObjects(inst)
        if CreatedObjects then
            for k, v in pairs(CreatedObjects) do
                if IsValid(v) then v:Remove() end
            end

            CreatedObjects = {}
        end

        for k, v in SortedPairs(Objects) do
            local Lbl = vgui.Create("DLabel")
            Lbl:SetTall(2)
            Lbl:SetText("")
            ObjectPanel:AddItem(Lbl)
            local Obj = vgui.Create("VC_Repair_Obj")
            Obj.VC_Ent = ent
            Obj:SetVCText(v.name or "")
            Obj:SetTall(43)
            Obj:SetIcon(v.icon)
            Obj:SetCost(v.cost or 10)
            Obj:SetTime(v.time or 5)
            Obj:SetSelected(v.selected)
            Obj:SetWorking(v.working)
            if ent.VC_RM_LastFixing and v.var .. (v.varint or 1) == (ent.VC_RM_LastFixing.type .. ent.VC_RM_LastFixing.int) then Obj:SetCurrent(true) end
            Obj:SetBaseColor(v.clr_base)
            Obj.VC_Tbl = table.Copy(v)
            Obj:SetData({
                obj = v.var,
                int = v.varint
            })

            Obj.side = v.side
            Lbl:SetParent(Obj)
            if not inst then
                Obj:AlphaTo(0, 0, 0)
                timer.Simple(0.05 * k, function() if IsValid(Obj) then Obj:AlphaTo(255, 0.2, 0.2) end end)
            end

            ObjectPanel:AddItem(Obj)
            table.insert(CreatedObjects, Obj)
        end
    end

    RefreshObjects()
    local TotalPanel = VC.Add_El_List(0, ofst + ObjectPanel:GetTall() + 10, 240, Pnl:GetTall() - ObjectPanel:GetTall() - ofst - 20)
    TotalPanel.StartPos_X, TotalPanel.StartPos_Y = TotalPanel:GetPos()
    TotalPanel:SetParent(Pnl)
    local symbol = VC.getCurCurrency().symbol
    TotalPanel.Paint = function(obj, Sx, Sy)
        draw.SimpleText(VC.Lng("PartsCost") .. ":", "VC_Regular_Ms", 10, 10, VC.Color.White, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        draw.SimpleText(symbol .. VC.PreparePrice(Pnl.VC_TotalCost), "VC_Regular_Ms", Sx - 10, 10, VC.Color.White, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
        draw.SimpleText(VC.Lng("RepairCost") .. ":", "VC_Regular_Ms", 10, 21, VC.Color.White, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        draw.SimpleText(symbol .. VC.PreparePrice(Pnl.VC_TotalTimeCost or 0), "VC_Regular_Ms", Sx - 10, 21, VC.Color.White, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
        draw.SimpleText(VC.Lng("RepairTime") .. ":", "VC_Regular_Ms", 10, 32, VC.Color.Blue, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        draw.SimpleText(string.FormattedTime(Pnl.VC_TotalTime, "%02i:%02i"), "VC_Regular_Ms", Sx - 10, 32, VC.Color.Blue, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
        draw.SimpleText(VC.Lng("Total") .. ":", "VC_Menu_Header", 10, Sy - 10, VC.Color.White, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        draw.SimpleText(symbol .. VC.PreparePrice((Pnl.VC_TotalCost or 0) + (Pnl.VC_TotalTimeCost or 0)), "VC_Menu_Header", Sx / 2 - 20, Sy - 10, VC.Color.Good, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    local Select = vgui.Create("DImageButton")
    Select:SetMaterial("icon16/text_list_bullets.png")
    Select:SetParent(Pnl)
    Select:SetText("")
    Select:SetSize(20, 20)
    Select:SetPos(TotalPanel:GetWide() - 20, 12)
    Select.DoClick = function()
        local allsel = true
        for k, v in pairs(CreatedObjects) do
            if not v:GetSelected() and not v:GetWorking() and not v:GetCurrent() then
                allsel = false
                break
            end
        end

        for k, v in pairs(CreatedObjects) do
            if not v:GetWorking() and not v:GetCurrent() then v:SetSelected(not allsel) end
        end
    end

    local ConfirmButon = vgui.Create("VC_Button")
    ConfirmButon:SetParent(TotalPanel)
    ConfirmButon:SetText(VC.Lng("Accept"))
    ConfirmButon:SetColor(VC.Color.Btn_Add)
    ConfirmButon:SetSize(TotalPanel:GetWide() / 2 - 20, 20)
    ConfirmButon:SetPos(TotalPanel:GetWide() / 2 + 10, TotalPanel:GetTall() - 20)
    ConfirmButon.DoClick = function()
        local C_Pnl = vgui.Create("DFrame")
        C_Pnl:SetSize(400, 180)
        C_Pnl:SetTitle("")
        C_Pnl:SetPos(ScrW() / 2 - C_Pnl:GetWide() / 2, ScrH() / 2 - C_Pnl:GetTall() / 2)
        C_Pnl:SetDraggable(false)
        C_Pnl:ShowCloseButton(false)
        C_Pnl:AlphaTo(0, 0, 0)
        C_Pnl:AlphaTo(255, 0.2, 0)
        C_Pnl:SetParent(Pnl)
        C_Pnl.VC_FocusCheckTime = CurTime() + 1
        local selt = {}
        for k, v in pairs(CreatedObjects) do
            if v:GetSelected() then selt[v:GetIcon()] = (selt[v:GetIcon()] or 0) + 1 end
        end

        local cnt = table.Count(selt)
        C_Pnl.Paint = function(obj, Sx, Sy)
            draw.RoundedBox(0, 0, 0, Sx, Sy, VC.Color.Main)
            draw.RoundedBox(0, 0, 0, Sx, 50, VC.Color.Main)
            local cur = 1
            for k, v in pairs(selt) do
                local isx, isy = Sx, Sy * 0.55
                surface.SetDrawColor(Color(255, 255, 255, 255))
                surface.SetMaterial(k)
                local ps = Sx / 2 - cnt * 45 * 0.5 + cur * 45 - 5 - 30
                surface.DrawTexturedRect(ps, 10, 30, 30)
                draw.SimpleText(v, "VC_Dev_Text", ps + 13, 45, VC.Color.White, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                cur = cur + 1
            end

            draw.SimpleText(VC.Lng("PartsCost") .. ":", "VC_Regular_Ms", 20, 60, VC.Color.White, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            draw.SimpleText(symbol .. VC.PreparePrice(Pnl.VC_TotalCost), "VC_Regular_Ms", Sx - 20, 60, VC.Color.White, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
            draw.SimpleText(VC.Lng("RepairCost") .. ":", "VC_Regular_Ms", 20, 75, VC.Color.White, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            draw.SimpleText(symbol .. VC.PreparePrice(Pnl.VC_TotalTimeCost or 0), "VC_Regular_Ms", Sx - 20, 75, VC.Color.White, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
            draw.SimpleText(VC.Lng("RepairTime") .. ":", "VC_Regular_Ms", 20, 90, VC.Color.Blue, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            draw.SimpleText(string.FormattedTime(Pnl.VC_TotalTime, "%02i:%02i"), "VC_Regular_Ms", Sx - 20, 90, VC.Color.Blue, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
            draw.SimpleText(VC.Lng("Total") .. ":", "VC_Menu_Header", 20, 115, VC.Color.White, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            draw.SimpleText(symbol .. VC.PreparePrice((Pnl.VC_TotalCost or 0) + (Pnl.VC_TotalTimeCost or 0)), "VC_Menu_Header", Sx - 20, 115, VC.Color.Good, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
        end

        local Accept = vgui.Create("VC_Button", C_Pnl)
        Accept:SetColor(VC.Color.Btn_Add)
        Accept:SetText(VC.Lng("Accept"))
        Accept:SetFont("VC_Regular2")
        Accept:SetSize(C_Pnl:GetWide() / 2 - 25, 35)
        Accept:SetPos(20, C_Pnl:GetTall() - Accept:GetTall() - 15)
        local Cancel = vgui.Create("VC_Button", C_Pnl)
        Cancel:SetColor(VC.Color.Btn_Rem)
        Cancel:SetText(VC.Lng("Cancel"))
        Cancel:SetFont("VC_Regular2")
        Cancel:SetSize(C_Pnl:GetWide() / 2 - 25, 35)
        Cancel:SetPos(C_Pnl:GetWide() / 2 + 5, C_Pnl:GetTall() - Cancel:GetTall() - 15)
        Accept.DoClick = function()
            local ttbl = {}
            local objtbl = {}
            for k, v in pairs(CreatedObjects) do
                if v:GetSelected() then
                    objtbl[k] = v
                    table.insert(ttbl, {v.VC_Tbl.var, v.VC_Tbl.varint})
                end
            end

            if VC.CanAfford(LocalPlayer(), (Pnl.VC_TotalCost or 0) + (Pnl.VC_TotalTimeCost or 0)) then
                VCPopup("Purchased", "check")
                for k2, v2 in pairs(objtbl) do
                    v2:SetSelected(false)
                    v2:SetWorking(true)
                    if not tbl then tbl = {} end
                    if not tbl.objects then tbl.objects = {} end
                    tbl.objects[v2.VC_Tbl.var .. (v2.VC_Tbl.varint or 1)] = {v2.VC_Tbl.var, v2.VC_Tbl.varint, CurTime()}
                end

                net.Start("VC_RM_SendPurchases")
                net.WriteEntity(ent)
                net.WriteEntity(npc)
                net.WriteTable(ttbl)
                net.SendToServer()
            else
                VCPopup("CD_Cant_Afford", "cross")
            end

            C_Pnl:Close()
        end

        C_Pnl.Think = function()
            local backDown = input.IsKeyDown(KEY_BACKSPACE)
            if backDown and not backPressed then
                Cancel.DoClick()
                backPressed = true
            elseif not backDown and backPressed then
                backPressed = false
            end

            local enterDown = input.IsKeyDown(KEY_ENTER)
            if enterDown and not enterPressed then
                Accept.DoClick()
                enterPressed = true
            elseif not enterDown and enterPressed then
                enterPressed = false
            end
        end

        Cancel.DoClick = function() C_Pnl:Close() end
        C_Pnl:MakePopup()
    end

    local function RefreshTotal()
        local cnt = 0
        local cost = 0
        local time = 0
        for k, v in pairs(CreatedObjects) do
            if v:GetSelected() then
                cnt = cnt + 1
                cost = cost + v:GetCost()
                time = time + v:GetTime()
            end
        end

        Pnl.VC_TotalSelected = cnt
        ConfirmButon:SetVisible(Pnl.VC_TotalSelected > 0)
        Pnl.VC_TotalCost = cost
        Pnl.VC_TotalTime = time
        Pnl.VC_TotalTimeCost = math.Round(time * VC.getServerSetting("RM_Repair_Time_Cost", 1))
    end

    RefreshTotal()
    Pnl.Think = function()
        if VC_RM_Refresh_Objects then
            ReinitObjects()
            RefreshObjects(true)
            VC_RM_Refresh_Objects = nil
        end

        if Pnl.VC_Refresh_Total then
            RefreshTotal()
            Pnl.VC_Refresh_Total = nil
        end
    end

    Pnl:MakePopup()
end

function VC.RM.HUDPaint()
    local FTm = VC.FTm()
    for k, ent in pairs(VC.GetVehicleList()) do
        if not IsValid(ent) then continue end
        if ent.VC_RM_LastFixing then
            if not ent.VC_RM_DistCheckT or CurTime() >= ent.VC_RM_DistCheckT then
                ent.VC_RM_DistCheckT = CurTime() + 1
                ent.VC_RM_Rep_Dist = VC.GetViewPos():Distance(ent:GetPos())
            end

            local on = ent.VC_RM_Rep_Dist < 300
            local anim = VC.UI_AnimData("RM_Repair_" .. k, on, 0.05, 0.02)
            if anim then
                local Rat_L = anim * 2
                if Rat_L > 1 then Rat_L = 1 end
                local Rat_BT = anim * 3
                if Rat_BT > 1 then Rat_BT = 1 end
                local Rat_TT = anim * 2 - 1
                if Rat_TT < 0 then Rat_TT = 0 end
                local pos = Vector(0, 0, 0)
                local text = VC.Lng("Repairing")
                local prc = 0
                local pname = ent.VC_RM_LastFixing.type
                if pname == "light" and VC.DamagedLightIsELS(ent, ent.VC_RM_LastFixing.int).isELS then pname = "light_els" end
                local icon = VC.GetPartIcon(pname)
                prc = (CurTime() - ent.VC_RM_LastFixing.time_s) / ent.VC_RM_LastFixing.time
                local txtclr = Color(Lerp(prc, 255, 155), Lerp(prc, 255, 255), Lerp(prc, 255, 155), 255 * Rat_TT)
                prc = math.Clamp(math.Round(prc * 100), 0, 100)
                text = text .. " " .. prc .. "%"
                local SPos = ent:LocalToWorld(ent.VC_RM_LastFixing.pos):ToScreen()
                local Sx, Sy = 35, 35
                surface.SetFont("VC_Model_Name")
                local tsize = surface.GetTextSize(text)
                local tclr = table.Copy(VC.Color.Main)
                tclr.a = tclr.a * Rat_L
                VC.DrawFadeRect(SPos.x - Sx / 2, SPos.y - Sy / 2 - 5, Sx + tsize * Rat_BT + 5, Sy + 9, tclr)
                draw.SimpleText(text, "VC_Model_Name", SPos.x + Sx / 2 + 5, SPos.y, txtclr, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
                local tclr = table.Copy(VC.Color.Blue)
                tclr.a = (200 - math.sin(CurTime() * 10) * 55) * Rat_BT
                surface.SetDrawColor(tclr)
                surface.SetMaterial(icon)
                surface.DrawTexturedRect(math.Round(SPos.x - Sx / 2), math.Round(SPos.y - Sy / 2), Sx, Sy)
            end
        end
    end

    for k, ent in pairs(ents.FindByClass("vc_npc_repair")) do
        local text = VC.getName(ent, VC.RM.Default.Name)
        if hook.Call("VC_RM_canRenderInfo", GAMEMODE, ent, text) ~= false then
            if not ent.VC_PVsb then
                ent.VC_Color = VC.Color.Neutral
                ent.VC_PVsb = util.GetPixelVisibleHandle()
            end

            local BInd = ent:LookupBone("ValveBiped.Bip01_Head1")
            local pos = Vector(0, 0, 0)
            if BInd then
                local BonePos, BoneAng = ent:GetBonePosition(ent:LookupBone("ValveBiped.Bip01_Head1"))
                pos = BonePos + Vector(0, 0, 8)
            else
                pos = ent:GetPos() + Vector(0, 0, 65)
            end

            local Vis = util.PixelVisible(pos + Vector(0, 0, 5), 1, ent.VC_PVsb)
            local Dist = nil
            if Vis > 0 then Dist = VC.GetViewPos():Distance(pos) end
            local on = Vis > 0 and Dist < VC.getServerSetting("RM_Text_Dist", 500)
            local anim = VC.UI_AnimData("RM_" .. k, on, 0.05, 0.02)
            if anim and ent.VC_LastPos_X and ent.VC_LastPos_Y then
                surface.SetFont("VC_Name")
                local tz = surface.GetTextSize(text) + 20
                local Sx = math.Round(ent.VC_LastPos_X - (anim - 1) * 50)
                local Sy = math.Round(ent.VC_LastPos_Y - 25)
                local PSx, PSy = tz, 50
                local clr = table.Copy(VC.Color.Main)
                clr.a = clr.a * anim
                draw.RoundedBox(0, math.Round(Sx - PSx / 2) + 1, Sy, PSx, PSy, clr)
                surface.SetMaterial(VC.Material.Fade)
                surface.DrawTexturedRectRotated(math.Round(Sx + VC.FadeW / 2 + PSx / 2 + 1), Sy + PSy / 2, VC.FadeW, PSy, 0)
                surface.DrawTexturedRectRotated(math.Round(Sx - VC.FadeW / 2 - PSx / 2 + 1), Sy + PSy / 2, VC.FadeW, PSy, 180)
                local tclr = table.Copy(VC.Color.Blue)
                tclr.a = tclr.a * anim
                draw.SimpleText(text, "VC_Name", Sx + 20, Sy + 25, tclr, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                surface.SetDrawColor(tclr)
                surface.SetMaterial(VC.Material.icon_repair)
                surface.DrawTexturedRect(Sx - PSx / 2 - 15, Sy + 3, 45, 45)
            end

            local pos = (ent:GetPos() + Vector(0, 0, 75)):ToScreen()
            ent.VC_LastPos_X = math.Clamp(Lerp(0.2, ent.VC_LastPos_X or pos.x, pos.x), -200, ScrW() + 200)
            ent.VC_LastPos_Y = math.Clamp(Lerp(0.2, ent.VC_LastPos_Y or pos.y, pos.y), -200, ScrH() + 200)
        end
    end
end

function VC.RM.open_vehicle_select(npc, npctbl, npcint)
    if not IsValid(npc) then return end
    if VC.isPlayerRestricted(LocalPlayer(), nil, npctbl) then return end
    local tbl = {}
    for k, v in pairs(VC.GetVehicleList()) do
        if not IsValid(v) then continue end
        local dist = npc:GetPos():Distance(v:GetPos())
        if dist <= (VC.getServerSetting("RM_Distance", 350) + 50) then tbl[dist] = v end
    end

    local cnt = table.Count(tbl)
    if cnt == 0 then
        VCPopup("NoCloseVehicles", "cross")
        return
    end

    if table.Count(tbl) > 1 then
        local Pnl = vgui.Create("DFrame")
        Pnl:SetSize(600, 150)
        Pnl:SetTitle("")
        Pnl:SetPos(ScrW() / 2 - Pnl:GetWide() / 2, ScrH() / 2 - Pnl:GetTall() / 2)
        Pnl:ShowCloseButton(false)
        Pnl:SetDraggable(false)
        Pnl:SizeTo(0, 150, 0)
        Pnl:SizeTo(600, 150, 0.2, 0.2, 1)
        Pnl.Paint = function(obj, Sx, Sy)
            draw.RoundedBox(0, 0, 0, Sx, Sy, VC.Color.Main)
            draw.RoundedBox(0, 0, 0, Sx, 25, VC.Color.Main)
            draw.DrawText(VC.Lng("SelectVehicle"), "VC_Dev_Text", 10, 5, VC.Color.White, TEXT_ALIGN_LEFT)
        end

        local Close = vgui.Create("DImageButton")
        Close:SetMaterial(VC.Material.Cross)
        Close:SetSize(20, 20)
        Close:SetPos(Pnl:GetWide() - Close:GetWide() - 5, 5)
        Close:SetParent(Pnl)
        Close:SetText("")
        Close.DoClick = function() Pnl:Close() end
        Pnl:AlphaTo(0, 0, 0)
        Pnl:AlphaTo(255, 0.2, 0.2)
        local Horz = vgui.Create("DHorizontalScroller", Pnl)
        Horz:SetSize(Pnl:GetWide() - 30, Pnl:GetTall() - 35)
        Horz:AlignTop(30)
        Horz:AlignLeft(15)
        Horz:SetOverlap(0)
        Horz:NoClipping(true)
        local Btn_Prev = vgui.Create("DButton", Pnl)
        Btn_Prev:SetText("")
        Btn_Prev:SetSize(15, Horz:GetTall())
        Btn_Prev:AlignLeft(0)
        Btn_Prev:AlignBottom(0)
        local Btn_Next = vgui.Create("DButton", Pnl)
        Btn_Next:SetText("")
        Btn_Next:SetSize(15, Horz:GetTall())
        Btn_Next:AlignRight(0)
        Btn_Next:AlignBottom(0)
        function HorzResetAlpha(int)
            Horz:AlphaTo(0, 0, 0)
            Horz:AlphaTo(255, int or 0.5, 0)
            Btn_Prev:AlphaTo(0, 0, 0)
            Btn_Prev:AlphaTo(255, int or 0.5, 0)
            Btn_Next:AlphaTo(0, 0, 0)
            Btn_Next:AlphaTo(255, int or 0.5, 0)
        end

        HorzResetAlpha(1)
        Horz.Think = function()
            if Btn_Prev:IsDown() then
                Horz.OffsetX = Horz.OffsetX - 2000
                Horz:InvalidateLayout(true)
            end

            if Btn_Next:IsDown() then
                Horz.OffsetX = Horz.OffsetX + 2000
                Horz:InvalidateLayout(true)
            end
        end

        function Horz:OnMouseWheeled(delta)
            Horz.OffsetX = Horz.OffsetX + delta * -100
            self:InvalidateLayout(true)
            return true
        end

        function Horz:PerformLayout()
            local w, h = self:GetSize()
            local x = 0
            self.pnlCanvas:SetTall(h)
            if self.Panels then
                for k, v in pairs(self.Panels) do
                    if IsValid(v) then
                        v:SetPos(x, 0)
                        v:SetTall(h)
                        v:ApplySchemeSettings()
                        x = x + v:GetWide() - self.m_iOverlap
                    end
                end

                self.pnlCanvas:SetWide(x + self.m_iOverlap)
                if w < self.pnlCanvas:GetWide() then
                    self.OffsetX = math.Clamp(self.OffsetX, 0, self.pnlCanvas:GetWide() - self:GetWide())
                else
                    self.OffsetX = 0
                end

                self.pnlCanvas.x = Lerp(0.1, self.pnlCanvas.x, -self.OffsetX)
            end

            self.btnLeft:SetVisible(false)
            self.btnRight:SetVisible(false)
            Btn_Prev:SetVisible(self.pnlCanvas.x < -25)
            Btn_Next:SetVisible(self.pnlCanvas.x + self.pnlCanvas:GetWide() > (self:GetWide() + 25))
        end

        Btn_Next.Paint = function(obj, Sx, Sy)
            surface.SetDrawColor(255, 255, 255, obj:IsHovered() and 255 or 55)
            surface.SetMaterial(VC.Material.icon_right)
            surface.DrawTexturedRect(0, 10, Sx, Sy - 20)
        end

        Btn_Prev.Paint = function(obj, Sx, Sy)
            surface.SetDrawColor(255, 255, 255, obj:IsHovered() and 255 or 55)
            surface.SetMaterial(VC.Material.icon_left)
            surface.DrawTexturedRect(0, 10, Sx, Sy - 20)
        end

        local clr = table.Copy(VC.Color.Main)
        for k, v in SortedPairs(tbl) do
            local prc = v:GetNWInt("VC_HealthPerc", 1)
            local txt = math.Round(math.Round(prc * 100), 0, 100) .. "%"
            local engclr = getHealthColor(prc)
            local mdl = vgui.Create("DModelPanel", Pnl)
            mdl:SetModel(v:GetModel())
            local mvent = mdl:GetEntity()
            mdl.ModelLength = mvent:GetRenderBounds():Length() * 1.5 - 200
            mdl.RBounds = mvent:GetRenderBounds()
            mvent:SetPoseParameter("vehicle_steer", -1)
            mvent:SetPoseParameter("vehicle_wheel_rl_height", 0.5)
            mvent:SetPoseParameter("vehicle_wheel_rr_height", 0.5)
            mvent:SetPoseParameter("vehicle_wheel_fl_height", 0.5)
            mvent:SetPoseParameter("vehicle_wheel_fr_height", 0.5)
            mdl:SetLookAng(Vector(0, 0, 62))
            mdl:SetSize(250, 150)
            function mdl:LayoutEntity()
                mdl:SetLookAng(Angle(0, 180, 0))
                mdl:SetCamPos(Vector(mdl:IsHovered() and 250 or 280, 0, 60) - Angle(0, 180, 0):Forward() * mdl.ModelLength)
                return
            end

            mdl.DoClick = function()
                Pnl:Close()
                VC.RM.open_menu_main_pre(v, npc, npctbl, npcint)
            end

            VC.ApplyEntityParams(v, mdl:GetEntity())
            local name = VC.getName(v, VC.Lng("Unknown"))
            mdl.PaintOver = function(obj, Sx, Sy)
                local tclr = table.Copy(clr)
                draw.RoundedBox(0, 0, 0, Sx, 25, clr)
                if not mdl:IsHovered() and not (mdl:IsHovered() or sel) then draw.RoundedBox(0, 0, 0, Sx, Sy, Color(0, 0, 0, 200)) end
                if mdl:IsDown() then draw.RoundedBox(0, 0, 0, Sx, Sy, Color(0, 100, 100, 55)) end
                draw.DrawText(name, nil, Sx / 2, 7, VC.Color.Base, TEXT_ALIGN_CENTER)
                surface.SetFont("VC_Regular2")
                draw.DrawText(txt, "VC_Regular2", Sx - 2, 30, engclr, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
                local tz = surface.GetTextSize(txt)
                surface.SetDrawColor(engclr.r, engclr.g, engclr.b, engclr.a)
                surface.SetMaterial(VC.Material.icon_engine)
                surface.DrawTexturedRect(Sx - tz - 28, 27, 22, 22)
                local pos = 0
                if mdl:IsHovered() then
                    tclr = table.Copy(VC.Color.Blue)
                    surface.SetDrawColor(tclr)
                    surface.DrawLine(pos, 0, pos + Sx - 1, 0)
                    surface.DrawLine(pos, Sy - 1, pos + Sx - 1, Sy - 1)
                    surface.DrawLine(pos, 0, pos, Sy - 1)
                    surface.DrawLine(pos + Sx - 1, 0, pos + Sx - 1, Sy - 1)
                end
            end

            Horz:AddPanel(mdl)
        end

        Pnl:MakePopup()
    else
        for k, v in pairs(tbl) do
            VC.RM.open_menu_main_pre(v, npc, npctbl, npcint)
        end
    end
end

function VC.RM.open_menu_RepairMain_edit(ent)
    if IsValid(VC.RM_Edit_Panel) then
        VC.RM_Edit_Panel:Close()
        VC.RM_Edit_Panel = nil
    end

    local Pnl = vgui.Create("DFrame")
    VC.RM_Edit_Panel = Pnl
    Pnl:SetSize(600, 320)
    Pnl:SetTitle("")
    Pnl:SetPos(ScrW() / 2 - Pnl:GetWide() / 2, ScrH() / 2 - Pnl:GetTall() / 2)
    Pnl:ShowCloseButton(false)
    Pnl:AlphaTo(0, 0, 0)
    Pnl:AlphaTo(255, 0.2, 0)
    VC.RM.LastTbl.Pos = ent:GetPos()
    VC.RM.LastTbl.Ang = ent:GetAngles()
    VC.RM.LastTbl.Model = ent:GetModel()
    Pnl.Paint = function(obj, Sx, Sy)
        draw.RoundedBox(0, 0, 0, Sx, Sy, VC.Color.Main)
        draw.RoundedBox(0, 0, 0, Sx, 25, VC.Color.Main)
        draw.DrawText('VCMod Repair Man Editor. ID - "' .. ent:GetNWInt("VC_Int") .. '".', "VC_Dev_Text", 7, 5, VC.Color.Blue, TEXT_ALIGN_LEFT)
        draw.RoundedBox(0, 10, 30, 155, 255, VC.Color.Main)
        draw.DrawText("Name:", "VC_Dev_Text", 15, 40, VC.Color.Blue, TEXT_ALIGN_LEFT)
        draw.DrawText("Model:", "VC_Dev_Text", 15, 215, VC.Color.Blue, TEXT_ALIGN_LEFT)
        draw.DrawText("Pos: " .. math.Round(VC.RM.LastTbl.Pos.x) .. ", " .. math.Round(VC.RM.LastTbl.Pos.y) .. ", " .. math.Round(VC.RM.LastTbl.Pos.z), "VC_Dev_Text", 15, 235, VC.Color.Blue, TEXT_ALIGN_LEFT)
        draw.DrawText("Ang: " .. math.Round(VC.RM.LastTbl.Ang.p) .. ", " .. math.Round(VC.RM.LastTbl.Ang.y) .. ", " .. math.Round(VC.RM.LastTbl.Ang.r), "VC_Dev_Text", 15, 255, VC.Color.Blue, TEXT_ALIGN_LEFT)
    end

    local delete = vgui.Create("VC_Button", Pnl)
    delete:SetToolTip("Delete the repair man from the server and all the data files.")
    delete:SetText("Delete this repair man")
    delete:SetSize(Pnl:GetWide() - 20, 20)
    delete:SetPos(10, Pnl:GetTall() - delete:GetTall() - 10)
    delete:SetColor(VC.Color.Btn_Rem)
    delete:SetTextIsWhite(true)
    delete.DoClick = function()
        net.Start("VC_RM_Delete")
        net.WriteEntity(ent)
        net.SendToServer()
        Pnl:Close()
        VC.RM.MM_Refresh = true
    end

    local done = vgui.Create("DImageButton", Pnl)
    done:SetMaterial(VC.Material.icon_check)
    done:SetToolTip("Close menu and save settings.")
    done:SetSize(20 + 15, 20)
    done:SetPos(Pnl:GetWide() - done:GetWide() - 2 - 15, 2)
    done.DoClick = function()
        net.Start("VC_RM_DoneEditting")
        net.WriteEntity(ent)
        net.WriteTable(VC.RM.LastTbl)
        net.WriteInt(VC.RM.LastInt, 8)
        net.WriteInt(1, 8)
        net.SendToServer()
        Pnl:Close()
        VC.RM.MM_Refresh = true
    end

    local cancel = vgui.Create("DImageButton", Pnl)
    cancel:SetMaterial(VC.Material.icon_cross)
    cancel:SetToolTip("Discard all settings and close.")
    cancel:SetSize(20, 20)
    cancel:SetPos(Pnl:GetWide() - cancel:GetWide() - 24 - 45, 2)
    cancel.DoClick = function()
        Pnl:Close()
        VC.RM.MM_Refresh = true
    end

    local find = vgui.Create("DImageButton", Pnl)
    find:SetMaterial(VC.Material.icon_paste)
    find:SetToolTip("Import from other Repair men.")
    find:SetSize(20, 20)
    find:SetPos(Pnl:GetWide() - 65 - 60, 2)
    find.DoClick = function()
        local DDM = VC.DermaMenu("Import")
        local ISM = nil
        DDM:AddButton("Import from other maps (everything)", function()
            net.Start("VC_RM_RequestInfo_Import_NPC_OtherInfo")
            net.WriteEntity(ent)
            net.SendToServer()
        end):SetImage("icon16/key.png")

        for k, v in pairs(ents.FindByClass("vc_npc_repair")) do
            if v:GetNWInt("VC_Int", 0) ~= VC.RM.LastInt then
                DDM:AddButton(VC.getName(v, VC.RM.Default.Name), function()
                    if IsValid(v) then
                        net.Start("VC_RM_RequestInfo_Import_NPC")
                        net.WriteEntity(v)
                        net.SendToServer()
                    end
                end)
            end
        end

        if DDM then DDM:Open() end
    end

    local el_mdl = vgui.Create("DModelPanel", Pnl)
    el_mdl:SetModel(VC.RM.LastTbl.Model)
    el_mdl:SetCamPos(Vector(20, 0, 62))
    el_mdl:SetLookAt(Vector(0, 0, 62))
    el_mdl:SetSize(150, 150)
    el_mdl:SetPos(10, 50)
    function el_mdl:LayoutEntity()
        el_mdl:SetLookAt(Vector(0, math.sin(CurTime() * 2), 62))
        return
    end

    local el_name = vgui.Create("DTextEntry", Pnl)
    el_name:SetTall(20)
    el_name:SetWide(100)
    el_name:SetToolTip("Repair man's name.")
    el_name:SetValue(VC.RM.LastTbl.Name)
    el_name:SetPos(60, 35)
    el_name.OnTextChanged = function()
        local val = el_name:GetValue()
        VC.RM.LastTbl.Name = val
    end

    local el_mdlname = vgui.Create("DTextEntry", Pnl)
    el_mdlname:SetTall(20)
    el_mdlname:SetWide(100)
    el_mdlname:SetToolTip("Repair man's model. Enter it manually here or click on the image.")
    el_mdlname:SetValue(VC.RM.LastTbl.Model)
    el_mdlname:SetPos(60, 210)
    el_mdlname.OnTextChanged = function()
        local val = el_mdlname:GetValue()
        VC.RM.LastTbl.Model = val
        el_mdl:SetModel(val)
    end

    local function SetModel(mdl)
        el_mdlname:SetValue(mdl)
        el_mdl:GetEntity():SetModel(mdl)
        el_mdlname.OnTextChanged()
        local iSeq = el_mdl:GetEntity():LookupSequence("walk_all")
        if iSeq <= 0 then iSeq = el_mdl:GetEntity():LookupSequence("WalkUnarmed_all") end
        if iSeq <= 0 then iSeq = el_mdl:GetEntity():LookupSequence("walk_all_moderate") end
        if iSeq > 0 then el_mdl:GetEntity():ResetSequence(iSeq) end
    end

    el_mdl.DoClick = function()
        local DDM = VC.DermaMenu("Model")
        DDM:AddButton("Mossman", function() SetModel("models/mossman.mdl") end)
        DDM:AddButton("Barney", function() SetModel("models/Barney.mdl") end)
        DDM:AddButton("Breen", function() SetModel("models/breen.mdl") end)
        DDM:AddButton("Eli", function() SetModel("models/Eli.mdl") end)
        DDM:AddButton("GMan", function() SetModel("models/gman_high.mdl") end)
        DDM:AddButton("Kleiner", function() SetModel("models/Kleiner.mdl") end)
        DDM:AddButton("Father Grigory", function() SetModel("models/monk.mdl") end)
        DDM:AddButton("Vortigaunt", function() SetModel("models/vortigaunt.mdl") end)
        DDM:AddButton("Police", function() SetModel("models/Police.mdl") end)
        DDM:AddButton("Zombie", function() SetModel("models/Zombie/Classic.mdl") end)
        DDM:Open()
    end

    local El_List1 = VC.Add_El_List(175 + (Pnl:GetWide() - 175) / 2, 35, (Pnl:GetWide() - 175) / 2 - 10, Pnl:GetTall() - 75)
    El_List1:SetParent(Pnl)
    El_List1:NoClipping(true)
    El_List1.Paint = function(obj, Sx, Sy) draw.RoundedBox(0, -5, -5, Sx + 10, Sy + 10, VC.Color.Main) end
    local ResE2L = {}
    if not VC.RM.LastTbl.RankRestrict then VC.RM.LastTbl.RankRestrict = {} end
    for k, v in pairs(VC.getRanks()) do
        local el = VC.Add_El_Checkbox(v, "This rank is allowed to use this repair man.")
        El_List1:AddItem(el)
        el.OnChange = function(idx, val) VC.RM.LastTbl.RankRestrict[k] = not val end
        ResE2L[k] = el
    end

    local El_List1 = VC.Add_El_List(175, 35, (Pnl:GetWide() - 175) / 2 - 15, Pnl:GetTall() - 75)
    El_List1:SetParent(Pnl)
    El_List1:NoClipping(true)
    El_List1.Paint = function(obj, Sx, Sy) draw.RoundedBox(0, -5, -5, Sx + 10, Sy + 10, VC.Color.Main) end
    local ResElL = {}
    if RPExtraTeams then
        if not VC.RM.LastTbl.JobRestrict then VC.RM.LastTbl.JobRestrict = {} end
        for k, v in pairs(RPExtraTeams) do
            local nm = v.name or VC.Lng("Unknown")
            ResElL[nm] = VC.Add_El_Checkbox(nm, "This job is allowed to use this repair man.")
            El_List1:AddItem(ResElL[nm])
            ResElL[nm].OnChange = function(idx, val) VC.RM.LastTbl.JobRestrict[nm] = not val end
        end
    end

    local function RefreshInfo()
        local tmdl = VC.RM.LastTbl.Model
        el_mdlname:SetValue(tmdl)
        SetModel(tmdl)
        el_mdlname.OnTextChanged()
        el_name:SetValue(VC.RM.LastTbl.Name)
        if not VC.RM.LastTbl.RankRestrict then VC.RM.LastTbl.RankRestrict = {} end
        for k, v in pairs(VC.getRanks()) do
            if ResE2L[k] then ResE2L[k]:SetValue(not VC.RM.LastTbl.RankRestrict[k]) end
        end

        if RPExtraTeams then
            if not VC.RM.LastTbl.JobRestrict then VC.RM.LastTbl.JobRestrict = {} end
            for k, v in pairs(RPExtraTeams) do
                local nm = v.name or VC.Lng("Unknown")
                if ResElL[nm] then ResElL[nm]:SetValue(not VC.RM.LastTbl.JobRestrict[nm]) end
            end
        end
    end

    RefreshInfo()
    Pnl.Think = function()
        if VC.RM.Import_NPC_Tbl then
            local temptbl = table.Copy(VC.RM.Import_NPC_Tbl[2])
            if not VC.RM.LastTbl then VC.RM.LastTbl = {} end
            VC.RM.LastTbl = temptbl
            RefreshInfo()
            VC.RM.Import_NPC_Tbl = nil
        end
    end

    Pnl:MakePopup()
end

function VC.RM.open_menu_choice(npc, npctbl, npcint)
    local Pnl = vgui.Create("DFrame")
    Pnl:SetSize(600, 150)
    Pnl:SetTitle("")
    Pnl:SetPos(ScrW() / 2 - Pnl:GetWide() / 2, ScrH() / 2 - Pnl:GetTall() / 2)
    Pnl:ShowCloseButton(false)
    Pnl:SetDraggable(false)
    Pnl:SizeTo(600, 0, 0)
    Pnl:SizeTo(600, 150, 0.1, 0, 1)
    Pnl.Paint = function(obj, Sx, Sy)
        draw.RoundedBox(0, 0, 0, Sx, Sy, VC.Color.Main)
        draw.DrawText("This menu is only visible to administrators.", "VC_Dev_Text", 10, 10, VC.Color.White, TEXT_ALIGN_LEFT)
    end

    local Main = vgui.Create("VC_Button", Pnl)
    Main:SetColor(VC.Color.Btn_Add)
    Main:SetText("Repair man's menu")
    Main:SetFont("VC_Big_Italic")
    Main:SetSize(Pnl:GetWide() / 2 - 30, Pnl:GetTall() - 55)
    Main:SetPos(20, 35)
    local Main_Edit = vgui.Create("VC_Button", Pnl)
    Main_Edit:SetColor(VC.Color.Btn_Chng)
    Main_Edit:SetText("Edit menu")
    Main_Edit:SetFont("VC_Big_Italic")
    Main_Edit:SetSize(Pnl:GetWide() / 2 - 30, Pnl:GetTall() - 55)
    Main_Edit:SetPos(Pnl:GetWide() / 2 + 10, 35)
    Main.DoClick = function()
        VC.RM.open_vehicle_select(npc, npctbl, npcint)
        Pnl:Close()
    end

    Main_Edit.DoClick = function()
        VC.RM.LastTbl = npctbl or table.Copy(VC.RM.Default)
        VC.RM.LastInt = npcint
        if IsValid(npc) then
            VC.RM.LastNPC = npc
            VC.RM.open_menu_RepairMain_edit(npc, npctbl, npcint)
        end

        Pnl:Close()
    end

    Pnl:MakePopup()
end

net.Receive("VC_RM_Send_Menu_Open", function(len)
    local npc, npctbl, npcint, admin = net.ReadEntity(), net.ReadTable(), net.ReadInt(8), net.ReadInt(4)
    if IsValid(npc) then
        if admin and admin == 1 then
            VC.RM.open_menu_choice(npc, npctbl, npcint)
        else
            VC.RM.open_vehicle_select(npc, npctbl, npcint)
        end
    end
end)


VC.AnimDriverTypes = {
    [0] = {
        name = "default",
        id = ""
    },
    [1] = {
        name = "Standing (scooter)",
        id = "standing_scooter"
    },
    [2] = {
        name = "Sitting (bycicle BMX)",
        id = "bicycle_bmx"
    },
    [3] = {
        name = "Sitting (bycicle)",
        id = "bicycle"
    },
    [4] = {
        name = "Sitting (tricycle)",
        id = "tricycle"
    },
}

VC.AnimTable_Or = {
    Instant = {
        PassSeatLegs = {
            Bones = {
                {
                    Bone = "ValveBiped.Bip01_R_Calf",
                    Angle = Angle(0, -50, -20)
                },
                {
                    Bone = "ValveBiped.Bip01_R_Calf",
                    Angle = Angle(0, -50, -20)
                },
                {
                    Bone = "ValveBiped.Bip01_L_Calf",
                    Angle = Angle(0, -50, 20)
                }
            },
        },
        standing_scooter = {
            Bones = {
                {
                    Bone = "ValveBiped.bip01_pelvis",
                    Angle = Angle(0, 0, 10)
                },
                {
                    Bone = "ValveBiped.bip01_spine1",
                    Angle = Angle(0, 10, 0)
                },
                {
                    Bone = "ValveBiped.Bip01_R_Thigh",
                    Angle = Angle(15, 95, 0)
                },
                {
                    Bone = "ValveBiped.Bip01_R_Calf",
                    Angle = Angle(0, -50, -10)
                },
                {
                    Bone = "ValveBiped.Bip01_R_Foot",
                    Angle = Angle(25, -10, 0)
                },
                {
                    Bone = "ValveBiped.Bip01_L_Thigh",
                    Angle = Angle(-12, 70, 0)
                },
                {
                    Bone = "ValveBiped.Bip01_L_Calf",
                    Angle = Angle(0, -35, -10)
                },
                {
                    Bone = "ValveBiped.Bip01_L_Foot",
                    Angle = Angle(0, 10, 0)
                },
                {
                    Bone = "ValveBiped.Bip01_R_UpperArm",
                    Angle = Angle(0, 25, 0)
                },
                {
                    Bone = "ValveBiped.Bip01_R_Forearm",
                    Angle = Angle(0, -50, -25)
                },
                {
                    Bone = "ValveBiped.Bip01_R_Hand",
                    Angle = Angle(20, 0, -25)
                },
                {
                    Bone = "ValveBiped.Bip01_L_UpperArm",
                    Angle = Angle(0, 20, 0)
                },
                {
                    Bone = "ValveBiped.Bip01_L_Forearm",
                    Angle = Angle(0, -50, 25)
                },
                {
                    Bone = "ValveBiped.Bip01_L_Hand",
                    Angle = Angle(20, 0, 35)
                },
            },
        },
        bicycle_bmx = {
            Bones = {
                {
                    Bone = "ValveBiped.bip01_spine1",
                    Angle = Angle(0, 10, 0)
                },
                {
                    Bone = "ValveBiped.Bip01_R_Thigh",
                    Angle = Angle(15, 35, 0)
                },
                {
                    Bone = "ValveBiped.Bip01_R_Calf",
                    Angle = Angle(20, 25, -10)
                },
                {
                    Bone = "ValveBiped.Bip01_R_Foot",
                    Angle = Angle(0, -10, 0)
                },
                {
                    Bone = "ValveBiped.Bip01_L_Thigh",
                    Angle = Angle(-12, 0, 0)
                },
                {
                    Bone = "ValveBiped.Bip01_L_Calf",
                    Angle = Angle(0, 25, -10)
                },
                {
                    Bone = "ValveBiped.Bip01_L_Foot",
                    Angle = Angle(0, 10, 0)
                },
                {
                    Bone = "ValveBiped.Bip01_R_UpperArm",
                    Angle = Angle(7, 5, 0)
                },
                {
                    Bone = "ValveBiped.Bip01_R_Forearm",
                    Angle = Angle(0, -32, -40)
                },
                {
                    Bone = "ValveBiped.Bip01_R_Hand",
                    Angle = Angle(0, 0, -25)
                },
                {
                    Bone = "ValveBiped.Bip01_L_UpperArm",
                    Angle = Angle(-15, 10, 0)
                },
                {
                    Bone = "ValveBiped.Bip01_L_Forearm",
                    Angle = Angle(0, -36, 25)
                },
                {
                    Bone = "ValveBiped.Bip01_L_Hand",
                    Angle = Angle(0, 0, 35)
                },
            },
        },
        bicycle = {
            Bones = {
                {
                    Bone = "ValveBiped.bip01_pelvis",
                    Angle = Angle(0, 0, 10)
                },
                {
                    Bone = "ValveBiped.bip01_spine1",
                    Angle = Angle(0, 10, 0)
                },
                {
                    Bone = "ValveBiped.bip01_spine2",
                    Angle = Angle(0, 10, 0)
                },
                {
                    Bone = "ValveBiped.Bip01_R_Thigh",
                    Angle = Angle(0, 35, 0)
                },
                {
                    Bone = "ValveBiped.Bip01_R_Calf",
                    Angle = Angle(20, -20, -10)
                },
                {
                    Bone = "ValveBiped.Bip01_R_Foot",
                    Angle = Angle(0, 10, 0)
                },
                {
                    Bone = "ValveBiped.Bip01_L_Thigh",
                    Angle = Angle(0, 18, 0)
                },
                {
                    Bone = "ValveBiped.Bip01_L_Calf",
                    Angle = Angle(0, -25, 10)
                },
                {
                    Bone = "ValveBiped.Bip01_L_Foot",
                    Angle = Angle(0, 25, 0)
                },
                {
                    Bone = "ValveBiped.Bip01_R_UpperArm",
                    Angle = Angle(0, -18, 0)
                },
                {
                    Bone = "ValveBiped.Bip01_R_Forearm",
                    Angle = Angle(0, -22, -40)
                },
                {
                    Bone = "ValveBiped.Bip01_R_Hand",
                    Angle = Angle(0, 0, -35)
                },
                {
                    Bone = "ValveBiped.Bip01_L_UpperArm",
                    Angle = Angle(0, -22, 0)
                },
                {
                    Bone = "ValveBiped.Bip01_L_Forearm",
                    Angle = Angle(0, -15, 40)
                },
                {
                    Bone = "ValveBiped.Bip01_L_Hand",
                    Angle = Angle(0, 0, 45)
                },
            },
        },
        tricycle = {
            Bones = {
                {
                    Bone = "ValveBiped.Bip01_R_Thigh",
                    Angle = Angle(0, -10, 0)
                },
                {
                    Bone = "ValveBiped.Bip01_R_Calf",
                    Angle = Angle(20, 50, -10)
                },
                {
                    Bone = "ValveBiped.Bip01_R_Foot",
                    Angle = Angle(0, 10, 0)
                },
                {
                    Bone = "ValveBiped.Bip01_L_Thigh",
                    Angle = Angle(0, -5, 0)
                },
                {
                    Bone = "ValveBiped.Bip01_L_Calf",
                    Angle = Angle(-10, 20, 10)
                },
                {
                    Bone = "ValveBiped.Bip01_L_Foot",
                    Angle = Angle(0, 15, 0)
                },
                {
                    Bone = "ValveBiped.Bip01_R_UpperArm",
                    Angle = Angle(10, 50, 0)
                },
                {
                    Bone = "ValveBiped.Bip01_R_Forearm",
                    Angle = Angle(0, -48, 0)
                },
                {
                    Bone = "ValveBiped.Bip01_R_Hand",
                    Angle = Angle(0, 0, -35)
                },
                {
                    Bone = "ValveBiped.Bip01_L_UpperArm",
                    Angle = Angle(-10, 50, 0)
                },
                {
                    Bone = "ValveBiped.Bip01_L_Forearm",
                    Angle = Angle(0, -48, 0)
                },
                {
                    Bone = "ValveBiped.Bip01_L_Hand",
                    Angle = Angle(0, 0, 45)
                },
            },
        }
    },
    L_Foot = {
        Brakes = {
            IncSpeed = 1.5,
            DecSpeed = 0.5,
            Bones = {
                {
                    Bone = "ValveBiped.Bip01_L_Foot",
                    Angle = Angle(10, 10, 30)
                },
                {
                    Bone = "ValveBiped.Bip01_L_Calf",
                    Angle = Angle(-10, -20, -10)
                },
                {
                    Bone = "ValveBiped.Bip01_L_Thigh",
                    Angle = Angle(10, 15, -20)
                }
            },
        },
        Clutch = {
            IncSpeed = 1,
            DecSpeed = 0.5,
            Bones = {
                {
                    Bone = "ValveBiped.Bip01_L_Foot",
                    Angle = Angle(0, 20, 0)
                },
                {
                    Bone = "ValveBiped.Bip01_L_Calf",
                    Angle = Angle(0, -20, 0)
                },
                {
                    Bone = "ValveBiped.Bip01_L_Thigh",
                    Angle = Angle(0, 10, 0)
                }
            },
        },
    },
    R_Foot = {
        Throttle = {
            IncSpeed = 0.75,
            DecSpeed = 0.5,
            Bones = {
                {
                    Bone = "ValveBiped.Bip01_R_Foot",
                    Angle = Angle(0, 20, 0)
                },
                {
                    Bone = "ValveBiped.Bip01_R_Calf",
                    Angle = Angle(0, -20, 0)
                },
                {
                    Bone = "ValveBiped.Bip01_R_Thigh",
                    Angle = Angle(0, 10, 0)
                }
            }
        },
    },
    L_Arm = {
        Horn = {
            IncSpeed = 2,
            DecSpeed = 1,
            Bones = {
                {
                    Bone = "ValveBiped.Bip01_L_UpperArm",
                    Angle = Angle(20, 7, 15)
                },
                {
                    Bone = "ValveBiped.Bip01_L_Forearm",
                    Angle = Angle(0, -5, 22)
                },
                {
                    Bone = "ValveBiped.Bip01_L_Hand",
                    Angle = Angle(-43, 90, 13)
                }
            },
        },
        Right_HandBrake = {
            IncSpeed = 1.5,
            DecSpeed = 1,
            Bones = {
                {
                    Bone = "ValveBiped.Bip01_L_UpperArm",
                    Angle = Angle(-52, 46, 0)
                },
                {
                    Bone = "ValveBiped.Bip01_L_Forearm",
                    Angle = Angle(60, 10, 25)
                },
                {
                    Bone = "ValveBiped.Bip01_L_Hand",
                    Angle = Angle(2, 34, 0)
                }
            },
        },
        Right_Gear = {
            IncSpeed = 1.5,
            DecSpeed = 0.7,
            Bones = {
                {
                    Bone = "ValveBiped.Bip01_L_UpperArm",
                    Angle = Angle(-25, 52, 16)
                },
                {
                    Bone = "ValveBiped.Bip01_L_Forearm",
                    Angle = Angle(-10, -40, -45)
                },
                {
                    Bone = "ValveBiped.Bip01_L_Hand",
                    Angle = Angle(0, 0, 80)
                }
            },
        },
    },
    R_Arm = {
        Key = {
            IncSpeed = 0.5,
            DecSpeed = 0.2,
            Bones = {
                {
                    Bone = "ValveBiped.bip01_spine2",
                    Angle = Angle(5, 40, -10)
                },
                {
                    Bone = "ValveBiped.Bip01_R_UpperArm",
                    Angle = Angle(20, -40, 20)
                },
                {
                    Bone = "ValveBiped.Bip01_R_Forearm",
                    Angle = Angle(-50, 30, 40)
                },
                {
                    Bone = "ValveBiped.Bip01_R_Hand",
                    Angle = Angle(35, 0, -90)
                },
                {
                    Bone = "ValveBiped.Bip01_L_UpperArm",
                    Angle = Angle(-75, -10, -20)
                },
                {
                    Bone = "ValveBiped.Bip01_L_Forearm",
                    Angle = Angle(60, -75, 0)
                },
                {
                    Bone = "ValveBiped.Bip01_L_Hand",
                    Angle = Angle(0, 10, -90)
                }
            },
        },
        HandBrake = {
            IncSpeed = 1.5,
            DecSpeed = 1,
            Bones = {
                {
                    Bone = "ValveBiped.Bip01_R_UpperArm",
                    Angle = Angle(52, 46, 0)
                },
                {
                    Bone = "ValveBiped.Bip01_R_Forearm",
                    Angle = Angle(-60, 10, 25)
                },
                {
                    Bone = "ValveBiped.Bip01_R_Hand",
                    Angle = Angle(2, 34, 0)
                }
            },
        },
        Gear = {
            IncSpeed = 1.5,
            DecSpeed = 0.7,
            Bones = {
                {
                    Bone = "ValveBiped.Bip01_R_UpperArm",
                    Angle = Angle(25, 52, -16)
                },
                {
                    Bone = "ValveBiped.Bip01_R_Forearm",
                    Angle = Angle(10, -40, -45)
                },
                {
                    Bone = "ValveBiped.Bip01_R_Hand",
                    Angle = Angle(0, 16, 13)
                }
            },
        },
        Right_Horn = {
            IncSpeed = 2,
            DecSpeed = 1,
            Bones = {
                {
                    Bone = "ValveBiped.Bip01_R_UpperArm",
                    Angle = Angle(-20, 7, -15)
                },
                {
                    Bone = "ValveBiped.Bip01_R_Forearm",
                    Angle = Angle(0, -5, -22)
                },
                {
                    Bone = "ValveBiped.Bip01_R_Hand",
                    Angle = Angle(43, 90, 13)
                }
            },
        },
    },
}

VC.AnimTable = table.Copy(VC.AnimTable_Or)
function VC.AnimateBone(ent, bone, ang, pos)
    local b = ent:LookupBone(bone)
    if not b then return end
    if not ent.VC_BoneTable then ent.VC_BoneTable = {} end
    ent.VC_BoneTable[b] = ang
    ent:ManipulateBoneAngles(b, ang)
end

function VC.HandleAnim_SetBones(ent, Group, Type)
    local Tbl = VC.AnimTable[Group][Type]
    Tbl.Int = 1
    local AI = ent:GetNWEntity("VC_AI_PlayerModel")
    if IsValid(AI) then ent = AI end
    for _, BTbl in pairs(Tbl.Bones) do
        VC.AnimateBone(ent, BTbl.Bone, BTbl.Angle, BTbl.Pos)
    end

    ent:InvalidateBoneCache()
end

function VC.HandleAnim_LerpBones(ent, Group, Type, Increase, Override)
    local Tbl = VC.AnimTable[Group][Type]
    if Override then
        Tbl.Int = Lerp(0.05 * VC.FTm(), Tbl.Int or Override, Override)
        for _, BTbl in pairs(Tbl.Bones) do
            VC.AnimateBone(ent, BTbl.Bone, LerpAngle(VC.EaseInOut(Tbl.Int), Angle(0, 0, 0), BTbl.Angle))
        end
    else
        if not ent.VC_AnimInt then ent.VC_AnimInt = {} end
        if Increase then
            if not ent.VC_AnimInt[Type] then ent.VC_AnimInt[Type] = 0 end
            if ent.VC_AnimInt[Type] < 1 then
                local allowed = true
                for GAnimk, GAnimv in pairs(VC.AnimTable[Group]) do
                    if GAnimk ~= Type and ent.VC_AnimInt[GAnimk] and ent.VC_AnimInt[GAnimk] > 0 then
                        allowed = false
                        break
                    end
                end

                if allowed then
                    ent.VC_AnimInt[Type] = ent.VC_AnimInt[Type] + 0.05 * Tbl.IncSpeed * VC.FTm()
                    if ent.VC_AnimInt[Type] > 1 then ent.VC_AnimInt[Type] = 1 end
                    for _, BTbl in pairs(Tbl.Bones) do
                        VC.AnimateBone(ent, BTbl.Bone, LerpAngle(VC.EaseInOut(ent.VC_AnimInt[Type]), Angle(0, 0, 0), BTbl.Angle))
                    end
                end
            end
        elseif ent.VC_AnimInt[Type] and ent.VC_AnimInt[Type] > 0 then
            local allowed = false
            for GAnimk, GAnimv in pairs(VC.AnimTable[Group]) do
                if GAnimk ~= Type and ent.VC_AnimInt[GAnimk] then
                    allowed = true
                    break
                end
            end

            ent.VC_AnimInt[Type] = ent.VC_AnimInt[Type] - 0.05 * Tbl.DecSpeed * (allowed and 3 or 1) * VC.FTm()
            if ent.VC_AnimInt[Type] < 0 then ent.VC_AnimInt[Type] = 0 end
            for _, BTbl in pairs(Tbl.Bones) do
                VC.AnimateBone(ent, BTbl.Bone, LerpAngle(VC.EaseInOut(ent.VC_AnimInt[Type]), Angle(0, 0, 0), BTbl.Angle))
            end
        else
            ent.VC_AnimInt[Type] = nil
        end
    end
end

function VC.HandleAnim_Initial_Spec(ply, OV, Veh, VSC)
    if VC.getSetting("Animations") and VC.getSetting("Animations_All") then
        for _, ent in pairs(player.GetAll()) do
            local Prt = ent:GetVehicle()
            if IsValid(Prt) then
                if Prt.VC_ExtraSeat and not ent.VC_LegsSet then
                    VC.HandleAnim_SetBones(ent, "Instant", "PassSeatLegs")
                    ent.VC_LegsSet = true
                end

                if Prt.VC_isSupported then
                    if not Prt.VC_Pl_Check_Dist_Time or CurTime() >= Prt.VC_Pl_Check_Dist_Time then
                        Prt.VC_Pl_Check_Dist_Time = CurTime() + 5
                        Prt.VC_Pl_Check_Dist = Prt:GetPos():Distance(LocalPlayer():EyePos()) < 1000 and not IsValid(Prt:GetParent())
                    end

                    VC.HandleAnimations(ent, Prt)
                end
            else
                VC.ResetBones(ent)
            end
        end

        for _, ent in pairs(ents.FindByClass("vc_generic")) do
            local Prt = ent:GetParent()
            if ent:GetNWBool("VC_AI_Driver", false) and IsValid(Prt) then
                if Prt.VC_ExtraSeat and not ent.VC_LegsSet then
                    VC.HandleAnim_SetBones(ent, "Instant", "PassSeatLegs")
                    ent.VC_LegsSet = true
                end

                if not Prt.VC_Pl_Check_Dist_Time or CurTime() >= Prt.VC_Pl_Check_Dist_Time then
                    Prt.VC_Pl_Check_Dist_Time = CurTime() + 5
                    Prt.VC_Pl_Check_Dist = Prt:GetPos():Distance(VC.GetViewPos()) < 1000 and not IsValid(Prt:GetParent())
                end

                if Prt.VC_Pl_Check_Dist then VC.HandleAnimations(ent, Prt) end
            else
                VC.ResetBones(ent)
            end
        end
    end
end

hook.Add("VC_dataDownloaded", "VC_dataDownloadedAnimFix", function(mdl)
    for k, ent in pairs(ents.FindByModel(mdl)) do
        if VC.GetModel(ent) == mdl then
            local drv = VC.GetDriver(ent)
            if IsValid(Drv) then VC.handleAnimEnterStartInstant(drv, ent) end
        end
    end
end)

function VC.anim_DoBendLegs(ply, ent, alsoExtraSeat)
    if not VC.getSetting("Anim_PassengerLegBending") then return end
    local ID = ply.VC_SeatID or ent:GetNWInt("VC_Key", 1)
    if ent.VC_ExtraSeat or alsoExtraSeat then
        local mainVeh = VC.getMainVehicle(ent)
        if not VC.SeatGetOptionFromID(mainVeh, ID, "noBendLegs") and not VC.SeatGetOptionFromID(mainVeh, ID, "Lay") then VC.HandleAnim_SetBones(ply, "Instant", "PassSeatLegs") end
    end
end

function VC.anim_OnDriverEnter(ply, ent, alsoExtraSeat, isTesting)
    if not IsValid(ent) or not VC.isVCModCompatible(ent) or ent.VC_ExtraSeat or alsoExtraSeat then return end
    if isTesting then
        VC.HandleAnim_SetBones(ply, "test", "test")
        return
    end

    local data = VC_suckfreemmann(ent)
    if not data then return end
    local animID = data["anim_OnDriverEnter"]
    if not animID or not VC.AnimDriverTypes[animID] then return end
    animID = VC.AnimDriverTypes[animID].id
    VC.HandleAnim_SetBones(ply, "Instant", animID)
end

hook.Add("UpdateAnimation", "VC_UpdateAnimation", function(ply, vel, max)
    if not VC.getSetting("Enabled") then return end
    if VC.DoHandleAnim_Player then VC.DoHandleAnim_Player(ply) end
end)

function VC.DoHandleAnim_Player(ply)
    local ent = ply:GetVehicle()
    if IsValid(ent) then if ent.VC_animDoOverridePos then ply:SetPos(ent:LocalToWorld(ent.VC_animDoOverridePos)) end end
    if VC.animDoTest then
        local ent = ply:GetVehicle()
        if IsValid(ent) then if VC.anim_OnDriverEnter then VC.anim_OnDriverEnter(ply, ent, alsoExtraSeat, true) end end
    end
end

function VC.DoHandleAnim_Initial(ply, ent, Veh, IsNotPod, VSC)
    for _, ent in pairs(player.GetAll()) do
        local Prt = ent:GetVehicle()
        if IsValid(Prt) then
            if Prt.VC_ExtraSeat and not ent.VC_LegsSet then
                VC.HandleAnim_SetBones(ent, "Instant", "PassSeatLegs")
                ent.VC_LegsSet = true
            end

            if Prt.VC_isSupported then end
        else
            VC.ResetBones(ent)
        end
    end
end

function VC.HandleAnimations(ply, Veh)
    if VC.InitializeData_Anim then
        local sData = VC_suckfreemmann(Veh)
        if sData.leftSteer then end
    end
end

VC.InitializeData_Anim = true

function VC.SettingsSetNew(tbl)
    local ret = {}
    if tbl then
        ret = tbl
    else
        VCPrint("ERROR! Failed to load settings file. This issue is most likely caused by not allowing to write to garrysmod/data/vcmod directory.")
    end

    VC.Settings = table.Copy(ret)
    if SERVER then VC.ServerSettings = table.Copy(ret) end
    return ret
end

if SERVER then
    function VC.Override_Controls_Read()
        VC.Override_Controls = util.KeyValuesToTable(file.Read("data/vcmod/override_controls.txt", "GAME") or "")
    end

    function VC.Override_Controls_Create()
        local CntTbl = {}
        file.Write("vcmod/override_controls.txt", util.TableToKeyValues(CntTbl))
        VC.Override_Controls_Read()
    end

    if not file.Exists("vcmod/override_controls.txt", "DATA") then
        VC.Override_Controls_Create()
    else
        VC.Override_Controls_Read()
    end

    util.AddNetworkString("VC_SendSettingsToServer_Override_Controls")
    net.Receive("VC_SendSettingsToServer_Override_Controls", function(len, ply)
        if not VC.CanEditAdminSettings(ply) then return end
        local Tbl = net.ReadTable()
        if not Tbl then return end
        for k, v in pairs(Tbl) do
            if not v.use or v.use ~= "1" then Tbl[k] = nil end
        end

        VC.Override_Controls = Tbl
        file.Write("vcmod/override_controls.txt", util.TableToKeyValues(Tbl))
        VC.Stream_Override_Controls()
        VC.log('<General> Player: ' .. VC.log_getPlayer(ply) .. ' has altered VCMod administrative override conntrols settings.', "General")
    end)

    util.AddNetworkString("VC_SendToClient_Options")
    util.AddNetworkString("VC_SendToClient_Logging")
    util.AddNetworkString("VC_SendToClient_Logging_Spec")
    util.AddNetworkString("VC_SendSettingsToServer")
    function VC.SettingsChanged()
        VC.Stream_SV_Settings()
    end

    local function CheckDefaults()
        local chng = false
        for k, v in pairs(VC.Settings_Defaults) do
            if VC.Settings[k] == nil then
                VC.Settings[k] = v
                chng = true
            end
        end

        if chng then VC.SettingsChanged() end
    end

    function VC.ResetSettings()
        file.Write("vcmod/settings_sv.txt", util.TableToJSON(VC.Settings_Defaults, true))
        VC.SettingsSetNew(VC.Settings_Defaults)
        VC.SettingsChanged()
        CheckDefaults()
    end

    function VC.LoadSettings()
        if file.Exists("vcmod/settings_sv.txt", "DATA") then
            VC.SettingsSetNew(table.Copy(util.JSONToTable(file.Read("vcmod/settings_sv.txt", "DATA"))))
            VC.SettingsChanged()
        else
            VC.ResetSettings()
        end

        CheckDefaults()
    end

    function VC.SaveSetting(k, v)
        hook.Call("VC_SettingChanged", GAMEMODE, k, v, VC.Settings[k] or v)
        hook.Call("VC_settingChanged", GAMEMODE, k, v, VC.Settings[k] or v)
    end

    VC.LoadSettings()
    timer.Simple(10, VC.SettingsChanged)
    function VC.GetSettings(ply)
        net.Start("VC_SendToClient_Options")
        net.WriteTable(VC.Settings)
        if ply then
            net.Send(ply)
        else
            net.Broadcast()
        end
    end

    concommand.Add("VC_ResetSettings", function(ply, cmd, arg) if VC.CanEditAdminSettings(ply) then VC.ResetSettings() end end)
    concommand.Add("VC_GetSettings_Sv", function(ply, cmd, arg) if VC.CanEditAdminSettings(ply) then VC.GetSettings(ply) end end)
    concommand.Add("VC_GetLogging_Data", function(ply, cmd, arg)
        if VC.CanEditAdminSettings(ply) then
            local data = {}
            for k, v in pairs(file.Find("vcmod/logs/*", "DATA")) do
                data[k] = string.gsub(v, ".txt", "")
            end

            net.Start("VC_SendToClient_Logging")
            net.WriteString(util.TableToJSON(data))
            if ply then
                net.Send(ply)
            else
                net.Broadcast()
            end
        end
    end)

    concommand.Add("VC_GetLogging_Data_Spec", function(ply, cmd, arg)
        if VC.CanEditAdminSettings(ply) and arg[1] then
            local contents = file.Read("vcmod/logs/" .. arg[1] .. ".txt", "DATA")
            if contents then
                net.Start("VC_SendToClient_Logging_Spec")
                net.WriteString(contents)
                if ply then
                    net.Send(ply)
                else
                    net.Broadcast()
                end
            end
        end
    end)

    concommand.Add("VC_GetSettings_Sv_Override_Controls", function(ply, cmd, arg) if VC.CanEditAdminSettings(ply) then VC.Stream_Override_Controls(ply) end end)
    function VC.Settings_Save(tbl)
        if not tbl then return end
        file.Write("vcmod/settings_sv.txt", util.TableToJSON(tbl, true))
    end

    net.Receive("VC_SendSettingsToServer", function(len, ply)
        if not VC.CanEditAdminSettings(ply) then return end
        local Tbl = net.ReadTable()
        if not Tbl then return end
        for k, v in pairs(Tbl) do
            if VC.Settings[k] ~= v then VC.SaveSetting(k, v) end
        end

        VC.SettingsSetNew(Tbl)
        CheckDefaults()
        VC.SettingsChanged()
        VC.Settings_Save(Tbl)
        VC.log('<General> Player: ' .. VC.log_getPlayer(ply) .. ' has altered VCMod administrative settings.', "General")
    end)
else
    function VC.SettingsChanged()
        if not VC.Material then return end
        VC.HD_Texture = VC.Material.HD2
        if VC.getSetting("Light_Type") == 2 then VC.HD_Texture = VC.Material.HD end
    end

    local function CheckDefaults()
        local chng = false
        for k, v in pairs(VC.Settings_Defaults) do
            if VC.Settings[k] == nil then
                VC.Settings[k] = v
                chng = true
            end
        end

        if chng then VC.SettingsChanged() end
    end

    function VC.ResetSettings()
        file.Write("vcmod/settings_cl.txt", util.TableToJSON(VC.Settings_Defaults, true))
        VC.SettingsSetNew(VC.Settings_Defaults)
        VC.SettingsChanged()
        CheckDefaults()
    end

    function VC.LoadSettings()
        if file.Exists("vcmod/settings_cl.txt", "DATA") then
            VC.SettingsSetNew(table.Copy(util.JSONToTable(file.Read("vcmod/settings_cl.txt", "DATA"))))
            VC.SettingsChanged()
        else
            VC.ResetSettings()
        end

        CheckDefaults()
    end

    function VC.SaveSetting(k, v)
        hook.Call("VC_SettingChanged", GAMEMODE, k, v, VC.Settings[k] or v)
        hook.Call("VC_settingChanged", GAMEMODE, k, v, VC.Settings[k] or v)
        if k and v ~= nil then
            local Tbl = {}
            if file.Exists("vcmod/settings_cl.txt", "DATA") then
                Tbl = util.JSONToTable(file.Read("vcmod/settings_cl.txt", "DATA"))
            else
                Tbl = VC.Settings_Defaults
            end

            if not Tbl then return end
            Tbl[k] = v
            VC.SettingsSetNew(Tbl)
            CheckDefaults()
            VC.SettingsChanged()
            file.Write("vcmod/settings_cl.txt", util.TableToJSON(Tbl, true))
        end
    end

    VC.LoadSettings()
    concommand.Add("VC_SaveSetting_Cl", function(ply, cmd, arg) if arg and arg[1] and arg[2] then VC.SaveSetting(arg[1], arg[2]) end end)
    VC.lngLoadLocal()
    VC.lngReload()
    VC.Lng_Get()
    VCPrint("Initialized clientside language data.")
    function VC.Controls_ReadScript()
        VC.Controls_List = util.KeyValuesToTable(file.Read("data/vcmod/controls.txt", "GAME") or "")
        for k, v in pairs(VC.Controls_Main) do
            if not VC.Controls_List[v.cmd] then
                VC.Controls_List[v.cmd] = {
                    key = v.default.key,
                    hold = v.default.hold
                }
            end
        end
    end

    function VC.Controls_CreateScript()
        local CntTbl = {}
        for _, Ctr in pairs(VC.Controls_Main) do
            if not Ctr.default.hold then Ctr.default.hold = "0" end
            CntTbl[Ctr.cmd] = Ctr.default
        end

        file.Write("vcmod/controls.txt", util.TableToKeyValues(CntTbl))
        VC.Controls_ReadScript()
    end

    if vcmod1 or vcmod1_els then
        if not file.Exists("vcmod/controls.txt", "DATA") then
            VC.Controls_CreateScript()
        else
            VC.Controls_ReadScript()
        end
    end

    hook.Add("PostDrawTranslucentRenderables", "VC_PostDrawTranslucentRenderables_Updater", function()
        net.Start("VC_RequestGlobalData")
        net.SendToServer()
        hook.Remove("PostDrawTranslucentRenderables", "VC_PostDrawTranslucentRenderables_Updater")
    end)
end
function VC.GetDataGeneral(mdl)
    local ret = nil
    if not ultrafreemmansuckGen then
        if VC.globalODGen_LoadLocal then
            VC.globalODGen_LoadLocal()
        else
            ultrafreemmansuckGen = {}
        end
    end
    return ultrafreemmansuckGen[mdl]
end

if VC.Extra_Modules then
    for k, v in pairs(VC.Extra_Modules) do
        if v.init_postLoad and not v.inited_postLoad then
            v.inited_postLoad = true
            v.init_postLoad()
        end
    end
end

function VC.log_removeOld(time)
    if not time then time = 60 * 60 * 24 * 31 end
    local count = 0
    local data = {}
    for k, v in pairs(file.Find("vcmod/logs/*", "DATA")) do
        data[k] = string.gsub(v, ".txt", "")
    end

    for k, v in pairs(data) do
        local var = string.Explode("(", v)[2]
        if var then
            local fileTime = string.Explode(")", var)[1]
            if fileTime then
                fileTime = tonumber(fileTime)
                if fileTime and type(fileTime) == "number" and fileTime < (os.time() - time) then
                    count = count + 1
                    file.Delete("vcmod/logs/" .. v .. ".txt")
                end
            end
        end
    end

    if count > 0 then VCPrint("Removed " .. count .. " old log files that were over a month old.") end
end

VC.log_removeOld()
if not ultrafreemmansuck then ultrafreemmansuck = {} end

local meta = FindMetaTable("Player")
if SERVER then
    function meta:VC_CD_getVehicleData()
        return VC.CD.GetPlayerOptions(self)
    end

    function meta:VC_CD_getOwnedVehicleData(ID)
        local ret = nil
        local data = VC.CD.GetPlayerOptions(self)
        if ID and data.Vehicles and data.Vehicles[ID] then ret = data.Vehicles[ID] end
        return ret
    end

    function meta:VC_CD_addVehicle(ID)
        return VC.CD.addVehicle(self, ID, {}, true)
    end

    function meta:VC_CD_removeVehicle(ID)
        return VC.CD.removeVehicle(self, ID, true)
    end
end

local meta = FindMetaTable("Entity")
function meta:VC_CD_getInfo()
    return VC.CD_getInfo(self)
end

function meta:VC_RM_getInfo()
    return VC.RM_getInfo(self)
end

local meta = FindMetaTable("Vehicle")
function meta:VC_fuelGetType()
    local ftype = self:GetNWInt("VC_FuelType", 0)
    return ftype, VC.FuelTypes[ftype].name
end

function meta:VC_getFuel(perc)
    local val = VC.getFuel(self)
    if perc then
        return val / VC.getFuelMax(self) * 100
    else
        return val
    end
end

meta.VC_GetFuel = meta.VC_getFuel
meta.VC_fuelGet = meta.VC_getFuel
function meta:VC_getMaxFuel()
    return VC.getFuelMax(self)
end

meta.VC_GetMaxFuel = meta.VC_getMaxFuel
meta.VC_fuelGetMax = meta.VC_getMaxFuel
function meta:VC_fuelSetMax(val)
    return VC.setFuelMax(val)
end

function meta:VC_getHealth(perc)
    if not VC.getServerSetting("Damage") then return 100 end
    if CLIENT then
        return self:GetNWInt("VC_HealthPerc", 1) * 100
    else
        if perc then
            return (self.VC_HealthPerc or 1) * 100
        else
            return self.VC_Health
        end
    end
end

meta.VC_GetHealth = meta.VC_getHealth
function meta:VC_getMaxHealth()
    return self.VC_MaxHealth
end

meta.VC_GetMaxHealth = meta.VC_getMaxHealth
meta.VC_getHealthMax = meta.VC_getMaxHealth
function meta:VC_CD_getVehicleID()
    return VC.CD.getVehicleID(self)
end

function meta:VC_CD_getVehicleIDFromData()
    return VC.CD.getVehicleIDFromData(self)
end

function VC_CD_getVehicleDataFromID(val)
    return VC.CD.getVehicleDataFromID(val)
end

function meta:VC_getName(default)
    return VC.getName(self, default)
end

meta.VC_GetName = meta.VC_getName
function meta:VC_getSpeedKmH()
    local ent = self
    if self.VC_ExtraSeat then
        local prt = self:GetParent()
        if IsValid(prt) then ent = prt end
    end

    local vel = ent:GetVelocity():Dot(CLIENT and ent:GetRight() or ent:GetForward())
    return vel and VC.VelocityToKmH(vel) or 0
end

meta.VC_GetSpeedKmH = meta.VC_getSpeedKmH
function VC_getCurrency()
    return VC.getCurCurrency()
end

function VC_fuelGetPrice(ftype)
    if not ftype then ftype = 1 end
    return math.Round(VC.getServerSetting("Fuel_PPL_" .. ftype, 1), 2)
end

function VC_getSettings()
    return VC.Settings
end

VC_GetSettings = VC_getSettings
function VC_setSettings(tbl)
    VC.SettingsSetNew(tbl)
    VC.SettingsChanged()
end

VC_SetSettings = VC_setSettings
function meta:VC_getDamagedParts()
    local tbl = {}
    if self.VC_DamagedObjects then
        tbl = {}
        if self.VC_DamagedObjects.wheel then tbl.wheel = table.Copy(self.VC_DamagedObjects.wheel) end
        if self.VC_DamagedObjects.light then tbl.light = table.Copy(self.VC_DamagedObjects.light) end
        if self.VC_DamagedObjects.exhaust then tbl.exhaust = table.Copy(self.VC_DamagedObjects.exhaust) end
    end
    return tbl
end

meta.VC_GetDamagedParts = meta.VC_getDamagedParts
function meta:VC_partIsDamaged(val)
    return VC.ObjectIsDamaged(self, val)
end

function meta:VC_getStates()
    return self.VC_States or {}
end

meta.VC_GetStates = meta.VC_getStates
function meta:VC_setStates(val)
    self.VC_States = val
end

meta.VC_SetStates = meta.VC_setStates
function meta:VC_setRunningLights(on)
    if on then
        return VC.RunningLightsOn(self)
    else
        return VC.RunningLightsOff(self)
    end
end

meta.VC_SetRunningLights = meta.VC_setRunningLights
function meta:VC_setFogLights(on)
    if on then
        return VC.FogLightsOn(self)
    else
        return VC.FogLightsOff(self)
    end
end

meta.VC_SetFogLights = meta.VC_setFogLights
function meta:VC_setHazardLights(on)
    if on then
        return VC.HazardLightsOn(self)
    else
        return VC.HazardLightsOff(self)
    end
end

meta.VC_SetHazardLights = meta.VC_setHazardLights
function meta:VC_setHighBeams(on)
    if on then
        return VC.HighBeamsOn(self)
    else
        return VC.HighBeamsOff(self)
    end
end

meta.VC_SetHighBeams = meta.VC_setHighBeams
function meta:VC_setLowBeams(on)
    if on then
        return VC.LowBeamsOn(self)
    else
        return VC.LowBeamsOff(self)
    end
end

meta.VC_SetLowBeams = meta.VC_setLowBeams
function meta:VC_setTurnLightLeft(on)
    if on then
        return VC.TurnLightLeftOn(self)
    else
        return VC.TurnLightLeftOff(self)
    end
end

meta.VC_SetTurnLightLeft = meta.VC_setTurnLightLeft
function meta:VC_setTurnLightRight(on)
    if on then
        return VC.TurnLightRightOn(self)
    else
        return VC.TurnLightRightOff(self)
    end
end

meta.VC_SetTurnLightRight = meta.VC_setTurnLightRight
function meta:VC_setHorn(on)
    if on then
        return VC.HornOn(self)
    else
        return VC.HornOff(self)
    end
end

function meta:VC_setCruiseControl(on)
    if on then
        return VC.CruiseOn(self)
    else
        return VC.CruiseOff(self)
    end
end

meta.VC_SetCruiseControl = meta.VC_setCruiseControl
function meta:VC_setELSManual(on)
    if on then
        return VC.ELS_ManualOn(self)
    else
        return VC.ELS_ManualOff(self)
    end
end

meta.VC_SetELSManual = meta.VC_setELSManual
function meta:VC_setELSLights(on)
    if on then
        return VC.ELS_LightsOn(self)
    else
        return VC.ELS_LightsOff(self)
    end
end

meta.VC_SetELSLights = meta.VC_setELSLights
function meta:VC_setELSLightsCycle()
    return VC.ELS_Lht_Cycle(self)
end

meta.VC_SetELSLightsCycle = meta.VC_setELSLightsCycle
function meta:VC_setELSSound(on)
    if on then
        return VC.ELS_SoundOn(self)
    else
        return VC.ELS_SoundOff(self)
    end
end

meta.VC_SetELSSound = meta.VC_setELSSound
function meta:VC_setELSSoundCycle()
    return VC.ELS_Snd_Cycle(self)
end

meta.VC_SetELSSoundCycle = meta.VC_setELSSoundCycle
function meta:VC_getELSLightsOn()
    return VC.is_ELSLightsOn(self)
end

meta.VC_GetELSLightsOn = meta.VC_getELSLightsOn
function meta:VC_getELSSoundOn()
    return VC.is_ELSSoundOn(self)
end

meta.VC_GetELSSoundOn = meta.VC_getELSSoundOn
function meta:VC_getCruise(val)
    return VC.getCruise(self)
end

function meta:VC_isTrailer(val)
    return VC.isTrailer(self)
end

function meta:VC_getTruck(val)
    return VC.getTruck(self)
end

function meta:VC_getTrailer(val)
    return VC.getTrailer(self)
end

function meta:VC_getAttachedTo(val)
    return VC.getAttachedTo(self)
end

function meta:VC_isTrailerSupported(val)
    return VC.isTrailerSupported(self)
end

function meta:VC_setOverride(key, val)
    return VC.setOverride(self, key, val)
end

function meta:VC_getOverride(key)
    return VC.getOverride(self, key)
end

function meta:VC_isFuelConsumptionEnabled()
    return VC.isFuelConsumptionEnabled(self)
end

if SERVER then
    function meta:VC_getVehiclePersistanceData()
        return VC.getVehiclePersistanceData(self)
    end

    function meta:VC_setVehiclePersistanceData(val)
        return VC.setVehiclePersistanceData(self, val)
    end

    function meta:VC_lock()
        return VC.Lock(self)
    end

    meta.VC_Lock = meta.VC_lock
    function meta:VC_getExitData(pos)
        local data, found = VC.getExitData(self, pos)
        return found and data[1]
    end

    function meta:VC_UnLock()
        return VC.UnLock(self)
    end

    meta.VC_unLock = meta.VC_UnLock
    function meta:VC_isLocked()
        return VC.IsLocked(self)
    end

    meta.VC_IsLocked = meta.VC_isLocked
    function meta:VC_setDamagedParts(tbl)
        if IsValid(self) then return VC.SetDamagedObjects(self, tbl) end
    end

    meta.VC_SetDamagedParts = meta.VC_setDamagedParts
    function meta:VC_repairFull_Admin()
        if IsValid(self) then return VC.RepairVehicle_Admin(self) end
    end

    meta.VC_RepairFull_Admin = meta.VC_repairFull_Admin
    function meta:VC_damageFull_Admin()
        if IsValid(self) then return VC.DamageVehicle_Admin(self) end
    end

    meta.VC_DamageFull_Admin = meta.VC_damageFull_Admin
    function meta:VC_hasGodMode()
        if IsValid(self) then return self.VC_GodMode end
    end

    meta.VC_HasGodMode = meta.VC_hasGodMode
    function meta:VC_getSeatsAvailable()
        if IsValid(self) then return VC.SeatsGetAvailable(self) end
    end

    meta.VC_GetSeatsAvailable = meta.VC_getSeatsAvailable
    function meta:VC_setGodMode(val)
        if IsValid(self) then self.VC_GodMode = val end
    end

    meta.VC_SetGodMode = meta.VC_setGodMode
    function meta:VC_setHealth(val)
        if IsValid(self) then return VC.SetHealth(self, val) end
    end

    function meta:VC_setHealthMax(val)
        if IsValid(self) then return VC.SetHealthMax(self, val) end
    end

    function meta:VC_damageHealth(val)
        if IsValid(self) then return VC.DamageHealth(self, val) end
    end

    meta.VC_DamageHealth = meta.VC_damageHealth
    function meta:VC_repairHealth(val)
        if IsValid(self) then return VC.RepairHealth(self, val) end
    end

    meta.VC_RepairHealth = meta.VC_repairHealth
    function meta:VC_explodeEngine(silent)
        if IsValid(self) then return VC.ExplodeEngine(self, silent) end
    end

    meta.VC_ExplodeEngine = meta.VC_explodeEngine
    function meta:VC_doBackfire(damageHealth, damagedOnly)
        if IsValid(self) then return VC.DoBackFire(self, damageHealth, damagedOnly) end
    end

    function meta:VC_fuelCanisterSet(val)
        if IsValid(self) then
            if self:GetClass() == "vc_jerrycan" then
                self.VC_FuelAmount = val
                self:SetNWInt("VC_FuelAmount", self.VC_FuelAmount or 0)
            else
                self.VC_Storage = val
                self:SetNWInt("VC_Storage", val)
            end
        end
    end

    meta.VC_Fuel_Canister_Set = meta.VC_fuelCanisterSet
    function meta:VC_fuelSet(val)
        if IsValid(self) then return VC.setFuel(self, val) end
    end

    function meta:VC_fuelAdd(val)
        if IsValid(self) then return VC.Refuel(self, val) end
    end

    meta.VC_Fuel_Add = meta.VC_fuelAdd
    function meta:VC_fuelSetConsumptionMultiplier(val)
        self.VC_fuelConsumptionMultiplier = val
    end

    function meta:VC_fuelConsume(val)
        if IsValid(self) then return VC.FuelConsume(self, val) end
    end

    meta.VC_Fuel_Consume = meta.VC_fuelConsume
    function meta:VC_fuelConsumptionSetEnabled(val)
        if IsValid(self) then return VC.setFuelConsumptionEnabled(self, val) end
    end

    function meta:VC_setCruiseSpeed(val)
        return VC.CruiseSetSpeed(self, val)
    end

    meta.VC_SetCruiseSpeed = meta.VC_setCruiseSpeed
    function meta:VC_setHornCustom(snd, pitch, vol, lvl)
        return VC.SetHornCustom(self, snd, pitch, vol, lvl)
    end

    meta.VC_SetHornCustom = meta.VC_setHornCustom
    function meta:VC_detachTrailer()
        return VC.Trailer_Detach(self)
    end

    meta.VC_DetachTrailer = meta.VC_detachTrailer
    function meta:VC_clearSeats()
        return VC.ClearSeats(self)
    end

    meta.VC_ClearSeats = meta.VC_clearSeats
    function meta:VC_getPlayers()
        return VC.GetDrivers(self)
    end

    meta.VC_GetPlayers = meta.VC_getPlayers
    function meta:VC_CD_menuOpen(ply)
        return VC.CD.RequestOpen(self, ply)
    end

    meta.VC_Menu_CD_Open = meta.VC_CD_menuOpen
    function meta:VC_damagePart(obj, int, att, inf)
        return VC.DamagePart(self, obj, int, att, inf)
    end

    meta.VC_DamagePart = meta.VC_damagePart
    function meta:VC_repairPart(obj, int)
        return VC.RepairPart(self, obj, int)
    end

    meta.VC_RepairPart = meta.VC_repairPart
    function meta:VC_getLights(obj, int)
        return VC.getLights(self)
    end

    function meta:VC_CD_returnVehicle(force)
        return VC.CD.ReturnVehicle(self, force)
    end

    meta.VC_CarDealerReturnVehicle = meta.VC_CD_returnVehicle
else
    function meta:VC_CD_editMenuOpen()
        return VC.CD.open_menu_cardealer_edit(self)
    end

    meta.VC_Menu_CD_Edit_Open = meta.VC_CD_editMenuOpen
end



print('VCMOD LOADED')