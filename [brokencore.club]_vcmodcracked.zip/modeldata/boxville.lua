VCModels['models/boxville.mdl']	=	{
		Light_DD_Int	=	true,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Date	=	"Mon Jul 23 16:28:44 2018",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-16.549999237061,-135.02000427246,9.4300003051758),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		Copyright	=	"Copyright © 2012-2018 VCMod (freemmaann). All Rights Reserved.",
		ExtraSeats	=	{
				{
				Pos	=	Vector(24.60000038147,38.860000610352,50.409999847412),
				DoorSounds	=	true,
				Ang	=	Angle(0,0,0),
				EnterRange	=	80,
				RadioControl	=	true,
					},
				},
		DLT	=	3491063048,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.32,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Use	=	true,
					Pos2	=	Vector(-35.840000152588,83.110000610352,38.080001831055),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Pos4	=	Vector(-26.25,83.050003051758,27.930000305176),
					Pos1	=	Vector(-26.239999771118,82.98999786377,38.099998474121),
					Pos3	=	Vector(-35.869998931885,83.129997253418,27.950000762939),
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				SpecMat	=	{
						},
				RenderHD_Adv	=	true,
				Beta_Inner3D	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Pos	=	Vector(-31.25,83.220001220703,32.689998626709),
				UseSprite	=	true,
				HBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.32,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Use	=	true,
					Pos2	=	Vector(35.840000152588,83.110000610352,38.080001831055),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Pos4	=	Vector(26.25,83.050003051758,27.930000305176),
					Pos1	=	Vector(26.239999771118,82.98999786377,38.099998474121),
					Pos3	=	Vector(35.869998931885,83.129997253418,27.950000762939),
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				SpecMat	=	{
						},
				Beta_Inner3D	=	true,
				RenderHD_Adv	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Pos	=	Vector(31.25,83.220001220703,32.689998626709),
				UseSprite	=	true,
				HBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.32,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				RenderHD_Adv	=	true,
				Pos	=	Vector(-31.219999313354,84.379997253418,43.599998474121),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				UseBlinkers	=	true,
				UseSprite	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Use	=	true,
					Pos2	=	Vector(-27.629999160767,84.300003051758,44.930000305176),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Pos4	=	Vector(-34.770000457764,84.339996337891,42.400001525879),
					Pos1	=	Vector(-34.799999237061,84.330001831055,44.970001220703),
					Pos3	=	Vector(-27.540000915527,84.279998779297,42.400001525879),
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.32,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(31.120000839233,84.379997253418,43.599998474121),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Use	=	true,
					Pos2	=	Vector(27.430000305176,84.300003051758,44.950000762939),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Pos4	=	Vector(34.619998931885,84.339996337891,42.439998626709),
					Pos1	=	Vector(34.619998931885,84.330001831055,44.970001220703),
					Pos3	=	Vector(27.440000534058,84.279998779297,42.400001525879),
						},
				RenderHD_Adv	=	true,
				Beta_Inner3D	=	true,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.32,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-34,-134.46000671387,48.110000610352),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Use	=	true,
					Pos2	=	Vector(-29.690000534058,-134.53999328613,49.939998626709),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Pos4	=	Vector(-38.110000610352,-134.5,46.430000305176),
					Pos1	=	Vector(-38.119998931885,-134.50999450684,49.909999847412),
					Pos3	=	Vector(-29.629999160767,-134.55999755859,46.479999542236),
						},
				Beta_Inner3D	=	true,
				RenderHD_Adv	=	true,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.32,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Use	=	true,
					Pos2	=	Vector(29.770000457764,-134.53999328613,49.939998626709),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Pos4	=	Vector(38.189998626709,-134.52000427246,46.430000305176),
					Pos1	=	Vector(38.200000762939,-134.50999450684,49.909999847412),
					Pos3	=	Vector(29.709999084473,-134.55999755859,46.479999542236),
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(34.080001831055,-134.46000671387,48.110000610352),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				Beta_Inner3D	=	true,
				RenderHD_Adv	=	true,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.32,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Use	=	true,
					Pos2	=	Vector(-29.469999313354,-134.53999328613,44.220001220703),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Pos4	=	Vector(-38.520000457764,-134.5,40.520000457764),
					Pos1	=	Vector(-38.529998779297,-134.50999450684,44.229999542236),
					Pos3	=	Vector(-29.450000762939,-134.55999755859,40.509998321533),
						},
				SpecMat	=	{
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				UseSprite	=	true,
				Pos	=	Vector(-34,-134.46000671387,42.200000762939),
				UseDynamic	=	true,
				RenderHD_Adv	=	true,
				UseBrake	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.32,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Use	=	true,
					Pos2	=	Vector(29.559999465942,-134.53999328613,44.220001220703),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Pos4	=	Vector(38.599998474121,-134.52000427246,40.520000457764),
					Pos1	=	Vector(38.610000610352,-134.50999450684,44.229999542236),
					Pos3	=	Vector(29.579999923706,-134.55999755859,40.509998321533),
						},
				SpecMat	=	{
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				UseSprite	=	true,
				Pos	=	Vector(34.080001831055,-134.46000671387,42.200000762939),
				UseDynamic	=	true,
				Beta_Inner3D	=	true,
				UseBrake	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderHD_Adv	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.32,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Use	=	true,
					Pos2	=	Vector(-35.880001068115,83.110000610352,38.080001831055),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Pos4	=	Vector(-26.290000915527,83.050003051758,27.930000305176),
					Pos1	=	Vector(-26.280000686646,82.98999786377,38.099998474121),
					Pos3	=	Vector(-35.909999847412,83.129997253418,27.950000762939),
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-31.290000915527,83.220001220703,32.689998626709),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.32,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Use	=	true,
					Pos2	=	Vector(35.889999389648,83.110000610352,38.080001831055),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Pos4	=	Vector(26.299999237061,83.050003051758,27.930000305176),
					Pos1	=	Vector(26.290000915527,82.98999786377,38.099998474121),
					Pos3	=	Vector(35.919998168945,83.129997253418,27.950000762939),
						},
				SpecMat	=	{
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(31.299999237061,83.220001220703,32.689998626709),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				UseRunning	=	true,
				RenderHD_Adv	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.32,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Use	=	true,
					Pos2	=	Vector(31.39999961853,-134.5299987793,109.23000335693),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Pos4	=	Vector(36.639999389648,-134.5299987793,107.94000244141),
					Pos1	=	Vector(36.639999389648,-134.5299987793,109.2200012207),
					Pos3	=	Vector(31.389999389648,-134.5299987793,107.95999908447),
						},
				SpecMat	=	{
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(34.119998931885,-134.5299987793,108.56999969482),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				UseRunning	=	true,
				RenderHD_Adv	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.32,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Use	=	true,
					Pos2	=	Vector(-31.360000610352,-134.5299987793,109.23000335693),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Pos4	=	Vector(-36.599998474121,-134.5299987793,107.94000244141),
					Pos1	=	Vector(-36.599998474121,-134.5299987793,109.2200012207),
					Pos3	=	Vector(-31.35000038147,-134.5299987793,107.95999908447),
						},
				SpecMat	=	{
						},
				RenderHD_Adv	=	true,
				Pos	=	Vector(-34.080001831055,-134.5299987793,108.56999969482),
				UseDynamic	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				UseSprite	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				Beta_Inner3D	=	true,
					},
				},
		em_state	=	5236594572,
		Fuel	=	{
			FuelLidPos	=	Vector(-43.450000762939,-25.940000534058,38.830001831055),
			FuelTypeUse	=	true,
			FuelLidUse	=	true,
			FuelType	=	1,
				},
		Author	=	"TheCarson116 (76561198123551419)",
}