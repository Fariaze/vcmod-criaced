VCModels['models/crsk_autospeugeot206rc_2003.mdl']	=	{
		em_state	=	5236594800,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		HealthEnginePosOvr	=	true,
		Date	=	"Sun Nov 18 10:47:10 2018",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-22.530000686646,-89.589996337891,12.060000419617),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-18.059999465942,-89.589996337891,12.060000419617),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		Indication	=	{
			fuel	=	{
				max	=	1,
				pp	=	"fuel_needle",
				top	=	1,
					},
				},
		Copyright	=	"Copyright © 2012-2018 VCMod (freemmaann). All Rights Reserved.",
		HealthEnginePos	=	Vector(0,78.690002441406,40.229999542236),
		DLT	=	3491063200,
		Lights	=	{
				{
				UseRunning	=	true,
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
					Select	=	3,
					New	=	"models\crskautos\peugeot\206rc_2003\interior_lod0_illum_on",
					Use	=	true,
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Pos	=	Vector(-14.729999542236,8.25,51.75),
					},
				{
				UseRunning	=	true,
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
					Select	=	27,
					New	=	"models\crskautos\shared\vmt\white_illum_on",
					Use	=	true,
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Pos	=	Vector(-12.89999961853,8.25,51.75),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseRunning	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-21.159999847412,89.900001525879,30.64999961853),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				SpecMat	=	{
						},
				RenderInner	=	true,
				Pos	=	Vector(-25.700000762939,83.099998474121,31.680000305176),
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				UseSprite	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				SpecMat	=	{
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseHighBeams	=	true,
				UsePrjTex	=	true,
				Pos	=	Vector(-29.579999923706,80.389999389648,33.189998626709),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseSprite	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6099,
						},
				SpecSpin	=	{
						},
				BGroups	=	{
					[3]	=	{
							"bamp_pered_stock",
							},
						},
				UsePrjTex	=	true,
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.8,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-26.049999237061,85.650001525879,15.14999961853),
					Pos2	=	Vector(-33.599998474121,85.410003662109,21.959999084473),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-25.129999160767,85.360000610352,22),
					Pos3	=	Vector(-33.700000762939,85.76000213623,16.020000457764),
						},
				FogColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-29.879999160767,85.569999694824,18.64999961853),
				RenderInner	=	true,
				UseFog	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				RenderInner_Size	=	1.654,
				RenderHD_Adv	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				BlinkerLeft	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-31.89999961853,78.51000213623,35.450000762939),
				UseDynamic	=	true,
				SpecMat	=	{
						},
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-38.490001678467,40.319999694824,30.129999160767),
					Pos2	=	Vector(-38.490001678467,44.909999847412,32.409999847412),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-38.479999542236,40.889999389648,32.759998321533),
					Pos3	=	Vector(-38.569999694824,44.580001831055,29.809999465942),
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-38.5,42.75,31.319999694824),
				UseDynamic	=	true,
				BlinkerLeft	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-31.809999465942,-78.339996337891,39.290000915527),
					Pos2	=	Vector(-32.900001525879,-75.150001525879,41.939998626709),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-30.170000076294,-77.050003051758,42.279998779297),
					Pos3	=	Vector(-33.380001068115,-76.160003662109,39.319999694824),
						},
				BlinkerLeft	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-31.809999465942,-76.550003051758,40.740001678467),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-29.479999542236,-80.300003051758,39.069999694824),
				UseDynamic	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-27.60000038147,-81.099998474121,35.400001525879),
					Pos2	=	Vector(-30.239999771118,-80.580001831055,37.849998474121),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-27.770000457764,-80.910003662109,37.770000457764),
					Pos3	=	Vector(-30.049999237061,-80.76000213623,35.549999237061),
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-28.870000839233,-80.889999389648,36.630001068115),
				UseDynamic	=	true,
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				UseRunning	=	true,
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
					Select	=	3,
					New	=	"models\crskautos\peugeot\206rc_2003\interior_lod0_illum_on",
					Use	=	true,
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Pos	=	Vector(14.729999542236,8.25,51.75),
					},
				{
				UseRunning	=	true,
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
					Select	=	27,
					New	=	"models\crskautos\shared\vmt\white_illum_on",
					Use	=	true,
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Pos	=	Vector(12.89999961853,8.25,51.75),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseRunning	=	true,
				UseSprite	=	true,
				Pos	=	Vector(21.159999847412,89.900001525879,30.64999961853),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				SpecMat	=	{
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				RenderInner	=	true,
				Pos	=	Vector(25.709999084473,83.099998474121,31.690000534058),
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				UseSprite	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				SpecMat	=	{
						},
				UseHighBeams	=	true,
				UseSprite	=	true,
				Pos	=	Vector(29.579999923706,80.389999389648,33.189998626709),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UsePrjTex	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6099,
						},
				SpecSpin	=	{
						},
				BGroups	=	{
					[3]	=	{
							"bamp_pered_stock",
							},
						},
				UsePrjTex	=	true,
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.8,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(26.049999237061,85.650001525879,15.14999961853),
					Pos2	=	Vector(33.599998474121,85.410003662109,21.959999084473),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(25.129999160767,85.360000610352,22),
					Pos3	=	Vector(33.700000762939,85.76000213623,16.020000457764),
						},
				FogColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				SpecMat	=	{
						},
				RenderHD_Adv	=	true,
				Pos	=	Vector(29.879999160767,85.569999694824,18.64999961853),
				RenderInner	=	true,
				UseFog	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				RenderInner_Size	=	1.654,
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(31.89999961853,78.51000213623,35.450000762939),
				UseDynamic	=	true,
				BlinkerRight	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(38.490001678467,40.319999694824,30.129999160767),
					Pos2	=	Vector(38.490001678467,44.909999847412,32.409999847412),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(38.479999542236,40.889999389648,32.759998321533),
					Pos3	=	Vector(38.569999694824,44.580001831055,29.809999465942),
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(38.5,42.75,31.319999694824),
				UseDynamic	=	true,
				BlinkerRight	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(31.809999465942,-78.339996337891,39.290000915527),
					Pos2	=	Vector(32.900001525879,-75.150001525879,41.939998626709),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(30.170000076294,-77.050003051758,42.279998779297),
					Pos3	=	Vector(33.380001068115,-76.160003662109,39.319999694824),
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(31.809999465942,-76.550003051758,40.740001678467),
				UseDynamic	=	true,
				BlinkerRight	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(29.479999542236,-80.300003051758,39.069999694824),
				UseDynamic	=	true,
				UseRunning	=	true,
				UseBrake	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(27.60000038147,-81.099998474121,35.400001525879),
					Pos2	=	Vector(30.239999771118,-80.580001831055,37.849998474121),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(27.770000457764,-80.910003662109,37.770000457764),
					Pos3	=	Vector(30.049999237061,-80.76000213623,35.549999237061),
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(28.870000839233,-80.889999389648,36.630001068115),
				UseDynamic	=	true,
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(0,-86.529998779297,19.840000152588),
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2714,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-5.460000038147,-59.680000305176,63.080001831055),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	13,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(5.710000038147,-59.630001068115,63.130001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.0375,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	55,
					b	=	0,
					a	=	255,
					g	=	255,
						},
				RenderType	=	2,
				BlinkerLeft	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-16.680000305176,32.099998474121,47.099998474121),
				SpecMat	=	{
						},
				RenderInner_Size	=	2.6064,
				RenderInner	=	true,
				UseBlinkers	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	17,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.0375,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	55,
					b	=	0,
					a	=	255,
					g	=	255,
						},
				RenderType	=	2,
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-13.029999732971,32.099998474121,47.099998474121),
				BlinkerRight	=	true,
				RenderInner	=	true,
				RenderInner_Size	=	2.6064,
				UseBlinkers	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	17,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.0588,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/gui/icons/dashboard/running.png",
					Pos4	=	Vector(-15.85000038147,31.690000534058,46.849998474121),
					Pos2	=	Vector(-15.35000038147,31.979999542236,47.360000610352),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-15.869999885559,31.819999694824,47.419998168945),
					Pos3	=	Vector(-15.369999885559,31.809999465942,46.819999694824),
						},
				RenderType	=	2,
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-15.529999732971,31.790000915527,47.020000457764),
				RunningColor	=	{
					r	=	55,
					b	=	0,
					a	=	255,
					g	=	255,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.0588,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/gui/icons/dashboard/lowbeams.png",
					Pos4	=	Vector(-15.310000419617,31.690000534058,46.849998474121),
					Pos2	=	Vector(-14.810000419617,31.979999542236,47.360000610352),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-15.329999923706,31.819999694824,47.419998168945),
					Pos3	=	Vector(-14.829999923706,31.809999465942,46.819999694824),
						},
				RenderType	=	2,
				SpecMat	=	{
						},
				UseSprite	=	true,
				LBeamColor	=	{
					r	=	55,
					b	=	0,
					a	=	255,
					g	=	255,
						},
				UseHighBeams	=	true,
				Pos	=	Vector(-14.989999771118,31.790000915527,47.020000457764),
				HBeamColor	=	{
					r	=	55,
					b	=	0,
					a	=	255,
					g	=	255,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.0588,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/gui/icons/dashboard/highbeams.png",
					Pos4	=	Vector(-14.810000419617,31.690000534058,46.849998474121),
					Pos2	=	Vector(-14.310000419617,31.979999542236,47.360000610352),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-14.829999923706,31.819999694824,47.419998168945),
					Pos3	=	Vector(-14.329999923706,31.809999465942,46.819999694824),
						},
				RenderType	=	2,
				HBeamColor	=	{
					r	=	0,
					b	=	255,
					a	=	255,
					g	=	55,
						},
				UseSprite	=	true,
				Pos	=	Vector(-14.489999771118,31.790000915527,47.020000457764),
				UseHighBeams	=	true,
				SpecMat	=	{
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.0588,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/gui/icons/dashboard/fog.png",
					Pos4	=	Vector(-14.329999923706,31.690000534058,46.849998474121),
					Pos2	=	Vector(-13.829999923706,31.979999542236,47.360000610352),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-14.35000038147,31.819999694824,47.419998168945),
					Pos3	=	Vector(-13.85000038147,31.809999465942,46.819999694824),
						},
				RenderType	=	2,
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-14.010000228882,31.790000915527,47.020000457764),
				UseFog	=	true,
				FogColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(25,0,0),
				Pos	=	Vector(14.720000267029,13.159999847412,30.329999923706),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(25,0,0),
				Pos	=	Vector(-18.139999389648,-26.540000915527,28.010000228882),
					},
				{
				Ang	=	Angle(25,0,0),
				Pos	=	Vector(18.139999389648,-26.540000915527,28.010000228882),
					},
				{
				Ang	=	Angle(25,0,0),
				Pos	=	Vector(-1.0099999904633,-26.540000915527,28.010000228882),
					},
				},
		Fuel	=	{
			FuelLidPos	=	Vector(33.909999847412,-59.319999694824,41.619998931885),
			FuelType	=	0,
			Override	=	true,
			FuelTypeUse	=	true,
			FuelLidUse	=	true,
				},
		Author	=	"DangerKiddy(DK) (76561198132964487)",
}