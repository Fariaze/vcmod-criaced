VCModels['models/crsk_autospeugeot205_t16_1984.mdl']	=	{
		em_state	=	5236594458,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		HealthEnginePosOvr	=	true,
		Date	=	"Fri Jan 19 02:29:59 2018",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-19.64999961853,-96.449996948242,10.640000343323),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(16,0,0),
				Pos	=	Vector(14.409999847412,4.7300000190735,28.930000305176),
				RadioControl	=	true,
					},
				},
		HealthEnginePos	=	Vector(11.289999961853,-46.040000915527,34.540000915527),
		DLT	=	3491062972,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-17.719999313354,87.940002441406,28.129999160767),
					UseColor	=	true,
					Pos2	=	Vector(-31.219999313354,82.110000610352,34.459999084473),
					Color	=	{
						r	=	247,
						b	=	190,
						a	=	255,
						g	=	255,
							},
					Use	=	true,
					Pos1	=	Vector(-19.379999160767,85.099998474121,34.290000915527),
					Pos3	=	Vector(-31.760000228882,85.190002441406,27.909999847412),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-25.510000228882,84.559997558594,30.60000038147),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	247,
					b	=	190,
					a	=	255,
					g	=	255,
						},
				Dynamic	=	{
					Size	=	1.4552,
					Brightness	=	1.4552,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(32.25,85.190002441406,27.969999313354),
					UseColor	=	true,
					Pos2	=	Vector(20.200000762939,84.730003356934,34.25),
					Color	=	{
						r	=	247,
						b	=	190,
						a	=	255,
						g	=	255,
							},
					Use	=	true,
					Pos1	=	Vector(31.870000839233,82.379997253418,34.299999237061),
					Pos3	=	Vector(18.219999313354,88.120002746582,27.790000915527),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(25.870000839233,84.559997558594,30.840000152588),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	247,
					b	=	190,
					a	=	255,
					g	=	255,
						},
				Dynamic	=	{
					Size	=	1.41,
					Brightness	=	1.6,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-31.549999237061,86.150001525879,15.340000152588),
					Use	=	true,
					Pos2	=	Vector(-24.979999542236,86.370002746582,18.75),
					Color	=	{
						r	=	255,
						b	=	100,
						a	=	255,
						g	=	175,
							},
					UseColor	=	true,
					Pos1	=	Vector(-31.559999465942,85.940002441406,18.809999465942),
					Pos3	=	Vector(-25,86.5,15.340000152588),
						},
				FogColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				BGroups	=	{
						{
						[0]	=	"bumperfa",
						[1]	=	"bumperfrace",
							},
						},
				UsePrjTex	=	true,
				Pos	=	Vector(-28.35000038147,86.620002746582,17.110000610352),
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				UseFog	=	true,
				UseSprite	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				Beta_Inner3D	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(31.989999771118,86,15.130000114441),
					UseColor	=	true,
					Pos2	=	Vector(25.420000076294,86.269996643066,18.659999847412),
					Color	=	{
						r	=	255,
						b	=	100,
						a	=	255,
						g	=	175,
							},
					Use	=	true,
					Pos1	=	Vector(32,85.790000915527,18.60000038147),
					Pos3	=	Vector(25.440000534058,86.419998168945,15.130000114441),
						},
				FogColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				BGroups	=	{
						{
						[0]	=	"bumperfa",
						[1]	=	"bumperfrace",
							},
						},
				UsePrjTex	=	true,
				Pos	=	Vector(28.670000076294,86.519996643066,17.030000686646),
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				RenderInner	=	true,
				UseFog	=	true,
				UseSprite	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.18,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-32.659999847412,-91.580001831055,28.549999237061),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0.1866,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.18,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(32.340000152588,-91.819999694824,28.299999237061),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0.1866,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(30.860000610352,-91.559997558594,31.340000152588),
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-31,-91.580001831055,32.150001525879),
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(35.330001831055,-90.529998779297,29.770000457764),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.1119,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(33.229999542236,83.459999084473,28.489999771118),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	4,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(33.409999847412,81.089996337891,33.580001831055),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-35.810001373291,-90.01000213623,30.200000762939),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.1119,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-33.490001678467,83.019996643066,28.639999389648),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	4,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-32.909999847412,80.830001831055,33.549999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2576,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(29.89999961853,-92.730003356934,28.340000152588),
				UseDynamic	=	true,
				ReverseColor	=	{
					r	=	255,
					b	=	255,
					a	=	255,
					g	=	255,
						},
				Dynamic	=	{
					Size	=	0.3358,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2576,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-29.969999313354,-92.349998474121,28.280000686646),
				UseDynamic	=	true,
				ReverseColor	=	{
					r	=	255,
					b	=	255,
					a	=	255,
					g	=	255,
						},
				Dynamic	=	{
					Size	=	0.3358,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(32.25,85.190002441406,27.969999313354),
					UseColor	=	true,
					Pos2	=	Vector(20.200000762939,84.730003356934,34.25),
					Color	=	{
						r	=	247,
						b	=	190,
						a	=	255,
						g	=	255,
							},
					Use	=	true,
					Pos1	=	Vector(31.870000839233,82.379997253418,34.299999237061),
					Pos3	=	Vector(18.219999313354,88.120002746582,27.790000915527),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	1.41,
					Brightness	=	1.6,
						},
				UseSprite	=	true,
				LBeamColor	=	{
					r	=	247,
					b	=	190,
					a	=	255,
					g	=	255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				HBeamColor	=	{
					r	=	247,
					b	=	190,
					a	=	255,
					g	=	255,
						},
				Pos	=	Vector(25.870000839233,84.559997558594,30.840000152588),
				UsePrjTex	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-17.719999313354,87.940002441406,28.129999160767),
					UseColor	=	true,
					Pos2	=	Vector(-31.219999313354,82.110000610352,34.459999084473),
					Color	=	{
						r	=	247,
						b	=	190,
						a	=	255,
						g	=	255,
							},
					Use	=	true,
					Pos1	=	Vector(-19.379999160767,85.099998474121,34.290000915527),
					Pos3	=	Vector(-31.760000228882,85.190002441406,27.909999847412),
						},
				HBeamColor	=	{
					r	=	247,
					b	=	190,
					a	=	255,
					g	=	255,
						},
				ReducedVis	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseSprite	=	true,
				LBeamColor	=	{
					r	=	247,
					b	=	190,
					a	=	255,
					g	=	255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	1.4552,
					Brightness	=	1.4552,
						},
				Pos	=	Vector(-25.510000228882,84.559997558594,30.60000038147),
				UsePrjTex	=	true,
				SpecMat	=	{
						},
					},
				},
		Copyright	=	"Copyright © 2012-2018 VCMod (freemmaann). All Rights Reserved.",
		Fuel	=	{
			FuelType	=	0,
			Capacity	=	110,
			Override	=	true,
				},
		Author	=	"𝓒𝓣𝓥𝟏𝟐𝟐𝟓 (76561198051637331)",
}