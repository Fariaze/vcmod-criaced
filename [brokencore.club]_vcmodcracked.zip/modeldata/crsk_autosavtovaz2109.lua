VCModels['models/crsk_autosavtovaz2109.mdl']	=	{
		em_state	=	5236594818,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Copyright	=	"Copyright © 2012-2019 VCMod (freemmaann). All Rights Reserved.",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-24.549999237061,-107.87000274658,14.60000038147),
				EffectStress	=	"VC_Exhaust_Truck",
				EffectIdle	=	"VC_Exhaust_Truck",
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(15,0,0),
				Pos	=	Vector(18.969999313354,7.5999999046326,31.25),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(15,0,0),
				Pos	=	Vector(-21.040000915527,-36.569999694824,31.25),
					},
				{
				Ang	=	Angle(15,0,0),
				Pos	=	Vector(21.040000915527,-36.569999694824,31.25),
					},
				{
				Ang	=	Angle(15,0,0),
				Pos	=	Vector(0,-36.569999694824,31.25),
					},
				},
		DLT	=	3491063212,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-26.110000610352,95.879997253418,32.409999847412),
				UseDynamic	=	true,
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RunningColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(26.75,95.879997253418,32.409999847412),
				UseDynamic	=	true,
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RunningColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.18,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-34.689998626709,-103.79000091553,28.190000534058),
					UseColor	=	true,
					Pos2	=	Vector(-29.64999961853,-104.12999725342,37.380001068115),
					Color	=	{
							150,
							0,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(-34.680000305176,-103.62999725342,37.400001525879),
					Pos3	=	Vector(-29.760000228882,-104.36000061035,28.180000305176),
						},
				UseSprite	=	true,
				Pos	=	Vector(-32.439998626709,-103.09999847412,32.869998931885),
				UseDynamic	=	true,
				UseRunning	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2.1,
						},
				UseDynamic	=	true,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMLine	=	{
					Amount	=	4,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(35.779998779297,92.819999694824,36),
								},
							},
						},
				UseBlinkers	=	true,
				Pos	=	Vector(35.689998626709,95.23999786377,30.030000686646),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2273,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMLine	=	{
					Amount	=	3,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-37.819999694824,-102,29.340000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.459999084473,-101.95999908447,35.709999084473),
								},
							},
						},
				UseBlinkers	=	true,
				Pos	=	Vector(-37.569999694824,-100.63999938965,33.200000762939),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2.1,
						},
				UseDynamic	=	true,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMLine	=	{
					Amount	=	4,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-35.110000610352,93.050003051758,35.560001373291),
								},
							},
						},
				UseBlinkers	=	true,
				Pos	=	Vector(-35.689998626709,95.23999786377,30.030000686646),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseLowBeams	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				HBeamColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseHighBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				UseDynamic	=	true,
				RenderInner	=	true,
				Pos	=	Vector(25.329999923706,95.940002441406,31.459999084473),
				UseSprite	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseLowBeams	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				HBeamColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-25.309999465942,95.940002441406,31.590000152588),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				LBeamColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				UsePrjTex	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.14,
						},
				Dynamic	=	{
					Size	=	0.1119,
					Brightness	=	2.1,
						},
				UseDynamic	=	true,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseBlinkers	=	true,
				Pos	=	Vector(43.790000915527,41.560001373291,31.860000610352),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1364,
						},
				Dynamic	=	{
					Size	=	0.1119,
					Brightness	=	2.1269,
						},
				UseDynamic	=	true,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseBlinkers	=	true,
				Pos	=	Vector(-43.060001373291,41.529998779297,32.069999694824),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.0758,
						},
				Dynamic	=	{
					Size	=	0.3358,
					Brightness	=	1.0821,
						},
				UseDynamic	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-30.020000457764,-104.0299987793,37.040000915527),
					UseColor	=	true,
					Pos2	=	Vector(-21.430000305176,-104.7799987793,32.360000610352),
					Color	=	{
							120,
							0,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(-21.360000610352,-104.7799987793,37.009998321533),
					Pos3	=	Vector(-29.930000305176,-104.09999847412,32.430000305176),
						},
				FogColor	=	{
						255,
						55,
						0,
						},
				UseFog	=	true,
				Pos	=	Vector(-25.409999847412,-104.91000366211,34.549999237061),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2273,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMLine	=	{
					Amount	=	3,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(37.049999237061,-101.56999969482,29.260000228882),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.409999847412,-101.5299987793,35.630001068115),
								},
							},
						},
				UseBlinkers	=	true,
				Pos	=	Vector(37.119998931885,-101.5299987793,32.700000762939),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.18,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(29.270000457764,-104.48000335693,28.319999694824),
					UseColor	=	true,
					Pos2	=	Vector(34.450000762939,-103.38999938965,37.569999694824),
					Color	=	{
							150,
							0,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(29.25,-104.58999633789,37.419998168945),
					Pos3	=	Vector(34.459999084473,-103.76999664307,28.409999847412),
						},
				UseSprite	=	true,
				Pos	=	Vector(32.040000915527,-104.01999664307,32.869998931885),
				UseDynamic	=	true,
				UseRunning	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.0758,
						},
				Dynamic	=	{
					Size	=	0.3358,
					Brightness	=	1.0821,
						},
				UseDynamic	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(21.059999465942,-104.87000274658,37.159999847412),
					UseColor	=	true,
					Pos2	=	Vector(29.469999313354,-104.05999755859,32.389999389648),
					Color	=	{
							120,
							0,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(29.549999237061,-104.08000183105,37.240001678467),
					Pos3	=	Vector(21.209999084473,-104.80000305176,32.330001831055),
						},
				FogColor	=	{
						255,
						55,
						0,
						},
				UseFog	=	true,
				Pos	=	Vector(25.190000534058,-104.79000091553,34.520000457764),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.18,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(16.639999389648,-104.95999908447,28.520000457764),
					UseColor	=	true,
					Pos2	=	Vector(21.379999160767,-104.83000183105,37.419998168945),
					Color	=	{
							180,
							0,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(16.409999847412,-104.83999633789,37.330001831055),
					Pos3	=	Vector(21.329999923706,-104.79000091553,28.520000457764),
						},
				UseSprite	=	true,
				Pos	=	Vector(18.909999847412,-105.04000091553,32.709999084473),
				UseDynamic	=	true,
				UseRunning	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.18,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-21.559999465942,-104.81999969482,28.360000610352),
					UseColor	=	true,
					Pos2	=	Vector(-16.879999160767,-104.86000061035,37.389999389648),
					Color	=	{
							180,
							0,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(-21.790000915527,-104.76000213623,37.520000457764),
					Pos3	=	Vector(-16.870000839233,-104.80000305176,28.25),
						},
				UseSprite	=	true,
				Pos	=	Vector(-19.290000915527,-105.13999938965,32.740001678467),
				UseDynamic	=	true,
				UseRunning	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.0758,
						},
				Dynamic	=	{
					Size	=	0.3358,
					Brightness	=	1.0821,
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-29.860000610352,-103.9700012207,32.599998474121),
					UseColor	=	true,
					Pos2	=	Vector(-21.280000686646,-104.87000274658,28.540000915527),
					Color	=	{
							200,
							225,
							255,
							},
					Use	=	true,
					Pos1	=	Vector(-21.209999084473,-104.86000061035,32.540000915527),
					Pos3	=	Vector(-29.840000152588,-103.98000335693,28.540000915527),
						},
				ReverseColor	=	{
						200,
						225,
						255,
						},
				UseDynamic	=	true,
				Pos	=	Vector(-25.260000228882,-104.69000244141,30.540000915527),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.0758,
						},
				Dynamic	=	{
					Size	=	0.3358,
					Brightness	=	1.0821,
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(21.340000152588,-104.76999664307,32.419998168945),
					UseColor	=	true,
					Pos2	=	Vector(29.319999694824,-104.08000183105,28.629999160767),
					Color	=	{
						r	=	200,
						b	=	255,
						a	=	255,
						g	=	225,
							},
					Use	=	true,
					Pos1	=	Vector(29.340000152588,-104.25,32.459999084473),
					Pos3	=	Vector(21.360000610352,-104.79000091553,28.670000076294),
						},
				UseSprite	=	true,
				Pos	=	Vector(25.219999313354,-104.62999725342,30.479999542236),
				UseDynamic	=	true,
				ReverseColor	=	{
					r	=	200,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
					},
				},
		Date	=	"Mon Feb 18 11:22:01 2019",
		Fuel	=	{
			FuelLidPos	=	Vector(40.5,-95.48999786377,32.549999237061),
			FuelType	=	0,
			Capacity	=	43,
			Override	=	true,
			FuelLidUse	=	true,
				},
		Author	=	"DangerKiddy(DK) (76561198132964487)",
}