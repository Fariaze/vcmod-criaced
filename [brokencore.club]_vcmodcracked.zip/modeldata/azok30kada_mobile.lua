VCModels['models/azok30kada_mobile.mdl']	=	{
		em_state	=	5236594707,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Date	=	"Wed Apr 17 21:04:42 2019",
		hornData	=	{
			Volume	=	1,
			Distance	=	75,
			Pitch	=	100,
			Sound	=	"vcmod/horn/general_lee.wav",
				},
		hornUseCustom	=	true,
		ExtraSeats	=	{
				{
				Pos	=	Vector(10.5,1,32.5),
					},
				{
				Pos	=	Vector(0,62.159999847412,29.120000839233),
					},
				},
		DLT	=	3491063138,
		Copyright	=	"Copyright © 2012-2019 VCMod (freemmaann). All Rights Reserved.",
		Author	=	"Azok30 - SWEETRP.FR (76561198183398967)",
}