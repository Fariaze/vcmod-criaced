VCModels['models/carma1carma1_new.mdl']	=	{
		em_state	=	5236594332,
		Copyright	=	"Copyright © 2012-2018 VCMod (freemmaann). All Rights Reserved.",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(0,-18.479999542236,67.98999786377),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		forcedTP	=	true,
		DLT	=	3491062888,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(40.509998321533,97.319999694824,25.35000038147),
					Pos2	=	Vector(25.629999160767,91.559997558594,28.940000534058),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(41.180000305176,91.550003051758,28.89999961853),
					Pos3	=	Vector(25.459999084473,97.410003662109,25.309999465942),
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(32.680000305176,94.660003662109,27.020000457764),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseRunning	=	true,
				Beta_Inner3D	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderHD_Adv	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-40.240001678467,97.029998779297,25.569999694824),
					Pos2	=	Vector(-25.360000610352,91.269996643066,29.159999847412),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-40.909999847412,91.26000213623,29.120000839233),
					Pos3	=	Vector(-25.190000534058,97.120002746582,25.530000686646),
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-32.409999847412,94.370002746582,27.239999771118),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				UseRunning	=	true,
				RenderHD_Adv	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-11.789999961853,103.66999816895,15.729999542236),
					Pos2	=	Vector(-22.239999771118,105.37000274658,19.559999465942),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-11.810000419617,105.25,19.319999694824),
					Pos3	=	Vector(-22.14999961853,103.69999694824,15.720000267029),
						},
				FogColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-17.040000915527,105.05999755859,17.340000152588),
				UseDynamic	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseFog	=	true,
				UseSprite	=	true,
				UsePrjTex	=	true,
				RenderHD_Adv	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(11.789999961853,103.66999816895,15.729999542236),
					Pos2	=	Vector(22.239999771118,105.37000274658,19.559999465942),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(11.810000419617,105.25,19.319999694824),
					Pos3	=	Vector(22.14999961853,103.69999694824,15.720000267029),
						},
				FogColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				SpecMat	=	{
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UsePrjTex	=	true,
				Pos	=	Vector(17.040000915527,105.05999755859,17.340000152588),
				UseDynamic	=	true,
				UseSprite	=	true,
				UseFog	=	true,
				Beta_Inner3D	=	true,
				RenderHD_Adv	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.32,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(29.010000228882,-99.180000305176,32.759998321533),
					Pos2	=	Vector(21.280000686646,-99.349998474121,38.319999694824),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(28.930000305176,-99.180000305176,38.319999694824),
					Pos3	=	Vector(21.420000076294,-99.330001831055,32.759998321533),
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(25.120000839233,-99.180000305176,35.540000915527),
				UseDynamic	=	true,
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
				RenderHD_Adv	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.32,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-28.940000534058,-99.180000305176,32.990001678467),
					Pos2	=	Vector(-21.610000610352,-99.349998474121,38.310001373291),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-28.860000610352,-99.180000305176,38.310001373291),
					Pos3	=	Vector(-21.75,-99.330001831055,32.990001678467),
						},
				SpecMat	=	{
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-25.25,-99.180000305176,35.650001525879),
				UseDynamic	=	true,
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RenderHD_Adv	=	true,
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(36.119998931885,-98.75,32.759998321533),
					Pos2	=	Vector(29.170000076294,-98.959999084473,38.319999694824),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(36.169998168945,-98.620002746582,38.319999694824),
					Pos3	=	Vector(29.270000457764,-99.080001831055,32.759998321533),
						},
				SpecMat	=	{
						},
				RenderHD_Adv	=	true,
				UseRunning	=	true,
				UseSprite	=	true,
				Pos	=	Vector(32.790000915527,-98.620002746582,35.540000915527),
				UseDynamic	=	true,
				Beta_Inner3D	=	true,
				UseBrake	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.32,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(43.380001068115,-98.26000213623,32.759998321533),
					Pos2	=	Vector(36.340000152588,-98.569999694824,38.389999389648),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(43.259998321533,-98.099998474121,38.430000305176),
					Pos3	=	Vector(36.310001373291,-98.769996643066,32.759998321533),
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(40.049999237061,-98.099998474121,35.540000915527),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				RenderHD_Adv	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-43.380001068115,-98.26000213623,32.759998321533),
					Pos2	=	Vector(-36.340000152588,-98.569999694824,38.389999389648),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-43.259998321533,-98.099998474121,38.430000305176),
					Pos3	=	Vector(-36.310001373291,-98.769996643066,32.759998321533),
						},
				SpecMat	=	{
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-40.049999237061,-98.099998474121,35.540000915527),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				RenderHD_Adv	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-36.119998931885,-98.75,32.759998321533),
					Pos2	=	Vector(-29.170000076294,-98.959999084473,38.319999694824),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-36.169998168945,-98.620002746582,38.319999694824),
					Pos3	=	Vector(-29.270000457764,-99.080001831055,32.759998321533),
						},
				SpecMat	=	{
						},
				UseRunning	=	true,
				UseBrake	=	true,
				RenderHD_Adv	=	true,
				Pos	=	Vector(-32.790000915527,-98.620002746582,35.540000915527),
				UseDynamic	=	true,
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(31.610000610352,93.930000305176,27.75),
				UseDynamic	=	true,
				UseSprite	=	true,
				RenderHD_Adv	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseBlinkers	=	true,
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-31.610000610352,93.930000305176,27.75),
				UseDynamic	=	true,
				UseSprite	=	true,
				RenderHD_Adv	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseBlinkers	=	true,
				UseBrake	=	true,
					},
				},
		Date	=	"Mon Jul 23 16:26:44 2018",
		Fuel	=	{
			FuelType	=	0,
			FuelLidUse	=	true,
			FuelLidPos	=	Vector(41.479999542236,-21.870000839233,30),
				},
		Author	=	"TheCarson116 (76561198123551419)",
}