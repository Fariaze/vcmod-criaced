VCModels['models/amgeneralhummerh2update.mdl']	=	{
		em_state	=	5236594599,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Copyright	=	"Copyright © 2012-2018 VCMod (freemmaann). All Rights Reserved.",
		Exhaust	=	{
				{
				Ang	=	Angle(45,-90,0),
				Pos	=	Vector(13.439999580383,-77.709999084473,25.979999542236),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Pos	=	Vector(21.140899658203,23.717800140381,51.512798309326),
				DoorSounds	=	true,
				Ang	=	Angle(0,0,0),
				EnterRange	=	80,
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(-24.39999961853,-14,51.509998321533),
				EnterRange	=	80,
				DoorSounds	=	true,
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(21.139999389648,-14,51.509998321533),
				EnterRange	=	80,
				DoorSounds	=	true,
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(-2.7699999809265,-14,51.509998321533),
				EnterRange	=	80,
				DoorSounds	=	true,
					},
				},
		DLT	=	3491063066,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-41.630001068115,-93.430000305176,54.939998626709),
					Use	=	true,
					Pos2	=	Vector(-34.840000152588,-93.720001220703,62.139999389648),
					Color	=	{
						r	=	233,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					UseColor	=	true,
					Pos1	=	Vector(-41.630001068115,-93.080001831055,62.139999389648),
					Pos3	=	Vector(-34.939998626709,-94.019996643066,54.939998626709),
						},
				SpecMat	=	{
					New	=	"models\amgeneral\h2 b\h2_lights_lit",
					Select	=	1,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-38.310001373291,-93.319999694824,58.5),
				UseDynamic	=	true,
				UseRunning	=	true,
				UseBrake	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
					},
				{
				Sprite	=	{
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-13.920000076294,-91.269996643066,85.099998474121),
				UseDynamic	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.2,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(0,-91.599998474121,85.099998474121),
				UseDynamic	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.2,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					Size	=	0.15,
						},
				UseBrake	=	true,
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-7.3000001907349,-87.849998474121,89.360000610352),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	8,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(7.3000001907349,-87.849998474121,89.360000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-37.380001068115,45,88.400001525879),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.3,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-15.439999580383,48.939998626709,88.410003662109),
				UseDynamic	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.2,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(0,49.610000610352,88.410003662109),
				UseDynamic	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.2,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				HBeamColor	=	{
					r	=	230,
					b	=	255,
					a	=	255,
					g	=	228,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	1.3,
						},
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	168,
					b	=	168,
					a	=	255,
					g	=	168,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				UseSprite	=	true,
				ProjTexture	=	{
					Size	=	2024,
					Angle	=	Angle(0,90,0),
						},
				Pos	=	Vector(-25.739999771118,114.76999664307,50.340000152588),
				SpecMat	=	{
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-28.139999389648,119.23000335693,38.209999084473),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	253,
					b	=	186,
					a	=	255,
					g	=	238,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
					},
				{
				UseBlinkers	=	true,
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.3,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-45.880001068115,103.83999633789,52.810001373291),
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.1,
						},
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	2,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-46.009998321533,102.62000274658,52.779998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Size	=	0.75,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(13.470000267029,-91.269996643066,85.099998474121),
				UseDynamic	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.2,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(36.639999389648,-83.620002746582,90.180000305176),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Brightness	=	3.5448,
					Size	=	0.3,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(37.380001068115,45,88.400001525879),
				UseDynamic	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.3,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(15.439999580383,48.939998626709,88.410003662109),
				UseDynamic	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.2,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				HBeamColor	=	{
					r	=	168,
					b	=	168,
					a	=	255,
					g	=	168,
						},
				SpecMat	=	{
						},
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	168,
					b	=	168,
					a	=	255,
					g	=	168,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Pos	=	Vector(26.120000839233,114.76999664307,50.340000152588),
				Dynamic	=	{
					Brightness	=	2,
					Size	=	1.3,
						},
				UseSprite	=	true,
				ProjTexture	=	{
					Size	=	2024,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				UseBlinkers	=	true,
				SpecSpin	=	{
						},
				DD_HD	=	true,
				UseDynamic	=	true,
				DD_Main	=	true,
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.6,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/rectangle_rounded_2x8",
					Pos4	=	Vector(37.330001831055,115.94999694824,47.470001220703),
					Pos2	=	Vector(43.080001831055,113.33999633789,52.540000915527),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(37.439998626709,115.37999725342,52.729999542236),
					Pos3	=	Vector(43.159999847412,114,47.560001373291),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.6,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(39.759998321533,114.33000183105,50.25),
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_Size	=	1.2,
				RenderInner	=	true,
				UseSprite	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(28.139999389648,119.23000335693,38.209999084473),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	253,
					b	=	186,
					a	=	255,
					g	=	238,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
					},
				{
				UseBlinkers	=	true,
				SpecSpin	=	{
						},
				DD_HD	=	true,
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.6,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.6,
						},
				UseSprite	=	true,
				Pos	=	Vector(-39.470001220703,114.5,50.25),
				DD_Main	=	true,
				RenderInner	=	true,
				RenderInner_Size	=	1.2,
				Beta_Inner3D	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/rectangle_rounded_2x8",
					Pos4	=	Vector(-36.880001068115,116.12000274658,47.470001220703),
					Pos2	=	Vector(-42.790000915527,113.51000213623,52.540000915527),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-37.020000457764,115.30999755859,52.729999542236),
					Pos3	=	Vector(-42.869998931885,114.26999664307,47.459999084473),
						},
					},
				{
				UseBlinkers	=	true,
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.3,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(45.959999084473,-81.290000915527,59.029998779297),
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.1,
						},
				RenderInner_Size	=	0.75,
				SpecMLine	=	{
					Amount	=	2,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(45.970001220703,-82.51000213623,59),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(41.630001068115,-93.430000305176,54.939998626709),
					Use	=	true,
					Pos2	=	Vector(34.840000152588,-93.720001220703,62.139999389648),
					Color	=	{
						r	=	233,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					UseColor	=	true,
					Pos1	=	Vector(41.630001068115,-93.080001831055,62.139999389648),
					Pos3	=	Vector(34.939998626709,-94.019996643066,54.939998626709),
						},
				SpecMat	=	{
					New	=	"models\amgeneral\h2 b\h2_lights_lit",
					Select	=	1,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(38.310001373291,-93.319999694824,58.5),
				UseDynamic	=	true,
				UseRunning	=	true,
				UseBrake	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-37.139999389648,-83.620002746582,90.180000305176),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Brightness	=	3.5448,
					Size	=	0.3,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.5,
						},
				SpecSpin	=	{
						},
				DD_HD	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-6.7199997901917,124.93000030518,45.209999084473),
					Pos2	=	Vector(-15.640000343323,124.93000030518,54.590000152588),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-6.7199997901917,124.93000030518,54.590000152588),
					Pos3	=	Vector(-15.640000343323,124.93000030518,45.470001220703),
						},
				SpecMat	=	{
						},
				BGroups	=	{
					[2]	=	{
						[2]	=	"Brushguard2",
							},
						},
				UseSprite	=	true,
				Pos	=	Vector(-11.510000228882,124.98999786377,50.340000152588),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	175,
					b	=	175,
					a	=	255,
					g	=	175,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.6,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.5,
						},
				SpecSpin	=	{
						},
				DD_HD	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(15.939999580383,124.93000030518,45.209999084473),
					Pos2	=	Vector(7.0199999809265,124.93000030518,54.590000152588),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(15.939999580383,124.93000030518,54.590000152588),
					Pos3	=	Vector(7.0199999809265,124.93000030518,45.470001220703),
						},
				SpecMat	=	{
						},
				BGroups	=	{
					[2]	=	{
						[2]	=	"Brushguard2",
							},
						},
				UseSprite	=	true,
				Pos	=	Vector(11.14999961853,124.98999786377,50.340000152588),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	175,
					b	=	175,
					a	=	255,
					g	=	175,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.6,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.5,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(15.159999847412,36.990001678467,93.889999389648),
					Pos2	=	Vector(6.2399997711182,36.990001678467,103.26999664307),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(15.159999847412,36.990001678467,103.26999664307),
					Pos3	=	Vector(6.2399997711182,36.990001678467,94.150001525879),
						},
				SpecMat	=	{
						},
				BGroups	=	{
					[3]	=	{
						[3]	=	"Light rack",
						[4]	=	"Light rack black",
							},
						},
				UseSprite	=	true,
				Pos	=	Vector(10.590000152588,37.049999237061,99.019996643066),
				UseDynamic	=	true,
				Beta_Inner3D	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	175,
					b	=	175,
					a	=	255,
					g	=	175,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.6,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.5,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(36.009998321533,36.990001678467,93.889999389648),
					Pos2	=	Vector(27.090000152588,36.990001678467,103.26999664307),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(36.009998321533,36.990001678467,103.26999664307),
					Pos3	=	Vector(27.090000152588,36.990001678467,94.150001525879),
						},
				SpecMat	=	{
						},
				BGroups	=	{
					[3]	=	{
						[4]	=	"Light rack black",
						[3]	=	"Light rack",
							},
						},
				UseSprite	=	true,
				Pos	=	Vector(31.409999847412,37.049999237061,99.019996643066),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	175,
					b	=	175,
					a	=	255,
					g	=	175,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.6,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.5,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-6.4099998474121,37.060001373291,93.889999389648),
					Pos2	=	Vector(-15.329999923706,37.060001373291,103.26999664307),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-6.4099998474121,37.060001373291,103.26999664307),
					Pos3	=	Vector(-15.329999923706,37.060001373291,94.150001525879),
						},
				SpecMat	=	{
						},
				BGroups	=	{
					[3]	=	{
						[3]	=	"Light rack",
						[4]	=	"Light rack black",
							},
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-11,37.119998931885,99.019996643066),
				UseDynamic	=	true,
				UseSprite	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	175,
					b	=	175,
					a	=	255,
					g	=	175,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.6,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.5,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-27.239999771118,37.090000152588,93.889999389648),
					Pos2	=	Vector(-36.159999847412,37.090000152588,103.26999664307),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-27.239999771118,37.090000152588,103.26999664307),
					Pos3	=	Vector(-36.159999847412,37.090000152588,94.150001525879),
						},
				SpecMat	=	{
						},
				BGroups	=	{
					[3]	=	{
						[4]	=	"Light rack black",
						[3]	=	"Light rack",
							},
						},
				UseSprite	=	true,
				Pos	=	Vector(-31.719999313354,37.150001525879,99.019996643066),
				UseDynamic	=	true,
				Beta_Inner3D	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	175,
					b	=	175,
					a	=	255,
					g	=	175,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.6,
						},
					},
				{
				UseBlinkers	=	true,
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.3,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecMat	=	{
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-46.099998474121,-81.290000915527,58.799999237061),
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.1,
						},
				RenderInner_Size	=	0.75,
				SpecMLine	=	{
					Amount	=	2,
					Use	=	true,
					LTbl	=	{
							{
							Clr	=	{
								r	=	255,
								b	=	0,
								a	=	255,
								g	=	55,
									},
							Pos	=	Vector(-46.110000610352,-82.51000213623,58.770000457764),
							Size	=	0.1,
							UseClr	=	false,
								},
							},
						},
				RenderInner	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseSprite	=	true,
					},
				{
				UseBlinkers	=	true,
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.3,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(46.220001220703,103.44000244141,52.810001373291),
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.1,
						},
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	2,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(46.229999542236,102.2200012207,52.779998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Size	=	0.75,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(41.630001068115,-93.669998168945,49.880001068115),
					Pos2	=	Vector(34.939998626709,-93.959999084473,55.700000762939),
					Color	=	{
						r	=	233,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(41.630001068115,-93.349998474121,55.700000762939),
					Pos3	=	Vector(34.939998626709,-94.230003356934,49.880001068115),
						},
				SpecMat	=	{
					New	=	"models\amgeneral\h2 b\h2_lights_lit",
					Select	=	1,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(38.169998168945,-93.559997558594,52.439998626709),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Beta_Inner3D	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-41.630001068115,-93.669998168945,49.880001068115),
					Pos2	=	Vector(-34.939998626709,-93.959999084473,55.700000762939),
					Color	=	{
						r	=	233,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-41.630001068115,-93.349998474121,55.700000762939),
					Pos3	=	Vector(-34.939998626709,-94.230003356934,49.880001068115),
						},
				SpecMat	=	{
					New	=	"models\amgeneral\h2 b\h2_lights_lit",
					Select	=	1,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-38.169998168945,-93.559997558594,52.439998626709),
				UseDynamic	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				Beta_Inner3D	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-41.669998168945,-93.550003051758,44.779998779297),
					Pos2	=	Vector(-35.529998779297,-94.089996337891,50.180000305176),
					Color	=	{
						r	=	233,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-41.669998168945,-93.389999389648,50.180000305176),
					Pos3	=	Vector(-35.529998779297,-94.220001220703,44.779998779297),
						},
				SpecMat	=	{
					New	=	"models\amgeneral\h2 b\h2_lights_lit",
					Select	=	1,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-38.209999084473,-93.599998474121,46.919998168945),
				UseDynamic	=	true,
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(41.380001068115,-93.680000305176,44.779998779297),
					Pos2	=	Vector(35.240001678467,-94.220001220703,50.180000305176),
					Color	=	{
						r	=	233,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(41.380001068115,-93.519996643066,50.180000305176),
					Pos3	=	Vector(35.240001678467,-94.349998474121,44.779998779297),
						},
				SpecMat	=	{
					New	=	"models\amgeneral\h2 b\h2_lights_lit",
					Select	=	1,
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(37.919998168945,-93.730003356934,46.919998168945),
				UseDynamic	=	true,
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseSprite	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
					},
				},
		Date	=	"Thu Feb  8 15:44:14 2018",
		Fuel	=	{
			FuelLidPos	=	Vector(-45.950000762939,-81.669998168945,48.849998474121),
			FuelLidUse	=	true,
			FuelType	=	0,
				},
		Author	=	"Talon 733 (76561197971625504)",
}