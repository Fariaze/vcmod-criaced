VCModels['models/crsk_autosfordgrantorino_1972.mdl']	=	{
		em_state	=	5236594707,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Date	=	"Mon Nov  5 10:00:54 2018",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(31.219999313354,-128.97999572754,14.659999847412),
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(-31.219999313354,-128.97999572754,14.659999847412),
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(20,0,0),
				Pos	=	Vector(18.590000152588,3.8399999141693,30.229999542236),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(20,0,0),
				Pos	=	Vector(-18.590000152588,-39.959999084473,30.229999542236),
					},
				{
				Ang	=	Angle(20,0,0),
				Pos	=	Vector(18.590000152588,-39.959999084473,30.229999542236),
					},
				{
				Ang	=	Angle(20,0,0),
				Pos	=	Vector(0,-39.959999084473,30.229999542236),
					},
				},
		DLT	=	3491063138,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.7927,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Use	=	true,
					Pos2	=	Vector(31.389999389648,108.73999786377,36.229999542236),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Pos4	=	Vector(39.25,108.73999786377,28.469999313354),
					Pos1	=	Vector(39.409999847412,108.5,36.029998779297),
					Pos3	=	Vector(31.680000305176,108.93000030518,28.340000152588),
						},
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				UseSprite	=	true,
				Pos	=	Vector(35.470001220703,108.73999786377,32.369998931885),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderInner_Size	=	1.576,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(34.740001678467,107.59999847412,21.559999465942),
					Pos2	=	Vector(26.920000076294,108.98999786377,24.489999771118),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(34.930000305176,108.80999755859,24.520000457764),
					Pos3	=	Vector(27.200000762939,107.84999847412,21.549999237061),
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(30.909999847412,108.94999694824,22.85000038147),
				UseDynamic	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				BlinkerRight	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(44.880001068115,96.459999084473,30.379999160767),
				UseDynamic	=	true,
				BlinkerRight	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(45.069999694824,92.879997253418,31.379999160767),
					Pos2	=	Vector(44.810001373291,100.2799987793,29.489999771118),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(44.959999084473,92.98999786377,29.530000686646),
					Pos3	=	Vector(44.810001373291,100.29000091553,31.379999160767),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(28.430000305176,-136.08000183105,33.279998779297),
					Pos2	=	Vector(26.430000305176,-136.08000183105,35.279998779297),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(28.430000305176,-136.08000183105,35.279998779297),
					Pos3	=	Vector(26.430000305176,-136.08000183105,33.279998779297),
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(27.430000305176,-136.08000183105,34.279998779297),
				UseDynamic	=	true,
				ReverseColor	=	{
					r	=	255,
					b	=	220,
					a	=	255,
					g	=	225,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(37.569999694824,-135.86000061035,32.5),
					Pos2	=	Vector(29.379999160767,-135.86000061035,35.900001525879),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(37.569999694824,-135.86000061035,36.060001373291),
					Pos3	=	Vector(29.319999694824,-136.08999633789,32.520000457764),
						},
				SpecMat	=	{
						},
				UseRunning	=	true,
				UseSprite	=	true,
				Pos	=	Vector(36.569999694824,-135.86000061035,34.189998626709),
				UseDynamic	=	true,
				UseBrake	=	true,
				SpecMLine	=	{
					Amount	=	18,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(30.309999465942,-136.33999633789,34.240001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	100,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(39.090000152588,-135.58999633789,34.080001831055),
				UseDynamic	=	true,
				BlinkerRight	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(41.369998931885,-135.58999633789,32.939998626709),
					Pos2	=	Vector(37.040000915527,-135.60000610352,35.939998626709),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(41.409999847412,-135.44999694824,36.830001831055),
					Pos3	=	Vector(37.130001068115,-135.67999267578,31.219999313354),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	100,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(45.740001678467,-124.44999694824,32.450000762939),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				BlinkerRight	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(45.459999084473,-128.08000183105,31.450000762939),
					Pos2	=	Vector(45.740001678467,-120.62000274658,33.450000762939),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(45.740001678467,-128.13999938965,33.450000762939),
					Pos3	=	Vector(45.740001678467,-120.69000244141,31.450000762939),
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Use	=	true,
					Pos2	=	Vector(22.340000152588,108.73999786377,36.229999542236),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Pos4	=	Vector(30.200000762939,108.73999786377,28.469999313354),
					Pos1	=	Vector(30.360000610352,108.5,36.029998779297),
					Pos3	=	Vector(22.629999160767,108.93000030518,28.340000152588),
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(26.420000076294,108.73999786377,32.369998931885),
				RenderInner_Size	=	1.576,
				HBeamColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				RenderInner	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Use	=	true,
					Pos2	=	Vector(-21.690000534058,108.73999786377,36.229999542236),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Pos4	=	Vector(-29.549999237061,108.73999786377,28.469999313354),
					Pos1	=	Vector(-29.709999084473,108.5,36.029998779297),
					Pos3	=	Vector(-21.979999542236,108.93000030518,28.340000152588),
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-25.770000457764,108.73999786377,32.369998931885),
				RenderInner_Size	=	1.576,
				HBeamColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				RenderInner	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.7927,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Use	=	true,
					Pos2	=	Vector(-30.780000686646,108.73999786377,36.229999542236),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Pos4	=	Vector(-38.639999389648,108.73999786377,28.469999313354),
					Pos1	=	Vector(-38.799999237061,108.5,36.029998779297),
					Pos3	=	Vector(-31.069999694824,108.93000030518,28.340000152588),
						},
				SpecMat	=	{
						},
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				UseSprite	=	true,
				Pos	=	Vector(-34.860000610352,108.73999786377,32.369998931885),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderInner_Size	=	1.576,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				BlinkerLeft	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-30.430000305176,109.08999633789,22.959999084473),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-34.330001831055,107.83999633789,21.670000076294),
					Pos2	=	Vector(-26.370000839233,109.0299987793,24.60000038147),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-34.380001068115,109.05000305176,24.629999160767),
					Pos3	=	Vector(-26.790000915527,107.88999938965,21.659999847412),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				BlinkerLeft	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-44.240001678467,96.459999084473,30.379999160767),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-44.549999237061,92.879997253418,31.379999160767),
					Pos2	=	Vector(-44.049999237061,100.2799987793,29.489999771118),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-44.439998626709,92.98999786377,29.530000686646),
					Pos3	=	Vector(-44.049999237061,100.29000091553,31.379999160767),
						},
				SpecMat	=	{
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	100,
						},
				BlinkerLeft	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-45.740001678467,-124.44999694824,32.450000762939),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-45.459999084473,-128.08000183105,31.450000762939),
					Pos2	=	Vector(-46.159999847412,-120.62000274658,33.450000762939),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-45.740001678467,-128.13999938965,33.450000762939),
					Pos3	=	Vector(-45.860000610352,-120.69000244141,31.450000762939),
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-37.569999694824,-135.86000061035,32.5),
					Pos2	=	Vector(-29.379999160767,-135.86000061035,35.900001525879),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-37.569999694824,-135.86000061035,36.060001373291),
					Pos3	=	Vector(-29.319999694824,-136.08999633789,32.520000457764),
						},
				SpecMat	=	{
						},
				UseBrake	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-36.569999694824,-135.86000061035,34.189998626709),
				UseDynamic	=	true,
				UseRunning	=	true,
				SpecMLine	=	{
					Amount	=	18,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-30.309999465942,-136.33999633789,34.240001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-41.720001220703,-135.58999633789,32.939998626709),
					Pos2	=	Vector(-37.389999389648,-135.60000610352,35.939998626709),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-41.880001068115,-135.44999694824,37.139999389648),
					Pos3	=	Vector(-37.479999542236,-135.67999267578,31.219999313354),
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-39.439998626709,-135.58999633789,34.080001831055),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	100,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				BlinkerLeft	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-28.430000305176,-136.08000183105,33.279998779297),
					Pos2	=	Vector(-26.430000305176,-136.08000183105,35.279998779297),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-28.430000305176,-136.08000183105,35.279998779297),
					Pos3	=	Vector(-26.430000305176,-136.08000183105,33.279998779297),
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-27.430000305176,-136.08000183105,34.279998779297),
				UseDynamic	=	true,
				ReverseColor	=	{
					r	=	255,
					b	=	220,
					a	=	255,
					g	=	225,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				},
		Copyright	=	"Copyright © 2012-2018 VCMod (freemmaann). All Rights Reserved.",
		Fuel	=	{
			FuelLidPos	=	Vector(0,0,0),
			Capacity	=	87,
			Override	=	true,
			FuelType	=	0,
				},
		Author	=	"DangerKiddy(DK) (76561198132964487)",
}