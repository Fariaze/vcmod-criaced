VCModels['models/crsk_autoscadillacfleetwood_brougham_1985.mdl']	=	{
		em_state	=	5236594728,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Copyright	=	"Copyright © 2012-2018 VCMod (freemmaann). All Rights Reserved.",
		Exhaust	=	{
				{
				Ang	=	Angle(61,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(24.690000534058,-157.00999450684,15.739999771118),
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(61,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(-24.690000534058,-157.00999450684,15.739999771118),
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(25,0,0),
				Pos	=	Vector(20.299999237061,-3.7400000095367,33.990001678467),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(25,0,0),
				Pos	=	Vector(-20.299999237061,-51.860000610352,36.540000915527),
					},
				{
				Ang	=	Angle(25,0,0),
				Pos	=	Vector(20.299999237061,-51.860000610352,36.540000915527),
					},
				{
				Ang	=	Angle(25,0,0),
				Pos	=	Vector(0,-51.860000610352,36.540000915527),
					},
				},
		DLT	=	3491063152,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.12,
						},
				SpecSpin	=	{
						},
				UseSprite	=	true,
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Pos4	=	Vector(-43.110000610352,105.31999969482,30.090000152588),
					AmountV	=	4,
					Pos2	=	Vector(-42.919998168945,105.31999969482,32.900001525879),
					AmountH	=	3,
					Use	=	true,
					Pos1	=	Vector(-24.579999923706,105.31999969482,32.979999542236),
					Pos3	=	Vector(-28.25,105.31999969482,30.010000228882),
						},
				RunningColor	=	{
						255,
						255,
						175,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-23.329999923706,105.25,30.569999694824),
					UseColor	=	true,
					Pos2	=	Vector(-43.400001525879,104.58000183105,33.060001373291),
					Color	=	{
							255,
							255,
							175,
							},
					Use	=	true,
					Pos1	=	Vector(-23.309999465942,105.26000213623,32.990001678467),
					Pos3	=	Vector(-43.439998626709,104.51999664307,30.590000152588),
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-33.529998779297,105.31999969482,31.620000839233),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
						255,
						225,
						200,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.12,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Pos4	=	Vector(8.8800001144409,-156.35000610352,33),
					AmountV	=	4,
					Pos2	=	Vector(13.310000419617,-156.35000610352,40.700000762939),
					AmountH	=	3,
					Use	=	true,
					Pos1	=	Vector(8.9799995422363,-156.35000610352,40.610000610352),
					Pos3	=	Vector(13.140000343323,-156.35000610352,33.209999084473),
						},
				Beta_Inner3D	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(8.3500003814697,-156.36999511719,32.419998168945),
					UseColor	=	true,
					Pos2	=	Vector(12.960000038147,-155.69000244141,41.630001068115),
					Color	=	{
							225,
							225,
							255,
							},
					Use	=	true,
					Pos1	=	Vector(8.3199996948242,-155.86999511719,41.580001831055),
					Pos3	=	Vector(13.130000114441,-156.44000244141,32.369998931885),
						},
				UseSprite	=	true,
				Pos	=	Vector(10.689999580383,-156.35000610352,37.040000915527),
				UseDynamic	=	true,
				RenderInner	=	true,
				ReverseColor	=	{
						225,
						225,
						255,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
						255,
						225,
						200,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.42,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(45.080001831055,102.15000152588,36.840000152588),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-23.690000534058,104.76999664307,33.119998931885),
					UseColor	=	true,
					Pos2	=	Vector(-33.959999084473,104.41000366211,40.229999542236),
					Color	=	{
						r	=	225,
						b	=	155,
						a	=	255,
						g	=	225,
							},
					Use	=	true,
					Pos1	=	Vector(-23.579999923706,104.83999633789,40.189998626709),
					Pos3	=	Vector(-34,104.34999847412,33.349998474121),
						},
				SpecMat	=	{
						},
				HBeamColor	=	{
					r	=	255,
					b	=	155,
					a	=	255,
					g	=	225,
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-28.979999542236,105.37999725342,36.709999084473),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.31,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						255,
						225,
						200,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.4851,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						100,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(41.959999084473,-159.97999572754,42.520000457764),
				UseBrake	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(41.869998931885,-161.38000488281,28.729999542236),
								},
							},
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.31,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						255,
						225,
						200,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.4851,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						100,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-42.419998168945,-159.97999572754,42.520000457764),
				UseBrake	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-42.330001831055,-161.38000488281,28.729999542236),
								},
							},
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.12,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Pos4	=	Vector(-9.4499998092651,-156.35000610352,33),
					AmountV	=	4,
					Pos2	=	Vector(-13.880000114441,-156.35000610352,40.700000762939),
					AmountH	=	3,
					Use	=	true,
					Pos1	=	Vector(-9.5500001907349,-156.35000610352,40.610000610352),
					Pos3	=	Vector(-13.710000038147,-156.35000610352,33.209999084473),
						},
				Beta_Inner3D	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-8.9200000762939,-156.36999511719,32.419998168945),
					UseColor	=	true,
					Pos2	=	Vector(-13.529999732971,-155.69000244141,41.630001068115),
					Color	=	{
							225,
							225,
							255,
							},
					Use	=	true,
					Pos1	=	Vector(-8.8900003433228,-155.86999511719,41.580001831055),
					Pos3	=	Vector(-13.699999809265,-156.44000244141,32.369998931885),
						},
				UseSprite	=	true,
				Pos	=	Vector(-11.260000228882,-156.35000610352,37.040000915527),
				UseDynamic	=	true,
				RenderInner	=	true,
				ReverseColor	=	{
						225,
						225,
						255,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
						255,
						225,
						200,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(24.229999542236,104.76999664307,33.119998931885),
					UseColor	=	true,
					Pos2	=	Vector(34.5,104.23000335693,40.229999542236),
					Color	=	{
						r	=	225,
						b	=	155,
						a	=	255,
						g	=	225,
							},
					Use	=	true,
					Pos1	=	Vector(24.120000839233,104.83999633789,40.189998626709),
					Pos3	=	Vector(34.540000915527,104.16000366211,33.349998474121),
						},
				HBeamColor	=	{
					r	=	255,
					b	=	155,
					a	=	255,
					g	=	225,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				UseSprite	=	true,
				Pos	=	Vector(29.25,105.37999725342,36.779998779297),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
						255,
						225,
						155,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-32.930000305176,104.38999938965,33.299999237061),
					UseColor	=	true,
					Pos2	=	Vector(-43.200000762939,104.09999847412,40.409999847412),
					Color	=	{
							225,
							225,
							155,
							},
					Use	=	true,
					Pos1	=	Vector(-32.819999694824,104.5,40.369998931885),
					Pos3	=	Vector(-43.240001678467,104.04000091553,33.529998779297),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-38.220001220703,105.06999969482,36.889999389648),
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				HBeamColor	=	{
						255,
						225,
						155,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
						255,
						225,
						155,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(33.75,104.12000274658,33.209999084473),
					UseColor	=	true,
					Pos2	=	Vector(44.020000457764,103.91999816895,40.319999694824),
					Color	=	{
							225,
							225,
							155,
							},
					Use	=	true,
					Pos1	=	Vector(33.639999389648,104.44000244141,40.279998779297),
					Pos3	=	Vector(44.060001373291,103.84999847412,33.439998626709),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(38.770000457764,105.06999969482,36.869998931885),
				RenderInner	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				HBeamColor	=	{
						255,
						225,
						155,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.12,
						},
				SpecSpin	=	{
						},
				UseSprite	=	true,
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Pos4	=	Vector(43.560001373291,105.12999725342,30.090000152588),
					AmountV	=	4,
					Pos2	=	Vector(43.369998931885,105.12999725342,32.900001525879),
					AmountH	=	3,
					Use	=	true,
					Pos1	=	Vector(25.030000686646,105.12999725342,32.979999542236),
					Pos3	=	Vector(28.700000762939,105.12999725342,30.010000228882),
						},
				RunningColor	=	{
						255,
						255,
						175,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(23.780000686646,105.19000244141,30.569999694824),
					UseColor	=	true,
					Pos2	=	Vector(43.849998474121,104.38999938965,33.060001373291),
					Color	=	{
							255,
							255,
							175,
							},
					Use	=	true,
					Pos1	=	Vector(23.760000228882,105.13999938965,32.990001678467),
					Pos3	=	Vector(43.889999389648,104.33000183105,30.590000152588),
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(34.369998931885,105.12999725342,31.620000839233),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
						255,
						225,
						200,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.42,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-44.040000915527,102.15000152588,36.840000152588),
				UseDynamic	=	true,
				UseSprite	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.42,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(45.279998779297,101.55000305176,31.940000534058),
				UseDynamic	=	true,
				UseRunning	=	true,
				Beta_Inner3D	=	true,
				RunningColor	=	{
						255,
						225,
						175,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.42,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-44.520000457764,101.55000305176,31.940000534058),
				UseDynamic	=	true,
				UseRunning	=	true,
				Beta_Inner3D	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	175,
					a	=	255,
					g	=	225,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
					},
				},
		Date	=	"Wed Jan 17 21:16:09 2018",
		Fuel	=	{
			FuelType	=	0,
			FuelLidPos	=	Vector(0,0,0),
				},
		Author	=	"𝓒𝓣𝓥𝟏𝟐𝟐𝟓 (76561198051637331)",
}