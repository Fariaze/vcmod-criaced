VCModels['models/azok30victor_moto.mdl']	=	{
		em_state	=	5236594977,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Copyright	=	"Copyright © 2012-2019 VCMod (freemmaann). All Rights Reserved.",
		Exhaust	=	{
				{
				EffectStress	=	"VC_Exhaust_Stress",
				Invulnerable	=	true,
				EffectIdle	=	"VC_Exhaust",
				Ang	=	Angle(-15,-90,0),
				Pos	=	Vector(9.0600004196167,-60.299999237061,19.389999389648),
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(0,-31.459999084473,37.299999237061),
				RadioControl	=	true,
					},
				},
		DLT	=	3491063318,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Pos	=	Vector(-5.710000038147,32.150001525879,31.020000457764),
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Pos	=	Vector(5.710000038147,32.150001525879,31.020000457764),
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				HBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UsePrjTex	=	true,
				Pos	=	Vector(-5.710000038147,32.150001525879,31.020000457764),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				UseSprite	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				HBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UsePrjTex	=	true,
				Pos	=	Vector(5.710000038147,32.150001525879,31.020000457764),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				UseSprite	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-12.279999732971,24,24.139999389648),
				UseDynamic	=	true,
				RenderInner_Size	=	3.7069,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-10.069999694824,28.170000076294,23.040000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-11.189999580383,25.549999237061,21.790000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-12.279999732971,24,24.139999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseBlinkers	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				RenderInner_Size	=	3.7069,
				UseSprite	=	true,
				Pos	=	Vector(12.279999732971,24,24.139999389648),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(10.069999694824,28.170000076294,23.040000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(11.189999580383,25.549999237061,21.790000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(12.279999732971,24,24.139999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-6.5100002288818,-49.099998474121,31.940000534058),
				UseDynamic	=	true,
				RenderInner_Size	=	3.7069,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-7.3600001335144,-46.459999084473,30.950000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseBlinkers	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				RenderInner_Size	=	3.7069,
				UseSprite	=	true,
				Pos	=	Vector(6.5100002288818,-49.099998474121,31.940000534058),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(7.3600001335144,-46.459999084473,30.950000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseRunning	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(4.4499998092651,-50.560001373291,35.130001068115),
				UseDynamic	=	true,
				RenderInner_Size	=	3.7069,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-4.3400001525879,-51.400001525879,35.509998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				UseBrake	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				RenderInner_Size	=	3.7069,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(4.4499998092651,-50.560001373291,35.130001068115),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-4.3400001525879,-51.400001525879,35.509998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	true,
					},
				},
		Date	=	"Mon Mar 11 23:18:36 2019",
		Fuel	=	{
			FuelType	=	0,
				},
		Author	=	"Azok30 (76561198183398967)",
}