VCModels['models/crsk_autosbmwz4e89_2012.mdl']	=	{
		Light_DD_Int	=	true,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		HealthEnginePosOvr	=	true,
		Date	=	"Thu Sep 14 21:44:37 2017",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-22.819999694824,-98.160003662109,12.430000305176),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-26.879999160767,-96.150001525879,12.409999847412),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		em_state	=	5236595013,
		Copyright	=	"Copyright © 2012-2017 VCMod (freemmaann). All Rights Reserved.",
		HealthEnginePos	=	Vector(-0.5,58.5,31.5),
		DLT	=	3491063342,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						255,
						111,
						0,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-33.529998779297,-86.589996337891,37.229999542236),
				RenderMLCenter	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-32.689998626709,-87.709999084473,37),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.799999237061,-88.720001220703,36.799999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.700000762939,-89.720001220703,36.610000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.549999237061,-90.599998474121,36.479999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.670000076294,-91.150001525879,36.409999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.590000152588,-91.73999786377,36.360000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.700000762939,-92.709999084473,36.310001373291),
								},
							},
						},
				RenderInner_Size	=	2.5,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						255,
						111,
						0,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-34.990001678467,-84.769996643066,35.819999694824),
				RenderMLCenter	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-34.310001373291,-86.129997253418,35.659999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.639999389648,-87.23999786377,35.529998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.779998779297,-88.51000213623,35.389999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.879999160767,-89.559997558594,35.290000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.940000534058,-90.400001525879,35.200000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.030000686646,-91.120002746582,35.119998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.079999923706,-91.790000915527,35.060001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.049999237061,-92.410003662109,35.009998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.860000610352,-93.029998779297,34.979999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.760000228882,-93.550003051758,34.979999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-23.35000038147,-94.529998779297,35.029998779297),
								},
							},
						},
				RenderInner_Size	=	2.7,
				RunningColor	=	{
						255,
						55,
						0,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.02,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					Pos4	=	Vector(-26.170000076294,-93.519996643066,32.619998931885),
					AmountV	=	10,
					Pos1	=	Vector(-27.469999313354,-92.339996337891,34.540000915527),
					Pos2	=	Vector(-22.659999847412,-94.610000610352,34.459999084473),
					AmountH	=	12,
					Use	=	true,
					Mid_Full	=	true,
					Pos3	=	Vector(-21.129999160767,-96.01000213623,32.509998321533),
						},
				UseDynamic	=	true,
				RenderHD_Size	=	0.25,
				BrakeColor	=	{
						255,
						25,
						0,
						},
				RenderInner_Clr	=	{
						255,
						100,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	1,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderHD_Adv	=	true,
				Pos	=	Vector(-24.469999313354,-94,33.569999694824),
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				RenderInner_Size	=	3,
				RenderMLCenter	=	true,
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.02,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					Pos4	=	Vector(25.819999694824,-93.540000915527,32.479999542236),
					AmountV	=	10,
					Pos1	=	Vector(27.120000839233,-92.360000610352,34.400001525879),
					Pos2	=	Vector(22.309999465942,-94.629997253418,34.319999694824),
					AmountH	=	12,
					Use	=	true,
					Mid_Full	=	true,
					Pos3	=	Vector(20.780000686646,-96.029998779297,32.369998931885),
						},
				UseDynamic	=	true,
				RenderHD_Size	=	0.25,
				BrakeColor	=	{
						255,
						25,
						0,
						},
				RenderInner_Clr	=	{
						255,
						100,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	1,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(24.120000839233,-94.019996643066,33.430000305176),
				RenderHD_Adv	=	true,
				RenderInner_Size	=	3,
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				UseBrake	=	true,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.02,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					Pos4	=	Vector(-35.689998626709,-84.610000610352,32.259998321533),
					AmountV	=	10,
					Pos1	=	Vector(-35.549999237061,-83.48999786377,35.139999389648),
					Pos2	=	Vector(-31.459999084473,-89.589996337891,34.650001525879),
					AmountH	=	20,
					Use	=	true,
					Mid_Full	=	true,
					Pos3	=	Vector(-30.170000076294,-90.940002441406,32.5),
						},
				UseDynamic	=	true,
				RenderHD_Size	=	0.3,
				BrakeColor	=	{
						255,
						25,
						0,
						},
				RenderInner_Clr	=	{
						255,
						100,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	1,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-34.159999847412,-87.470001220703,33.900001525879),
				UseBrake	=	true,
				RenderInner_Size	=	3,
				RenderHD_Adv	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.02,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					Pos4	=	Vector(35.419998168945,-84.819999694824,32.049999237061),
					AmountV	=	10,
					Pos1	=	Vector(35.279998779297,-83.699996948242,34.930000305176),
					Pos2	=	Vector(31.190000534058,-89.800003051758,34.439998626709),
					AmountH	=	20,
					Use	=	true,
					Mid_Full	=	true,
					Pos3	=	Vector(29.89999961853,-91.150001525879,32.290000915527),
						},
				UseDynamic	=	true,
				RenderHD_Size	=	0.3,
				BrakeColor	=	{
						255,
						25,
						0,
						},
				RenderInner_Clr	=	{
						255,
						100,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	1,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderHD_Adv	=	true,
				Pos	=	Vector(33.889999389648,-87.680000305176,33.689998626709),
				UseBrake	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				RenderInner_Size	=	3,
				Beta_Inner3D	=	true,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				SpecRec	=	{
					Use	=	true,
					AmountH	=	2,
					Pos1	=	Vector(-28.729999542236,-92.959999084473,33.459999084473),
					InnerCenterOnly	=	true,
					AmountV	=	2,
					Pos2	=	Vector(-29.459999084473,-92.419998168945,33.689998626709),
					Pos4	=	Vector(-27.959999084473,-93.5,33.25),
					Mid_Full	=	true,
					Pos3	=	Vector(-28.809999465942,-92.919998168945,33.430000305176),
						},
				UseDynamic	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				RenderInner_Clr	=	{
						200,
						225,
						255,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-26.780000686646,-94.349998474121,32.889999389648),
					UseColor	=	true,
					Pos2	=	Vector(-30.639999389648,-91.569999694824,34.049999237061),
					Color	=	{
							200,
							225,
							255,
							},
					Use	=	true,
					Pos1	=	Vector(-27.479999542236,-93.589996337891,34.020000457764),
					Pos3	=	Vector(-29.979999542236,-92.290000915527,32.840000152588),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-28.739999771118,-90.440002441406,33.419998168945),
				RenderMLCenter	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				RenderInner_Size	=	2.7,
				RenderHD_Adv	=	true,
				RenderHD_Size	=	2,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				SpecRec	=	{
					Use	=	true,
					AmountH	=	2,
					Pos1	=	Vector(28.370000839233,-93.089996337891,33.319999694824),
					InnerCenterOnly	=	true,
					AmountV	=	2,
					Pos2	=	Vector(29.10000038147,-92.550003051758,33.549999237061),
					Pos4	=	Vector(27.60000038147,-93.629997253418,33.110000610352),
					Mid_Full	=	true,
					Pos3	=	Vector(28.450000762939,-93.050003051758,33.290000915527),
						},
				UseDynamic	=	true,
				RenderHD_Size	=	2,
				RenderInner_Clr	=	{
						200,
						225,
						255,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(26.420000076294,-94.480003356934,32.75),
					UseColor	=	true,
					Pos2	=	Vector(30.280000686646,-91.699996948242,33.909999847412),
					Color	=	{
							200,
							225,
							255,
							},
					Use	=	true,
					Pos1	=	Vector(27.120000839233,-93.720001220703,33.880001068115),
					Pos3	=	Vector(29.620000839233,-92.419998168945,32.700000762939),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(28.379999160767,-90.569999694824,33.279998779297),
				RenderMLCenter	=	true,
				RenderInner_Size	=	2.7,
				UseSprite	=	true,
				RenderInner	=	true,
				RenderHD_Adv	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						255,
						111,
						0,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(33.240001678467,-86.790000915527,37.060001373291),
				UseSprite	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(32.400001525879,-87.910003662109,36.830001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.510000228882,-88.919998168945,36.630001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.409999847412,-89.919998168945,36.439998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.260000228882,-90.800003051758,36.310001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.379999160767,-91.349998474121,36.240001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.299999237061,-91.940002441406,36.189998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.409999847412,-92.910003662109,36.139999389648),
								},
							},
						},
				RenderInner_Size	=	2.5,
				RunningColor	=	{
						255,
						55,
						0,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						255,
						111,
						0,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(34.75,-84.949996948242,35.680000305176),
				RenderMLCenter	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(34.069999694824,-86.309997558594,35.520000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.400001525879,-87.419998168945,35.389999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.540000915527,-88.690002441406,35.25),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.639999389648,-89.73999786377,35.150001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.700000762939,-90.580001831055,35.060001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.790000915527,-91.300003051758,34.979999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.840000152588,-91.970001220703,34.919998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.809999465942,-92.589996337891,34.869998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.620000839233,-93.209999084473,34.840000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.520000457764,-93.730003356934,34.840000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(23.110000610352,-94.709999084473,34.889999389648),
								},
							},
						},
				RenderInner_Size	=	2.7,
				RunningColor	=	{
						255,
						55,
						0,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				RenderMLCenter	=	true,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				Beta_Inner3D	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-35.5,-86.01000213623,31.590000152588),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	18,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-34.150001525879,-87.860000610352,31.579999923706),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.540000915527,-88.650001525879,31.60000038147),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.830001831055,-89.480003356934,31.610000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.029998779297,-90.269996643066,31.620000839233),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.190000534058,-91.019996643066,31.629999160767),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.229999542236,-91.800003051758,31.629999160767),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.239999771118,-92.529998779297,31.639999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.370000839233,-93.120002746582,31.639999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.469999313354,-93.699996948242,31.639999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.079999923706,-94.459999084473,31.64999961853),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.809999465942,-95.069999694824,31.64999961853),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-23.719999313354,-95.559997558594,31.659999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-22.809999465942,-95.930000305176,31.670000076294),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-20.620000839233,-96.629997253418,31.719999313354),
								},
							},
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	1,
						},
				RenderInner_Clr	=	{
						255,
						100,
						0,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				UseSprite	=	true,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				RenderInner_Size	=	1,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(35.209999084473,-86.089996337891,31.5),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	18,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(33.860000610352,-87.940002441406,31.489999771118),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.25,-88.730003356934,31.510000228882),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.540000915527,-89.559997558594,31.520000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.739999771118,-90.349998474121,31.530000686646),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.89999961853,-91.099998474121,31.540000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.940000534058,-91.879997253418,31.540000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.950000762939,-92.610000610352,31.549999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.079999923706,-93.199996948242,31.549999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.180000305176,-93.779998779297,31.549999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.790000915527,-94.540000915527,31.559999465942),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.520000457764,-95.150001525879,31.559999465942),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(23.430000305176,-95.639999389648,31.569999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(22.520000457764,-96.01000213623,31.579999923706),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(20.329999923706,-96.709999084473,31.629999160767),
								},
							},
						},
				RenderMLCenter	=	true,
				RenderInner_Clr	=	{
						255,
						100,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderHD_Size	=	0.5,
				BrakeColor	=	{
						255,
						0,
						0,
						},
				RenderInner_Clr	=	{
						255,
						122,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	1,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-10.210000038147,-79.699996948242,43.790000915527),
				UseBrake	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	35,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-0.15999999642372,-80.099998474121,44.040000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(10,-79.769996643066,43.770000457764),
								},
							},
						},
				UseSprite	=	true,
				RenderInner_Size	=	1,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				RenderMLCenter	=	true,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-36.029998779297,76.339996337891,29.420000076294),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderHD_Size	=	0.5,
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
						255,
						96,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				UseBlinkers	=	true,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseSprite	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(36.459999084473,76.169998168945,29.280000686646),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				RenderHD_Size	=	0.5,
				RenderMLCenter	=	true,
				RenderInner_Clr	=	{
						255,
						96,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderHD_Size	=	0.5,
				RenderInner_Clr	=	{
						255,
						175,
						155,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	1,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-31.059999465942,82.23999786377,25.889999389648),
				RenderMLCenter	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-31.60000038147,82.300003051758,26.010000228882),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.029998779297,82.339996337891,26.159999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.400001525879,82.379997253418,26.370000839233),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.740001678467,82.410003662109,26.64999961853),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.979999542236,82.430000305176,26.950000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.130001068115,82.440002441406,27.180000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.259998321533,82.459999084473,27.430000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.400001525879,82.459999084473,27.829999923706),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.470001220703,82.459999084473,28.270000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.479999542236,82.470001220703,28.610000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.400001525879,82.470001220703,29.040000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.299999237061,82.459999084473,29.370000839233),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.159999847412,82.449996948242,29.709999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.990001678467,82.440002441406,29.950000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.860000610352,82.419998168945,30.110000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.700000762939,82.410003662109,30.280000686646),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.529998779297,82.389999389648,30.420000076294),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.299999237061,82.370002746582,30.569999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.110000610352,82.349998474121,30.690000534058),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.909999847412,82.330001831055,30.790000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.64999961853,82.300003051758,30.889999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.389999389648,82.269996643066,30.950000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.120000839233,82.25,30.979999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.860000610352,82.230003356934,30.989999771118),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.60000038147,82.209999084473,30.969999313354),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.35000038147,82.190002441406,30.930000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.020000457764,82.160003662109,30.840000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.760000228882,82.129997253418,30.739999771118),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.469999313354,82.110000610352,30.60000038147),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.190000534058,82.080001831055,30.39999961853),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29,82.050003051758,30.219999313354),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.85000038147,82.040000915527,30.049999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.690000534058,82.019996643066,29.829999923706),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.520000457764,82.01000213623,29.520000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.39999961853,82,29.209999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.35000038147,81.98999786377,28.930000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.299999237061,81.970001220703,28.60000038147),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.299999237061,81.98999786377,28.299999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.340000152588,82,27.930000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.389999389648,82.01000213623,27.709999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.5,82.01000213623,27.39999961853),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.64999961853,82.019996643066,27.090000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29,82.040000915527,26.659999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.219999313354,82.059997558594,26.469999313354),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.489999771118,82.089996337891,26.270000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.790000915527,82.110000610352,26.120000839233),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.10000038147,82.150001525879,26.010000228882),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.540000915527,82.190002441406,25.89999961853),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.059999465942,82.23999786377,25.889999389648),
								},
							},
						},
				RenderInner_Size	=	1,
				RunningColor	=	{
						255,
						175,
						100,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderHD_Size	=	0.5,
				RenderInner_Clr	=	{
						255,
						175,
						155,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	1,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(31.510000228882,82.099998474121,25.709999084473),
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(32.049999237061,82.160003662109,25.829999923706),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.479999542236,82.199996948242,25.979999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.849998474121,82.23999786377,26.190000534058),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.189998626709,82.269996643066,26.469999313354),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.430000305176,82.290000915527,26.770000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.580001831055,82.300003051758,27),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.709999084473,82.319999694824,27.25),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.849998474121,82.319999694824,27.64999961853),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.919998168945,82.319999694824,28.090000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.930000305176,82.330001831055,28.430000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.849998474121,82.330001831055,28.860000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.75,82.319999694824,29.190000534058),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.610000610352,82.309997558594,29.530000686646),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.439998626709,82.300003051758,29.770000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.310001373291,82.279998779297,29.930000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.150001525879,82.269996643066,30.10000038147),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.979999542236,82.25,30.239999771118),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.75,82.230003356934,30.389999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.560001373291,82.209999084473,30.510000228882),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.360000610352,82.190002441406,30.610000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.099998474121,82.160003662109,30.709999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.840000152588,82.129997253418,30.770000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.569999694824,82.110000610352,30.799999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.309999465942,82.089996337891,30.809999465942),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.049999237061,82.069999694824,30.790000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.799999237061,82.050003051758,30.75),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.469999313354,82.019996643066,30.659999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.209999084473,81.98999786377,30.559999465942),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.920000076294,81.970001220703,30.420000076294),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.639999389648,81.940002441406,30.219999313354),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.450000762939,81.910003662109,30.040000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.299999237061,81.900001525879,29.870000839233),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.139999389648,81.879997253418,29.64999961853),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.969999313354,81.870002746582,29.340000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.85000038147,81.860000610352,29.030000686646),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.799999237061,81.849998474121,28.75),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.75,81.830001831055,28.420000076294),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.75,81.849998474121,28.120000839233),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.790000915527,81.860000610352,27.75),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.840000152588,81.870002746582,27.530000686646),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.950000762939,81.870002746582,27.219999313354),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.10000038147,81.879997253418,26.909999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.450000762939,81.900001525879,26.479999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.670000076294,81.919998168945,26.290000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.940000534058,81.949996948242,26.090000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.239999771118,81.970001220703,25.940000534058),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.549999237061,82.01000213623,25.829999923706),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.989999771118,82.050003051758,25.719999313354),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.510000228882,82.099998474121,25.709999084473),
								},
							},
						},
				RenderInner	=	true,
				RunningColor	=	{
						255,
						175,
						100,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.08,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderHD_Size	=	0.5,
				RenderInner_Clr	=	{
						255,
						175,
						155,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	1,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(27.010000228882,82.459999084473,26.159999847412),
				RenderMLCenter	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	5,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(27.229999542236,82.470001220703,26.200000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.469999313354,82.470001220703,26.290000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.729999542236,82.480003356934,26.409999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.930000305176,82.5,26.590000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.030000686646,82.51000213623,26.729999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.120000839233,82.519996643066,26.860000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.200000762939,82.519996643066,27.110000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.229999542236,82.51000213623,27.370000839233),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.209999084473,82.51000213623,27.610000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.14999961853,82.51000213623,27.840000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.059999465942,82.51000213623,28.040000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.920000076294,82.5,28.239999771118),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.770000457764,82.480003356934,28.39999961853),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.60000038147,82.480003356934,28.520000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.430000305176,82.470001220703,28.610000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.229999542236,82.459999084473,28.670000076294),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.940000534058,82.449996948242,28.690000534058),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.709999084473,82.449996948242,28.670000076294),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.5,82.449996948242,28.629999160767),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.290000915527,82.440002441406,28.540000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.129999160767,82.430000305176,28.409999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.979999542236,82.419998168945,28.270000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.829999923706,82.410003662109,28.040000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.739999771118,82.400001525879,27.799999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.690000534058,82.400001525879,27.569999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.690000534058,82.400001525879,27.319999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.729999542236,82.400001525879,27.040000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.809999465942,82.400001525879,26.799999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.950000762939,82.410003662109,26.590000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.159999847412,82.419998168945,26.389999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.360000610352,82.440002441406,26.290000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.559999465942,82.449996948242,26.209999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.819999694824,82.449996948242,26.170000076294),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.010000228882,82.459999084473,26.159999847412),
								},
							},
						},
				RenderInner_Size	=	1,
				RunningColor	=	{
						255,
						175,
						100,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.08,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderHD_Size	=	0.5,
				RenderInner_Clr	=	{
						255,
						175,
						155,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	1,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-26.559999465942,82.599998474121,26.319999694824),
				UseSprite	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	5,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-26.780000686646,82.610000610352,26.360000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.020000457764,82.610000610352,26.450000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.280000686646,82.620002746582,26.569999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.479999542236,82.639999389648,26.75),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.579999923706,82.650001525879,26.889999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.670000076294,82.660003662109,27.020000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.75,82.660003662109,27.270000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.780000686646,82.650001525879,27.530000686646),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.760000228882,82.650001525879,27.770000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.700000762939,82.650001525879,28),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.610000610352,82.650001525879,28.200000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.469999313354,82.639999389648,28.39999961853),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.319999694824,82.620002746582,28.559999465942),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.14999961853,82.620002746582,28.680000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.979999542236,82.610000610352,28.770000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.780000686646,82.599998474121,28.829999923706),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.489999771118,82.589996337891,28.85000038147),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.260000228882,82.589996337891,28.829999923706),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.049999237061,82.589996337891,28.790000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.840000152588,82.580001831055,28.700000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.680000305176,82.569999694824,28.569999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.530000686646,82.559997558594,28.430000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.379999160767,82.550003051758,28.200000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.290000915527,82.540000915527,27.959999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.239999771118,82.540000915527,27.729999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.239999771118,82.540000915527,27.479999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.280000686646,82.540000915527,27.200000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.360000610352,82.540000915527,26.959999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.5,82.550003051758,26.75),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.709999084473,82.559997558594,26.549999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.909999847412,82.580001831055,26.450000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.110000610352,82.589996337891,26.370000839233),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.370000839233,82.589996337891,26.329999923706),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.559999465942,82.599998474121,26.319999694824),
								},
							},
						},
				RenderInner	=	true,
				RunningColor	=	{
						255,
						175,
						100,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderHD_Size	=	0.5,
				RenderInner_Clr	=	{
						255,
						175,
						155,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	1,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-25.170000076294,85.73999786377,25.389999389648),
				RenderMLCenter	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-25.409999847412,85.75,25.420000076294),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.639999389648,85.769996643066,25.479999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.979999542236,85.790000915527,25.620000839233),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.270000457764,85.809997558594,25.780000686646),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.459999084473,85.819999694824,25.940000534058),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.620000839233,85.839996337891,26.129999160767),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.780000686646,85.830001831055,26.340000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.920000076294,85.849998474121,26.569999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.010000228882,85.849998474121,26.840000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.049999237061,85.860000610352,27.110000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.059999465942,85.860000610352,27.370000839233),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.040000915527,85.860000610352,27.610000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.979999542236,85.849998474121,27.85000038147),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.909999847412,85.860000610352,28.049999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.809999465942,85.849998474121,28.280000686646),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.690000534058,85.849998474121,28.459999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.520000457764,85.839996337891,28.659999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.340000152588,85.819999694824,28.809999465942),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.10000038147,85.790000915527,28.969999313354),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.85000038147,85.76000213623,29.079999923706),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.610000610352,85.73999786377,29.170000076294),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.370000839233,85.730003356934,29.209999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.120000839233,85.709999084473,29.229999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.889999389648,85.699996948242,29.209999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.670000076294,85.690002441406,29.180000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.440000534058,85.680000305176,29.110000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.219999313354,85.669998168945,29),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24,85.650001525879,28.870000839233),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-23.780000686646,85.650001525879,28.690000534058),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-23.569999694824,85.639999389648,28.450000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-23.420000076294,85.629997253418,28.219999313354),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-23.319999694824,85.629997253418,27.979999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-23.239999771118,85.629997253418,27.75),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-23.190000534058,85.639999389648,27.479999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-23.159999847412,85.639999389648,27.229999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-23.170000076294,85.639999389648,26.969999313354),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-23.229999542236,85.629997253418,26.700000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-23.329999923706,85.629997253418,26.430000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-23.459999084473,85.629997253418,26.229999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-23.610000610352,85.639999389648,26.040000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-23.85000038147,85.650001525879,25.840000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.110000610352,85.660003662109,25.680000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.389999389648,85.680000305176,25.540000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.659999847412,85.690002441406,25.440000534058),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.909999847412,85.720001220703,25.389999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.170000076294,85.73999786377,25.389999389648),
								},
							},
						},
				RenderInner	=	true,
				RunningColor	=	{
						255,
						175,
						100,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderHD_Size	=	0.5,
				RenderInner_Clr	=	{
						255,
						175,
						155,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	1,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(25.659999847412,85.650001525879,25.340000152588),
				RenderMLCenter	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(25.89999961853,85.660003662109,25.370000839233),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.129999160767,85.680000305176,25.430000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.469999313354,85.699996948242,25.569999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.760000228882,85.720001220703,25.729999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.950000762939,85.730003356934,25.889999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.110000610352,85.75,26.079999923706),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.270000457764,85.73999786377,26.290000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.409999847412,85.76000213623,26.520000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.5,85.76000213623,26.790000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.540000915527,85.769996643066,27.059999465942),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.549999237061,85.769996643066,27.319999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.530000686646,85.769996643066,27.559999465942),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.469999313354,85.76000213623,27.799999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.39999961853,85.769996643066,28),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.299999237061,85.76000213623,28.229999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.180000305176,85.76000213623,28.409999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.010000228882,85.75,28.610000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.829999923706,85.730003356934,28.760000228882),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.590000152588,85.699996948242,28.920000076294),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.340000152588,85.669998168945,29.030000686646),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.10000038147,85.650001525879,29.120000839233),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.860000610352,85.639999389648,29.159999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.610000610352,85.620002746582,29.180000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.379999160767,85.610000610352,29.159999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.159999847412,85.599998474121,29.129999160767),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.930000305176,85.589996337891,29.059999465942),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.709999084473,85.580001831055,28.950000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.489999771118,85.559997558594,28.819999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.270000457764,85.559997558594,28.639999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.059999465942,85.550003051758,28.39999961853),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(23.909999847412,85.540000915527,28.170000076294),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(23.809999465942,85.540000915527,27.930000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(23.729999542236,85.540000915527,27.700000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(23.680000305176,85.550003051758,27.430000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(23.64999961853,85.550003051758,27.180000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(23.659999847412,85.550003051758,26.920000076294),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(23.719999313354,85.540000915527,26.64999961853),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(23.819999694824,85.540000915527,26.379999160767),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(23.950000762939,85.540000915527,26.180000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.10000038147,85.550003051758,25.989999771118),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.340000152588,85.559997558594,25.790000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.60000038147,85.569999694824,25.629999160767),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.879999160767,85.589996337891,25.489999771118),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.14999961853,85.599998474121,25.389999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.39999961853,85.629997253418,25.340000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.659999847412,85.650001525879,25.340000152588),
								},
							},
						},
				RenderInner_Size	=	1,
				RunningColor	=	{
						255,
						175,
						100,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
						200,
						225,
						255,
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						255,
						100,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-28.620000839233,81.160003662109,25.959999084473),
					UseColor	=	true,
					Pos2	=	Vector(-33.470001220703,81.629997253418,30.799999237061),
					Color	=	{
							200,
							225,
							255,
							},
					Use	=	true,
					Pos1	=	Vector(-28.639999389648,81.069999694824,31),
					Pos3	=	Vector(-33.509998321533,81.629997253418,26.139999389648),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-31.139999389648,80.589996337891,28.5),
				RenderInner_Size	=	1,
				RenderMLCenter	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-23.190000534058,85.620002746582,25.459999084473),
					UseColor	=	true,
					Pos2	=	Vector(-27.110000610352,85.900001525879,28.959999084473),
					Color	=	{
							200,
							225,
							255,
							},
					Use	=	true,
					Pos1	=	Vector(-23.200000762939,85.550003051758,29.180000305176),
					Pos3	=	Vector(-27.059999465942,85.900001525879,25.629999160767),
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	1,
						},
				HBeamColor	=	{
						200,
						225,
						255,
						},
				ReducedVis	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-25.229999542236,84.980003356934,27.360000610352),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderMLCenter	=	true,
				UsePrjTex	=	true,
				UseSprite	=	true,
				SpecMat	=	{
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-25.469999313354,82,26.35000038147),
					UseColor	=	true,
					Pos2	=	Vector(-27.559999465942,82.080001831055,28.760000228882),
					Color	=	{
							200,
							225,
							255,
							},
					Use	=	true,
					Pos1	=	Vector(-25.39999961853,81.980003356934,28.75),
					Pos3	=	Vector(-27.719999313354,82.150001525879,26.450000762939),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				HBeamColor	=	{
						200,
						225,
						255,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-26.549999237061,82.01000213623,27.75),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderMLCenter	=	true,
				SpecCircle	=	{
					InnerCenterOnly	=	true,
					Use	=	true,
					Amount	=	7,
						},
				UseSprite	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						255,
						155,
						0,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	1,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-37.709999084473,75.029998779297,31.540000915527),
				RenderInner	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	3,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-37.909999847412,74.300003051758,31.629999160767),
								},
							},
						},
				UseSprite	=	true,
				RunningColor	=	{
						255,
						155,
						0,
						},
				RenderHD_Adv	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						255,
						155,
						0,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	1,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(38.130001068115,74.839996337891,31.35000038147),
				RenderInner	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	3,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(38.330001831055,74.110000610352,31.440000534058),
								},
							},
						},
				RenderHD_Adv	=	true,
				RunningColor	=	{
						255,
						155,
						0,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
						200,
						225,
						255,
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						255,
						100,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(29.040000915527,80.98999786377,25.819999694824),
					UseColor	=	true,
					Pos2	=	Vector(33.889999389648,81.459999084473,30.659999847412),
					Color	=	{
							200,
							225,
							255,
							},
					Use	=	true,
					Pos1	=	Vector(29.059999465942,80.900001525879,30.860000610352),
					Pos3	=	Vector(33.930000305176,81.459999084473,26),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(31.559999465942,80.449996948242,28.360000610352),
				RenderInner_Size	=	1,
				RenderMLCenter	=	true,
				UseSprite	=	true,
				RenderInner	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(25.889999389648,81.889999389648,26.209999084473),
					UseColor	=	true,
					Pos2	=	Vector(28.10000038147,81.970001220703,28.620000839233),
					Color	=	{
							200,
							225,
							255,
							},
					Use	=	true,
					Pos1	=	Vector(25.819999694824,81.870002746582,28.610000610352),
					Pos3	=	Vector(28.139999389648,82.040000915527,26.309999465942),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				HBeamColor	=	{
						200,
						225,
						255,
						},
				UseSprite	=	true,
				Pos	=	Vector(26.969999313354,81.900001525879,27.610000610352),
				UseDynamic	=	true,
				SpecCircle	=	{
					InnerCenterOnly	=	true,
					Use	=	true,
					Amount	=	7,
						},
				RenderMLCenter	=	true,
				Beta_Inner3D	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(23.610000610352,85.5,25.319999694824),
					UseColor	=	true,
					Pos2	=	Vector(27.530000686646,85.779998779297,28.819999694824),
					Color	=	{
							200,
							225,
							255,
							},
					Use	=	true,
					Pos1	=	Vector(23.620000839233,85.430000305176,29.040000915527),
					Pos3	=	Vector(27.479999542236,85.779998779297,25.489999771118),
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	1,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(25.64999961853,84.860000610352,27.219999313354),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				UseSprite	=	true,
				UsePrjTex	=	true,
				HBeamColor	=	{
						200,
						225,
						255,
						},
				RenderMLCenter	=	true,
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(10,0,0),
				Pos	=	Vector(18.89999961853,-8.3400001525879,25.25),
				RadioControl	=	true,
					},
				},
		Fuel	=	{
			FuelLidPos	=	Vector(39.490001678467,-57.220001220703,39.389999389648),
			FuelType	=	0,
			Capacity	=	55,
			Override	=	true,
			FuelLidUse	=	true,
				},
		Author	=	"CгεερεгƬv (76561198051637331)",
}