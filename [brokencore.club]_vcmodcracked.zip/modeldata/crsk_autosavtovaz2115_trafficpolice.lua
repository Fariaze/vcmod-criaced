VCModels['models/crsk_autosavtovaz2115_trafficpolice.mdl']	=	{
		em_state	=	5236594380,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Siren	=	{
			Sounds	=	{
					{
					Pitch	=	100,
					Volume	=	1,
					Distance	=	95,
					Name	=	"Wail",
					Sound	=	"vcmod/tdmsirens/wail.wav",
						},
					{
					Pitch	=	100,
					Volume	=	1,
					Distance	=	95,
					Name	=	"Yelp",
					Sound	=	"vcmod/tdmsirens/siren2.wav",
						},
					{
					Pitch	=	100,
					Volume	=	1,
					Distance	=	95,
					Name	=	"phaser",
					Sound	=	"vcmod/els/phaser_2.wav",
						},
					},
			Sections_BGroups	=	{
				[8]	=	{
					[0]	=	"migalka",
						},
					},
			Sequences	=	{
					{
					SubSeq	=	{
							{
							Type	=	"Custom",
							Time	=	5,
							Stages	=	{
									{
									Lights	=	{
											1,
											2,
											},
									Time	=	0.3,
										},
									{
									Lights	=	{
											3,
											4,
											},
									Time	=	0.3,
										},
									},
								},
							{
							Type	=	"Custom",
							Time	=	5,
							Stages	=	{
									{
									Lights	=	{
											1,
											2,
											3,
											4,
											},
									Time	=	0.3,
										},
									{
									Lights	=	{
											},
									Time	=	0.3,
										},
									},
								},
							},
					Codes	=	{
							true,
							},
					Lights_Sel	=	{
							true,
							true,
							true,
							true,
							},
						},
					{
					SubSeq	=	{
							{
							Type	=	"Custom",
							Time	=	5,
							Stages	=	{
									{
									Lights	=	{
											1,
											3,
											},
									Time	=	0.12,
										},
									{
									Lights	=	{
											},
									Time	=	0.12,
										},
									{
									Lights	=	{
											1,
											3,
											},
									Time	=	0.12,
										},
									{
									Lights	=	{
											},
									Time	=	0.12,
										},
									{
									Lights	=	{
											2,
											4,
											},
									Time	=	0.12,
										},
									{
									Lights	=	{
											},
									Time	=	0.12,
										},
									{
									Lights	=	{
											2,
											4,
											},
									Time	=	0.12,
										},
									{
									Lights	=	{
											},
									Time	=	0.12,
										},
									},
								},
							{
							Type	=	"Custom",
							Time	=	5,
							Stages	=	{
									{
									Lights	=	{
											3,
											4,
											},
									Time	=	0.12,
										},
									{
									Lights	=	{
											1,
											2,
											},
									Time	=	0.12,
										},
									},
								},
							},
					Codes	=	{
						[2]	=	true,
							},
					Lights_Sel	=	{
							true,
							true,
							true,
							true,
							},
						},
					{
					SubSeq	=	{
							{
							Type	=	"Custom",
							Time	=	3,
							Stages	=	{
									{
									Lights	=	{
											1,
											2,
											4,
											},
									Time	=	0.07,
										},
									{
									Lights	=	{
											3,
											},
									Time	=	0.07,
										},
									},
								},
							{
							Type	=	"Custom",
							Time	=	3,
							Stages	=	{
									{
									Lights	=	{
											},
									Time	=	0.04,
										},
									{
									Lights	=	{
											1,
											4,
											2,
											3,
											},
									Time	=	0.05,
										},
									},
								},
							{
							Type	=	"Custom",
							Time	=	3,
							Stages	=	{
									{
									Lights	=	{
											1,
											2,
											4,
											},
									Time	=	0.07,
										},
									{
									Lights	=	{
											3,
											},
									Time	=	0.07,
										},
									},
								},
							{
							Type	=	"Custom",
							Time	=	3,
							Stages	=	{
									{
									Lights	=	{
											1,
											2,
											},
									Time	=	0.06,
										},
									{
									Lights	=	{
											3,
											4,
											},
									Time	=	0.06,
										},
									},
								},
							},
					Codes	=	{
						[3]	=	true,
							},
					Lights_Sel	=	{
							true,
							true,
							true,
							true,
							},
						},
					{
					SubSeq	=	{
							{
							Type	=	"Custom",
							Time	=	5,
							Stages	=	{
									{
									Lights	=	{
											3,
											4,
											},
									Time	=	0.3,
										},
									{
									Lights	=	{
											1,
											2,
											},
									Time	=	0.3,
										},
									},
								},
							{
							Type	=	"Custom",
							Time	=	5,
							Stages	=	{
									{
									Lights	=	{
											3,
											4,
											},
									Time	=	0.3,
										},
									{
									Lights	=	{
											1,
											2,
											},
									Time	=	0.3,
										},
									},
								},
							},
					Codes	=	{
						[9]	=	true,
							},
					Lights_Sel	=	{
							true,
							true,
							true,
							true,
							},
						},
					},
			Lights	=	{
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.4,
							},
					inner_AsSpheres	=	true,
					SpecRec	=	{
						Pos4	=	Vector(22.450000762939,-7.8299999237061,66.73999786377),
						Pos2	=	Vector(22.120000839233,-7.8099999427795,66.930000305176),
						Use	=	true,
						Pos1	=	Vector(22.440000534058,-7.8200001716614,66.919998168945),
						Pos3	=	Vector(22.120000839233,-7.8200001716614,66.730003356934),
							},
					BGroups	=	{
						[8]	=	{
							[0]	=	"migalka",
								},
							},
					UseDynamic	=	true,
					SpecModel	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
					RenderInner_ClrUse	=	false,
					Dynamic	=	{
						Size	=	2,
						Brightness	=	2,
							},
					Spec3D	=	{
						Mat	=	"vcmod/square",
						Pos4	=	Vector(20.799999237061,-7.7699999809265,67.970001220703),
						Pos2	=	Vector(23.690000534058,-7.8699998855591,65.059997558594),
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
						Use	=	true,
						Pos1	=	Vector(20.860000610352,-7.8400001525879,65.120002746582),
						Pos3	=	Vector(23.729999542236,-7.8000001907349,67.959999084473),
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(22.280000686646,-7.8099999427795,66.800003051758),
					Beta_Inner3D	=	true,
					RenderInner	=	true,
					Color	=	{
						r	=	0,
						b	=	255,
						a	=	255,
						g	=	55,
							},
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner_Size	=	1,
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.4,
							},
					inner_AsSpheres	=	true,
					UseSprite	=	true,
					SpecRec	=	{
						Pos4	=	Vector(10.050000190735,-7.710000038147,66.699996948242),
						Pos2	=	Vector(9.7200002670288,-7.6900000572205,66.889999389648),
						Use	=	true,
						Pos1	=	Vector(10.039999961853,-7.6999998092651,66.879997253418),
						Pos3	=	Vector(9.7200002670288,-7.6999998092651,66.690002441406),
							},
					SpecModel	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
					Spec3D	=	{
						Mat	=	"vcmod/square",
						Pos4	=	Vector(8.3299999237061,-7.6500000953674,68.029998779297),
						Pos2	=	Vector(11.199999809265,-7.75,65),
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
						Use	=	true,
						Pos1	=	Vector(8.3000001907349,-7.7199997901917,65.099998474121),
						Pos3	=	Vector(11.199999809265,-7.6799998283386,68.029998779297),
							},
					RenderInner	=	true,
					RenderHD_Adv	=	true,
					Beta_Inner3D	=	true,
					Pos	=	Vector(9.8800001144409,-7.6900000572205,66.76000213623),
					UseDynamic	=	true,
					RenderInner_Size	=	1,
					Color	=	{
						r	=	0,
						b	=	255,
						a	=	255,
						g	=	55,
							},
					Dynamic	=	{
						Size	=	2,
						Brightness	=	2,
							},
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner_ClrUse	=	false,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.4,
							},
					inner_AsSpheres	=	true,
					SpecRec	=	{
						Use	=	true,
						Pos2	=	Vector(-9.2700004577637,-7.8299999237061,66.580001831055),
						Pos4	=	Vector(-9.6000003814697,-7.8499999046326,66.389999389648),
						Pos1	=	Vector(-9.5900001525879,-7.8400001525879,66.569999694824),
						Pos3	=	Vector(-9.2700004577637,-7.8400001525879,66.379997253418),
							},
					BGroups	=	{
						[8]	=	{
							[0]	=	"migalka",
								},
							},
					UseDynamic	=	true,
					SpecModel	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
					RenderInner_ClrUse	=	false,
					Dynamic	=	{
						Size	=	2,
						Brightness	=	2,
							},
					Spec3D	=	{
						Mat	=	"vcmod/square",
						Pos4	=	Vector(-8.1099996566772,-7.789999961853,68.019996643066),
						UseColor	=	true,
						Pos2	=	Vector(-10.989999771118,-7.8899998664856,65.059997558594),
						Color	=	{
							r	=	255,
							b	=	0,
							a	=	255,
							g	=	141,
								},
						Use	=	true,
						Pos1	=	Vector(-8.1400003433228,-7.8600001335144,65.050003051758),
						Pos3	=	Vector(-11.010000228882,-7.8200001716614,68.019996643066),
							},
					Beta_Inner3D	=	true,
					Pos	=	Vector(-9.4300003051758,-7.8299999237061,66.449996948242),
					RenderHD_Adv	=	true,
					RenderInner_Size	=	1,
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	55,
							},
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner	=	true,
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.4,
							},
					inner_AsSpheres	=	true,
					SpecRec	=	{
						Pos4	=	Vector(-21.969999313354,-7.6599998474121,66.430000305176),
						Pos2	=	Vector(-21.639999389648,-7.6399998664856,66.620002746582),
						Use	=	true,
						Pos1	=	Vector(-21.959999084473,-7.6500000953674,66.610000610352),
						Pos3	=	Vector(-21.639999389648,-7.6500000953674,66.419998168945),
							},
					BGroups	=	{
						[8]	=	{
							[0]	=	"migalka",
								},
							},
					UseDynamic	=	true,
					SpecModel	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
					RenderInner_ClrUse	=	false,
					Dynamic	=	{
						Size	=	2,
						Brightness	=	2,
							},
					Spec3D	=	{
						Mat	=	"vcmod/square",
						Pos4	=	Vector(-23.5,-7.6999998092651,65.139999389648),
						UseColor	=	true,
						Pos2	=	Vector(-20.569999694824,-7.5999999046326,68.099998474121),
						Color	=	{
							r	=	255,
							b	=	0,
							a	=	255,
							g	=	155,
								},
						Use	=	true,
						Pos1	=	Vector(-23.489999771118,-7.6300001144409,68.150001525879),
						Pos3	=	Vector(-20.620000839233,-7.6700000762939,65.150001525879),
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-21.799999237061,-7.6399998664856,66.48999786377),
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner	=	true,
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	55,
							},
					RenderInner_Size	=	1,
					UseSprite	=	true,
					Beta_Inner3D	=	true,
						},
					},
			Sounds_Horn	=	{
				Use	=	true,
				Volume	=	1,
				Distance	=	95,
				Pitch	=	50,
				Sound	=	"vcmod/els/smartsiren/horn.wav",
					},
			Codes	=	{
				[13]	=	{
					Include	=	true,
						},
					},
			Sounds_Manual	=	{
				Use	=	true,
				Volume	=	1,
				Distance	=	95,
				Pitch	=	100,
				Sound	=	"vcmod/tdmsirens/wail.wav",
					},
				},
		Date	=	"Sun Apr 14 13:38:35 2019",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(-25.489999771118,-93.919998168945,10.119999885559),
				EffectIdle	=	"VC_Exhaust",
					},
				},
		Indication	=	{
			fuel	=	{
				max	=	1,
				pp	=	"fuel_needle",
				top	=	1,
					},
				},
		Copyright	=	"Copyright © 2012-2019 VCMod (freemmaann). All Rights Reserved.",
		ExtraSeats	=	{
				{
				Ang	=	Angle(22,0,0),
				Pos	=	Vector(16.25,12.369999885559,30.860000610352),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(18,0,0),
				Pos	=	Vector(20.89999961853,-25.110000610352,30.139999389648),
					},
				{
				Ang	=	Angle(18,0,0),
				Pos	=	Vector(-1.1699999570847,-25.110000610352,30.139999389648),
					},
				{
				Ang	=	Angle(18,0,0),
				Pos	=	Vector(-21.620000839233,-25.110000610352,30.139999389648),
					},
				},
		HealthEnginePos	=	Vector(0,77.830001831055,33.189998626709),
		DLT	=	3491062920,
		Lights	=	{
				{
				UseRunning	=	true,
				Pos	=	Vector(-20.270000457764,23.329999923706,43.330001831055),
				SpecMat	=	{
					Select	=	13,
					New	=	"models/crskautos/shared/vmt/white_illum_on",
					Use	=	true,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
					},
				{
				UseRunning	=	true,
				Pos	=	Vector(-16.879999160767,23.329999923706,43.330001831055),
				SpecMat	=	{
					Select	=	22,
					New	=	"models/crskautos/shared/vmt/red_illum_on",
					Use	=	true,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2.1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-18.620000839233,94.459999084473,27.739999771118),
					UseColor	=	true,
					Pos2	=	Vector(-29.14999961853,91.370002746582,31.89999961853),
					Color	=	{
						r	=	255,
						b	=	100,
						a	=	255,
						g	=	192,
							},
					Use	=	true,
					Pos1	=	Vector(-18.360000610352,92.220001220703,31.75),
					Pos3	=	Vector(-29.440000534058,93.430000305176,27.89999961853),
						},
				UseSprite	=	true,
				Pos	=	Vector(-23.909999847412,92.379997253418,30.030000686646),
				UseDynamic	=	true,
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				RunningColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-18.620000839233,94.459999084473,27.739999771118),
					UseColor	=	true,
					Pos2	=	Vector(-29.14999961853,91.370002746582,31.89999961853),
					Color	=	{
						r	=	255,
						b	=	100,
						a	=	255,
						g	=	192,
							},
					Use	=	true,
					Pos1	=	Vector(-18.360000610352,92.220001220703,31.75),
					Pos3	=	Vector(-29.440000534058,93.430000305176,27.89999961853),
						},
				HBeamColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				UseSprite	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				Pos	=	Vector(-23.909999847412,92.379997253418,30.030000686646),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2.1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(19.069999694824,94.459999084473,27.540000915527),
					UseColor	=	true,
					Pos2	=	Vector(29.60000038147,91.370002746582,31.700000762939),
					Color	=	{
						r	=	255,
						b	=	100,
						a	=	255,
						g	=	192,
							},
					Use	=	true,
					Pos1	=	Vector(18.809999465942,92.220001220703,31.549999237061),
					Pos3	=	Vector(29.889999389648,93.430000305176,27.700000762939),
						},
				UseSprite	=	true,
				Pos	=	Vector(24.360000610352,92.379997253418,29.829999923706),
				UseDynamic	=	true,
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				RunningColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(19.069999694824,94.459999084473,27.540000915527),
					UseColor	=	true,
					Pos2	=	Vector(29.60000038147,91.370002746582,31.700000762939),
					Color	=	{
						r	=	255,
						b	=	100,
						a	=	255,
						g	=	192,
							},
					Use	=	true,
					Pos1	=	Vector(18.809999465942,92.220001220703,31.549999237061),
					Pos3	=	Vector(29.889999389648,93.430000305176,27.700000762939),
						},
				HBeamColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Pos	=	Vector(24.360000610352,92.379997253418,29.829999923706),
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2.1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-22.170000076294,94.900001525879,14.659999847412),
					UseColor	=	true,
					Pos2	=	Vector(-28.25,95.360000610352,18.340000152588),
					Color	=	{
						r	=	255,
						b	=	155,
						a	=	255,
						g	=	206,
							},
					Use	=	true,
					Pos1	=	Vector(-22.14999961853,95.279998779297,18.280000686646),
					Pos3	=	Vector(-28.139999389648,95.01000213623,14.670000076294),
						},
				FogColor	=	{
					r	=	255,
					b	=	155,
					a	=	255,
					g	=	206,
						},
				UseSprite	=	true,
				Pos	=	Vector(-25.139999389648,94.940002441406,16.420000076294),
				UseDynamic	=	true,
				UseFog	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2.1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(22.629999160767,94.779998779297,14.60000038147),
					UseColor	=	true,
					Pos2	=	Vector(28.709999084473,95.23999786377,18.280000686646),
					Color	=	{
						r	=	255,
						b	=	155,
						a	=	255,
						g	=	206,
							},
					Use	=	true,
					Pos1	=	Vector(22.610000610352,95.160003662109,18.219999313354),
					Pos3	=	Vector(28.60000038147,94.889999389648,14.609999656677),
						},
				FogColor	=	{
					r	=	255,
					b	=	155,
					a	=	255,
					g	=	206,
						},
				UseSprite	=	true,
				Pos	=	Vector(25.60000038147,94.819999694824,16.360000610352),
				UseDynamic	=	true,
				UseFog	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
				UseDynamic	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				Pos	=	Vector(33,87.959999084473,29.60000038147),
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
				UseDynamic	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				Pos	=	Vector(-32.509998321533,88.290000915527,29.760000228882),
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.23,
						},
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2.1,
						},
				UseDynamic	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				Pos	=	Vector(-38.130001068115,45.009998321533,28.670000076294),
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.23,
						},
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2.1,
						},
				UseDynamic	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				Pos	=	Vector(38.290000915527,44.869998931885,28.459999084473),
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				UseBrake	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-25.860000610352,-91.230003356934,26.430000305176),
					UseColor	=	true,
					Pos2	=	Vector(-31.170000076294,-91.580001831055,35.080001831055),
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	128,
							},
					Use	=	true,
					Pos1	=	Vector(-27.10000038147,-91.769996643066,35.220001220703),
					Pos3	=	Vector(-31.069999694824,-91.069999694824,26.479999542236),
						},
				UseSprite	=	true,
				Pos	=	Vector(-28.829999923706,-91.860000610352,30.520000457764),
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				UseBrake	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(25.540000915527,-91.400001525879,26.430000305176),
					UseColor	=	true,
					Pos2	=	Vector(30.85000038147,-91.75,35.080001831055),
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	128,
							},
					Use	=	true,
					Pos1	=	Vector(26.780000686646,-91.940002441406,35.220001220703),
					Pos3	=	Vector(30.75,-91.23999786377,26.479999542236),
						},
				UseSprite	=	true,
				Pos	=	Vector(28.510000228882,-92.029998779297,30.520000457764),
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2.1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-20.889999389648,-91.76000213623,26.430000305176),
					UseColor	=	true,
					Pos2	=	Vector(-26.909999847412,-92.110000610352,35.080001831055),
					Color	=	{
						r	=	141,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-23.39999961853,-92.309997558594,35.220001220703),
					Pos3	=	Vector(-26.159999847412,-91.599998474121,26.479999542236),
						},
				UseSprite	=	true,
				Pos	=	Vector(-24.479999542236,-92.389999389648,30.520000457764),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2.1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(20.920000076294,-91.900001525879,26.430000305176),
					UseColor	=	true,
					Pos2	=	Vector(26.940000534058,-92.25,35.080001831055),
					Color	=	{
						r	=	141,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(23.430000305176,-92.449996948242,35.220001220703),
					Pos3	=	Vector(26.190000534058,-91.73999786377,26.479999542236),
						},
				UseSprite	=	true,
				Pos	=	Vector(24.510000228882,-92.529998779297,30.520000457764),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2.1,
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-16.159999847412,-91.389999389648,27.700000762939),
					UseColor	=	true,
					Pos2	=	Vector(-21.809999465942,-91.73999786377,33.970001220703),
					Color	=	{
						r	=	220,
						b	=	255,
						a	=	255,
						g	=	225,
							},
					Use	=	true,
					Pos1	=	Vector(-18.170000076294,-91.940002441406,33.900001525879),
					Pos3	=	Vector(-19.559999465942,-91.230003356934,27.719999313354),
						},
				UseSprite	=	true,
				Pos	=	Vector(-18.969999313354,-92.019996643066,30.520000457764),
				UseDynamic	=	true,
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2.1,
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(15.85000038147,-91.419998168945,27.659999847412),
					UseColor	=	true,
					Pos2	=	Vector(21.459999084473,-91.769996643066,33.930000305176),
					Color	=	{
						r	=	220,
						b	=	255,
						a	=	255,
						g	=	225,
							},
					Use	=	true,
					Pos1	=	Vector(17.75,-91.970001220703,33.860000610352),
					Pos3	=	Vector(19.209999084473,-91.26000213623,27.680000305176),
						},
				UseSprite	=	true,
				Pos	=	Vector(18.620000839233,-92.050003051758,30.479999542236),
				UseDynamic	=	true,
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2.1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-12.949999809265,-91.389999389648,27.239999771118),
					UseColor	=	true,
					Pos2	=	Vector(-18.60000038147,-91.73999786377,33.709999084473),
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	87,
							},
					Use	=	true,
					Pos1	=	Vector(-14.960000038147,-91.940002441406,33.639999389648),
					Pos3	=	Vector(-16.35000038147,-91.230003356934,27.200000762939),
						},
				FogColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseSprite	=	true,
				Pos	=	Vector(-15.659999847412,-92.019996643066,30.430000305176),
				UseDynamic	=	true,
				UseFog	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2.1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(12.640000343323,-91.449996948242,27.239999771118),
					UseColor	=	true,
					Pos2	=	Vector(18.290000915527,-91.800003051758,33.709999084473),
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	87,
							},
					Use	=	true,
					Pos1	=	Vector(14.64999961853,-92,33.639999389648),
					Pos3	=	Vector(16.040000915527,-91.290000915527,27.200000762939),
						},
				FogColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseSprite	=	true,
				Pos	=	Vector(15.35000038147,-92.080001831055,30.430000305176),
				UseDynamic	=	true,
				UseFog	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseSprite	=	true,
				Pos	=	Vector(32.639999389648,-89.180000305176,30.079999923706),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(30.629999160767,-91.120002746582,26.430000305176),
					UseColor	=	true,
					Pos2	=	Vector(35.090000152588,-88.089996337891,35.080001831055),
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	155,
							},
					Use	=	true,
					Pos1	=	Vector(31.020000457764,-91.300003051758,35.220001220703),
					Pos3	=	Vector(35.189998626709,-87.059997558594,26.479999542236),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseSprite	=	true,
				Pos	=	Vector(-32.639999389648,-88.959999084473,30.329999923706),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-30.629999160767,-90.900001525879,26.829999923706),
					UseColor	=	true,
					Pos2	=	Vector(-35.090000152588,-87.870002746582,35.479999542236),
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	155,
							},
					Use	=	true,
					Pos1	=	Vector(-31.020000457764,-91.080001831055,35.619998931885),
					Pos3	=	Vector(-35.189998626709,-86.839996337891,26.879999160767),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2.1,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				BGroups	=	{
					[10]	=	{
						[0]	=	"spoiler",
							},
						},
				UseSprite	=	true,
				Pos	=	Vector(-5.6799998283386,-92.910003662109,46.099998474121),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	11,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(5.3699998855591,-92.970001220703,46.090000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				Dynamic	=	{
					Size	=	0.09,
					Brightness	=	2.1,
						},
				UseInter	=	true,
				InterColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				SpecMat	=	{
					Select	=	17,
					New	=	"models/crskautos/avtovaz/2115/st_plafon_on",
					Use	=	true,
						},
				UseSprite	=	true,
				Pos	=	Vector(0.10000000149012,-12.069999694824,60.380001068115),
				UseDynamic	=	true,
				RenderType	=	2,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				DD_Main	=	true,
					},
				},
		HealthEnginePosOvr	=	true,
		Fuel	=	{
			FuelLidPos	=	Vector(36.490001678467,-83.339996337891,29.360000610352),
			Override	=	true,
			FuelType	=	0,
			Capacity	=	43,
			FuelLidUse	=	true,
			FuelTypeUse	=	true,
				},
		Author	=	"CrushingSkirmish (76561198017348899)",
}