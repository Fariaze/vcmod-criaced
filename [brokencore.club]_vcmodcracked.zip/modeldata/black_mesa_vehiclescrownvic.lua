VCModels['models/black_mesa_vehiclescrownvic.mdl']	=	{
		em_state	=	5236594356,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Copyright	=	"DurkaTeam @ 2025 No rights reserved",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-24.299999237061,-112.19999694824,22.969999313354),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(24.299999237061,-112.19999694824,22.969999313354),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Pos	=	Vector(20.709999084473,30.700000762939,36.169998168945),
				DoorSounds	=	true,
				Ang	=	Angle(0,0,0),
				EnterRange	=	80,
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(-19.290000915527,-7.289999961853,36.169998168945),
				EnterRange	=	80,
				DoorSounds	=	true,
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(19.290000915527,-7.289999961853,36.169998168945),
				EnterRange	=	80,
				DoorSounds	=	true,
					},
				},
		DLT	=	3491062904,
		Lights	=	{
				{
				UseSprite	=	true,
				Pos	=	Vector(-8.7700004577637,-104.69000244141,40.119998931885),
				UseReverse	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				Sprite	=	{
					Size	=	0.3,
						},
				UseDynamic	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.3,
						},
					},
				{
				Sprite	=	{
					Size	=	0.6,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.6,
						},
				UseSprite	=	true,
				Pos	=	Vector(-30.760000228882,-102.7799987793,39.810001373291),
				UseDynamic	=	true,
				UseRunning	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseBrake	=	true,
					},
				{
				UseBlinkers	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(-37.229999542236,-98.379997253418,39.200000762939),
				UseDynamic	=	true,
				RenderInner	=	true,
				Sprite	=	{
					Size	=	0.4,
						},
				RenderInner_Size	=	1.2,
				Beta_Inner3D	=	true,
					},
				{
				UseBlinkers	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(-36.959999084473,114,35.590000152588),
				UseDynamic	=	true,
				RenderInner	=	true,
				Sprite	=	{
					Size	=	0.4,
						},
				RenderInner_Size	=	1.2,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.45,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.45,
						},
				UseDynamic	=	true,
				UseRunning	=	true,
				UseSprite	=	true,
				RunningColor	=	{
						190.98,
						199.58,
						237.91,
						},
				Pos	=	Vector(-19.379999160767,126.01999664307,36.349998474121),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	1.2,
						},
				ProjTexture	=	{
					Forward	=	30,
					Size	=	2024,
					Angle	=	Angle(0,90,0),
						},
				UseHead	=	true,
				UsePrjTex	=	true,
				Pos	=	Vector(-26.610000610352,124.86000061035,36.040000915527),
				UseDynamic	=	true,
				HeadColor	=	{
						194,
						233,
						255,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.6,
						},
				UseSprite	=	true,
					},
				{
				UseSprite	=	true,
				Pos	=	Vector(8.7700004577637,-104.69000244141,40.119998931885),
				UseReverse	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				Sprite	=	{
					Size	=	0.3,
						},
				UseDynamic	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.3,
						},
					},
				{
				Sprite	=	{
					Size	=	0.6,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.6,
						},
				UseSprite	=	true,
				Pos	=	Vector(30.760000228882,-102.7799987793,39.810001373291),
				UseDynamic	=	true,
				UseRunning	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseBrake	=	true,
					},
				{
				UseBlinkers	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(37.229999542236,-98.379997253418,39.200000762939),
				UseDynamic	=	true,
				RenderInner	=	true,
				Sprite	=	{
					Size	=	0.4,
						},
				RenderInner_Size	=	1.2,
				Beta_Inner3D	=	true,
					},
				{
				UseBlinkers	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(36.959999084473,114,35.590000152588),
				UseDynamic	=	true,
				RenderInner	=	true,
				Sprite	=	{
					Size	=	0.4,
						},
				RenderInner_Size	=	1.2,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.45,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.45,
						},
				UseDynamic	=	true,
				UseRunning	=	true,
				UseSprite	=	true,
				RunningColor	=	{
						190.98,
						199.58,
						237.91,
						},
				Pos	=	Vector(19.379999160767,126.01999664307,36.349998474121),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	1.2,
						},
				ProjTexture	=	{
					Forward	=	30,
					Size	=	2024,
					Angle	=	Angle(0,90,0),
						},
				UseHead	=	true,
				UsePrjTex	=	true,
				Pos	=	Vector(26.610000610352,124.86000061035,36.040000915527),
				UseDynamic	=	true,
				HeadColor	=	{
						194,
						233,
						255,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.6,
						},
				UseSprite	=	true,
					},
				},
		Date	=	"06/30/15 19:35:03",
		Author	=	"freemmaann (STEAM_0:1:14528726)",
}