VCModels['models/creator_2013vehiclesopel_insignia_2017.mdl']	=	{
		em_state	=	5236594461,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		HealthEnginePosOvr	=	true,
		Date	=	"Sun Apr  5 19:58:36 2020",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-76.099998474121,6.3000001907349),
				Pos	=	Vector(23.25,-113.40000152588,20.170000076294),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-103.90000152588,6.3000001907349),
				Pos	=	Vector(-23.25,-113.40000152588,20.170000076294),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(17.690000534058,8.3299999237061,34.75),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(-17.690000534058,-33.459999084473,34.909999847412),
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(17.690000534058,-33.459999084473,34.909999847412),
					},
				},
		HealthEnginePos	=	Vector(0,83.629997253418,49.959999084473),
		DLT	=	3491062974,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.0778,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				DD_Blnk_Run	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseBlinkers	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-24.510000228882,105.65000152588,39.479999542236),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	11,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-31.700000762939,99.940002441406,40.490001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-36.310001373291,94.400001525879,41.119998931885),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-38.169998168945,90.029998779297,41.290000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.0778,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				DD_Blnk_Run	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseBlinkers	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(24.510000228882,105.65000152588,39.479999542236),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	11,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(31.700000762939,99.940002441406,40.490001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(36.310001373291,94.400001525879,41.119998931885),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(38.169998168945,90.029998779297,41.290000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.4762,
					Size	=	0.0654,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				DD_Blnk_Run	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseBlinkers	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-38.430000305176,92.430000305176,37.759998321533),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	6,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-38.580001831055,91.419998168945,39.5),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-38.450000762939,90.650001525879,40.529998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-38.450000762939,90.290000915527,40.970001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.4762,
					Size	=	0.0654,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				DD_Blnk_Run	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseBlinkers	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(38.430000305176,92.430000305176,37.759998321533),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	6,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(38.580001831055,91.419998168945,39.5),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(38.450000762939,90.650001525879,40.529998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(38.450000762939,90.290000915527,40.970001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.0778,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				DD_Blnk_Run	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseBlinkers	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-23.840000152588,105.65000152588,39.909999847412),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	11,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-31.030000686646,99.940002441406,41.049999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-35.349998474121,94.400001525879,41.689998626709),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-37.5,90.029998779297,42.009998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-38.759998321533,86.519996643066,42.150001525879),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.0778,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				DD_Blnk_Run	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseBlinkers	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(23.840000152588,105.65000152588,39.909999847412),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	11,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(31.030000686646,99.940002441406,41.049999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(35.349998474121,94.400001525879,41.689998626709),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(37.5,90.029998779297,42.009998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(38.759998321533,86.519996643066,42.150001525879),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.4762,
					Size	=	0.0654,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				DD_Blnk_Run	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseBlinkers	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-38.930000305176,91.349998474121,38.009998321533),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	7,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-39.180000305176,89.48999786377,39.720001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-39.119998931885,88.209999084473,40.779998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-38.950000762939,86.699996948242,42.090000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1.4762,
					Size	=	0.0654,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				DD_Blnk_Run	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseBlinkers	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(38.930000305176,91.349998474121,38.009998321533),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	7,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(39.180000305176,89.48999786377,39.720001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(39.119998931885,88.209999084473,40.779998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(38.950000762939,86.699996948242,42.090000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2011,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-33.560001373291,93.529998779297,37.349998474121),
					Pos2	=	Vector(-37.099998474121,93.529998779297,40.459999084473),
					Color	=	{
						r	=	195,
						b	=	225,
						a	=	255,
						g	=	195,
							},
					Use	=	true,
					Pos1	=	Vector(-33.560001373291,93.529998779297,40.459999084473),
					Pos3	=	Vector(-37.099998474121,93.529998779297,37.349998474121),
						},
				HBeamColor	=	{
					r	=	195,
					b	=	225,
					a	=	255,
					g	=	195,
						},
				UseSprite	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	225,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				UsePrjTex	=	true,
				Pos	=	Vector(-35.520000457764,93.529998779297,38.880001068115),
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2011,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(33.560001373291,93.529998779297,37.349998474121),
					Pos2	=	Vector(37.099998474121,93.529998779297,40.459999084473),
					Color	=	{
						r	=	195,
						b	=	225,
						a	=	255,
						g	=	195,
							},
					Use	=	true,
					Pos1	=	Vector(33.560001373291,93.529998779297,40.459999084473),
					Pos3	=	Vector(37.099998474121,93.529998779297,37.349998474121),
						},
				HBeamColor	=	{
					r	=	195,
					b	=	225,
					a	=	255,
					g	=	195,
						},
				UseSprite	=	true,
				Pos	=	Vector(35.520000457764,93.529998779297,38.880001068115),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	225,
					a	=	255,
					g	=	195,
						},
				UsePrjTex	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2006,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-29.120000839233,98.529998779297,37.169998168945),
					Pos2	=	Vector(-31.829999923706,98.529998779297,39.560001373291),
					Color	=	{
						r	=	195,
						b	=	225,
						a	=	255,
						g	=	195,
							},
					Use	=	true,
					Pos1	=	Vector(-29.120000839233,98.529998779297,39.560001373291),
					Pos3	=	Vector(-31.829999923706,98.529998779297,37.169998168945),
						},
				HBeamColor	=	{
					r	=	195,
					b	=	225,
					a	=	255,
					g	=	195,
						},
				UseSprite	=	true,
				Pos	=	Vector(-30.670000076294,98.529998779297,38.340000152588),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UsePrjTex	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2006,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(29.120000839233,98.529998779297,37.169998168945),
					Pos2	=	Vector(31.829999923706,98.529998779297,39.560001373291),
					Color	=	{
						r	=	195,
						b	=	225,
						a	=	255,
						g	=	195,
							},
					Use	=	true,
					Pos1	=	Vector(29.120000839233,98.529998779297,39.560001373291),
					Pos3	=	Vector(31.829999923706,98.529998779297,37.169998168945),
						},
				HBeamColor	=	{
					r	=	195,
					b	=	225,
					a	=	255,
					g	=	195,
						},
				UsePrjTex	=	true,
				Pos	=	Vector(30.670000076294,98.529998779297,38.340000152588),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2006,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-26.209999084473,99.279998779297,37),
					Pos2	=	Vector(-28.920000076294,99.279998779297,39.389999389648),
					Color	=	{
						r	=	195,
						b	=	225,
						a	=	255,
						g	=	195,
							},
					Use	=	true,
					Pos1	=	Vector(-26.209999084473,99.279998779297,39.389999389648),
					Pos3	=	Vector(-28.920000076294,99.279998779297,37),
						},
				HBeamColor	=	{
					r	=	195,
					b	=	225,
					a	=	255,
					g	=	195,
						},
				UsePrjTex	=	true,
				Pos	=	Vector(-27.760000228882,99.279998779297,38.169998168945),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2006,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(26.209999084473,99.279998779297,37),
					Pos2	=	Vector(28.920000076294,99.279998779297,39.389999389648),
					Color	=	{
						r	=	195,
						b	=	225,
						a	=	255,
						g	=	195,
							},
					Use	=	true,
					Pos1	=	Vector(26.209999084473,99.279998779297,39.389999389648),
					Pos3	=	Vector(28.920000076294,99.279998779297,37),
						},
				HBeamColor	=	{
					r	=	195,
					b	=	225,
					a	=	255,
					g	=	195,
						},
				UsePrjTex	=	true,
				Pos	=	Vector(27.760000228882,99.279998779297,38.169998168945),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1307,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseBrake	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				UseSprite	=	true,
				Pos	=	Vector(-8.8699998855591,-69.019996643066,67.819999694824),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(8.8699998855591,-69.019996643066,67.819999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1012,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseSprite	=	true,
				Pos	=	Vector(-42.979999542236,49.569999694824,40.340000152588),
				UseBlinkers	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	9,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-43.040000915527,46.240001678467,40.630001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1012,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseSprite	=	true,
				Pos	=	Vector(42.979999542236,49.569999694824,40.340000152588),
				UseBlinkers	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	9,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(43.040000915527,46.240001678467,40.630001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				Dynamic	=	{
					Size	=	0.8,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-31.39999961853,100.88999938965,20.579999923706),
					UseColor	=	true,
					Pos2	=	Vector(-39.049999237061,93.330001831055,23.25),
					Color	=	{
						r	=	255,
						b	=	100,
						a	=	255,
						g	=	175,
							},
					Use	=	true,
					Pos1	=	Vector(-28.780000686646,102.84999847412,22.360000610352),
					Pos3	=	Vector(-39,93.330001831055,20.770000457764),
						},
				FogColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				UseSprite	=	true,
				Pos	=	Vector(-34.790000915527,94.830001831055,22.25),
				UseDynamic	=	true,
				UseFog	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UsePrjTex	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				Dynamic	=	{
					Size	=	0.8,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(31.39999961853,100.88999938965,20.579999923706),
					UseColor	=	true,
					Pos2	=	Vector(39.049999237061,93.330001831055,23.25),
					Color	=	{
						r	=	255,
						b	=	100,
						a	=	255,
						g	=	175,
							},
					Use	=	true,
					Pos1	=	Vector(28.780000686646,102.84999847412,22.360000610352),
					Pos3	=	Vector(39,93.330001831055,20.770000457764),
						},
				FogColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				UseSprite	=	true,
				Pos	=	Vector(34.790000915527,94.830001831055,22.25),
				UseDynamic	=	true,
				UseFog	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UsePrjTex	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseSprite	=	true,
				Pos	=	Vector(-29.969999313354,-106.98000335693,46.360000610352),
				UseDynamic	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-27.579999923706,-108.19999694824,44.619998931885),
					UseColor	=	true,
					Pos2	=	Vector(-32.75,-105.73999786377,47.580001831055),
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	155,
							},
					Use	=	true,
					Pos1	=	Vector(-28.299999237061,-107.91999816895,47.810001373291),
					Pos3	=	Vector(-32.020000457764,-106.87000274658,44.290000915527),
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(27.579999923706,-108.19999694824,44.619998931885),
					UseColor	=	true,
					Pos2	=	Vector(32.75,-105.73999786377,47.580001831055),
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	155,
							},
					Use	=	true,
					Pos1	=	Vector(28.299999237061,-107.91999816895,47.810001373291),
					Pos3	=	Vector(32.020000457764,-106.87000274658,44.290000915527),
						},
				UseSprite	=	true,
				Pos	=	Vector(29.969999313354,-106.98000335693,46.360000610352),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				UseBrake	=	true,
				SpecMat	=	{
					Select	=	15,
					New	=	"models/creator_2013/vcmod/debugdrawflat",
					Use	=	true,
						},
				UseSprite	=	true,
				Pos	=	Vector(-33.529998779297,-104.56999969482,48.840000152588),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	5,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-28.930000305176,-106.7799987793,48.840000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				UseBrake	=	true,
				SpecMat	=	{
					Select	=	14,
					New	=	"models/creator_2013/vcmod/debugdrawflat",
					Use	=	true,
						},
				UseSprite	=	true,
				Pos	=	Vector(33.529998779297,-104.56999969482,48.840000152588),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	5,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(28.930000305176,-106.7799987793,48.840000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				SpecMat	=	{
					Select	=	6,
					New	=	"models/creator_2013/vcmod/debugdrawflat",
					Use	=	true,
						},
				UseSprite	=	true,
				Pos	=	Vector(-33.430000305176,-106.11000061035,45.279998779297),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	8,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-34.080001831055,-104.69000244141,48.759998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-29.069999694824,-107.38999938965,48.930000305176),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				SpecMat	=	{
					Select	=	8,
					New	=	"models/creator_2013/vcmod/debugdrawflat",
					Use	=	true,
						},
				UseSprite	=	true,
				Pos	=	Vector(33.430000305176,-106.11000061035,45.279998779297),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	8,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(34.080001831055,-104.69000244141,48.759998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(29.069999694824,-107.38999938965,48.930000305176),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				SpecMat	=	{
					Use	=	true,
					New	=	"models/creator_2013/vcmod/debugdrawflat",
					Select	=	7,
						},
				UseSprite	=	true,
				Pos	=	Vector(-27.280000686646,-107.91999816895,48.790000915527),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-16.129999160767,-111.05999755859,48.409999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				SpecMat	=	{
					Use	=	true,
					New	=	"models/creator_2013/vcmod/debugdrawflat",
					Select	=	9,
						},
				UseSprite	=	true,
				Pos	=	Vector(27.280000686646,-107.91999816895,48.790000915527),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(16.129999160767,-111.05999755859,48.409999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-22.5,-108.58999633789,44.619998931885),
					UseColor	=	true,
					Pos2	=	Vector(-27.020000457764,-107.61000061035,47.729999542236),
					Color	=	{
						r	=	220,
						b	=	255,
						a	=	255,
						g	=	225,
							},
					Use	=	true,
					Pos1	=	Vector(-23.069999694824,-108.75,47.810001373291),
					Pos3	=	Vector(-26.049999237061,-107.91999816895,45.360000610352),
						},
				UseSprite	=	true,
				Pos	=	Vector(-24.739999771118,-107.80999755859,46.360000610352),
				UseDynamic	=	true,
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(22.5,-108.58999633789,44.619998931885),
					UseColor	=	true,
					Pos2	=	Vector(27.020000457764,-107.61000061035,47.729999542236),
					Color	=	{
						r	=	220,
						b	=	255,
						a	=	255,
						g	=	225,
							},
					Use	=	true,
					Pos1	=	Vector(23.069999694824,-108.75,47.810001373291),
					Pos3	=	Vector(26.049999237061,-107.91999816895,45.360000610352),
						},
				UseSprite	=	true,
				Pos	=	Vector(24.739999771118,-107.80999755859,46.360000610352),
				UseDynamic	=	true,
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2495,
						},
				Dynamic	=	{
					Size	=	0.3978,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-18.409999847412,-110.41999816895,45.880001068115),
					UseColor	=	true,
					Pos2	=	Vector(-22.930000305176,-108.58000183105,47.759998321533),
					Color	=	{
						r	=	220,
						b	=	255,
						a	=	255,
						g	=	225,
							},
					Use	=	true,
					Pos1	=	Vector(-16.85000038147,-110.62999725342,47.610000610352),
					Pos3	=	Vector(-22.530000686646,-108.88999938965,45.389999389648),
						},
				FogColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseSprite	=	true,
				Pos	=	Vector(-20.64999961853,-108.7799987793,46.389999389648),
				UseDynamic	=	true,
				UseFog	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2495,
						},
				Dynamic	=	{
					Size	=	0.3978,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(18.409999847412,-110.41999816895,45.880001068115),
					UseColor	=	true,
					Pos2	=	Vector(22.930000305176,-108.58000183105,47.759998321533),
					Color	=	{
						r	=	220,
						b	=	255,
						a	=	255,
						g	=	225,
							},
					Use	=	true,
					Pos1	=	Vector(16.85000038147,-110.62999725342,47.610000610352),
					Pos3	=	Vector(22.530000686646,-108.88999938965,45.389999389648),
						},
				FogColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseSprite	=	true,
				Pos	=	Vector(20.64999961853,-108.7799987793,46.389999389648),
				UseDynamic	=	true,
				UseFog	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
					},
				},
		Copyright	=	"Copyright © 2020 VCMod (freemmaann). All Rights Reserved.",
		Fuel	=	{
			FuelType	=	0,
			FuelLidUse	=	true,
			FuelLidPos	=	Vector(40.990001678467,-72,47.590000152588),
				},
		Author	=	"creator_2013 (76561198254696984)",
}