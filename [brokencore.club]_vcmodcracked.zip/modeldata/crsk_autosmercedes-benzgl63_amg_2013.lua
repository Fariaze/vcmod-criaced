VCModels['models/crsk_autosmercedes-benzgl63_amg_2013.mdl']	=	{
		em_state	=	5236594419,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		HealthEnginePosOvr	=	true,
		Date	=	"Tue Jan 23 08:14:31 2018",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(33.470001220703,-136.66999816895,16.760000228882),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-33.849998474121,-136.66999816895,16.870000839233),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(27.590000152588,-138.49000549316,16.89999961853),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-28.10000038147,-138.4700012207,17.040000915527),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		Indication	=	{
			speedo_kmph	=	{
				max	=	1,
				pp	=	"vehicle_guage",
				min	=	0,
				top	=	200,
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(20,0,0),
				Pos	=	Vector(20.299999237061,8.9200000762939,43.029998779297),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(7,0,0),
				Pos	=	Vector(21.799999237061,-45.439998626709,40.529998779297),
					},
				{
				Ang	=	Angle(7,0,0),
				Pos	=	Vector(1.7999999523163,-45.439998626709,40.529998779297),
					},
				{
				Ang	=	Angle(7,0,0),
				Pos	=	Vector(-18.200000762939,-45.439998626709,40.529998779297),
					},
				},
		HealthEnginePos	=	Vector(0,75,49),
		DLT	=	3491062946,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderGlow_Size	=	0.3737,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-12.689999580383,-124.66000366211,78.730003356934),
				UseSprite	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-0.60000002384186,-125.38999938965,78.870002746582),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(12.470000267029,-124.65000152588,78.639999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderHD_Adv	=	true,
				RenderInner_Size	=	1,
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				UseDynamic	=	true,
				ReverseColor	=	{
					r	=	200,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner_Clr	=	{
					r	=	200,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(24.430000305176,-131.94000244141,43.700000762939),
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	15,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(28.610000610352,-131.00999450684,43.700000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Size	=	1,
				Beta_Inner3D	=	true,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.08,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderGlow_Size	=	0.3737,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(46.880001068115,26.629999160767,55.25),
				RenderMLCenter	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(48.459999084473,25.520000457764,55.270000457764),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(49.470001220703,24.780000686646,55.299999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(50.529998779297,23.829999923706,55.319999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(51.419998168945,22.629999160767,55.340000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(51.770000457764,21.430000305176,55.380001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(51.840000152588,19.440000534058,55.439998626709),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(51.520000457764,19.610000610352,56.880001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(51.580001831055,20.930000305176,56.819999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(51.599998474121,21.709999084473,56.799999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(51.110000610352,22.569999694824,56.759998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(50.549999237061,23.440000534058,56.740001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(49.450000762939,24.430000305176,56.689998626709),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(47.849998474121,25.450000762939,56.669998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Size	=	1,
				Beta_Inner3D	=	true,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.03,
						},
				SpecSpin	=	{
						},
				DD_HD	=	true,
				UseDynamic	=	true,
				RenderGlow_Size	=	0.3737,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(51.669998168945,20.200000762939,56.110000610352),
				RenderInner	=	true,
				UseBlinkers	=	true,
				RenderInner_Size	=	2,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.16,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderGlow_Size	=	0.3737,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.5597,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(30.309999465942,101.05999755859,26.25),
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	7,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(32.220001220703,100.51999664307,26.35000038147),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(33.939998626709,99.910003662109,26.459999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(35.689998626709,99.209999084473,26.530000686646),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(37.529998779297,98.309997558594,26.590000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(39.090000152588,97.410003662109,26.639999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(40.360000610352,96.360000610352,26.670000076294),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner	=	true,
				RunningColor	=	{
					r	=	198,
					b	=	234,
					a	=	255,
					g	=	200,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.08,
						},
				SpecSpin	=	{
						},
				DD_Blnk_Run	=	true,
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(39.479999542236,86.26000213623,45.060001373291),
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	60,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(37.889999389648,89,44.599998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(36.119998931885,91.180000305176,44.169998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(33.720001220703,93.589996337891,43.569999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(31.639999389648,95.559997558594,42.919998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(30.520000457764,96.830001831055,42.009998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(29.829999923706,97.769996643066,40.540000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(28.979999542236,98.699996948242,38.509998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(27.870000839233,99.559997558594,35.659999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.03,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	225,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	10,
					Use	=	true,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				HBeamColor	=	{
					r	=	195,
					b	=	225,
					a	=	255,
					g	=	195,
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(38.509998321533,89.26000213623,40.580001831055),
				RenderInner	=	true,
				UseHighBeams	=	true,
				RenderInner_Size	=	4,
				UseSprite	=	true,
				SpecMat	=	{
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	4.0227,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	1.6791,
					Brightness	=	2,
						},
				HBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				ReducedVis	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(32.680000305176,91.930000305176,37.479999542236),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Size	=	1,
				Beta_Inner3D	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderGlow_Size	=	0.3737,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(37.069999694824,-130.17999267578,49.770000457764),
				UseSprite	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	40,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(38.349998474121,-129.0299987793,49.770000457764),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(39.990001678467,-127.05000305176,49.770000457764),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(41.509998321533,-124.23000335693,49.770000457764),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(41.779998779297,-122.5299987793,49.790000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(41.919998168945,-121.69999694824,49.880001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(42.049999237061,-120.87000274658,50.099998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(41.729999542236,-121.83999633789,50.740001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(41.400001525879,-122.91000366211,51.290000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(40.840000152588,-124.18000030518,51.630001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(40.279998779297,-125.44000244141,51.880001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(39.360000610352,-126.73999786377,51.919998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(38.439998626709,-128.0299987793,51.909999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(37.259998321533,-129.24000549316,51.819999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseBlinkers	=	true,
				RenderInner_Size	=	1,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.0758,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderGlow_Size	=	0.3737,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	117,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(35.729999542236,-130.57000732422,44.680000305176),
				RenderMLCenter	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	40,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(36.979999542236,-130.08999633789,44.669998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(37.549999237061,-129.75,44.659999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(38.080001831055,-129.36000061035,44.669998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(38.819999694824,-128.63000488281,44.709999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(39.450000762939,-127.83000183105,44.779998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(39.970001220703,-126.98000335693,44.889999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(40.400001525879,-126.2200012207,45.099998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(40.830001831055,-125.45999908447,45.400001525879),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(41.139999389648,-124.83000183105,45.790000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(41.540000915527,-123.7200012207,46.779998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.0758,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderGlow_Size	=	0.3737,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	117,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(36.080001831055,-130.55999755859,47.049999237061),
				RenderMLCenter	=	true,
				RenderInner_Size	=	1.3,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(37.279998779297,-129.99000549316,47.029998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(38.349998474121,-129.19000244141,47.009998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(38.900001525879,-128.61000061035,47),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(39.349998474121,-127.98999786377,47),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(40.090000152588,-126.83000183105,47),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(40.790000915527,-125.56999969482,47),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(41.25,-124.61000061035,47),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(41.540000915527,-123.56999969482,47),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.0758,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderGlow_Size	=	0.3737,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	117,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(26.309999465942,-133.42999267578,46.919998168945),
				RenderMLCenter	=	true,
				RenderInner_Size	=	1.1,
				SpecMLine	=	{
					Amount	=	40,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(31.260000228882,-132.24000549316,47.029998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(34.459999084473,-131.35000610352,47.090000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.0758,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderGlow_Size	=	0.3737,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	117,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(25.809999465942,-133.36999511719,45.060001373291),
				RenderMLCenter	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	40,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(30.459999084473,-132.42999267578,44.919998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(34.169998168945,-131.55999755859,44.840000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				UseDynamic	=	true,
				ReverseColor	=	{
					r	=	200,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner_Clr	=	{
					r	=	200,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(27.450000762939,-132.38999938965,49.720001220703),
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(30.440000534058,-131.80000305176,50.139999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Size	=	1,
				RenderHD_Size	=	0.2,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.08,
						},
				SpecSpin	=	{
						},
				DD_Blnk_Run	=	true,
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-39.319999694824,86.5,45.360000610352),
				RenderInner_Size	=	1,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	60,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-37.729999542236,89.23999786377,44.900001525879),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-35.959999084473,91.419998168945,44.430000305176),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-33.590000152588,93.830001831055,43.830001831055),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-31.5,95.790000915527,43.189998626709),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-30.370000839233,97.069999694824,42.290000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-29.510000228882,98.040000915527,40.939998626709),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-28.670000076294,98.959999084473,38.819999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-27.540000915527,99.900001525879,36.009998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseSprite	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.16,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderGlow_Size	=	0.3737,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.5597,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-29.860000610352,101.66000366211,26.409999847412),
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	7,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-31.729999542236,101.05000305176,26.510000228882),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-33.409999847412,100.44000244141,26.60000038147),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-35.150001525879,99.669998168945,26.690000534058),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-36.959999084473,98.819999694824,26.75),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-38.560001373291,97.919998168945,26.809999465942),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-39.869998931885,96.839996337891,26.829999923706),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner	=	true,
				RunningColor	=	{
					r	=	198,
					b	=	234,
					a	=	255,
					g	=	200,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	4.0227,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	1.6791,
					Brightness	=	2,
						},
				HBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				ReducedVis	=	true,
				UseHighBeams	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-32.25,92.059997558594,37.590000152588),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	225,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderHD_Size	=	2,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(38.509998321533,89.76000213623,40.580001831055),
				RenderInner_Size	=	1,
				HBeamColor	=	{
					r	=	195,
					b	=	225,
					a	=	255,
					g	=	195,
						},
				UseSprite	=	true,
				RenderInner	=	true,
				ProjTexture	=	{
					Size	=	2000,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.03,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	225,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	10,
					Use	=	true,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				HBeamColor	=	{
					r	=	195,
					b	=	225,
					a	=	255,
					g	=	195,
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-37.959999084473,89.559997558594,40.700000762939),
				RenderInner	=	true,
				UseHighBeams	=	true,
				SpecMat	=	{
						},
				UseSprite	=	true,
				RenderInner_Size	=	4,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	225,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderHD_Size	=	2,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				HBeamColor	=	{
					r	=	195,
					b	=	225,
					a	=	255,
					g	=	195,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-37.959999084473,90.059997558594,40.700000762939),
				RenderInner_Size	=	1,
				SpecMat	=	{
						},
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				ProjTexture	=	{
					Size	=	2000,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.08,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderGlow_Size	=	0.3737,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-46.549999237061,26.870000839233,55.470001220703),
				RenderMLCenter	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-48.130001068115,25.760000228882,55.490001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-49.139999389648,25.020000457764,55.520000457764),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-50.200000762939,24.069999694824,55.540000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-51.090000152588,22.870000839233,55.560001373291),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-51.439998626709,21.670000076294,55.599998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-51.509998321533,19.680000305176,55.659999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-51.189998626709,19.85000038147,57.099998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-51.25,21.170000076294,57.040000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-51.270000457764,21.950000762939,57.020000457764),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-50.779998779297,22.809999465942,56.979999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-50.220001220703,23.680000305176,56.959999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-49.119998931885,24.670000076294,56.909999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-47.520000457764,25.690000534058,56.889999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.03,
						},
				SpecSpin	=	{
						},
				DD_HD	=	true,
				UseDynamic	=	true,
				RenderGlow_Size	=	0.3737,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-51.490001678467,20.329999923706,56.360000610352),
				RenderInner_Size	=	2,
				UseBlinkers	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.0758,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderGlow_Size	=	0.3737,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	117,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-36.020000457764,-130.44999694824,44.869998931885),
				RenderMLCenter	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	40,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-37.270000457764,-129.9700012207,44.860000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-37.840000152588,-129.63000488281,44.849998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-38.380001068115,-129.24000549316,44.860000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-39.110000610352,-128.50999450684,44.900001525879),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-39.740001678467,-127.70999908447,44.970001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-40.259998321533,-126.86000061035,45.080001831055),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-40.689998626709,-126.09999847412,45.290000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-41.119998931885,-125.33999633789,45.590000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-41.459999084473,-124.66000366211,45.959999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-41.979999542236,-123.51999664307,47.009998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.08,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderGlow_Size	=	0.3737,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	117,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-36.430000305176,-130.41000366211,47.240001678467),
				RenderMLCenter	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-37.630001068115,-129.83999633789,47.220001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-38.700000762939,-129.03999328613,47.200000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-39.25,-128.46000671387,47.189998626709),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-39.700000762939,-127.83999633789,47.189998626709),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-40.450000762939,-126.63999938965,47.189998626709),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-41.169998168945,-125.37999725342,47.200000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-41.599998474121,-124.4700012207,47.209999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-41.889999389648,-123.41999816895,47.189998626709),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Size	=	1.2,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.0758,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderGlow_Size	=	0.3737,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	117,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-26.170000076294,-133.2799987793,45.220001220703),
				RenderMLCenter	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	40,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-30.819999694824,-132.33999633789,45.069999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-34.569999694824,-131.4700012207,44.959999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.0758,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderGlow_Size	=	0.3737,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	117,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-26.760000228882,-133.2799987793,47.049999237061),
				UseSprite	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	40,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-31.760000228882,-132.08999633789,47.189998626709),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-34.900001525879,-131.19999694824,47.259998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Size	=	1.1,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				UseDynamic	=	true,
				ReverseColor	=	{
					r	=	200,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner_Clr	=	{
					r	=	200,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-24.889999389648,-131.83000183105,43.799999237061),
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	15,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-29.079999923706,-130.88000488281,43.819999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner	=	true,
				RenderHD_Size	=	0.2,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				UseDynamic	=	true,
				RenderHD_Size	=	0.2,
				RenderInner_Clr	=	{
					r	=	200,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-27.909999847412,-132.33000183105,49.860000610352),
				ReverseColor	=	{
					r	=	200,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-30.89999961853,-131.63999938965,50.290000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderGlow_Size	=	0.3737,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-37.490001678467,-130.02000427246,49.970001220703),
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	40,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-38.770000457764,-128.86999511719,49.970001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-40.409999847412,-126.88999938965,49.970001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-41.930000305176,-124.06999969482,49.970001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-42.200000762939,-122.37000274658,49.990001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-42.340000152588,-121.54000091553,50.080001831055),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-42.470001220703,-120.70999908447,50.299999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-42.150001525879,-121.68000030518,50.939998626709),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-41.819999694824,-122.75,51.490001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-41.259998321533,-124.01999664307,51.830001831055),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-40.700000762939,-125.2799987793,52.080001831055),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-39.779998779297,-126.58000183105,52.119998931885),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-38.860000610352,-127.87000274658,52.110000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-37.680000305176,-129.08000183105,52.020000457764),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderMLCenter	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1,
						},
				SpecSpin	=	{
						},
				UseBrake	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-38.639999389648,-127.45999908447,46.090000152588),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	189,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1,
						},
				SpecSpin	=	{
						},
				UseBrake	=	true,
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				UseSprite	=	true,
				Pos	=	Vector(39.139999389648,-128.11999511719,45.889999389648),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	189,
						},
				RenderInner_ClrUse	=	true,
					},
				},
		Copyright	=	"Copyright © 2012-2018 VCMod (freemmaann). All Rights Reserved.",
		Fuel	=	{
			FuelLidPos	=	Vector(44.970001220703,-93.339996337891,48.740001678467),
			FuelType	=	0,
			Capacity	=	100,
			Override	=	true,
			FuelLidUse	=	true,
				},
		Author	=	"CrushingSkirmish (76561198017348899)",
}