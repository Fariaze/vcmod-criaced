VCModels['models/black_mesa_vehicleslav.mdl']	=	{
		em_state	=	5236594926,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Copyright	=	"Copyright © 2012-2019 VCMod (freemmaann). All Rights Reserved.",
		Exhaust	=	{
				{
				Ang	=	Angle(35,-45,0),
				Pos	=	Vector(47.299999237061,-26.879999160767,69.089996337891),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		Light_DD_Int	=	true,
		forcedView	=	3,
		ExtraSeats	=	{
				{
				Pos	=	Vector(14.609999656677,82.430000305176,52.090000152588),
				DoorSounds	=	true,
				Ang	=	Angle(0,0,0),
				EnterRange	=	80,
				RadioControl	=	true,
					},
				},
		DLT	=	3491063284,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				UseBrake	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-39.900001525879,-108.83999633789,60.049999237061),
				UseDynamic	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.6,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.6,
						},
				UseDynamic	=	true,
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseSprite	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				Pos	=	Vector(-35.400001525879,135.13999938965,62.709999084473),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				ProjTexture	=	{
					Size	=	2024,
					Angle	=	Angle(0,90,0),
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-27.819999694824,132.69999694824,66.73999786377),
					Pos2	=	Vector(-35.740001678467,132.69999694824,74.660003662109),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-27.819999694824,132.69999694824,74.660003662109),
					Pos3	=	Vector(-35.740001678467,132.69999694824,66.73999786377),
						},
				HBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseSprite	=	true,
				LBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.6,
						},
				UsePrjTex	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				Pos	=	Vector(-31.780000686646,132.69999694824,70.699996948242),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.6,
						},
				UseSprite	=	true,
				Pos	=	Vector(41.599998474121,-108.83999633789,60.049999237061),
				UseDynamic	=	true,
				UseBrake	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.6,
						},
				UseDynamic	=	true,
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseSprite	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				Pos	=	Vector(37.849998474121,135.13999938965,62.709999084473),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				ProjTexture	=	{
					Size	=	2024,
					Angle	=	Angle(0,90,0),
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(30.60000038147,132.69999694824,66.73999786377),
					Pos2	=	Vector(38.520000457764,132.69999694824,74.660003662109),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(30.60000038147,132.69999694824,74.660003662109),
					Pos3	=	Vector(38.520000457764,132.69999694824,66.73999786377),
						},
				HBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseSprite	=	true,
				LBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.6,
						},
				UsePrjTex	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				Pos	=	Vector(34.560001373291,132.69999694824,70.699996948242),
					},
				},
		Date	=	"Wed May  1 13:49:17 2019",
		Fuel	=	{
			FuelType	=	1,
			Capacity	=	269,
			Override	=	true,
			FuelTypeUse	=	true,
				},
		Author	=	"TheCarson116 (76561198123551419)",
}