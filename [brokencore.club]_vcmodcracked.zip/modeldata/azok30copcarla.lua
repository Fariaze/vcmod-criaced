VCModels['models/azok30copcarla.mdl']	=	{
		em_state	=	5236594344,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Siren	=	{
			Sounds	=	{
					{
					Volume	=	1,
					Pitch	=	100,
					Distance	=	95,
					Name	=	"Wail",
					Sound	=	"vcmod/els/smartsiren/wail.wav",
						},
					{
					Volume	=	1,
					Pitch	=	100,
					Distance	=	95,
					Name	=	"Yelp",
					Sound	=	"vcmod/els/smartsiren/yelp.wav",
						},
					{
					Volume	=	1,
					Pitch	=	100,
					Distance	=	95,
					Name	=	"Priority",
					Sound	=	"vcmod/els/smartsiren/priority.wav",
						},
					},
			Lights	=	{
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.4,
							},
					Dynamic	=	{
						Size	=	1,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-32.819999694824,-16.10000038147,78.449996948242),
					UseDynamic	=	true,
					SpecMLine	=	{
						Amount	=	37,
						Use	=	true,
						LTbl	=	{
								{
								Pos	=	Vector(-11.689999580383,-16.319999694824,78.110000610352),
								UseClr	=	true,
								Clr	=	{
									r	=	219,
									b	=	0,
									a	=	255,
									g	=	47,
										},
									},
								},
							},
					UseSprite	=	true,
					SpecModel	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
						scale	=	1,
						scaleVector	=	Vector(1000,1000,1000),
							},
					Color	=	{
						r	=	0,
						b	=	255,
						a	=	255,
						g	=	55,
							},
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.4,
							},
					Dynamic	=	{
						Size	=	1,
						Brightness	=	2,
							},
					UseSprite	=	true,
					Pos	=	Vector(32.819999694824,-16.10000038147,78.449996948242),
					UseDynamic	=	true,
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	55,
							},
					RenderHD_Adv	=	true,
					SpecModel	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
						scale	=	1,
						scaleVector	=	Vector(1000,1000,1000),
							},
					SpecMLine	=	{
						Amount	=	37,
						Use	=	true,
						LTbl	=	{
								{
								Pos	=	Vector(11.689999580383,-16.319999694824,78.110000610352),
								UseClr	=	true,
								Clr	=	{
									r	=	219,
									b	=	0,
									a	=	255,
									g	=	47,
										},
									},
								},
							},
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.4,
							},
					Dynamic	=	{
						Size	=	1,
						Brightness	=	2,
							},
					UseSprite	=	true,
					Pos	=	Vector(-13.369999885559,122.31999969482,26.729999542236),
					UseDynamic	=	true,
					SpecMLine	=	{
						Amount	=	37,
						Use	=	true,
						LTbl	=	{
								{
								Pos	=	Vector(-9.6599998474121,122.09999847412,26.389999389648),
								UseClr	=	false,
								Clr	=	{
									r	=	0,
									b	=	0,
									a	=	255,
									g	=	0,
										},
									},
								},
							},
					Color	=	{
						r	=	0,
						b	=	255,
						a	=	255,
						g	=	55,
							},
					SpecModel	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
						scale	=	1,
						scaleVector	=	Vector(1000,1000,1000),
							},
					RenderHD_Adv	=	true,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.4,
							},
					Dynamic	=	{
						Size	=	1,
						Brightness	=	2,
							},
					UseSprite	=	true,
					Pos	=	Vector(13.369999885559,122.31999969482,26.729999542236),
					UseDynamic	=	true,
					SpecMLine	=	{
						Amount	=	37,
						Use	=	true,
						LTbl	=	{
								{
								Pos	=	Vector(9.6599998474121,122.09999847412,26.389999389648),
								UseClr	=	false,
								Clr	=	{
									r	=	0,
									b	=	0,
									a	=	255,
									g	=	0,
										},
									},
								},
							},
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	55,
							},
					SpecModel	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
						scale	=	1,
						scaleVector	=	Vector(1000,1000,1000),
							},
					RenderHD_Adv	=	true,
						},
					},
			Sounds_Horn	=	{
				Use	=	true,
				Volume	=	1,
				Distance	=	95,
				Pitch	=	100,
				Sound	=	"vcmod/els/smartsiren/horn.wav",
					},
			Sequences	=	{
					{
					SubSeq	=	{
							{
							Stages	=	{
									{
									Lights	=	{
											1,
											3,
											},
									Time	=	0.2,
										},
									{
									Lights	=	{
											2,
											4,
											},
									Time	=	0.2,
										},
									},
							Time	=	5,
							Type	=	"Each side",
								},
							},
					Codes	=	{
							true,
							},
					Lights_Sel	=	{
							true,
							true,
							true,
							true,
							},
						},
					{
					SubSeq	=	{
							{
							Stages	=	{
									{
									Lights	=	{
											1,
											3,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											1,
											3,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											2,
											4,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											2,
											4,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									},
							Time	=	5,
							Type	=	"Each side, flash",
								},
							},
					Codes	=	{
						[2]	=	true,
							},
					Lights_Sel	=	{
							true,
							true,
							true,
							true,
							},
						},
					},
			Sounds_Manual	=	{
				Use	=	true,
				Volume	=	1,
				Distance	=	95,
				Pitch	=	100,
				Sound	=	"vcmod/els/smartsiren/manual.wav",
					},
				},
		Date	=	"Sat Apr 18 09:58:42 2020",
		hornData	=	{
			Volume	=	1,
			Distance	=	75,
			Pitch	=	100,
			Sound	=	"vcmod/els/smartsiren/horn.wav",
				},
		Exhaust	=	{
				{
				EffectStress	=	"VC_Exhaust_Stress",
				Invulnerable	=	true,
				EffectIdle	=	"VC_Exhaust",
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(26.85000038147,-119.93000030518,8.1999998092651),
					},
				},
		hornUseCustom	=	true,
		ExtraSeats	=	{
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(21.909999847412,9.8800001144409,29.360000610352),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(-27.409999847412,-35.139999389648,29.360000610352),
				Cant_Exit_Lock	=	true,
				Switch_Rear	=	true,
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(27.409999847412,-35.139999389648,29.360000610352),
				Cant_Exit_Lock	=	true,
				Switch_Rear	=	true,
					},
				{
				Ang	=	Angle(0,0,0),
				Cant_Exit_Lock	=	true,
				Pos	=	Vector(0,-35.139999389648,29.360000610352),
				Switch_Rear	=	true,
					},
				},
		DLT	=	3491062896,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				UseSprite	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Pos	=	Vector(-35.830001831055,104.55999755859,31.079999923706),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				HBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UsePrjTex	=	true,
				Pos	=	Vector(-35.830001831055,104.55999755859,31.079999923706),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-45.680000305176,103.04000091553,30.579999923706),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				RenderInner_Size	=	4,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-50.869998931885,96.129997253418,20.770000457764),
					Pos2	=	Vector(-50.849998474121,101.65000152588,22.770000457764),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-50.869998931885,96.129997253418,22.770000457764),
					Pos3	=	Vector(-50.849998474121,101.65000152588,20.770000457764),
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				UseSprite	=	true,
				Pos	=	Vector(-50.860000610352,98.639999389648,21.770000457764),
				UseDynamic	=	true,
				RenderInner_Size	=	4,
				UseBlinkers	=	true,
				RenderInner	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				UseSprite	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Pos	=	Vector(35.830001831055,104.55999755859,31.079999923706),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				HBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UsePrjTex	=	true,
				Pos	=	Vector(35.830001831055,104.55999755859,31.079999923706),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(45.680000305176,103.04000091553,30.579999923706),
				UseDynamic	=	true,
				RenderInner_Size	=	4,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(50.869998931885,96.129997253418,20.770000457764),
					Pos2	=	Vector(50.849998474121,101.65000152588,22.770000457764),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(50.869998931885,96.129997253418,22.770000457764),
					Pos3	=	Vector(50.849998474121,101.65000152588,20.770000457764),
						},
				UseBlinkers	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				UseSprite	=	true,
				Pos	=	Vector(50.860000610352,98.639999389648,21.770000457764),
				UseDynamic	=	true,
				RenderInner_Size	=	4,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RenderInner	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				UseSprite	=	true,
				Pos	=	Vector(-50.549999237061,-115.36000061035,20.870000839233),
				UseDynamic	=	true,
				RenderInner_Size	=	4,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-50.75,-112.34999847412,21.89999961853),
					Pos2	=	Vector(-50.349998474121,-117.87000274658,19.840000152588),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-50.330001831055,-112.34999847412,19.89999961853),
					Pos3	=	Vector(-50.770000457764,-117.87000274658,21.840000152588),
						},
				RenderInner	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-21.5,-125.73999786377,27.819999694824),
					UseColor	=	true,
					Pos2	=	Vector(-48.319999694824,-123.83999633789,36.419998168945),
					Color	=	{
						r	=	146,
						b	=	0,
						a	=	255,
						g	=	31,
							},
					Use	=	true,
					Pos1	=	Vector(-23.440000534058,-125.70999908447,36.419998168945),
					Pos3	=	Vector(-48.380001068115,-123.83999633789,28.319999694824),
						},
				UseSprite	=	true,
				Pos	=	Vector(-36.409999847412,-124.7799987793,32.119998931885),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseSprite	=	true,
				Pos	=	Vector(-48.919998168945,-122.09999847412,32.119998931885),
				UseDynamic	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-49.119998931885,-120.05999755859,36.669998168945),
					UseColor	=	true,
					Pos2	=	Vector(-46.529998779297,-123.75,28.069999694824),
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	155,
							},
					Use	=	true,
					Pos1	=	Vector(-49.520000457764,-119.81999969482,28.069999694824),
					Pos3	=	Vector(-46.979999542236,-123.2799987793,36.169998168945),
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-21.5,-125.73999786377,27.819999694824),
					UseColor	=	true,
					Pos2	=	Vector(-48.319999694824,-123.83999633789,36.419998168945),
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	54,
							},
					Use	=	true,
					Pos1	=	Vector(-23.440000534058,-125.70999908447,36.419998168945),
					Pos3	=	Vector(-48.380001068115,-123.83999633789,28.319999694824),
						},
				UseSprite	=	true,
				Pos	=	Vector(-36.409999847412,-124.7799987793,32.119998931885),
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseReverse	=	true,
				RenderInner	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				UseSprite	=	true,
				Pos	=	Vector(-22.940000534058,-125.08000183105,28.090000152588),
				UseDynamic	=	true,
				RenderInner_Size	=	3.0172,
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				SpecMLine	=	{
					Amount	=	6,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-25.120000839233,-124.95999908447,35.729999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				UseSprite	=	true,
				Pos	=	Vector(50.549999237061,-115.36000061035,20.870000839233),
				UseDynamic	=	true,
				RenderInner	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(50.75,-112.34999847412,21.89999961853),
					Pos2	=	Vector(50.349998474121,-117.87000274658,19.840000152588),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(50.330001831055,-112.34999847412,19.89999961853),
					Pos3	=	Vector(50.770000457764,-117.87000274658,21.840000152588),
						},
				RenderInner_Size	=	4,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(21.5,-125.73999786377,27.819999694824),
					UseColor	=	true,
					Pos2	=	Vector(48.319999694824,-123.83999633789,36.419998168945),
					Color	=	{
						r	=	146,
						b	=	0,
						a	=	255,
						g	=	31,
							},
					Use	=	true,
					Pos1	=	Vector(23.440000534058,-125.70999908447,36.419998168945),
					Pos3	=	Vector(48.380001068115,-123.83999633789,28.319999694824),
						},
				UseSprite	=	true,
				Pos	=	Vector(36.409999847412,-124.7799987793,32.119998931885),
				UseDynamic	=	true,
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseSprite	=	true,
				Pos	=	Vector(48.919998168945,-122.09999847412,32.119998931885),
				UseDynamic	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(49.119998931885,-120.05999755859,36.669998168945),
					UseColor	=	true,
					Pos2	=	Vector(46.529998779297,-123.75,28.069999694824),
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	155,
							},
					Use	=	true,
					Pos1	=	Vector(49.520000457764,-119.81999969482,28.069999694824),
					Pos3	=	Vector(46.979999542236,-123.2799987793,36.169998168945),
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				UseBrake	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(21.5,-125.73999786377,27.819999694824),
					UseColor	=	true,
					Pos2	=	Vector(48.319999694824,-123.83999633789,36.419998168945),
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	54,
							},
					Use	=	true,
					Pos1	=	Vector(23.440000534058,-125.70999908447,36.419998168945),
					Pos3	=	Vector(48.380001068115,-123.83999633789,28.319999694824),
						},
				UseSprite	=	true,
				Pos	=	Vector(36.409999847412,-124.7799987793,32.119998931885),
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseReverse	=	true,
				RenderInner	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				UseSprite	=	true,
				Pos	=	Vector(22.940000534058,-125.08000183105,28.090000152588),
				UseDynamic	=	true,
				RenderInner_Size	=	3.0172,
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				SpecMLine	=	{
					Amount	=	6,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(25.120000839233,-124.95999908447,35.729999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				},
		Copyright	=	"Copyright © 2020 VCMod (freemmaann). All Rights Reserved.",
		Fuel	=	{
			FuelType	=	0,
				},
		Author	=	"Azok30 - CODEMODELING.fr (76561198183398967)",
}