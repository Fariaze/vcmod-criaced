VCModels['models/black_mesa_vehiclesutility_truck.mdl']	=	{
		em_state	=	5236594359,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Copyright	=	"DurkaTeam @ 2025 No rights reserved",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-26.530000686646,-123.04000091553,20),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Pos	=	Vector(21.5,36.150001525879,34.689998626709),
				DoorSounds	=	true,
				Ang	=	Angle(0,0,0),
				EnterRange	=	80,
				RadioControl	=	true,
					},
				},
		DLT	=	3491062906,
		Lights	=	{
				{
				UseBlinkers	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(-38.119998931885,-115.2200012207,32.979999542236),
				UseDynamic	=	true,
				RenderInner	=	true,
				Sprite	=	{
					Size	=	0.4,
						},
				RenderInner_Size	=	1.2,
				Beta_Inner3D	=	true,
					},
				{
				UseSprite	=	true,
				Pos	=	Vector(-38.029998779297,-115.29000091553,38.220001220703),
				UseReverse	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				Sprite	=	{
					Size	=	0.4,
						},
				UseDynamic	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
					},
				{
				Sprite	=	{
					Size	=	0.4,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
				UseSprite	=	true,
				Pos	=	Vector(-38.029998779297,-115.29000091553,42.419998168945),
				UseDynamic	=	true,
				UseRunning	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					Size	=	0.1,
						},
				UseBrake	=	true,
				UseDynamic	=	true,
				Pos	=	Vector(-4.6500000953674,-99.309997558594,80.980003356934),
				UseSprite	=	true,
				SpecLine	=	{
					Amount	=	9,
					Pos	=	Vector(4.6500000953674,-99.309997558594,80.980003356934),
					Use	=	true,
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.3,
						},
					},
				{
				UseBlinkers	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.3,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(-37.450000762939,66.5,44.040000915527),
				UseDynamic	=	true,
				RenderInner	=	true,
				Sprite	=	{
					Size	=	0.3,
						},
				RenderInner_Size	=	1.2,
				Beta_Inner3D	=	true,
					},
				{
				UseBlinkers	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.35,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(-22.239999771118,116.83999633789,29.60000038147),
				UseDynamic	=	true,
				RenderInner	=	true,
				Sprite	=	{
					Size	=	0.15,
						},
				SpecLine	=	{
					Amount	=	5,
					Pos	=	Vector(-28.040000915527,115.87000274658,29.620000839233),
					Use	=	true,
						},
				RenderInner_Size	=	1.2,
				Beta_Inner3D	=	true,
					},
				{
				UseBlinkers	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.35,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(-31.680000305176,109.5,34.159999847412),
				UseDynamic	=	true,
				RenderInner	=	true,
				Sprite	=	{
					Size	=	0.15,
						},
				SpecLine	=	{
					Amount	=	7,
					Pos	=	Vector(-31.680000305176,109.5,40.939998626709),
					Use	=	true,
						},
				RenderInner_Size	=	1.2,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					Size	=	1.2,
						},
				ProjTexture	=	{
					Forward	=	30,
					Size	=	2024,
					Angle	=	Angle(0,90,0),
						},
				UseHead	=	true,
				UsePrjTex	=	true,
				Pos	=	Vector(-23.639999389648,112.63999938965,37.979999542236),
				UseDynamic	=	true,
				HeadColor	=	{
						194,
						211,
						255,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.6,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.15,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.35,
						},
				UseDynamic	=	true,
				UseSprite	=	true,
				UseRunning	=	true,
				SpecLine	=	{
					Amount	=	5,
					Pos	=	Vector(-20,116.93000030518,29.690000534058),
					Use	=	true,
						},
				RunningColor	=	{
						212.57,
						185.81,
						207.76,
						},
				Pos	=	Vector(-14.199999809265,117.83999633789,29.760000228882),
					},
				{
				UseBlinkers	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(38.119998931885,-115.2200012207,32.979999542236),
				UseDynamic	=	true,
				RenderInner	=	true,
				Sprite	=	{
					Size	=	0.4,
						},
				RenderInner_Size	=	1.2,
				Beta_Inner3D	=	true,
					},
				{
				UseSprite	=	true,
				Pos	=	Vector(38.029998779297,-115.29000091553,38.220001220703),
				UseReverse	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				Sprite	=	{
					Size	=	0.4,
						},
				UseDynamic	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
					},
				{
				Sprite	=	{
					Size	=	0.4,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
				UseSprite	=	true,
				Pos	=	Vector(38.029998779297,-115.29000091553,42.419998168945),
				UseDynamic	=	true,
				UseRunning	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseBrake	=	true,
					},
				{
				UseBlinkers	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.3,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(37.450000762939,66.5,44.040000915527),
				UseDynamic	=	true,
				RenderInner	=	true,
				Sprite	=	{
					Size	=	0.3,
						},
				RenderInner_Size	=	1.2,
				Beta_Inner3D	=	true,
					},
				{
				UseBlinkers	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.35,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(22.239999771118,116.83999633789,29.60000038147),
				UseDynamic	=	true,
				RenderInner	=	true,
				Sprite	=	{
					Size	=	0.15,
						},
				SpecLine	=	{
					Amount	=	5,
					Pos	=	Vector(28.040000915527,115.87000274658,29.620000839233),
					Use	=	true,
						},
				RenderInner_Size	=	1.2,
				Beta_Inner3D	=	true,
					},
				{
				UseBlinkers	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.35,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(31.680000305176,109.5,34.159999847412),
				UseDynamic	=	true,
				RenderInner	=	true,
				Sprite	=	{
					Size	=	0.15,
						},
				SpecLine	=	{
					Amount	=	7,
					Pos	=	Vector(31.680000305176,109.5,40.939998626709),
					Use	=	true,
						},
				RenderInner_Size	=	1.2,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					Size	=	1.2,
						},
				ProjTexture	=	{
					Forward	=	30,
					Size	=	2024,
					Angle	=	Angle(0,90,0),
						},
				UseHead	=	true,
				UsePrjTex	=	true,
				Pos	=	Vector(23.639999389648,112.63999938965,37.979999542236),
				UseDynamic	=	true,
				HeadColor	=	{
						194,
						211,
						255,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.6,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.15,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.35,
						},
				UseDynamic	=	true,
				UseSprite	=	true,
				UseRunning	=	true,
				SpecLine	=	{
					Amount	=	5,
					Pos	=	Vector(20,116.93000030518,29.690000534058),
					Use	=	true,
						},
				RunningColor	=	{
						212.57,
						185.81,
						207.76,
						},
				Pos	=	Vector(14.199999809265,117.83999633789,29.760000228882),
					},
				},
		Date	=	"06/30/15 22:44:11",
		Author	=	"freemmaann (STEAM_0:1:14528726)",
}