-- DurkaTeam @ 2025 Никакие права не защищены

include('shared.lua')

ENT.RenderGroup = RENDERGROUP_BOTH

function ENT:Initialize() self.VC_Color = Color(0,255,255,255) self.VC_Length = 154 self.VC_Text = "Vehicle Fuel 100%" self.VC_PVsb = util.GetPixelVisibleHandle() end