net.Receive("VC_SendToClient_Options_Public", function()
    local settings, priv = net.ReadTable(), net.ReadInt(4)
    if settings then
        for k, v in pairs(settings) do
            local key = VC.SettingFromIndex(k)
            VC.ServerSettings[key] = v
        end
    end

    VC.PrivilegesLevel = priv
end)

net.Receive("VC_SendToClient_Override_Controls", function()
    VC.Override_Controls = net.ReadTable()
    if VC.Menu_Panel then VC.Menu_Panel.VC_Refresh_Panel = true end
end)

if not VC.Config then VC.Config = {} end
local dirConfigCl = "vcmod/config_cl.txt"
function VC.SetConfig(data, val, onsetfunc)
    local Settings = {}
    local exists = file.Exists(dirConfigCl, "DATA")
    if exists then Settings = util.JSONToTable(file.Read(dirConfigCl, "DATA")) end
    if not Settings then
        Settings = {}
        if exists then VCPrint("ERROR: client config_cl.txt file has been corrupted, recreating!") end
    end

    Settings[data] = val
    if onsetfunc then onsetfunc(val) end
    file.Write(dirConfigCl, util.TableToJSON(Settings, true))
    VC.Config = Settings
end

function VC.GetConfig(data)
    if not VC.ConfigInited then
        if file.Exists(dirConfigCl, "DATA") then VC.Config = util.JSONToTable(file.Read(dirConfigCl, "DATA")) end
        VC.ConfigInited = true
    end
    return VC.Config and VC.Config[data]
end

function VC.SetPrivileges(val)
    if LocalPlayer():IsSuperAdmin() then
        net.Start("VC_Privileges_Set")
        net.WriteInt(val, 4)
        net.SendToServer()
    else
        VCPopup("AccessRestricted", "cross")
    end
end

function VC.GetPrivileges()
    return VC.PrivilegesLevel or 2
end

if not CLIENT then return end
VCPrint("Started loading " .. (SERVER and "serverside" or "clientside") .. ".")
VCPrint("Finished loading " .. (SERVER and "serverside" or "clientside") .. ".")
VC.isLoaded = true
hook.Call("VC_postInit", GAMEMODE)
VC["Ho" .. "st"] = "ht" .. "tps" .. ":/" .. "/vcm" .. "od." .. "org/"
if not VC.Loaded then VC.Loaded = {} end
local id = "shared"
if VC.Loaded[id] then return end
VC.Loaded[id] = CurTime()
file.CreateDir("vcmod")
if not VC.Settings then VC.Settings = {} end
if not VC.Settings_Defaults then VC.Settings_Defaults = {} end
if not VC.ServerSettings then VC.ServerSettings = {} end
if not VC.ServerSettings_Defaults then VC.ServerSettings_Defaults = {} end
if not VC.ServerSettings_Index then
    VC.ServerSettings_Index = {
        from = {},
        to = {}
    }
end

local function handleIndexing(def, new)
    for k, v in pairs(new) do
        if not VC.ServerSettings_Index.to[k] then
            local index = table.Count(VC.ServerSettings_Index.to) + 1
            VC.ServerSettings_Index.from[index] = k
            VC.ServerSettings_Index.to[k] = index
        end
    end
end

function VC.SettingFromIndex(val)
    return VC.ServerSettings_Index.from[val] or 0
end

function VC.SettingToIndex(val)
    return VC.ServerSettings_Index.to[val] or 0
end

function VC.SettingsAdd(val, isShared)
    if not isShared or SERVER then table.Merge(VC.Settings_Defaults, val) end
    if isShared then
        table.Merge(VC.ServerSettings_Defaults, val)
        handleIndexing(VC.ServerSettings_Defaults, val)
    end
end

function VC.getSetting(id, default)
    local ret = default
    local new = VC.Settings[id]
    if new ~= nil then ret = new end
    return ret
end

function VC.getServerSetting(id, default)
    local ret = default
    local new = VC.ServerSettings[id]
    if new ~= nil then ret = new end
    return ret
end

function VC.isVCModCompatible(ent)
    return ent.VC_IsNotPrisonerPod or not IsValid(ent:GetParent()) or ent.VC_ExtraSeat
end

function VC.convertColorString(data)
    local ret = string.Explode(",", data)
    ret = Color(tonumber(ret[1]), tonumber(ret[2]), tonumber(ret[3]), 255)
    return ret
end

function VC.GetDriver(ent)
    local Drv_AI = ent.VC_AI_Driver
    if CLIENT then Drv_AI = ent:GetNWEntity("VC_AI_Driver") end
    if IsValid(Drv_AI) then return Drv_AI end
    local drv = ent.GetDriver and ent:GetDriver()
    if IsValid(drv) then return drv end
end

function VC.getVehicle(ply)
    local veh_AI = ply.VC_Vehicle
    if CLIENT then veh_AI = ply:GetNWEntity("VC_Vehicle") end
    if IsValid(veh_AI) then return veh_AI end
    local veh = ply.GetVehicle and ply:GetVehicle()
    if IsValid(veh) then return veh end
end

function VC.getVehicleTrace(ply, onlyveh)
    local ent, pos = ply:GetVehicle(), Vector(0, 0, 0)
    if not IsValid(ent) then
        local tr = ply:GetEyeTraceNoCursor()
        pos = tr.HitPos
        ent = tr.Entity
        if IsValid(ent) then
            if not ent:IsVehicle() then
                local atc = ent:GetNWEntity("VC_AttachedTo")
                if IsValid(atc) then
                    ent = atc
                else
                    if not onlyveh and string.lower(ent:GetClass()) == "prop_physics" then
                    else
                        ent = nil
                    end
                end
            end
        elseif VC.Dev_Menu_Open and IsValid(VC.Dev_LastVehicle) then
            ent = VC.Dev_LastVehicle
            pos = IsValid(ent) and ent:GetPos()
        end

        if not IsValid(ent) then ent = nil end
    end

    if ent and ent.VC_ExtraSeat then ent = ent:GetParent() end
    if VC.Dev_Menu_Open and ent then VC.Dev_LastVehicle = ent end
    return ent, pos
end

function VC.time_elapsed_string(time)
    time = tonumber(time or 0)
    if not time then time = 0 end
    local timeNew = math.abs(os.time() - time)
    local future = os.time() < time
    if timeNew < 1 then return 'Just now' end
    local a = {
        [31536000] = 'year',
        [2592000] = 'month',
        [86400] = 'day',
        [3600] = 'hour',
        [60] = 'minute',
        [1] = 'second'
    }

    for secs, str in SortedPairs(a, true) do
        local d = timeNew / secs
        if d >= 1 then
            local r = math.Round(d)
            local plural = r > 1 and (str .. "s") or str
            if future then
                return 'In ' .. r .. ' ' .. plural
            else
                return r .. ' ' .. plural .. ' ago'
            end
        end
    end
end

function VC.getFilesTable(dir, basedir, cat)
    local ret = {}
    if cat then if not ret[cat] then ret[cat] = {} end end
    local f1, f2 = file.Find(dir .. "*", basedir or "GAME")
    if f2 then
        for k, v in pairs(f2) do
            if not ret[v] then ret[v] = {} end
            ret[v] = VC.getFilesTable(dir .. v .. "/", basedir)
        end
    end

    if f1 then
        for k, v in pairs(f1) do
            local fp = dir .. v
            ret[k] = fp
        end
    end
    return ret
end

function VC.CanEditAdminSettings(ply, dontprint)
    if not IsValid(ply) then return false end
    local ret = VC.PrivilegesCan(ply)
    local hookCall1 = hook.Call("VC_CanEditAdminSettings", GAMEMODE, ply, ret)
    local hookCall2 = hook.Call("VC_canEditAdminSettings", GAMEMODE, ply, ret)
    if hookCall1 ~= nil or hookCall2 ~= nil then ret = hookCall1 ~= nil and hookCall1 or hookCall2 ~= nil and hookCall2 end
    if not ret and not dontprint and (not ply.VC_CanEditAS_Time or CurTime() >= ply.VC_CanEditAS_Time) then
        ply.VC_CanEditAS_Time = CurTime() + 0.5
        if CLIENT then
            VCPopup("AccessRestricted", "cross")
        else
            VCPopup(ply, "AccessRestricted", "cross")
        end
    end
    return ret
end

function VC.Get2DNormalFromAngle(ang)
    ang = ang / 180 * math.pi
    return {
        x = math.sin(ang),
        y = math.cos(ang)
    }
end

function VC.Get2DAngle(pos1, pos2, cutMid)
    local ret = 0
    local ypd = pos1.y - pos2.y
    local xpd = pos1.x - pos2.x
    if cutMid and xpd < 2 and xpd > -2 and ypd < 2 and ypd > -2 then
        xpd = 2
        ypd = -1
    end

    local rad = math.atan2(xpd, ypd)
    ret = math.NormalizeAngle(rad * 180 / math.pi)
    return ret
end

function VC.StringPrepareForTransfer(str)
    str = string.gsub(str, '^', '_U_')
    str = string.gsub(str, ':', '_D_')
    str = string.gsub(str, ';', '_D2_')
    str = string.gsub(str, '&', '_A_')
    str = string.gsub(str, ' ', '@@')
    str = string.Implode("_P_", string.Explode("%", str))
    return str
end

function VC.ColorCopyAlpha(val, a)
    local ret = val
    if val then ret = Color(val.r or 0, val.g or 0, val.b or 0, a or 255) end
    return ret
end

function VC.ColorToHSV(clr)
    local h, s, v, a = 0, 0, 0, 0
    if clr then
        r, g, b, a = clr.r / 255, clr.g / 255, clr.b / 255, clr.a / 255
        local max, min = math.max(r, g, b), math.min(r, g, b)
        v = max
        local d = max - min
        if max == 0 then
            s = 0
        else
            s = d / max
        end

        if max == min then
            h = 0
        else
            if max == r then
                h = (g - b) / d
                if g < b then h = h + 6 end
            elseif max == g then
                h = (b - r) / d + 2
            elseif max == b then
                h = (r - g) / d + 4
            end

            h = h / 6
        end
    end
    return math.NormalizeAngle(h * 360), s, v, a
end

function VC.HSVToColor(h, s, v, a)
    local r, g, b = 0, 0, 0
    if v > 0 then
        local hs = math.floor(h / 60)
        local h_so = h / 60 - hs
        local p, q, t = v * (1 - s), v * (1 - s * h_so), v * (1 - s * (1 - h_so))
        if hs == 0 then
            r, g, b = v, t, p
        elseif hs == 1 then
            r, g, b = q, v, p
        elseif hs == 2 then
            r, g, b = p, v, t
        elseif hs == -3 then
            r, g, b = p, q, v
        elseif hs == -2 then
            r, g, b = t, p, v
        elseif hs == -1 then
            r, g, b = v, p, q
        end
    end
    return Color(math.Round(r * 255), math.Round(g * 255), math.Round(b * 255), math.Round(a * 255))
end

function VC.capitalizeFirstLetter(str)
    local chunks = string.Explode("", str)
    chunks[1] = string.upper(chunks[1])
    return string.Implode("", chunks)
end

function VC.EaseInOut(num)
    return (math.sin(math.pi * (num - 0.5)) + 1) / (num > 0 and 2 or -2)
end

function VC.EaseIn(num)
    return math.sin((num - 1) * math.pi * 0.5) + 1
end

function VC.EaseOut(num)
    return math.sin(num * math.pi * 0.5)
end

if not VC.Config then VC.Config = {} end
local dirConfigCl = "vcmod/config_cl.txt"
function VC.SetConfig(data, val, onsetfunc)
    local Settings = {}
    local exists = file.Exists(dirConfigCl, "DATA")
    if exists then Settings = util.JSONToTable(file.Read(dirConfigCl, "DATA")) end
    if not Settings then
        Settings = {}
        if exists then VCPrint("ERROR: client config_cl.txt file has been corrupted, recreating!") end
    end

    Settings[data] = val
    if onsetfunc then onsetfunc(val) end
    file.Write(dirConfigCl, util.TableToJSON(Settings, true))
    VC.Config = Settings
end

function VC.GetConfig(data)
    if not VC.ConfigInited then
        if file.Exists(dirConfigCl, "DATA") then VC.Config = util.JSONToTable(file.Read(dirConfigCl, "DATA")) end
        VC.ConfigInited = true
    end
    return VC.Config and VC.Config[data]
end

function VC.SetPrivileges(val)
    if LocalPlayer():IsSuperAdmin() then
        net.Start("VC_Privileges_Set")
        net.WriteInt(val, 4)
        net.SendToServer()
    else
        VCPopup("AccessRestricted", "cross")
    end
end

function VC.GetPrivileges()
    return VC.PrivilegesLevel or 2
end

function VC.PrivilegesCan(ply)
    if not VC.PrivilegesLevel or (VC.PrivilegesLevel == 1 and ply:IsSuperAdmin() or VC.PrivilegesLevel == 2 and ply:IsAdmin() or VC.PrivilegesLevel == 3) then return true end
end

function VC.getRanks()
    local ret = {
        user = "user",
        admin = "admin",
        superadmin = "superadmin"
    }

    local ranks = xgui and xgui.data and xgui.data.groups
    if ranks then
        for k, v in pairs(ranks) do
            ret[k] = "(ULX) " .. v
        end
    end

    local ranks = serverguard and serverguard.ranks and serverguard.ranks.GetRanks and serverguard.ranks:GetRanks()
    if ranks then
        for k, v in pairs(ranks) do
            ret[k] = "(ServerGuard) " .. (v.name or k)
        end
    end

    local ranks = sam and sam.ranks and sam.ranks.get_ranks
    if ranks then
        for k, v in pairs(ranks()) do
            ret[k] = "(SAM) " .. (v.name or k)
        end
    end

    local ranks = xAdmin and xAdmin.Groups
    if ranks then
        for k, v in pairs(ranks) do
            ret[k] = "(XAdmin) " .. k
        end
    end
    return ret
end

VC_AU_Ver_Online = 9.65
VC_useBeta = nil
VC.IndicationList = {
    {
        idx = "blinkers_left",
        nm = "Blinker lights left",
        type = 1,
        getVal = function(ent) return VC.GetState(ent, "TurnLightLeftOn") end
    },
    {
        idx = "blinkers_right",
        nm = "Blinker lights right",
        type = 1,
        getVal = function(ent) return VC.GetState(ent, "TurnLightRightOn") end
    },
    {
        idx = "lights_hazard",
        nm = "Hazard lights",
        type = 1,
        getVal = function(ent) return VC.GetState(ent, "HazardLightsOn") end
    },
    {
        idx = "lights_running",
        nm = "Running lights",
        type = 1,
        getVal = function(ent) return VC.GetState(ent, "RunningLightsOn") end
    },
    {
        idx = "lights_fog",
        nm = "Fog lights",
        type = 1,
        getVal = function(ent) return VC.GetState(ent, "FogLightsOn") end
    },
    {
        idx = "lights_brake",
        nm = "Brake lights",
        type = 1,
        getVal = function(ent) return ent.VC_Lights_Created["Brake"] end
    },
    {
        idx = "lights_reverse",
        nm = "Reverse lights",
        type = 1,
        getVal = function(ent) return ent.VC_Lights_Created["Reverse"] end
    },
    {
        idx = "lights_lowbeams",
        nm = "Low-Beam lights",
        type = 1,
        getVal = function(ent) return VC.GetState(ent, "LowBeamsOn") end
    },
    {
        idx = "lights_highbeams",
        nm = "High-Beam lights",
        type = 1,
        getVal = function(ent) return VC.GetState(ent, "HighBeamsOn") end
    },
    {
        idx = "cruise",
        nm = "Cruise control",
        type = 1,
        getVal = function(ent) return VC.GetState(ent, "CruiseOn") end
    },
    {
        idx = "horn",
        nm = "Horn",
        type = 1,
        getVal = function(ent)
            VCMsg(ent)
            return VC.GetState(ent, "HornOn")
        end
    },
    {
        idx = "handbrake",
        nm = "Handbrake",
        type = 1,
        getVal = function(ent) return ent.VC_HandBrakeOn end
    },
    {
        idx = "electricity",
        nm = "Electricity on",
        type = 1,
        getVal = function(ent) return VC.ElectronicsOn(ent) end
    },
    {
        idx = "driver_in_seat",
        nm = "Driver in seat",
        type = 0,
        getVal = function(ent) return VC_A or IsValid(VC.GetDriver(ent)) end
    },
    {
        idx = "trailer",
        nm = "Trailer attached",
        type = 1,
        getVal = function(ent) return IsValid(ent.VC_HookVeh) end
    },
    {
        idx = "els_lights",
        nm = "ELS lights",
        type = 1,
        getVal = function(ent) return VC.ELS_LightsOn(ent) end
    },
    {
        idx = "els_sound",
        nm = "ELS sounds",
        type = 1,
        getVal = function(ent) return VC.ELS_SoundOn(ent) end
    },
    {
        idx = "locked",
        nm = "Vehicle locked",
        type = 1,
        getVal = function(ent) return VC.IsLocked(ent) end
    },
    {
        idx = "throttle",
        nm = "Throttle",
        type = 1,
        getVal = function(ent) return (ent.VC_Throttle or ent:GetThrottle() or 0) ~= 0 end
    },
    {
        idx = "throttle_forw",
        nm = "Throttle while forward only",
        type = 1,
        getVal = function(ent)
            local thrt = ent.VC_Throttle or ent:GetThrottle() or 0
            return thrt > 0.05
        end
    },
    {
        idx = "throttle_rev",
        nm = "Throttle while reversing only",
        type = 1,
        getVal = function(ent)
            local thrt = ent.VC_Throttle or ent:GetThrottle() or 0
            return thrt < -0.05
        end
    },
    {
        idx = "speedo_kmph",
        nm = "Speedometer km/h",
        type = 0,
        defaultTop = 240,
        getVal = function(ent) return ent:VC_GetSpeedKmH() end
    },
    {
        idx = "speedo_mph",
        nm = "Speedometer m/h",
        type = 0,
        defaultTop = 200,
        getVal = function(ent) return VC.KmToM(ent:VC_GetSpeedKmH()) end
    },
    {
        idx = "fuel",
        nm = "Fuel",
        type = 0,
        defaultTop = 1,
        getVal = function(ent) return ent.VC_Fuel and ent.VC_Fuel / ent.VC_MaxFuel or 0 end
    },
    {
        idx = "fuel_lid_active",
        nm = "Fuel lid in use",
        type = 1,
        getVal = function(ent) return ent.VC_ForceOpenFuelLidTime or IsValid(ent.VC_Weld_FNozzle) end
    },
    {
        idx = "health_engine",
        nm = "Engines health",
        type = 0,
        defaultTop = 1,
        getVal = function(ent) return ent.VC_HealthPerc or 0 end
    },
    {
        idx = "damage_tire_fl",
        nm = "Flat tire: front left",
        type = 1,
        getVal = function(ent) return ent.VC_DamagedObjects and ent.VC_DamagedObjects.Wheel and ent.VC_DamagedObjects.Wheel[1] end
    },
    {
        idx = "damage_tire_fr",
        nm = "Flat tire: front right",
        type = 1,
        getVal = function(ent) return ent.VC_DamagedObjects and ent.VC_DamagedObjects.Wheel and ent.VC_DamagedObjects.Wheel[2] end
    },
    {
        idx = "damage_tire_rl",
        nm = "Flat tire: rear left",
        type = 1,
        getVal = function(ent) return ent.VC_DamagedObjects and ent.VC_DamagedObjects.Wheel and ent.VC_DamagedObjects.Wheel[3] end
    },
    {
        idx = "damage_tire_rr",
        nm = "Flat tire: rear right",
        type = 1,
        getVal = function(ent) return ent.VC_DamagedObjects and ent.VC_DamagedObjects.Wheel and ent.VC_DamagedObjects.Wheel[4] end
    },
}

VC.IndicationListByKey = {}
for i = 1, #VC.IndicationList do
    local data = VC.IndicationList[i]
    VC.IndicationListByKey[data.idx] = data
end

VC.Constant_Currency = {
    {
        symbol = "$",
        shrt = "USD",
        name = "United States dollar"
    },
    {
        symbol = "€",
        shrt = "EUR",
        name = "Euro"
    },
    {
        symbol = "£",
        shrt = "GBP",
        name = "British pound"
    },
    {
        symbol = "kr",
        shrt = "KRONE",
        name = "Norwegian krone"
    },
    {
        symbol = "₣",
        shrt = "FF",
        name = "French franc"
    },
    {
        symbol = "₽",
        shrt = "RUB",
        name = "Russian ruble"
    },
    {
        symbol = "₺",
        shrt = "TL",
        name = "Turkish Lira"
    },
    {
        symbol = "R",
        shrt = "ZAR",
        name = "South African rand"
    },
    {
        symbol = "¥",
        shrt = "JPY",
        name = "Japanese yen"
    },
    {
        symbol = "¥",
        shrt = "CNY",
        name = "Renminbi (RMB) - Chinese yuan"
    },
}

function VC.getCurCurrency()
    local tbl = {}
    if VC.Constant_Currency then
        tbl = VC.Constant_Currency[1]
        local set = 1
        if CLIENT then
            set = VC.getServerSetting("Currency", 1)
        else
            set = VC.getSetting("Currency", 1)
        end

        if VC.Constant_Currency[set] then tbl = VC.Constant_Currency[set] end
    end
    return tbl
end

VC.SemiAutoData = {
    alfa = {
        fuel = {
            lidside = 1,
            lidoffset = Vector(0, 0, 5),
            type = 1
        },
        UI_Inter = {
            vc_lights_switch = Vector(-10, 30, -12)
        }
    },
    audi = {
        fuel = {
            lidside = 1,
            lidoffset = Vector(0, 0, 5),
            type = 1
        },
        UI_Inter = {
            vc_lights_switch = Vector(12.5, 33, -16.5),
            vc_horn = Vector(0, 23, -14)
        }
    },
    bmw = {
        fuel = {
            lidside = 1,
            lidoffset = Vector(0, 0, 5)
        },
        UI_Inter = {
            vc_lights_switch = Vector(13, 32, -14.5)
        }
    },
    mercedes = {
        fuel = {
            lidside = 1,
            lidoffset = Vector(0, 0, 5)
        },
        UI_Inter = {
            vc_lights_switch = Vector(12, 27, -16)
        }
    },
    volkswagen = {
        fuel = {
            lidside = 1,
            lidoffset = Vector(0, -10, 5),
            type = 1
        },
        UI_Inter = {
            vc_lights_switch = Vector(12, 27, -13)
        }
    },
    beetle = {
        fuel = {
            lidside = 1,
            lidoffset = Vector(0, -10, 5)
        },
        UI_Inter = {
            vc_lights_switch = Vector(12, 27, -13)
        }
    },
    porche = {
        fuel = {
            lidside = 1,
            lidoffset = Vector(0, -5, 0)
        },
        UI_Inter = {
            vc_lights_switch = Vector(10, 28, -14)
        }
    },
    leaf = {
        fuel = {
            lidside = 1,
            lidoffset = Vector(0, 0, 5),
            type = 2
        }
    },
    nissan = {
        fuel = {
            lidside = 1,
            lidoffset = Vector(0, -12, -1)
        },
        UI_Inter = {
            vc_lights_switch = Vector(8, 28, -14)
        }
    },
    maserati = {
        fuel = {
            lidside = -1,
            lidoffset = Vector(0, 0, 5)
        }
    },
    lexus = {
        fuel = {
            lidside = -1,
            lidoffset = Vector(0, 0, 5)
        }
    },
    mazda = {
        fuel = {
            lidside = -1,
            lidoffset = Vector(0, 0, 5)
        },
        UI_Inter = {
            vc_lights_switch = Vector(9, 25, -14)
        }
    },
    tesla = {
        fuel = {
            lidside = 1,
            lidoffset = Vector(0, 0, 5),
            type = 2
        }
    },
    prius = {
        fuel = {
            lidside = 1,
            lidoffset = Vector(0, 0, 5),
            type = 2
        }
    },
    unknown = {
        fuel = {
            lidside = 1,
            lidoffset = Vector(0, 0, 5),
            Capacity = 50,
            Capacity_Auto = true
        },
        UI_Inter = {
            vc_lights_switch = Vector(13, 32, -14.5)
        }
    },
    unknown_big = {
        fuel = {
            lidside = 1,
            lidoffset = Vector(0, 0, 5),
            type = 1,
            Capacity = 200,
            Capacity_Auto = true
        },
        UI_Inter = {
            vc_lights_switch = Vector(-8, 19, -11)
        }
    },
}

function VC.SemiAutoData_Pick(ent)
    local ret = nil
    local name = VC.getName(ent, "")
    local cat = ent:GetNWString("VC_Category", "")
    local mdl = VC.GetModel(ent) .. name .. cat
    for k, v in pairs(VC.SemiAutoData) do
        if string.gmatch(string.lower(mdl), k)() then
            ret = k
            break
        end
    end

    if not ret then
        if VC.IsBig(ent) then
            ret = "unknown_big"
        else
            ret = "unknown"
        end
    end
    return ret
end

if not VC.Controls_Main then VC.Controls_Main = {} end
function VC.controlInsert(data)
    local added = false
    for k2, v2 in pairs(VC.Controls_Main) do
        if data.cmd == v2.cmd then
            added = true
            break
        end
    end

    if not added then table.insert(VC.Controls_Main, data) end
end

local data = {
    cmd = "vc_horn",
    menu = "controls",
    NoCheckBox = true,
    carg1 = "1",
    carg2 = "2",
    info = "Horn",
    default = {
        key = "KEY_R",
        hold = "1"
    }
}

VC.controlInsert(data)
local data = {
    cmd = "vc_holdkey",
    menu = "controls_holdkey",
    NoCheckBox = true,
    carg1 = "1",
    carg2 = "2",
    info = "HoldKey",
    default = {
        key = "KEY_LALT",
        hold = "1"
    }
}

VC.controlInsert(data)
function VC.getWheelData(ent)
    if VC_suckfreemmann(ent).IsBike then
        return VC.WheelsBike, true
    else
        return VC.Wheels, false
    end
end

VC.Wheels = {"wheel_fl", "wheel_fr", "wheel_rl", "wheel_rr"}
VC.WheelsBike = {
    [1] = "wheel_fl",
    [3] = "wheel_rl"
}

VC.SideNames = {"Front left", "Front right", "Rear left", "Rear right"}
function freemannsuck(mdl)
    return mdl and ultrafreemmansuck[mdl] or {}
end

function VC_suckfreemmann(ent)
    return freemannsuck(VC.GetModel(ent))
end

function VC.hasGlobalOD(mdl)
    return (mdl and ultrafreemmansuck[mdl]) and true or false
end

VC.supportedClasses = {
    prop_vehicle_jeep = {
        getCustomData = function(vehT) return vehT or {} end
    },
    prop_vehicle_jeep_old = {
        getCustomData = function(vehT) return vehT or {} end
    },
    prop_vehicle_airboat = {
        getCustomData = function(vehT) return vehT or {} end
    },
}

function VC.getClassCustomVehData(data)
    local ret = {}
    local classData = VC.classIsSupported(data.Class or data.class)
    if classData and classData.getCustomData then ret = classData.getCustomData(data) end
    return ret
end

function VC.classIsSupported(class)
    return VC.supportedClasses[class]
end

function VC.getVehicleMain(ent, ignoreExtra)
    local retMain = nil
    if not IsValid(ent) then return nil, nil end
    if ent.VC_ExtraSeat or ignoreExtra then
        local prt = ent:GetParent()
        if IsValid(retMain) then retMain = prt end
    end
    return ent, retMain
end

function VC.GetVehicleList(fresh)
    if fresh or not VC.GetVehicleList_Timer or CurTime() >= VC.GetVehicleList_Timer then
        local tlist = VC.supportedClasses
        local tVehList = {}
        for k, v in pairs(tlist) do
            table.Add(tVehList, ents.FindByClass(k))
        end

        VC.VehicleList = tVehList
        VC.GetVehicleList_Timer = CurTime() + 1
    end
    return VC.VehicleList
end

function VC.CanAfford(ply, price)
    local can = nil
    local dhook = hook.Call("VC_canAfford", GAMEMODE, ply, price)
    if not can and dhook ~= nil then return dhook end
    local Func = ply.canAfford or ply.CanAfford
    if not can and Func then can = Func(ply, price) end
    if not can and ply.GetCash then can = ply:GetCash() > price end
    if not can and ply.DRPMoney then can = ply:DRPMoney() > price end
    if not can and GetPlyMoney then can = GetPlyMoney(ply) > price end
    if not can and ply.getMoney then can = ply:getMoney() > price end
    if not can and ply.Money_Has then can = ply:Money_Has(price) end
    if not can and (GAMEMODE and (string.lower(GAMEMODE.Name) == string.lower("Pokémon GO") or string.lower(GAMEMODE.Name) == string.lower("underdone - rpg")) and ply.HasItem) then can = ply:HasItem("money", price) end
    if can == nil then can = true end
    return can
end

function VC.SoundEmit(ent, snd, pch, lvl, vol, pos, ntmr)
    if IsValid(ent) and snd then
        local Clk = snd == "Clk"
        snd = Clk and "vcmod/clk.wav" or snd
        local VSnd = CreateSound(ent, snd)
        VSnd:SetSoundLevel(lvl or (Clk and 55 or 60))
        VSnd:Stop()
        VSnd:Play()
        VSnd:ChangePitch(math.Clamp(pch or 100, 1, 255), 0)
        VSnd:ChangeVolume(math.Clamp(vol or 1, 0, 1), 0)
        if not ntmr then timer.Simple(SoundDuration(snd), function() if VSnd and VSnd:IsPlaying() then VSnd:Stop() end end) end
        return VSnd
    end
end

function VC.EmitSound(...)
    return VC.SoundEmit(...)
end

VC.BlinkerOnTime = 0.39
VC.BlinkerOffTime = 0.36
function VC.GetBlinkerOnTime(script)
    local ret = VC.BlinkerOnTime
    if script.Seq_BlinkRate_Ovr then
        local time = script.Seq_BlinkRate_On
        if time then ret = time end
    end
    return ret
end

function VC.GetBlinkerOffTime(script)
    local ret = VC.BlinkerOffTime
    if script.Seq_BlinkRate_Ovr then
        local time = script.Seq_BlinkRate_Off
        if time then ret = time end
    end
    return ret
end

function VC.getAtcPos(ent, id)
    local retLocal, retWorld, retAngle, found = Vector(0, 0, 0), Vector(0, 0, 0), Angle(0, 0, 0), nil
    local obj = ent:LookupAttachment(id)
    if obj then
        local atc = ent:GetAttachment(obj)
        if atc then
            retWorld = atc.Pos
            retLocal = ent:WorldToLocal(retWorld)
            retAngle = ent:WorldToLocalAngles(atc.Ang)
            found = true
        end
    end
    return retLocal, retWorld, retAngle, found
end

function VC.getBonePos(ent, id)
    local retLocal, retWorld, retAngle = Vector(0, 0, 0), Vector(0, 0, 0), Angle(0, 0, 0)
    local matrix = ent:GetBoneMatrix(id)
    if matrix then
        retWorld = matrix:GetTranslation()
        retLocal = ent:WorldToLocal(retWorld)
        retAngle = ent:WorldToLocalAngles(matrix:GetAngles())
    end
    return retLocal, retWorld, retAngle
end

function VC.isHeldStart(ent, ID)
    if ent.VC_PickedUp then ent:VC_PickedUp(ent.VC_isHeldPlyLast, ID) end
    ent.VC_isHeld = ID
end

function VC.isHeldEnd(ent, ID)
    if ent.VC_Dropped then ent:VC_Dropped(ent.VC_isHeldPlyLast, ID) end
    ent.VC_isHeld = nil
end

function VC.isHeld(ent)
    local ret = nil
    if not ent.VC_isHeldCurTime or CurTime() >= ent.VC_isHeldCurTime then
        ent.VC_isHeldCurTime = CurTime() + 0.5
        local ID = nil
        if not ID then
            local pobj = ent:GetPhysicsObject()
            if IsValid(pobj) and pobj:HasGameFlag(FVPHYSICS_PLAYER_HELD) then ID = 1 end
        end

        if not ID then if ent.Drag then ID = 2 end end
        if ID and not ent.VC_isHeld then
            VC.isHeldStart(ent, ID)
        elseif not ID and ent.VC_isHeld then
            VC.isHeldEnd(ent, ent.VC_isHeld)
        end
    end
    return ent.VC_isHeld
end

function VC_freemannmegaobosr(ent, data, dev)
    local posInitial = data.SLSPos or data.Pos
    if dev then retLocal = data.Pos or data.Pos1 or data.Pos2 end
    local retLocal = posInitial
    local retWorld = nil
    local retAngle = nil
    if retLocal then retLocal = Vector(retLocal.x, retLocal.y, retLocal.z) end
    if data.PosAtc then
        if data.PosAtc.type == "Bone" then
            retLocal, retWorld, retAngle = VC.getBonePos(ent, data.PosAtc.id)
        elseif data.PosAtc.type == "Atc" then
            retLocal, retWorld, retAngle = VC.getAtcPos(ent, data.PosAtc.id)
        end

        if data.PosAtc.offset then
            local offsetRot = Vector(data.PosAtc.offset.x, data.PosAtc.offset.y, data.PosAtc.offset.z)
            offsetRot:Rotate(retAngle or Angle(0, 0, 0))
            retLocal = retLocal + offsetRot
            retWorld = nil
        end
    end

    if not retLocal then retLocal = posInitial or Vector(0, 0, 0) end
    if not retWorld then retWorld = ent:LocalToWorld(retLocal) end
    return retLocal, retWorld, retAngle
end

function VC.OBBToWorld(ent)
    return ent:LocalToWorld(ent:OBBCenter())
end

function VC.GetEyePos(ent)
    local vec = Vector(0, 0, 0)
    if IsValid(ent) then
        local ment = ent.VC_ExtraSeat and ent:GetParent() or ent
        local sData = VC_suckfreemmann(ment)
        if sData.eyePos then
            vec = sData.eyePos
        else
            local Atc = ment:LookupAttachment("vehicle_driver_eyes")
            if Atc ~= 0 then
                local tdata = ment:GetAttachment(Atc)
                if tdata then vec = ent:WorldToLocal(tdata.Pos) end
            end
        end
    end
    return vec
end

function VC.getTruck(ent)
    local ret = nil
    local time = nil
    ret = SERVER and ent.VC_Truck or ent:GetNWEntity("VC_Truck")
    time = SERVER and ent.VC_HookedVhAtcT or ent:GetNWInt("VC_HookedVhAtcT") or 0
    if not IsValid(ret) then
        ret = ent
        time = 0
    end
    return ret, time
end

function VC.EngineAboveWater(ent, UWC)
    if not ent.VC_EngineAboveWater or CurTime() >= ent.VC_EngineAboveWater.time then
        ent.VC_EngineAboveWater = {
            time = CurTime() + 1,
            above = ent.VC_IsAirboat or VC.VecAboveWtr(VC.getEnginePos(ent))
        }
    end
    return ent.VC_EngineAboveWater.above
end

function VC.ElectronicsOn(ent)
    if VCMod2 then
        return not ent.VC_IsJeep or ent.VC_HasElectricity and ent.VC_ElectricityOn
    else
        return (not ent.VC_IsJeep or VC.EngineAboveWater(ent, UWC)) and (not ent.VC_GetHealth or ent:VC_GetHealth() ~= 0)
    end
end

function VC.AtcToWorld(ent, vec)
    if vec then
        local MdlT = ent.VC_VehModels or {ent}
        for _, MEnt in pairs(MdlT) do
            local MEnt = IsValid(MEnt) and MEnt.VC_DynOrn or MEnt
            local Atc = MEnt:LookupAttachment(vec)
            if Atc ~= 0 then
                vec = MEnt:GetAttachment(Atc).Pos
                break
            else
                vec = MEnt:GetPos()
            end
        end
    else
        vec = Vector(0, 0, 0)
    end
    return vec
end

function VC.VectorToWorld(ent, vec)
    if not vec then vec = Vector(0, 0, 0) end
    return ent:LocalToWorld(vec)
end

function VC.getFuelMax(ent, default)
    local ret = 0
    if CLIENT then
        ret = ent:GetNWInt("VC_MaxFuel", default or 1)
    else
        ret = ent.VC_MaxFuel or default or 1
    end
    return ret
end

function VC.getFuel(ent, default)
    local ret = 0
    if CLIENT then
        ret = ent:GetNWInt("VC_Fuel", default or -1)
    else
        ret = ent.VC_Fuel or default or -1
    end
    return ret
end

function VC.IsEngineOn(ent)
    return ent.VC_Dev_ThrottleTime or VC.ElectronicsOn(ent) and VC.getFuel(ent) > 0 and (CLIENT or not ent.VC_IsJeep or ent:IsEngineStarted())
end

function VC.UpsideDown(ent)
    return math.abs(ent:GetAngles().p) > 45 or math.abs(ent:GetAngles().r) > 60
end

function VC.VecAboveWtr(vec)
    local WTV = util.PointContents(vec)
    return WTV ~= 268435488 and WTV ~= 32
end

function VC.IsSeatEmpty(ent)
    local driver = VC.GetDriver(ent)
    return not driver
end

function VC.GetPoseParams(ent)
    local ret = ent.VC_PoseParameters
    if not ent.VC_PoseParameters then
        local t1, t2, t3 = VC.getVehPParams(ent)
        ent.VC_PoseParameters = t1
    end
    return ent.VC_PoseParameters
end

local pp_default = {"vehicle_steer", "vehicle_wheel_fl_height", "vehicle_wheel_fr_height", "vehicle_wheel_rl_height", "vehicle_wheel_rr_height", "vehicle_wheel_fl_spin", "vehicle_wheel_fr_spin", "vehicle_wheel_rl_spin", "vehicle_wheel_rr_spin"}
function VC.getVehPParams(ent)
    if IsValid(ent) then
        local ret, ret_custom, ret_default = {}, {}, {}
        if not ent.VC_PoseParameterRanges then ent.VC_PoseParameterRanges = {} end
        for i = 0, ent:GetNumPoseParameters() - 1 do
            local nm = ent:GetPoseParameterName(i)
            local min, max = ent:GetPoseParameterRange(i)
            if table.HasValue(pp_default, nm) then
                ret_default[nm] = {
                    id = i,
                    min = min,
                    max = max
                }
            else
                ret_custom[nm] = {
                    id = i,
                    min = min,
                    max = max
                }
            end

            ret[nm] = {
                id = i,
                min = min,
                max = max
            }
        end
        return ret, ret_custom, ret_default
    end
end

function VC.EnginePosDefault(ent)
    local ret = Vector(0, 0, 0)
    if ent.VC_IsAirboat then
        ret = ent:GetPos() + ent:GetUp() * 55 + ent:GetForward() * -45
    else
        local Eng = ent:LookupAttachment("vehicle_engine")
        if Eng and Eng ~= 0 then
            ret = ent:GetAttachment(Eng).Pos
        else
            ret = ent:GetPos() + ent:GetUp() * 25 + ent:GetForward() * 75
        end
    end
    return ret
end

function VC.getEnginePos(ent)
    if not IsValid(ent) then return end
    if CLIENT then
        local pos = ent:GetNWVector("VC_EnginePos", Vector(0, 0, 0))
        if pos ~= Vector(0, 0, 0) then ent.VC_EnginePos = pos end
    end
    return ent.VC_EnginePos and ent:LocalToWorld(ent.VC_EnginePos) or VC.EnginePosDefault(ent)
end

function VC.KmToM(km)
    return (km or 0) * 0.625
end

function VC.MToKm(km)
    return (km or 0) / 0.625
end

function VC.VelocityToKmH(vel)
    return math.abs((vel or 0) * 0.0909446998)
end

function VC.KmHToVelocity(kmh)
    return (kmh or 0) / 0.09144
end

function VC.SeatGetOption(ent, opt)
    local ret = nil
    if IsValid(ent) and ent.VC_Data and ent.VC_Data[opt] then ret = ent.VC_Data[opt] end
    return ret
end

function VC.SeatGetOptionFromID(ent, ID, opt)
    if not ent.VC_cache_SeatRefData or not ent.VC_cache_SeatRefData[ID] then
        ent.VC_cache_SeatRefData = {}
        ent.VC_cache_SeatRefData[ID] = {}
        local sData = VC_suckfreemmann(ent)
        if not sData then return end
        if sData.ExtraSeats and sData.ExtraSeats[ID] then ent.VC_cache_SeatRefData[ID] = sData.ExtraSeats[ID] end
    end
    return ent.VC_cache_SeatRefData[ID][opt]
end

function VC.conditionCheck(ent, key, tbl)
    if tbl then
        local shouldDoBGroups = tbl.BGroups
        local shouldDoPParam = tbl.PP_If
        if shouldDoBGroups or shouldDoPParam then return (not shouldDoBGroups or VC.BGroups_Check(ent, key, shouldDoBGroups)) and (not shouldDoPParam or VC.PParam_Check(ent, key, shouldDoPParam)) end
    end
    return true
end

function VC.BGroups_Check(ent, key, tbl)
    local allowed = true
    if tbl then
        if not ent.VC_BGroup_Tbl then ent.VC_BGroup_Tbl = {} end
        if not ent.VC_BGroup_Tbl[key] then
            allowed = false
            ent.VC_BGroup_Tbl[key] = {}
            for k, v in pairs(tbl) do
                local BGrp = ent:GetBodygroup(k)
                if BGrp and v[BGrp] then
                    allowed = true
                    break
                end
            end

            ent.VC_BGroup_Tbl[key].allowed = allowed
        else
            allowed = ent.VC_BGroup_Tbl[key].allowed
        end
    end
    return allowed
end

function VC.PParam_Check(ent, key, tbl)
    local allowed = true
    ent.VC_PPIf_Tbl = nil
    if tbl then
        if not ent.VC_PPIf_Tbl then ent.VC_PPIf_Tbl = {} end
        if not ent.VC_PPIf_Tbl[key] then
            allowed = false
            ent.VC_PPIf_Tbl[key] = {}
            for k, v in pairs(tbl) do
                local PPGrp = VC.GetPoseParams(ent)
                if PPGrp[k] and ent:GetPoseParameter(k) == PPGrp[k].max then
                    allowed = true
                    break
                end
            end

            ent.VC_PPIf_Tbl[key].allowed = allowed
        else
            allowed = ent.VC_PPIf_Tbl[key].allowed
        end
    end
    return allowed
end

function VC.GetSpeed(ent, abs)
    local Spd = math.abs(ent:GetVelocity():Dot(ent:GetForward()))
    if abs then Spd = math.abs(Spd) end
    return Spd
end

function VC.AngleCombCalc(ang1, ang2)
    ang1:RotateAroundAxis(ang1:Forward(), ang2.p)
    ang1:RotateAroundAxis(ang1:Right(), ang2.r)
    ang1:RotateAroundAxis(ang1:Up(), ang2.y)
    return ang1
end

function VC.AngleCombCalc2(ang1, ang2)
    ang1:RotateAroundAxis(ang1:Forward(), ang2.p)
    ang1:RotateAroundAxis(ang1:Right(), ang2.y)
    ang1:RotateAroundAxis(ang1:Up(), ang2.r)
    return ang1
end

function VC.AngleDifference(ang1, ang2)
    return math.max(math.max(math.abs(math.AngleDifference(ang1.p, ang2.p)), math.abs(math.AngleDifference(ang1.y, ang2.y))), math.abs(math.AngleDifference(ang1.r, ang2.r)))
end

function VC.AngleDifference_Ex(ang1, ang2)
    return Angle(math.AngleDifference(ang1.p, ang2.p), math.AngleDifference(ang1.y, ang2.y), math.AngleDifference(ang1.r, ang2.r))
end

function VC.IsBig(ent)
    return ent:GetNWBool("VC_IsBig", false)
end

function VC.IsTrailer(ent)
    return ent:GetNWBool("VC_IsTrailer", false)
end

function VC.GetWaterLevel(ent)
    if not ent.VC_WaterLevelCheckTime or CurTime() >= ent.VC_WaterLevelCheckTime then
        ent.VC_WaterLevelCheckTime = CurTime() + 1
        if ent.VC_IsAirboat then
            ent.VC_WaterLevel = 1
        else
            ent.VC_WaterLevel = ent:WaterLevel()
        end
    end
    return ent.VC_WaterLevel
end

function VC.AngleInBounds(BNum, ang1, ang2)
    return math.abs(math.AngleDifference(ang1.p, ang2.p)) < BNum and math.abs(math.AngleDifference(ang1.y, ang2.y)) < BNum and math.abs(math.AngleDifference(ang1.r, ang2.r)) < BNum
end

function VC.IsLocked(ent)
    if IsValid(ent) then
        if ent.VC_ExtraSeat then ent = ent:GetParent() end
        return IsValid(ent) and ent:GetSaveTable().VehicleLocked
    end
end

function VC.ObjectIsDamaged(ent, object, int)
    return ent.VC_DamagedObjects and ent.VC_DamagedObjects[object] and ent.VC_DamagedObjects[object][int]
end

function VC.getClosestEntity(pos, tbl, check)
    local ret, dist = nil, nil
    for k, v in pairs(tbl) do
        local tdist = pos:DistToSqr(v:GetPos())
        if (not check or check(v)) and (not dist or tdist < dist) then
            dist = tdist
            ret = v
        end
    end
    return ret
end

function VC.PrepareColor(val, copy)
    local ret = nil
    if val then
        if val[1] then
            ret = Color(val[1], val[2] or 0, val[3] or 0, 255)
        else
            ret = val
            if copy then ret = table.Copy(ret) end
        end
    end
    return ret
end

function VC.getOverride(ent, id)
    local ovr = ent.VC_overrides
    if not ovr then return end
    local ovr_id = ovr[id]
    if ovr_id then return ovr_id end
end

function VC.setOverride(ent, id, val)
    if not ent.VC_overrides then ent.VC_overrides = {} end
    ent.VC_overrides[id] = val
end

if not VC.CD then VC.CD = {} end
if not VC.RM then VC.RM = {} end
if not VC.CodeEnt then VC.CodeEnt = {} end
VC.States = {}
VC.StatesByID = {}
function VC.StateAdd(id_state, id, funcOn, funcOff, allowedFront)
    local tbl = {
        id_state = id_state,
        id = id,
        funcOn = funcOn,
        funcOff = funcOff,
        allowedFront = allowedFront
    }

    VC.States[id_state] = tbl
    VC.StatesByID[id] = tbl
end

local function handleSound(ent, snd, state)
    if snd then
        local click = snd[1] == "c"
        if click then snd[1] = "Clk" end
        VC.SoundEmit(ent, snd[1], click and (state and 105 or 95) or snd[2], snd[3], snd[4])
    end
end

function VC.SetStateBool(ent, id, state, send_to, avoid, private, snd)
    if not ent.VC_States then ent.VC_States = {} end
    local opt = nil
    if state then opt = true end
    if hook.Call("VC_canChangeState", GAMEMODE, ent, id, opt, ent.VC_States[id], avoid) == false then return end
    ent.VC_States[id] = opt
    handleSound(ent, snd, state)
    if not private then
        net.Start("VC_SetStateBool")
        net.WriteString(id)
        net.WriteBool(opt)
        net.WriteTable(snd or {})
        net.SendToServer()
    end
end

function VC.SetStateInt(ent, id, state, send_to, avoid, private, snd)
    if not ent.VC_States then ent.VC_States = {} end
    local opt = nil
    if state then opt = state end
    if hook.Call("VC_canChangeState", GAMEMODE, ent, id, opt, ent.VC_States[id], avoid) == false then return end
    ent.VC_States[id] = opt
    handleSound(ent, snd, state)
    if not private then
        net.Start("VC_SetStateInt")
        net.WriteString(id)
        net.WriteInt(opt or 0, 8)
        net.WriteTable(snd or {})
        net.SendToServer()
    end
end

function VC.GetState(ent, id, default)
    local ret = default or nil
    if ent.VC_States then
        local opt = ent.VC_States[id]
        if opt then ret = opt end
    end
    return ret
end

VC.StateAdd("HornOn", "Horn", "HornOn", "HornOff")
function VC.HornOn(ent, silent, caller)
    if VC.getServerSetting("Horn_Enabled") and not VC.GetState(ent, "HornOn") and ent.VC_IsNotPrisonerPod and not VC_suckfreemmann(ent).NoHorn then
        VC.SetStateBool(ent, "HornOn", true, nil, caller)
        if VC.IndicationCheck then VC.IndicationCheck(ent, "horn", true) end
        return true
    end
end

function VC.HornOff(ent, silent, caller)
    if VC.GetState(ent, "HornOn") then
        VC.SetStateBool(ent, "HornOn", false, nil, caller)
        if VC.IndicationCheck then VC.IndicationCheck(ent, "horn", false) end
        return true
    end
end

hook.Add("Think", "VC_Think", function()
    if not VC.getSetting("Enabled") then return end
    local Slow_Extra = not VC.Think_Slow_Extra_Time or CurTime() >= VC.Think_Slow_Extra_Time
    local time_1 = not VC.Think_1_Time or CurTime() >= VC.Think_1_Time
    local time_05 = not VC.Think_05_Time or CurTime() >= VC.Think_05_Time
    local Slow = not VC.Think_Slow_Time or CurTime() >= VC.Think_Slow_Time
    local Medium = not VC.Think_Medium_Time or CurTime() >= VC.Think_Medium_Time
    local Fast = not VC.Think_Fast_Time or CurTime() >= VC.Think_Fast_Time
    if time_1 and VC.Think_time_1 then VC.Think_time_1() end
    if Slow_Extra and VC.Think_Slow_Extra then VC.Think_Slow_Extra() end
    if Slow and VC.Think_Slow then VC.Think_Slow() end
    if Medium and VC.Think_Medium then VC.Think_Medium() end
    if Fast and VC.Think_Fast then VC.Think_Fast() end
    if VC.Think_Instant then VC.Think_Instant() end
    if VC.Think_Instant_PerPlayer then
        for k, ply in pairs(player.GetAll()) do
            VC.Think_Instant_PerPlayer(ply)
        end
    end

    for EntLN, ent in pairs(VC.GetVehicleList()) do
        if IsValid(ent) and (CLIENT or IsValid(ent:GetPhysicsObject())) then
            ent.VC_VelLength = ent:GetVelocity():Length()
            ent.VC_Speed_Forward = ent:GetVelocity():Dot(ent:GetForward())
            local Drv = SERVER and ent:GetDriver()
            if not IsValid(Drv) or not Drv:IsPlayer() then Drv = nil end
            VC.Initialize_Basic(ent)
            if Slow_Extra and VC.Think_Slow_Extra_Each then VC.Think_Slow_Extra_Each(ent, EntLN, Drv) end
            if time_05 and VC.Think_Each_time_05 then VC.Think_Each_time_05(ent, EntLN, Drv) end
            if Slow then
                if VC.Think_Slow_Each_All then VC.Think_Slow_Each_All(ent, EntLN, Drv) end
                if VC.Think_Slow_Each_Main then VC.Think_Slow_Each_Main(ent, EntLN, Drv) end
                if VC.Think_Slow_Each_ELS then VC.Think_Slow_Each_ELS(ent, EntLN, Drv) end
            end

            if Fast and VC.Think_Fast_Each then VC.Think_Fast_Each(ent, EntLN, Drv) end
            if VC.AI_Think_Each_Instant then VC.AI_Think_Each_Instant(ent, EntLN, Drv) end
            if VC.Think_Each_Instant then VC.Think_Each_Instant(ent, EntLN, Drv) end
        end
    end

    if Slow_Extra then VC.Think_Slow_Extra_Time = CurTime() + 5 end
    if time_1 then VC.Think_1_Time = CurTime() + 1 end
    if time_05 then VC.Think_05_Time = CurTime() + 0.5 end
    if Slow then VC.Think_Slow_Time = CurTime() + 0.2 end
    if Slow then VC.Think_Slow_Time = CurTime() + 0.2 end
    if Medium then VC.Think_Medium_Time = CurTime() + 0.1 end
    if Fast then VC.Think_Fast_Time = CurTime() + 0.05 end
end)

function VC.GetTLTTR_Info(ent)
    return ent.VC_TLTTR_BInfo or 1
end

VC.Entities = {}
function VC.unregisterEntity(ent, key)
    if ent.VC_Entities then
        if ent.VC_Entities[key] then
            if IsValid(ent.VC_Entities[key]) then ent.VC_Entities[key]:Remove() end
            ent.VC_Entities[key] = nil
        end
    end
end

function VC_freemanngnida(ent, prt, key, lifetime)
    if not prt.VC_Entities then prt.VC_Entities = {} end
    if key then
        prt.VC_Entities[key] = ent
    else
        table.insert(prt.VC_Entities, ent)
    end

    if lifetime then timer.Simple(lifetime, function() if IsValid(ent) then ent:Remove() end end) end
end

function VC.clearEntity(ent)
    if ent.VC_Sounds then
        for k, v in pairs(ent.VC_Sounds) do
            v:Stop()
        end
    end

    if ent.VC_Entities then
        for k, v in pairs(ent.VC_Entities) do
            if IsValid(v) then v:Remove() end
        end
    end
end

hook.Add("EntityRemoved", "VC_Removed", function(ent)
    if ent.VC_CD_DataNeedsUpdatingTime then
        ent.VC_CD_DataNeedsUpdatingTime = CurTime()
        VC.HandleCarDealer_Slow(ent)
    end

    if ent:IsVehicle() then
        local ply = ent:GetDriver()
        if IsValid(ply) then ply.VC_ChnSts = false end
    end

    VC.clearEntity(ent)
end)

function VC.ApplyEntityParams(from, to)
    local bgroup_str = ""
    for k, v in pairs(from:GetBodyGroups()) do
        bgroup_str = bgroup_str .. from:GetBodygroup(v.id)
    end

    to:SetBodyGroups(bgroup_str)
    to:SetSkin(from:GetSkin())
    to:SetColor(from:GetColor())
end

function VC.Initialize_Basic(ent)
    if ent.VC_InitializedBasic then return end
    ent.VC_InitializedBasic = true
    if not VC.GetTLTTR_Info then return end
    if not IsValid(ent) then return end
    ent.VC_Sounds = {}
    ent.VC_Class = string.lower(ent:GetClass())
    ent.VC_isSupported = VC.classIsSupported(ent.VC_Class)
    ent.VC_IsJeep = ent.VC_Class == "prop_vehicle_jeep"
    ent.VC_IsPrisonerPod = ent.VC_Class == "prop_vehicle_prisoner_pod"
    ent.VC_IsNotPrisonerPod = not ent.VC_IsPrisonerPod
    ent.VC_IsAirboat = ent.VC_Class == "prop_vehicle_airboat"
    ent.VC_ExtraSeat = ent.VC_IsPrisonerPod and ent:GetNWBool("VC_ExtraSeat", false)
    if ent.VC_ExtraSeat then ent.VC_View_TP_Radius = math.Max(200, ent:BoundingRadius()) end
    if VC.Initialize_Basic_Stage2 then VC.Initialize_Basic_Stage2(ent) end
end

function VC_freemannobosr111(Tbl)
    local Vec = nil
    if Tbl.SpecMLine and Tbl.SpecMLine.Use and Tbl.SpecMLine.LTbl then
        if Tbl.RenderMLCenter then
            local tpos = Tbl.Pos
            for k, v in pairs(Tbl.SpecMLine.LTbl) do
                tpos = tpos + (v and v.Pos or Tbl.Pos)
            end

            Vec = tpos / (#Tbl.SpecMLine.LTbl + 1)
        else
            local ttbl = Tbl.SpecMLine.LTbl[math.floor((1 + #Tbl.SpecMLine.LTbl) / 2)]
            Vec = ttbl and ttbl.Pos or Tbl.Pos
        end
    elseif Tbl.SpecRec and Tbl.SpecRec.Use then
        Vec = ((Tbl.SpecRec.Pos1 or Vector(0, 0, 0)) + (Tbl.SpecRec.Pos2 or Vector(0, 0, 0)) + (Tbl.SpecRec.Pos3 or Vector(0, 0, 0)) + (Tbl.SpecRec.Pos4 or Vector(0, 0, 0))) / 4
    end
    return Vec
end

function VC_freemannobosrzzz(Tbl)
    local LTbl = {}
    if Tbl.Siren and Tbl.Siren.Lights then
        for Lhtk, Lt in pairs(Tbl.Siren.Lights) do
            Tbl.Siren.Lights[Lhtk].SLSPos = VC_freemannobosr111(Lt)
        end
    end

    if Tbl.Lights then
        for Lhtk, Lt in pairs(Tbl.Lights) do
            Tbl.Lights[Lhtk].SLSPos = VC_freemannobosr111(Lt)
        end

        for Lhtk, Lt in pairs(Tbl.Lights) do
            if Lt.BrakeColor and Lt.UseBrake then
                if not LTbl.Brake then LTbl.Brake = {} end
                LTbl.Brake[Lhtk] = Lt
            end

            if Lt.ReverseColor and Lt.UseReverse then
                if not LTbl.Reverse then LTbl.Reverse = {} end
                LTbl.Reverse[Lhtk] = Lt
            end

            if Lt.HeadColor and Lt.UseHead then
                Lt.HBeamColor = Lt.HeadColor
                Lt.UseHighBeams = true
                Lt.LBeamColor = Lt.HeadColor
                Lt.UseLowBeams = true
                Lt.HeadColor = nil
                Lt.UseHead = nil
            end

            if Lt.HBeamColor and Lt.UseHighBeams then
                if not LTbl.HBeam then LTbl.HBeam = {} end
                LTbl.HBeam[Lhtk] = Lt
            end

            if Lt.LBeamColor and Lt.UseLowBeams then
                if not LTbl.LBeam then LTbl.LBeam = {} end
                LTbl.LBeam[Lhtk] = Lt
            end

            if Lt.RunningColor and Lt.UseRunning then
                if not LTbl.Running then LTbl.Running = {} end
                LTbl.Running[Lhtk] = Lt
            end

            if Lt.BlinkersColor and Lt.UseBlinkers then
                if not LTbl.Blinker then LTbl.Blinker = {} end
                LTbl.Blinker[Lhtk] = Lt
            end

            if Lt.SirenColor and Lt.UseSiren then
                if not LTbl.Siren then LTbl.Siren = {} end
                LTbl.Siren[Lhtk] = Lt
            end

            if Lt.FogColor and Lt.UseFog then
                if not LTbl.Fog then LTbl.Fog = {} end
                LTbl.Fog[Lhtk] = Lt
            end

            if Lt.InterColor and Lt.UseInter then
                if not LTbl.Inter then LTbl.Inter = {} end
                LTbl.Inter[Lhtk] = Lt
            end
        end
    end
    return LTbl
end

function VC.getName(ent, default)
    local ret = nil
    if IsValid(ent) then
        local data = ent:GetNWString("VC_Name", "")
        if data ~= "" then ret = data end
    end
    return ret or default
end

local meta = FindMetaTable("Entity")
net.Receive("VC_BGroup_Changed", function(len, ply)
    local ent, var1 = net.ReadEntity(), net.ReadInt(8)
    if not IsValid(ent) then return end
    ent.VC_BGroup_Tbl = nil
    if VC.ELS_BgroupChanged then VC.ELS_BgroupChanged(ent, var1) end
end)

local function BGroupChanged(ent, var1, var2, var3)
    if IsValid(ent) and ent:IsVehicle() then
        hook.Call("VC_BodyGroupChanged", GAMEMODE, var1, var2, var3)
        hook.Call("VC_bodyGroupChanged", GAMEMODE, var1, var2, var3)
    end
end

if not meta.VC_Defaults_SetBodygroup then meta.VC_Defaults_SetBodygroup = meta.SetBodygroup end
function meta:SetBodygroup(...)
    self:VC_Defaults_SetBodygroup(...)
    if self:IsVehicle() then BGroupChanged(self, ...) end
end

if not meta.VC_Defaults_SetBodyGroups then meta.VC_Defaults_SetBodyGroups = meta.SetBodyGroups end
function meta:SetBodyGroups(...)
    self:VC_Defaults_SetBodyGroups(...)
    if self:IsVehicle() then BGroupChanged(self, ...) end
end

if not meta.VC_Defaults_SetSkin then meta.VC_Defaults_SetSkin = meta.SetSkin end
function meta:SetSkin(...)
    if IsValid(ent) and ent:IsVehicle() then
        hook.Call("VC_SkinChanged", GAMEMODE, ...)
        hook.Call("VC_skinChanged", GAMEMODE, ...)
    end

    self:VC_Defaults_SetSkin(...)
end

function VC.Compat_Refresh_PocketBlackList()
    if vcmod1 then
        if GM and GM.Config and GM.Config.PocketBlacklist then
            GM.Config.PocketBlacklist["vc_fuel_nozzle"] = true
            GM.Config.PocketBlacklist["vc_fuel_station_diesel"] = true
            GM.Config.PocketBlacklist["vc_fuel_station_petrol"] = true
            GM.Config.PocketBlacklist["vc_fuel_station_electricity"] = true
            GM.Config.PocketBlacklist["vc_npc_cardealer"] = true
            GM.Config.PocketBlacklist["vc_npc_obj_spawn"] = true
            GM.Config.PocketBlacklist["vc_npc_repair"] = true
            GM.Config.PocketBlacklist["vc_spikestrip"] = true
            GM.Config.PocketBlacklist["vc_spikestrip_pointyend"] = true
            GM.Config.PocketBlacklist["vc_spikestrip_pointyend_extended"] = true
        end
    end
end

VC.Compat_Refresh_PocketBlackList()
timer.Create("VC_Compat_Refresh_PocketBlackList", 60 * 5, 0, VC.Compat_Refresh_PocketBlackList)
local settings = {
    Enabled = true,
    Lights = true,
    Override_Controls = false,
    Currency = 1,
    Horn_Volume = 1,
    Horn_Enabled = true,
}

VC.SettingsAdd(settings, true)
VC.Color.Main = Color(0, 0, 0, 220)
VC.Color.Good = Color(155, 255, 100, 255)
VC.Color.Neutral = Color(255, 170, 0, 255)
VC.Color.Blue = Color(155, 225, 255, 255)
VC.Color.Bad = Color(255, 70, 70, 255)
VC.Color.Slider = Color(0, 0, 0, 200)
VC.Color.White = Color(220, 255, 255, 255)
VC.Color.Base = Color(237, 237, 237, 255)
VC.Color.Accent = Color(127, 37, 37, 255)
VC.Color.Accent_Light = Color(163, 48, 48, 255)
VC.Color.Btn_Add = Color(0, 125, 0, 255)
VC.Color.Btn_Rem = Color(200, 0, 0, 255)
VC.Color.Btn_Cng = Color(155, 225, 255, 255)
VC.Color.Btn_Spw = Color(155, 155, 255, 255)
VC.Color.Btn_Orn = Color(255, 180, 55, 255)
VC.FadeW = 50
VC.KBK = {
    ["KEY_A"] = {},
    ["KEY_B"] = {},
    ["KEY_C"] = {},
    ["KEY_D"] = {},
    ["KEY_E"] = {},
    ["KEY_F"] = {},
    ["KEY_G"] = {},
    ["KEY_H"] = {},
    ["KEY_I"] = {},
    ["KEY_J"] = {},
    ["KEY_K"] = {},
    ["KEY_L"] = {},
    ["KEY_M"] = {},
    ["KEY_N"] = {},
    ["KEY_O"] = {},
    ["KEY_P"] = {},
    ["KEY_Q"] = {},
    ["KEY_R"] = {},
    ["KEY_S"] = {},
    ["KEY_T"] = {},
    ["KEY_U"] = {},
    ["KEY_V"] = {},
    ["KEY_W"] = {},
    ["KEY_X"] = {},
    ["KEY_Y"] = {},
    ["KEY_Z"] = {},
    ["KEY_PAD_0"] = {
        name = "Keypad 0"
    },
    ["KEY_PAD_1"] = {
        name = "Keypad 1"
    },
    ["KEY_PAD_2"] = {
        name = "Keypad 2"
    },
    ["KEY_PAD_3"] = {
        name = "Keypad 3"
    },
    ["KEY_PAD_4"] = {
        name = "Keypad 4"
    },
    ["KEY_PAD_5"] = {
        name = "Keypad 5"
    },
    ["KEY_PAD_6"] = {
        name = "Keypad 6"
    },
    ["KEY_PAD_7"] = {
        name = "Keypad 7"
    },
    ["KEY_PAD_8"] = {
        name = "Keypad 8"
    },
    ["KEY_PAD_9"] = {
        name = "Keypad 9"
    },
    ["KEY_PAD_DIVIDE"] = {
        name = "Keypad /"
    },
    ["KEY_PAD_MULTIPLY"] = {
        name = "Keypad *"
    },
    ["KEY_PAD_MINUS"] = {
        name = "Keypad -"
    },
    ["KEY_PAD_PLUS"] = {
        name = "Keypad +"
    },
    ["KEY_PAD_ENTER"] = {
        name = "Keypad Enter"
    },
    ["KEY_PAD_DECIMAL"] = {
        name = "Keypad Del"
    },
    ["KEY_LBRACKET"] = {
        name = "Left Bracket"
    },
    ["KEY_RBRACKET"] = {
        name = "Right Bracket"
    },
    ["KEY_SEMICOLON"] = {
        name = "Semicolon"
    },
    ["KEY_APOSTROPHE"] = {
        name = 'Apostrophe'
    },
    ["KEY_BACKQUOTE"] = {
        name = "Back quote"
    },
    ["KEY_COMMA"] = {
        name = "Comma"
    },
    ["KEY_PERIOD"] = {
        name = "Period"
    },
    ["KEY_SLASH"] = {
        name = "Forward Slash"
    },
    ["KEY_BACKSLASH"] = {
        name = "Back Slash"
    },
    ["KEY_MINUS"] = {
        name = "Minus"
    },
    ["KEY_EQUAL"] = {
        name = "Equal"
    },
    ["KEY_ENTER"] = {
        name = "Enter"
    },
    ["KEY_SPACE"] = {
        name = "Space"
    },
    ["KEY_TAB"] = {
        name = "Tab"
    },
    ["KEY_CAPSLOCK"] = {
        name = "Caps Lock"
    },
    ["KEY_NUMLOCK"] = {
        name = "Num Lock"
    },
    ["KEY_SCROLLLOCK"] = {
        name = "Scroll Lock"
    },
    ["KEY_INSERT"] = {
        name = "Insert"
    },
    ["KEY_DELETE"] = {
        name = "Delete"
    },
    ["KEY_HOME"] = {
        name = "Home"
    },
    ["KEY_END"] = {
        name = "End"
    },
    ["KEY_PAGEUP"] = {
        name = "Page Up"
    },
    ["KEY_PAGEDOWN"] = {
        name = "Page Down"
    },
    ["KEY_BREAK"] = {
        name = "Break"
    },
    ["KEY_LSHIFT"] = {
        name = "Shift"
    },
    ["KEY_RSHIFT"] = {
        name = "Shift"
    },
    ["KEY_LALT"] = {
        name = "Alt"
    },
    ["KEY_RALT"] = {
        name = "Alt"
    },
    ["KEY_LCONTROL"] = {
        name = "Control"
    },
    ["KEY_RCONTROL"] = {
        name = "Control"
    },
    ["KEY_UP"] = {
        name = "Arrow Up"
    },
    ["KEY_LEFT"] = {
        name = "Arrow Left"
    },
    ["KEY_DOWN"] = {
        name = "Arrow Down"
    },
    ["KEY_RIGHT"] = {
        name = "Arrow Right"
    },
    ["KEY_F1"] = {
        name = "Function 1"
    },
    ["KEY_F2"] = {
        name = "Function 2"
    },
    ["KEY_F3"] = {
        name = "Function 3"
    },
    ["KEY_F4"] = {
        name = "Function 4"
    },
    ["KEY_F5"] = {
        name = "Function 5"
    },
    ["KEY_F6"] = {
        name = "Function 6"
    },
    ["KEY_F7"] = {
        name = "Function 7"
    },
    ["KEY_F8"] = {
        name = "Function 8"
    },
    ["KEY_F9"] = {
        name = "Function 9"
    },
    ["KEY_F10"] = {
        name = "Function 10"
    },
    ["KEY_F11"] = {
        name = "Function 11"
    },
    ["KEY_F12"] = {
        name = "Function 12"
    }
}

VC.KBK_Mouse = {
    MOUSE_LEFT = {
        name = "Mouse 1"
    },
    MOUSE_RIGHT = {
        name = "Mouse 2"
    },
    MOUSE_MIDDLE = {
        name = "Mouse 3"
    },
    MOUSE_4 = {
        name = "Mouse 4"
    },
    MOUSE_5 = {
        name = "Mouse 5"
    }
}

local Icon_Tick = Material("icon16/tick.png")
local tbl = {
    main = "vcmod1",
    els = "vcmod1_els",
    hdl = "vcmod_hdl"
}

function VC.FunctionDRAW(Sx, Sy, self)
    if self.Info then
        local size = Sx
        local Clr = table.Copy(self.Info.color)
        local Spd = self.StartSpeed
        if self:IsHovered() then
            Clr.a = 255
            Spd = Spd + 3
            size = size - 15
            draw.RoundedBox(0, 100, 60, 200, 255, VC.Color.Main)
            draw.RoundedBox(0, 100, 60, 200, 25, VC.Color.Main)
            draw.DrawText(self.Info.name, "VC_Dev_Text", 107, 60, VC.Color.Blue, TEXT_ALIGN_LEFT)
            for k, v in pairs(self.Info.features) do
                surface.SetDrawColor(255, 255, 255, 255)
                surface.SetMaterial(Icon_Tick)
                surface.DrawTexturedRect(107, 65 + k * 15, 15, 15)
                draw.DrawText(v, nil, 130, 65 + k * 15, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT)
            end

            surface.SetDrawColor(VC.Color.Blue.r, VC.Color.Blue.g, VC.Color.Blue.b, 255)
            local pcx, pcy = Sx / 2, Sy / 2
            local epx, epy = 95, 75
            local epx2, epy2 = epx + 205, epy
            for i = 1, 5 do
                surface.DrawLine(pcx + i, pcy, epx + i, epy)
            end

            for i = 1, 3 do
                surface.DrawLine(epx + i, epy + i - 1, epx2, epy2 + i - 1)
            end
        end

        local symbol = "$"
        local tclr = Color(255, 55, 0, 255)
        if self.Info.price then
            local free = nil
            if self.Info.price == "0.00" then
                tclr = VC.Color.Good
                free = true
            end

            surface.SetDrawColor(tclr)
            local pcx, pcy = Sx / 2, Sy / 2
            local epx, epy = pcx - 50, pcy - 40
            local epx2, epy2 = epx - (free and 40 or 100), epy
            for i = 1, 5 do
                surface.DrawLine(pcx + i, pcy, epx + i, epy)
            end

            for i = 1, 3 do
                surface.DrawLine(epx + i, epy + i - 1, epx2, epy2 + i - 1)
            end

            draw.DrawText(free and "free" or (symbol .. self.Info.price .. " " .. symbol .. self.Info.price_full), "VC_Dev_Text", epx2 + 5, epy2 - 15, VC.Color.Good, TEXT_ALIGN_LEFT)
            if not free then
                surface.SetDrawColor(VC.Color.Good.r, VC.Color.Good.g, VC.Color.Good.b, 255)
                surface.DrawLine(epx, epy - 6, epx - 50, epy - 6)
                surface.DrawLine(epx, epy - 7, epx - 50, epy - 7)
            end
        end

        local cur_ver = tonumber(self.Info.cur_ver)
        local addon_ver = VC.Versions[tbl[self.Info.id]]
        local Tclr = VC.Color.Blue
        local len = 115
        local text = "Not installed"
        if addon_ver then
            if VC_useBeta or cur_ver > addon_ver then
                text = "Beta"
                Tclr = VC.Color.Blue
                len = 50
            else
                text = "Up to date"
                Tclr = VC.Color.Good
                len = 100
            end
        end

        surface.SetDrawColor(tclr)
        local pcx, pcy = Sx / 2, Sy / 2
        local epx, epy = pcx - 10, pcy - 60
        local epx2, epy2 = epx + len, epy
        for i = 1, 5 do
            surface.DrawLine(pcx + i, pcy, epx + i, epy)
        end

        for i = 1, 3 do
            surface.DrawLine(epx + i, epy + i - 1, epx2, epy2 + i - 1)
        end

        draw.DrawText(text, "VC_Menu_Side", epx + 5, epy2 - 20, Tclr, TEXT_ALIGN_LEFT)
        surface.SetDrawColor(Clr.r, Clr.g, Clr.b, Clr.a)
        surface.SetMaterial(VC.Material.Circle_32)
        local sin = math.sin(CurTime() * 1 * Spd) * 5
        local TX, TY = sin * math.sin(CurTime() * 5 * Spd) * 3, sin * math.sin(CurTime() * 8 * Spd) * 3
        surface.DrawTexturedRect(Sx / 2 - size / 2 - TX / 2, Sy / 2 - size / 2 - TY / 2, size + TX, size + TY)
        local sin = math.sin(CurTime() * 2 * Spd) * 4
        local TX, TY = sin * math.sin(CurTime() * 4 * Spd) * 2, sin * math.sin(CurTime() * 9 * Spd) * 4
        surface.DrawTexturedRect(Sx / 2 - size / 2 - TX / 2, Sy / 2 - size / 2 - TY / 2, size + TX, size + TY)
        local sin = math.sin(CurTime() * 3 * Spd) * 3
        local TX, TY = sin * math.sin(CurTime() * 3 * Spd) * 1, sin * math.sin(CurTime() * 10 * Spd) * 2
        surface.DrawTexturedRect(Sx / 2 - size / 2 - TX / 2, Sy / 2 - size / 2 - TY / 2, size + TX, size + TY)
        draw.DrawText(self.Info.title, Hov and "VC_Big" or "VC_Big", Sx / 2, Sy / 2 - 15, Color(255, 255, 255, self:IsHovered() and 255 or Clr.a), TEXT_ALIGN_CENTER)
    end
end

local El = {}
function El:Init()
    self.VC_Button = vgui.Create("DButton", self)
    self.VC_Button:SetSize(self:GetSize())
    self.VC_Button:SetText("")
    self.VC_Button.Paint = function(obj, Sx, Sy) end
end

function El:Setup(Tbl)
    self.VC_Button:SetSize(self:GetSize())
    self.VC_Button.Info = Tbl
    self.VC_Button.StartSpeed = math.Rand(0.6, 1)
    if Tbl.link then
        self.VC_Button.DoClick = function()
            local Tclr = VC.Color.Blue
            local len = 115
            local DDM = VC.DermaMenu("VCMod " .. Tbl.name)
            DDM:AddLabel("Version: " .. Tbl.cur_ver)
            DDM:AddLabel("Price: " .. (Tbl.price == 0 and "free" or (Tbl.price .. "USD")))
            DDM:AddSpacer()
            if Tbl.trailer then DDM:AddButton("Watch trailer", function() gui.OpenURL(Tbl.trailer) end):SetImage("icon16/film.png") end
            if Tbl.link then DDM:AddButton("Download", function() gui.OpenURL(Tbl.link) end):SetImage("icon16/plugin.png") end
            DDM:Open()
        end
    end
end

function El:Paint(Sx, Sy)
    VC.FunctionDRAW(Sx, Sy, self.VC_Button)
end

vgui.Register("VC_Ball", El)
local El = {}
function El:Init()
    self.VC_List1, self.VC_List2, self.VC_Button = vgui.Create("DListView", self), vgui.Create("DListView", self), vgui.Create("DImageButton", self)
    self.VC_Button:SetMaterial(VC.Material.icon_right)
end

function El:Think()
    local PWth = self:GetParent():GetWide()
    self.VC_List1:SetTall(self.VC_Tall)
    self.VC_List1:SetWide(PWth * 0.47)
    self.VC_List2:SetWide(PWth * 0.47)
    self.VC_List2:SetTall(self.VC_Tall)
    self.VC_List2:SetPos(PWth - PWth * 0.47, 0)
    self.VC_Button:SetWide(PWth * 0.06)
    local BtnHt = math.min(50, self.VC_Tall)
    self.VC_Button:SetPos(PWth * 0.47, self.VC_Tall / 2 - BtnHt / 2)
    self.VC_Button:SetTall(BtnHt)
end

vgui.Register("VC_Lists", El)
local El_TxtNtr = {}
function El_TxtNtr:Init()
    self.VC_TxtNtr, self.VC_TxtNtrLbl = vgui.Create("DTextEntry", self), vgui.Create("DLabel", self)
end

function El_TxtNtr:SetTextColor(clr)
    self.VC_TxtNtrLbl:SetTextColor(clr)
end

function El_TxtNtr:GetValue()
    self.VC_TxtNtr:GetValue()
end

function El_TxtNtr:Think()
    if not self.VC_AsnedChng and self.VC_TextChngd then
        self.VC_TxtNtr.OnTextChanged = self.VC_TextChngd
        self.VC_AsnedChng = true
    end

    if not self.VC_AsnedInfo then
        self.VC_TxtNtrLbl:SetText(self.VC_Text)
        self.VC_AsnedInfo = true
    end

    local PWth = self:GetParent():GetWide()
    local EWth = PWth * (self.VC_TxtNtrPrc or 0.7)
    self.VC_TxtNtr:SetWide(EWth)
    self.VC_TxtNtrLbl:SetPos(math.Clamp(EWth + 6, 0, PWth), 0)
    self.VC_TxtNtrLbl:SetWide(math.Clamp(PWth - EWth - 6, 0, PWth))
end

vgui.Register("VC_TextEntry", El_TxtNtr)
local El = {}
function El:Init()
    self.Color = VC.Color.Blue
end

function El:Paint(Sx, Sy)
    local clr = self:GetColor()
    if clr then draw.RoundedBox(0, 4, Sy / 2 - 1, Sx - 8, 2, clr) end
end

function El:SetColor(val)
    self.Color = val
end

function El:GetColor()
    return self.Color
end

derma.DefineControl("VC_Line", "A tiny line spanning accross the x axis.", El, "Panel")
local El = {}
function El:Init()
    self:SetTall(40)
    self.Color = VC.Color.Blue
end

function El:Paint(Sx, Sy)
    local clr = self:GetColor()
    if not clr then clr = VC.Color.Blue end
    draw.SimpleText(self:GetText() or VC.Lng("Unknown"), "VC_DEV_lower", Sx / 2, Sy / 2, clr, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    draw.RoundedBox(1, 4, Sy - 2 - 5, Sx - 8, 2, clr)
end

function El:SetText(val)
    self.Text = val
end

function El:GetText()
    return self.Text
end

function El:SetColor(val)
    self.Color = val
end

function El:GetColor()
    return self.Color
end

derma.DefineControl("VC_Banner", "A tiny banner with a line.", El, "Panel")
local El_Cnt = {}
function El_Cnt:Paint()
    if not self.VC_AsgndInf then return end
    self.VC_BtnSlcTNm = self.VC_BtnSlcTNm or 0
    local CMS, BW, BH = self.VC_BtnSlcTNm > 0 and ((80 + math.sin(CurTime() * 10) * 8) * self.VC_BtnSlcTNm) or 20, self:GetSize()
    if self.VC_AwaitInput and self.VC_BtnSlcTNm < 1 then
        self.VC_BtnSlcTNm = self.VC_BtnSlcTNm + 0.05
    elseif not self.VC_AwaitInput and self.VC_BtnSlcTNm > 0 then
        self.VC_BtnSlcTNm = self.VC_BtnSlcTNm - 0.03
    end

    draw.RoundedBox(0, BW / 2, 0, BW / 2, BH, Color(CMS, (self.VC_BtnInfo[2] or self.VC_BtnCmd == "vc_holdkey") and 65 or 50, 70 - 80 * self.VC_BtnSlcTNm, 255))
    if self:CheckIfOverwritten() then
        draw.RoundedBox(0, 0, 0, BW / 2, BH, Color(0, 0, 0, 255))
        draw.RoundedBox(0, BW / 2, 0, BW / 2, BH, Color(0, 0, 0, 55))
    else
        draw.RoundedBox(0, 0, 0, BW / 2, BH, Color(90, 20, 00, 255))
    end
end

function El_Cnt:OnMousePressed(MB)
    if MB == MOUSE_LEFT then
        if not self.VC_AwaitInput and not self:CheckIfOverwritten() then
            self.VC_BtnKey:SetText(VC.Lng("EnterKey"))
            self.VC_AwaitInput_Time = CurTime() + 5
            self.VC_AwaitInput = true
        end
    end
end

function El_Cnt:CheckIfOverwritten()
    return not self.VC_Override and VC.getServerSetting("Override_Controls") and VC.Override_Controls and VC.Override_Controls[self.VC_BtnCmd] and tostring(VC.Override_Controls[self.VC_BtnCmd].use) == "1"
end

function El_Cnt:Think()
    local ctbl = VC.Controls_List
    if self.VC_Override or self:CheckIfOverwritten() then
        ctbl = VC.Override_Controls
        if self.VC_Override and self.VC_BtnCmd and ctbl and not ctbl[self.VC_BtnCmd] then ctbl[self.VC_BtnCmd] = VC.Controls_List[self.VC_BtnCmd] end
    end

    if not ctbl then ctbl = {} end
    local Width = self:GetWide() / 2 + 10
    if self.VC_BtnInfo and not self.VC_AsgndInf then
        self.VC_BtnInfLbl = vgui.Create("DLabel", self)
        self.VC_BtnInfLbl:SetSize(Width - 18, 20)
        self.VC_BtnInfLbl:SetPos(8, 2)
        self.VC_BtnInfLbl:SetText((self:CheckIfOverwritten() and ("{{" .. VC.Lng("Overwritten") .. "}} ") or "") .. VC.Lng(self.VC_BtnInfo[1]))
        self.VC_BtnKey = vgui.Create("DLabel", self)
        self.VC_BtnKey:SetSize(Width, 20)
        local GCN = (ctbl[self.VC_BtnCmd] or {}).key or "None"
        self.VC_BtnKey:SetText((self.VC_BtnInfo[2] and (VC.Lng("HoldKey") .. " + ") or "") .. VC.Lng(GCN == "None" and "None" or (VC.KBK[GCN] or VC.KBK_Mouse[GCN]).name or string.Explode("KEY_", ctbl[self.VC_BtnCmd].key)[2]))
        self.VC_AsgndInf = true
    end

    if self.VC_BtnKey then self.VC_BtnKey:SetPos(Width, 2) end
    if self.VC_AwaitInput and vgui.CursorVisible() and self.VC_AwaitInput_Time and CurTime() < self.VC_AwaitInput_Time then
        self.VC_BtnInit = true
        if input.IsKeyDown(KEY_BACKSPACE) then
            RunConsoleCommand(self.VC_Override and "VC_SetControl_Override" or "VC_SetControl", self.VC_BtnCmd, "None")
            self.VC_BtnKey:SetText("None")
            self.VC_AwaitInput = nil
            self.VC_BtnTxt = nil
        end

        for KLk, KLv in pairs(VC.KBK) do
            if input.IsKeyDown(_G[KLk]) and not KLv[self] then
                KLv[self] = true
            elseif not input.IsKeyDown(_G[KLk]) and KLv[self] and self.VC_BtnCmd then
                self.VC_BtnTxt = KLv.name or string.Explode("KEY_", KLk)[2]
                RunConsoleCommand(self.VC_Override and "VC_SetControl_Override" or "VC_SetControl", self.VC_BtnCmd, KLk)
                self.VC_BtnKey:SetText(self.VC_BtnTxt)
                self.VC_AwaitInput = nil
            end
        end

        if CurTime() >= (self.VC_AwaitInput_Time - 4.8) then
            for KLk, KLv in pairs(VC.KBK_Mouse) do
                if input.IsMouseDown(_G[KLk]) and not KLv[self] then
                    KLv[self] = true
                elseif not input.IsMouseDown(_G[KLk]) and KLv[self] and self.VC_BtnCmd then
                    self.VC_BtnTxt = KLv.name
                    RunConsoleCommand(self.VC_Override and "VC_SetControl_Override" or "VC_SetControl", self.VC_BtnCmd, KLk, "0", "1")
                    self.VC_BtnKey:SetText(self.VC_BtnTxt)
                    self.VC_AwaitInput = nil
                end
            end
        end
    elseif self.VC_BtnInit then
        local GCN = (ctbl[self.VC_BtnCmd] or {}).key or "None"
        self.VC_BtnKey:SetText((self.VC_BtnInfo[2] and (VC.Lng("HoldKey") .. " + ") or "") .. VC.Lng((self.VC_BtnTxt == "None" or GCN == "None") and "None" or (VC.KBK[GCN] or VC.KBK_Mouse[GCN]).name or string.Explode("KEY_", ctbl[self.VC_BtnCmd].key)[2]))
        for KLk, KLv in pairs(VC.KBK) do
            KLv[self] = nil
        end

        for KLk, KLv in pairs(VC.KBK_Mouse) do
            KLv[self] = nil
        end

        self.VC_AwaitInput = nil
        self.VC_BtnInit = nil
    end
end

vgui.Register("VC_Control", El_Cnt)
local El_Cnt_Chk = {}
function El_Cnt_Chk:Think()
    if self.VC_BtnInfo and not self.VC_AsgndInf then
        local ctbl = VC.Controls_List
        if self.VC_Override then ctbl = VC.Override_Controls end
        if not ctbl then ctbl = {} end
        self.VC_Control = vgui.Create("VC_Control", self)
        self.VC_Control.VC_Override = self.VC_Override
        self.VC_Control.VC_BtnInfo = self.VC_BtnInfo
        self.VC_Control.VC_BtnCmd = self.VC_BtnCmd
        self.VC_CheckBox = vgui.Create("DCheckBox", self)
        self.VC_CheckBox:SetValue(ctbl[self.VC_BtnCmd] and ctbl[self.VC_BtnCmd].hold or 0)
        self.VC_CheckBox:SetToolTip("Hold")
        self.VC_CheckBox.OnChange = function(CBP, CBV) RunConsoleCommand(self.VC_Override and "VC_SetControl_Override" or "VC_SetControl", self.VC_BtnCmd, "Hold", CBV and "1" or "0") end
        self.VC_AsgndInf = true
    end

    if self.VC_Control then
        self.VC_Control:SetSize(self:GetSize())
        if self.VC_Control:CheckIfOverwritten() then self.VC_CheckBox:SetDisabled(true) end
        self.VC_CheckBox:SetPos(self:GetWide() - 20, 4)
    end
end

vgui.Register("VC_Control_CheckBox", El_Cnt_Chk)
local El_Pnl = {}
function El_Pnl:Think()
    if self.VC_BTbl then
        local DoIcons = #self.VC_BTbl == 2 and self:GetWide() < 200
        for Bk, Bv in pairs(self.VC_BTbl) do
            if not self.VC_BTbl[Bk].info then
                local Btn = vgui.Create("VC_Button", self)
                Btn:SetText(Bv.name)
                if Bv.tooltip then Btn:SetToolTip(Bv.tooltip) end
                if Bv.clk then Btn.DoClick = Bv.clk end
                self.VC_BTbl[Bk].btn = Btn
                self.VC_BTbl[Bk].info = true
                Btn:SetTextIsWhite(true)
                if Bk == 1 then
                    Btn:SetColor(VC.Color.Btn_Add)
                    if DoIcons then Btn.VC_DrawIcon = "Add" end
                elseif Bk == (self.RemoveButton or 2) then
                    Btn:SetColor(VC.Color.Btn_Rem)
                    if DoIcons then Btn.VC_DrawIcon = "Rem" end
                else
                    Btn:SetColor(VC.Color.Btn_Cng)
                    Btn:SetTextIsWhite(false)
                end

                if Bv.paint then Btn.Paint = Bv.paint end
            end

            local Sx, Sy = self:GetSize()
            Bv.btn:SetPos(Sx / #self.VC_BTbl * (Bk - 1))
            Bv.btn:SetSize(Sx / #self.VC_BTbl - 1, Sy)
        end
    end
end

vgui.Register("VC_ARB", El_Pnl)
local function Init(self)
    local PosX = 0
    self.VC_Panels = {}
    for k, v in pairs(VC.DevPanelDimentions) do
        self.VC_Panels[k] = vgui.Create("DPanelList")
        self.VC_Panels[k]:EnableVerticalScrollbar(true)
        self.VC_Panels[k]:SetParent(self)
    end

    self.VC_DevPanelDimentions = table.Copy(VC.DevPanelDimentions)
    VC.DevPanelDimentions = nil
end

local function Think(self)
    if self.VC_Panels and self.VC_Parent and self.VC_DevPanelDimentions then
        local PosX = 0
        local Sx, Sy = self.VC_Parent:GetSize()
        for k, v in pairs(self.VC_DevPanelDimentions) do
            self.VC_Panels[k]:SetPos(PosX, 0)
            self.VC_Panels[k]:SetSize(Sx * v - (self.VC_Panels[k + 1] and 2 or 0), Sy)
            PosX = PosX + Sx * v
        end
    end
end

local El_Pnl = {}
function El_Pnl:Init()
    Init(self)
end

function El_Pnl:Think()
    Think(self)
end

function El_Pnl:Paint()
    for k, v in pairs(self.VC_Panels) do
        local Px, Py = v:GetPos()
        local Sx, Sy = v:GetSize()
        draw.RoundedBox(0, Px, Py, Sx, Sy - 4, Color(0, 0, 0, 120))
    end
end

vgui.Register("VC_Panel", El_Pnl)
local El_Pnl = {}
function El_Pnl:Init()
    Init(self)
end

function El_Pnl:Think()
    Think(self)
end

vgui.Register("VC_Panel_NoDraw", El_Pnl)
local El_Pnl = {}
function El_Pnl:Init()
    Init(self)
end

function El_Pnl:Think()
    Think(self)
end

function El_Pnl:Paint()
    local Sx, Sy = self:GetSize()
    draw.RoundedBox(0, 0, 0, Sx, Sy - 4, Color(0, 0, 0, 120))
end

vgui.Register("VC_Panel_Draw_Whole", El_Pnl)
local El = {}
function El:SetColor(val)
    self.VC_Color = val
end

function El:SetPulseColor(val)
    self.VC_PulseColor = val
end

function El:SetFont(val)
    self.VC_Font = val
end

function El:SetKey(val)
    self.VC_Key = "[" .. string.upper(val) .. "]"
end

function El:SetText(val)
    self.VC_Text = val
end

function El:SetTextIsWhite(val)
    self.VC_IsWhiteText = val
end

function El:Paint(Sx, Sy)
    local cx, cy = Sx / 2, Sy / 2
    if not self.VC_ClrNil then
        self.VC_ClrNil = true
        self:SetTextColor(Color(0, 0, 0, 0))
    end

    local hov = self:IsHovered()
    local dwn = self:IsDown()
    local clr = self.VC_Color or VC.Color.Blue
    if self.VC_PulseColor and math.sin(CurTime() * 50) > 0 then clr = self.VC_PulseColor end
    local clr_t = table.Copy(clr)
    clr_t.a = 25
    draw.RoundedBox(0, 0, 0, Sx, Sy, Color(0, 0, 0, 255))
    draw.RoundedBox(0, 0, 0, Sx, Sy, clr_t)
    if dwn then
        clr_t.a = 255
        draw.RoundedBox(0, 0, 0, Sx, Sy, clr_t)
    elseif hov then
        draw.RoundedBox(0, 0, 0, Sx, Sy, clr_t)
    end

    draw.RoundedBox(0, 1, Sy - 2, Sx - 1, 2, clr)
    if self.VC_DrawIcon then
        local nclr = VC.Color.Good
        local icon = VC.Material.icon_add
        if self.VC_DrawIcon == "Rem" then
            nclr = VC.Color.Bad
            icon = VC.Material.icon_remove
        end

        surface.SetDrawColor(255, 255, 255, 255)
        surface.SetMaterial(icon)
        local sz = Sy * 0.8
        surface.DrawTexturedRect(cx - sz / 2, cy - sz / 2, sz, sz)
    else
        local pos_y = cy - (Sy > 50 and 12 or 8)
        draw.DrawText(self.VC_Text or "", self.VC_Font, cx, pos_y, dwn and Color(0, 0, 0, 255) or VC.Color.White, TEXT_ALIGN_CENTER)
        if self.VC_Key then draw.DrawText(self.VC_Key or "", nil, Sx - 3, pos_y, clr, TEXT_ALIGN_RIGHT) end
    end
end

derma.DefineControl("VC_Button", "VCMod's button.", El, "DButton")
local El_MBtn = {}
function El_MBtn:Think()
    if self.VC_BTbl then
        for Bk, Bv in pairs(self.VC_BTbl) do
            if not self.VC_BTbl[Bk].info then
                local Btn = vgui.Create("VC_Button", self)
                Btn:SetText(Bv.name)
                if Bv.tooltip then Btn:SetToolTip(Bv.tooltip) end
                if Bv.clk then Btn.DoClick = Bv.clk end
                self.VC_BTbl[Bk].btn = Btn
                self.VC_BTbl[Bk].info = true
                if Bv.clr then Btn:SetColor(Bv.clr) end
                if Bv.IsTextWhite then Btn:SetTextIsWhite(Bv.IsTextWhite) end
            end

            local Sx, Sy = self:GetSize()
            Bv.btn:SetPos(Sx / #self.VC_BTbl * (Bk - 1))
            Bv.btn:SetSize(Sx / #self.VC_BTbl - 1, Sy)
        end
    end
end

vgui.Register("VC_MultiButton", El_MBtn)
local El = {}
function El:Init()
    self.VC_List = vgui.Create("DComboBox", self)
    self.VC_Max = 0
    self.VC_Sel = 0
    self.VC_List.OnSelect = function(...) self.OnSelect(...) end
    self.VC_Btn1 = vgui.Create("DImageButton", self)
    self.VC_Btn1:SetMaterial(VC.Material.icon_left)
    self.VC_Btn1:SetToolTip("Select previous in the list.")
    self.VC_Btn1:SetWidth(25)
    self.VC_Btn2 = vgui.Create("DImageButton", self)
    self.VC_Btn2:SetMaterial(VC.Material.icon_right)
    self.VC_Btn2:SetToolTip("Select next in the list.")
    self.VC_Btn2:SetWidth(25)
    self.VC_Btn3 = vgui.Create("DImageButton", self)
    self.VC_Btn3:SetMaterial(VC.Material.icon_search)
    self.VC_Btn3:SetToolTip("Display all data.")
    self.VC_Btn3:SetWidth(25)
    self.VC_Btn1.DoClick = function()
        local sel = self:GetSelected()
        if sel and sel > 1 then self:ChooseOptionID(sel - 1) end
    end

    self.VC_Btn2.DoClick = function()
        local sel = self:GetSelected()
        local cnt = table.Count(self.VC_List.Choices)
        if cnt > 0 and (not sel or cnt > sel) then self:ChooseOptionID((sel or 0) + 1) end
    end
end

function El:AddChoice(...)
    if self.VC_List then return self.VC_List:AddChoice(...) end
end

function El:ChooseOption(...)
    if self.VC_List then self.VC_List:ChooseOption(...) end
end

function El:ChooseOptionID(...)
    if self.VC_List then self.VC_List:ChooseOptionID(...) end
end

function El:GetSelected()
    local ret = self.VC_List and self.VC_List.selected
    return ret
end

function El:Clear(...)
    if self.VC_List then self.VC_List:Clear(...) end
end

function El:OnSelect(...)
end

function El:Think()
    if self.VC_List then
        local Sx, Sy = self:GetSize()
        if self.VC_DontDoView then
            self.VC_List:SetWidth(Sx - 50)
            self.VC_Btn1:SetPos(Sx - 50, 0)
            self.VC_Btn2:SetPos(Sx - 25, 0)
            self.VC_Btn3:Remove()
        else
            self.VC_List:SetWidth(Sx - 75)
            self.VC_Btn1:SetPos(Sx - 75, 0)
            self.VC_Btn2:SetPos(Sx - 50, 0)
            self.VC_Btn3:SetPos(Sx - 25, 0)
        end
    end
end

vgui.Register("VC_DComboBox", El)
local El_Vec = {}
function El_Vec:Init()
    self:DockPadding(2, 2, 2, 2)
    self.VC_VecLbl = vgui.Create("DLabel", self)
    self.VC_VecLbl:SetSize(37, 24)
    self.VC_VecLbl:Dock(FILL)
    self.VC_VecZ = vgui.Create("DNumberWang", self)
    self.VC_VecZ:SetSize(50, 20)
    self.VC_VecZ:Dock(RIGHT)
    self.VC_VecY = vgui.Create("DNumberWang", self)
    self.VC_VecY:SetSize(50, 20)
    self.VC_VecY:Dock(RIGHT)
    self.VC_VecX = vgui.Create("DNumberWang", self)
    self.VC_VecX:SetSize(50, 20)
    self.VC_VecX:Dock(RIGHT)
    self.VC_VecX.OnValueChanged = function(idx, val) if not self.IgnoreChange and self.OnChange then self.OnChange(nil, self:GetValue()) end end
    self.VC_VecY.OnValueChanged = function(idx, val) if not self.IgnoreChange and self.OnChange then self.OnChange(nil, self:GetValue()) end end
    self.VC_VecZ.OnValueChanged = function(idx, val) if not self.IgnoreChange and self.OnChange then self.OnChange(nil, self:GetValue()) end end
end

function El_Vec:SetText(val)
    if self.VC_VecLbl then self.VC_VecLbl:SetText(val) end
end

function El_Vec:SetColor(val)
    if self.VC_VecLbl then self.VC_VecLbl:SetColor(val) end
end

function El_Vec:Setup(text, min, max, dec)
    if not text then text = "" end
    self.VC_Text = text
    if not min then min = -2000 end
    if not max then max = 2000 end
    if not dec then dec = 2 end
    self.VC_VecX:SetMin(min)
    self.VC_VecX:SetMax(max)
    self.VC_VecX:SetDecimals(dec)
    self.VC_VecY:SetMin(min)
    self.VC_VecY:SetMax(max)
    self.VC_VecY:SetDecimals(dec)
    self.VC_VecZ:SetMin(min)
    self.VC_VecZ:SetMax(max)
    self.VC_VecZ:SetDecimals(dec)
    self:SetText(text)
    self.VC_VecX:SetValue(0)
    self.VC_VecY:SetValue(0)
    self.VC_VecZ:SetValue(0)
end

function El_Vec:SetValue(vec)
    if not self.VC_VecX:IsEnabled() then return end
    if not vec then
        vec = Vector(0, 0, 0)
    elseif type(vec) ~= "vector" then
        vec = Vector(vec[1], vec[2], vec[3])
    end

    vec = Vector(math.Round(vec[1] * 100) / 100, math.Round(vec[2] * 100) / 100, math.Round(vec[3] * 100) / 100)
    if vec.x ~= self.VC_VecX:GetValue() or vec.y ~= self.VC_VecY:GetValue() or vec.z ~= self.VC_VecZ:GetValue() then
        self.IgnoreChange = true
        self.VC_VecX:SetValue(vec.x)
        self.VC_VecY:SetValue(vec.y)
        self.VC_VecZ:SetValue(vec.z)
        self.IgnoreChange = nil
        if self.OnChange then self.OnChange(nil, vec) end
    end
end

function El_Vec:SetEnabled(on)
    self.VC_VecX:SetEnabled(on)
    self.VC_VecY:SetEnabled(on)
    self.VC_VecZ:SetEnabled(on)
end

function El_Vec:GetValue()
    return Vector(self.VC_VecX:GetValue(), self.VC_VecY:GetValue(), self.VC_VecZ:GetValue())
end

derma.DefineControl("VC_Vector", "A nice tiny vector.", El_Vec, "Panel")
if not VC.Menu_Items_P then VC.Menu_Items_P = {} end
if not VC.Menu_Items_A then VC.Menu_Items_A = {} end
local function BuildMenu(Pnl)
    local Font2 = "VC_Treb24_Small"
    if not VC.Fonts[Font2] then
        VC.Fonts[Font2] = true
        surface.CreateFont(Font2, {
            font = "Trebuchet24",
            size = 17,
            weight = 500,
            blursize = 0,
            scanlines = 0,
            antialias = true,
            underline = false,
            italic = false,
            strikeout = false,
            symbol = false,
            rotary = false,
            shadow = false,
            additive = false,
            outline = false
        })
    end

    local Font3 = "VC_Treb24_12"
    if not VC.Fonts[Font3] then
        VC.Fonts[Font3] = true
        surface.CreateFont(Font3, {
            font = "Trebuchet24",
            size = 12,
            weight = 500,
            blursize = 0,
            scanlines = 0,
            antialias = true,
            underline = false,
            italic = false,
            strikeout = false,
            symbol = false,
            rotary = false,
            shadow = false,
            additive = false,
            outline = false
        })
    end

    local Font_Logo = "VC_Logo"
    if not VC.Fonts[Font_Logo] then
        VC.Fonts[Font_Logo] = true
        surface.CreateFont(Font_Logo, {
            font = "MenuLarge",
            size = 40,
            weight = 1000,
            blursize = 2,
            scanlines = 0,
            antialias = true,
            underline = false,
            italic = false,
            strikeout = false,
            symbol = false,
            rotary = false,
            shadow = false,
            additive = false,
            outline = false
        })
    end

    local List = VC.Add_El_List(7, 130, Pnl:GetWide() - 14, Pnl:GetTall() - 82)
    List:SetParent(Pnl)
    List:SetSpacing(7)
    Pnl.Paint = function(obj, Sx, Sy)
        draw.DrawText(game.SinglePlayer() and VC.Lng("YouAreUsingVCMod") or VC.Lng("ServerIsUsingVCMod"), "VC_Big_Italic", List:GetWide() / 2, 5, VC.Color.Blue, TEXT_ALIGN_CENTER)
        draw.DrawText(VC.Lng("Info_EverThought"), Font2, 50, 50, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT)
        draw.DrawText(VC.Lng("Info_VCModIsDesigned"), Font2, 10, 68, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT)
        draw.DrawText(VC.Lng("Info_VCModHasFollowingAddons"), Font2, 10, 100, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT)
    end

    local news = vgui.Create("DHTML", Pnl)
    news:OpenURL("https://vcmod.org/" .. "api/news_v3.php?st=ns")
    news:SetPos(5, Pnl:GetTall() * 0.7)
    news:SetSize(Pnl:GetWide() - 10, 152)
    news.Paint = function(obj, Sx, Sy)
        draw.RoundedBox(0, 0, 0, Sx, Sy, Color(255, 255, 255, 255))
        draw.DrawText(VC.Lng("WhyISellVCMod"), Font3, Sx + 5, 8, VC.Color.Blue, TEXT_ALIGN_RIGHT)
    end

    local objects = {}
    if VC.DataServer then
        for k, v in pairs(VC.DataServer) do
            local El = vgui.Create("VC_Ball", Pnl)
            El:SetSize(v.size, v.size)
            El:SetPos(Pnl:GetWide() * v.pos_x - v.size / 2, Pnl:GetTall() * v.pos_y - v.size / 2)
            local Px, Py = El:GetPos()
            objects[k] = {El, Px, Py, math.Rand(0.5, 3), math.Rand(0.5, 3), math.Rand(2, 4), math.Rand(2, 4)}
            El:Setup(v)
            El:NoClipping(true)
        end
    end

    Pnl.Think = function()
        for k, v in pairs(objects) do
            local Px, Py = v[2], v[3]
            local sin = math.sin(CurTime() * v[4]) * v[6]
            v[1]:SetPos(Px + math.sin(CurTime() * v[4]) * v[6], Py + math.sin(CurTime() * v[5]) * v[7])
        end
    end

    local Btn = vgui.Create("DButton")
    Btn:SetPos(5, Pnl:GetTall() - 185)
    Btn:SetSize(145, 25)
    Btn:SetText(" ")
    Btn:SetParent(Pnl)
    Btn:NoClipping(true)
    Btn.DoClick = function() chat.AddText('Потому что жидман - пидор') end
    Btn.Paint = function(stuff, Sx, Sy)
        if Btn:IsHovered() then
            local clr = table.Copy(VC.Color.Main)
            draw.RoundedBox(0, 0, 0, Sx + 12, Sy, clr)
        end

        draw.DrawText(VC.Lng("WhyISellVCMod"), Font3, Sx / 2 + 5, 8, VC.Color.Blue, TEXT_ALIGN_CENTER)
    end

    local Btn = vgui.Create("DButton")
    Btn:SetPos(Pnl:GetWide() - 130, Pnl:GetTall() - 185)
    Btn:SetSize(125, 25)
    Btn:SetText(" ")
    Btn:SetParent(Pnl)
    Btn:NoClipping(true)
    Btn.Paint = function(stuff, Sx, Sy)
        if Btn:IsHovered() then
            local clr = table.Copy(VC.Color.Main)
            draw.RoundedBox(0, 0, 0, Sx + 12, Sy, clr)
        end

        draw.DrawText(VC.Lng("CreatedBy") .. ": ", Font3, Sx - 60, 8, VC.Color.Blue, TEXT_ALIGN_RIGHT)
        draw.DrawText("DurkaTeam", Font3, Sx - 5, 8, VC.Color.Good, TEXT_ALIGN_RIGHT)
    end
end

VC.Menu_Info_Panel_Build = {"Info", BuildMenu}
local function BuildMenu(Pnl)
    local PW = Pnl:GetWide()
    local List = VC.Add_El_List(0, 40, PW, Pnl:GetTall() - 40)
    List:SetParent(Pnl)
    local html = vgui.Create("DHTML", List)
    html:OpenURL(VC.Host .. "ingame/changelog2/general/")
    html:SetPos(0, 0)
    html:SetSize(List:GetSize())
    html.Paint = function(obj, Sx, Sy)
        surface.SetDrawColor(VC.Color.Base)
        surface.DrawRect(0, 0, Sx, Sy)
    end

    local X, Y = List:GetPos()
    local Sx, Sy = List:GetSize()
    Pnl.Paint = function(obj, Sx, Sy) draw.DrawText(VC.Lng("UpdatesAreAppliedAutomaticallyAfterMapRestart"), "VC_Dev_Text", List:GetWide() / 2, 10, VC.Color.White, TEXT_ALIGN_CENTER) end
    return Draw
end

VC.Menu_Update_Panel_Build = {"Updates", BuildMenu}
local function BuildMenu(Pnl)
    local Font_Link = "VC_Link"
    if not VC.Fonts[Font_Link] then
        VC.Fonts[Font_Link] = true
        surface.CreateFont(Font_Link, {
            font = "MenuLarge",
            size = 14,
            weight = 0,
            blursize = 0,
            scanlines = 0,
            antialias = true,
            underline = true,
            italic = false,
            strikeout = false,
            symbol = false,
            rotary = false,
            shadow = false,
            additive = false,
            outline = false
        })
    end

    local PW = Pnl:GetWide()
    local List = VC.Add_El_List(5, 40, PW, Pnl:GetTall() - 100)
    List:SetParent(Pnl)
    local MPnl = VC.Add_El_Panel(List, {0.2, 0.15, 0.25, 0.2, 0.1}, 25, true)
    local SNLbl = vgui.Create("DLabel")
    SNLbl:SetText(VC.Lng('Language'))
    SNLbl:SetWide(PW * 0.3)
    SNLbl:SetColor(Color(200, 200, 255, 255))
    SNLbl:SetFont("VC_Info_Small")
    MPnl[1]:AddItem(SNLbl)
    local SNLbl = vgui.Create("DLabel")
    SNLbl:SetText(VC.Lng('Revision'))
    SNLbl:SetWide(PW * 0.3)
    SNLbl:SetFont("VC_Info_Smaller")
    MPnl[2]:AddItem(SNLbl)
    local SNLbl = vgui.Create("DLabel")
    SNLbl:SetText(VC.Lng('Author'))
    SNLbl:SetWide(PW * 0.3)
    SNLbl:SetFont("VC_Info_Smaller")
    MPnl[3]:AddItem(SNLbl)
    local SNLbl = vgui.Create("DLabel")
    SNLbl:SetText(VC.Lng('Date'))
    SNLbl:SetWide(PW * 0.3)
    SNLbl:SetFont("VC_Info_Smaller")
    MPnl[4]:AddItem(SNLbl)
    local SNLbl = vgui.Create("DLabel")
    SNLbl:SetText(VC.Lng('Status'))
    SNLbl:SetWide(PW * 0.3)
    SNLbl:SetFont("VC_Info_Smaller")
    MPnl[5]:AddItem(SNLbl)
    if VC.Lng_T then
        for k, v in SortedPairs(VC.Lng_T) do
            local MPnl = VC.Add_El_Panel(List, {0.2, 0.15, 0.25, 0.2, 0.15}, 20, 2)
            local SNLbl = vgui.Create("DLabel")
            SNLbl:SetText(VC.lngData[k] or 1)
            SNLbl:SetWide(PW * 0.2)
            SNLbl:SetColor(VC.Color.Good)
            MPnl[2]:AddItem(SNLbl)
            local SNLbl = vgui.Create("DLabel")
            SNLbl:SetText(string.upper(k) .. "  " .. v.Name)
            SNLbl:SetWide(PW * 0.25)
            SNLbl:SetColor(Color(200, 200, 255, 255))
            MPnl[1]:AddItem(SNLbl)
            local UpToDate = table.Count(v) >= table.Count(VC.Lng_Default)
            local SNLbl = vgui.Create("DLabel")
            SNLbl:SetText(UpToDate and VC.Lng("Good") or VC.Lng("Outdated"))
            SNLbl:SetWide(PW * 0.3)
            SNLbl:SetColor(UpToDate and VC.Color.Good or VC.Color.Bad)
            MPnl[5]:AddItem(SNLbl)
            local Btn = vgui.Create("DButton")
            Btn:SetSize(50, 15)
            Btn:SetText("")
            MPnl[3]:AddItem(Btn)
            Btn.DoClick = function()
                if v.Translated_By_Link then
                    gui.OpenURL(v.Translated_By_Link)
                else
                    VCPopup("Sorry, no link found.", "cross")
                end
            end

            Btn.Paint = function(obj, Sx, Sy)
                if Btn:IsHovered() then draw.RoundedBox(0, 0, 0, Sx, Sy, Color(0, 25, 55, 255)) end
                draw.DrawText(v.Translated_By_Name or "-", Font_Link, 0, 2, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT)
            end

            local SNLbl = vgui.Create("DLabel")
            SNLbl:SetText(v.Translated_Date or "-")
            SNLbl:SetWide(PW * 0.3)
            MPnl[4]:AddItem(SNLbl)
        end
    end

    local Btn = vgui.Create("DButton")
    Btn:SetSize(Pnl:GetWide() - 10, 50)
    Btn:SetPos(5, Pnl:GetTall() - Btn:GetTall() - 5)
    Btn:SetText("")
    Btn:SetParent(Pnl)
    Btn.DoClick = function()
        RunConsoleCommand("vc_menu_open_translation")
        VC.Menu_Panel:Close()
    end

    Btn.Paint = function(obj, Sx, Sy)
        draw.RoundedBox(0, 0, 0, Sx, Sy, Color(0, 155, 100, Btn:IsHovered() and 55 or 20))
        draw.DrawText(VC.Lng("WishToHelpTranslate"), "VC_Info_Smaller", Sx / 2, 18, Color(200, 225, 255, 255), TEXT_ALIGN_CENTER)
    end

    local X, Y = List:GetPos()
    local Sx, Sy = List:GetSize()
    Pnl.Paint = function(obj, Sx, Sy)
        draw.RoundedBox(0, X - 5, Y, Sx, 21, Color(0, 0, 0, 150))
        draw.RoundedBox(0, X - 5, Y, Sx, Sy, Color(0, 0, 0, 150))
        draw.RoundedBox(0, X - 5, Sx - 57, Sy, 57, Color(0, 0, 0, 150))
        draw.DrawText(VC.Lng("BigThankYouToAllWhoHelpedTranslate"), "VC_Dev_Text", List:GetWide() / 2, 5, VC.Color.Blue, TEXT_ALIGN_CENTER)
    end
    return Draw
end

VC.Menu_Items_P.Language = {"Language", BuildMenu}
timer.Simple(1, function()
    local function BuildMenu(Pnl)
        local List = VC.Add_El_List(0, 35, Pnl:GetWide(), Pnl:GetTall() - 35)
        List:SetParent(Pnl)
        local CBox = VC.Add_El_Checkbox("Enabled_Cl", "Basically shuts down all the stuff bellow.", "Enabled", VC.Settings)
        List:AddItem(CBox)
        local MPnl_M = VC.Add_El_Panel(List, {1}, 222)
        local SNLbl = vgui.Create("DLabel")
        SNLbl:SetText(VC.Lng("Lights") .. ":")
        MPnl_M[1]:AddItem(SNLbl)
        local LType = vgui.Create("DComboBox", List)
        LType:AddChoice(VC.Lng("Blurred"))
        LType:AddChoice(VC.Lng("Rays"))
        LType:SetSize(100, 24)
        LType:SetPos(List:GetWide() - LType:GetWide(), 10)
        LType:ChooseOptionID(VC.getSetting("Light_Type"))
        LType.OnSelect = function(idx, val) VC.SaveSetting("Light_Type", val) end
        local MPnl_M2 = VC.Add_El_Panel(MPnl_M[1], {1}, 202)
        local Sldr = VC.Add_El_Slider("VisDist", 0, 15000, 0, "How far the lights can be seen, reduces the lag a bit.", "LightDistance", VC.Settings)
        MPnl_M2[1]:AddItem(Sldr)
        local MPnl = VC.Add_El_Panel(MPnl_M2[1], {0.25, 0.75}, 32, true)
        local SNLbl = vgui.Create("DLabel")
        SNLbl:SetText("")
        SNLbl:SetTall(8)
        MPnl[1]:AddItem(SNLbl)
        local CBox = VC.Add_El_Checkbox("Main", "Main texture to outline the light.", "Light_Main", VC.Settings)
        MPnl[1]:AddItem(CBox)
        local Sldr = VC.Add_El_Slider("Multiplier", 0, 5, 2, "Will be multiplied by this amount.", "Light_Main_M", VC.Settings)
        MPnl[2]:AddItem(Sldr)
        local MPnl = VC.Add_El_Panel(MPnl_M2[1], {0.25, 0.75}, 32, true)
        local SNLbl = vgui.Create("DLabel")
        SNLbl:SetText("")
        SNLbl:SetTall(8)
        MPnl[1]:AddItem(SNLbl)
        local CBox = VC.Add_El_Checkbox("Warmth", "Creates a new light in the middle, blends the two together.", "Light_Warm", VC.Settings)
        MPnl[1]:AddItem(CBox)
        local Sldr = VC.Add_El_Slider("Multiplier", 0, 5, 2, "Will be multiplied by this amount.", "Light_Warm_M", VC.Settings)
        MPnl[2]:AddItem(Sldr)
        local MPnl = VC.Add_El_Panel(MPnl_M2[1], {0.25, 0.75}, 32, true)
        local SNLbl = vgui.Create("DLabel")
        SNLbl:SetText("")
        SNLbl:SetTall(8)
        MPnl[1]:AddItem(SNLbl)
        local CBox = VC.Add_El_Checkbox("Lines", "The lines you see around lights if its bright enough.", "Light_HD", VC.Settings)
        MPnl[1]:AddItem(CBox)
        local Sldr = VC.Add_El_Slider("Multiplier", 0, 5, 2, "Will be multiplied by this amount.", "Light_HD_M", VC.Settings)
        MPnl[2]:AddItem(Sldr)
        local MPnl = VC.Add_El_Panel(MPnl_M2[1], {0.25, 0.75}, 32, true)
        local SNLbl = vgui.Create("DLabel")
        SNLbl:SetText("")
        SNLbl:SetTall(8)
        MPnl[1]:AddItem(SNLbl)
        local CBox = VC.Add_El_Checkbox("Glow", "The very transparent glow around the lights.", "Light_Glow", VC.Settings)
        MPnl[1]:AddItem(CBox)
        local Sldr = VC.Add_El_Slider("Multiplier", 0, 5, 2, "Will be multiplied by this amount.", "Light_Glow_M", VC.Settings)
        MPnl[2]:AddItem(Sldr)
        local CBox = VC.Add_El_Checkbox("3D", "This light object renders in 3D instead of dot based style.", "Light_3D", VC.Settings)
        MPnl_M2[1]:AddItem(CBox)
        local MPnl = VC.Add_El_Panel(MPnl_M2[1], {0.25, 0.75}, 32, true)
        local SNLbl = vgui.Create("DLabel")
        SNLbl:SetText("")
        SNLbl:SetTall(8)
        MPnl[1]:AddItem(SNLbl)
        local CBox = VC.Add_El_Checkbox("DynamicLights", "If lights are lagging for you, uncheck this.", "DynamicLights", VC.Settings)
        MPnl[1]:AddItem(CBox)
        local Sldr = VC.Add_El_Slider("FadeOutDistance", 1000, 10000, 0, "Dynamic lights will turn off at this distance (gradually). Fades from 1 to 0 in 1000 units.", "DynamicLights_OffDist", VC.Settings)
        MPnl[2]:AddItem(Sldr)
        local Sheet = vgui.Create("DPropertySheet")
        Sheet:SetTall(210)
        if VC.CreateClSettingsTab_Effects then
            local TList = VC.Add_El_List(0, 6, 450, Sheet:GetTall())
            Sheet:AddSheet(VC.Lng("Effects"), TList, "icon16/chart_line.png", false, false, "Controls for the VCMod Package.")
            VC.CreateClSettingsTab_Effects(List, TList)
        end

        if VC.CreateClSettingsTab_TireTracks then
            local TList = VC.Add_El_List(0, 6, 450, Sheet:GetTall())
            Sheet:AddSheet(VC.Lng("TireTracks"), TList, "icon16/vector.png", false, false, "Controls for the VCMod Package.")
            VC.CreateClSettingsTab_TireTracks(List, TList)
        end

        if VC.CreateClSettingsTab_VC1 then
            local TList = VC.Add_El_List(0, 6, 450, Sheet:GetTall())
            Sheet:AddSheet(VC.Lng("ThirdPersonView"), TList, "icon16/user_red.png", false, false, "Controls for the VCMod Main Package.")
            VC.CreateClSettingsTab_VC1(List, TList)
        end

        if VC.CreateClSettingsTab_VC1_ELS then
            local TList = VC.Add_El_List(0, 6, 450, Sheet:GetTall())
            Sheet:AddSheet(VC.Lng("ELS"), TList, "icon16/user_orange.png", false, false, "Controls for the VCMod ELS package.")
            VC.CreateClSettingsTab_VC1_ELS(List, TList)
        end

        if VC.CreateClSettingsTab_Other then
            local TList = VC.Add_El_List(0, 6, 450, Sheet:GetTall())
            Sheet:AddSheet(VC.Lng("Other"), TList, "icon16/box.png", false, false, "Controls for the VCMod Main Package.")
            VC.CreateClSettingsTab_Other(List, TList)
        end

        List:AddItem(Sheet)
        local Btn = vgui.Create("VC_Button")
        Btn:SetColor(VC.Color.Btn_Orn)
        Btn:SetSize(75, 20)
        Btn:SetPos(Pnl:GetWide() / 2 - 35, Pnl:GetTall() - 24)
        Btn:SetText(VC.Lng("Reset"))
        Btn:SetParent(Pnl)
        Btn:SetToolTip("Reset all settings to their default values.")
        Btn.DoClick = function()
            VC.ResetSettings()
            if VC.Menu_Panel then VC.Menu_Panel.VC_Refresh_Panel = true end
            VCPopup("SettingsReset", "check")
        end

        local X, Y = List:GetPos()
        local Sx, Sy = List:GetSize()
        Pnl.Paint = function(obj, Sx, Sy)
            draw.RoundedBox(0, X, Y, Sx, Sy, Color(0, 0, 0, 100))
            draw.DrawText(VC.Lng("OptOnly_You"), "VC_Dev_Text", List:GetWide() / 2, 5, VC.Color.Blue, TEXT_ALIGN_CENTER)
        end
        return Draw
    end

    VC.Menu_Items_P.Personal = {
        "Options",
        BuildMenu,
        Check = function() return VCMod1 or VCMod1_ELS end
    }
end)

local function BuildMenu(Pnl)
    local List = VC.Add_El_List(0, 6, 450, 550)
    List:SetParent(Pnl)
    local List2 = VC.Add_El_List(459, 6, 146, 458)
    List2:SetParent(Pnl)
    local MPnl = VC.Add_El_Panel(List, {0.5, 0.5}, 32, 2)
    local SNLbl = vgui.Create("DLabel")
    SNLbl:SetText("")
    SNLbl:SetTall(2)
    MPnl[1]:AddItem(SNLbl)
    local Cmd = nil
    for k, v in pairs(VC.Controls_Main) do
        if v.cmd == "vc_holdkey" then Cmd = v end
    end

    local VCBtn = vgui.Create("VC_Control")
    VCBtn.VC_BtnInfo = {Cmd.info, Cmd.keyhold}
    VCBtn.VC_BtnCmd = Cmd.cmd
    if Cmd.desk then VCBtn:SetToolTip(Cmd.desk) end
    MPnl[1]:AddItem(VCBtn)
    local Sldr = VC.Add_El_Slider("HoldDuration", 0.1, 1, 1, "Buttons with checkbox checked will only work after this hold delay.", "Keyboard_Input_Hold", VC.Settings)
    Sldr:SetSize(450, 30)
    MPnl[2]:AddItem(Sldr)
    local Sheet = vgui.Create("DPropertySheet")
    Sheet:SetTall(455)
    if VCMod1 then
        local TList = VC.Add_El_List(0, 6, 450, 505)
        Sheet:AddSheet(VC.Lng("Main"), TList, "icon16/user_red.png", false, false, "Controls for the VCMod Main Package.")
        for _, Cmd in pairs(VC.Controls_Main) do
            if Cmd.menu == "controls" then
                local VCBtn = vgui.Create(Cmd.NoCheckBox and "VC_Control" or "VC_Control_CheckBox")
                VCBtn.VC_BtnInfo = {Cmd.info, Cmd.keyhold}
                VCBtn.VC_BtnCmd = Cmd.cmd
                if Cmd.desk then VCBtn:SetToolTip(Cmd.desk) end
                TList:AddItem(VCBtn)
            end
        end
    end

    if VCMod1_ELS then
        local TList = VC.Add_El_List(0, 6, 450, 505)
        Sheet:AddSheet(VC.Lng("ELS"), TList, "icon16/user_orange.png", false, false, "Controls for the VCMod ELS package.")
        for _, Cmd in pairs(VC.Controls_Main) do
            if Cmd.menu == "controls_els" then
                local VCBtn = vgui.Create(Cmd.NoCheckBox and "VC_Control" or "VC_Control_CheckBox")
                VCBtn.VC_BtnInfo = {Cmd.info, Cmd.keyhold}
                VCBtn.VC_keyhold = Cmd.keyhold
                VCBtn.VC_BtnCmd = Cmd.cmd
                if Cmd.desk then VCBtn:SetToolTip(Cmd.desk) end
                TList:AddItem(VCBtn)
            end
        end
    end

    List:AddItem(Sheet)
    local CBox = VC.Add_El_Checkbox("KeyboardInput", "Toggles all controls, excluding the mouse buttons.", "Keyboard_Input", VC.Settings)
    List2:AddItem(CBox)
    local CBox = VC.Add_El_Checkbox("MouseInput", "Toggles mouse button controls.", "MouseControl", VC.Settings)
    List2:AddItem(CBox)
    if vcmod1 then
        local SNLbl = vgui.Create("DLabel")
        SNLbl:SetText(VC.Lng("SwitchSeats"))
        List2:AddItem(SNLbl)
        local SNLbl = vgui.Create("DLabel")
        SNLbl:SetText("'1-9', '0'.")
        List2:AddItem(SNLbl)
        local SNLbl = vgui.Create("DLabel")
        SNLbl:SetText("")
        List2:AddItem(SNLbl)
        local SNLbl = vgui.Create("DLabel")
        SNLbl:SetText(VC.Lng("KickPeopleOut"))
        List2:AddItem(SNLbl)
        local SNLbl = vgui.Create("DLabel")
        SNLbl:SetText(VC.Lng("Holdkey") .. "+ ('1-9', '0').")
        List2:AddItem(SNLbl)
    end

    local Btn = vgui.Create("VC_Button")
    Btn:SetColor(VC.Color.Btn_Orn)
    Btn:SetSize(75, 20)
    Btn:SetPos(187.5, Pnl:GetTall() - 20)
    Btn:SetText(VC.Lng("Reset"))
    Btn:SetParent(Pnl)
    Btn:SetToolTip("Reset all controls to their default values, changes settings of all addons, not just this one.")
    Btn.DoClick = function()
        VC.Controls_CreateScript()
        if VC.Menu_Panel then VC.Menu_Panel.VC_Refresh_Panel = true end
        VCPopup("ControlsReset", "check")
    end

    Pnl.Paint = function(obj, Sx, Sy) draw.RoundedBox(0, 453, 0, 152, Sy, Color(0, 0, 0, 100)) end
end

VC.Menu_Items_P.Controls = {
    "Controls",
    BuildMenu,
    Check = function() return VCMod1 or VCMod1_ELS end
}

local function BuildMenu(Pnl)
    local List = VC.Add_El_List(0, 35, Pnl:GetWide(), Pnl:GetTall() - 60)
    List:SetParent(Pnl)
    local ElTbl = {}
    local Settings_Sv = {}
    if vcmod1 then
        local CBox = VC.Add_El_Checkbox("DarkRP Fire System (GModStore)", "When something explodes it spawns fire entities from this addon.", "Compat_CH_Fire_System", Settings_Sv, true)
        List:AddItem(CBox)
        ElTbl.Compat_CH_Fire_System = CBox
    end

    local Btn = vgui.Create("VC_Button")
    Btn:SetColor(VC.Color.Btn_Add)
    Btn:SetSize(75, 20)
    Btn:SetPos(Pnl:GetWide() / 2 - 112.25, Pnl:GetTall() - 20)
    Btn:SetText(VC.Lng("Save"))
    Btn:SetParent(Pnl)
    Btn:SetToolTip("Save the settings.")
    Btn.DoClick = function()
        if VC.CanEditAdminSettings(LocalPlayer()) then
            net.Start("VC_SendSettingsToServer")
            net.WriteTable(Settings_Sv)
            net.SendToServer()
            VCPopup("SettingsSaved", "check")
        end
    end

    local Btn = vgui.Create("VC_Button")
    Btn:SetColor(VC.Color.Btn_Orn)
    Btn:SetSize(75, 20)
    Btn:SetPos(Pnl:GetWide() / 2 - 37.25, Pnl:GetTall() - 20)
    Btn:SetText(VC.Lng("Reset"))
    Btn:SetParent(Pnl)
    Btn:SetToolTip("Reset all settings to their default values.")
    Btn.DoClick = function()
        if VC.CanEditAdminSettings(LocalPlayer()) then
            RunConsoleCommand("VC_ResetSettings")
            if VC.Menu_Panel then VC.Menu_Panel.VC_Refresh_Panel = true end
            VCPopup("SettingsReset", "check")
        end
    end

    local Btn = vgui.Create("VC_Button")
    Btn:SetColor(VC.Color.Btn_Spw)
    Btn:SetPos(Pnl:GetWide() / 2 + 37.25, Pnl:GetTall() - 20)
    Btn:SetSize(75, 20)
    Btn:SetText(VC.Lng("Load"))
    Btn:SetParent(Pnl)
    Btn:SetToolTip("Load settings from the server.")
    Btn.DoClick = function()
        if VC.CanEditAdminSettings(LocalPlayer()) then
            RunConsoleCommand("VC_GetSettings_Sv")
            VCPopup("LoadedSettingsFromServer", "check")
        end
    end

    if VC.CanEditAdminSettings(LocalPlayer()) then RunConsoleCommand("VC_GetSettings_Sv") end
    local X, Y = List:GetPos()
    local Sx, Sy = List:GetSize()
    Pnl.Paint = function(obj, Sx, Sy)
        draw.RoundedBox(0, X, Y, Sx, Sy, Color(0, 0, 0, 100))
        draw.DrawText(VC.Lng("OptOnly_Admin"), "VC_Dev_Text", List:GetWide() / 2, 5, VC.Color.Blue, TEXT_ALIGN_CENTER)
    end

    Pnl.Think = function()
        if VC.Settings_TempTbl then
            for k, v in pairs(VC.Settings_TempTbl) do
                if ElTbl[k] then ElTbl[k]:SetValue(v) end
                Settings_Sv[k] = v
            end

            VC.Settings_TempTbl = nil
        end
    end
    return Draw
end

VC.Menu_Items_A.Compatibility = {"Compatibility", BuildMenu}
local datacolours = {}
datacolours["General"] = VC.Color.White
datacolours["Car dealer"] = Color(255, 155, 100, 255)
datacolours["Repair man"] = Color(155, 155, 255, 255)
datacolours["Fuel"] = Color(155, 255, 185, 255)
local function BuildMenu(Pnl)
    local List = VC.Add_El_List(0, 0, 165, Pnl:GetTall())
    List:SetParent(Pnl)
    local List2 = VC.Add_El_List(List:GetWide() + 5 + 15, 0, Pnl:GetWide() - List:GetWide() - 5, Pnl:GetTall())
    List2:SetParent(Pnl)
    List.PaintOver = function(obj, Sx, Sy)
        draw.RoundedBox(0, 0, 0, Sx, Sy, Color(0, 0, 0, 100))
        if not Pnl.VC_List then draw.DrawText(VC.Lng("Loading"), "VC_Dev_Text", Sx / 2, Sy / 2, VC.Color.Blue, TEXT_ALIGN_CENTER) end
    end

    List2.PaintOver = function(obj, Sx, Sy) if Pnl.VC_Data and Pnl.VC_Data == "" then draw.DrawText(VC.Lng("Loading"), "VC_Dev_Text", Sx / 2, Sy / 2, VC.Color.Blue, TEXT_ALIGN_CENTER) end end
    if not VC.Logging_Data and VC.CanEditAdminSettings(LocalPlayer()) then RunConsoleCommand("VC_GetLogging_Data") end
    local function RefreshData(data)
        List2:Clear()
        for k, v in SortedPairs(data, true) do
            local SNLbl = vgui.Create("DLabel")
            SNLbl:SetText("")
            SNLbl:SetTall(8)
            List2:AddItem(SNLbl)
            local SNLbl = vgui.Create("DLabel")
            SNLbl:SetTextColor(Color(255, 255, 255, 255))
            SNLbl:NoClipping(true)
            SNLbl:SetText(v.text)
            SNLbl:SetFont("VC_Regular_S")
            SNLbl:SetAutoStretchVertical(true)
            SNLbl:SetWrap(true)
            SNLbl.PaintOver = function(obj, Sx, Sy) draw.RoundedBox(8, -15, 0, 10, 10, v.color) end
            List2:AddItem(SNLbl)
            SNLbl:SetPos(50, 0)
        end
    end

    local function import(name)
        Pnl.VC_Data = ""
        RunConsoleCommand("VC_GetLogging_Data_Spec", name)
    end

    local function RefreshList(tbl)
        List:Clear()
        Pnl.VC_List = tbl
        for k, v in SortedPairs(tbl, true) do
            local Btn = vgui.Create("DButton")
            Btn:SetText("")
            Btn:SetToolTip('A text file of this log is available at: "garrysmod/data/vcmod/logs' .. v .. '.txt".')
            List:AddItem(Btn)
            Btn:AlphaTo(0, 0, 0)
            Btn:AlphaTo(255, 0.2, 0)
            Btn.DoClick = function()
                Pnl.VC_Sel = v
                import(v)
            end

            Btn.Paint = function(obj, Sx, Sy)
                draw.DrawText(v, "VC_Regular_S", 5, 8, VC.Color.White, TEXT_ALIGN_LEFT)
                local Sel = Pnl.VC_Sel and Pnl.VC_Sel == v
                if Sel or obj:IsHovered() then
                    local Clr = Sel and VC.Color.Good or VC.Color.Blue
                    surface.SetDrawColor(Clr.r, Clr.g, Clr.b, Clr.a)
                    local Py = Sy - 1
                    surface.DrawLine(0, Py, Sx, Py)
                end
            end
        end
    end

    Pnl.Think = function()
        if VC.Logging_Data then
            RefreshList(VC.Logging_Data)
            VC.Logging_Data = nil
        end

        if VC.Logging_Data_Spec then
            local cdata = {}
            local data = string.Explode("\n", VC.Logging_Data_Spec)
            for k, v in pairs(data) do
                if string.len(v) > 5 then
                    local tbl = {}
                    local tdata = string.Explode("<", v)
                    if tdata[2] then tdata = string.Explode(">", tdata[2]) end
                    tbl.color = tdata[1] and datacolours[tdata[1]] or Color(0, 0, 0, 0)
                    tbl.text = v
                    cdata[k] = tbl
                end
            end

            RefreshData(cdata)
            Pnl.VC_Data = cdata
            VC.Logging_Data_Spec = nil
        end
    end
    return Draw
end

VC.Menu_Items_A.Logging = {"Logs", BuildMenu}
net.Receive("VC_SendToClient_Logging", function(len)
    local str = net.ReadString()
    VC.Logging_Data = util.JSONToTable(str)
end)

net.Receive("VC_SendToClient_Logging_Spec", function(len)
    local str = net.ReadString()
    VC.Logging_Data_Spec = str
end)

local function BuildMenu(Pnl)
    local List = VC.Add_El_List(0, 6, Pnl:GetWide(), Pnl:GetTall())
    List:SetParent(Pnl)
    local Sheet_Base = vgui.Create("DPropertySheet")
    Sheet_Base:SetSize(Pnl:GetWide(), Pnl:GetTall())
    local Controls = VC.Add_El_List(0, 6, Sheet_Base:GetSize())
    Sheet_Base:AddSheet(VC.Lng("Controls"), Controls, "icon16/tab.png", false, false, "Allows you to override controls for all players, instead of their chosen ones.")
    local Other = VC.Add_El_List(0, 6, Sheet_Base:GetSize())
    Sheet_Base:AddSheet(VC.Lng("Other"), Other, "icon16/anchor.png", false, false, "Allows you to override specific clientside controls.")
    local ElTbl = {}
    local Settings_Sv = {}
    local CBox = VC.Add_El_Checkbox("Override_Controls", "When this is enabled the default player controls (which they can customize) will be forced to use this instead.", "Override_Controls", Settings_Sv, true)
    ElTbl.Override_Controls = CBox
    Controls:AddItem(CBox)
    if VCMod1 or VCMod1_ELS then
        for _, Cmd in pairs(VC.Controls_Main) do
            if Cmd.menu == "controls_holdkey" then
                local MPnl = VC.Add_El_Panel(Controls, {0.2, 0.8}, 24, true)
                local SNLbl = vgui.Create("DLabel")
                SNLbl:SetText("")
                SNLbl:SetTall(8)
                MPnl[1]:AddItem(SNLbl)
                local CBox = VC.Add_El_Checkbox("Use", "If option should be overwritten or not.")
                MPnl[1]:AddItem(CBox)
                CBox.OnChange = function(idx, val)
                    if CBox.VC_Ignore then
                        CBox.VC_Ignore = nil
                        return
                    end

                    RunConsoleCommand("VC_SetControl_Override_Use", Cmd.cmd, val and "1" or "0")
                end

                if VC.Override_Controls and VC.Override_Controls[Cmd.cmd] and VC.Override_Controls[Cmd.cmd].use and tostring(VC.Override_Controls[Cmd.cmd].use) == "1" then
                    CBox.VC_Ignore = true
                    CBox:SetValue(true)
                end

                local VCBtn = vgui.Create(Cmd.NoCheckBox and "VC_Control" or "VC_Control_CheckBox")
                VCBtn.VC_Override = true
                VCBtn.VC_BtnInfo = {Cmd.info, Cmd.keyhold}
                VCBtn.VC_BtnCmd = Cmd.cmd
                if Cmd.desk then VCBtn:SetToolTip(Cmd.desk) end
                MPnl[2]:AddItem(VCBtn)
            end
        end
    end

    if VCMod1 then
        local CBox = VC.Add_El_Checkbox("ForceFirstPersonView", "Disables switching to third person view.", "TP_Override", Settings_Sv, true)
        ElTbl.TP_Override = CBox
        Other:AddItem(CBox)
    end

    local Sheet = vgui.Create("DPropertySheet")
    Sheet:SetTall(Controls:GetTall() - 25 - 25 - 50)
    local objects = {}
    if VCMod1 then
        local TList = VC.Add_El_List(0, 6, 450, 505)
        Sheet:AddSheet(VC.Lng("Main"), TList, "icon16/user_red.png", false, false, "Controls for the VCMod Main Package.")
        for _, Cmd in pairs(VC.Controls_Main) do
            if Cmd.menu == "controls" then
                local MPnl = VC.Add_El_Panel(TList, {0.2, 0.8}, 24, true)
                local SNLbl = vgui.Create("DLabel")
                SNLbl:SetText("")
                SNLbl:SetTall(8)
                MPnl[1]:AddItem(SNLbl)
                local CBox = VC.Add_El_Checkbox("Use", "If option should be overwritten or not.")
                MPnl[1]:AddItem(CBox)
                CBox.OnChange = function(idx, val)
                    if CBox.VC_Ignore then
                        CBox.VC_Ignore = nil
                        return
                    end

                    RunConsoleCommand("VC_SetControl_Override_Use", Cmd.cmd, val and "1" or "0")
                end

                if VC.Override_Controls and VC.Override_Controls[Cmd.cmd] and VC.Override_Controls[Cmd.cmd].use and tostring(VC.Override_Controls[Cmd.cmd].use) == "1" then
                    CBox.VC_Ignore = true
                    CBox:SetValue(true)
                end

                local VCBtn = vgui.Create(Cmd.NoCheckBox and "VC_Control" or "VC_Control_CheckBox")
                VCBtn.VC_Override = true
                VCBtn.VC_BtnInfo = {Cmd.info, Cmd.keyhold}
                VCBtn.VC_BtnCmd = Cmd.cmd
                if Cmd.desk then VCBtn:SetToolTip(Cmd.desk) end
                MPnl[2]:AddItem(VCBtn)
            end
        end
    end

    if VCMod1_ELS then
        local TList = VC.Add_El_List(0, 6, 450, 505)
        Sheet:AddSheet(VC.Lng("ELS"), TList, "icon16/user_orange.png", false, false, "Controls for the VCMod ELS Package.")
        for _, Cmd in pairs(VC.Controls_Main) do
            if Cmd.menu == "controls_els" then
                local MPnl = VC.Add_El_Panel(TList, {0.2, 0.8}, 24, true)
                local SNLbl = vgui.Create("DLabel")
                SNLbl:SetText("")
                SNLbl:SetTall(8)
                MPnl[1]:AddItem(SNLbl)
                local CBox = VC.Add_El_Checkbox("Use", "If option should be overwritten or not.")
                MPnl[1]:AddItem(CBox)
                CBox.OnChange = function(idx, val)
                    if CBox.VC_Ignore then
                        CBox.VC_Ignore = nil
                        return
                    end

                    RunConsoleCommand("VC_SetControl_Override_Use", Cmd.cmd, val and "1" or "0")
                end

                if VC.Override_Controls and VC.Override_Controls[Cmd.cmd] and VC.Override_Controls[Cmd.cmd].use and tostring(VC.Override_Controls[Cmd.cmd].use) == "1" then
                    CBox.VC_Ignore = true
                    CBox:SetValue(true)
                end

                local VCBtn = vgui.Create(Cmd.NoCheckBox and "VC_Control" or "VC_Control_CheckBox")
                VCBtn.VC_Override = true
                VCBtn.VC_BtnInfo = {Cmd.info, Cmd.keyhold}
                VCBtn.VC_BtnCmd = Cmd.cmd
                if Cmd.desk then VCBtn:SetToolTip(Cmd.desk) end
                MPnl[2]:AddItem(VCBtn)
            end
        end
    end

    Controls:AddItem(Sheet)
    List:AddItem(Sheet_Base)
    local Btn = vgui.Create("VC_Button")
    Btn:SetColor(VC.Color.Btn_Add)
    Btn:SetSize(120, 20)
    Btn:SetPos(Pnl:GetWide() / 2 - 120, Pnl:GetTall() - 20)
    Btn:SetText(VC.Lng("Save"))
    Btn:SetParent(Pnl)
    Btn:SetToolTip("Save the settings.")
    Btn.DoClick = function()
        if VC.CanEditAdminSettings(LocalPlayer()) then
            net.Start("VC_SendSettingsToServer")
            net.WriteTable(Settings_Sv)
            net.SendToServer()
            net.Start("VC_SendSettingsToServer_Override_Controls")
            net.WriteTable(VC.Override_Controls)
            net.SendToServer()
            VCPopup("SettingsSaved", "check")
        end
    end

    local Btn = vgui.Create("VC_Button")
    Btn:SetColor(VC.Color.Btn_Spw)
    Btn:SetPos(Pnl:GetWide() / 2, Pnl:GetTall() - 20)
    Btn:SetSize(120, 20)
    Btn:SetText(VC.Lng("Load"))
    Btn:SetParent(Pnl)
    Btn:SetToolTip("Load settings from the server.")
    Btn.DoClick = function()
        if VC.CanEditAdminSettings(LocalPlayer()) then
            RunConsoleCommand("VC_GetSettings_Sv")
            RunConsoleCommand("VC_GetSettings_Sv_Override_Controls")
            VCPopup("LoadedSettingsFromServer", "check")
        end
    end

    if VC.CanEditAdminSettings(LocalPlayer()) then RunConsoleCommand("VC_GetSettings_Sv") end
    Pnl.Think = function()
        if VC.Settings_TempTbl then
            for k, v in pairs(VC.Settings_TempTbl) do
                if ElTbl[k] then ElTbl[k]:SetValue(v) end
                Settings_Sv[k] = v
            end

            VC.Settings_TempTbl = nil
        end
    end
end

VC.Menu_Items_A.Controls = {
    "Overrides",
    BuildMenu,
    Check = function() return VCMod1 or VCMod1_ELS end
}

local function BuildMenu(Pnl)
    local List = VC.Add_El_List(0, 35, Pnl:GetWide(), Pnl:GetTall() - 35)
    List:SetParent(Pnl)
    local CBox = VC.Add_El_Checkbox("Imperialinsteadofmetric", "Use imperial system instead of the metric one", "HUD_MPh", VC.Settings)
    List:AddItem(CBox)
    local MPnl = VC.Add_El_Panel(List, {0.5, 0.5}, 32, true)
    local SNLbl = vgui.Create("DLabel")
    SNLbl:SetText("")
    SNLbl:SetTall(8)
    MPnl[1]:AddItem(SNLbl)
    local CBox = VC.Add_El_Checkbox("Effect3D", "When you sway your mouse around the HUD tries to stay with the view.", "HUD_3D", VC.Settings)
    MPnl[1]:AddItem(CBox)
    local Sldr = VC.Add_El_Slider("Multiplier", 0, 3, 2, "How much the view will sway.", "HUD_3D_Mult", VC.Settings)
    MPnl[2]:AddItem(Sldr)
    local Sldr = VC.Add_El_Slider("HUDHeight", 0, 100, 0, "How high on your screen the HUD will be on the right.", "HUD_Height", VC.Settings)
    List:AddItem(Sldr)
    if vcmod1 then
        local Sldr = VC.Add_El_Slider("PickupDistance", 0, 5000, 0, "Distance of which the pickup entity text is drawn.", "PickupDistance", VC.Settings)
        List:AddItem(Sldr)
        local MPnl = VC.Add_El_Panel(List, {0.5, 0.5}, 24, true)
        local CBox = VC.Add_El_Checkbox("TheName", "When entering a car the name of the car will appear on the bottom left of the screen.", "HUD_Name", VC.Settings)
        MPnl[1]:AddItem(CBox)
        local Sldr = VC.Add_El_Slider("Height", 0, 1, 2, "How hight the vehicles name will be.", "HUD_Name_Height", VC.Settings)
        MPnl[2]:AddItem(Sldr)
        local MPnl = VC.Add_El_Panel(List, {0.5, 0.5}, 24, true)
        local CBox = VC.Add_El_Checkbox("Health", "Indicator of the vehicles health on the middle right of the screen.", "HUD_Health", VC.Settings)
        MPnl[1]:AddItem(CBox)
        local CBox = VC.Add_El_Checkbox("Icons", "Shows the fancy icon and real time damage.", "HUD_Health_Adv", VC.Settings)
        MPnl[2]:AddItem(CBox)
        local MPnl = VC.Add_El_Panel(List, {0.5, 0.5}, 24, true)
        local CBox = VC.Add_El_Checkbox("Fuel", "Indicator of the vehicles fuel on the middle right of the screen.", "HUD_Fuel", VC.Settings)
        MPnl[1]:AddItem(CBox)
        local CBox = VC.Add_El_Checkbox("FuelLidPosition", "Shows where you can pour fuel on the vehicle.", "HUD_FuelLidPosition", VC.Settings)
        MPnl[2]:AddItem(CBox)
        local CBox = VC.Add_El_Checkbox("DriveBy", "Enter/Exit indicator on the middle bottom of the screen.", "HUD_DriveBy", VC.Settings)
        List:AddItem(CBox)
        local CBox = VC.Add_El_Checkbox("Icons", "Icons of what is active on the vehicle.", "HUD_Icons", VC.Settings)
        List:AddItem(CBox)
        local CBox = VC.Add_El_Checkbox("Cruise", "Will show up when the cruise control is active, middle bottom of the screen.", "HUD_Cruise", VC.Settings)
        List:AddItem(CBox)
    end

    if vcmod1_els then
        local CBox = VC.Add_El_Checkbox("ELS_Siren", "ELS HUD element, which will show the siren's.", "HUD_ELS_Siren", VC.Settings)
        List:AddItem(CBox)
        local CBox = VC.Add_El_Checkbox("ELS_Lights", "ELS HUD element, which will show the light codes and sequences.", "HUD_ELS", VC.Settings)
        List:AddItem(CBox)
    end

    local Btn = vgui.Create("VC_Button")
    Btn:SetColor(VC.Color.Btn_Orn)
    Btn:SetSize(75, 20)
    Btn:SetPos(Pnl:GetWide() / 2 - 35, Pnl:GetTall() - 24)
    Btn:SetText(VC.Lng("Reset"))
    Btn:SetParent(Pnl)
    Btn:SetToolTip("Reset all settings to their default values.")
    Btn.DoClick = function()
        VC.ResetSettings()
        if VC.Menu_Panel then VC.Menu_Panel.VC_Refresh_Panel = true end
        VCPopup("SettingsReset", "check")
    end

    local X, Y = List:GetPos()
    Pnl.Paint = function(obj, Sx, Sy)
        draw.RoundedBox(0, X, Y, Sx, Sy, Color(0, 0, 0, 100))
        draw.DrawText(VC.Lng("OptOnly_You"), "VC_Dev_Text", Sx / 2, 5, VC.Color.Blue, TEXT_ALIGN_CENTER)
    end
    return Draw
end

VC.Menu_Items_P.HUD = {
    "HUD",
    BuildMenu,
    Check = function() return VCMod1 or VCMod1_ELS end
}

local function BuildMenu(Pnl)
    local List = VC.Add_El_List(0, 35, Pnl:GetWide(), Pnl:GetTall() - 35)
    List:SetParent(Pnl)
    local MPnl = VC.Add_El_Panel(List, {0.5, 0.5}, 32, true)
    local ComboBox = vgui.Create("DComboBox", List)
    ComboBox:SetSize(200, 24)
    ComboBox:AddChoice(VC.Lng("SuperAdmin"))
    ComboBox:AddChoice(VC.Lng("Administrator"))
    ComboBox:AddChoice(VC.Lng("NoneAdmin"))
    ComboBox:ChooseOptionID(VC.GetPrivileges())
    ComboBox.OnSelect = function(idx, val) VC.SetPrivileges(val) end
    local SNLbl = vgui.Create("DLabel")
    SNLbl:SetText(VC.Lng("AdminControlsCanBeAlteredBy"))
    MPnl[1]:AddItem(SNLbl)
    MPnl[2]:AddItem(ComboBox)
    local Btn = vgui.Create("VC_Button")
    Btn:SetColor(VC.Color.Btn_Spw)
    Btn:SetText(VC.Lng("Clear vehicle data cache, will cause to redownload"))
    Btn:SetToolTip("Clears any vehicle data information, redownloads if needed.")
    List:AddItem(Btn)
    Btn.DoClick = function() RunConsoleCommand("vc_update_data") end
    local Btn = vgui.Create("VC_Button")
    Btn:SetColor(VC.Color.Btn_Chn)
    Btn:SetText(VC.Lng("Check for General Vehicle Data updates"))
    Btn:SetToolTip("Will check if there are any GVC updates available, if found, downloads them in the background.")
    List:AddItem(Btn)
    Btn.DoClick = function() RunConsoleCommand("vc_update_gvd") end
    local SNLbl = vgui.Create("DLabel")
    SNLbl:SetText("Debug tools:")
    List:AddItem(SNLbl)
    local Btn = vgui.Create("VC_Button")
    Btn:SetColor(VC.Color.Btn_Chn)
    Btn:SetText("Send data to for analysis")
    Btn:SetToolTip("This will include a list of all of the installed addons, VCMod ussage information, any of VCMod logs.")
    List:AddItem(Btn)
    Btn.DoClick = function() RunConsoleCommand("vc_debug_senddata") end
    local X, Y = List:GetPos()
    Pnl.Paint = function(obj, Sx, Sy)
        draw.RoundedBox(0, X, Y, Sx, Sy, Color(0, 0, 0, 100))
        draw.DrawText(VC.Lng("OptOnly_SuperAdmin"), "VC_Dev_Text", List:GetWide() / 2, 5, VC.Color.Blue, TEXT_ALIGN_CENTER)
    end
    return Draw
end

VC.Menu_Items_A.Menu = {
    "CoreOptions",
    BuildMenu,
    Check = function() return VCMod1 or VCMod1_ELS end
}

if not VC_AU_Ver or VC_AU_Ver < 9 then
    local function printMsg()
        if LocalPlayer():IsAdmin() then VCMsg("(Only visible to administrators) This copy of VCMod is no longer supported and no longer receives automated updates.\nPlease download and install the newer version.") end
    end

    timer.Simple(15, function()
        printMsg()
        timer.Create("vc_au_ver_msg", 60 * 60 * 3, 0, function() printMsg() end)
    end)
elseif VC_AU_Ver and VC_AU_Ver_Online and VC_AU_Ver < VC_AU_Ver_Online and not vcmod_dev then
    local function printMsg()
        if not VCMod_Dev and LocalPlayer():IsAdmin() then VCMsg("(Only visible to administrators) VCMod needs to be redownloaded! It will still receive automated updates, however, some files might be missing or outdated.\nUpdate is heavily recommended, but is not mandatory.") end
    end

    timer.Simple(15, function()
        printMsg()
        timer.Create("vc_au_ver_msg", 60 * 60 * 3, 0, function() printMsg() end)
    end)
end

concommand.Add("vc_holdkey", function(ply, cmd, arg)
    if arg[1] then
        if VC.KeyPrimaryHold and arg[1] == "2" then
            VC.KeyPrimaryHold = false
        elseif not VC.KeyPrimaryHold and arg[1] == "1" then
            VC.KeyPrimaryHold = true
        end
    end
end)

local settings = {
    Enabled = true,
    HUD = true,
    HUD_3D = true,
    HUD_3D_Mult = 1,
    HUD_Height = 35,
    PickupDistance = 1000,
    Light_Main = true,
    Light_Main_M = 1,
    Light_HD = true,
    Light_HD_M = 1,
    Light_Glow = true,
    Light_Glow_M = 1,
    Light_Warm = true,
    Light_Warm_M = 1,
    Light_3D = true,
    Light_Type = 1,
    LightDistance = 8000,
    DynamicLights = true,
    DynamicLights_OffDist = 1500,
    MouseControl = true,
    Keyboard_Input = true,
    Keyboard_Input_Hold = 0.2,
}

VC.SettingsAdd(settings)
if not VC.Global_Model_Names then VC.Global_Model_Names = {} end
function VC.GetModel(ent)
    local ret = ""
    if IsValid(ent) then
        if ent.VC_ExtraSeat then ent = ent:GetParent() end
        if IsValid(ent) then
            ret = ent and ent.VC_Model
            if not ret then
                local mdl = ent:GetModel()
                ent.VC_Model = VC.Global_Model_Names[mdl]
                ret = ent.VC_Model
                if not ret then ret = mdl end
            end
        end
    end
    return ret
end

function VC.FTm()
    local FTm = (VC.FrameTime or RealFrameTime()) * 100
    return FTm
end

function VC.GetViewPos()
    return GetViewEntity():GetPos()
end

function VC.PreparePrice(val, free)
    if free and (not val or val == 0 or val == "") then
        val = VC.Lng("Free")
    else
        local k = nil
        val = math.Round(val, 2)
        while k ~= 0 do
            val, k = string.gsub(val, "^(-?%d+)(%d%d%d)", '%1,%2')
        end
    end
    return val
end

local function reset_UI_Inter_Time(mdl)
    if VC.UI_Inter_Cache then
        if not VC.UI_Inter_Cache[mdl] then VC.UI_Inter_Cache[mdl] = {} end
        VC.UI_Inter_Cache[mdl].refreshTime = CurTime() + 2
    end
end

local function dataDownloaded(mdl, dataType)
    reset_UI_Inter_Time(mdl)
end

net.Receive("VC_SendToClient_General", function(len)
    local mdl = net.ReadString()
    local tbl = net.ReadTable()
    if not mdl then mdl = "" end
    if not ultrafreemmansuckGen then ultrafreemmansuckGen = {} end
    ultrafreemmansuckGen[mdl] = tbl
    dataDownloaded(mdl, "general")
end)

net.Receive("VC_SendToClient_Model", function(len)
    local ent, mdl = net.ReadEntity(), net.ReadString()
    if IsValid(ent) then
        ent.VC_Model = mdl
        if VC.Global_Model_Names then
            local tmdl = ent:GetModel()
            if not tmdl then tdml = "" end
            VC.Global_Model_Names[tmdl] = ent.VC_Model
        end

        VC.Initialize_PostModel(ent)
        dataDownloaded(mdl, "mdl")
    end
end)

net.Receive("VC_SendToClient_Model_Null", function(len)
    local ent = net.ReadEntity()
    if IsValid(ent) then ent.VC_Model_IsNull = true end
end)

net.Receive("VC_SendToClient_Options", function(len)
    local Tbl = net.ReadTable()
    VC.Settings_TempTbl = Tbl
end)

local function ClearDataCache()
    ultrafreemmansuck = {}
    VC.Global_Model_Names = {}
    for k, v in pairs(VC.GetVehicleList(true)) do
        v.VC_Initialized = nil
        v.VC_Model = nil
    end
end

net.Receive("VC_ClearDataCache", function(len) ClearDataCache() end)
function VC.isThirdPerson(ent)
    local isTP = nil
    if IsValid(ent) then
        isTP = ent.GetThirdPersonMode and ent:GetThirdPersonMode()
        local forcedView = VC_suckfreemmann(ent).forcedView
        if forcedView then
            if isTP then
                if forcedView == 2 then isTP = false end
            else
                if forcedView == 3 then isTP = true end
            end
        end
    end
    return isTP
end

function VC.CheckViewerIsSelf()
    return GetViewEntity() == LocalPlayer()
end

function VC.ViewChanged()
    if VC.View_LastRanMode and VC.CheckViewerIsSelf() then
        local ply = LocalPlayer()
        VC.HUD_FadeAlpha = 255
        if ply.VC_DSPCngd then
            ply.VC_DSPCngd = nil
            ply:SetDSP(1)
        end

        VC.LookBackLerp = nil
        ply.VC_DynFOV = nil
        ply.VC_APLBP = nil
        ply.VC_View_LastMouseMovedTime = nil
        ply.VC_TPVDC = nil
        ply.VC_CCAng = nil
        ply.VC_View_Angle_Simulated = nil
        if ply.VC_View_Angle_Real and IsValid(ply:GetVehicle()) then ply:SetEyeAngles(ply.VC_View_Angle_Real) end
        ply.VC_CnstVV = nil
        ply.VC_View_Angle_Real = nil
        if ply.VC_Cin_CurMode then
            VC.CinModes[ply.VC_Cin_CurMode].End(ply, Veh)
            ply.VC_Cin_CurMode = nil
            ply.VC_Cin_ChangeTime = nil
            ply.VC_Cin_CurTime = nil
        end

        VC.velAvgData = nil
    end
end

net.Receive("VC_ViewChanged", function(len) VC.ViewChanged() end)
function VC.Think_Instant()
    if not VC.getSetting("Enabled") then return end
    local ply = LocalPlayer()
    local ent = ply:GetVehicle()
    if not IsValid(ent) then ent = nil end
    if ent then
        VC.ThinkDriverRan = true
        VC.Initialize_Basic(ent)
        local Veh = VC.getMainVehicle(ent)
        VC.IsThirdPerson = VC.isThirdPerson(ent) and VC.CheckViewerIsSelf()
        if ent.VC_IsNotPrisonerPod or ent.VC_ExtraSeat then
            if ply.VC_LastVehicle and ply.VC_LastVehicle ~= ent then
                if not VC.IsThirdPerson and not vcmod2 then VC.ViewChanged() end
                if VC.VehicleChanged then VC.VehicleChanged(ply, ent) end
            end

            ply.VC_LastVehicle = ent
            local IsNotPod = VC.isVCModCompatible(ent)
            local VSC = IsNotPod or Veh:GetNWBool("VC_HasWeapon", false)
            VC.HandleInput(ply, ent, Veh, IsNotPod, VSC)
            if VC.HandleDSP then VC.HandleDSP(ply, ent, Veh, IsNotPod, VSC) end
        end
    else
        if VC.ThinkDriverRan then
            VC.ThinkDriverRan = nil
            if VC.ResetBones then VC.ResetBones(ply) end
            VC.ViewChanged()
            VC.InputResetHold(ply)
        end
    end

    if VC.Dev_HandleMenu then VC.Dev_HandleMenu() end
end

function VC.Think_time_1()
    local pos = EyePos()
    VC.isPlayerInWorld = util.TraceLine({
        start = pos,
        endpos = pos,
        collisiongroup = COLLISION_GROUP_WORLD
    }).HitWorld
end

hook.Add("PreDrawTranslucentRenderables", "FixEyePos", function() end)
function VC.Think_Each_time_05(ent, EntLN, Drv)
    local pos = VC.OBBToWorld(ent)
    local brt = render.GetLightColor(pos)
    ent.VC_Brightness = (brt.x + brt.y + brt.z) / 30
    ent.VC_notCenter = ent:GetPos() ~= Vector(0, 0, 0)
    ent.VC_isNoDraw = ent:GetNoDraw()
    ent.VC_Distance = VC.GetViewPos():Distance(pos)
    ent.VC_Lht_DstCheck_B = ent.VC_Distance < VC.getSetting("LightDistance", 8000)
    if not ent.VC_Lht_DstCheckMult then ent.VC_Lht_DstCheckMult = 1 end
    local dynLOffDist = VC.getSetting("DynamicLights_OffDist", 2500)
    if VC.getSetting("DynamicLights") and (dynLOffDist - 1000) < ent.VC_Distance then
        if dynLOffDist < ent.VC_Distance then
            ent.VC_LhtSzOffset_D = 0
        else
            ent.VC_LhtSzOffset_D = (dynLOffDist - ent.VC_Distance) / 1000
        end
    else
        ent.VC_LhtSzOffset_D = 1
    end

    if not ent.VC_Lights_RanTimes then ent.VC_Lights_RanTimes = {} end
end

function VC.isClose(ent)
    local dist = ent.VC_Distance
    if dist < 2000 then return dist end
    return false
end

function VC.isCloseEnough(ent)
    local distMult = ent.VC_Lht_DstCheckMult
    if distMult > 0 then return distMult end
    return false
end

function VC.Think_Fast_Each(ent, EntLN, Drv)
    if VC.HandleAudio then VC.HandleAudio(ent, EntLN) end
    if VC.HandleTireTrackData then VC.HandleTireTrackData(ent, EntLN) end
    if VC.HandleSurface then VC.HandleSurface(ent, EntLN) end
end

function VC.Think_Slow()
    if IsValid(VC.Model_Spikestrip_wep) then
        local wep = LocalPlayer():GetActiveWeapon()
        if not IsValid(wep) or wep:GetClass() ~= "vc_spikestrip_wep" then
            VC.Model_Spikestrip_wep:Remove()
            VC.Model_Spikestrip_wep = nil
        end
    end
end

function VC.Think_Instant_PerPlayer(ply)
    local ent = VC.getVehicle(ply)
    if not IsValid(ent) then ent = nil end
    if ent then
        if ply.VC_InVeh then
            if IsValid(ply.VC_lastVehicle) and ply.VC_lastVehicle ~= ent then
                VC.exitStarted(ply)
                VC.exitFinished(ply, ply.VC_lastVehicle)
                VC.enterStarted(ply, ent)
                VC.enterFinished(ply, ent)
                if VC.seatSwitched then VC.seatSwitched(ply, ply.VC_lastVehicle, ent) end
            end
        else
            VC.enterStarted(ply, ent)
            ply.VC_InVeh = true
        end
    else
        if ply.VC_InVeh then
            VC.exitStarted(ply, ent)
            ply.VC_InVeh = false
        end
    end

    if ply.VC_isEntering and CurTime() >= ply.VC_isEntering then VC.enterFinished(ply, ent) end
    if ply.VC_isExiting and CurTime() >= ply.VC_isExiting then VC.exitFinished(ply, ent) end
end

local function SeatIsAvailable(ent, ID)
    local VehTbl = VC_suckfreemmann(ent)
    local data = VehTbl and VehTbl.ExtraSeats and VehTbl.ExtraSeats[ID]
    if data then return not data.BGroups or VC.BGroups_Check(ent, "Seat " .. ID, data.BGroups) end
    return true
end

function VC.SeatsGetAvailable(ent)
    if not ent.VC_SeatTable then
        local data = ent:GetNWString("VC_SeatData", "")
        if data == "" then return {} end
        data = util.JSONToTable(data)
        if not data or table.Count(data) == 0 then return {} end
        local ret = {}
        for k, v in pairs(data) do
            local seat = ents.GetByIndex(v)
            ret[k] = {seat, SeatIsAvailable(ent, k)}
        end
    end
end

function VC.getMainVehicle(ent)
    if ent.VC_ExtraSeat then
        local prt = ent:GetParent()
        if IsValid(prt) then return prt end
    end
    return ent
end

hook.Add("CalcView", "VC_ViewCalc_Shared", function(ply, pos, ang, fov)
    if not VC.getSetting("Enabled") then return end
    local ent, View = ply:GetVehicle(), nil
    local drawChairs = true
    if IsValid(ent) then
        if VC.LastCar ~= ent and ent.SetThirdPersonMode then ent:SetThirdPersonMode(VC.IsInThirdPerson) end
        VC.LastCar = ent
        VC.IsInThirdPerson = ent.GetThirdPersonMode and ent:GetThirdPersonMode()
        local Veh = VC.getMainVehicle(ent)
        if drawChairs or ent.VC_IsNotPrisonerPod or ent.VC_ExtraSeat then
            local IsNotPod = VC.isVCModCompatible(ent)
            local VSC = IsNotPod or Veh:GetNWBool("VC_HasWeapon", false)
            if VC.HandleView then
                local View = VC.HandleView(ply, ent, Veh, IsNotPod, VSC, pos, ang, fov)
                if View and table.Count(View) > 0 then
                    VC.DM_Menu_EyePos = View.origin
                    return View
                end
            end
        end
    else
        VC.velAvgData = nil
    end
end)

function VC.isMidEnterExit(ply)
    return ply.VC_isEntering or ply.VC_isExiting
end

function VC.enterStarted(ply, ent)
    local mainVeh = VC.getMainVehicle(ent)
    ply.VC_isEntering = CurTime() + math.Max(math.Rand(0.7, 1), mainVeh:SequenceDuration() or 0)
    ply.VC_isExiting = false
    ply.VC_InVeh = true
    ply.VC_lastVehicle = ent
    ent.VC_lastDriver = ply
    VC.handleAnimEnterStartInstant(ply, ent)
end

function VC.enterFinished(ply, ent)
    ply.VC_isEntering = false
end

function VC.exitStarted(ply, AIVeh)
    local ent = ply.VC_lastVehicle
    if IsValid(ent) then
        local mainVeh = VC.getMainVehicle(ent)
        ply.VC_isExiting = CurTime() + math.Max(math.Rand(0.7, 1), mainVeh:SequenceDuration() or 0)
        ply.VC_isEntering = false
    end

    VC.ResetBones(ply)
end

function VC.exitFinished(ply, ent)
    ply.VC_isExiting = false
    if IsValid(ent) then ent.VC_lastDriver = nil end
    if IsValid(ply) then
        ply.VC_lastVehicle = nil
        ply.VC_InVeh = false
    end
end

function VC.seatSwitched(ply, ent_old, ent)
end

function VC.VehicleChanged(ply, ent)
    VC.ResetBones(ply)
end

function VC.ResetBones(ent)
    if ent.VC_BoneTable then
        for k, v in pairs(ent.VC_BoneTable) do
            ent:ManipulateBoneAngles(k, Angle(0, 0, 0))
        end

        ent.VC_BoneTable = nil
    end
end

function VC.handleAnimEnterStartInstant(ply, ent, alsoExtraSeat)
    if VC.anim_DoBendLegs then VC.anim_DoBendLegs(ply, ent, alsoExtraSeat) end
    if VC.anim_OnDriverEnter then VC.anim_OnDriverEnter(ply, ent, alsoExtraSeat) end
end

local sort_asc = {
    [1] = true,
    [2] = false,
    [3] = true,
    [4] = false
}

function VC_freemannzhyd(mdl, data, ent)
    if not mdl or not data then return end
    if vcmod1_els then data = VC.Insert_Siren_Lights_Into_Reg(data) end
    if data.Lights then
        data.LightTable = VC_freemannobosrzzz(data)
        data.LightTypeCount = 0
        data.HUD_CanDisplay = nil
        if data.LightTable then
            data.LightTypeCount = table.Count(data.LightTable)
            data.HUD_CanDisplay = data.LightTypeCount > 0 and (data.LightTypeCount > 1 or not data.LightTable.Brake and not data.LightTable.Reverse)
        end

        data.LPT_Seq = nil
        data.LPT = {}
        for Type, vdata in pairs(data.LightTable) do
            for key, v in pairs(vdata) do
                local isELS = nil
                if v.UseSiren then isELS = true end
                local isSeq = nil
                if v.seq_use then isSeq = true end
                local pos = v.SLSPos or v.Pos or Vector(0, 0, 0)
                local newData = {
                    Pos = pos,
                    els = isELS,
                    seq = isSeq,
                    seq_stay = v.seq_stay,
                    x = pos.x,
                    reversed = v.seq_rev
                }

                data.LPT[key] = newData
                if isSeq then
                    if not data.LPT_Seq then
                        data.LPT_Seq = {
                            [0] = {}
                        }
                    end

                    local isLeft = pos.x < 0
                    local isBack = pos.y < 0
                    local side = 1
                    if not isLeft and not isBack then
                        side = 2
                    elseif isLeft and isBack then
                        side = 3
                    elseif not isLeft and isBack then
                        side = 4
                    end

                    local id = side .. Type
                    if not data.LPT_Seq[id] then data.LPT_Seq[id] = {} end
                    data.LPT_Seq[id][key] = newData
                    data.LPT_Seq[0][key] = id
                end
            end
        end

        if data.LPT_Seq then
            local time_on = VC.GetBlinkerOnTime(data)
            for id, _ in pairs(data.LPT_Seq) do
                if id ~= 0 and data.LPT_Seq[id] then
                    local count = table.Count(data.LPT_Seq[id])
                    local ttime = time_on / count
                    local cur = 0
                    local side = tonumber(id[1])
                    for k, v in SortedPairsByMemberValue(data.LPT_Seq[id], "x", sort_asc[side]) do
                        local new = cur + 1
                        data.LPT_Seq[id][k].timeOn = ttime * cur
                        data.LPT_Seq[id][k].timeOff = v.seq_stay and time_on or ttime * new
                        cur = new
                    end
                end
            end
        end

        if vcmod1_els then data = VC.ELS_Convert_Section_Data(data) end
        data.Lights = nil
    end

    table.Merge(ultrafreemmansuck[mdl], data)
    VC.Initialize_PostModel(ent)
end

function VC.Initialize_PostModel(ent)
    local mdl = VC.GetModel(ent)
    if IsValid(ent) and not ultrafreemmansuck[mdl] then
        ultrafreemmansuck[mdl] = {}
        ultrafreemmansuck[mdl].eyePos = VC.GetEyePos(ent)
        ultrafreemmansuck[mdl].semiData_doorLightPos = ultrafreemmansuck[mdl].eyePos * Vector(0, 1, 1) + Vector(0, 0, 8)
        ultrafreemmansuck[mdl].leftSteer = ultrafreemmansuck[mdl].eyePos.x < 0
        local data_semiAuto = VC.SemiAutoData_Pick(ent)
        ultrafreemmansuck[mdl].semiAutoData = data_semiAuto
        if not mdl then return end
        if not ultrafreemmansuck[mdl] then ultrafreemmansuck[mdl] = {} end
        if not VC_suckfreemmann(ent).ScriptStatus or VC_suckfreemmann(ent).ScriptStatus == 0 then
            if not VCModels[mdl] then
                VC_suckfreemmann(ent).ScriptStatus = -1
            else
                VC_suckfreemmann(ent).ScriptStatus = 1
                hook.Call("VC_DataDownloaded", GAMEMODE, mdl)
                hook.Call("VC_dataDownloaded", GAMEMODE, mdl)
                VC_freemannzhyd(mdl, VCModels[mdl], ent)
            end
        end
    else
        if VC.InitializePostDataLoad then VC.InitializePostDataLoad(ent) end
        hook.Call("VC_postVehicleInit", GAMEMODE, ent)
    end
end

function VC.InitializePostDataLoad(ent)
    local data = VC_suckfreemmann(ent)
    if not data then return end
    ent.VC_animDoOverridePos = data.animDriverPosUse and data.animDriverPos
end

function VC.Initialize_Basic_Stage2(ent)
    if ent.VC_IsExtra then
        local entMain = ent:GetParent()
        if not IsValid(entMain) then return end
        if not entMain.VC_SeatTable then entMain.VC_SeatTable = {} end
        local id = ent:GetNWInt("VC_Key")
        if not entMain.VC_SeatTable[id] then entMain.VC_SeatTable[id] = ent end
    end
end

hook.Add("OnTextEntryLoseFocus", "VC_OnTextEntryLoseFocus", function() VC.isTyping_CanTime = CurTime() + 0.1 end)
function VC.isTyping()
    local focus = vgui.GetKeyboardFocus()
    local class = focus and focus:GetClassName()
    local ret = focus and class and class == "TextEntry" or gui.IsConsoleVisible()
    if not ret and VC.isTyping_CanTime then ret = CurTime() < VC.isTyping_CanTime end
    return ret
end

concommand.Add("VC_SetControl", function(ply, cmd, arg)
    if arg[1] and arg[2] then
        local CTbl = util.KeyValuesToTable(file.Read("Data/vcmod/controls.txt", "GAME"))
        if not CTbl[arg[1]] then CTbl[arg[1]] = {} end
        CTbl[arg[1]].mouse = nil
        if arg[4] then CTbl[arg[1]].mouse = "1" end
        if arg[2] == "Hold" then
            CTbl[arg[1]].hold = arg[3]
        else
            CTbl[arg[1]].key = arg[2]
        end

        file.Write("vcmod/controls.txt", util.TableToKeyValues(CTbl))
        VC.Controls_List = CTbl
    end
end)

concommand.Add("VC_SetControl_Override_Use", function(ply, cmd, arg)
    local CTbl = VC.Override_Controls
    if arg[1] then
        if not CTbl then CTbl = {} end
        if not CTbl[arg[1]] then CTbl[arg[1]] = VC.Controls_List[arg[1]] or {} end
        CTbl[arg[1]].use = arg[2]
        VC.Override_Controls = CTbl
    end
end)

concommand.Add("VC_SetControl_Override", function(ply, cmd, arg)
    local CTbl = VC.Override_Controls
    if arg[1] and arg[2] then
        if not CTbl then CTbl = {} end
        if not CTbl[arg[1]] then CTbl[arg[1]] = VC.Controls_List[arg[1]] or {} end
        CTbl[arg[1]].mouse = nil
        if arg[4] then CTbl[arg[1]].mouse = "1" end
        if arg[2] == "Hold" then
            CTbl[arg[1]].hold = arg[3]
        else
            CTbl[arg[1]].key = arg[2]
        end

        VC.Override_Controls = CTbl
    end
end)

hook.Add("PlayerBindPress", "VC_BindPress_DisableFunc", function(ply, bind, pressed)
    if pressed then
        if string.find(bind, "jump") then
            local ent = ply:GetVehicle()
            if not IsValid(ent) then return end
            local data = VC_suckfreemmann(ent)
            if data and data.NoHandbrake then return true end
        end
    end
end)

hook.Add("PlayerBindPress", "VC_BindPress", function(ply, bind)
    if VC.getSetting("Enabled") then
        local ent = ply:GetVehicle()
        if not vgui.CursorVisible() then
            if IsValid(ent) then
                if bind == "+duck" and VC.CheckViewerIsSelf() then
                    if VC.Cinematic_View then
                        ply.VC_Cin_ChangeTime = 0
                    else
                        if not VC.IsInThirdPerson and VC.getServerSetting("TP_Override") then return true end
                    end
                end

                if VC.getSetting("MouseControl") and VC.isVCModCompatible(ent) and VC.isThirdPerson(ent) and GetViewEntity() == LocalPlayer() then
                    local InK = 0
                    if string.find(bind, "invprev") then
                        InK = -0.1
                    elseif string.find(bind, "invnext") then
                        InK = 0.1
                    end

                    VC.View_TP_CamZoomLevel = math.Clamp((VC.View_TP_CamZoomLevel or 1) + InK, 0.7, 2.5)
                end
            elseif string.find(bind, "+use") and (not ply.VC_CheckVehicleEnter or CurTime() >= ply.VC_CheckVehicleEnter) then
                local tr = ply:GetEyeTraceNoCursor()
                if IsValid(tr.Entity) and tr.Entity:IsVehicle() and ply:GetShootPos():Distance(tr.HitPos) <= 75 then
                    net.Start("VC_PlayerScanForSeats")
                    net.WriteEntity(tr.Entity)
                    net.SendToServer()
                end

                ply.VC_CheckVehicleEnter = CurTime() + 0.5
            end
        end
    end
end)

local function GetCmdTbl(cmd)
    local tbl = VC.Controls_List and VC.Controls_List[cmd]
    if VC.getServerSetting("Override_Controls") and VC.Override_Controls and VC.Override_Controls[cmd] and VC.Override_Controls[cmd].use and tostring(VC.Override_Controls[cmd].use) == "1" then tbl = VC.Override_Controls[cmd] end
    return tbl
end

function VC.HandleInput(ply, ent, Veh, IsNotPod, VSC)
    if VC.getSetting("Keyboard_Input") and not VC.isMidEnterExit(ply) then
        if VC.Handle_Input_VC2 then
            VC.Handle_Input_VC2(ply, ent, Veh, IsNotPod, VSC)
        elseif VC.Handle_Input_VC1 then
            VC.Handle_Input_VC1(ply, ent, Veh, IsNotPod, VSC)
        end

        local cursorVis = vgui.CursorVisible()
        for _, Cmd in pairs(VC.Controls_Main) do
            if not Cmd.cursor and not cursorVis or Cmd.cursor and cursorVis then
                local CurrrentCMD = GetCmdTbl(Cmd.cmd)
                if CurrrentCMD and CurrrentCMD.key ~= "None" then
                    local Key, Hold, SKHE, KHB, KHld = CurrrentCMD.key, tobool(CurrrentCMD.hold or "1"), nil, true, true
                    local GK = nil
                    if Key then GK = _G[Key] end
                    if GK then
                        local GKey = input.IsMouseDown(_G[Key]) or input.IsKeyDown(_G[Key])
                        if not VC.UI_Inter_Hover or Key ~= "MOUSE_LEFT" then
                            if Cmd.keyhold then
                                KHld = nil
                                if VC.KeyPrimaryHold then KHld = true end
                            else
                                local OtherHasHold = nil
                                for k, v in pairs(VC.Controls_Main) do
                                    local TempCmd = GetCmdTbl(v.cmd)
                                    if TempCmd and TempCmd.key == Key and v.keyhold and VC.KeyPrimaryHold then
                                        OtherHasHold = true
                                        break
                                    end
                                end

                                if OtherHasHold then
                                    KHB = nil
                                else
                                    for _, KHK in pairs(VC.Controls_Main) do
                                        local TempCmd = GetCmdTbl(KHK.cmd)
                                        if KHK.cmd and TempCmd and Cmd ~= KHK and Key == TempCmd.key and CurrrentCMD.hold == TempCmd.hold and KHK.keyhold and Key ~= "None" then if VC.KeyPrimaryHold then KHB = nil end end
                                    end
                                end
                            end

                            for GK, GV in pairs(VC.Controls_List) do
                                GV = GetCmdTbl(GK)
                                if Key ~= "None" and not Hold and tobool(GV.hold) and GV.key == Key then
                                    SKHE = true
                                    break
                                end
                            end

                            if GKey then
                                if not Cmd.holdTriggerTime then
                                    local set_hold = VC.getSetting("Keyboard_Input_Hold")
                                    Cmd.holdTriggerTime = CurTime() + (SKHE and set_hold or Hold and set_hold or 0)
                                    Cmd.VC_KeyAP = true
                                elseif KHB and KHld and Cmd.VC_KeyAP and (Cmd.carg1 and Hold or not SKHE and CurTime() >= Cmd.holdTriggerTime) then
                                    RunConsoleCommand(Cmd.cmd, Cmd.carg1)
                                    Cmd.VC_KeyAP = nil
                                end
                            elseif Cmd.holdTriggerTime and not GKey then
                                if KHld and KHB and (Cmd.carg2 and Hold or SKHE and CurTime() < Cmd.holdTriggerTime) then RunConsoleCommand(Cmd.cmd, Cmd.carg2) end
                                Cmd.VC_KeyAP = nil
                                Cmd.holdTriggerTime = nil
                            end
                        end
                    end
                end
            end
        end
    end
end

function VC.InputResetHold(ply)
    for k, v in pairs(VC.Controls_Main) do
        VC.Controls_Main[k].holdTriggerTime = nil
    end
end

function VC.HUD_DrawFade()
    if VC.HUD_FadeAlpha and VC.HUD_FadeAlpha > 0 then
        VC.HUD_FadeAlpha = VC.HUD_FadeAlpha - 20 * VC.FTm()
        surface.SetDrawColor(0, 0, 0, VC.HUD_FadeAlpha)
        surface.DrawRect(0, 0, ScrW(), ScrH())
    else
        VC.HUD_FadeAlpha = nil
    end
end

if not VC.DrawFT then VC.DrawFT = {} end
if not VC.UI_AnimDataInfo then VC.UI_AnimDataInfo = {} end
function VC.UI_AnimData(key, On, IncS, DecS)
    local tdata = VC.UI_AnimDataInfo[key]
    if On then
        if not tdata then
            VC.UI_AnimDataInfo[key] = 0
            tdata = 0
        end

        local change = IncS * VC.FTm()
        if change <= 0 then change = 0.001 end
        if tdata < 1 then
            VC.UI_AnimDataInfo[key] = math.Round(tdata + change, 100)
            if VC.UI_AnimDataInfo[key] > 1 then VC.UI_AnimDataInfo[key] = 1 end
        end
    elseif tdata then
        local change = DecS * VC.FTm()
        if change <= 0 then change = 0.001 end
        VC.UI_AnimDataInfo[key] = math.Round(tdata - DecS * VC.FTm(), 100)
        if VC.UI_AnimDataInfo[key] < 0 then VC.UI_AnimDataInfo[key] = nil end
    end
    return VC.UI_AnimDataInfo[key]
end

function VC.UI_canDraw(hookName)
    if hook.Call("HUDShouldDraw", GAMEMODE, hookName) == false then return false end
    return true
end

hook.Add("HUDPaint", "VC_HUDPaint", function()
    local rtime = SysTime()
    VC.FrameTime = rtime - (VC.SysTime or rtime)
    VC.SysTime = rtime
    if not VC.UI_canDraw("VCMod") then return false end
    if VC.getSetting("Enabled") then
        VC.HUD_DrawFade()
        local ply = LocalPlayer()
        local ent = ply:GetVehicle()
        if not IsValid(ent) then ent = nil end
        local Veh = ent and ent.VC_ExtraSeat and ent:GetParent() or ent
        local DrvV = ent and VC.CheckViewerIsSelf() and not VC.isMidEnterExit(ply)
        if VC.DrawFT["Damage"] and VC.UI_canDraw("VCMod_Damage") then VC.DrawFT["Damage"](ply, CARot, ent, DrvV, Veh, Sart_Height) end
        if VC.getSetting("HUD_PickUp") and VC.UI_canDraw("VCMod_Entity") and vcmod1 then VC.DrawFT["PickUp"](ply, CARot, ent, DrvV, Veh, Sart_Height) end
        if VC.DrawFT["Fuel Lid Pos"] and VC.UI_canDraw("VCMod_FuelLid") then VC.DrawFT["Fuel Lid Pos"](ply, CARot, ent, DrvV, Veh, Sart_Height) end
        if Veh and not Veh.VC_isSupported then return end
        local CARot = {0, 0}
        if VC.getSetting("HUD_3D") then
            local AnChng = EyeAngles() - (VC.HUD_PAng or EyeAngles())
            VC.HUD_PAng = EyeAngles()
            VC.HUD_AngRot = LerpAngle(0.2 * VC.getSetting("HUD_3D_Mult"), VC.HUD_AngRot or AnChng, AnChng)
            CARot = {VC.HUD_AngRot.y, VC.HUD_AngRot.p}
            if CARot[1] < 0.0001 and CARot[2] < 0.0001 then CARot = {0, 0} end
        end

        if not VC_DG_HUD_Side and VC.UI_canDraw("VCMod_Side") then
            local Sart_Height = Lerp(VC.getSetting("HUD_Height", 3.5) / 100, 0, ScrH())
            local Lrp = 1
            local SrnTbl = ent and VC.GetModel(ent) and VC_suckfreemmann(ent).Siren
            if vcmod1 then
                if QD_VCModHUD then
                    if QD_VCModHUD_Name then QD_VCModHUD_Name(ply, CARot, ent, DrvV, Veh, Sart_Height) end
                else
                    if VC.getSetting("HUD_Name") and VC.UI_canDraw("VCMod_Name") then VC.DrawFT["Name"](ply, CARot, ent, DrvV, Veh, Sart_Height) end
                    if VC.getSetting("HUD_Cruise") and VC.UI_canDraw("VCMod_Cruise") then VC.DrawFT["Cruise"](ply, CARot, ent, DrvV, Veh, Sart_Height) end
                    if VC.getSetting("HUD_Icons") and VC.UI_canDraw("VCMod_Icons") then
                        Sart_Height = VC.DrawFT["Icons"](ply, CARot, ent, DrvV, Veh, Sart_Height, Lrp, SrnTbl)
                        Lrp = Lrp + 1
                    end

                    if VC.getSetting("HUD_Health") and VC.UI_canDraw("VCMod_Health") then
                        Sart_Height = VC.DrawFT["Health"](ply, CARot, ent, DrvV, Veh, Sart_Height, Lrp, SrnTbl)
                        Lrp = Lrp + 1
                    end

                    if VC.getSetting("HUD_Fuel") and VC.UI_canDraw("VCMod_Fuel") then
                        Sart_Height = VC.DrawFT["Fuel"](ply, CARot, ent, DrvV, Veh, Sart_Height, Lrp, SrnTbl)
                        Lrp = Lrp + 1
                    end

                    if VC.getSetting("HUD_DriveBy") and VC.UI_canDraw("VCMod_DriveBy") then
                        VC.DrawFT["DriveBy"](ply, CARot, ent, DrvV, Veh, Sart_Height, Lrp, SrnTbl)
                        Lrp = Lrp + 1
                    end
                end
            end

            if vcmod1_els then
                if VC.BGroups_Check(ent, "ELS Sound", SrnTbl and SrnTbl.Sound_BGroups) and VC.UI_canDraw("VCMod_ELS_Siren") then
                    Sart_Height = VC.DrawFT["ELS_Siren"](ply, CARot, ent, DrvV, Veh, Sart_Height, Lrp, SrnTbl)
                    Lrp = Lrp + 1
                end

                if VC.BGroups_Check(ent, "ELS Sections", SrnTbl and SrnTbl.Sections_BGroups) and VC.UI_canDraw("VCMod_ELS_Lights") then
                    Sart_Height = VC.DrawFT["ELS_Lights"](ply, CARot, ent, DrvV, Veh, Sart_Height, Lrp, SrnTbl)
                    Lrp = Lrp + 1
                end
            end
        end

        if VC.Local and VC.UI_canDraw("VCMod_Speedometer") then VC.DrawFT["Speedo"](ply, CARot, ent, DrvV, Veh, Sart_Height) end
        if VC.CD and VC.CD.HUDPaint then VC.CD.HUDPaint() end
        if VC.RM and VC.RM.HUDPaint then VC.RM.HUDPaint() end
    end
end)

VC.dataSpeedo = {}
local nData = {}
nData.draw = function() end
VC.dataSpeedo["default"] = nData
VC.dataSpeedoCur = VC.dataSpeedo["default"]
local mats = {}
local name = "body_outer"
mats[name] = Material("vcmod/hud/speedo/default/" .. name .. ".png")
local name = "body_inner"
mats[name] = Material("vcmod/hud/speedo/default/" .. name .. ".png")
local name = "body_fill"
mats[name] = Material("vcmod/hud/speedo/default/" .. name .. ".png")
local name = "body_fill_extra"
mats[name] = Material("vcmod/hud/speedo/default/" .. name .. ".png")
local name = "extra"
mats[name] = Material("vcmod/hud/speedo/default/" .. name .. ".png")
local name = "spikes"
mats[name] = Material("vcmod/hud/speedo/default/" .. name .. ".png")
local name = "numbers_200"
mats[name] = Material("vcmod/hud/speedo/default/" .. name .. ".png")
VC.DrawFT["Speedo"] = function(ply, CARot, ent, DrvV, GVeh, Sart_Height, Lrp, SrnTbl)
    local data = VC.dataSpeedoCur
    if not data then return end
    local pos = LocalPlayer():GetPos()
    local size = 300
    local pos = {}
    pos.x = ScrW() - size / 2 - 50
    pos.y = ScrH() - size / 2
    surface.SetDrawColor(255, 255, 255, 255)
    surface.SetMaterial(mats["body_fill"])
    surface.DrawTexturedRectRotated(pos.x, pos.y, size, size, 0)
    surface.SetDrawColor(255, 255, 255, 255)
    surface.SetDrawColor(VC.Color.Accent_Light.r, VC.Color.Accent_Light.g, VC.Color.Accent_Light.b, 255)
    surface.SetMaterial(mats["body_fill_extra"])
    surface.DrawTexturedRectRotated(pos.x, pos.y, size, size, 0)
    surface.SetDrawColor(255, 255, 255, 255)
    surface.SetMaterial(mats["spikes"])
    surface.DrawTexturedRectRotated(pos.x, pos.y, size, size, 0)
    surface.SetDrawColor(255, 255, 255, 255)
    surface.SetDrawColor(VC.Color.Accent_Light.r, VC.Color.Accent_Light.g, VC.Color.Accent_Light.b, 255)
    surface.SetMaterial(mats["body_inner"])
    surface.DrawTexturedRectRotated(pos.x, pos.y, size, size, 0)
    surface.SetDrawColor(255, 255, 255, 255)
    surface.SetMaterial(mats["body_outer"])
    surface.DrawTexturedRectRotated(pos.x, pos.y, size, size, 0)
    surface.SetDrawColor(255, 255, 255, 255)
    surface.SetMaterial(mats["numbers_200"])
    surface.DrawTexturedRectRotated(pos.x, pos.y, size, size, 0)
    surface.SetDrawColor(255, 255, 255, 255)
    surface.SetMaterial(mats["extra"])
    surface.DrawTexturedRectRotated(pos.x, pos.y, size, size, 0)
end

VC.UI_InterData = {}
VC.UI_Inter_Cache = {}
function VC.UI_InterAdd(id, data)
    VC.UI_InterData[id] = data
end

local data = {}
data.name = "Switch lights"
data.desc = "Controls the running lights (front and rear) and the low beams."
data.cmd = "vc_lights_switch"
data.type = 0
data.checkIfActive = function(ent) return true end
data.checkIfCan = function(ent) return true end
data.findPos = function(ent, id) return VC.UI_Inter_getPos_eyePosBased(ent, id) end
VC.UI_InterAdd(data.cmd, data)
local data = {}
data.name = "Horn"
data.desc = "Controls the horn"
data.cmd = "vc_horn"
data.type = 1
data.checkIfActive = function(ent) return true end
data.checkIfCan = function(ent) return true end
data.findPos = function(ent, id) return VC.UI_Inter_getPos_eyePosBased(ent, id) end
VC.UI_InterAdd(data.cmd, data)
function VC.UI_Inter_getPos_eyePosBased(ent, id)
    local ret = Vector(0, 0, 0)
    local sData = VC_suckfreemmann(ent)
    if sData.UI_Inter and sData.UI_Inter[id] and sData.UI_Inter and sData.UI_Inter[id].override then
        if sData.UI_Inter[id].pos then ret = sData.UI_Inter[id].pos end
    else
        if sData.eyePos then
            local semiData = VC.SemiAutoData[sData.semiAutoData]
            local extra = VC_TEMPVEC or semiData and semiData.UI_Inter and semiData.UI_Inter[id] or Vector(-19.71, -11.36, 59.18)
            if not sData.semiData_axleSpacing then
                local val = 130
                local p1, has = VC.GetWheelPos(ent, 1, 143)
                if not has then p1 = nil end
                local p2, has = VC.GetWheelPos(ent, 3, 143)
                if not has then p2 = nil end
                if p1 and p2 then val = p1:Distance(p2) end
                sData.semiData_axleSpacingMult = math.floor(val) / 130
                sData.semiData_axleSpacing = val
            end

            ret = sData.eyePos + Vector(sData.leftSteer and (-extra.x) or extra.x, extra.y, extra.z) * sData.semiData_axleSpacingMult
        end
    end
    return ret
end

local function UI_Inter_Refresh_Cache(mdl)
end

VC.Color.UI_Inter = VC.Color.Base
VC.Color.UI_Inter_Sel = VC.Color.Accent_Light
function VC.UI_Inter_Initialize(ent)
    local mdl = VC.GetModel(ent)
    VC.UI_Inter_Cache[mdl] = {}
    for k, data in pairs(VC.UI_InterData) do
        local ndata = nil
        if data.checkIfCan(ent) then
            ndata = table.Copy(data)
            ndata.pos = ndata.findPos(ent, k)
            ndata.findPos = nil
            ndata.checkIfCan = nil
        end

        VC.UI_Inter_Cache[mdl][data.cmd] = ndata
    end
end

local function UI_Inter_GetInfo(ent)
    local mdl = VC.GetModel(ent)
    VC.UI_Inter_Initialize(ent)
    return VC.UI_Inter_Cache[mdl]
end

local function UI_Inter_findPos(ent, data)
    local ret = Vector(0, 0, 0)
    local pos = data.pos
    if data.findPos then pos = data.findPos(ent, data) end
    ret = ent:LocalToWorld(pos or Vector(0, 0, 0)):ToScreen()
    return ret
end

function VC.UI_Inter_Click(int, mdl)
    if not mdl then
        local ent = LocalPlayer():GetVehicle()
        if IsValid(ent) then local mdl = ent.VC_Model end
    end

    local data = table.Copy(VC.UI_Inter_GetAll(mdl)[int])
    RunConsoleCommand(data.cmd, data.carg1 or "1")
    VC.UI_Inter_Pressed = data
end

function VC.UI_Inter_Unclick()
    if VC.UI_Inter_Pressed then
        local data = VC.UI_Inter_Pressed
        if data.Carg2 then end
        VC.UI_Inter_Pressed = nil
    end
end

local function UI_Inter_LoseHover()
    VC.UI_Inter_Hover = nil
    VC.UI_Inter_Unclick()
end

local function UI_Inter_HandleInputs(mdl)
    if input.IsMouseDown(MOUSE_LEFT) then
        if not VC.Input_Mouse_Left_Down then
            VC.Input_Mouse_Left_Down = true
            if VC.UI_Inter_Hover and not VC.UI_Inter_Pressed then VC.UI_Inter_Click(VC.UI_Inter_Hover, mdl) end
        end
    elseif VC.Input_Mouse_Left_Down then
        VC.Input_Mouse_Left_Down = nil
        VC.UI_Inter_Unclick()
    end
end

local function UI_Inter_HandleDrawing(k, pos)
    local clr = VC.Color.UI_Inter
    local size = 8
    local alpha = 155
    if VC.UI_Inter_Pressed then
        clr = VC.Color.Good
        size = 15
        alpha = 255
    else
        if VC.UI_Inter_Hover and k == VC.UI_Inter_Hover then
            clr = VC.Color.UI_Inter_Sel
            size = 12
            alpha = 255
        end
    end

    surface.SetDrawColor(clr.r, clr.g, clr.b, alpha)
    surface.DrawTexturedRect(pos.x - size / 2, pos.y - size / 2, size, size)
end

local function do_UI_Inter()
    if not VC.IsThirdPerson or true then
        local ent = LocalPlayer():GetVehicle()
        local ent = ents.FindByClass("prop_vehicle_jeep")[1]
        if IsValid(ent) then
            local mdl = ent.VC_Model
            if mdl then
                local info = UI_Inter_GetInfo(ent)
                if not VC.UI_Inter_RescanTime or CurTime() >= VC.UI_Inter_RescanTime then
                    VC.UI_Inter_Hover = nil
                    local screenW, screenH = ScrW() / 2, ScrH() / 2
                    local mouse_sx, mouse_sy = gui.MousePos()
                    local dist, hover, mpos = 500, nil, nil
                    surface.SetMaterial(VC.Material.Circle_32)
                    for k, data in pairs(info) do
                        local pos = ent:LocalToWorld(data.pos or Vector(0, 0, 0)):ToScreen()
                        UI_Inter_HandleDrawing(k, pos)
                        if vgui.CursorVisible() then
                            local csize = 15
                            if pos.x > (mouse_sx - csize) and pos.x < (mouse_sx + csize) and pos.y > (mouse_sy - csize) and pos.y < (mouse_sy + csize) then
                                local cdist = Vector(pos.x, pos.y, 0):Distance(Vector(mouse_sx, mouse_sy, 0))
                                if cdist < dist then
                                    dist = cdist
                                    hover = k
                                end
                            end
                        else
                            local csize = 50
                            local cdist = math.max(math.abs(pos.x - screenW), math.abs(pos.y - screenH))
                            if cdist < csize and cdist < dist then
                                dist = cdist
                                hover = k
                            end
                        end
                    end

                    if hover then VC.UI_Inter_Hover = hover end
                end
            elseif VC.UI_Inter_Hover then
                UI_Inter_LoseHover()
            end
        elseif VC.UI_Inter_Hover then
            UI_Inter_LoseHover()
        end
    elseif VC.UI_Inter_Hover then
        UI_Inter_LoseHover()
    end
end

if vcmod_dev then
    hook.Add("HUDPaint", "VC_HUDPaint_Inter", function()
        if not VC.UI_canDraw("VCMod_Interior") then return end
        if VC.Dev_IsFree then
            if VC.Dev_Imager_Perform and VC.Dev_Imager_Perform.perform then return end
            do_UI_Inter()
        end
    end)
end

if not VC.Material then VC.Material = {} end
if not VC.Image then VC.Image = {} end
local ID = "hue_ring"
VC.Image[ID] = "materials/vcmod/gui/hue_ring.png"
VC.Material[ID] = Material(VC.Image[ID])
local ID = "icon_add"
VC.Image[ID] = "materials/vcmod/gui/icons/add.png"
VC.Material[ID] = Material(VC.Image[ID])
local ID = "icon_brakepads"
VC.Image[ID] = "materials/vcmod/gui/icons/brakepads.png"
VC.Material[ID] = Material(VC.Image[ID])
local ID = "icon_car"
VC.Image[ID] = "materials/vcmod/gui/icons/car.png"
VC.Material[ID] = Material(VC.Image[ID])
local ID = "icon_check"
VC.Image[ID] = "materials/vcmod/gui/icons/check.png"
VC.Material[ID] = Material(VC.Image[ID])
local ID = "icon_climate"
VC.Image[ID] = "materials/vcmod/gui/icons/climate.png"
VC.Material[ID] = Material(VC.Image[ID])
local ID = "icon_copy"
VC.Image[ID] = "materials/vcmod/gui/icons/copy.png"
VC.Material[ID] = Material(VC.Image[ID])
local ID = "icon_cross"
VC.Image[ID] = "materials/vcmod/gui/icons/cross.png"
VC.Material[ID] = Material(VC.Image[ID])
local ID = "icon_download"
VC.Image[ID] = "materials/vcmod/gui/icons/download.png"
VC.Material[ID] = Material(VC.Image[ID])
local ID = "icon_drop"
VC.Image[ID] = "materials/vcmod/gui/icons/drop.png"
VC.Material[ID] = Material(VC.Image[ID])
local ID = "icon_edit"
VC.Image[ID] = "materials/vcmod/gui/icons/edit.png"
VC.Material[ID] = Material(VC.Image[ID])
local ID = "icon_electricity"
VC.Image[ID] = "materials/vcmod/gui/icons/electricity.png"
VC.Material[ID] = Material(VC.Image[ID])
local ID = "icon_els"
VC.Image[ID] = "materials/vcmod/gui/icons/els.png"
VC.Material[ID] = Material(VC.Image[ID])
local ID = "icon_esp"
VC.Image[ID] = "materials/vcmod/gui/icons/esp.png"
VC.Material[ID] = Material(VC.Image[ID])
local ID = "icon_exhaust"
VC.Image[ID] = "materials/vcmod/gui/icons/exhaust.png"
VC.Material[ID] = Material(VC.Image[ID])
local ID = "icon_fuel"
VC.Image[ID] = "materials/vcmod/gui/icons/fuel.png"
VC.Material[ID] = Material(VC.Image[ID])
local ID = "icon_home"
VC.Image[ID] = "materials/vcmod/gui/icons/home.png"
VC.Material[ID] = Material(VC.Image[ID])
local ID = "icon_info"
VC.Image[ID] = "materials/vcmod/gui/icons/info.png"
VC.Material[ID] = Material(VC.Image[ID])
local ID = "icon_left"
VC.Image[ID] = "materials/vcmod/gui/icons/left.png"
VC.Material[ID] = Material(VC.Image[ID])
local ID = "icon_paste"
VC.Image[ID] = "materials/vcmod/gui/icons/paste.png"
VC.Material[ID] = Material(VC.Image[ID])
local ID = "icon_remove"
VC.Image[ID] = "materials/vcmod/gui/icons/remove.png"
VC.Material[ID] = Material(VC.Image[ID])
local ID = "icon_repair"
VC.Image[ID] = "materials/vcmod/gui/icons/repair.png"
VC.Material[ID] = Material(VC.Image[ID])
local ID = "icon_right"
VC.Image[ID] = "materials/vcmod/gui/icons/right.png"
VC.Material[ID] = Material(VC.Image[ID])
local ID = "icon_save"
VC.Image[ID] = "materials/vcmod/gui/icons/save.png"
VC.Material[ID] = Material(VC.Image[ID])
local ID = "icon_search"
VC.Image[ID] = "materials/vcmod/gui/icons/search.png"
VC.Material[ID] = Material(VC.Image[ID])
local ID = "icon_seat"
VC.Image[ID] = "materials/vcmod/gui/icons/seat.png"
VC.Material[ID] = Material(VC.Image[ID])
local ID = "icon_settings"
VC.Image[ID] = "materials/vcmod/gui/icons/settings.png"
VC.Material[ID] = Material(VC.Image[ID])
local ID = "icon_spikestrips"
VC.Image[ID] = "materials/vcmod/gui/icons/spikestrips.png"
VC.Material[ID] = Material(VC.Image[ID])
local ID = "icon_trailer"
VC.Image[ID] = "materials/vcmod/gui/icons/trailer.png"
VC.Material[ID] = Material(VC.Image[ID])
local ID = "icon_upload"
VC.Image[ID] = "materials/vcmod/gui/icons/upload.png"
VC.Material[ID] = Material(VC.Image[ID])
local ID = "icon_wheel"
VC.Image[ID] = "materials/vcmod/gui/icons/wheel.png"
VC.Material[ID] = Material(VC.Image[ID])
local ID = "icon_abs"
VC.Image[ID] = "materials/vcmod/gui/icons/dashboard/abs.png"
VC.Material[ID] = Material(VC.Image[ID])
local ID = "icon_airbag"
VC.Image[ID] = "materials/vcmod/gui/icons/dashboard/airbag.png"
VC.Material[ID] = Material(VC.Image[ID])
local ID = "icon_battery"
VC.Image[ID] = "materials/vcmod/gui/icons/dashboard/battery.png"
VC.Material[ID] = Material(VC.Image[ID])
local ID = "icon_blinker_left"
VC.Image[ID] = "materials/vcmod/gui/icons/dashboard/blinker_left.png"
VC.Material[ID] = Material(VC.Image[ID])
local ID = "icon_blinker_right"
VC.Image[ID] = "materials/vcmod/gui/icons/dashboard/blinker_right.png"
VC.Material[ID] = Material(VC.Image[ID])
local ID = "icon_brakes"
VC.Image[ID] = "materials/vcmod/gui/icons/dashboard/brakes.png"
VC.Material[ID] = Material(VC.Image[ID])
local ID = "icon_coolant"
VC.Image[ID] = "materials/vcmod/gui/icons/dashboard/coolant.png"
VC.Material[ID] = Material(VC.Image[ID])
local ID = "icon_cruise"
VC.Image[ID] = "materials/vcmod/gui/icons/dashboard/cruise.png"
VC.Material[ID] = Material(VC.Image[ID])
local ID = "icon_engine"
VC.Image[ID] = "materials/vcmod/gui/icons/dashboard/engine.png"
VC.Material[ID] = Material(VC.Image[ID])
local ID = "icon_fog"
VC.Image[ID] = "materials/vcmod/gui/icons/dashboard/fog.png"
VC.Material[ID] = Material(VC.Image[ID])
local ID = "icon_hazards"
VC.Image[ID] = "materials/vcmod/gui/icons/dashboard/hazards.png"
VC.Material[ID] = Material(VC.Image[ID])
local ID = "icon_heater"
VC.Image[ID] = "materials/vcmod/gui/icons/dashboard/heater.png"
VC.Material[ID] = Material(VC.Image[ID])
local ID = "icon_highbeams"
VC.Image[ID] = "materials/vcmod/gui/icons/dashboard/highbeams.png"
VC.Material[ID] = Material(VC.Image[ID])
local ID = "icon_lowbeams"
VC.Image[ID] = "materials/vcmod/gui/icons/dashboard/lowbeams.png"
VC.Material[ID] = Material(VC.Image[ID])
local ID = "icon_oil"
VC.Image[ID] = "materials/vcmod/gui/icons/dashboard/oil.png"
VC.Material[ID] = Material(VC.Image[ID])
local ID = "icon_running"
VC.Image[ID] = "materials/vcmod/gui/icons/dashboard/running.png"
VC.Material[ID] = Material(VC.Image[ID])
local ID = "icon_seatbelt"
VC.Image[ID] = "materials/vcmod/gui/icons/dashboard/seatbelt.png"
VC.Material[ID] = Material(VC.Image[ID])
local ID = "icon_tire_pressure"
VC.Image[ID] = "materials/vcmod/gui/icons/dashboard/tire_pressure.png"
VC.Material[ID] = Material(VC.Image[ID])
function VC.UI_AnimatePanel_Start(self, time, delay)
    self:AlphaTo(0, 0, 0)
    self:AlphaTo(255, time or 1, delay or 0.5)
end

VC.Material.Fade = Material("VCMod/fade")
VC.Material.Circle_32 = Material("vcmod/circle_32")
VC.Material.Circle = Material("vcmod/circle")
VC.Material.Check = Material("vcmod/check.png")
VC.Material.Cross = Material("vcmod/cross.png")
VC.Material.Info = Material("vcmod/info.png")
VC.Material.Button = Material("vcmod/button.png")
function VC.UI_PaintOver(obj, Sx, Sy)
    local pnl = obj.VC_Panel
    if obj:IsHovered() or pnl and pnl:IsHovered() then
        local tclr = VC.ColorCopyAlpha(VC.Color.Accent, (obj.IsDown and obj:IsDown() or pnl and pnl.IsDown and pnl:IsDown()) and 55 or 25)
        surface.SetDrawColor(tclr)
        surface.DrawRect(0, 0, Sx, Sy)
    end
end

local function applyMenu(self)
    self.AddSpacer = function()
        local dpnl = vgui.Create("DPanel")
        dpnl:SetTall(6)
        dpnl.Paint = function(obj, Sx, Sy)
            surface.SetDrawColor(VC.Color.Accent)
            surface.DrawLine(5, 3, Sx - 5, 3)
        end

        self:AddPanel(dpnl)
    end

    self.AddSlider = function(obj, text, min, max, dec, def, cw, ch)
        local el = vgui.Create("DNumSlider", self)
        el.Label:SetTextColor(Color(0, 0, 0, 255))
        el:SetText(text or "")
        el:SetMin(mir or 0)
        el:SetMax(max or 1)
        el:SetDecimals(dec or 2)
        el:SetValue(def or 0)
        self:AddCustom(el, cw or 250, ch or 30)
        el.TextArea:SetEditable(true)
        el.TextArea:SetEnabled(true)
        return el
    end

    self.AddLabel = function(obj, text, cw, ch)
        local el = vgui.Create("DLabel", self)
        el:SetText(text)
        el:SetColor(Color(0, 0, 0, 255))
        self:AddCustom(el, cw or 250, ch or 24)
        return el
    end

    self.AddCheckBox = function(obj, text, def, cw, ch)
        local el = vgui.Create("DCheckBoxLabel", self)
        el:SetText(text)
        el:SetTextColor(Color(0, 0, 0, 255))
        el:SetChecked(def or 0)
        self:AddCustom(el, cw or 250, ch or 24)
        return el
    end

    self.AddButtonStay = function(obj, text, func)
        local el = vgui.Create("DButton", self)
        el:SetText(text or "")
        self:AddCustom(el, cw or 250, ch or 30)
        el.Paint = VC.UI_PaintOver
        function el:SetColorIcon(clr)
            el.ColorIcon = clr
        end

        el.PaintOver = function(_, Sx, Sy)
            if el.ColorIcon then
                draw.RoundedBox(4, 10, 5, 12, 12, VC.Color.Accent)
                draw.RoundedBox(4, 11, 6, 10, 10, el.ColorIcon)
            end
        end
        return el
    end

    self.AddButton = function(obj, text, func)
        local el = self:AddOption(text, func)
        el.Paint = VC.UI_PaintOver
        function el:SetColorIcon(clr)
            el.ColorIcon = clr
        end

        el.PaintOver = function(_, Sx, Sy)
            if el.ColorIcon then
                draw.RoundedBox(4, 10, 5, 12, 12, VC.Color.Accent)
                draw.RoundedBox(4, 11, 6, 10, 10, el.ColorIcon)
            end
        end
        return el
    end

    self.VC_AddSubMenu = function(obj, text, func)
        local sobj, sobj_l = obj:AddSubMenu(text, func)
        applyMenu(sobj)
        sobj_l.Paint = VC.UI_PaintOver
        sobj.Paint = function(tobj, Sx, Sy)
            surface.SetDrawColor(VC.Color.Accent)
            surface.DrawRect(0, 0, Sx, Sy)
            surface.SetDrawColor(VC.Color.Base)
            surface.DrawRect(1, 1, Sx - 2, Sy - 2)
        end
        return sobj, sobj_l
    end

    self.AddCustom = function(obj, el, cw, ch, marg)
        local pnl = vgui.Create("DPanel", self)
        pnl.Paint = function() end
        el:SetParent(pnl)
        pnl:SetTall(ch or el:GetTall())
        pnl:SetWide(cw or self:GetWide())
        if marg then
            el:DockMargin(marg.l, marg.t, marg.r, marg.b)
        else
            el:DockMargin(10, 4, 10, 4)
        end

        pnl.VC_Panel = el
        pnl.PaintOver = VC.UI_PaintOver
        el:Dock(FILL)
        self:AddPanel(pnl)
        return pnl
    end
end

function VC.DermaMenu(text)
    local self = DermaMenu()
    applyMenu(self)
    self.AddAction = function(obj, clk, icon, ttip)
        if not self.ActionPanel then
            self.ActionPanel = vgui.Create("DPanel")
            self.ActionPanel:SetTall(40)
            self.ActionPanel.Paint = function(idx, Sx, Sy) end
            self:AddCustom(self.ActionPanel)
            self:AddSpacer()
        end

        local tall = self.ActionPanel:GetTall()
        local btn = vgui.Create("DButton", self.ActionPanel)
        btn:SetSize(tall, tall)
        btn.DoClick = clk
        btn:Dock(LEFT)
        btn:SetText("")
        btn.VC_Icon = icon
        if ttip then btn:SetTooltip(ttip) end
        local margins = 2
        btn.PaintOver = VC.UI_PaintOver
        btn.Paint = function(idx, Sx, Sy)
            if idx.VC_Icon then
                surface.SetDrawColor(VC.Color.Accent)
                surface.SetMaterial(idx.VC_Icon)
                surface.DrawTexturedRect(margins, margins, Sx - margins * 2, Sy - margins * 2)
            end
        end
    end

    self.VC_Text = text or VC.Lng("Unknown")
    self.Button_Close = vgui.Create("DButton", self)
    self.Button_Close:SetTall(25)
    self.Button_Close:SetText("")
    self.Button_Close.DoClick = function() self:Remove() end
    self.Button_Close.Paint = function(obj, Sx, Sy) draw.SimpleText(self.VC_Text, "VC_DEV_lower", Sx / 2, Sy - 3, VC.Color.Accent, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM) end
    self:AddPanel(self.Button_Close)
    self.Paint = function(obj, Sx, Sy)
        local clr_bg = VC.Color.Base
        local clr_a = VC.Color.Accent
        local hov = self.Button_Close:IsHovered()
        local act = self.Button_Close:IsDown()
        local clr = VC.Color.Accent_Light
        if hov then clr = VC.Color.Accent end
        if act then clr = VC.Color.Base end
        surface.SetDrawColor(clr)
        local size = 25
        surface.DrawRect(Sx - size - 2, 2, size, size)
        local clr = VC.Color.Base
        if hov then clr = Color(255, 255, 255, 255) end
        if act then clr = VC.Color.Accent end
        surface.SetDrawColor(clr)
        surface.SetMaterial(VC.Material.icon_cross)
        local size = 12
        surface.DrawTexturedRect(Sx - size - 2, 2, size, size)
        VC.UI_DrawPanelBG(obj, Sx, Sy)
    end

    self.AddSpacer()
    VC.UI_AnimatePanel_Start(self, 0.2, 0)
    return self
end

local function createPoly(Sx, Sy, cSize, extra, psx, psy)
    return {
        {
            x = psx + extra,
            y = psy + extra
        },
        {
            x = psx + Sx - cSize - extra,
            y = psy + extra
        },
        {
            x = psx + Sx - extra,
            y = psy + cSize + extra
        },
        {
            x = psx + Sx - extra,
            y = psy + Sy - extra
        },
        {
            x = psx + extra,
            y = psy + Sy - extra
        }
    }
end

function VC.UI_DrawPanelBG(obj, Sx, Sy, psx, psy, extra)
    if not psx then psx = 0 end
    if not psy then psy = 0 end
    if not extra then extra = 25 end
    local clr_bg = VC.Color.Base
    local clr_a = VC.Color.Accent
    surface.SetDrawColor(clr_a)
    draw.NoTexture()
    surface.DrawPoly(createPoly(Sx, Sy, extra, 0, psx, psy))
    surface.SetDrawColor(clr_bg)
    surface.DrawPoly(createPoly(Sx, Sy, extra, 2, psx, psy))
end

function VCMsg(PM, clr)
    if type(PM) == "table" then
        VCMsg("Displaying message as table.")
        PrintTable(PM)
        VCMsg("Finished displaying message as table.")
        return
    end

    if type(PM) ~= "string" then
        PM = tostring(PM)
    else
        PM = VC.Lng(PM)
    end

    if not PM then PM = "nil" end
    if not VC_DG_Chat_Msg_All then chat.AddText(VC.Color.Accent_Light, "VCMod: ", clr or VC.Color.Base, tostring(PM)) end
end

net.Receive("VCMsg", function(len)
    local PM = net.ReadTable()
    VCMsg(PM[1], nil, true)
end)

if not VC.Fonts then VC.Fonts = {} end
local Txt = "VC_Dev_Text"
if not VC.Fonts[Txt] then
    VC.Fonts[Txt] = true
    surface.CreateFont(Txt, {
        font = "MenuLarge",
        size = 16,
        weight = 1000,
        blursize = 0,
        scanlines = 0,
        antialias = true,
        underline = false,
        italic = false,
        strikeout = false,
        symbol = false,
        rotary = false,
        shadow = false,
        additive = false,
        outline = false
    })
end

local Font = "VC_Big"
if not VC.Fonts[Font] then
    VC.Fonts[Font] = true
    surface.CreateFont(Font, {
        font = "Trebuchet24",
        size = 26,
        weight = 10000,
        blursize = 0,
        scanlines = 0,
        antialias = true,
        underline = false,
        italic = false,
        strikeout = false,
        symbol = false,
        rotary = false,
        shadow = false,
        additive = false,
        outline = false
    })
end

local Font_i = "VC_Big_Italic"
if not VC.Fonts[Font_i] then
    VC.Fonts[Font_i] = true
    surface.CreateFont(Font_i, {
        font = "Trebuchet24",
        size = 26,
        weight = 10000,
        blursize = 0,
        scanlines = 0,
        antialias = true,
        underline = false,
        italic = true,
        strikeout = false,
        symbol = false,
        rotary = false,
        shadow = false,
        additive = false,
        outline = false
    })
end

local Font_Logo = "VC_Logo"
if not VC.Fonts[Font_Logo] then
    VC.Fonts[Font_Logo] = true
    surface.CreateFont(Font_Logo, {
        font = "MenuLarge",
        size = 50,
        weight = 1000,
        blursize = 5,
        scanlines = 0,
        antialias = true,
        underline = false,
        italic = false,
        strikeout = false,
        symbol = false,
        rotary = false,
        shadow = false,
        additive = false,
        outline = false
    })
end

local Font_SideBtn = "VC_Menu_Side"
if not VC.Fonts[Font_SideBtn] then
    VC.Fonts[Font_SideBtn] = true
    surface.CreateFont(Font_SideBtn, {
        font = "MenuLarge",
        size = 20,
        weight = 1000,
        blursize = 0,
        scanlines = 0,
        antialias = true,
        underline = false,
        italic = false,
        strikeout = false,
        symbol = false,
        rotary = false,
        shadow = false,
        additive = false,
        outline = false
    })
end

local Font_SideBtn_Focused = "VC_Menu_Side_Focused"
if not VC.Fonts[Font_SideBtn_Focused] then
    VC.Fonts[Font_SideBtn_Focused] = true
    surface.CreateFont(Font_SideBtn_Focused, {
        font = "MenuLarge",
        size = 20,
        weight = 1000,
        blursize = 0,
        scanlines = 0,
        antialias = true,
        underline = false,
        italic = true,
        strikeout = false,
        symbol = false,
        rotary = false,
        shadow = false,
        additive = false,
        outline = false
    })
end

local Font_Header = "VC_Menu_Header"
if not VC.Fonts[Font_Header] then
    VC.Fonts[Font_Header] = true
    surface.CreateFont(Font_Header, {
        font = "MenuLarge",
        size = 18,
        weight = 1000,
        blursize = 0,
        scanlines = 0,
        antialias = true,
        underline = false,
        italic = false,
        strikeout = false,
        symbol = false,
        rotary = false,
        shadow = false,
        additive = false,
        outline = false
    })
end

local Font_Header_Focused = "VC_Menu_Header_Focused"
if not VC.Fonts[Font_Header_Focused] then
    VC.Fonts[Font_Header_Focused] = true
    surface.CreateFont(Font_Header_Focused, {
        font = "MenuLarge",
        size = 18,
        weight = 1000,
        blursize = 0,
        scanlines = 0,
        antialias = true,
        underline = false,
        italic = true,
        strikeout = false,
        symbol = false,
        rotary = false,
        shadow = false,
        additive = false,
        outline = false
    })
end

local Fnt = "VC_Name"
if not VC.Fonts[Fnt] then
    VC.Fonts[Fnt] = true
    surface.CreateFont(Fnt, {
        font = "MenuLarge",
        size = 26,
        weight = 1000,
        blursize = 0,
        scanlines = 0,
        antialias = true,
        underline = false,
        italic = false,
        strikeout = false,
        symbol = false,
        rotary = false,
        shadow = false,
        additive = false,
        outline = false
    })
end

local Font_Info_Small = "VC_Info_Small"
if not VC.Fonts[Font_Info_Small] then
    VC.Fonts[Font_Info_Small] = true
    surface.CreateFont(Font_Info_Small, {
        font = "MenuLarge",
        size = 19,
        weight = 1000,
        blursize = 0,
        scanlines = 0,
        antialias = true,
        underline = false,
        italic = false,
        strikeout = false,
        symbol = false,
        rotary = false,
        shadow = false,
        additive = false,
        outline = false
    })
end

local Font_Info_Smaller = "VC_Info_Smaller"
if not VC.Fonts[Font_Info_Smaller] then
    VC.Fonts[Font_Info_Smaller] = true
    surface.CreateFont(Font_Info_Smaller, {
        font = "MenuLarge",
        size = 17,
        weight = 1000,
        blursize = 0,
        scanlines = 0,
        antialias = true,
        underline = false,
        italic = false,
        strikeout = false,
        symbol = false,
        rotary = false,
        shadow = false,
        additive = false,
        outline = false
    })
end

if not VC.Fonts["VC_Regular2"] then
    VC.Fonts["VC_Regular2"] = true
    surface.CreateFont("VC_Regular2", {
        font = "MenuLarge",
        size = 15,
        weight = 1000,
        blursize = 0,
        scanlines = 0,
        antialias = true,
        underline = false,
        italic = false,
        strikeout = false,
        symbol = false,
        rotary = false,
        shadow = false,
        additive = false,
        outline = false
    })
end

if not VC.Fonts["VC_HUD_Bisgs"] then
    VC.Fonts["VC_HUD_Bisgs"] = true
    surface.CreateFont("VC_HUD_Bisgs", {
        font = "BudgetLabel",
        size = 17,
        weight = 1000,
        blursize = 0,
        scanlines = 0,
        antialias = true,
        underline = false,
        italic = false,
        strikeout = false,
        symbol = false,
        rotary = false,
        shadow = false,
        additive = false,
        outline = false
    })
end

if not VC.Fonts["VC_Regular_S"] then
    VC.Fonts["VC_Regular_S"] = true
    surface.CreateFont("VC_Regular_S", {
        font = "MenuLarge",
        size = 10,
        weight = 1000,
        blursize = 0,
        scanlines = 0,
        antialias = true,
        underline = false,
        italic = false,
        strikeout = false,
        symbol = false,
        rotary = false,
        shadow = false,
        additive = false,
        outline = false
    })
end

if not VC.Fonts["VC_Regular_Ms"] then
    VC.Fonts["VC_Regular_Ms"] = true
    surface.CreateFont("VC_Regular_Ms", {
        font = "MenuLarge",
        size = 13,
        weight = 1000,
        blursize = 0,
        scanlines = 0,
        antialias = true,
        underline = false,
        italic = false,
        strikeout = false,
        symbol = false,
        rotary = false,
        shadow = false,
        additive = false,
        outline = false
    })
end

if not VC.Fonts["VC_Cruise"] then
    VC.Fonts["VC_Cruise"] = true
    surface.CreateFont("VC_Cruise", {
        font = "MenuLarge",
        size = 26,
        weight = 1000,
        blursize = 0,
        scanlines = 0,
        antialias = true,
        underline = false,
        italic = false,
        strikeout = false,
        symbol = false,
        rotary = false,
        shadow = false,
        additive = false,
        outline = false
    })
end

if not VC.Fonts["VC_DEV_lower"] then
    VC.Fonts["VC_DEV_lower"] = true
    surface.CreateFont("VC_DEV_lower", {
        font = "MenuLarge",
        size = 13,
        weight = 1000,
        blursize = 0,
        scanlines = 0,
        antialias = true,
        underline = false,
        italic = false,
        strikeout = false,
        symbol = false,
        rotary = false,
        shadow = false,
        additive = false,
        outline = false
    })
end

local Font_Model_Name = "VC_Model_Name"
if not VC.Fonts[Font_Model_Name] then
    VC.Fonts[Font_Model_Name] = true
    surface.CreateFont(Font_Model_Name, {
        font = "MenuLarge",
        size = 18,
        weight = 1000,
        blursize = 0,
        scanlines = 0,
        antialias = true,
        underline = false,
        italic = false,
        strikeout = false,
        symbol = false,
        rotary = false,
        shadow = false,
        additive = false,
        outline = false
    })
end

function VC.Add_El_List(Px, Py, Sx, Sy)
    local List = vgui.Create("DPanelList")
    List:EnableVerticalScrollbar(true)
    List:SetPos(Px, Py)
    List:SetSize(Sx, Sy)
    local sbar = List.VBar
    sbar:SetWide(2)
    sbar.btnUp:SetWide(2)
    sbar.btnDown:SetWide(2)
    sbar.btnGrip:SetWide(2)
    function sbar:Paint(w, h)
    end

    function sbar.btnUp:Paint(w, h)
    end

    function sbar.btnDown:Paint(w, h)
    end

    sbar.btnGrip:NoClipping(true)
    function sbar.btnGrip:Paint(w, h)
        draw.RoundedBox(0, w - 2, -sbar.btnDown:GetTall(), 2, h + sbar.btnDown:GetTall() * 2, VC.Color.Blue)
    end
    return List
end

function VC.Add_El_Slider(Txt, Min, Max, Dec, Tip, CVar, Tbl, JustAdd)
    if not Tbl then Tbl = VC.Settings end
    local Sldr = vgui.Create("DNumSlider")
    Sldr.Paint = function(obj, Sx, Sy) draw.RoundedBox(0, Sx - 50, 5, 45, Sy - 10, Color(100, 200, 200, 100)) end
    Sldr.VC_Text = VC.Lng(Txt or "")
    Sldr:SetText(Sldr.VC_Text)
    Sldr:SetMin(Min or 0)
    Sldr:SetMax(Max or 1)
    Sldr.VC_Decimals = Dec or 2
    Sldr:SetDecimals(Dec or 2)
    Sldr:SetValue(math.Clamp(0, Min or 0, Max or 1))
    if Tip then
        Sldr:SetToolTip(Tip)
        Sldr.VC_Tip = Tip
    end

    if CVar then
        Sldr:SetValue(Tbl[CVar] or 0)
        Sldr.OnValueChanged = function(idx, val)
            if JustAdd then
                Tbl[CVar] = val
            else
                VC.SaveSetting(CVar, val)
            end
        end
    end
    return Sldr
end

function VC.Add_El_Checkbox(Txt, Tip, CVar, Tbl, JustAdd)
    if not Tbl then Tbl = VC.Settings end
    local CBox = vgui.Create("DCheckBoxLabel")
    CBox.VC_Text = Txt or ""
    CBox.VC_CheckBox = true
    CBox:SetText(VC.Lng(Txt or ""))
    CBox:SetValue(0)
    if Tip then
        CBox:SetToolTip(Tip)
        CBox.VC_Tip = Tip
    end

    if CVar then
        CBox:SetValue(Tbl[CVar] or 0)
        CBox.OnChange = function(idx, val)
            if JustAdd then
                Tbl[CVar] = val
            else
                VC.SaveSetting(CVar, val)
            end
        end
    end
    return CBox
end

function VC.Add_El_Line(Pnl, clr)
    local Line = vgui.Create("VC_Line", Pnl)
    if clr then Line:SetColor(clr) end
    Line:SetTall(10)
    if Pnl then Pnl:AddItem(Line) end
end

function VC.Add_El_Banner(Pnl, Text, Clr)
    local El = vgui.Create("VC_Banner", Pnl)
    El:SetText(VC.Lng(Text))
    El:SetColor(Clr)
    if Pnl then Pnl:AddItem(El) end
end

function VC.Add_El_Panel(Prt, Tbl, Sy, NDraw)
    VC.DevPanelDimentions = Tbl
    local Pnl = vgui.Create(NDraw and (NDraw == 2 and "VC_Panel_Draw_Whole" or "VC_Panel_NoDraw") or "VC_Panel")
    Pnl.VC_Parent = Prt
    local Sx, _ = Prt:GetSize()
    Pnl:SetSize(Sx, Sy)
    Prt:AddItem(Pnl)
    Pnl.VC_Panels.Main = Pnl
    return Pnl.VC_Panels
end

function VC.Add_El_SliderP(Pnl, Txt, Min, Max, Dec, Tip)
    local Sldr = VC.Add_El_Slider(Txt, Min, Max, Dec, Tip)
    if Pnl then Pnl:AddItem(Sldr) end
    return Sldr
end

function VC.Add_El_CheckboxP(Pnl, Txt, Tip)
    local CBox = VC.Add_El_Checkbox(Txt, Tip)
    if Pnl then Pnl:AddItem(CBox) end
    return CBox
end

function VC.DoTabClr(prt, pnl)
    pnl.Tab.Paint = function(obj, Sx, Sy)
        local active = prt:GetActiveTab() == pnl.Tab
        draw.RoundedBox(0, 0, 0, Sx, Sy - (active and 4 or 0), active and Color(64, 64, 64, 255) or Color(0, 0, 0, 200))
    end
end

function VC.DrawFadeRect(Px, Py, Sx, Sy, tclr, fade)
    if not tclr then tclr = VC.Color.Main end
    tclr = tclr and table.Copy(tclr)
    if not fade then fade = VC.FadeW end
    Sx = math.Round(Sx)
    Sy = math.Round(Sy)
    Px = math.Round(Px)
    Py = math.Round(Py)
    local Sy2 = math.Round(Sy / 2)
    draw.RoundedBox(0, math.Round(Px + fade / 2), Py, Sx - fade, Sy, tclr)
    surface.SetDrawColor(tclr)
    surface.SetMaterial(VC.Material.Fade)
    surface.DrawTexturedRectRotated(Px + Sx, Py + Sy2, fade, Sy, 0)
    surface.DrawTexturedRectRotated(Px, Py + Sy2, fade, Sy, 180)
end

local typedata = {
    check = {
        mat = VC.Material.Check,
        clr = VC.Color.Base
    },
    cross = {
        mat = VC.Material.Cross,
        clr = VC.Color.Base
    },
    info = {
        mat = VC.Material.Info,
        clr = VC.Color.Bsae
    }
}

net.Receive("VCPopup", function(dt) VCPopup(net.ReadString(), net.ReadString(), net.ReadInt(8)) end)
function VCPopup(text, ttype, length)
    if VC_DG_Popup then return end
    local instant = (length or 2) < 0.8
    local Pnl = vgui.Create("DFrame")
    Pnl:SetSize(50, 50)
    Pnl:SetTitle("")
    Pnl:SetPos(ScrW() / 2 - Pnl:GetWide() / 2, ScrH() / 2 - Pnl:GetTall() / 2)
    Pnl.VC_OriginalPos = {Pnl:GetPos()}
    Pnl:SetDraggable(false)
    Pnl:ShowCloseButton(false)
    Pnl:NoClipping(true)
    if not instant then
        Pnl:AlphaTo(0, 0, 0)
        Pnl:AlphaTo(255, 0.3, 0)
    end

    local TextPnl = VC.Add_El_List(0, 0, 50, 50)
    TextPnl:SetParent(Pnl)
    local text = VC.Lng(text)
    if not length then length = 2.5 end
    if not ttype then ttype = "info" end
    ttype = string.lower(ttype)
    local data = typedata[ttype]
    TextPnl.Paint = function(obj, Sx, Sy)
        draw.DrawText(text, Font, Sx, 12, data.clr, TEXT_ALIGN_RIGHT)
        Pnl.VC_TextSize = surface.GetTextSize(text) + 10
    end

    Pnl.VC_Start = instant and 0.6 or -0.5
    local tclr = table.Copy(VC.Color.Main)
    Pnl.Paint = function(obj, Sx, Sy)
        local FTm = Pnl.FrameRate or 15
        if FTm > 10 then FTm = 0.01 end
        Pnl.VC_Start = Pnl.VC_Start + 3.5 * FTm
        local Int = Pnl.VC_Start
        if Int < 0 then Int = 0 end
        if Int > 1 then Int = 1 end
        Int = VC.EaseInOut(Int) * (Pnl.VC_TextSize or 100)
        tclr.a = Int * 5
        if tclr.a > 220 then tclr.a = 220 end
        Pnl:SetPos(Pnl.VC_OriginalPos[1] - Int / 2, Pnl.VC_OriginalPos[2])
        Pnl:SetWide(50 + Int)
        TextPnl:SetPos(40, 0)
        TextPnl:SetWide(Int)
        VC.DrawFadeRect(0, 0, Sx, Sy)
        surface.SetDrawColor(255, 255, 255, 255)
        surface.SetMaterial(data.mat)
        surface.DrawTexturedRect(5, 5, 40, 40)
        if Pnl.VC_Start > length * 2 and not Pnl.VC_Removing then
            Pnl.VC_Removing = true
            Pnl:AlphaTo(0, 0.2, 0)
            timer.Simple(0.2, function() Pnl:Remove() end)
        end

        Pnl.FrameRate = VGUIFrameTime() - (Pnl.FrameTime or 0)
        Pnl.FrameTime = VGUIFrameTime()
    end

    if vgui.CursorVisible() then Pnl:MakePopup() end
end

VC.Menu_Info_Panel = true
VC.Menu_Update_Panel = nil
local function GetFirstAvailable(ttbl)
    local key = nil
    for k, v in pairs(ttbl) do
        if not v.Check or v.Check() then
            key = k
            break
        end
    end
    return key
end

function VC.DoOpenMenu(ply, cmd, arg)
    if VC_DG_Menu or arg[1] and ply:EntIndex() ~= tonumber(arg[1]) then return end
    if IsValid(VC.Menu_Panel) then
        VC.Menu_Panel:SetVisible(true)
        VC.Menu_Panel:AlphaTo(0, 0, 0)
        VC.Menu_Panel:AlphaTo(255, 0.2, 0)
        return
    end

    local Menu_Items_A = VC.Menu_Items_A or {}
    local Menu_Items_P = VC.Menu_Items_P or {}
    local CL_Body = VC.Color.Main
    local CL_Selection = table.Copy(VC.Color.Blue)
    CL_Selection.a = CL_Selection.a / 51
    local CL_Button = Color(0, 0, 0, 0)
    local CL_Button_Hov = table.Copy(VC.Color.Blue)
    CL_Button_Hov.a = CL_Button_Hov.a / 10
    local CL_Button_Sel_Hov = CL_Button_Hov
    local SideButtons, SizeX, SizeY = {}, 750, 550
    VC.Menu_Panel = vgui.Create("DFrame")
    if not VC.MenuPosX then VC.MenuPosX = ScrW() / 2 - SizeX / 2 end
    if not VC.MenuPosY then VC.MenuPosY = ScrH() / 2 - SizeY / 2 end
    VC.Menu_Panel:SetPos(VC.MenuPosX, VC.MenuPosY)
    VC.Menu_Panel:SetSize(SizeX, SizeY)
    VC.Menu_Panel:SetTitle("")
    VC.Menu_Panel:NoClipping(true)
    VC.Menu_Panel:MakePopup()
    VC.Menu_Panel.VC_Refresh = true
    VC.Menu_Panel.VC_Refresh_Side = true
    VC.Menu_Panel:AlphaTo(0, 0, 0)
    VC.Menu_Panel:AlphaTo(255, 0.2, 0)
    VC.Menu_Panel.Paint = function(obj, Sx, Sy)
        draw.RoundedBox(0, 0, 0, SizeX, SizeY, CL_Body)
        draw.DrawText("VCMod", Font_Logo, -15, -20, Color(255, 55, 0, 255), TEXT_ALIGN_LEFT)
        draw.RoundedBox(0, 135, 26, 611, SizeY - 30, CL_Selection)
    end

    local Button_personal = vgui.Create("DButton")
    Button_personal:SetParent(VC.Menu_Panel)
    Button_personal:SetPos(135, 3)
    Button_personal:SetSize(226, 20)
    Button_personal:SetText("")
    Button_personal:NoClipping(true)
    Button_personal.DoClick = function()
        if VC.Menu_AdminPanelSel or VC.Menu_Info_Panel or VC.Menu_Update_Panel then
            VC.Menu_Info_Panel = nil
            VC.Menu_Update_Panel = nil
            if not VC.Menu_AdminPanelSel_Side_P then VC.Menu_AdminPanelSel_Side_P = GetFirstAvailable(Menu_Items_P) end
            VC.Menu_Panel.VC_Refresh_Side = true
            VC.Menu_Panel.VC_Refresh = true
        end

        VC.Menu_AdminPanelSel = false
    end

    Button_personal.Paint = function(obj, Sx, Sy)
        local IsHovered = Button_personal:IsHovered()
        draw.RoundedBox(0, 0, 0, Sx, Sy + (VC.Menu_AdminPanelSel and 0 or 3), (VC.Menu_Info_Panel or VC.Menu_Update_Panel or VC.Menu_AdminPanelSel) and (IsHovered and CL_Button_Hov or CL_Button) or (IsHovered and CL_Button_Sel_Hov or CL_Selection))
        draw.DrawText(VC.Lng("Personal"), IsHovered and Font_Header_Focused or Font_Header, Sx / 2, 0, not (VC.Menu_Info_Panel or VC.Menu_Update_Panel or VC.Menu_AdminPanelSel) and VC.Color.Good or VC.Color.White, TEXT_ALIGN_CENTER)
    end

    local Button_admin = vgui.Create("DButton")
    Button_admin:SetParent(VC.Menu_Panel)
    Button_admin:SetPos(364, 3)
    Button_admin:SetSize(226, 20)
    Button_admin:SetText("")
    Button_admin:NoClipping(true)
    Button_admin.DoClick = function()
        if not VC.CanEditAdminSettings(LocalPlayer()) or not vcmod1 and not vcmod1_els then
            VCPopup("AccessRestricted", "cross")
            Button_personal.DoClick()
            return
        end

        if not VC.Menu_AdminPanelSel or VC.Menu_Update_Panel or VC.Menu_Info_Panel then
            VC.Menu_Info_Panel = nil
            VC.Menu_Update_Panel = nil
            if not VC.Menu_AdminPanelSel_Side_A then VC.Menu_AdminPanelSel_Side_A = GetFirstAvailable(Menu_Items_A) end
            VC.Menu_Panel.VC_Refresh_Side = true
            VC.Menu_Panel.VC_Refresh = true
        end

        VC.Menu_AdminPanelSel = true
    end

    Button_admin.Paint = function(obj, Sx, Sy)
        local IsHovered = Button_admin:IsHovered()
        draw.RoundedBox(0, 0, 0, Sx, Sy + (VC.Menu_AdminPanelSel and 3 or 0), (VC.Menu_Info_Panel or VC.Menu_Update_Panel or not VC.Menu_AdminPanelSel) and (IsHovered and CL_Button_Hov or CL_Button) or (IsHovered and CL_Button_Sel_Hov or CL_Selection))
        draw.DrawText(VC.Lng("Administrator"), IsHovered and Font_Header_Focused or Font_Header, Sx / 2, 0, not VC.Menu_Info_Panel and not VC.Menu_Update_Panel and VC.Menu_AdminPanelSel and VC.Color.Good or VC.Color.White, TEXT_ALIGN_CENTER)
    end

    local Tbl = {}
    local TblR = {}
    local Int = 1
    local Lng_CBox = vgui.Create("DComboBox", Pnl)
    Lng_CBox:SetParent(VC.Menu_Panel)
    Lng_CBox:SetPos(593, 3)
    Lng_CBox:SetSize(120, 20)
    for k, v in pairs(VC.Lng_T) do
        local code = string.lower(v.Language_Code)
        Lng_CBox:AddChoice(string.upper(code) .. "  " .. v.Name)
        Tbl[Int] = code
        TblR[code] = Int
        Int = Int + 1
    end

    Lng_CBox.OnSelect = function(idx, val)
        if Lng_CBox.Ignore then
            Lng_CBox.Ignore = nil
            return
        end

        if VC.Lng_Sel == Tbl[val] then return end
        if VC.Lng_Set then VC.Lng_Set(Tbl[val]) end
        VC.Menu_Panel:Close()
        VC.DoOpenMenu(ply, {}, {})
    end

    if VC.Lng_Sel and TblR[VC.Lng_Sel] then
        Lng_CBox:ChooseOptionID(TblR[VC.Lng_Sel])
    else
        Lng_CBox.Ignore = true
        Lng_CBox:ChooseOptionID(1)
    end

    Lng_CBox:SetColor(Color(255, 255, 255, 255))
    Lng_CBox.Paint = function(obj, Sx, Sy)
        local IsHovered = Lng_CBox:IsHovered()
        draw.RoundedBox(0, 0, 0, Sx, Sy, IsHovered and Color(35, 135, 100, 245) or Color(35, 100, 135, 245))
    end

    VC.Menu_SelectedPnl = nil
    local Btn = vgui.Create("DButton")
    Btn:SetParent(VC.Menu_Panel)
    Btn:SetPos(3, VC.Menu_Panel:GetTall() - 40)
    Btn:SetSize(129, 40)
    Btn:SetText("")
    Btn:NoClipping(true)
    Btn.DoClick = function()
        if not VC.Menu_Info_Panel then VC.Menu_Panel.VC_Refresh_Side = true end
        VC.Menu_Info_Panel = true
        VC.Menu_Update_Panel = nil
    end

    Btn.Paint = function(obj, Sx, Sy)
        local IsHovered = Btn:IsHovered()
        draw.RoundedBox(0, 0, 0, Sx + (VC.Menu_Info_Panel and 3 or 0), Sy - 4, VC.Menu_Info_Panel and (IsHovered and CL_Button_Sel_Hov or CL_Selection) or (IsHovered and CL_Button_Hov or CL_Button))
        draw.DrawText(VC.Lng("Info"), IsHovered and Font_SideBtn_Focused or Font_SideBtn, Sx / 2, Sy / 2 - 14, VC.Menu_Info_Panel and VC.Color.Good or VC.Color.White, TEXT_ALIGN_CENTER)
    end

    local Btn = vgui.Create("DButton")
    Btn:SetParent(VC.Menu_Panel)
    Btn:SetPos(3, VC.Menu_Panel:GetTall() - 40 * 2)
    Btn:SetSize(129, 40)
    Btn:SetText("")
    Btn:NoClipping(true)
    Btn.DoClick = function()
        if not VC.Menu_Update_Panel then VC.Menu_Panel.VC_Refresh_Side = true end
        VC.Menu_Update_Panel = true
        VC.Menu_Info_Panel = nil
    end

    Btn.Paint = function(obj, Sx, Sy)
        local IsHovered = Btn:IsHovered()
        draw.RoundedBox(0, 0, 0, Sx + (VC.Menu_Update_Panel and 3 or 0), Sy - 4, VC.Menu_Update_Panel and (IsHovered and CL_Button_Sel_Hov or CL_Selection) or (IsHovered and CL_Button_Hov or CL_Button))
        draw.DrawText(VC.Lng("Updates"), IsHovered and Font_SideBtn_Focused or Font_SideBtn, Sx / 2, Sy / 2 - 14, VC.Menu_Update_Panel and VC.Color.Good or VC.Color.White, TEXT_ALIGN_CENTER)
    end

    Button_personal.Think = function()
        if VC.Menu_Panel.VC_Refresh then
            for btnk, btnv in pairs(SideButtons) do
                if IsValid(btnv) then btnv:Remove() end
            end

            SideButtons = {}
            if VC.Menu_AdminPanelSel then
                local Int = 0
                for ItemK, Table in pairs(Menu_Items_A) do
                    if not Table.Check or Table.Check() then
                        local Name = Table[1]
                        if Name then
                            local Btn = vgui.Create("DButton")
                            Btn:SetParent(VC.Menu_Panel)
                            Btn:SetPos(3, 26 + Int)
                            Btn:SetSize(129, (Table[3] or 45) - (Table[4] or 5))
                            Btn:SetText("")
                            Btn:NoClipping(true)
                            Btn.DoClick = function()
                                if VC.Menu_AdminPanelSel_Side_A ~= ItemK or VC.Menu_Info_Panel or VC.Menu_Update_Panel then VC.Menu_Panel.VC_Refresh_Side = true end
                                VC.Menu_AdminPanelSel_Side_A = ItemK
                                VC.Menu_Info_Panel = nil
                                VC.Menu_Update_Panel = nil
                            end

                            Btn.Paint = function(obj, Sx, Sy)
                                local IsHovered = Btn:IsHovered()
                                local On = VC.Menu_AdminPanelSel_Side_A == ItemK and not VC.Menu_Info_Panel and not VC.Menu_Update_Panel
                                draw.RoundedBox(0, 0, 0, Sx + (On and 3 or 0), Sy, On and (IsHovered and CL_Button_Sel_Hov or CL_Selection) or (IsHovered and CL_Button_Hov or CL_Button))
                                draw.DrawText(VC.Lng(Name), IsHovered and Font_SideBtn_Focused or Font_SideBtn, Sx / 2, Sy / 2 - 11, On and VC.Color.Good or VC.Color.White, TEXT_ALIGN_CENTER)
                            end

                            SideButtons[Name] = Btn
                        end

                        Int = Int + (Table[3] or 43)
                    end
                end
            else
                local Int = 0
                for ItemK, Table in pairs(Menu_Items_P) do
                    if not Table.Check or Table.Check() then
                        local Name = Table[1]
                        if Name then
                            local Btn = vgui.Create("DButton")
                            Btn:SetParent(VC.Menu_Panel)
                            Btn:SetPos(3, 26 + Int)
                            Btn:SetSize(129, (Table[3] or 45) - (Table[4] or 5))
                            Btn:SetText("")
                            Btn:NoClipping(true)
                            Btn.DoClick = function()
                                if VC.Menu_AdminPanelSel_Side_P ~= ItemK or VC.Menu_Info_Panel or VC.Menu_Update_Panel then VC.Menu_Panel.VC_Refresh_Side = true end
                                VC.Menu_AdminPanelSel_Side_P = ItemK
                                VC.Menu_Info_Panel = nil
                                VC.Menu_Update_Panel = nil
                            end

                            Btn.Paint = function(obj, Sx, Sy)
                                local IsHovered = Btn:IsHovered()
                                local On = VC.Menu_AdminPanelSel_Side_P == ItemK and not VC.Menu_Info_Panel and not VC.Menu_Update_Panel
                                draw.RoundedBox(0, 0, 0, Sx + (On and 3 or 0), Sy, On and (IsHovered and CL_Button_Sel_Hov or CL_Selection) or (IsHovered and CL_Button_Hov or CL_Button))
                                draw.DrawText(VC.Lng(Name), IsHovered and Font_SideBtn_Focused or Font_SideBtn, Sx / 2, Sy / 2 - 11, On and VC.Color.Good or VC.Color.White, TEXT_ALIGN_CENTER)
                            end

                            SideButtons[Name] = Btn
                        end

                        Int = Int + (Table[3] or 43)
                    end
                end
            end

            VC.Menu_Panel.VC_Refresh = nil
        end

        if VC.Menu_Panel.VC_Refresh_Panel then
            if VC.Menu_SelectedPnl then
                VC.Menu_SelectedPnl:Remove()
                VC.Menu_SelectedPnl = nil
            end

            local function HandlePanel(Table)
                if Table then
                    local Pnl = VC.Add_El_List(138, 29, 605, SizeY - 36)
                    Pnl:SetParent(VC.Menu_Panel)
                    Table.Panel = Pnl
                    VC.Menu_SelectedPnl = Pnl
                    Table[2](Pnl)
                end
            end

            HandlePanel(VC.Menu_Info_Panel and VC.Menu_Info_Panel_Build or VC.Menu_Update_Panel and VC.Menu_Update_Panel_Build or VC.Menu_AdminPanelSel and Menu_Items_A[VC.Menu_AdminPanelSel_Side_A] or VC.Menu_AdminPanelSel_Side_P and Menu_Items_P[VC.Menu_AdminPanelSel_Side_P])
            VC.Menu_Panel.VC_Refresh_Panel = nil
        end

        if VC.Menu_Panel.VC_Refresh_Side then
            if VC.Menu_SelectedPnl then
                VC.Menu_SelectedPnl:SetVisible(false)
                VC.Menu_SelectedPnl = nil
            end

            local function HandlePanel(Table)
                if Table then
                    if IsValid(Table.Panel) then
                        Table.Panel:SetVisible(true)
                        Table.Panel:AlphaTo(0, 0, 0)
                        Table.Panel:AlphaTo(255, 0.2, 0)
                        VC.Menu_SelectedPnl = Table.Panel
                    else
                        local Pnl = VC.Add_El_List(138, 29, 605, SizeY - 36)
                        Pnl:AlphaTo(0, 0, 0)
                        Pnl:AlphaTo(255, 0.2, 0)
                        Pnl:SetParent(VC.Menu_Panel)
                        Table.Panel = Pnl
                        VC.Menu_SelectedPnl = Pnl
                        Table[2](Pnl)
                    end
                end
            end

            HandlePanel(VC.Menu_Info_Panel and VC.Menu_Info_Panel_Build or VC.Menu_Update_Panel and VC.Menu_Update_Panel_Build or VC.Menu_AdminPanelSel and Menu_Items_A[VC.Menu_AdminPanelSel_Side_A] or VC.Menu_AdminPanelSel_Side_P and Menu_Items_P[VC.Menu_AdminPanelSel_Side_P])
            VC.Menu_Panel.VC_Refresh_Side = nil
        end
    end
end

local cmds = {"vc_open_menu", "vc_menu", "vcmod"}
for k, v in pairs(cmds) do
    concommand.Add(v, function(...) VC.DoOpenMenu(LocalPlayer(), {}, {}) end)
end

concommand.Add("vc_menu_null", function() end)
if not VC.Lng_T then
    VC.Lng_T = {}
    VC.Lng_T_Rev = {}
end

local Lng = {}
Lng.Name = {"English", 'Specify this in your native language. Example: "Lietuvių", not "Lithuanian".'}
Lng.Language_Code = {"en", "Country code"}
Lng.Translated_By_Name = {"freemmaann", 'Your name.'}
Lng.Translated_By_Link = {"http://steamcommunity.com//id/freemmaann/", "Your steam link."}
Lng.Translated_Date = {"2016/05/26", "Date of which this was updated."}
Lng.BigThankYouToAllWhoHelpedTranslate = {"Big thank you to all who helped translate VCMod", ''}
Lng.WishToHelpTranslate = {"Wish to help translate? Click here.", ''}
Lng.Outdated = {"Outdated", ''}
Lng.Good = {"Good", ''}
Lng.TheName = {"Name", ''}
Lng.Overrides = {"Overrides", ''}
Lng.Tire = {"Tire", ''}
Lng["Too soon"] = {"Too soon!", ''}
Lng["Please wait"] = {"Please wait!", ''}
Lng["Changed"] = {"Changed", ''}
Lng.Light = {"Light", ''}
Lng.Revision = {"Revision", ''}
Lng.Compatibility = {"Compatibility", ''}
Lng.Use = {"Use", ''}
Lng.Disabled = {"Disabled", '"Test drive is diabled."'}
Lng.Overwritten = {"Overwritten", ''}
Lng.Status = {"Status", ''}
Lng.Override_Controls = {"Override controls", ''}
Lng.Date = {"Date", ''}
Lng.Effects = {"Effects", ''}
Lng.Logs = {"Logs", 'Logging events of VCMod.'}
Lng.Return = {"Return", ''}
Lng.Locked = {"Vehicle locked.", 'Vehicle has been locked.'}
Lng.UnLocked = {"Vehicle unlocked.", 'Vehicle has been unlocked.'}
Lng.FuelLidPosition = {'Fuel lid position', ''}
Lng.Chat = {'To adjust options (car lights, view) type "!vcmod" in chat.', 'You seen this menu in chat when entering a vehicle.'}
Lng.Broken = {"This vehicle is broken, it needs to be repaired.", 'You see this when entering a broken vehicle.'}
Lng.AutoEnter = {"Automatically enter", ''}
Lng.LimitReturnDistance = {"Limit return distance", ''}
Lng.AutoReturnOnDisconnect = {"Automatically return vehicles on disconnect", ''}
Lng.Trl_Atch = {"Trailer attached.", 'When attaching a trailer. "This trailer has been attached."'}
Lng.Trl_Detch = {"Trailer detached.", 'When detaching a trailer. "This trailer has been detached."'}
Lng.ELS_TuningIntoPoliceC = {"Tuning into police chatter", 'When entering an emergency vehicle displayed in chat.'}
Lng.ELS_NoPoliceRCFound = {"No police chatter found.", 'When failed to find a police chatter stream when entering an emergency vehicle.'}
Lng.All = {"All", '"All vehicles have been spawned."'}
Lng.Apply = {"Apply", ''}
Lng.Added = {"Added", 'Added something to something.'}
Lng.Done = {"Done", 'Done doing something.'}
Lng.Updates = {"Updates", ''}
Lng.UpdatesAreAppliedAutomaticallyAfterMapRestart = {"Updates are applied automatically after map restart.", ''}
Lng.UnknownVehicle = {"Unknown Vehicle", 'When entering a vehicle.'}
Lng.Close = {"Close", '"To close this menu."'}
Lng.LoadFromFile = {"Load from file", ''}
Lng.Engine = {"Engine", ''}
Lng.Available = {"Available", '"These vehicles are available to be purchased."'}
Lng.JobRelated = {"Job related", ''}
Lng.Buy = {"Buy", '"You can buy this vehicle."'}
Lng.Sell = {"Sell", 'You can sell this vehicle.'}
Lng.Paintjob = {"Paint job", 'Vehicles paint job, in other words, its skin.'}
Lng.Spawn = {"Spawn", '"I am able to spawn thing vehicle."'}
Lng.Purchase = {"Purchase", '"You are able to purchase this vehicle."'}
Lng.Purchased = {"Purchased", '"This vehicle has been purchased."'}
Lng.TestDrive = {"Test drive", '"You can test drive this vehicle."'}
Lng.Allowed = {"Allowed", '"Was allowed to do something."'}
Lng.NotAllowedRemoveOtherVehicles = {"Not allowed, remove other spawned vehicles.", '""'}
Lng.AccessRestricted = {"Access restricted.", '"Your access has been restricted. In other words, denied."'}
Lng.CantBeUsedBy = {"Can't be used by", '"Used in car dealer when someone is trying to use something they dont have access to."'}
Lng.CantBeSpawnedBy = {"Can't be spawned by", '"Used in car dealer when someone is trying to spawn something they dont have access to."'}
Lng.OriginalPrice = {"Original price", '"Vehicles original price."'}
Lng.RefundPercentage = {"Refund percentage", 'The percentage you receive when selling the vehicle from the original price.'}
Lng.SellingPrice = {"Selling price", 'For what price it will be sold.'}
Lng.Free = {"Free", '"This addon is free."'}
Lng.Humming = {"Humming", 'Humming, as in singing quitly.'}
Lng.Persistent = {"Persistent", 'Constantly staying on or not wanting to change.'}
Lng.TowingNotAllowTooFar = {"Not allowed to tow if too far", 'Car can not be towed back if its too far away.'}
Lng.TooFar = {"Too far", 'Something is not close enough.'}
Lng.Blurred = {"Blurred", 'Blurry, smudged.'}
Lng.CoreOptions = {"Core options", ''}
Lng.RM_Settings = {"Repair Man options", ''}
Lng.HoldUseToPickup = {"Hold [USE] to pick up", ''}
Lng.YouAlreadyHaveSpikestrip = {"You already have spike strip", ''}
Lng.RepairMan = {"Repair Man", ''}
Lng.NoneAdmin = {"None administrator", ''}
Lng.AdminControlsCanBeAlteredBy = {"Administrator controls can be altered by:", ''}
Lng.RMPlaced = {"Repair man placed", ''}
Lng.Rays = {"NoneFound", '"None found."'}
Lng.Rays = {"Rays", '"These light rays are blinding."'}
Lng.Rotate = {"Rotate", '"Rotate this object around."'}
Lng.customisation = {"customization", 'To alter, change something, customize.'}
Lng.Sold = {"Sold", '"This vehicle has been sold."'}
Lng.Tab = {"Tab", 'Same as the "Vehicle tab" or "NPC tab" you see in the Q menu.'}
Lng.Previous = {"Previous", 'A thing before that. "Previous vehicle."'}
Lng.Next = {"Next", 'A thing after that. "Next vehicle."'}
Lng.RepairingVehicleAdmin = {"Admin: repairing vehicle", ''}
Lng.Active = {"Active", ''}
Lng.Idle = {"Idle", ''}
Lng.TouchBrokenCarPiece = {"Touch broken car piece", ''}
Lng.Pumping = {"Pumping", ''}
Lng.Fuel_lidNeedUnlocked = {"Has to be unlocked to refuel.", ''}
Lng.FuelTaken = {"Fuel taken", ''}
Lng.DroppedFuel = {"Fuel dropped", ''}
Lng.Wheels = {"Wheels", ''}
Lng.critical = {"critical", ''}
Lng.destroyed = {"destroyed", ''}
Lng.damaged = {"damaged", ''}
Lng.Repairs = {"Repairs", ''}
Lng.DamagedParts = {"Damaged parts", ''}
Lng.EngineNew = {"Engine new", ''}
Lng.SelectVehicle = {"Select a vehicle", ''}
Lng.YourVehiclesRepairsComplete = {"Your vehicle repairs are complete.", ''}
Lng.severelydamaged = {"severely damaged", ''}
Lng.YourVehiclesRepairsFailed = {"Your vehicle repair have failed", ''}
Lng.sec = {"sec", ''}
Lng.RepairSpeedMult = {"Repair speed multiplier", ''}
Lng.NeedVehiclePart = {"Need a vehicle part", ''}
Lng["Front left"] = {"Front left", 'Keep this etremely short.'}
Lng["Front right"] = {"Front right", 'Keep this etremely short.'}
Lng["Rear left"] = {"Rear left", 'Keep this etremely short.'}
Lng["Rear right"] = {"Rear right", 'Keep this etremely short.'}
Lng.Repairing = {"Repairing", ''}
Lng.Prices = {"Prices", ''}
Lng.PartsCost = {"Parts cost", ''}
Lng.RepairCost = {"Repair cost", ''}
Lng.RepairTime = {"Repair time", ''}
Lng.Total = {"Total", ''}
Lng.OutOfFuel = {"Out of fuel", ''}
Lng.FuelRemaining = {"Fuel remaining", ''}
Lng.Function = {"Function", ''}
Lng.TestDriveEnded = {"Test drive ended.", '"Test drive has ended."'}
Lng.EndTestDrive = {"End test drive", 'Button text. "To end a test drive."'}
Lng.Error = {"Something went wrong.", ""}
Lng.Respawn = {"Respawn", ""}
Lng.Create = {"Create", ""}
Lng.CantRemoveThisWay = {"Can't remove this way.", ""}
Lng.Price = {"Price", ""}
Lng.Add = {"Add", ""}
Lng.OnlyAllowOneCarToBeSpawnedPerCarDealerPerUser = {"Only allow one car to be spawned per car dealer per user", ""}
Lng.StoreInformation = {"Store information", "This car dealer will star information like fuel and health state of the vehicle."}
Lng["Unlock vehicle on use by the spawner"] = {"Unlock vehicle on use by the spawner", ""}
Lng["Unlock vehicle on use by person who locked from inside"] = {"Unlock vehicle on use by the person who locked from inside", ""}
Lng.TextViewDistance = {"Text view distance", ""}
Lng.DetectDistance = {"Detect distance", ""}
Lng.TowingCost = {"Towing cost", ""}
Lng.RefundPricePerc = {"Refund price %", ""}
Lng.VehiclesCanBeRemovedByTool = {"Vehicles can be removed by tool", ""}
Lng.CD_Cant_Afford = {"You can not afford this.", ''}
Lng.ReachedMaxCapacity = {"Reached maximum capacity", ''}
Lng.CD_Loading = {"Keep calm, car dealer is loading.", ''}
Lng.VehicleBought = {"Vehicle has been bought.", ''}
Lng.ParkingLotsTaken = {"All parking lots taken.", ''}
Lng.NoVehiclesFound = {"No vehicles found", ''}
Lng.VehicleSpawned = {"Vehicle has been spawned", ''}
Lng.AreYouSureYouWantToSell = {"Are you sure you want to sell", ''}
Lng.TestDriveTimeLeft = {"Test drive time left", ''}
Lng.SpawnedVehicle = {"Spawned vehicle", ''}
Lng.FirstReturnTheVehicle = {"You have to return the vehicle first.", ''}
Lng.VehicleReturned = {"Vehicle returned.", ''}
Lng.VehicleTowedFor = {"Vehicle towed for", ''}
Lng.YouHaveToBeAdmin = {"You have to be an administrator.", ''}
Lng.CDPlaced = {'Car dealer placed', ''}
Lng.Deleted = {'Successfully deleted', ''}
Lng.CDsPlaced = {"All car dealer's respawned.", ''}
Lng.CDSpawnedIncorrectly = {"Car dealer has been spawned incorrectly.", ''}
Lng.NoCloseVehicles = {"No nearby vehicles available.", ''}
Lng.PosChanged = {"Positions changed.", ''}
Lng.TouchCarWithThis = {"Touch a car using this for it to take affect.", ''}
Lng.Info = {"Info", '"Information"'}
Lng.Menu = {"Menu", '"Open this menu."'}
Lng.Author = {"Author", ''}
Lng.NoCDFound = {"No car dealer found", ''}
Lng.Language = {"Language", ''}
Lng.Personal = {"Personal", ''}
Lng.Administrator = {"Administrator", ''}
Lng.SuperAdmin = {"Super administrator", ''}
Lng.Options = {"Options", ''}
Lng.ELSOptions = {"ELS options", ''}
Lng.Main = {"Main", '"Main lights."'}
Lng.Controls = {"Controls", ''}
Lng.Accept = {"Accept", ''}
Lng.Cancel = {"Cancel", ''}
Lng.HUD = {"HUD", ''}
Lng.CruisingAt = {"Cruising at", ''}
Lng.Damage_Repair_GiveWrenchToDriver = {"Give repair wrench to driver", ''}
Lng.Damage_Repair_GiveWrenchToCarPartUser = {"Give repair wrench on vehicle part use", ''}
Lng.Damage_Repair_NeedPart = {"Repairing with wrench needs vehicle part", ''}
Lng.View = {"View", ''}
Lng.Advanced = {"Advanced", ''}
Lng.Lerp = {"Lerp", ''}
Lng.ThirdPView = {"Radio", ''}
Lng.FlatTire = {"Flat tire", ''}
Lng.Radio = {"Radio", ''}
Lng.Multiplier = {"Multiplier", 'A thing that multiplies things.'}
Lng.OptOnly_You = {"These options will only affect you", ''}
Lng.OptOnly_Admin = {"These settings can only be changed by an administrator", ''}
Lng.OptOnly_SuperAdmin = {"These settings can only be changed by a super administrator", ''}
Lng.CD_Settings = {"Car dealer", ''}
Lng.Normal = {"Normal", ''}
Lng.Skidding = {"Skidding", ''}
Lng.Sparks = {"Sparks", ''}
Lng.TireTracks = {"Tire tracks", ''}
Lng.Height = {"Height", ''}
Lng.PerformanceImpact = {"Performance impact", ''}
Lng.Detail = {"Detail", ''}
Lng.SpeedTilt = {"Speed tilt", ''}
Lng.FadeOutTime = {"Fade out time", 'Time after which things start to become dimmer and dimmer.'}
Lng.FadeOutDistance = {"Fade out distance", 'Distance at which things start to become dimmer and dimmer.'}
Lng.BendPassengerLegs = {"Bend passenger legs", ''}
Lng.OverrideDriverAnims = {"Override driver animations, position", ''}
Lng.Reset = {"Reset", ''}
Lng.Save = {"Save", ''}
Lng.Load = {"Load", ''}
Lng.Map = {"Map", ''}
Lng.Volume = {"Volume", 'How load a thing is.'}
Lng.LockFromInside = {"Lock vehicle from inside", ''}
Lng.ThirdPersonViewSeeThroughProps = {"Third person view allows players to see through props", ''}
Lng.LimitDriveByView = {"Limit drive by view", 'While in drive by if it should limite the player view rotation.'}
Lng.Distance = {"Distance", ''}
Lng.CantSwitchFromThisSeat = {"Can't change seats from this seat.", ''}
Lng.CantSwitchToFront = {"You can not switch to front.", ''}
Lng.CantExitWhileLocked = {"Can't exit while vehicle is locked.", ''}
Lng.ExitPointNotFound = {"Exit blocked!", 'Ran when exiting the vehicle, no points found'}
Lng.None = {"None", ''}
Lng.Loading = {"Loading...", ''}
Lng.EnterKey = {"Enter key", '"Please anter a key."'}
Lng.Enabled_Cl = {"Enabled clientside", ''}
Lng.Enabled_Sv = {"Enabled serverside", ''}
Lng.Lights = {"Lights", ''}
Lng.Health = {"Health", ''}
Lng.Sound = {"Sound", ''}
Lng.Other = {"Other", ''}
Lng.CreatedBy = {"Created by", ''}
Lng.Enabled = {"Enabled", ''}
Lng.OffTime = {"Off time", 'Time in which it will be off.'}
Lng.Time = {"Time", ''}
Lng.DistMultiplier = {"Distance multiplier", ''}
Lng.ControlsReset = {"Controls reset.", ''}
Lng.SettingsSaved = {"Settings saved.", ''}
Lng.SettingsReset = {"Settings reset.", ''}
Lng.LoadedSettingsFromServer = {"Settings loaded from server.", ''}
Lng.InteriorIndicators = {"Interior indicators", 'Indicators that are inside of a vehicle.'}
Lng.ExtraGlow = {"Extra glow", ''}
Lng.ManualSiren = {"Manual siren", ''}
Lng.ELSSirenSwitch = {"ELS siren switch", ''}
Lng.ELSSirenToggle = {"ELS siren toggle", ''}
Lng.ELSLightsSwitch = {"ELS lights switch", ''}
Lng.ELSLightsToggle = {"ELS lights toggle", ''}
Lng.VCModMainEnabled = {"VCMod main enabled", ''}
Lng.VCModELSEnabled = {"VCMod ELS enabled", ''}
Lng.ELSLightsEnabled = {"ELS lights enabled", ''}
Lng.AutoDisableELSLights = {"Auto disable ELS lights", ''}
Lng.OffOnExit = {"Off on exit", ''}
Lng.Siren = {"Siren", ''}
Lng.AutoDisableELSSounds = {"Auto disable ELS sounds", ''}
Lng.Manual = {"Manual", ''}
Lng.AdvancedDamage = {"Advanced damage", ''}
Lng.Damage_Lights = {"Can damage lights", ''}
Lng.Damage_Wheels = {"Can damage tires", ''}
Lng.Damage_Wheels_ELSOff = {"ELS vehicles have bullet-proof tires", ''}
Lng.Damage_Exhaust = {"Can damage exhaust", ''}
Lng.Damage_Exhaust_Backfire = {"Can backfire", ''}
Lng.Damage_FuelLid = {"Can damage fuel lid", ''}
Lng.Indication = {"Indication", 'Things that indicate something, example: "Popup headlights".'}
Lng.Damage_Custom_Sounds = {"Custom collision sounds", ''}
Lng.SpikeStrip_auto_give_els = {"Spike strip auto given in ELS vehicles", ''}
Lng.Spikestrip = {"Spike strip", ''}
Lng.SpikeStrip_auto_remove_death = {"Spike strip auto remove when player dies", ''}
Lng.CanDamagePlayersNPCs = {"Can damage players/NPCs", ''}
Lng.IgnoreEmergencyVehicles = {"Ignore emergency vehicles", ''}
Lng.Explode = {"Explode", ''}
Lng.Off = {"Off", ''}
Lng.Light_Damage = {"Light damaged", ''}
Lng.Light_Damaged = {"Light damaged, use sparks", 'The sparks when a light is damaged but is attempted to be used.'}
Lng.Exhaust_Damage = {"Exhaust damaged", ''}
Lng.Wheel_Damage = {"Tire damaged", ''}
Lng.Damage_Sparks_Damage = {"Collision sparks", ''}
Lng.Explosion_Custom = {"Custom explosion", ''}
Lng["Help translate"] = {"Help translate"}
Lng.Exhaust_Custom = {"Custom exhaust", ''}
Lng.Brake_Effects = {"Brake/sliding - effects, tire tracks, sounds", ''}
Lng.On = {"On", ''}
Lng.Bullhorn = {"Bullhorn", ''}
Lng.PoliceChatterEnabled = {"Police chatter enabled", ''}
Lng.PoliceChatter = {"Police chatter", ''}
Lng.PoliceChatter_Info = {"Police chatter is a real time feed of official police chatter VIA radio.", ''}
Lng.SelectedRadioChatter = {"Selected radio chatter channel", ''}
Lng.ReduceDamageToEmergencyVehicles = {"Reduce damage to emergency vehicles", ''}
Lng.Repair = {"Repair", ''}
Lng.YouAreUsingVCMod = {"You are using VCMod", ''}
Lng.ServerIsUsingVCMod = {"This server is using VCMod", ''}
Lng.Info_EverThought = {"Ever thought that Garrysmod's vehicles are lacking realism?", ''}
Lng["Search"] = {"Search"}
Lng["Core"] = {"Core"}
Lng["Home"] = {"Home"}
Lng["Changelog"] = {"Changelog"}
Lng.Info_VCModIsDesigned = {"VCMod is designed to provide Garrysmod's vehicle with full assortment of features.", ''}
Lng.Info_VCModHasFollowingAddons = {"VCMod has the following addons:", ''}
Lng.WhyISellVCMod = {"Why VCMod is for sale", ''}
Lng.VisDist = {"Visibility distance", ''}
Lng.Warmth = {"Warmth", ''}
Lng.Lines = {"Lines", ''}
Lng.Glow = {"Glow", ''}
Lng.DynamicLights = {"Dynamic lights", ''}
Lng.ThirdPersonView = {"Third person view", ''}
Lng.DynamicView = {"Dynamic view", ''}
Lng.AutoFocus = {"Auto focus", ''}
Lng.Reverse = {"Reverse", ''}
Lng.VectorStiffness = {"Vector stiffness %", ''}
Lng.AngleStiffness = {"Angle stiffness %", ''}
Lng.TruckView = {"Truck connected view", ''}
Lng.HoldDuration = {"Hold duration", ''}
Lng.HoldKey = {"Hold key", ''}
Lng.SwitchSeats = {"Switch seats:", ''}
Lng.KickPeopleOut = {"Kick people out:", ''}
Lng.OpenMenu = {"Open menu", ''}
Lng.Body = {"Body", ''}
Lng.Steering = {"Steering", ''}
Lng.FrontAxle = {"Front Axle", ''}
Lng.RearAxle = {"Rear Axle", ''}
Lng.Mouse = {"Mouse", ''}
Lng.KeyboardInput = {"Keyboard input", ''}
Lng.MouseInput = {"Mouse input", ''}
Lng.RunningLights = {"Running lights", ''}
Lng.LightsSwitch = {"Swich lights", ''}
Lng.HeadLights = {"Head lights", ''}
Lng.FogLights = {"Fog lights", ''}
Lng.Handling = {"Handling", ''}
Lng.LowHighBeamToggle = {"Low/High beams", ''}
Lng.LowHigh = {"Low/High beam toggle", ''}
Lng.LowBeams = {"Low beams", ''}
Lng.HighBeams = {"High beams", ''}
Lng.HighBeamsFlash = {"High beams flash", ''}
Lng.HazardLights = {"Hazard lights", ''}
Lng.BlinkerLeft = {"Blinker left", ''}
Lng.BlinkerRight = {"Blinker right", ''}
Lng.Exhaust_Effect_BackFireHealthLow = {"Exhaust backfires if health is low", ''}
Lng.DriveBy_NoSwitch = {"No switching weapons while in drive by mode", ''}
Lng.Horn = {"Horn", ''}
Lng.Cruise = {"Cruise", ''}
Lng.LockUnlock = {"Lock/Unlock", ''}
Lng.LookBehind = {"Look behind", ''}
Lng.DetachTrailer = {"Detach trailer", ''}
Lng.Wipers = {"Wipers", ''}
Lng.Weaponry = {"Weaponry", ''}
Lng.AuxiliaryLights = {"Auxiliary Lights", ''}
Lng.Effect3D = {"3D effect", ''}
Lng.PickupDistance = {"Pickup text draw distance", ''}
Lng.HUDHeight = {"Side HUD height %", ''}
Lng.Icons = {"Icons", ''}
Lng.Drain_Fuel = {"Drain fuel", ''}
Lng.HUD_MPH = {"mi/h instead of km/h", ''}
Lng.ELS_Siren = {"ELS siren", ''}
Lng.CanShootPlayersInSeats = {"Can shoot players inside vehicles", ''}
Lng.CanShootPlayersInSeatsOverrideDefault = {"Can shoot players inside vehicles, override default", ''}
Lng.HitLikelinessMult = {"Hit likeliness mult", ''}
Lng.Empty = {"Empty", ''}
Lng.hour = {"hour", 'As in 20 liters / hour'}
Lng.g_gallons = {"gal", 'Short of the word Gallons'}
Lng.g_liters = {"l", 'Short of the word Liters'}
Lng.Parts = {"Parts", ''}
Lng.ForceFirstPersonView = {"Force first person view", ''}
Lng.Update = {"Update", ''}
Lng.ELS_Lights = {"ELS lights", ''}
Lng.HandbrakeLights = {"Handbrake lights", ''}
Lng.EnterDriveByMode = {"Shoot out of the window", ''}
Lng.DriveBy = {"Drive By mode for passengers", ''}
Lng.ExitDriveByMode = {"Stop shooting out of the window", ''}
Lng.Damage_Ignite = {"Ignite vehicle after explosion", ''}
Lng.MinimumSpeed = {"Minimum speed", ''}
Lng.Minor = {"Minor", ''}
Lng.Currency = {"Currency", ''}
Lng.Everything = {"Everything", ''}
Lng.InteriorLights = {"Interior lights", ''}
Lng.CanNotEquipThisWeapon = {"Can not equip this weapon", ''}
Lng.BlinkersOffExit = {"Blinkers (turn signals) off on exit", ''}
Lng.Imperialinsteadofmetric = {"Use imperial system instead of metric", ''}
Lng.DamageEnabled = {"Damage enabled", ''}
Lng.StartHealthMultiplier = {"Start health multiplier", ''}
Lng.PhysicalDamage = {"Physical damage", ''}
Lng.PhysicalDamageWPhysGun = {"Physical damage while using phys gun", ''}
Lng["Player damage multiplier"] = {"Player damage multiplier", ''}
Lng["Disable default driver physical damage"] = {"Disable default driver physical damage", ''}
Lng.OnlyWithPassengers = {"Only with passengers", ''}
Lng.HealthRepairBulletDamage = {"Attempt to repair default source bullet damage", ''}
Lng.FireDuration = {"Fire duration", ''}
Lng.SmokeDuration = {"Smoke duration", ''}
Lng.RemoveDestroyedVehicle = {"Remove destroyed vehicle", ''}
Lng.CanEnterIfDestroyed = {"Can enter if destroyed", ''}
Lng.CarsCantRunOverPlayers = {"Cars can't damage players", ''}
Lng.DoorSounds = {"Door sounds", ''}
Lng.TruckRevBeep = {"Truck reverse sound", ''}
Lng.OverrideDefaultSteeringLockOnExit = {"Override default steering lock on exit", ''}
Lng.OverrideDefaultBrakesOnExit = {"Override default brakes on exit", ''}
Lng.MatchPlayerSpeedExit = {"Match player speed on exit", ''}
Lng.NoCollidePlyOnExit = {"No collide players with car on exit", ''}
Lng.PlayersGetDamagedOnExit = {"Players get damaged on exit", ''}
Lng.kWh = {"kWh", 'Kilo what hour'}
Lng.Fuel = {"Fuel", ''}
Lng.Exhaust = {"Exhaust", ''}
Lng.PassengerSeats = {"Passenger seats", ''}
Lng.Diesel = {"Diesel", 'Fuel type.'}
Lng.Fuel_Cons_Mult = {"Fuel consumption multiplier", ''}
Lng.Refuel_Mult_Station = {"Refueling speed multiplier using station", ''}
Lng.Refuel_MaxCapacity = {"Refueling station maximum capacity", ''}
Lng.Fuel_StartMult = {"Initial amount multiplier", ''}
Lng.Refuel_Mult_Hand = {"Refueling speed multiplier using hands", ''}
Lng.Fuel_Pickup_Pickup = {"Can pick up fuel canisters", ''}
Lng.Fuel_Pickup_Explode = {"Fuel canisters can explode", ''}
Lng.Fuel_Pickup_Touch = {"Fuel canisters can refuel by touch", ''}
Lng.Fuel_Pickup_Touch_Elec = {"Fuel canisters can refuel by touch (Electricity)", ''}
Lng.Fuel_Pickups_Beside_Stations = {"Place fuel canisters besides fuel stations", ''}
Lng.Petrol = {"Petrol", 'Fuel type.'}
Lng.Electricity = {"Electricity", ''}
Lng.Elec = {"Elec", 'Electricity shortened.'}
Lng.Pickup_Repair = {"Vehicle repair :val:", 'This is used in pickup entities.\n\n:val: will be replaced by the percentage.'}
Lng.Pickup_Fuel = {"Vehicle fuel: ", 'This is used in pickup entities.'}
Lng.Pickup_PartKit = {"Part kit", 'Box of parts (entity).'}
Lng.Pickup_Carpart = {"Vehicle part: ", 'This is used in pickup entities.'}
Lng.liters = {"liters", 'Volume, as in, 20 liters of water.'}
Lng.gallons = {"gallons", 'Volume, as in, 20 gallons of water.'}
Lng.AbleToSwitch = {"Can switch from inside", ''}
Lng.DriverUsesCustomExitPos = {"Override driver exit position", ''}
Lng.TrailerAttach = {"Trailer attach", ''}
Lng.TrailerAttachConStrengthM = {"Trailer attach connection strength multiplier", ''}
Lng.TrailersCanAtchToReg = {"Trailer can attach to regular cars", ''}
Lng.RepairToolSpeedMult = {"Repair tool speed multiplier", ''}
Lng["Auto select based on location"] = {"Auto select based on location", ""}
VC.Lng_Default = Lng
VC.Lng_Default_Count = table.Count(VC.Lng_Default)
local TempLng = {}
for k, v in pairs(Lng) do
    TempLng[k] = v[1]
end

VC.Lng_T[Lng.Language_Code[1]] = TempLng
VC.Lng_T_Rev[Lng.Language_Code[1]] = 1
local lngDef = VC.Lng_T["en"]
function VC.Lng(msg)
    if VC.Lng_Sel and VC.Lng_T[VC.Lng_Sel] and VC.Lng_T[VC.Lng_Sel][msg] then
        msg = VC.Lng_T[VC.Lng_Sel][msg]
    else
        msg = lngDef[msg] or msg
    end
    return msg
end

function VC.getLanguages()
    return VC.Lng_T or {
        en = lngDef
    }
end

function VC.Lng_Pick()
    local sysLng = string.lower(system.GetCountry())
    if VC.Lng_T[sysLng] then
        VCMsg("Player location detected, setting language to " .. string.upper(sysLng) .. ".")
        VC.Lng_Set(sysLng)
        VC.SetConfig("lng_picked", true)
    else
        VC.Lng_Sel = nil
    end
end

function VC.Lng_Set(val)
    VC.SetConfig("lng", val, function(lng) VC.Lng_Sel = lng end)
    if VC.menu2Reopen then VC.menu2Reopen() end
end

function VC.Lng_Get()
    local lng = VC.GetConfig("lng")
    if lng then VC.Lng_Sel = string.lower(lng) end
    if not VC.GetConfig("lng_picked", true) then VC.Lng_Pick() end
    if not VC.Lng_T then
        VC.Lng_T = {}
        VC.Lng_T_Rev = {}
    end

    if not VC.Lng_CanHelpCheck and VC.Lng_Default_Count and VC.Lng_Sel and VC.Lng_T[VC.Lng_Sel] then
        timer.Simple(10, function() if VC.Lng_T and VC.Lng_T[VC.Lng_Sel] and VC.Lng_Default_Count ~= table.Count(VC.Lng_T[VC.Lng_Sel]) and math.random(0, 25) == 0 then VCMsg('VCMod needs your help.\nYour language "' .. string.upper(VC.Lng_Sel) .. '" seems to be outdated. You can help everyone by translating.\nTranslation tool is located at: "!vcmod" chat menu -> "Personal" -> "Language" tab.') end end)
        VC.Lng_CanHelpCheck = true
    end
end

function VC.lngReload()
    for k, v in pairs(VCLanguages) do
        VC.Lng_T[k] = v
        VC.Lng_T_Rev[k] = VCLanguagesRev[k]
    end
end

function VC.lngLoadLocal()
    VC.lngData = {}
    for k, v in pairs(VCLanguagesRev) do
        VC.lngData[k] = v
    end
end

function VC.Open_Menu_Translation()
    local Pnl = vgui.Create("DFrame")
    Pnl:SetSize(1000, 600)
    Pnl:SetPos(ScrW() / 2 - Pnl:GetWide() / 2, ScrH() / 2 - Pnl:GetTall() / 2)
    Pnl:SetTitle("")
    Pnl:NoClipping(true)
    Pnl:MakePopup()
    local LngH = Pnl:GetTall() - 35 - 82 - 20
    local MainList = VC.Add_El_List(180 + 5, 30, Pnl:GetWide() - 180 - 5, Pnl:GetTall() - 35)
    MainList:SetParent(Pnl)
    MainList.Paint = function(obj, Sx, Sy)
        draw.RoundedBox(0, -5, 0, Sx, Sy, VC.Color.Main)
        local Clr = VC.Color.Good
        surface.SetDrawColor(Clr.r, Clr.g, Clr.b, Clr.a)
        local Py = 30
        surface.DrawLine(0, Py, Sx - 5, Py)
        draw.DrawText("Original", "VC_Info_Smaller", 5, 8, VC.Color.Blue, TEXT_ALIGN_LEFT)
        draw.DrawText("Translation", "VC_Info_Smaller", Sx / 2, 8, VC.Color.Blue, TEXT_ALIGN_LEFT)
    end

    local Clear = vgui.Create("VC_Button")
    Clear:SetText("Clear")
    Clear:SetToolTip("Clear the contents of this language.")
    Clear:SetParent(Pnl)
    Clear:SetSize(60, 20)
    Clear:AlignRight(10)
    Clear:AlignTop(35)
    Clear:SetColor(VC.Color.Neutral)
    local Delete = vgui.Create("VC_Button")
    Delete:SetText("Delete")
    Delete:SetToolTip("Completely delete translation.")
    Delete:SetColor(VC.Color.Btn_Rem)
    local Search = vgui.Create("DTextEntry", Pnl)
    Search:SetToolTip("Search for a word or a phrase.")
    Search:SetParent(Pnl)
    Search:SetSize(100, 20)
    Search:AlignRight(75)
    Search:AlignTop(35)
    local SNLbl = vgui.Create("DLabel")
    SNLbl:SetText("")
    SNLbl:SetTall(25)
    MainList:AddItem(SNLbl)
    local MainList2 = nil
    local TranslationTbl = {}
    local function Import()
        if IsValid(MainList2) then MainList2:Remove() end
        if Pnl.VC_Sel and VC.Lng_T[Pnl.VC_Sel] then
            MainList2 = VC.Add_El_List(10, 35, MainList:GetWide() - 20, MainList:GetTall() - 40)
            MainList2:SetParent(MainList)
            MainList2:AlphaTo(0, 0, 0)
            for k, v in SortedPairs(VC.Lng_Default) do
                if k ~= "Name" and k ~= "Language_Code" and k ~= "Translated_By_Name" and k ~= "Translated_By_Link" and k ~= "Translated_Date" then
                    local desc = "Original text:\n" .. v[1] .. ((not v[2] or v[2] == "") and "" or ("\n\nDescription:\n" .. v[2]))
                    local MPnl = VC.Add_El_Panel(MainList2, {0.5, 0.5, 0.1}, 20, 2)
                    MPnl.Main:SetToolTip(desc)
                    local SNLbl = vgui.Create("DLabel")
                    SNLbl:SetText(v[1])
                    SNLbl:SetColor(VC.Color.Bad)
                    MPnl[1]:AddItem(SNLbl)
                    local tentr = vgui.Create("DTextEntry", Pnl)
                    MPnl[2]:AddItem(tentr)
                    tentr:SetToolTip(desc)
                    tentr.OnTextChanged = function()
                        local val = tentr:GetValue()
                        SNLbl:SetColor(val ~= "" and VC.Color.Good or VC.Color.Bad)
                    end

                    if Pnl.VC_Sel and VC.Lng_T[Pnl.VC_Sel] and VC.Lng_T[Pnl.VC_Sel][k] then
                        tentr:SetValue(VC.Lng_T[Pnl.VC_Sel][k])
                        tentr.OnTextChanged()
                    end

                    TranslationTbl[k] = {tentr, MPnl.Main, v[1], VC.Lng_T[Pnl.VC_Sel][k]}
                    MPnl.Main.PaintOver = function(Obj, Sx, Sy) if MPnl.Main:IsHovered() or SNLbl:IsHovered() or tentr:IsHovered() then draw.RoundedBox(0, 0, 0, Sx, Sy, Color(0, 100, 50, 50)) end end
                    SNLbl.Paint = function(obj, Sx, Sy)
                        if tentr:HasFocus() then draw.RoundedBox(0, 0, 0, Sx, Sy, Color(0, 80, 100, 100)) end
                        if MPnl.Main.Searched then draw.RoundedBox(0, 0, 0, Sx, Sy, Color(255, 155, 50, 155)) end
                    end
                end
            end

            MainList2:AlphaTo(255, 0.5, 0.2)
        end
    end

    Search.OnTextChanged = function()
        local val = string.lower(Search:GetValue())
        if val == "" then val = nil end
        for k, v in pairs(TranslationTbl) do
            v[2].Searched = val and (string.find(string.lower(v[3]), val) or v[4] and string.find(string.lower(v[4]), val))
        end
    end

    local List = VC.Add_El_List(5, 30, 180, LngH)
    List:SetParent(Pnl)
    List.Paint = function(obj, Sx, Sy) draw.RoundedBox(0, -5, 0, Sx, Sy, VC.Color.Main) end
    local BtnList = {}
    local MainCount = table.Count(VC.Lng_Default) - 5
    local function RefreshList()
        for k, v in pairs(BtnList) do
            if IsValid(v) then v:Remove() end
        end

        BtnList = {}
        for k, v in pairs(VC.Lng_T) do
            local code = string.lower(v.Language_Code)
            if code ~= "en" then
                local Btn = vgui.Create("DButton")
                Btn:SetText("")
                Btn:SetToolTip("Author:    " .. v.Translated_By_Name .. "\nDate:        " .. v.Translated_Date)
                List:AddItem(Btn)
                BtnList[code] = Btn
                Btn:AlphaTo(0, 0, 0)
                Btn:AlphaTo(255, 0.2, 0)
                Btn.DoClick = function()
                    Pnl.VC_Sel = code
                    Pnl.VC_Sel_Name = v.Name
                    Import()
                end

                Btn.Paint = function(obj, Sx, Sy)
                    draw.DrawText(string.upper(code), "VC_Dev_Text", 5, 5, VC.Color.Blue, TEXT_ALIGN_LEFT)
                    draw.DrawText(v.Name, "VC_Dev_Text", 30, 5, VC.Color.White, TEXT_ALIGN_LEFT)
                    local Sel = Pnl.VC_Sel and Pnl.VC_Sel == code
                    if Sel or obj:IsHovered() then
                        local Clr = Sel and VC.Color.Good or VC.Color.Blue
                        surface.SetDrawColor(Clr.r, Clr.g, Clr.b, Clr.a)
                        local Py = Sy - 1
                        surface.DrawLine(0, Py, Sx, Py)
                    end

                    local Cnt = table.Count(VC.Lng_T[k]) - 5
                    local good = MainCount <= Cnt
                    draw.DrawText(Cnt .. "/" .. MainCount, nil, Sx - 12, 8, good and VC.Color.Good or VC.Color.Bad, TEXT_ALIGN_RIGHT)
                end
            end
        end
    end

    local List2 = VC.Add_El_List(5, LngH + 30 + 5 + 5, 180, Pnl:GetTall() - LngH - 40)
    List2:SetParent(Pnl)
    List2:NoClipping(true)
    List2.Paint = function(obj, Sx, Sy) draw.RoundedBox(0, 0, -5, Sx - 5, Sy, VC.Color.Main) end
    Clear.DoClick = function()
        if Pnl.VC_Sel then
            for k, v in pairs(TranslationTbl) do
                v[1]:SetValue("")
            end

            VCPopup("Language cleared.", "check")
        end
    end

    Delete.DoClick = function()
        if Pnl.VC_Sel then
            --file.Delete("vcmod/data_lng/" .. string.lower(Pnl.VC_Sel) .. "__" .. Pnl.VC_Sel_Name .. ".txt")
            VC.Lng_T[Pnl.VC_Sel] = nil
            VC.Lng_T_Rev[Pnl.VC_Sel] = nil
            Pnl.VC_Sel = nil
            Pnl.VC_Sel_Name = nil
            RefreshList()
            Import()
        end
    end

    local MPnl = VC.Add_El_Panel(List2, {0.03, 0.92}, 25, true)
    local New = vgui.Create("VC_Button", Pnl)
    New:SetText("Add new")
    New:SetToolTip("Add a new language.")
    MPnl[2]:AddItem(New)
    New:SetColor(VC.Color.Btn_Spw)
    New.DoClick = function()
        local PnlNew = vgui.Create("DFrame")
        PnlNew:SetSize(300, 150)
        PnlNew:ShowCloseButton(false)
        PnlNew:SetPos(ScrW() / 2 - PnlNew:GetWide() / 2, ScrH() / 2 - PnlNew:GetTall() / 2)
        PnlNew:SetTitle("")
        PnlNew:NoClipping(true)
        PnlNew:MakePopup()
        PnlNew.Paint = function(obj, Sx, Sy)
            draw.RoundedBox(0, 0, 0, Sx, Sy, Color(55, 125, 55, 255))
            draw.RoundedBox(0, 0, 0, Sx, 25, Color(0, 55, 0, 255))
            draw.DrawText("Add a new language", "VC_Dev_Text", 7, 5, VC.Color.White, TEXT_ALIGN_LEFT)
        end

        local ListNew = VC.Add_El_List(5, 30, PnlNew:GetWide() - 10, PnlNew:GetTall() - 35)
        ListNew:SetParent(PnlNew)
        local code = vgui.Create("VC_TextEntry")
        code.VC_TEntry = true
        code:SetTall(20)
        code.VC_Text = "Language code"
        code.VC_TxtNtrPrc = 0.4
        code:SetToolTip("For example: for English its EN, for Lithuanian its LT.")
        code:SetTextColor(VC.Color.White)
        ListNew:AddItem(code)
        local name = vgui.Create("VC_TextEntry")
        name.VC_TEntry = true
        name:SetTall(20)
        name.VC_Text = "Language name"
        name.VC_TxtNtrPrc = 0.4
        name:SetToolTip("Use your language translation of the name. For example: Lietuvių, instead of Lithuanian.")
        name:SetTextColor(VC.Color.White)
        ListNew:AddItem(name)
        local Btn = vgui.Create("DImageButton")
        Btn:SetMaterial(VC.Material.Cross)
        Btn:SetParent(PnlNew)
        Btn:SetSize(20, 20)
        Btn:SetPos(PnlNew:GetWide() - Btn:GetWide(), PnlNew:GetTall() - PnlNew:GetTall())
        Btn.DoClick = function() PnlNew:Close() end
        local Btn = vgui.Create("VC_Button", ListNew)
        Btn:SetText("Add")
        Btn:SetToolTip("Add a new language.")
        ListNew:AddItem(Btn)
        Btn:SetColor(VC.Color.Btn_Add)
        Btn.DoClick = function()
            local codetxt = code.VC_TxtNtr:GetValue()
            local codel = string.lower(codetxt or "")
            local nametxt = name.VC_TxtNtr:GetValue()
            if codel == "" then
                VCPopup("Code can not be empty.", "cross")
                return
            end

            if codel[1] == "" or codel[2] == "" or codel[3] ~= "" then
                VCPopup("Can only be 2 letters.", "cross")
                return
            end

            if codel == "en" then
                VCPopup("Can not be EN", "cross")
                return
            end

            if nametxt == "" then
                VCPopup("Name can not be empty.", "cross")
                return
            end

            local Tbl = {}
            Tbl.Language_Code = codel
            Tbl.Name = nametxt
            Tbl.Translated_By_Name = LocalPlayer():Nick()
            Tbl.Translated_Date = os.date("%Y/%m/%d")
            Tbl.Translated_By_Link = "http://steamcommunity.com/profiles/" .. LocalPlayer():SteamID64()
            VC.Lng_T[codel] = Tbl
            VC.Lng_T_Rev[codel] = 1
            RefreshList()
            Pnl.VC_Sel = codel
            Pnl.VC_Sel_Name = nametxt
            Import()
            PnlNew:Close()
            VCPopup("Language " .. nametxt .. " has been added.", "check")
        end
    end

    local MPnl = VC.Add_El_Panel(List2, {0.03, 0.92}, 25, true)
    MPnl[2]:AddItem(Delete)
    local MPnl = VC.Add_El_Panel(List2, {0.03, 0.92}, 40, true)
    local Upload = vgui.Create("VC_Button", Pnl)
    Upload:SetText("Upload")
    Upload:SetTall(35)
    Upload:SetToolTip("Upload this language to VCMod web-server, where it will be checked and possibly included in the official revisions.")
    MPnl[2]:AddItem(Upload)
    Upload:SetColor(VC.Color.Btn_Add)
    Upload.DoClick = function()
        if not Pnl.VC_Sel then
            VCPopup("Nothing is selected.", "cross")
            return
        end

        local Tbl = {}
        for k, v in pairs(TranslationTbl) do
            local text = v[1]:GetValue()
            if text ~= "" then Tbl[k] = text end
        end

        Tbl.Language_Code = string.upper(Pnl.VC_Sel)
        Tbl.Name = Pnl.VC_Sel_Name
        Tbl.Translated_By_Name = LocalPlayer():Nick()
        Tbl.Translated_Date = os.date("%Y/%m/%d")
        Tbl.Translated_By_Link = "http://steamcommunity.com/profiles/" .. LocalPlayer():SteamID64()
        if (table.Count(VC.Lng_Default) - 5) > (table.Count(Tbl) - 5) then
            VCPopup("Not all words were translated.", "cross")
            return
        end

        VCMsg("Attempting to upload language file, this might take a bit.")
        VC.Lng_T[string.lower(Tbl.Language_Code)] = Tbl
        VC.Lng_T_Rev[string.lower(Tbl.Language_Code)] = 1
    end

    Pnl.Paint = function(obj, Sx, Sy)
        draw.RoundedBox(0, 0, 0, Sx, Sy, VC.Color.Main)
        draw.RoundedBox(0, 0, 0, Sx, 25, VC.Color.Main)
        draw.DrawText("VCMod translation tool", "VC_Dev_Text", 7, 5, VC.Color.Blue, TEXT_ALIGN_LEFT)
        draw.DrawText("Once language is uploaded it will need to be approved. Until then changes are only visible to you. A map restart may remove any of your edits.", nil, 210, 5, VC.Color.White, TEXT_ALIGN_LEFT)
    end

    RefreshList()
    Pnl:AlphaTo(0, 0, 0)
    Pnl:AlphaTo(255, 0.2, 0)
end

concommand.Add("vc_menu_open_translation", function() VC.Open_Menu_Translation() end)
if not VC.DrawFT then VC.DrawFT = {} end
VC.AnimCT = 500
function VC.HUD_DrawBG(alfa, x, y, wx, wy, clr, warningclr)
    local BGClr = table.Copy(VC.Color.Main)
    if clr then BGClr = table.Copy(clr) end
    BGClr.a = BGClr.a * alfa * 0.9
    x = math.Round(x)
    y = math.Round(y)
    draw.RoundedBox(0, x, y, wx, wy, BGClr)
    if warningclr then
        warningclr = warningclr and table.Copy(warningclr)
        if not fade then fade = VC.FadeW end
        local Sy2 = math.Round(wy / 2)
        surface.SetDrawColor(warningclr.r, warningclr.g, warningclr.b, warningclr.a)
        surface.SetMaterial(VC.Material.Fade)
        local div = wx / 1
        surface.DrawTexturedRectRotated(math.Round(x + div / 2), y + wy / 2, div, wy, 0)
        surface.DrawTexturedRectRotated(math.Round(x + wx - div / 2), y + wy / 2, div, wy, 180)
    end
end

VC.DrawFT["ELS_Siren"] = function(ply, CARot, ent, DrvV, GVeh, Sart_Height, Lrp, SrnTbl)
    local MainSz = 32
    local on = SrnTbl and SrnTbl.Sounds and table.Count(SrnTbl.Sounds) > 0 and GVeh == ent
    local anim = VC.UI_AnimData("ELS_Siren", on, 0.02 + Lrp / VC.AnimCT, 0.01 + Lrp / VC.AnimCT)
    if anim then
        local Rat_L = anim * 2
        if Rat_L > 1 then Rat_L = 1 end
        local Rat_B = anim * 3
        if Rat_B > 1 then Rat_B = 1 end
        local Rat_T = anim * 2 - 1
        if Rat_T < 0 then Rat_T = 0 end
        VC.HUD_DrawBG(Rat_B, ScrW() - 150 + CARot[1] - 20, Sart_Height + CARot[2], 180 - CARot[1], MainSz)
        local Sel = GVeh and VC.GetState(GVeh, "ELS_Snd_Sel", 0)
        draw.SimpleText(VC.Lng("Siren"), "VC_Regular2", math.Round(ScrW() - 160 + CARot[1]), math.Round(Sart_Height + 22 + CARot[2]), Color(255, 255, 255, 255 * Rat_T), TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
        local Mnl = GVeh and VC.GetState(GVeh, "ELS_ManualOn")
        local Off = GVeh and VC.GetState(GVeh, "ELS_S_Disabled")
        local Txt = "Off"
        local Clr = Color(255, 255, 255, 255 * Rat_T)
        if (Mnl or Sel and Sel > 0) and not Off and GVeh and VC.GetState(GVeh, "HornOn") and GVeh.VC_Siren_BullHorn then
            Txt = "Bullhorn"
            Clr = Color(120, 205, 255, 255 * Rat_T)
        elseif Mnl then
            Txt = "Manual"
            Clr = Color(255, 200, 0, 255 * Rat_T)
        elseif Off then
            Txt = Sel and Sel > 0 and (SrnTbl and SrnTbl.Sounds and SrnTbl.Sounds[Sel].Name or VC.Lng("Unknown")) or "Off"
            Clr = Color(255, 100, 100, 255 * Rat_T)
        elseif Sel and Sel > 0 then
            Txt = SrnTbl and SrnTbl.Sounds and SrnTbl.Sounds[Sel].Name or VC.Lng("Unknown")
            Clr = Color(100, 255, 55, 255 * Rat_T)
        end

        draw.SimpleText(string.upper(VC.Lng(Txt)), "VC_HUD_Bisgs", math.Round(ScrW() - 20 + CARot[1]), math.Round(Sart_Height + 22 + CARot[2]), Clr, TEXT_ALIGN_RIGHT, TEXT_ALIGN_BOTTOM)
        Clr.a = 255
        draw.RoundedBox(0, math.Round(ScrW() - 165 * Rat_L + CARot[1]), math.Round(Sart_Height + 24 + CARot[2]), 170 - CARot[1], 2, Clr)
    end

    if anim then Sart_Height = Sart_Height + MainSz + 2 end
    return Sart_Height
end

VC.DrawFT["ELS_Lights"] = function(ply, CARot, GVeh, DrvV, Veh, Sart_Height, Lrp, SrnTbl)
    local MainSz = 32
    local on = SrnTbl and SrnTbl.Sequences and GVeh and Veh == GVeh
    local anim = VC.UI_AnimData("ELS_Lights", on, 0.02 + Lrp / VC.AnimCT, 0.01 + Lrp / VC.AnimCT)
    local on = anim and anim == 1 and SrnTbl and SrnTbl.Sections
    local anim_adv = VC.UI_AnimData("ELS_Lights_Adv", on, 0.03, 0.02) or 0
    if anim then
        if not VC.ELS_Last then VC.ELS_Last = {} end
        if SrnTbl and GVeh and Veh == GVeh then VC.ELS_Last.Sections = SrnTbl.Sections end
        local Rat_Adv_L = anim_adv * 2
        if Rat_Adv_L > 1 then Rat_Adv_L = 1 end
        local Rat_Adv_T = anim_adv * 2 - 1
        if Rat_Adv_T < 0 then Rat_Adv_T = 0 end
        if VC.ELS_Last.Sections then MainSz = MainSz + 20 * table.Count(VC.ELS_Last.Sections) * (Rat_Adv_L or 0) end
        local Rat_L = anim * 2
        if Rat_L > 1 then Rat_L = 1 end
        local Rat_B = anim * 3
        if Rat_B > 1 then Rat_B = 1 end
        local Rat_T = anim * 2 - 1
        if Rat_T < 0 then Rat_T = 0 end
        VC.HUD_DrawBG(Rat_B, ScrW() - 150 + CARot[1] - 20, Sart_Height + CARot[2], 180 - CARot[1], MainSz)
        local ELS = VC.Lng("ELS")
        draw.SimpleText(ELS, "VC_Regular2", math.Round(ScrW() - 160 + CARot[1]), math.Round(Sart_Height + 22 + CARot[2]), Color(255, 255, 255, 255 * Rat_T), TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
        local codeName = VC.ELS_getCodeName(GVeh and VC.GetState(GVeh, "ELS_Lht_Sel", 0), GVeh)
        local Off = GVeh and VC.GetState(GVeh, "ELS_L_Disabled")
        local Txt = "off"
        local Clr = Color(255, 255, 255, 255 * Rat_T)
        if Off then
            Clr = Color(255, 100, 100, 255 * Rat_T)
        elseif codeName ~= "Off" then
            Clr = Color(100, 255, 55, 255 * Rat_T)
        end

        draw.SimpleText(string.upper(VC.Lng(codeName)), "VC_HUD_Bisgs", math.Round(ScrW() - 20 + CARot[1]), math.Round(Sart_Height + 22 + CARot[2]), Clr, TEXT_ALIGN_RIGHT, TEXT_ALIGN_BOTTOM)
        Clr.a = 255
        draw.RoundedBox(0, math.Round(ScrW() - 165 * Rat_L + CARot[1]), math.Round(Sart_Height + 24 + CARot[2]), 170 - CARot[1], 2, Clr)
        if VC.ELS_Last.Sections then
            local int = 0
            for k, v in SortedPairs(VC.ELS_Last.Sections) do
                draw.SimpleText(ELS, "VC_Regular2", math.Round(ScrW() - 160 + CARot[1]), math.Round(Sart_Height + 22 + CARot[2]), Color(255, 255, 255, 255 * Rat_Adv_T), TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
                local Am = table.Count(v)
                draw.SimpleText(VC.ELS_SectionNames[k], "VC_Regular_S", math.Round(ScrW() - 160 + CARot[1]), math.Round(Sart_Height + 36 + 5 + 20 * int + CARot[2]), Color(255, 255, 255, 120 * Rat_Adv_T), TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
                for i = 1, Am do
                    local Sel = nil
                    for k2, v2 in pairs(v[i]) do
                        if Veh and Veh.VC_LastRenderedL and Veh.VC_LastRenderedL[k2] then
                            Sel = true
                            break
                        end
                    end

                    local Size = 160 / Am
                    draw.RoundedBox(0, math.Round(ScrW() - 165 * Rat_L + CARot[1] + (Size * (i - 1))), math.Round(Sart_Height + 36 + 5 + 20 * int + CARot[2]), Size - 3, 4, Sel and Color(100, 255, 55, 255 * Rat_Adv_T) or Color(255, 255, 255, 20 * Rat_Adv_T))
                end

                int = int + 1
            end
        end
    end

    if anim then Sart_Height = Sart_Height + MainSz + 2 end
    return Sart_Height
end

VC.Material.Reg = Material("sprites/light_ignorez")
VC.Material.HD = Material("vcmod/lights/lines")
VC.Material.HD2 = Material("vcmod/lights/lines_2")
VC.Material.Glow = Material("vcmod/lights/glow_hd")
VC.Material.Beam = Material("vcmod/lights/beam")
VC.Material.BeamDot = Material("vcmod/lights/beamdot")
VC.Material.HBeam = Material("vcmod/lights/hbeam")
if not VC.PrjTextures then VC.PrjTextures = {} end
function VC.Lerp_Points(int, Tbl)
    for k, v in pairs(Tbl) do
        local NDP = Tbl[k + 1]
        if NDP and NDP[2] >= int then return LerpVector((NDP[2] - int) / (NDP[2] - v[2]), NDP[1], v[1]) end
    end
end

function VC.Bazzier(var, p1, p2, p3)
    return ((1 - var) ^ 2) * p1 + 2 * (1 - var) * var * p2 + (var ^ 2) * p3
end

local function getColor(Lhv, col)
    local tclr = Color(0, 255, 0, 255)
    if not Lhv.colors then
        Lhv.colors = {
            primary = tclr,
            middle = tclr
        }
    end

    if not Lhv.colors[col] then
        Lhv.colors[col] = {}
        local clr = VC.PrepareColor(Lhv[col], true)
        Lhv.colors[col].primary = clr
        if Lhv.OnSiren and clr.g == 55 then
            if clr.r == 255 and clr.b == 0 then
                Lhv.colors[col].primary = Color(255, 0, 0, 255)
            elseif clr.r == 0 and clr.b == 255 then
                Lhv.colors[col].primary = Color(0, 0, 255, 255)
            end
        end

        if Lhv.RenderInner and Lhv.RenderInner_ClrUse and Lhv.RenderInner_Clr then
            Lhv.colors[col].middle = VC.PrepareColor(Lhv.RenderInner_Clr, true)
        else
            local r, g, b = clr.r, clr.g, clr.b
            if r > g and r > b then
                Lhv.colors[col].middle = Color(255, Lhv.OnSiren and 200 or 155, 0, 255)
            elseif g > r and g > b then
                Lhv.colors[col].middle = Color(225, 255, 225, 255)
            elseif b > r and b > g then
                Lhv.colors[col].middle = Color(225, 225, 255, 255)
            else
                Lhv.colors[col].middle = clr
            end

            if math.abs(r - g) < 40 and math.abs(r - b) < 40 then
                local h = Color(255, 225, 225, 255)
                if r < g then h = Color(225, 255, 225, 255) end
                if g < b then h = Color(225, 225, 255, 255) end
                Lhv.colors[col].middle = h
            end
        end
    end
    return Lhv.colors[col]
end

local function adaptToFollow(pos, pos_mainvector, pos_local, ang)
    if ang then
        pos = pos - pos_mainvector
        pos:Rotate(ang)
        pos = pos + pos_local
    end
    return pos
end

local function Handle_Light_Init(Lhv, Lhk, col, pos_local, ang_local)
    local hasAtc = Lhv.PosAtc
    if Lhv.Inited and not hasAtc then return end
    Lhv.Inited = true
    if not hasAtc or (not Lhv.InitAtcPos or Lhv.InitAtcPos ~= pos_local) then
        Lhv.InitAtcPos = pos_local
    else
        return
    end

    Lhv.SpecTable = nil
    local STSz = 0
    local pos_mainvector = Lhv.Pos or Vector(0, 0, 0)
    if Lhv.SpecLine and Lhv.SpecLine.Use then
        if not Lhv.SpecTable then Lhv.SpecTable = {} end
        if Lhv.SpecLine.Amount and Lhv.SpecLine.Amount > 1 then
            local Am = Lhv.SpecLine.Amount - 2
            for i = 1, Am do
                Lhv.SpecTable[i] = LerpVector(i / (Am + 1), pos_local, Lhv.SpecLine.Pos or Vector(0, 0, 0))
            end

            STSz = STSz + Am
        end

        local Cnt = table.Count(Lhv.SpecTable)
        Lhv.SpecTable[Cnt + 1] = Lhv.Pos or Vector(0, 0, 0)
        Lhv.SpecTable[Cnt + 2] = Lhv.SpecLine.Pos or Vector(0, 0, 0)
    end

    if Lhv.SpecMLine and Lhv.SpecMLine.Use and Lhv.SpecMLine.LTbl then
        local posBase = ang_local and pos_local or pos_mainvector
        if not Lhv.SpecTable then Lhv.SpecTable = {posBase} end
        Lhv.DrawingSpecMLine = true
        local PT = {posBase}
        local TotalDist = 0
        local DistT = {{posBase, 0}}
        if Lhv.RenderBeam then
            Lhv.SpecTableBeam = {}
            Lhv.SpecTableBeam[1] = {
                Pos = posBase,
                Size = 1
            }

            for k, v in pairs(Lhv.SpecMLine.LTbl) do
                local clr_prep = nil
                if v.UseClr and v.Clr then clr_prep = VC.PrepareColor(v.Clr) end
                if k == 1 then
                    Lhv.SpecTableBeam[1] = {
                        Pos = pos_mainvector,
                        Size = v.Size
                    }

                    if clr_prep then Lhv.SpecTableBeam[1].Clr = clr_prep end
                end

                Lhv.SpecTableBeam[k + 1] = {
                    Pos = v.Pos,
                    Size = v.Size
                }

                if clr_prep then Lhv.SpecTableBeam[k + 1].Clr = clr_prep end
            end
        end

        if not Lhv.SpecMLine.Amount or Lhv.SpecMLine.Amount < 2 then Lhv.SpecMLine.Amount = 2 end
        for k, v in pairs(Lhv.SpecMLine.LTbl) do
            PT[k + 1] = adaptToFollow(v.Pos or Vector(0, 0, 0), pos_mainvector, pos_local, ang_local)
        end

        STSz = STSz + Lhv.SpecMLine.Amount - 1
        for k, v in pairs(PT) do
            if PT[k + 1] then
                local TD = v:Distance(PT[k + 1])
                TotalDist = TotalDist + TD
                DistT[k + 1] = {PT[k + 1], TotalDist}
            else
                break
            end
        end

        local Cnt = table.Count(Lhv.SpecTable)
        for i = 1, Lhv.SpecMLine.Amount do
            Lhv.SpecTable[Cnt + i] = VC.Lerp_Points(TotalDist * (i / (Lhv.SpecMLine.Amount - 1)), DistT)
        end
    end

    if Lhv.SpecCircle and Lhv.SpecCircle.Use then
        if Lhv.RenderBeam then Lhv.SpecTableBeam = {} end
        if not Lhv.SpecTable then Lhv.SpecTable = {} end
        local Am, SAm = Lhv.SpecCircle.Amount or 3, table.Count(Lhv.SpecTable)
        for i = 1, Am do
            local TVec = Vector(Lhv.SpecCircle.Radius or 1, 0, 0)
            TVec:Rotate(Angle(i / Am * 360, 0, 0))
            local totalRot = nil
            if Lhv.SpecCircle.Ang then totalRot = Lhv.SpecCircle.Ang end
            if ang_local then
                if totalRot then
                    totalRot = VC.AngleCombCalc2(Angle(ang_local.p, ang_local.y, ang_local.r), Angle(totalRot.p, totalRot.y, totalRot.r))
                else
                    totalRot = ang_local
                end
            end

            if totalRot then TVec:Rotate(totalRot) end
            Lhv.SpecTable[SAm + i] = pos_local + TVec
            if Lhv.RenderBeam then
                Lhv.SpecTableBeam[i] = {
                    Pos = pos_local + TVec
                }

                table.insert(Lhv.SpecTableBeam, {
                    Pos = Lhv.SpecTableBeam[1].Pos or Vector(0, 0, 0)
                })
            end
        end

        STSz = STSz + Am
    end

    if Lhv.SpecRec and Lhv.SpecRec.Use then
        if not Lhv.SpecTable then Lhv.SpecTable = {} end
        local SAm = table.Count(Lhv.SpecTable)
        local AmH, AmV = (Lhv.SpecRec.AmountH or 2) - 2, (Lhv.SpecRec.AmountV or 2) - 2
        local Pos1 = adaptToFollow(Lhv.SpecRec.Pos1, pos_mainvector, pos_local, ang_local)
        local Pos2 = adaptToFollow(Lhv.SpecRec.Pos2, pos_mainvector, pos_local, ang_local)
        local Pos3 = adaptToFollow(Lhv.SpecRec.Pos3, pos_mainvector, pos_local, ang_local)
        local Pos4 = adaptToFollow(Lhv.SpecRec.Pos4, pos_mainvector, pos_local, ang_local)
        Lhv.SpecTable[SAm + 1] = Pos1
        Lhv.SpecTable[SAm + 2] = Pos2
        Lhv.SpecTable[SAm + 3] = Pos3
        Lhv.SpecTable[SAm + 4] = Pos4
        if Lhv.SpecRec.Mid_Full then
            for i = 1, AmH do
                local TCnt = table.Count(Lhv.SpecTable)
                local pos_local = LerpVector(i / (AmH + 1), Pos1, Pos2)
                local EPos = LerpVector(i / (AmH + 1), Pos4, Pos3)
                local tSAm = table.Count(Lhv.SpecTable)
                for j = 1, AmV do
                    Lhv.SpecTable[tSAm + j] = LerpVector(j / (AmV + 1), pos_local, EPos)
                end
            end

            STSz = STSz + AmH
        else
            if Lhv.SpecRec.Mid then
                SAm = table.Count(Lhv.SpecTable)
                for i = 1, AmH do
                    Lhv.SpecTable[SAm + i] = LerpVector(i / (AmH + 1), (Pos1 + Pos4) / 2, (Pos2 + Pos3) / 2)
                end
            end

            if Lhv.SpecRec.Mid_V then
                SAm = table.Count(Lhv.SpecTable)
                for i = 1, AmV do
                    Lhv.SpecTable[SAm + i] = LerpVector(i / (AmV + 1), (Pos1 + Pos2) / 2, (Pos3 + Pos4) / 2)
                end
            end
        end

        SAm = table.Count(Lhv.SpecTable)
        for i = 1, AmH do
            Lhv.SpecTable[SAm + i] = LerpVector(i / (AmH + 1), Pos1, Pos2)
        end

        STSz = STSz + AmH
        SAm = table.Count(Lhv.SpecTable)
        for i = 1, AmV do
            Lhv.SpecTable[SAm + i] = LerpVector(i / (AmV + 1), Pos2, Pos3)
        end

        STSz = STSz + AmV
        SAm = table.Count(Lhv.SpecTable)
        for i = 1, AmH do
            Lhv.SpecTable[SAm + i] = LerpVector(i / (AmH + 1), Pos3, Pos4)
        end

        STSz = STSz + AmH
        SAm = table.Count(Lhv.SpecTable)
        for i = 1, AmV do
            Lhv.SpecTable[SAm + i] = LerpVector(i / (AmV + 1), Pos4, Pos1)
        end

        STSz = STSz + AmV
    end

    if Lhv.Spec3D and Lhv.Spec3D.Use and Lhv.Spec3D.Mat and Lhv.Spec3D.Mat ~= "" then
        local Pos1 = adaptToFollow(Lhv.Spec3D.Pos1, pos_mainvector, pos_local, ang_local)
        local Pos2 = adaptToFollow(Lhv.Spec3D.Pos2, pos_mainvector, pos_local, ang_local)
        local Pos3 = adaptToFollow(Lhv.Spec3D.Pos3, pos_mainvector, pos_local, ang_local)
        local Pos4 = adaptToFollow(Lhv.Spec3D.Pos4, pos_mainvector, pos_local, ang_local)
        Lhv.Data_3D = {
            Pos1 = Pos1,
            Pos2 = Pos2,
            Pos3 = Pos3,
            Pos4 = Pos4,
            Mat = Material(Lhv.Spec3D.Mat),
            Color = VC.PrepareColor(Lhv.Spec3D.UseColor and Lhv.Spec3D.Color, true)
        }
    end

    Lhv.dotCount = STSz
end

local function Send3DSpinPPData(ent, lht, data)
    if not ent.Spin3D_Data then ent.Spin3D_Data = {} end
    if not ent.Spin3D_Data[lht] then
        ent.Spin3D_Data[lht] = true
        if data.LastSync and CurTime() < data.LastSync then return end
        data.LastSync = CurTime() + 2
        net.Start("VC_Light_3DSpinPPData_Sync")
        net.WriteEntity(ent)
        net.WriteInt(lht, 8)
        net.WriteTable(data)
        net.SendToServer()
    end
end

local function SetSubMaterial(ent, Lhk, int, nmat)
    if not ent.VC_Light_SpecMat then ent.VC_Light_SpecMat = {} end
    if not ent.VC_Light_SpecMat[int] then
        ent.VC_Light_SpecMat[int] = {}
        if not ent.VC_Light_SpecMat[int][Lhk] then ent:SetSubMaterial(int - 1, nmat or "models/wireframe") end
        ent.VC_Light_SpecMat[int][Lhk] = true
    end
end

local prjtextdata = {
    {
        name = "Low beam",
        Ang = Angle(28, 0, 0),
        size = 0.5,
        fov = 140,
        SepAng = 5
    },
    {
        name = "High beam",
        Ang = Angle(5, 0, 0),
        size = 2,
        fov = 90,
        SepAng = 5
    },
    {
        name = "Fog",
        Ang = Angle(28, 0, 0),
        size = 0.3,
        fov = 160,
        SepAng = 5
    },
}

local function HandleProjectedTexture(ent, Lhk, Lhv, pos_world, Ang, Type)
end

local function getVis(ent, Lhk, Lhv, pos_world)
    local ret = 0
    if not ent.VC_Lights_PixVisTbl then ent.VC_Lights_PixVisTbl = {} end
    if not ent.VC_Lights_PixVisTbl[Lhk] then ent.VC_Lights_PixVisTbl[Lhk] = util.GetPixelVisibleHandle() end
    if not ent.VC_HDPTR_Vis_Cache[Lhk] then ent.VC_HDPTR_Vis_Cache[Lhk] = util.PixelVisible(pos_world, (Lhv.Sprite.GlowPrxSize or 2) * 0.5, ent.VC_Lights_PixVisTbl[Lhk]) * 255 end
    ret = ent.VC_HDPTR_Vis_Cache[Lhk]
    if Lhv.SpecFade then
        local data = Lhv.SpecFade
        if data.Use then
            local amount, freq, freq_wait = (data.amount or 0) / 100, data.freq or 0, data.freq_wait
            if not data.cur or CurTime() >= data.cur.rtimeRef then
                data.cur = {
                    final = 0,
                    int = 0,
                    timee = 0,
                    st = data.offset and 3 or 1
                }
            end

            data.cur.rtimeRef = CurTime() + 0.1
            if CurTime() >= data.cur.timee then
                local toAdd = freq
                if freq_wait and freq_wait > 0 then
                    data.cur.st = (data.cur.st or 1) + 1
                    if data.cur.st > 4 then data.cur.st = 1 end
                    if data.cur.st == 2 or data.cur.st == 4 then toAdd = freq_wait end
                else
                    if data.cur.st == 1 then
                        data.cur.st = 3
                    else
                        data.cur.st = 1
                    end
                end

                data.cur.add = toAdd
                data.cur.timee = CurTime() + data.cur.add
            end

            local cur = (data.cur.timee - CurTime()) / data.cur.add
            if data.cur.st == 1 or data.cur.st == 3 then
                if data.cur.st == 3 then cur = 1 - cur end
                data.cur.int = cur
            end

            local mult = math.Clamp(data.cur.int, 0, 1)
            if data.smooth then mult = (VC.EaseInOut((mult + 1) / 2) - 0.5) * 2 end
            if mult <= 0 then mult = 0.001 end
            data.cur.final = 1 - mult * amount
            ret = ret * data.cur.final
        end
    end
    return ret
end

local function handleSubMats(ent, Lhk, Lhv)
    if Lhv.SpecMat and Lhv.SpecMat.Use and Lhv.SpecMat.Select then SetSubMaterial(ent, Lhk, Lhv.SpecMat.Select, Lhv.SpecMat.New) end
end

function VC.addToRenderQueModel(ent, id, data, pos, ang, func)
    if not ent.VC_renderQueModel then ent.VC_renderQueModel = {} end
    local angAdd = ang or Angle(0, 0, 0)
    if data.Ang then angAdd = angAdd + data.Ang end
    local angVeh = ent:GetAngles()
    local entMdl = ClientsideModel(data.Model or "", RENDERGROUP_OTHER)
    entMdl:SetPos(pos or Vector(0, 0, 0))
    entMdl:SetAngles(VC.AngleCombCalc2(Angle(angVeh.p, angVeh.y, angVeh.r), Angle(angAdd.p, angAdd.y, angAdd.r)))
    entMdl:SetParent(ent)
    entMdl:SetModelScale(data.scale or 1)
    entMdl:ManipulateBoneScale(0, (data.scaleVector or Vector(1000, 1000, 1000)) / 1000)
    if data.matSolid then entMdl:SetMaterial("models/debug/debugwhite") end
    if data.UseColor and data.Color then entMdl:SetColor(data.Color) end
    if data.boneMerge then entMdl:AddEffects(EF_BONEMERGE) end
    entMdl:Spawn()
    ent.VC_renderQueModel[id] = entMdl
    VC_freemanngnida(entMdl, ent, id)
    if data.glow and data.glow.Use then VC.registerEntityDrawHalo(ent, entMdl, data.glow) end
    return entMdl
end

function VC.registerEntityDrawHalo(ent, entMdl, data)
    if not VC.registeredEntitiesDrawHalo then VC.registeredEntitiesDrawHalo = {} end
    if not ent.VC_registeredEntitiesDrawHalo then ent.VC_registeredEntitiesDrawHalo = {} end
    entMdl.dataGlow = table.Copy(data)
    local entID = ent:EntIndex()
    VC.registeredEntitiesDrawHalo[entID] = ent
    table.insert(ent.VC_registeredEntitiesDrawHalo, entMdl)
end

local function handleSpecModel(ent, Lhk, Lhv, colid, col, pos_world, pos_local, ang_local, NotDark, distnum, size_mult)
    if Lhv.SpecModel and Lhv.SpecModel.Use then if not ent.VC_renderQueModel or not IsValid(ent.VC_renderQueModel[Lhk]) then local entMdl = VC.addToRenderQueModel(ent, Lhk, Lhv.SpecModel, pos_world, ang_local) end end
end

local function handleDyn(ent, Lhk, Lhv, colid, clr_p, pos_world, pos_local, NotDark, distnum, size_mult)
    if Lhv.UseDynamic and Lhv.Dynamic and VC.getSetting("DynamicLights") and ent.VC_LhtSzOffset_D > 0 and (not Lhv.OnSiren or VC.getSetting("ELS_Dyn_Enabled")) then
        if not NotDark then
            local DLight = DynamicLight(ent:EntIndex() .. Lhk .. colid)
            DLight.Pos = pos_world
            DLight.r = clr_p.r
            DLight.g = clr_p.g
            DLight.b = clr_p.b
            DLight.Brightness = (Lhv.Dynamic.Brightness or 1) / 2
            local Sz = 180 * (Lhv.Dynamic.Size or 1) * distnum
            if size_mult then Sz = Sz * size_mult end
            DLight.Size = Sz * ent.VC_LhtSzOffset_D * (Lhv.OnSiren and VC.getSetting("ELS_Dyn_Mult") or 1)
            DLight.Decay = 500
            DLight.DieTime = CurTime() + 0.5
            if Lhv.InDoor then
                DLight.Decay = 100
                DLight.DieTime = CurTime() + 0.1
            end
        end
    end
end

local function getForwardUp(ent, ang, ang_local)
    local posForw = ent:GetRight()
    local posUp = ent:GetUp()
    if ang then
        posForw:Rotate(ang)
        posUp:Rotate(ang)
    end

    if ang_local and not ang_local:IsZero() then
        posForw:Rotate(ang_local)
        posUp:Rotate(ang_local)
    end
    return posForw, posUp
end

local function handlePrjText(ent, Lhv, clr_p, LightBeamVis, pos_world, ang_local, pos_local)
    if Lhv.UsePrjTex and Lhv.ProjTexture then
        local ang = nil
        if Lhv.ProjTexture.Angle then
            ang = Lhv.ProjTexture.Angle - Angle(0, 90, 0)
            if ang:IsZero() then ang = nil end
        end

        render.SetMaterial(VC.Material.HBeam)
        if Lhv.OnHighBeams or Lhv.OnLowBeams then
            if Lhv.OnHighBeams then
                local posForw, posUp = getForwardUp(ent, ang, ang_local)
                local mult = (1 - LightBeamVis) * 1.8
                if mult > 1 then mult = 1 end
                local clr = VC.ColorCopyAlpha(clr_p, 2 + 8 * mult)
                render.DrawBeam(pos_world + posForw * 80, pos_world - posForw * 1000 - posUp * 15, 170, 1, 0, clr)
                clr.a = 1 + 5 * mult
                render.DrawBeam(pos_world + posForw * 20, pos_world - posForw * 700 - posUp * 80, 400, 1, 0, clr)
            else
                local posForw, posUp = getForwardUp(ent, ang, ang_local)
                local pos_end = pos_world - posForw * 700 - posUp * 100
                local pos_end2 = pos_world - posForw * 500 - posUp * 250
                local pos_end3 = pos_world - posForw * 300 - posUp * 120
                local mult = (1 - LightBeamVis) * 1.3
                if mult > 1 then mult = 1 end
                local clr = VC.ColorCopyAlpha(clr_p, 2 + 8 * mult)
                render.DrawBeam(pos_world + posForw * 30, pos_end, 220, 1, 0, clr)
                clr.a = 2 + 2 * mult
                render.DrawBeam(pos_world + posForw * 50, pos_end2, 800, 1, 0, clr)
                clr.a = 0.5 + 1 * mult
                render.DrawBeam(pos_world + posForw * 20, pos_end3, 500, 1, 0, clr)
            end
        else
            local posForw, posUp = getForwardUp(ent, ang, ang_local)
            local pos_end = pos_world - posForw * 300 - posUp * 100
            local pos_end2 = pos_world - posForw * 500 - posUp * 250
            local pos_end3 = pos_world - posForw * 300 - posUp * 120
            local mult = (1 - LightBeamVis) * 1.3
            if mult > 1 then mult = 1 end
            local clr = clr_p
            clr.a = 2 + 8 * mult
            render.DrawBeam(pos_world + posForw * 30, pos_end, 600, 1, 0, clr)
            clr.a = 1 + 2 * mult
            render.DrawBeam(pos_world + posForw * 50, pos_end2, 800, 1, 0, clr)
            clr.a = 5
            render.DrawBeam(pos_world + posForw * 20, pos_end3, 500, 1, 0, clr)
        end
    end
end

local function handleLightState(Lhv, col)
    Lhv.OnHighBeams = nil
    Lhv.OnLowBeams = nil
    Lhv.OnELS = nil
    Lhv.InDoor = nil
    Lhv.OnRunning = nil
    Lhv.OnReverse = nil
    Lhv.OnBrake = nil
    Lhv.OnFog = nil
    Lhv.OnBlinker = nil
    Lhv.OnInter = nil
    if col == "RunningColor" then
        Lhv.OnRunning = true
    elseif col == "HBeamColor" then
        Lhv.OnHighBeams = true
    elseif col == "LBeamColor" then
        Lhv.OnLowBeams = true
    elseif col == "BrakeColor" then
        Lhv.OnBrake = true
    elseif col == "ReverseColor" then
        Lhv.OnReverse = true
    elseif col == "BlinkersColor" then
        Lhv.OnBlinker = true
    elseif col == "FogColor" then
        Lhv.OnFog = true
    elseif col == "InterColor" then
        Lhv.OnInter = true
    elseif col == "DoorColor" then
        Lhv.InDoor = true
    elseif col == "SirenColor" then
        Lhv.OnELS = true
    end
end

local function canByRender(Lhv, ent)
    local ret = false
    local diffCar = VC.InVehicleMain ~= ent
    if Lhv.IsInterior then Lhv.RenderType = 2 end
    local rType = Lhv.RenderType or 1
    if rType == 1 or rType == 5 then
        ret = diffCar or VC.InVehicleAndTP or not VC.IsViewerSelf
    elseif rType == 2 then
        ret = true
    elseif rType == 3 then
        ret = not VC.InVehicleAndTP
    elseif rType == 4 then
        ret = diffCar or VC.InVehicleAndTP
    end
    return ret
end

local function renderInner(pos, size, clr, doSphere)
    if doSphere then
        render.SetColorMaterial()
        render.DrawSphere(pos, (doSphere.size or size) * 0.05, 15, 15, VC.ColorCopyAlpha(clr, 255))
        render.SetMaterial(doSphere.prev_mat)
    end

    render.DrawSprite(pos, size, size, clr)
end

local function getMainSize(Lhv, distnum, size_mult, NotDark)
    local ret = (Lhv.Sprite.Size or 6) * 100 * distnum
    if size_mult then ret = ret * size_mult end
    if NotDark then ret = ret * 1.1 end
    return ret
end

local cachedMats = {}
function VC_freemannsinexeca(ent, Lhk, Lhv, col, colid, sideid, distnum, size_mult, seqData)
    if not Lhv then return end
    if VC.ObjectIsDamaged(ent, "light", Lhk) then return end
    if not VC.conditionCheck(ent, "Lht_render_" .. Lhk, Lhv) then return end
    local pos_local, pos_world, ang_local = VC_freemannmegaobosr(ent, Lhv)
    if not sideid or (sideid == 1 and (pos_local.x < 0 or Lhv.BlinkerLeft)) and not Lhv.BlinkerRight or (sideid == 2 and (pos_local.x > 0 or Lhv.BlinkerRight)) and not Lhv.BlinkerLeft then
        handleLightState(Lhv, col)
        handleSubMats(ent, Lhk, Lhv)
        local colors = getColor(Lhv, col)
        local clr_p = colors.primary
        local clr_m = colors.middle
        local clr_p = getColor(Lhv, col).primary
        local clr_ovr = nil
        if col == "LBeamColor" or col == "HBeamColor" then
            local ovr = VC.getOverride(ent, "HLColor")
            if ovr then
                clr_p = ovr
                clr_ovr = true
            end
        end

        local carReplaceDetail = ent.VC_Distance > 2500
        local InDetail = true
        local hasLayers = Lhv.SpecTable
        local SpinningSizeSync, SpinningAngSync = nil, nil
        local NotDark = Lhv.InDoor or ent.VC_Brightness > 0.35
        if Lhv.UseSprite and Lhv.Sprite and canByRender(Lhv, ent) then
            Handle_Light_Init(Lhv, Lhk, col, pos_local, ang_local)
            local vis = getVis(ent, Lhk, Lhv, pos_world)
            local visOr = vis
            local size_main = getMainSize(Lhv, distnum, size_mult, NotDark)
            local prxtext_offset = 1
            local LightBeamVis = 1
            InDetail = VC.isClose(ent)
            if vis > 0 then
                if Lhv.OnFog and pos_local.y < 0 then size_main = size_main * 2 end
                local size_glow_mid = ((Lhv.dotCount or 0) * 6 + size_main * 3.5) / 2
                if NotDark then size_glow_mid = size_glow_mid * 1.1 end
                clr_p.a = vis
                if Lhv.Data_3D and VC.getSetting("Light_3D") then
                    render.SetMaterial(Lhv.Data_3D.Mat)
                    local doRender = true
                    local p1, p2, p3, p4 = Lhv.Data_3D.Pos1 or Vector(0, 0, 0), Lhv.Data_3D.Pos2 or Vector(0, 0, 0), Lhv.Data_3D.Pos3 or Vector(0, 0, 0), Lhv.Data_3D.Pos4 or Vector(0, 0, 0)
                    if Lhv.SpecSpin and Lhv.SpecSpin.Use then
                        local speed_rot = Lhv.SpecSpin.Speed or 0
                        local ang = Angle(0, math.NormalizeAngle(CurTime() * speed_rot), 0)
                        if Lhv.SpecSpin.PParam then
                            local pparamRot = ent:GetPoseParameter(Lhv.SpecSpin.PParam)
                            ang.y = (pparamRot - 0.5) * 360
                            Send3DSpinPPData(ent, Lhk, Lhv.SpecSpin)
                        end

                        if Lhv.SpecSpin.Offset then ang.y = ang.y + Lhv.SpecSpin.Offset end
                        local ang_y = VC.AngleDifference(ang, ((pos_world - EyePos()):Angle() - Angle(0, ent:GetAngles().y, 0)) - Angle(0, 90, 0)) - 90
                        local isBackSide = true
                        local ang_dif = math.abs(ang_y)
                        if not Lhv.SpecSpin.Double and ang_y < 0 then
                            ang_dif = 0
                            isBackSide = false
                        end

                        local num = VC.EaseInOut(ang_dif / 90)
                        size_main = size_main / 5 + num * 180 * (Lhv.SpecSpin.Intensity or 1)
                        size_glow_mid = size_glow_mid / 2 + num * size_glow_mid
                        vis = num * 255
                        SpinningSizeSync = num
                        if Lhv.SpecSpin.Rotated then ang.y = ang.y + 90 end
                        ang.y = ang.y + 180
                        if not Lhv.SpecSpin.Reversed then ang.y = -ang.y end
                        local ps1, ps2, ps3, ps4 = pos_local - p1, pos_local - p2, pos_local - p3, pos_local - p4
                        ps1:Rotate(ang)
                        ps2:Rotate(ang)
                        ps3:Rotate(ang)
                        ps4:Rotate(ang)
                        SpinningAngSync = ang
                        p1 = ent:LocalToWorld(pos_local + ps1)
                        p2 = ent:LocalToWorld(pos_local + ps2)
                        p3 = ent:LocalToWorld(pos_local + ps3)
                        p4 = ent:LocalToWorld(pos_local + ps4)
                        doRender = ang_dif >= 0 and isBackSide
                    else
                        p1 = ent:LocalToWorld(p1)
                        p2 = ent:LocalToWorld(p2)
                        p3 = ent:LocalToWorld(p3)
                        p4 = ent:LocalToWorld(p4)
                    end

                    if doRender then
                        local clr_temp = Lhv.Data_3D.Color
                        if not clr_temp then clr_temp = VC.ColorCopyAlpha(clr_m, 255) end
                        if Lhv.SpecFade and Lhv.SpecFade.alter3D and Lhv.SpecFade.cur then clr_temp.a = 255 * Lhv.SpecFade.cur.final end
                        render.DrawQuad(p1, p2, p3, p4, clr_temp)
                    end
                end

                local vis_org = vis
                if Lhv.ReducedVis or true then
                    vis = vis * 0.65
                    clr_p.a = vis
                end

                local size_glow_extra = Lhv.OnELS and VC.getSetting("ELS_ExtraGlow")
                local size_main_extra = not Lhv.DD_Main and VC.getSetting("Light_Main")
                local size_HD = not Lhv.DD_HD and VC.getSetting("Light_HD") and InDetail
                local size_glow = not Lhv.DD_Glow and VC.getSetting("Light_Glow") and InDetail
                local size_mid = VC.getSetting("Light_Warm") and InDetail and (Lhv.RenderInner or clr_ovr)
                if size_main_extra then size_main_extra = VC.getSetting("Light_Main_M") end
                if size_HD then
                    size_HD = VC.getSetting("Light_HD_M")
                    if Lhv.RenderHD_Size then size_HD = size_HD * Lhv.RenderHD_Size end
                end

                if size_glow then
                    size_glow = VC.getSetting("Light_Glow_M")
                    if Lhv.RenderGlow_Size then size_glow = size_glow * Lhv.RenderGlow_Size end
                end

                if size_mid then
                    size_mid = VC.getSetting("Light_Warm_M")
                    if Lhv.RenderInner_Size then size_mid = size_mid * Lhv.RenderInner_Size end
                end

                if size_glow_extra then size_glow_extra = VC.getSetting("ELS_ExtraGlow_M") end
                if hasLayers and not carReplaceDetail then
                    if Lhv.SpecTableBeam and size_mid then
                        local count_seg = table.Count(Lhv.SpecTableBeam)
                        local clr_beam = VC.ColorCopyAlpha(clr_m, vis_org)
                        render.SetMaterial(VC.Material.Beam)
                        render.StartBeam(count_seg)
                        local size_temp = size_main * size_mid / 10
                        size_mid = false
                        for i = 1, count_seg do
                            local size_temp_new = size_temp
                            if Lhv.SpecTableBeam[i].Size then size_temp_new = size_temp * Lhv.SpecTableBeam[i].Size end
                            local clr_beamSeq = Lhv.SpecTableBeam[i].Clr
                            if not clr_beamSeq then clr_beamSeq = clr_beam end
                            render.AddBeam(ent:LocalToWorld(Lhv.SpecTableBeam[i].Pos), size_temp_new, CurTime() + i, clr_beamSeq)
                        end

                        render.EndBeam()
                    end

                    if size_mid and (Lhv.SpecRec and Lhv.SpecRec.InnerCenterOnly or Lhv.SpecCircle and Lhv.SpecCircle.InnerCenterOnly) then
                        render.SetMaterial(VC.Material.Reg)
                        renderInner(pos_world, size_main / 2.5 * size_mid, VC.ColorCopyAlpha(clr_m, vis), Lhv.inner_AsSpheres and {
                            prev_mat = VC.Material.Reg
                        })

                        size_mid = false
                    end

                    local count_seg = table.Count(Lhv.SpecTable)
                    if Lhv.RenderHD_Adv and size_HD then
                        local size_temp = size_glow_mid * size_HD
                        if size_mult then size_temp = size_temp * size_mult end
                        render.SetMaterial(VC.HD_Texture)
                        render.DrawSprite(pos_world, size_temp * 3, size_temp, clr_p)
                    end

                    if size_mid or size_main_extra then
                        render.SetMaterial(VC.Material.Reg)
                        local size_temp = size_main / 2.5
                        local LastPos = nil
                        VC.DrawMainHolt = false
                        local lastBlinkerOnTime, seqEachOnTime = nil, nil
                        if seqData and seqData.count == 1 then
                            lastBlinkerOnTime = ent.VC_Lights_RanTimes[col]
                            seqEachOnTime = seqData.time / (count_seg + 1)
                        end

                        for i = 1, count_seg do
                            local cur = i
                            if Lhv.SpecTable[cur] and (not lastBlinkerOnTime or CurTime() >= (lastBlinkerOnTime + seqEachOnTime * cur) and (seqData.stay or CurTime() <= (lastBlinkerOnTime + seqEachOnTime * (cur + 1)))) then
                                if lastBlinkerOnTime and seqData.reversed then cur = (count_seg - i) + 1 end
                                local pos_temp = ent:LocalToWorld(Lhv.SpecTable[cur])
                                if size_mid then
                                    renderInner(pos_temp, size_temp * size_mid, VC.ColorCopyAlpha(clr_m, vis_org), Lhv.inner_AsSpheres and {
                                        prev_mat = VC.Material.Reg
                                    })
                                end

                                if size_main_extra then
                                    if true or Lhv.Beta_Inner3D then
                                        if not VC.DrawMainHolt or not Lhv.DrawingSpecMLine then
                                            local clr_temp = table.Copy(clr_p)
                                            clr_temp.a = clr_temp.a / 5
                                            local size_temp = size_main * size_main_extra * 3
                                            render.DrawSprite(pos_temp, size_temp, size_temp, clr_temp)
                                            VC.DrawMainHolt = count_seg > 2
                                        else
                                            VC.DrawMainHolt = false
                                        end
                                    else
                                        local size_temp = size_main * size_main_extra
                                        render.DrawSprite(pos_temp, size_temp, size_temp, clr_p)
                                    end
                                end
                            end
                        end
                    end

                    if size_glow then
                        local size_temp = size_glow_mid * size_glow * 1.5
                        render.SetMaterial(VC.Material.Glow)
                        if size_glow_extra then
                            size_temp = size_temp * 7 * size_glow_extra
                            render.DrawSprite(pos_world, size_temp, size_temp, VC.ColorCopyAlpha(clr_p, clr_p.a * 0.06))
                        else
                            size_temp = size_temp * 1.2
                            render.DrawSprite(pos_world, size_temp, size_temp, VC.ColorCopyAlpha(clr_p, clr_p.a * 0.15))
                        end
                    end
                else
                    local HLSOf = nil
                    if Lhv.UsePrjTex then
                        prxtext_offset = Lhv.OnFog and 0.6 or Lhv.OnHighBeams and 0.4 or 0.5
                        local CAng = Lhv.OnFog and 75 or Lhv.OnHighBeams and 33 or 60
                        local Ang = math.abs(VC.AngleDifference(VC.AngleCombCalc(ent:GetForward():Angle(), Angle(30, 0, 0)), (pos_world - EyePos()):Angle()) - 90)
                        if Ang < CAng then
                            LightBeamVis = VC.EaseInOut(Ang / CAng)
                            prxtext_offset = prxtext_offset + (1 - LightBeamVis) * ((Lhv.OnFog and 0.25 or Lhv.OnHighBeams and 0.6 or 0.3) + (150 - size_main) / 100)
                        end

                        HLSOf = (size_main / 1.5 + vis / 255) * prxtext_offset
                    end

                    size_main = size_main * 0.85
                    local sizePriorToHeadLight = size_main
                    size_main = size_main * prxtext_offset
                    if not HLSOf then HLSOf = size_main end
                    render.SetMaterial(VC.Material.Reg)
                    if size_mid then
                        renderInner(pos_world, size_main / 2.5 * size_mid, VC.ColorCopyAlpha(clr_m, vis), Lhv.inner_AsSpheres and {
                            size = sizePriorToHeadLight / 2.5 * size_mid,
                            prev_mat = VC.Material.Reg
                        })
                    end

                    if size_main_extra then
                        HLSOf = HLSOf * size_main_extra * (hasLayers and carReplaceDetail and 5 or 1)
                        render.DrawSprite(pos_world, HLSOf, HLSOf, clr_p)
                    end

                    if size_HD then
                        size_main = size_main * size_HD
                        if size_main > 2 then
                            local NVis = vis - 100
                            if NVis > 0 then
                                local clr = VC.ColorCopyAlpha(clr_p, NVis)
                                render.SetMaterial(VC.HD_Texture)
                                render.DrawSprite(pos_world, size_main / 3, size_main * 3, clr)
                                render.DrawSprite(pos_world, size_main * 3, size_main, clr)
                            end
                        end
                    end

                    if size_glow then
                        local Sz = size_glow_mid * 3 * prxtext_offset * size_glow
                        render.SetMaterial(VC.Material.Glow)
                        if Lhv.ReducedVis or true then clr_p.a = clr_p.a * 1.535 end
                        if size_glow_extra then
                            Sz = Sz * 2 * size_glow_extra
                            render.DrawSprite(pos_world, Sz, Sz, VC.ColorCopyAlpha(clr_p, clr_p.a * 0.05))
                        else
                            Sz = Sz * 1.1
                            render.DrawSprite(pos_world, Sz, Sz, VC.ColorCopyAlpha(clr_p, clr_p.a * 0.11))
                        end
                    end
                end
            end

            if InDetail then
                handlePrjText(ent, Lhv, clr_p, LightBeamVis, pos_world, ang_local, pos_local)
                if SpinningSizeSync and Lhv.Data_3D and VC.getSetting("Light_3D") and Lhv.SpecSpin and Lhv.SpecSpin.Use and not Lhv.SpecSpin.dd_beam then
                    render.SetMaterial(VC.Material.HBeam)
                    local FP = (pos_world - ent:GetRight() * 200) - pos_world
                    FP:Rotate(SpinningAngSync + Angle(0, 180 - (Lhv.SpecSpin.Rotated and 90 or 0), 0))
                    render.DrawBeam(pos_world, pos_world + FP, 200, 1, 0, VC.ColorCopyAlpha(clr_p, 2 + 15 * SpinningSizeSync))
                end
            end
        end

        handleSpecModel(ent, Lhk, Lhv, colid, col, pos_world, pos_local, ang_local, NotDark, distnum, size_mult)
        handleDyn(ent, Lhk, Lhv, colid, clr_p, pos_world, pos_local, NotDark, distnum, size_mult)
        local Type = 1
        if Lhv.OnHighBeams then Type = 2 end
        if Lhv.OnFog then Type = 3 end
        ent.VC_LastRenderedL[Lhk] = Lhv[col]
    end
end

local function Handle_Light_Draw_Multi(ent, ltable, GTbl, col, colid, sideid, distnum)
    for Lhk, Lhv in pairs(ltable) do
        if Lhv and Lhv.Pos then
            local can = true
            local seqData = nil
            local notblnk = col ~= "BlinkersColor"
            if notblnk then
                if Lhv.DD_Blnk_Run then
                    local on = VC.GetState(ent, "HazardLightsOn")
                    if on then
                        can = false
                    else
                        if Lhv.Pos.x < 0 then
                            can = not on and not VC.GetState(ent, "TurnLightLeftOn")
                        else
                            can = not on and not VC.GetState(ent, "TurnLightRightOn")
                        end
                    end
                end

                local ELSSel = nil
                local state = VC.GetState(ent, "ELS_Lht_Sel", 0)
                local state_disabled = VC.GetState(ent, "ELS_L_Disabled")
                if can and Lhv.DD_ELS1 then
                    if not ELSSel then ELSSel = state end
                    if not state_disabled and ELSSel == 1 then can = false end
                end

                if can and Lhv.DD_ELS2 then
                    if not ELSSel then ELSSel = state end
                    if not state_disabled and ELSSel == 2 then can = false end
                end

                if can and Lhv.DD_ELS3 then
                    if not ELSSel then ELSSel = state end
                    if not state_disabled and ELSSel == 3 then can = false end
                end

                if can and Lhv.DD_if_LBeam then can = not VC.GetState(ent, "LowBeamsOn") end
                if can and Lhv.DD_if_brakes then can = not ent:GetNWBool("VC_Lights_Brake_Created", false) end
            end

            if can then
                local seqStart = ent.VC_Lights_RanTimes[col]
                if seqStart and GTbl.LPT_Seq and GTbl.LPT_Seq[0][Lhk] then
                    local tempData = GTbl.LPT_Seq[GTbl.LPT_Seq[0][Lhk]][Lhk]
                    if CurTime() < seqStart + tempData.timeOn or not tempData.seq_stay and CurTime() > seqStart + tempData.timeOff then can = nil end
                    seqData = {
                        time = tempData.timeOff,
                        stay = tempData.seq_stay,
                        count = table.Count(GTbl.LPT_Seq[GTbl.LPT_Seq[0][Lhk]]),
                        reversed = tempData.reversed
                    }
                end
            end

            if can then VC_freemannsinexeca(ent, Lhk, Lhv, col, colid, sideid, distnum, nil, seqData) end
        end
    end
end

local function canByDistance(ent)
    return VC.GetViewPos():Distance(ent:GetPos()) < 9000
end

function VC.StatesHandleInit(ent)
    if not ent.VC_SatesInitialized then
        ent.VC_SatesInitialized = true
        net.Start("VC_StatesRequestInit")
        net.WriteEntity(ent)
        net.SendToServer()
    end
end

local function DataReqCheck(ent)
    if not ent.VC_Model_IsNull then
        if not ent.VC_Model then
            local tmdl = VC.Global_Model_Names[ent:GetModel()]
            if tmdl then
                ent.VC_Model = tmdl
                VC.Initialize_PostModel(ent)
            elseif canByDistance(ent) then
                net.Start("VC_RequestVehData_Model")
                net.WriteEntity(ent)
                net.SendToServer()
            end
        end
    end

    VC.StatesHandleInit(ent)
end

local function HandleSpecMat(ent)
    if ent.VC_Light_SpecMat then
        for k, v in pairs(ent.VC_Light_SpecMat) do
            local can = false
            for k2, v2 in pairs(v) do
                if can then
                    if ent.VC_LastRenderedL[k2] then
                        can = false
                        break
                    end
                elseif not ent.VC_LastRenderedL[k2] then
                    can = k2
                end
            end

            if can then
                ent:SetSubMaterial(k - 1, nil)
                ent.VC_Light_SpecMat[k][can] = nil
            end

            if table.Count(ent.VC_Light_SpecMat[k]) == 0 then ent.VC_Light_SpecMat[k] = nil end
        end

        if table.Count(ent.VC_Light_SpecMat) == 0 then ent.VC_Light_SpecMat = nil end
    end
end

concommand.Add("VC_BETA_PDTR", function(ply)
    if not VC_BETA_PDTR then
        VC_BETA_PDTR = true
    else
        VC_BETA_PDTR = nil
    end
end)

local function drawDashboard(ent)
    local sData = VC_suckfreemmann(ent)
    if sData and sData.dash and sData.dash.enabled then
        local pos = sData.dash.pos or Vector(0, 0, 0)
        local ang = sData.dash.ang or Angle(0, 0, 0)
        local bg_scale = sData.dash.bg_scale or 1
        local bg_stretch_h = sData.dash.bg_stretch_h or 1
        local mat = sData.dash.bg_mat
        if not VC.Material[mat] then VC.Material[mat] = Material(mat) end
        mat = VC.Material[mat]
        local bg_clr = sData.dash.bg_color or Color(0, 0, 0, 255)
        bg_clr.a = sData.dash.bg_tr or 225
        cam.Start3D2D(ent:LocalToWorld(pos), ent:LocalToWorldAngles(ang), 0.1)
        surface.SetDrawColor(bg_clr)
        surface.SetMaterial(mat)
        surface.DrawTexturedRect(-100 * bg_scale, -100 * bg_scale, 200 * bg_scale, 200 * bg_scale)
        cam.End3D2D()
    end
end

local function handleLightsAnim(ent, id, id_clr, lData, GTbl, tid, ptid)
    id = id .. "Color"
    local idtime = ent.VC_Lights_RanTimes[id]
    if id_clr then
        if not idtime then ent.VC_Lights_RanTimes[id] = CurTime() end
    elseif idtime then
        ent.VC_Lights_RanTimes[id] = nil
    end
end

local function dohandleLights(ent, CBR, id, id_clr, lData, GTbl, tid, ptid, passive)
    local can = nil
    if passive then
        can = CBR:GetNWBool("VC_Lights_" .. id_clr .. "_Created", false)
    else
        local id_state = ""
        local sData = VC.StatesByID[id]
        if sData then id_state = sData.id_state end
        can = VC.GetState(CBR, id_state)
    end

    if can then
        Handle_Light_Draw_Multi(ent, lData, GTbl, id .. "Color", tid, ptid, ent.VC_Lht_DstCheckMult or 0)
        return ent, id, id_clr, lData, GTbl, tid, ptid
    end
end

local function handleLights(ent, CBR, id, id_clr, LhtTbl, GTbl, tid, ptid, passive)
    local lData = LhtTbl[id]
    if lData then return dohandleLights(ent, CBR, id, id_clr, lData, GTbl, tid, ptid, passive) end
end

function VC.FTmRender()
    return 1
end

local function handleRenderQueModel(ent)
    if ent.VC_renderQueModel then
        for id, v in pairs(ent.VC_renderQueModel) do
            if not ent.VC_LastRenderedL or not ent.VC_LastRenderedL[id] then
                VC.unregisterEntity(ent, id)
                ent.VC_renderQueModel[id] = nil
            end
        end
    end
end

hook.Add("PostDrawTranslucentRenderables", "VC_PostDrawTranslucentRenderables", function()
    VC.FrameTimeRender = (CurTime() - (VC.FrameTimeRenderLast or CurTime())) * 100
    VC.FrameTimeRenderLast = CurTime()
    EyePos()
    if not VC.getSetting("Enabled") then return end
    if VC.isPlayerInWorld then return end
    VC.IsViewerSelf = VC.CheckViewerIsSelf()
    local veh, veh_main = VC.getVehicleMain(LocalPlayer():GetVehicle(), true)
    VC.InVehicleMain = veh_main
    VC.InVehicleAndTP = veh and VC.isThirdPerson(veh)
    local CanUpdate = not VC.SyncTimeCheck or CurTime() >= VC.SyncTimeCheck
    for _, ent in pairs(VC.GetVehicleList()) do
        if IsValid(ent) then
            if VC_BETA_PDTR then
                if type(VC_BETA_PDTR) ~= "table" then
                    VC_BETA_PDTR = {}
                    VCMsg("Switching to BETA light rendering.")
                end
            else
                if CanUpdate then DataReqCheck(ent) end
                if VC.hasGlobalOD(ent.VC_Model) and (VC.ElectronicsOn(ent) or not ent:IsVehicle()) then
                    if VC.getSetting("HUD_Dashboard") or vcmod_dev then drawDashboard(ent) end
                    local PRenL = ent.VC_LastRenderedL
                    ent.VC_LastRenderedL = {}
                    local MEnt = ent.VC_ExtraSeat and ent:GetParent() or ent
                    if VC.Handle_PDTR_Alarm then VC.Handle_PDTR_Alarm(ent) end
                    ent.VC_HDPTR_Vis_Cache = {}
                    if ent.VC_Lht_DstCheckMult then
                        if ent.VC_Lht_DstCheck_B then
                            if ent.VC_Lht_DstCheckMult < 1 then
                                ent.VC_Lht_DstCheckMult = ent.VC_Lht_DstCheckMult + 0.01 * VC.FTmRender()
                                if ent.VC_Lht_DstCheckMult > 1 then ent.VC_Lht_DstCheckMult = 1 end
                            end
                        elseif ent.VC_Lht_DstCheckMult > 0 then
                            ent.VC_Lht_DstCheckMult = ent.VC_Lht_DstCheckMult - 0.01 * VC.FTmRender()
                            if ent.VC_Lht_DstCheckMult < 0 then ent.VC_Lht_DstCheckMult = 0 end
                        end
                    end

                    if ent.VC_Lht_DstCheckMult and ent.VC_Lht_DstCheckMult > 0 and ent.VC_notCenter and not ent.VC_isNoDraw then
                        local CBR = VC.getTruck(ent)
                        local GTbl = freemannsuck(ent.VC_Model)
                        local LhtTbl = GTbl.LightTable
                        if VC.HandleELSLights and LhtTbl then VC.HandleELSLights(ent, LhtTbl, PRenL) end
                        if LhtTbl then
                            local id = "Brake"
                            handleLightsAnim(ent, id, handleLights(ent, CBR, id, id, LhtTbl, GTbl, 2, nil, true))
                            local id = "Running"
                            handleLightsAnim(ent, id, handleLights(ent, CBR, id, id, LhtTbl, GTbl, 3))
                            local id = "Fog"
                            handleLightsAnim(ent, id, handleLights(ent, CBR, id, id, LhtTbl, GTbl, 10))
                            local id = "Reverse"
                            handleLightsAnim(ent, id, handleLights(ent, CBR, id, id, LhtTbl, GTbl, 4, nil, true))
                            local id = "Inter"
                            handleLightsAnim(ent, id, handleLights(ent, CBR, id, id, LhtTbl, GTbl, 8, nil, true))
                            if not VC.GetState(ent, "HighBeamsOn") then
                                local id = "LBeam"
                                handleLightsAnim(ent, id, handleLights(ent, CBR, id, id, LhtTbl, GTbl, 5))
                            end

                            local id = "HBeam"
                            handleLightsAnim(ent, id, handleLights(ent, CBR, id, id, LhtTbl, GTbl, 5))
                            local lData = LhtTbl.Blinker
                            if lData then
                                local ran, id = nil, "Blinkers"
                                local id_clr = "Alarm"
                                if dohandleLights(ent, CBR, id, id_clr, lData, GTbl, 6, nil, true) then ran = id_clr end
                                local id_clr = "Hazards"
                                if dohandleLights(ent, CBR, id, id_clr, lData, GTbl, 6, nil, true) then ran = id_clr end
                                local id_clr = "BlinkerLeft"
                                if dohandleLights(ent, CBR, id, id_clr, lData, GTbl, 6, 1, true) then ran = id_clr end
                                local id_clr = "BlinkerRight"
                                if dohandleLights(ent, CBR, id, id_clr, lData, GTbl, 6, 2, true) then ran = id_clr end
                                handleLightsAnim(ent, id, ran)
                            end
                        end

                        if ent:GetNWBool("VC_Lights_Door_Created", false) then
                            local sData = VC_suckfreemmann(ent)
                            if sData.semiData_doorLightPos then
                                VC_freemannsinexeca(ent, -45, {
                                    Pos = sData.semiData_doorLightPos,
                                    UseSprite = true,
                                    Sprite = {
                                        Size = 0.1
                                    },
                                    UseDynamic = true,
                                    Dynamic = {
                                        Brightness = 5,
                                        Size = 0.5
                                    },
                                    DoorColor = Color(255, 255, 255, 255),
                                    RenderType = 2
                                }, "DoorColor", 1, nil, ent.VC_Lht_DstCheckMult)
                            end
                        end
                    end
                end

                HandleSpecMat(ent)
                handleRenderQueModel(ent)
            end
        end
    end

    if CanUpdate then
        for k, v in pairs(VC.PrjTextures) do
            if not IsValid(ents.GetByIndex(k)) then
                for k2, v2 in pairs(v) do
                    if IsValid(v2.pt) then v2.pt:Remove() end
                end

                VC.PrjTextures[k] = nil
            end
        end

        VC.SyncTimeCheck = CurTime() + 1.5
    end
end)

local def_clr, def_val = Color(0, 0, 0, 0), 1
hook.Add("PreDrawHalos", "VC_PreDrawHalos", function()
    if not VC.registeredEntitiesDrawHalo then return end
    if VC.isPlayerInWorld then return end
    for k, v in pairs(VC.registeredEntitiesDrawHalo) do
        if not IsValid(v) or not v.VC_registeredEntitiesDrawHalo then
            VC.registeredEntitiesDrawHalo[k] = nil
            if #VC.registeredEntitiesDrawHalo == 0 then
                VC.registeredEntitiesDrawHalo = nil
                return
            end
        end

        if v.VC_registeredEntitiesDrawHalo and VC.isClose(v) then
            for k2, v2 in pairs(v.VC_registeredEntitiesDrawHalo) do
                if not IsValid(v2) then
                    v.VC_registeredEntitiesDrawHalo[k2] = nil
                    if #v.VC_registeredEntitiesDrawHalo == 0 then
                        v.VC_registeredEntitiesDrawHalo = nil
                        return
                    end
                end

                local data = v2.dataGlow
                if data then
                    halo.Add({v2}, data.Color or def_clr, data.blur or def_val, data.blur or def_val, data.passes or def_val)
                else
                    v.VC_registeredEntitiesDrawHalo[k2] = nil
                end
            end
        end
    end
end)

if not VC.CodeEnt.Repair_Wep then VC.CodeEnt.Repair_Wep = {} end
VC.CodeEnt.Wep_DrawSelection = function(self, x, y, w, t, a)
    if self.VC_WepSelectIcon then
        local clr = Color(255, 255, 0, a)
        surface.SetDrawColor(clr)
        surface.SetMaterial(self.VC_WepSelectIcon)
        draw.DrawText("VCMod", "VC_DEV_lower", x + 10, y + 10, clr, TEXT_ALIGN_LEFT)
        local size = 80
        surface.DrawTexturedRect(x + w / 2 - size / 2, y + t / 2 - size / 2, size, size)
    end
end

VC.CodeEnt.Repair_Wep.Initialize = function(self) self:SetWeaponHoldType("melee") end
VC.CodeEnt.Repair_Wep.GetViewModelPosition = function(self, pos, ang)
    if not vcmod1 then return end
    local FTm = VC.FTm()
    local ent = self:GetNWEntity("VC_DamagedEnt")
    if not self.VC_PastAngleInt then self.VC_PastAngleInt = 0 end
    if not self.VC_FixingInt then self.VC_FixingInt = 0 end
    local start, finish = self:GetNWInt("VC_DoingStart", 0), self:GetNWInt("VC_DoingFinish", 0)
    if start > 0 then
        if not self.VC_Sound then self.VC_Sound = CreateSound(self, "vcmod/socket_wrench.wav") end
        local time = finish - start
        local prc = math.Clamp(1 - (finish - CurTime()) / time, 0, 1)
        if self.VC_Sound and self.VC_Sound:IsPlaying() then self.VC_Sound:ChangePitch(105 - prc * 15) end
        if not self.VC_FixingIntDec then
            self.VC_FixingInt = self.VC_FixingInt + 0.03 * FTm
            if self.VC_FixingInt > 1 then
                self.VC_FixingInt = 1
                self.VC_FixingIntDec = true
                if self.VC_Sound and not self.VC_Sound:IsPlaying() then self.VC_Sound:Play() end
            else
                if self.VC_Sound and self.VC_Sound:IsPlaying() then self.VC_Sound:Stop() end
            end
        else
            local Extra = prc / 35
            self.VC_FixingInt = self.VC_FixingInt - (0.03 - Extra) * FTm
            if self.VC_FixingInt < 0 then
                self.VC_FixingInt = 0
                self.VC_FixingIntDec = false
            end
        end
    else
        if self.VC_Sound and self.VC_Sound:IsPlaying() then self.VC_Sound:Stop() end
        if self.VC_FixingInt > 0 then
            self.VC_FixingInt = self.VC_FixingInt - 0.02 * FTm
            if self.VC_FixingInt < 0 then self.VC_FixingInt = 0 end
        end
    end

    local FixAng = Angle(0, 0, 0)
    if self.VC_FixingInt > 0 then FixAng = LerpAngle(VC.EaseInOut(self.VC_FixingInt), FixAng, Angle(18, -10, -60)) end
    if IsValid(ent) then
        if self.VC_PastAngleInt < 1 then
            self.VC_PastAngleInt = self.VC_PastAngleInt + 0.05 * FTm
            if self.VC_PastAngleInt > 1 then self.VC_PastAngleInt = 1 end
        end
    elseif self.VC_PastAngleInt > 0 then
        self.VC_PastAngleInt = self.VC_PastAngleInt - 0.02 * FTm
        if self.VC_PastAngleInt < 0 then self.VC_PastAngleInt = 0 end
    end

    if self.VC_PastAngleInt > 0 then
        local aimang = IsValid(ent) and (ent:LocalToWorld(self:GetNWVector("VC_DamagedPos"), Vector(0, 0, 0)) - LocalPlayer():EyePos()):Angle() or ang
        local angdif = VC.AngleDifference_Ex(aimang, EyeAngles())
        self.VC_PastAngle = LerpAngle((IsValid(ent) and 0.05 or 0.01) * FTm, self.VC_PastAngle or ang, aimang + Angle(0, 100 / (angdif.y > 5 and angdif.y or 5), 0))
        ang = LerpAngle(VC.EaseInOut(self.VC_PastAngleInt), ang, self.VC_PastAngle)
    else
        self.VC_PastAngle = nil
        if self.VC_Sound and self.VC_Sound:IsPlaying() then self.VC_Sound:Stop() end
    end
    return pos, ang + FixAng
end

VC.CodeEnt.Repair_Wep.Holster = function(self)
    if self.VC_Sound and self.VC_Sound:IsPlaying() then self.VC_Sound:Stop() end
    return true
end

net.Receive("VC_SentToClient_FuelNozzle_PickedUp", function()
    local ent = net.ReadEntity()
    VC.PickedUpNozzle_Time = CurTime()
end)

if not VC.CodeEnt.Fuel_station then VC.CodeEnt.Fuel_station = {} end
VC.CodeEnt.Fuel_station.Draw = function(self)
    self:DrawModel()
    if not self.VC_DistCheckT or CurTime() >= self.VC_DistCheckT then
        self.VC_DistCheckT = CurTime() + 2
        self.VC_Dist = VC.GetViewPos():Distance(self:GetPos())
    end

    if self.VC_Dist > 1500 then return end
    local tr = {}
    if self.VC_Dist < 100 then
        tr = util.TraceLine({
            start = LocalPlayer():GetShootPos(),
            endpos = LocalPlayer():GetShootPos() + LocalPlayer():GetAimVector() * 90,
            filter = LocalPlayer()
        })
    end

    local ftype = self.VC_FuelType or 0
    local ftypetbl = VC.FuelTypes[ftype]
    local price = math.Round(VC.getServerSetting("Fuel_PPL_" .. ftype, 1), 2)
    local symbol = VC.getCurCurrency().symbol
    cam.Start3D2D(self:LocalToWorld(Vector(10.2, -8.8, 57.6)), self:LocalToWorldAngles(Angle(0, 90, 62)), 0.1)
    local Px, Py = 0, 47
    local Sx, Sy = 176, 150
    draw.RoundedBox(0, Px, Py, Sx, Sy, false and ftypetbl.clr or Color(55, 100, 255, 250))
    local text = "Active"
    if self:GetNWBool("VC_Hitched", false) then text = "Idle" end
    local cur, max = self:GetNWInt("VC_Pumped", 0), self:GetNWInt("VC_PumpedGoal", 0)
    local perc = max > 0 and cur / max or 0
    if self:GetNWBool("VC_Pumping", false) then text = "Pumping" end
    draw.RoundedBox(0, Px + 5, Py + Sy - 15, Sx - 10, 10, VC.Color.White)
    draw.RoundedBox(0, Px + 5, Py + Sy - 15, (Sx - 10) * perc, 10, Color(55, 155, 55, 255))
    draw.DrawText(VC.Lng(text), "VC_DEV_lower", Px + Sx / 2, Py + Sy - 17, VC.Color.Main, TEXT_ALIGN_CENTER)
    local sel = 0
    if self.VC_Dist < 100 and IsValid(tr.Entity) and tr.Entity == self then
        local pos = tr.Entity:WorldToLocal(tr.HitPos)
        if pos.y > -8 and pos.y < 8 and pos.z > 37 and pos.z < 50 then
            if pos.y < -4 then
                sel = 1
            elseif pos.y > 4 then
                sel = 2
            elseif pos.z < 44 then
                sel = 3
            end
        end
    end

    if sel == 1 then
        surface.SetDrawColor(255, 255, 255, 255)
    else
        surface.SetDrawColor(0, 0, 255, 155)
    end

    surface.SetMaterial(VC.Material.icon_left)
    surface.DrawTexturedRect(Px + 10, Py + Sy * 0.4, 20, 75)
    if sel == 2 then
        surface.SetDrawColor(255, 255, 255, 255)
    else
        surface.SetDrawColor(0, 0, 255, 155)
    end

    surface.SetMaterial(VC.Material.icon_right)
    surface.DrawTexturedRect(Px + Sx - 10 - 20, Py + Sy * 0.4, 20, 75)
    if sel == 3 then
        surface.SetDrawColor(25, 155, 25, 255)
    else
        surface.SetDrawColor(0, 0, 255, 155)
    end

    surface.SetMaterial(VC.Material.Button)
    surface.DrawTexturedRect(Px + 10 + 20 + 10, Py + Sy * 0.65, Sx - 80, 25)
    draw.DrawText(VC.Lng("Purchase"), "VC_Regular2", Px + Sx / 2, Py + Sy * 0.68, VC.Color.White, TEXT_ALIGN_CENTER)
    local cursel = self:GetNWInt("VC_Selected", 0)
    local purchcount = VC.LiterToAuto(self:GetNWInt("VC_Purchased", 0), self.VC_FuelType)
    local purchcount2 = VC.LiterToAuto(cursel, self.VC_FuelType)
    if self.VC_FuelType == 2 then
        draw.DrawText(purchcount2 .. " " .. VC.TextToAuto(self.VC_FuelType) .. " (" .. (symbol .. math.Round(price * purchcount2 * 100) / 100) .. ")", "VC_DEV_lower", Px + Sx / 2, Py + Sy * 0.68 - 20, VC.Color.White, TEXT_ALIGN_CENTER)
    else
        draw.DrawText(purchcount2 .. " " .. VC.TextToAuto(self.VC_FuelType) .. " (" .. (symbol .. math.Round(price * cursel * 100) / 100) .. ")", "VC_DEV_lower", Px + Sx / 2, Py + Sy * 0.68 - 20, VC.Color.White, TEXT_ALIGN_CENTER)
    end

    draw.DrawText(VC.Lng(ftypetbl.name) .. " (" .. VC.Lng(VC.Lng(ftypetbl.shrt)) .. ")", "VC_Name", Px + Sx / 2, Py + 5, VC.Color.White, TEXT_ALIGN_CENTER)
    draw.DrawText(VC.Lng("Price"), "VC_DEV_lower", Px + 10, Py + 40, VC.Color.White, TEXT_ALIGN_LEFT)
    draw.DrawText(symbol .. price .. "/" .. VC.TextToAuto(self.VC_FuelType), "VC_DEV_lower", Px + Sx - 10, Py + 40, VC.Color.White, TEXT_ALIGN_RIGHT)
    draw.DrawText(VC.Lng("Purchased"), "VC_DEV_lower", Px + 10, Py + 55, VC.Color.White, TEXT_ALIGN_LEFT)
    draw.DrawText(purchcount .. " " .. VC.TextToAuto(self.VC_FuelType), "VC_DEV_lower", Px + Sx - 10, Py + 55, VC.Color.White, TEXT_ALIGN_RIGHT)
    draw.DrawText(VC.Lng("Price"), "VC_DEV_lower", Px + 10, Py + 40, VC.Color.White, TEXT_ALIGN_LEFT)
    cam.End3D2D()
    cam.Start3D2D(self:LocalToWorld(Vector(5, 15.5, 55)), self:LocalToWorldAngles(Angle(0, 180, 83)), 0.1)
    surface.SetDrawColor(255, 255, 255, 255)
    surface.SetMaterial(VC.Material.Icon)
    surface.DrawTexturedRect(0, 0, 100, 100)
    cam.End3D2D()
end

if not VC.CodeEnt.Spikestrip then VC.CodeEnt.Spikestrip = {} end
VC.CodeEnt.Spikestrip.Think = function(self)
    if self.VC_DeployedInt then self:SetPoseParameter("deploy", self.VC_DeployedInt) end
    if self:GetNWBool("VC_Deployed", false) then
        if not self.VC_DeployedInt then self.VC_DeployedInt = 0 end
        if self.VC_DeployedInt < 1 then
            self.VC_DeployedInt = self.VC_DeployedInt + 0.05 * VC.FTm()
            if self.VC_DeployedInt > 1 then self.VC_DeployedInt = 1 end
        end
    elseif self.VC_DeployedInt then
        self.VC_DeployedInt = self.VC_DeployedInt - 0.015 * VC.FTm()
        if self.VC_DeployedInt < 0 then self.VC_DeployedInt = nil end
    end
end

if not VC.CodeEnt.Spikestrip_wep then VC.CodeEnt.Spikestrip_wep = {} end
VC.CodeEnt.Spikestrip_wep.Initialize = function(self) self:SetWeaponHoldType("physgun") end
VC.CodeEnt.Spikestrip_wep.Think = function(self)
    if self.VC_Doing then
        if not VC.Model_Spikestrip_wep then
            VC.Model_Spikestrip_wep = ClientsideModel("models/sentry/vc_spikestrip.mdl", RENDERGROUP_OPAQUE)
            VC.Model_Spikestrip_wep:SetParent(self)
            local id = "ent_spikestripwep_" .. self:EntIndex()
            VC_freemanngnida(self.VC_Model, self, id)
        end

        if IsValid(VC.Model_Spikestrip_wep) then
            VC.Model_Spikestrip_wep:SetPos(self.VC_LastTr.HitPos)
            VC.Model_Spikestrip_wep:SetAngles(Angle(0, EyeAngles().y - 90, 0))
            VC.Model_Spikestrip_wep:SetPoseParameter("deploy", (math.sin(CurTime()) + 1) / 2 * (self.VC_DoingLerp or 0))
            VC.Model_Spikestrip_wep:SetMaterial("models/wireframe")
        end
    else
        if IsValid(VC.Model_Spikestrip_wep) then
            VC.Model_Spikestrip_wep:Remove()
            VC.Model_Spikestrip_wep = nil
        end
    end
end

VC.CodeEnt.Spikestrip_wep.Holster = function(self, pos, ang)
    if IsValid(VC.Model_Spikestrip_wep) then VC.Model_Spikestrip_wep:Remove() end
    VC.Model_Spikestrip_wep = nil
    self.VC_DoingLerp = nil
end

VC.CodeEnt.Spikestrip_wep.GetViewModelPosition = function(self, pos, ang)
    if not vcmod1 then return end
    local FTm = VC.FTm()
    local doing = false
    if EyeAngles().p > 45 then
        local tr = LocalPlayer():GetEyeTraceNoCursor()
        self.VC_LastTr = tr
        doing = tr.Hit and tr.HitPos:Distance(LocalPlayer():EyePos()) < 100
    end

    self.VC_Doing = doing
    local FixAng = Angle(-10, 8, -8)
    local FixPos = Vector(0, 0, 0)
    local ReaddyPos = Vector((math.sin(CurTime()) + 1) * 0.3 * math.sin(CurTime() * 1), -8 + (math.sin(CurTime()) + 1) / 2 * math.sin(CurTime() * 0.75), 12 + (math.sin(CurTime()) + 1) * 0.2 * math.sin(CurTime() * 0.5))
    FixPos = FixPos + ang:Right() * ReaddyPos.x
    FixPos = FixPos - ang:Forward() * ReaddyPos.y
    FixPos = FixPos - ang:Up() * ReaddyPos.z
    if doing then
        if not self.VC_DoingLerp then self.VC_DoingLerp = 0 end
        if self.VC_DoingLerp < 1 then
            self.VC_DoingLerp = self.VC_DoingLerp + 0.02 * FTm
            if self.VC_DoingLerp > 1 then self.VC_DoingLerp = 1 end
        end
    elseif self.VC_DoingLerp then
        self.VC_DoingLerp = self.VC_DoingLerp - 0.01 * FTm
        if self.VC_DoingLerp < 0 then self.VC_DoingLerp = nil end
    end

    if self.VC_DoingLerp then
        FixAng = LerpAngle(VC.EaseInOut(self.VC_DoingLerp), FixAng, FixAng + Angle(-25, 0, -10))
        local DoPos = Vector(0, -10, 18)
        FixPos = FixPos + ang:Right() * DoPos.x * self.VC_DoingLerp
        FixPos = FixPos - ang:Forward() * DoPos.y * self.VC_DoingLerp
        FixPos = FixPos - ang:Up() * DoPos.z * self.VC_DoingLerp
    end

    FixPos = FixPos + ang:Right() * 10
    FixPos = FixPos - ang:Up() * 3
    return pos + FixPos, ang + FixAng
end

VC.CodeEnt.Spikestrip_wep.DrawWorldModel = function(self)
    if not IsValid(self:GetOwner()) then
        self:DrawModel()
        return
    end

    local atc = self.Owner:LookupAttachment("anim_attachment_rh")
    if atc ~= 0 then
        local Data = self.Owner:GetAttachment(atc)
        if not Data then Data = {} end
        if not Data.Pos then Data.Pos = Vector(0, 0, 0) end
        if not Data.Ang then Data.Ang = Angle(0, 0, 0) end
        local pos = Vector(7, -1, 15)
        local ang = Angle(0, -125, -15)
        self:SetRenderOrigin(Data.Pos + Data.Ang:Forward() * pos.x + Data.Ang:Up() * pos.y + Data.Ang:Right() * pos.z)
        Data.Ang:RotateAroundAxis(Data.Ang:Forward(), ang.p)
        Data.Ang:RotateAroundAxis(Data.Ang:Up(), ang.y)
        Data.Ang:RotateAroundAxis(Data.Ang:Right(), ang.r)
        self:SetRenderAngles(Data.Ang)
    end

    self:DrawModel()
end

VC.CodeEnt.Spikestrip_wep.ViewModelDrawn = function(self)
    if not self.VC_Model then
        self.VC_Model = ClientsideModel("models/sentry/vc_spikestrip.mdl", RENDERGROUP_OPAQUE)
        self.VC_Model:SetNoDraw(true)
        self.VC_Model:SetParent(self)
        local id = "ent_spikestrip_" .. self:EntIndex()
        VC_freemanngnida(self.VC_Model, self, id)
    end

    if self.Owner and self.Owner ~= NULL then
        local vm = self.Owner:GetViewModel()
        local lubone = vm:LookupBone("Bip01_L_Finger3")
        if lubone then
            local posLocal, posWorld, Angles = VC.getBonePos(vm, lubone)
            local ReadyPos = Vector(1.8, 9, -4.8)
            local ReadyAng = Angle(0, 0, 0)
            Angles = vm:LocalToWorldAngles(Angles)
            local mult = 1
            Angles:RotateAroundAxis(Angles:Forward(), 0 + ReadyAng.p * mult)
            Angles:RotateAroundAxis(Angles:Up(), -45 + ReadyAng.y * mult)
            Angles:RotateAroundAxis(Angles:Right(), 25 + ReadyAng.r * mult)
            posWorld = posWorld + Angles:Up() * (ReadyPos.x * mult)
            posWorld = posWorld + Angles:Right() * (ReadyPos.z * mult)
            posWorld = posWorld + Angles:Forward() * (ReadyPos.y * mult)
            self.VC_Model:SetPos(posWorld)
            self.VC_Model:SetAngles(Angles)
            self.VC_Model:DrawModel()
        end
    end
end

local ID = "Pickup_partkit"
if not VC.CodeEnt[ID] then VC.CodeEnt[ID] = {} end
if not VC.CodeEnt.Jerrycan_Wep then VC.CodeEnt.Jerrycan_Wep = {} end
VC.CodeEnt.Jerrycan_Wep.GetViewModelPosition = function(self, pos, ang)
    if not vcmod1 then return end
    local FTm = VC.FTm()
    local ent = self:GetNWEntity("VC_AimEntity")
    if ent and ent == self then ent = nil end
    if not self.VC_PastAngleInt then self.VC_PastAngleInt = 0 end
    local FixAng = Angle(0, 0, 0)
    local FixPos = Vector(0, 0, 0)
    if self.VC_PastAngleInt > 0 then
        local ReaddyPos = Vector(0, 0, 0)
        FixAng = LerpAngle(VC.EaseInOut(self.VC_PastAngleInt), Angle(0, 0, 0), Angle(-5, 6, 0))
        FixPos = FixPos + ang:Right() * ReaddyPos.x * self.VC_PastAngleInt
        FixPos = FixPos - ang:Forward() * ReaddyPos.y * self.VC_PastAngleInt
        FixPos = FixPos - ang:Up() * ReaddyPos.z * self.VC_PastAngleInt
    end

    if self.VC_FuelDoIntLerp and self.VC_FuelDoIntLerp > 0 then FixAng = LerpAngle(self.VC_FuelDoIntLerp, FixAng, FixAng + Angle(-5, 5, -5)) end
    if IsValid(ent) and self:GetNWInt("VC_FuelAmount", 0) > 0 then
        if self.VC_PastAngleInt < 1 then
            self.VC_PastAngleInt = self.VC_PastAngleInt + 0.02 * FTm
            if self.VC_PastAngleInt > 1 then self.VC_PastAngleInt = 1 end
        end
    elseif self.VC_PastAngleInt > 0 then
        self.VC_PastAngleInt = self.VC_PastAngleInt - 0.02 * FTm
        if self.VC_PastAngleInt < 0 then self.VC_PastAngleInt = 0 end
    end

    if self.VC_PastAngleInt > 0 then
        local aimang = IsValid(ent) and (ent:LocalToWorld(ent:GetNWVector("VC_FuelLidPos"), Vector(0, 0, 0)) - LocalPlayer():EyePos()):Angle() or ang
        local angdif = VC.AngleDifference_Ex(aimang, EyeAngles())
        self.VC_PastAngle = LerpAngle((IsValid(ent) and 0.05 or 0.01) * FTm, self.VC_PastAngle or ang, aimang + Angle(0, 100 / (angdif.y > 5 and angdif.y or 5), 0))
        ang = LerpAngle(VC.EaseInOut(self.VC_PastAngleInt), ang, self.VC_PastAngle)
    else
        self.VC_PastAngle = nil
    end

    FixPos = FixPos + ang:Right() * 10
    FixPos = FixPos - ang:Up() * 3
    return pos + FixPos, ang + FixAng
end

VC.CodeEnt.Jerrycan_Wep.DrawHUD = function(self)
    if not LocalPlayer():Alive() or LocalPlayer():InVehicle() then return end
    local vm = self.Owner:GetViewModel()
    local posLocal, posWorld, Angles = VC.getBonePos(vm, vm:LookupBone("ValveBiped.Bip01_R_Hand"))
    Angles = vm:LocalToWorldAngles(Angles)
    local posScr = (posWorld - vm:GetRight() * 8 + vm:GetForward() * 8):ToScreen()
    local PSx, PSy = math.Round(posScr.x), math.Round(posScr.y)
    local Sizey = 30
    local tclr = table.Copy(VC.Color.Main)
    tsize = 80
    local ftype, Cur, Max = self:GetNWInt("VC_FuelType", 0), math.ceil(self:GetNWInt("VC_FuelAmount", 0) * 10) / 10, 20
    local text = ""
    if Cur > 0 then
        text = VC.Lng(VC.FuelTypes[ftype].name) .. ": " .. (ftype == 2 and (math.Round(VC.LitersToKwH(Cur), 2) .. "/" .. math.Round(VC.LitersToKwH(Max), 2) .. " " .. VC.Lng("kWh")) or (VC.getSetting("HUD_MPh") and (math.Round(VC.LitersToGallons(Cur), 2) .. "/" .. math.Round(VC.LitersToGallons(Max), 2) .. " " .. VC.Lng("gallons")) or (math.Round(Cur, 2) .. "/" .. math.Round(Max, 2) .. " " .. VC.Lng("liters"))))
    else
        text = VC.Lng("Empty")
    end

    surface.SetFont("VC_Name")
    local tsize = surface.GetTextSize(text)
    VC.DrawFadeRect(PSx, PSy - Sizey, tsize + 10, Sizey + 5, tclr, fade)
    draw.SimpleText(text, "VC_Name", PSx + 5, PSy - 10, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
end

VC.CodeEnt.Jerrycan_Wep.DrawWorldModel = function(self)
    if not IsValid(self:GetOwner()) then
        self:DrawModel()
        return
    end

    local ftype = self:GetNWInt("VC_FuelType", 0)
    if self:GetModel() ~= VC.FuelTypes[ftype].mdl then self:SetModel(VC.FuelTypes[ftype].mdl) end
    local atc = self.Owner:LookupAttachment("anim_attachment_rh")
    if atc ~= 0 then
        local Data = self.Owner:GetAttachment(atc)
        if not Data then Data = {} end
        if not Data.Pos then Data.Pos = Vector(0, 0, 0) end
        if not Data.Ang then Data.Ang = Angle(0, 0, 0) end
        self:SetRenderOrigin(Data.Pos + Data.Ang:Forward() * 10 + Data.Ang:Up() * 1 + Data.Ang:Right() * 3)
        Data.Ang:RotateAroundAxis(Data.Ang:Forward(), 5)
        Data.Ang:RotateAroundAxis(Data.Ang:Up(), 60)
        self:SetRenderAngles(Data.Ang)
    end

    self:DrawModel()
end

VC.CodeEnt.Jerrycan_Wep.ViewModelDrawn = function(self)
    local ftype = self:GetNWInt("VC_FuelType", 0)
    if not self.VC_Model then
        self.VC_Model = ClientsideModel(VC.FuelTypes[ftype].mdl, RENDERGROUP_OPAQUE)
        self.VC_Model:SetNoDraw(true)
        self.VC_Model:SetParent(self)
        local id = "ent_jerrycanVM_" .. self:EntIndex()
        VC_freemanngnida(self.VC_Model, self, id)
    end

    if self.VC_Model:GetModel() ~= VC.FuelTypes[ftype].mdl then self.VC_Model:SetModel(VC.FuelTypes[ftype].mdl) end
    if self:GetModel() ~= VC.FuelTypes[ftype].mdl then self:SetModel(VC.FuelTypes[ftype].mdl) end
    if self.Owner and self.Owner ~= NULL then
        local vm = self.Owner:GetViewModel()
        local posLocal, posWorld, Angles = VC.getBonePos(vm, vm:LookupBone("ValveBiped.Bip01_R_Hand"))
        Angles = vm:LocalToWorldAngles(Angles)
        local ReadyPos = Vector(0, 0, 0)
        ReadyAng = Angle(0, 0, 0)
        if self.VC_PastAngleInt and self.VC_PastAngleInt > 0 then
            ReadyAng = Angle(45, -25, -50)
            ReadyPos = Vector(8, 0, -2)
            local Cur, Max = self:GetNWInt("VC_FuelAmount", 0), 20
            local int = (1 - Cur / Max) * self.VC_PastAngleInt
            self.VC_FuelDoIntLerp = Lerp(0.1 * VC.FTm(), self.VC_FuelDoIntLerp or int, int)
            if self.VC_FuelDoIntLerp and self.VC_FuelDoIntLerp > 0 then
                ReadyAng = LerpAngle(self.VC_FuelDoIntLerp, ReadyAng, ReadyAng + Angle(10, -30, -10))
                local DoPos = Vector(-8, -1, -2)
                ReadyPos = ReadyPos + Angles:Right() * DoPos.x * self.VC_FuelDoIntLerp
                ReadyPos = ReadyPos - Angles:Forward() * DoPos.y * self.VC_FuelDoIntLerp
                ReadyPos = ReadyPos - Angles:Up() * DoPos.z * self.VC_FuelDoIntLerp
            end
        end

        local mult = self.VC_PastAngleInt or 0
        Angles:RotateAroundAxis(Angles:Forward(), 145 + ReadyAng.p * mult)
        Angles:RotateAroundAxis(Angles:Up(), 90 + ReadyAng.y * mult)
        Angles:RotateAroundAxis(Angles:Right(), 10 + ReadyAng.r * mult)
        posWorld = posWorld + Angles:Up() * (-5 + ReadyPos.x * mult)
        posWorld = posWorld + Angles:Right() * (10 + ReadyPos.z * mult)
        posWorld = posWorld + Angles:Forward() * (4.5 + ReadyPos.y * mult)
        self.VC_Model:SetPos(posWorld)
        self.VC_Model:SetAngles(Angles)
        self.VC_Model:DrawModel()
    end
end