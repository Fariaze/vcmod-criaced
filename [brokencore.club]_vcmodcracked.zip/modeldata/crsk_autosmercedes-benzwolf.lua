VCModels['models/crsk_autosmercedes-benzwolf.mdl']	=	{
		em_state	=	5236594584,
		HealthEnginePosOvr	=	true,
		Date	=	"Tue Dec 12 23:40:48 2017",
		Exhaust	=	{
				{
				Ang	=	Angle(-2.5999999046326,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(12.569999694824,-78.959999084473,24.209999084473),
				EffectIdle	=	"VC_Exhaust",
					},
				},
		HealthEnginePos	=	Vector(0,65,58.389999389648),
		SocketPos	=	Vector(-1.3999999761581,-91.360000610352,33.270000457764),
		Fuel	=	{
			FuelType	=	0,
			FuelLidPos	=	Vector(0,0,0),
				},
		Author	=	"CгεερεгƬv (76561198051637331)",
		Light_DD_Int	=	true,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Copyright	=	"Copyright © 2012-2017 VCMod (freemmaann). All Rights Reserved.",
		UseSocket	=	true,
		ExtraSeats	=	{
				{
				Ang	=	Angle(-5,0,0),
				Pos	=	Vector(21.209999084473,1.8200000524521,51),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(0,90,5),
				Pos	=	Vector(18.709999084473,-59.180000305176,61.5),
				DriveBy_Cant	=	true,
				BGroups	=	{
					[17]	=	{
						[0]	=	"sidenie_zad",
							},
						},
					},
				},
		DLT	=	3491063056,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.5,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(36.130001068115,94.300003051758,45.209999084473),
					UseColor	=	true,
					Pos2	=	Vector(25.670000076294,94.300003051758,55.669998168945),
					Color	=	{
							255,
							255,
							253,
							},
					Use	=	true,
					Pos1	=	Vector(36.130001068115,94.300003051758,55.669998168945),
					Pos3	=	Vector(25.670000076294,94.300003051758,45.209999084473),
						},
				UseRunning	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RunningColor	=	{
						255,
						175,
						100,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(30.89999961853,94.800003051758,50.439998626709),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				RenderInner	=	true,
				UseSprite	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.9,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
						255,
						175,
						100,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(36.130001068115,94.300003051758,45.209999084473),
					UseColor	=	true,
					Pos2	=	Vector(25.670000076294,94.300003051758,55.669998168945),
					Color	=	{
							255,
							255,
							253,
							},
					Use	=	true,
					Pos1	=	Vector(36.130001068115,94.300003051758,55.669998168945),
					Pos3	=	Vector(25.670000076294,94.300003051758,45.209999084473),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(30.89999961853,94.300003051758,50.439998626709),
				RenderInner_Size	=	1,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				RenderInner	=	true,
				UseSprite	=	true,
				HBeamColor	=	{
						255,
						175,
						100,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.5,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-35.470001220703,94.400001525879,45.490001678467),
					UseColor	=	true,
					Pos2	=	Vector(-25.010000228882,94.400001525879,55.950000762939),
					Color	=	{
							255,
							255,
							253,
							},
					Use	=	true,
					Pos1	=	Vector(-35.470001220703,94.400001525879,55.950000762939),
					Pos3	=	Vector(-25.010000228882,94.400001525879,45.490001678467),
						},
				UseRunning	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RunningColor	=	{
						255,
						175,
						100,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-30.239999771118,94.400001525879,50.720001220703),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				RenderInner	=	true,
				UseSprite	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.2,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						100,
						0,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				UseSprite	=	true,
				Pos	=	Vector(31.479999542236,83.669998168945,59.599998474121),
				UseDynamic	=	true,
				RenderInner_Size	=	2,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(31.469999313354,86.910003662109,59.400001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.470001220703,86.900001525879,59.400001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.470001220703,83.669998168945,59.599998474121),
								},
							},
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.2,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						100,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-30.770000457764,83.76000213623,59.700000762939),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-30.760000228882,87,59.5),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.759998321533,87,59.5),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.759998321533,83.76000213623,59.700000762939),
								},
							},
						},
				Beta_Inner3D	=	true,
				RenderInner_Size	=	2,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.07,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Pos4	=	Vector(41.180000305176,37.590000152588,45.669998168945),
					Pos2	=	Vector(41.180000305176,39.75,47.110000610352),
					AmountH	=	6,
					Use	=	true,
					Pos1	=	Vector(41.180000305176,37.590000152588,47.110000610352),
					Pos3	=	Vector(41.180000305176,39.75,45.669998168945),
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						255,
						255,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						122,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderHD_Adv	=	true,
				Pos	=	Vector(41.180000305176,38.669998168945,46.389999389648),
				RenderInner	=	true,
				UseBlinkers	=	true,
				RenderInner_Size	=	1,
				UseSprite	=	true,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.07,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Pos4	=	Vector(0,37.590000152588,45.669998168945),
					Pos2	=	Vector(0,39.75,47.110000610352),
					AmountH	=	6,
					Use	=	true,
					Pos1	=	Vector(0,37.590000152588,47.110000610352),
					Pos3	=	Vector(0,39.75,45.669998168945),
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						255,
						255,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						122,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(0,38.669998168945,46.389999389648),
				RenderInner	=	true,
				RenderHD_Adv	=	true,
				RenderInner_Size	=	1,
				Beta_Inner3D	=	true,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.07,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Pos4	=	Vector(-40.759998321533,37.889999389648,45.909999847412),
					Pos2	=	Vector(-40.759998321533,40.049999237061,47.349998474121),
					AmountH	=	6,
					Use	=	true,
					Pos1	=	Vector(-40.759998321533,37.889999389648,47.349998474121),
					Pos3	=	Vector(-40.759998321533,40.049999237061,45.909999847412),
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						255,
						255,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						122,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-40.759998321533,38.970001220703,46.630001068115),
				RenderInner_Size	=	1,
				UseBlinkers	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				RenderHD_Adv	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-22.940000534058,-91.319999694824,33.650001525879),
					Use	=	true,
					Pos2	=	Vector(-30.239999771118,-91.319999694824,36.590000152588),
					Color	=	{
							255,
							133,
							0,
							},
					UseColor	=	true,
					Pos1	=	Vector(-22.940000534058,-91.319999694824,36.590000152588),
					Pos3	=	Vector(-30.239999771118,-91.319999694824,33.650001525879),
						},
				FogColor	=	{
						255,
						0,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-26.590000152588,-91.319999694824,35.119998931885),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				UseFog	=	true,
				RenderInner	=	true,
				RenderInner_Clr	=	{
						255,
						255,
						0,
						},
				Dynamic	=	{
					Size	=	0.8,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(29.819999694824,-91.449996948242,33.490001678467),
					Use	=	true,
					Pos2	=	Vector(22.520000457764,-91.449996948242,36.430000305176),
					Color	=	{
							255,
							175,
							100,
							},
					UseColor	=	true,
					Pos1	=	Vector(29.819999694824,-91.449996948242,36.430000305176),
					Pos3	=	Vector(22.520000457764,-91.449996948242,33.490001678467),
						},
				Beta_Inner3D	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(26.170000076294,-91.449996948242,34.959999084473),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				ReverseColor	=	{
						255,
						175,
						100,
						},
				Dynamic	=	{
					Size	=	0.8,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
						255,
						255,
						0,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseBrake	=	true,
				RunningColor	=	{
						255,
						0,
						0,
						},
				RenderInner	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				UseSprite	=	true,
				Pos	=	Vector(33.700000762939,-92,45.680000305176),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				UseRunning	=	true,
				BrakeColor	=	{
						255,
						0,
						0,
						},
				RenderInner_Clr	=	{
						255,
						255,
						0,
						},
				Dynamic	=	{
					Size	=	0.8,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseBrake	=	true,
				RunningColor	=	{
						255,
						0,
						0,
						},
				RenderInner_Size	=	1,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-34.580001831055,-91.800003051758,45.810001373291),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseRunning	=	true,
				BrakeColor	=	{
						255,
						0,
						0,
						},
				RenderInner_Clr	=	{
						255,
						255,
						0,
						},
				Dynamic	=	{
					Size	=	0.8,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						122,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(33.700000762939,-92,43.729999542236),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
						255,
						255,
						0,
						},
				Dynamic	=	{
					Size	=	0.8,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						122,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-34.580001831055,-91.800003051758,43.729999542236),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				RenderInner	=	true,
				UseSprite	=	true,
				RenderInner_Clr	=	{
						255,
						255,
						0,
						},
				Dynamic	=	{
					Size	=	0.8,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.9,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
						255,
						175,
						100,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-35.470001220703,94.400001525879,45.490001678467),
					UseColor	=	true,
					Pos2	=	Vector(-25.010000228882,94.400001525879,55.950000762939),
					Color	=	{
							255,
							255,
							253,
							},
					Use	=	true,
					Pos1	=	Vector(-35.470001220703,94.400001525879,55.950000762939),
					Pos3	=	Vector(-25.010000228882,94.400001525879,45.490001678467),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-30.239999771118,94.400001525879,50.720001220703),
				RenderInner_Size	=	1,
				HBeamColor	=	{
						255,
						175,
						100,
						},
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.01,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Pos4	=	Vector(-17.610000610352,21.450000762939,69.599998474121),
					Pos2	=	Vector(-17.729999542236,21.440000534058,69.480003356934),
					AmountH	=	2,
					Use	=	true,
					Pos1	=	Vector(-17.610000610352,21.440000534058,69.480003356934),
					Pos3	=	Vector(-17.729999542236,21.450000762939,69.599998474121),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				IsInterior	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-17.670000076294,21.409999847412,69.540000915527),
				UseHighBeams	=	true,
				LBeamColor	=	{
						255,
						255,
						253,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/highbeam",
					Pos4	=	Vector(-18.030000686646,21.39999961853,69.180000305176),
					UseColor	=	true,
					Pos2	=	Vector(-17.309999465942,21.489999771118,69.900001525879),
					Color	=	{
							255,
							255,
							253,
							},
					Use	=	true,
					Pos1	=	Vector(-18.030000686646,21.489999771118,69.900001525879),
					Pos3	=	Vector(-17.309999465942,21.39999961853,69.180000305176),
						},
				HBeamColor	=	{
						255,
						255,
						253,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.02,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Invulnerable	=	true,
				Beta_Inner3D	=	true,
				RunningColor	=	{
						255,
						255,
						253,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				BGroups	=	{
					[19]	=	{
							"empty",
							},
						},
				UseSprite	=	true,
				Pos	=	Vector(-9.4899997711182,-88.540000915527,45.259998321533),
				RenderInner	=	true,
				RenderInner_Size	=	1.3,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-8.0699996948242,-88.550003051758,42.520000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-6.6999998092651,-88.540000915527,45.259998321533),
								},
							},
						},
				RenderMLCenter	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.02,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Invulnerable	=	true,
				RenderMLCenter	=	true,
				RunningColor	=	{
						255,
						255,
						253,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				BGroups	=	{
					[19]	=	{
							"empty",
							},
						},
				UseSprite	=	true,
				Pos	=	Vector(-3.2000000476837,-88.540000915527,45.259998321533),
				RenderInner	=	true,
				RenderInner_Size	=	1.3,
				SpecMLine	=	{
					Amount	=	40,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-5.6999998092651,-88.540000915527,45.259998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-5.6999998092651,-88.540000915527,42.5),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-3.2000000476837,-88.540000915527,42.5),
								},
							},
						},
				Beta_Inner3D	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.02,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Invulnerable	=	true,
				UseSprite	=	true,
				RunningColor	=	{
						255,
						255,
						253,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				BGroups	=	{
					[19]	=	{
							"empty",
							},
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(0.80000001192093,-88.540000915527,42.5),
				RenderInner_Size	=	1.3,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	50,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(0.80000001192093,-88.540000915527,45.259998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-0.40000000596046,-88.540000915527,42.5),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-1.7000000476837,-88.540000915527,45.259998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-1.7000000476837,-88.540000915527,42.5),
								},
							},
						},
				RenderMLCenter	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.02,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Invulnerable	=	true,
				Beta_Inner3D	=	true,
				RunningColor	=	{
						255,
						255,
						253,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				BGroups	=	{
					[19]	=	{
							"empty",
							},
						},
				UseSprite	=	true,
				Pos	=	Vector(4.3000001907349,-88.540000915527,42.5),
				RenderInner_Size	=	1.3,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	50,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(4.3000001907349,-88.540000915527,45.259998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(1.7999999523163,-88.540000915527,45.259998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(1.7999999523163,-88.540000915527,42.5),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(4.3000001907349,-88.540000915527,42.5),
								},
							},
						},
				RenderMLCenter	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.02,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BGroups	=	{
					[19]	=	{
							"empty",
							},
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Invulnerable	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(8.3000001907349,-88.540000915527,43),
				RenderMLCenter	=	true,
				RenderInner_Size	=	1.3,
				SpecMLine	=	{
					Amount	=	50,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(8.3000001907349,-88.540000915527,44.759998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(5.8000001907349,-88.540000915527,45.259998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(5.8000001907349,-88.540000915527,42.5),
								},
							{
							Pos	=	Vector(8.3000001907349,-88.540000915527,43),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	253,
					a	=	255,
					g	=	255,
						},
				Beta_Inner3D	=	true,
					},
				},
		SocketType	=	1,
		Indication	=	{
			speedo_kmph	=	{
				max	=	1,
				pp	=	"vehicle_guage",
				min	=	0,
				top	=	120,
					},
				},
}