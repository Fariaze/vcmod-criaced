VCModels['models/crsk_autoschrysler300_hurst_1970.mdl']	=	{
		em_state	=	5236594803,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Copyright	=	"Copyright © 2012-2018 VCMod (freemmaann). All Rights Reserved.",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(25.409999847412,-133.42999267578,12.829999923706),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-25.409999847412,-133.42999267578,12.829999923706),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(25,0,0),
				Pos	=	Vector(22.5,23.719999313354,33.840000152588),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(15,0,0),
				Pos	=	Vector(-22.5,-20.829999923706,33.840000152588),
					},
				{
				Ang	=	Angle(15,0,0),
				Pos	=	Vector(22.5,-20.829999923706,33.840000152588),
					},
				{
				Ang	=	Angle(15,0,0),
				Pos	=	Vector(-0.83999997377396,-20.829999923706,33.840000152588),
					},
				},
		DLT	=	3491063202,
		Lights	=	{
				{
				UseRunning	=	true,
				SpecMat	=	{
					Select	=	5,
					New	=	"models\crskautos\chrysler\300_hurst_1970\c300hdetails_illum_on",
					Use	=	true,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Pos	=	Vector(-30.139999389648,55.349998474121,47.340000152588),
					},
				},
		Date	=	"Thu Dec 27 02:23:55 2018",
		Fuel	=	{
			Capacity	=	91,
			FuelTypeUse	=	true,
			Override	=	true,
				},
		Author	=	"CrushingSkirmish (76561198017348899)",
}