-- DurkaTeam @ 2025 Никакие права не защищены

ENT.Base = "base_ai"
ENT.Type = "ai"
ENT.PrintName		= "Car dealer"
ENT.Author			= "freemmaann"
ENT.Category		= "VCMod"
ENT.Contact			= "N/A"
ENT.Purpose			= "N/A"
ENT.Instructions	= "Press E"
ENT.Spawnable		= false
ENT.AdminSpawnable		= false
ENT.AutomaticFrameAdvance = true

function ENT:SetAutomaticFrameAdvance(bUsingAnim) self.AutomaticFrameAdvance = bUsingAnim end