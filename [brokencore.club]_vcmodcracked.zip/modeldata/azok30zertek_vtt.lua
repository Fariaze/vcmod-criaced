VCModels['models/azok30zertek_vtt.mdl']	=	{
		em_state	=	5236594485,
		Copyright	=	"Copyright © 2020 VCMod (freemmaann). All Rights Reserved.",
		hornData	=	{
			Volume	=	1,
			Distance	=	75,
			Pitch	=	100,
			Sound	=	"vehicles/azok30/zertek_vtt/klaxon.mp3",
				},
		hornUseCustom	=	true,
		DLT	=	3491062990,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				RenderInner_Size	=	2.431,
				UseSprite	=	true,
				Pos	=	Vector(0,16,30.860000610352),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				UseRunning	=	true,
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseSprite	=	true,
				Pos	=	Vector(0,-12.859999656677,23.329999923706),
				UseDynamic	=	true,
				RenderInner_Size	=	2.431,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				},
		Date	=	"Tue Apr 14 09:51:49 2020",
		Fuel	=	{
			FuelType	=	0,
			Disabled	=	true,
				},
		Author	=	"free (76561197989323181)",
}