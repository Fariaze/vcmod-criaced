VCModels['models/crsk_autosfordmustang_rtr_2018.mdl']	=	{
		em_state	=	5236594608,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		HealthEnginePosOvr	=	true,
		Date	=	"Fri Apr 19 20:41:44 2019",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-31.139999389648,-118.19000244141,13.159999847412),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(31.139999389648,-118.19000244141,13.159999847412),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-26.229999542236,-119.62000274658,13.159999847412),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(26.229999542236,-119.62000274658,13.159999847412),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		Indication	=	{
			fuel	=	{
				max	=	1,
				pp	=	"fuel_needle",
				min	=	0,
				top	=	1,
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(20,0,0),
				Pos	=	Vector(18.110000610352,-4.3299999237061,29.549999237061),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(25,0,0),
				Pos	=	Vector(-16.809999465942,-43.779998779297,31.110000610352),
					},
				{
				Ang	=	Angle(25,0,0),
				Pos	=	Vector(16.809999465942,-43.779998779297,31.110000610352),
					},
				{
				Ang	=	Angle(25,0,0),
				Pos	=	Vector(0,-43.779998779297,31.110000610352),
					},
				},
		HealthEnginePos	=	Vector(0,68.120002746582,38.540000915527),
		DLT	=	3491063072,
		Lights	=	{
				{
				UseRunning	=	true,
				Pos	=	Vector(-17.469999313354,14.550000190735,51.509998321533),
				SpecMat	=	{
					Select	=	8,
					New	=	"models\crskautos\ford\mustang_gt_2018\decal_label_illum_on",
					Use	=	true,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
					},
				{
				UseRunning	=	true,
				Pos	=	Vector(-14.409999847412,14.550000190735,51.509998321533),
				SpecMat	=	{
					Select	=	12,
					New	=	"models\crskautos\ford\mustang_gt_2018\decal_display_illum_on",
					Use	=	true,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
					},
				{
				UseRunning	=	true,
				Pos	=	Vector(-11.619999885559,14.550000190735,51.509998321533),
				SpecMat	=	{
					Select	=	20,
					New	=	"models\crskautos\ford\mustang_gt_2018\gauge_illum_on",
					Use	=	true,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
					},
				{
				UseRunning	=	true,
				Pos	=	Vector(-13.5,17.209999084473,42.209999084473),
				SpecMat	=	{
					Select	=	21,
					New	=	"models\crskautos\shared\vmt\red_illum_on",
					Use	=	true,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseSprite	=	true,
				Pos	=	Vector(29.780000686646,95.169998168945,33.900001525879),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	11,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(30.770000457764,97.290000915527,32.819999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(33.380001068115,95.849998474121,30.909999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(34.490001678467,93.220001220703,30.069999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				UseSprite	=	true,
				Pos	=	Vector(27.950000762939,99.940002441406,33.209999084473),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	9,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(29.010000228882,101.59999847412,32.159999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(31.10000038147,100.63999938965,30.700000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(31.909999847412,98.690002441406,30.110000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseSprite	=	true,
				Pos	=	Vector(28.85000038147,97.930000305176,33.639999389648),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	9,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(29.909999847412,99.589996337891,32.590000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(32,98.629997253418,31.129999160767),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(32.810001373291,96.680000305176,30.540000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4865,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(35.099998474121,99.980003356934,21.909999847412),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	5,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(36.520000457764,98.620002746582,22.14999961853),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(37.909999847412,97.370002746582,22.159999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(39.330001831055,96.050003051758,22.14999961853),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(40.319999694824,94.370002746582,22.180000305176),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseLowBeams	=	true,
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UsePrjTex	=	true,
				Pos	=	Vector(37.139999389648,93.089996337891,32.599998474121),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseSprite	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(49.319999694824,13.630000114441,46.450000762939),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	11,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(50.790000915527,11.050000190735,46.470001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(51.490001678467,7.6300001144409,46.459999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3953,
						},
				UseBrake	=	true,
				UseBlinkers	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseSprite	=	true,
				Pos	=	Vector(35.630001068115,-110.25,39.729999542236),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	6,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(35.130001068115,-113.91999816895,34.799999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3953,
						},
				UseBrake	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(24.459999084473,-114.15000152588,40.659999847412),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	6,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(23.959999084473,-118.38999938965,34.700000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3953,
						},
				UseBrake	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(30.25,-111.70999908447,40.860000610352),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	6,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(29.760000228882,-115.83000183105,35.110000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				UseRunning	=	true,
				Pos	=	Vector(17.469999313354,14.550000190735,51.509998321533),
				SpecMat	=	{
					Select	=	8,
					New	=	"models\crskautos\ford\mustang_gt_2018\decal_label_illum_on",
					Use	=	true,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
					},
				{
				UseRunning	=	true,
				Pos	=	Vector(14.409999847412,14.550000190735,51.509998321533),
				SpecMat	=	{
					Select	=	12,
					New	=	"models\crskautos\ford\mustang_gt_2018\decal_display_illum_on",
					Use	=	true,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
					},
				{
				UseRunning	=	true,
				Pos	=	Vector(11.619999885559,14.550000190735,51.509998321533),
				SpecMat	=	{
					Select	=	20,
					New	=	"models\crskautos\ford\mustang_gt_2018\gauge_illum_on",
					Use	=	true,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
					},
				{
				UseRunning	=	true,
				Pos	=	Vector(13.5,17.209999084473,42.209999084473),
				SpecMat	=	{
					Select	=	21,
					New	=	"models\crskautos\shared\vmt\red_illum_on",
					Use	=	true,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseSprite	=	true,
				Pos	=	Vector(-29.780000686646,95.169998168945,33.900001525879),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	11,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-30.770000457764,97.290000915527,32.819999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-33.380001068115,95.849998474121,30.909999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-34.490001678467,93.220001220703,30.069999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseSprite	=	true,
				Pos	=	Vector(-27.950000762939,99.940002441406,33.209999084473),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	9,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-29.010000228882,101.59999847412,32.159999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-31.10000038147,100.63999938965,30.700000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-31.909999847412,98.690002441406,30.110000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				UseSprite	=	true,
				Pos	=	Vector(-28.85000038147,97.930000305176,33.639999389648),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	9,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-29.909999847412,99.589996337891,32.590000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-32,98.629997253418,31.129999160767),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-32.810001373291,96.680000305176,30.540000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4865,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-35.099998474121,99.980003356934,21.909999847412),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	5,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-36.520000457764,98.620002746582,22.14999961853),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-37.909999847412,97.370002746582,22.159999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-39.330001831055,96.050003051758,22.14999961853),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-40.319999694824,94.370002746582,22.180000305176),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseLowBeams	=	true,
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UsePrjTex	=	true,
				Pos	=	Vector(-37.139999389648,93.089996337891,32.599998474121),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-49.319999694824,13.630000114441,46.450000762939),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	11,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-50.790000915527,11.050000190735,46.470001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-51.490001678467,7.6300001144409,46.459999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3953,
						},
				UseBrake	=	true,
				UseBlinkers	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseSprite	=	true,
				Pos	=	Vector(-35.630001068115,-110.25,39.729999542236),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	6,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-35.130001068115,-113.91999816895,34.799999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3953,
						},
				UseBrake	=	true,
				UseBlinkers	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseSprite	=	true,
				Pos	=	Vector(-24.459999084473,-114.15000152588,40.659999847412),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	6,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-23.959999084473,-118.38999938965,34.700000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3953,
						},
				UseBrake	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-30.25,-111.70999908447,40.860000610352),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	6,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-29.760000228882,-115.83000183105,35.110000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(21.659999847412,108.09999847412,31.709999084473),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	23,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(22.270000457764,107.91000366211,31.459999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(23.110000610352,107.63999938965,30.75),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(26.940000534058,106.5299987793,27.360000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(27.200000762939,106.30000305176,26.829999923706),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(27.139999389648,106.33000183105,26.510000228882),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(25.89999961853,106.26000213623,24.64999961853),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(25.39999961853,106.33000183105,24.35000038147),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(24.969999313354,106.44999694824,24.260000228882),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(24.170000076294,106.69999694824,24.170000076294),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(23.360000610352,106.9700012207,24.25),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(22.729999542236,107.06999969482,24.389999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(21.010000228882,107.51999664307,26.360000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(20.940000534058,108.06999969482,30.790000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(21.120000839233,108.06999969482,31.35000038147),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(21.370000839233,108.11000061035,31.659999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-21.659999847412,108.09999847412,31.709999084473),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	23,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-22.270000457764,107.91000366211,31.459999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-23.110000610352,107.63999938965,30.75),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-26.940000534058,106.5299987793,27.360000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-27.200000762939,106.30000305176,26.829999923706),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-27.139999389648,106.33000183105,26.510000228882),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-25.89999961853,106.26000213623,24.64999961853),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-25.39999961853,106.33000183105,24.35000038147),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-24.969999313354,106.44999694824,24.260000228882),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-24.170000076294,106.69999694824,24.170000076294),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-23.360000610352,106.9700012207,24.25),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-22.729999542236,107.06999969482,24.389999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-21.010000228882,107.51999664307,26.360000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-20.940000534058,108.06999969482,30.790000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-21.120000839233,108.06999969482,31.35000038147),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-21.370000839233,108.11000061035,31.659999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner_ClrUse	=	false,
					},
				},
		Copyright	=	"Copyright © 2012-2019 VCMod (freemmaann). All Rights Reserved.",
		Fuel	=	{
			FuelLidPos	=	Vector(-42.130001068115,-92.730003356934,38.770000457764),
			FuelTypeUse	=	true,
			FuelType	=	0,
			Capacity	=	60,
			Override	=	true,
			FuelLidUse	=	true,
				},
		Author	=	"DangerKiddy(DK) (76561198132964487)",
}