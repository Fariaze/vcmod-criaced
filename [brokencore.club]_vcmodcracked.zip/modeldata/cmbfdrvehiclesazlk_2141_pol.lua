VCModels['models/cmbfdrvehiclesazlk_2141_pol.mdl']	=	{
		em_state	=	5236594932,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Siren	=	{
			Sounds	=	{
					{
					Volume	=	1,
					Pitch	=	100,
					Distance	=	95,
					Name	=	"Wail",
					Sound	=	"vcmod/els/smartsiren/wail.wav",
						},
					{
					Volume	=	1,
					Pitch	=	100,
					Distance	=	95,
					Name	=	"Yelp",
					Sound	=	"vcmod/els/smartsiren/yelp.wav",
						},
					{
					Volume	=	1,
					Pitch	=	100,
					Distance	=	95,
					Name	=	"Priority",
					Sound	=	"vcmod/els/smartsiren/priority.wav",
						},
					},
			Lights	=	{
					{
					Sprite	=	{
						GlowPrxSize	=	5,
						Size	=	0.6,
							},
					SpecSpin	=	{
						Use	=	true,
						Offset	=	0,
						Speed	=	406,
							},
					Spec3D	=	{
						Mat	=	"vcmod/lights/3d/circle_texture",
						Use	=	true,
						Pos2	=	Vector(16.549999237061,-5.8000001907349,62.680000305176),
						Pos4	=	Vector(18.549999237061,-5.8000001907349,60.599998474121),
						Pos1	=	Vector(18.549999237061,-5.8000001907349,62.680000305176),
						Pos3	=	Vector(16.549999237061,-5.8000001907349,60.680000305176),
							},
					SpecMat	=	{
							},
					BGroups	=	{
							{
							[0]	=	"azlk_2141_siren",
								},
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(17.549999237061,-5.8000001907349,61.680000305176),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							0,
							55,
							255,
							},
					UseSprite	=	true,
					Dynamic	=	{
						Size	=	0.6,
						Brightness	=	2.1,
							},
						},
					{
					Sprite	=	{
						GlowPrxSize	=	5,
						Size	=	0.6,
							},
					SpecSpin	=	{
						Offset	=	57.61,
						Use	=	true,
						Speed	=	406,
							},
					Spec3D	=	{
						Mat	=	"vcmod/lights/3d/circle_texture",
						Use	=	true,
						Pos2	=	Vector(-15.460000038147,-5.8000001907349,62.680000305176),
						Pos4	=	Vector(-17.459999084473,-5.8000001907349,60.599998474121),
						Pos1	=	Vector(-17.459999084473,-5.8000001907349,62.680000305176),
						Pos3	=	Vector(-15.460000038147,-5.8000001907349,60.680000305176),
							},
					SpecMat	=	{
							},
					BGroups	=	{
							{
							[0]	=	"azlk_2141_siren",
								},
							},
					UseSprite	=	true,
					Pos	=	Vector(-16.459999084473,-5.8000001907349,61.680000305176),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							0,
							55,
							255,
							},
					RenderHD_Adv	=	true,
					Dynamic	=	{
						Size	=	0.6,
						Brightness	=	2.1,
							},
						},
					{
					Sprite	=	{
						GlowPrxSize	=	5,
						Size	=	0.6,
							},
					SpecSpin	=	{
						Use	=	true,
						Offset	=	-67.88,
						Reversed	=	true,
						Speed	=	406,
							},
					Spec3D	=	{
						Mat	=	"vcmod/lights/3d/circle_texture",
						Use	=	true,
						Pos2	=	Vector(-0.15999999642372,-5.8000001907349,68.400001525879),
						Pos4	=	Vector(1.8400000333786,-5.8000001907349,66.319999694824),
						Pos1	=	Vector(1.8400000333786,-5.8000001907349,68.400001525879),
						Pos3	=	Vector(-0.15999999642372,-5.8000001907349,66.400001525879),
							},
					SpecMat	=	{
							},
					BGroups	=	{
							{
							[0]	=	"azlk_2141_siren",
								},
							},
					UseSprite	=	true,
					Pos	=	Vector(0.83999997377396,-5.8000001907349,67.400001525879),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					RenderHD_Adv	=	true,
					Dynamic	=	{
						Size	=	0.6,
						Brightness	=	2.1,
							},
						},
					},
			Sounds_Horn	=	{
				Use	=	true,
				Volume	=	1,
				Distance	=	95,
				Pitch	=	100,
				Sound	=	"vcmod/els/smartsiren/horn.wav",
					},
			Sequences	=	{
					{
					SubSeq	=	{
							{
							Type	=	"Custom",
							Time	=	0.5,
							Stages	=	{
									{
									Lights	=	{
											1,
											2,
											},
									Time	=	0.01,
										},
									},
								},
							},
					Codes	=	{
							true,
							},
					Lights_Sel	=	{
							true,
							true,
							true,
							},
						},
					{
					SubSeq	=	{
							{
							Type	=	"Custom",
							Time	=	0.5,
							Stages	=	{
									{
									Lights	=	{
											1,
											2,
											3,
											},
									Time	=	0.01,
										},
									},
								},
							},
					Codes	=	{
						[2]	=	true,
							},
					Lights_Sel	=	{
							true,
							true,
							true,
							},
						},
					},
			Sounds_Manual	=	{
				Use	=	true,
				Volume	=	1,
				Distance	=	95,
				Pitch	=	100,
				Sound	=	"vcmod/els/smartsiren/manual.wav",
					},
				},
		Date	=	"Sat Sep 23 16:14:15 2017",
		ExtraSeats	=	{
				{
				Switch_Cant	=	true,
				Pos	=	Vector(15.329999923706,-21.549999237061,21.770000457764),
				DriveBy_Cant	=	true,
					},
				{
				RadioControl	=	true,
				Pos	=	Vector(17.809999465942,15.539999961853,22.329999923706),
					},
				{
				Switch_Cant	=	true,
				Pos	=	Vector(-21.909999847412,-21.549999237061,21.770000457764),
				DriveBy_Cant	=	true,
					},
				{
				Switch_Cant	=	true,
				Pos	=	Vector(-5.3299999237061,-21.549999237061,21.770000457764),
				DriveBy_Cant	=	true,
					},
				},
		DLT	=	3491063288,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(25.129999160767,104.2200012207,22.10000038147),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
						195,
						195,
						255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-25.129999160767,104.2200012207,22.10000038147),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
						195,
						195,
						255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				HBeamColor	=	{
						195,
						195,
						255,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(25.129999160767,104.2200012207,22.10000038147),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UsePrjTex	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				LBeamColor	=	{
						195,
						195,
						255,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				HBeamColor	=	{
						195,
						195,
						255,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseSprite	=	true,
				LBeamColor	=	{
						195,
						195,
						255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UsePrjTex	=	true,
				SpecMat	=	{
						},
				Pos	=	Vector(-25.129999160767,104.2200012207,22.10000038147),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(33.930000305176,102.36000061035,21.829999923706),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-33.930000305176,102.36000061035,21.829999923706),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(41.139999389648,48.069999694824,19.159999847412),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-39.75,48.069999694824,19.159999847412),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(36.099998474121,-91.980003356934,25.110000610352),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-36.099998474121,-91.980003356934,25.110000610352),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-28,-92.26000213623,25.620000839233),
				UseDynamic	=	true,
				RenderInner	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(28,-92.26000213623,25.620000839233),
				UseDynamic	=	true,
				RenderInner	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-15.960000038147,-92.26000213623,25.620000839233),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseRunning	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(15.960000038147,-92.26000213623,25.620000839233),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseRunning	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-21.280000686646,-92.26000213623,25.620000839233),
				UseDynamic	=	true,
				RenderInner	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(21.280000686646,-92.26000213623,25.620000839233),
				UseDynamic	=	true,
				RenderInner	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
					},
				},
		Copyright	=	"Copyright © 2012-2017 VCMod (freemmaann). All Rights Reserved.",
		Fuel	=	{
			FuelType	=	0,
				},
		Author	=	"Tokimune | FINLAND (76561198087327799)",
}