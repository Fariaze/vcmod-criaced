VCModels['models/crsk_autosbmw750i_e38_1995.mdl']	=	{
		em_state	=	5236594389,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		HealthEnginePosOvr	=	true,
		Date	=	"Sun Dec 23 20:24:28 2018",
		Exhaust	=	{
				{
				Ang	=	Angle(29.200000762939,-90,0),
				Pos	=	Vector(-28.459999084473,-119.37999725342,11.739999771118),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(29.200000762939,-90,0),
				Pos	=	Vector(27.829999923706,-119.37999725342,11.739999771118),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		Indication	=	{
			fuel	=	{
				max	=	1,
				pp	=	"fuel_needle",
				top	=	1,
					},
				},
		Copyright	=	"Copyright © 2012-2018 VCMod (freemmaann). All Rights Reserved.",
		HealthEnginePos	=	Vector(0,84.940002441406,42.729999542236),
		DLT	=	3491062926,
		Lights	=	{
				{
				UseRunning	=	true,
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
					Select	=	10,
					New	=	"models\crskautos\bmw\750i_e38_1995\whiteillum_on",
					Use	=	true,
						},
				RunningColor	=	{
					r	=	255,
					b	=	48,
					a	=	255,
					g	=	0,
						},
				Pos	=	Vector(-23.309999465942,29.819999694824,46.009998321533),
					},
				{
				UseRunning	=	true,
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
					Select	=	11,
					New	=	"models\crskautos\bmw\750i_e38_1995\intferior_lod0_on",
					Use	=	true,
						},
				RunningColor	=	{
					r	=	255,
					b	=	48,
					a	=	255,
					g	=	0,
						},
				Pos	=	Vector(-21.829999923706,29.819999694824,46.009998321533),
					},
				{
				UseRunning	=	true,
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
					Select	=	12,
					New	=	"models\crskautos\bmw\750i_e38_1995\but1_illum_on",
					Use	=	true,
						},
				RunningColor	=	{
					r	=	255,
					b	=	48,
					a	=	255,
					g	=	0,
						},
				Pos	=	Vector(-19.879999160767,29.819999694824,46.009998321533),
					},
				{
				UseRunning	=	true,
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
					Select	=	13,
					New	=	"models\crskautos\bmw\750i_e38_1995\but2_illum_on",
					Use	=	true,
						},
				RunningColor	=	{
					r	=	255,
					b	=	48,
					a	=	255,
					g	=	0,
						},
				Pos	=	Vector(-18.659999847412,29.819999694824,46.009998321533),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-19.760000228882,107.40000152588,27.129999160767),
					Pos2	=	Vector(-26.920000076294,107.2799987793,34.119998931885),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-19.469999313354,107.38999938965,34.150001525879),
					Pos3	=	Vector(-28.219999313354,107.41999816895,27.950000762939),
						},
				SpecMat	=	{
					New	=	"models\crskautos\bmw\750i_e38_1995\but2_illum_on",
					Select	=	13,
						},
				UseSprite	=	true,
				Pos	=	Vector(-23.670000076294,106.62000274658,30.790000915527),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(20.35000038147,107.30999755859,27.030000686646),
					Pos2	=	Vector(27.510000228882,107.18000030518,34.020000457764),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(20.059999465942,107.29000091553,34.049999237061),
					Pos3	=	Vector(28.809999465942,107.2799987793,27.85000038147),
						},
				SpecMat	=	{
					New	=	"models\crskautos\bmw\750i_e38_1995\but2_illum_on",
					Select	=	13,
						},
				UseSprite	=	true,
				Pos	=	Vector(24.260000228882,106.51999664307,30.690000534058),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(20.270000457764,107.30000305176,27.030000686646),
					Pos2	=	Vector(27.430000305176,107.16999816895,34.020000457764),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(19.979999542236,107.2799987793,34.049999237061),
					Pos3	=	Vector(28.729999542236,107.2799987793,27.85000038147),
						},
				HBeamColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				UseSprite	=	true,
				Pos	=	Vector(24.180000305176,106.51000213623,30.690000534058),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
					New	=	"models\crskautos\bmw\750i_e38_1995\but2_illum_on",
					Select	=	13,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-19.639999389648,107.41000366211,27.129999160767),
					Pos2	=	Vector(-26.799999237061,107.2799987793,34.119998931885),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-19.35000038147,107.38999938965,34.150001525879),
					Pos3	=	Vector(-28.10000038147,107.40000152588,27.950000762939),
						},
				HBeamColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				UseSprite	=	true,
				Pos	=	Vector(-23.549999237061,106.62000274658,30.790000915527),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
					New	=	"models\crskautos\bmw\750i_e38_1995\but2_illum_on",
					Select	=	13,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(30.239999771118,105.4700012207,28.909999847412),
					UseColor	=	true,
					Pos2	=	Vector(33.319999694824,105.48999786377,32.220001220703),
					Color	=	{
						r	=	255,
						b	=	155,
						a	=	255,
						g	=	175,
							},
					Use	=	true,
					Pos1	=	Vector(30.139999389648,105.51000213623,32.220001220703),
					Pos3	=	Vector(33.430000305176,105.48999786377,29.219999313354),
						},
				SpecMat	=	{
					New	=	"models\crskautos\bmw\750i_e38_1995\but2_illum_on",
					Select	=	13,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UsePrjTex	=	true,
				Pos	=	Vector(31.909999847412,105.4700012207,30.690000534058),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				LBeamColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				HBeamColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-29.629999160767,105.66999816895,29.020000457764),
					UseColor	=	true,
					Pos2	=	Vector(-32.709999084473,105.69000244141,32.330001831055),
					Color	=	{
						r	=	255,
						b	=	155,
						a	=	255,
						g	=	175,
							},
					Use	=	true,
					Pos1	=	Vector(-29.530000686646,105.70999908447,32.330001831055),
					Pos3	=	Vector(-32.819999694824,105.69000244141,29.329999923706),
						},
				HBeamColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-31.299999237061,105.66999816895,30.799999237061),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				SpecMat	=	{
					New	=	"models\crskautos\bmw\750i_e38_1995\but2_illum_on",
					Select	=	13,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-25.069999694824,108.58000183105,15.369999885559),
					UseColor	=	true,
					Pos2	=	Vector(-34.389999389648,107.34999847412,18.360000610352),
					Color	=	{
						r	=	255,
						b	=	155,
						a	=	255,
						g	=	175,
							},
					Use	=	true,
					Pos1	=	Vector(-25.610000610352,109.59999847412,18.360000610352),
					Pos3	=	Vector(-32.819999694824,106.65000152588,15.359999656677),
						},
				FogColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				SpecMat	=	{
					New	=	"models\crskautos\bmw\750i_e38_1995\but2_illum_on",
					Select	=	13,
						},
				UseSprite	=	true,
				Pos	=	Vector(-30.840000152588,107.56999969482,16.489999771118),
				UseDynamic	=	true,
				UseFog	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(25.680000305176,108.58000183105,15.220000267029),
					UseColor	=	true,
					Pos2	=	Vector(35,107.34999847412,18.209999084473),
					Color	=	{
						r	=	255,
						b	=	155,
						a	=	255,
						g	=	175,
							},
					Use	=	true,
					Pos1	=	Vector(26.219999313354,109.59999847412,18.209999084473),
					Pos3	=	Vector(33.430000305176,106.65000152588,15.210000038147),
						},
				FogColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				SpecMat	=	{
					New	=	"models\crskautos\bmw\750i_e38_1995\but2_illum_on",
					Select	=	13,
						},
				UseSprite	=	true,
				Pos	=	Vector(31.450000762939,107.56999969482,16.340000152588),
				UseDynamic	=	true,
				UseFog	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\bmw\750i_e38_1995\but2_illum_on",
					Select	=	13,
						},
				UseSprite	=	true,
				Pos	=	Vector(-38.090000152588,102.83000183105,31.64999961853),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\bmw\750i_e38_1995\but2_illum_on",
					Select	=	13,
						},
				UseSprite	=	true,
				Pos	=	Vector(38.599998474121,102.83000183105,31.430000305176),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\bmw\750i_e38_1995\but2_illum_on",
					Select	=	13,
						},
				UseSprite	=	true,
				Pos	=	Vector(45.700000762939,49.509998321533,25.379999160767),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\bmw\750i_e38_1995\but2_illum_on",
					Select	=	13,
						},
				UseSprite	=	true,
				Pos	=	Vector(-45.520000457764,49.509998321533,25.690000534058),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(3.8499999046326,-93.5,49.900001525879),
					Pos2	=	Vector(-2.9300000667572,-92.709999084473,51.439998626709),
					Color	=	{
						r	=	255,
						b	=	155,
						a	=	255,
						g	=	175,
							},
					Use	=	true,
					Pos1	=	Vector(2.7000000476837,-92.589996337891,51.360000610352),
					Pos3	=	Vector(-3.9500000476837,-93.580001831055,49.930000305176),
						},
				SpecMat	=	{
					New	=	"models\crskautos\bmw\750i_e38_1995\but2_illum_on",
					Select	=	13,
						},
				UseSprite	=	true,
				Pos	=	Vector(0,-93.01000213623,50.560001373291),
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseReverse	=	true,
				SpecMat	=	{
					New	=	"models\crskautos\bmw\750i_e38_1995\but2_illum_on",
					Select	=	13,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-32.099998474121,-121.43000030518,42.400001525879),
				UseDynamic	=	true,
				RenderInner_Size	=	2,
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				SpecMLine	=	{
					Amount	=	3,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-28.89999961853,-121.83999633789,42.340000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseReverse	=	true,
				SpecMat	=	{
					New	=	"models\crskautos\bmw\750i_e38_1995\but2_illum_on",
					Select	=	13,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(32.009998321533,-121.43000030518,42.150001525879),
				UseDynamic	=	true,
				RenderInner_Size	=	2,
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				SpecMLine	=	{
					Amount	=	3,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(28.809999465942,-121.83999633789,42.090000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\bmw\750i_e38_1995\but2_illum_on",
					Select	=	13,
						},
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-34.060001373291,-121.12999725342,42.400001525879),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	6,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-36.950000762939,-120.48999786377,42.340000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-39.25,-119.15000152588,42.340000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Size	=	2,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\bmw\750i_e38_1995\but2_illum_on",
					Select	=	13,
						},
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(33.970001220703,-121.12999725342,42.139999389648),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	6,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(36.860000610352,-120.48999786377,42.080001831055),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(39.159999847412,-119.15000152588,42.080001831055),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Size	=	2,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.12,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				SpecMat	=	{
					New	=	"models\crskautos\bmw\750i_e38_1995\but2_illum_on",
					Select	=	13,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Size	=	3.0172,
				UseSprite	=	true,
				Pos	=	Vector(-26.459999084473,-122.41000366211,39.200000762939),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	13,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-30.840000152588,-121.76999664307,39.139999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-35.349998474121,-121.05999755859,39.139999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-38.599998474121,-119.93000030518,39.139999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-41.200000762939,-118.2799987793,39.240001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.12,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				SpecMat	=	{
					New	=	"models\crskautos\bmw\750i_e38_1995\but2_illum_on",
					Select	=	13,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(26.14999961853,-122.41000366211,39.099998474121),
				UseDynamic	=	true,
				RenderInner_Size	=	3.0172,
				SpecMLine	=	{
					Amount	=	13,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(30.530000686646,-121.76999664307,39.040000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(35.040000915527,-121.05999755859,39.040000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(38.290000915527,-119.93000030518,39.040000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(40.889999389648,-118.2799987793,39.139999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseBrake	=	true,
				SpecMat	=	{
					New	=	"models\crskautos\bmw\750i_e38_1995\but2_illum_on",
					Select	=	13,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-36.189998626709,-120.70999908447,35.919998168945),
				UseDynamic	=	true,
				RenderInner_Size	=	2,
				SpecMLine	=	{
					Amount	=	6,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-39.080001831055,-119.62999725342,35.860000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-41.380001068115,-118.23000335693,35.860000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseBrake	=	true,
				SpecMat	=	{
					New	=	"models\crskautos\bmw\750i_e38_1995\but2_illum_on",
					Select	=	13,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(35.529998779297,-120.70999908447,35.740001678467),
				UseDynamic	=	true,
				RenderInner_Size	=	2,
				SpecMLine	=	{
					Amount	=	6,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(38.419998168945,-119.62999725342,35.680000305176),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(40.720001220703,-118.23000335693,35.680000305176),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				FogColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecMat	=	{
					New	=	"models\crskautos\bmw\750i_e38_1995\but2_illum_on",
					Select	=	13,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-34.009998321533,-121.16999816895,36),
				UseDynamic	=	true,
				RenderInner_Size	=	2.5,
				SpecMLine	=	{
					Amount	=	3,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-31.090000152588,-121.58000183105,35.939998626709),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseFog	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				FogColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecMat	=	{
					New	=	"models\crskautos\bmw\750i_e38_1995\but2_illum_on",
					Select	=	13,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(33.520000457764,-121.16999816895,35.700000762939),
				UseDynamic	=	true,
				RenderInner_Size	=	2.5,
				SpecMLine	=	{
					Amount	=	3,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(30.60000038147,-121.58000183105,35.639999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseFog	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseInter	=	true,
				InterColor	=	{
					r	=	225,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				SpecMat	=	{
					New	=	"models\crskautos\bmw\750i_e38_1995\but2_illum_on",
					Select	=	13,
						},
				UseSprite	=	true,
				Pos	=	Vector(0.23999999463558,11.800000190735,64.330001831055),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				RenderType	=	2,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseInter	=	true,
				InterColor	=	{
					r	=	225,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				SpecMat	=	{
					New	=	"models\crskautos\bmw\750i_e38_1995\but2_illum_on",
					Select	=	13,
						},
				UseSprite	=	true,
				Pos	=	Vector(-3.0299999713898,11.89999961853,64.330001831055),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.15,
					Brightness	=	2,
						},
				RenderType	=	2,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseInter	=	true,
				InterColor	=	{
					r	=	225,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				SpecMat	=	{
					New	=	"models\crskautos\bmw\750i_e38_1995\but2_illum_on",
					Select	=	13,
						},
				UseSprite	=	true,
				Pos	=	Vector(3.2699999809265,11.89999961853,64.330001831055),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.15,
					Brightness	=	2,
						},
				RenderType	=	2,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.0238,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	55,
					b	=	0,
					a	=	255,
					g	=	255,
						},
				RenderType	=	2,
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-14.520000457764,31.920000076294,45.900001525879),
				BlinkerRight	=	true,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.0238,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				RenderType	=	2,
				SpecMat	=	{
						},
				UseSprite	=	true,
				LBeamColor	=	{
					r	=	55,
					b	=	0,
					a	=	255,
					g	=	255,
						},
				Pos	=	Vector(-27.790000915527,31.579999923706,42.090000152588),
				BlinkerLeft	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.0238,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	55,
					b	=	0,
					a	=	255,
					g	=	255,
						},
				RenderType	=	2,
				BlinkerLeft	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-26.35000038147,31.920000076294,45.900001525879),
				SpecMat	=	{
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.0238,
						},
				SpecSpin	=	{
						},
				RenderType	=	2,
				BlinkerLeft	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-20.549999237061,32.650001525879,47.380001068115),
				UseHighBeams	=	true,
				SpecMat	=	{
						},
				HBeamColor	=	{
					r	=	0,
					b	=	255,
					a	=	255,
					g	=	55,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.0238,
						},
				SpecSpin	=	{
						},
				FogColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				BlinkerLeft	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-26.719999313354,31.579999923706,42.090000152588),
				UseFog	=	true,
				SpecMat	=	{
						},
				RenderType	=	2,
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(20,0,0),
				Pos	=	Vector(20.389999389648,12.109999656677,32.180000305176),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(20,0,0),
				Pos	=	Vector(-20.389999389648,-38.869998931885,32.180000305176),
					},
				{
				Ang	=	Angle(20,0,0),
				Pos	=	Vector(20.389999389648,-38.869998931885,32.180000305176),
					},
				{
				Ang	=	Angle(20,0,0),
				Pos	=	Vector(0.15999999642372,-38.869998931885,32.180000305176),
					},
				},
		Fuel	=	{
			FuelLidPos	=	Vector(42.569999694824,-79.76000213623,43.229999542236),
			FuelLidUse	=	true,
			FuelType	=	0,
			Capacity	=	95,
			Override	=	true,
			FuelTypeUse	=	true,
				},
		Author	=	"DangerKiddy(DK) (76561198132964487)",
}