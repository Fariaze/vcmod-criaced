VCModels['models/colorable_vehiclesflatnose_truck.mdl']	=	{
		IsBig	=	true,
		em_state	=	5236594569,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Date	=	"06/17/16 19:44:52",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-180,0),
				Pos	=	Vector(-45.279998779297,42.310001373291,153.30000305176),
				EffectStress	=	"VC_Exhaust_Truck_Stress",
				EffectIdle	=	"VC_Exhaust_Truck",
					},
				},
		Sound_Airbrake	=	true,
		ExtraSeats	=	{
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(26.670000076294,108,83.069999694824),
				RadioControl	=	true,
					},
				},
		DLT	=	3491063046,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(41.819999694824,135.36999511719,55.959999084473),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
						235.96,
						250.93,
						204.94,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseHead	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-41.819999694824,135.36999511719,55.959999084473),
				UseDynamic	=	true,
				HeadColor	=	{
						212,
						219,
						255,
						},
				ProjTexture	=	{
					Forward	=	30,
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UsePrjTex	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(33.889999389648,140.07000732422,47.439998626709),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-33.889999389648,140.07000732422,47.439998626709),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseHead	=	true,
				UsePrjTex	=	true,
				Pos	=	Vector(41.819999694824,135.36999511719,55.959999084473),
				UseDynamic	=	true,
				HeadColor	=	{
						212,
						219,
						255,
						},
				UseSprite	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				ProjTexture	=	{
					Forward	=	30,
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-41.819999694824,135.36999511719,55.959999084473),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
						235.96,
						250.93,
						204.94,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						55,
						0,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-17.530000686646,-145.0299987793,23.459999084473),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBrake	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						55,
						0,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(17.530000686646,-145.0299987793,23.459999084473),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-8.5100002288818,-145.80000305176,24.110000610352),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseRunning	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(8.5100002288818,-145.80000305176,24.110000610352),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseRunning	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(9.2399997711182,127.48999786377,131.61999511719),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseRunning	=	true,
				RunningColor	=	{
						255,
						155,
						0,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(46.580001831055,127,131.05999755859),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseRunning	=	true,
				RunningColor	=	{
						255,
						155,
						0,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(0,126.33000183105,131.13000488281),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseRunning	=	true,
				RunningColor	=	{
						255,
						155,
						0,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-9.2399997711182,127.48999786377,131.61999511719),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseRunning	=	true,
				RunningColor	=	{
						255,
						155,
						0,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-46.580001831055,127,131.05999755859),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseRunning	=	true,
				RunningColor	=	{
						255,
						155,
						0,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
					},
				},
		Sound_Backup	=	true,
		Copyright	=	"Copyright © 2012-2016 VCMod (freemmaann). All Rights Reserved.",
		Author	=	"[CG] Tokimune (76561198087327799)",
}