VCModels['models/copcar.mdl']	=	{
		em_state	=	5236594329,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Siren	=	{
			Sounds	=	{
					{
					Pitch	=	100,
					Volume	=	1,
					Distance	=	95,
					Name	=	"Wail",
					Sound	=	"vcmod/els/cencom/wail.wav",
						},
					{
					Pitch	=	100,
					Volume	=	1,
					Distance	=	95,
					Name	=	"Yelp",
					Sound	=	"vcmod/els/cencom/yelp.wav",
						},
					{
					Pitch	=	100,
					Volume	=	1,
					Distance	=	95,
					Name	=	"Priority",
					Sound	=	"vcmod/els/cencom/priority.wav",
						},
					},
			Sections	=	{
				[3]	=	{
						true,
						true,
						},
					},
			Lights	=	{
					{
					Sprite	=	{
						GlowPrxSize	=	10,
						Size	=	0.6,
							},
					Dynamic	=	{
						Brightness	=	2,
						Size	=	0.6,
							},
					UseSprite	=	true,
					Pos	=	Vector(7.4400000572205,-42.080001831055,60),
					UseSiren	=	true,
					RenderInner	=	true,
					Color	=	{
							0,
							55,
							255,
							},
					SpecLine	=	{
						Amount	=	8,
						Pos	=	Vector(-11.699999809265,-42.080001831055,60),
						Use	=	true,
							},
					RenderHD_Adv	=	true,
					UseDynamic	=	true,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	10,
						Size	=	0.6,
							},
					Dynamic	=	{
						Brightness	=	2,
						Size	=	0.6,
							},
					UseSprite	=	true,
					Beta_Inner3D	=	true,
					Pos	=	Vector(-55.310001373291,-42.080001831055,60),
					UseSiren	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					SpecLine	=	{
						Amount	=	8,
						Pos	=	Vector(-36.169998168945,-42.080001831055,60),
						Use	=	true,
							},
					RenderHD_Adv	=	true,
					UseDynamic	=	true,
						},
					},
			Sounds_Horn	=	{
				Use	=	true,
				Volume	=	1,
				Distance	=	95,
				Pitch	=	100,
				Sound	=	"vcmod/els/cencom/bullhorn.wav",
					},
			Sequences	=	{
					{
					SubSeq	=	{
							{
							Stages	=	{
									{
									Lights	=	{
											2,
											},
									Time	=	0.1,
										},
									{
									Lights	=	{
											1,
											},
									Time	=	0.1,
										},
									},
							Time	=	2,
								},
							{
							Stages	=	{
									{
									Lights	=	{
											2,
											},
									Time	=	0.075,
										},
									{
									Lights	=	{
											},
									Time	=	0.075,
										},
									},
							Time	=	0.5,
								},
							{
							Stages	=	{
									{
									Lights	=	{
											1,
											},
									Time	=	0.075,
										},
									{
									Lights	=	{
											},
									Time	=	0.075,
										},
									},
							Time	=	0.5,
								},
							{
							Stages	=	{
									{
									Lights	=	{
											2,
											},
									Time	=	0.3,
										},
									{
									Lights	=	{
											1,
											},
									Time	=	0.3,
										},
									},
							Time	=	2,
								},
							},
					Codes	=	{
							true,
							},
					Lights_Sel	=	{
							true,
							true,
							},
						},
					},
			Sounds_Manual	=	{
				Use	=	true,
				Volume	=	1,
				Distance	=	95,
				Pitch	=	100,
				Sound	=	"vcmod/els/cencom/wail.wav",
					},
				},
		Date	=	"03/05/15 19:56:31",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(0.99000000953674,-135.80999755859,-1.5),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Pos	=	Vector(0,-17,20),
				DoorSounds	=	true,
				Ang	=	Angle(0,0,0),
				EnterRange	=	80,
				RadioControl	=	true,
					},
				{
				switch_rear	=	true,
				Cant_Exit_Lock	=	true,
				Switch_Rear	=	true,
				DoorSounds	=	true,
				Ang	=	Angle(0,0,0),
				EnterRange	=	80,
				RadioControl	=	true,
				Pos	=	Vector(-50,-60,20),
					},
				{
				switch_rear	=	true,
				Cant_Exit_Lock	=	true,
				Switch_Rear	=	true,
				DoorSounds	=	true,
				Ang	=	Angle(0,0,0),
				EnterRange	=	80,
				RadioControl	=	true,
				Pos	=	Vector(0,-60,20),
					},
				},
		DLT	=	3491062886,
		Lights	=	{
				{
				UseSprite	=	true,
				Pos	=	Vector(-63.569999694824,-139.58999633789,20.170000076294),
				UseDynamic	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				Sprite	=	{
					Size	=	0.4,
						},
					},
				{
				UseSprite	=	true,
				Pos	=	Vector(-56.459999084473,-140.2799987793,20.280000686646),
				UseDynamic	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				Sprite	=	{
					Size	=	0.4,
						},
					},
				{
				UseSprite	=	true,
				UseBrake	=	true,
				UseDynamic	=	true,
				Pos	=	Vector(-49.779998779297,-140.94999694824,20.180000305176),
				BrakeColor	=	{
						255,
						55,
						0,
						},
				Sprite	=	{
					Size	=	0.4,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
					},
				{
				UseSprite	=	true,
				Pos	=	Vector(-35.430000305176,-140.47999572754,14.409999847412),
				UseReverse	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				Sprite	=	{
					Size	=	0.3,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.3,
						},
				UseDynamic	=	true,
					},
				{
				UseBlinkers	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.3,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-66.51000213623,-139.63000488281,23.299999237061),
				UseDynamic	=	true,
				RenderInner	=	true,
				Sprite	=	{
					Size	=	0.3,
						},
				RenderInner_Size	=	1.2,
				UseSprite	=	true,
					},
				{
				UseSprite	=	true,
				Pos	=	Vector(-53.479999542236,72.309997558594,19.809999465942),
				UseDynamic	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.6,
						},
				RunningColor	=	{
						246.7,
						204.14,
						218.27,
						},
				Sprite	=	{
					Size	=	0.6,
						},
					},
				{
				UseBlinkers	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.3,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-66.569999694824,70.199996948242,18.840000152588),
				UseDynamic	=	true,
				RenderInner	=	true,
				Sprite	=	{
					Size	=	0.3,
						},
				RenderInner_Size	=	1.2,
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					Size	=	1.2,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.6,
						},
				UseHead	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-60.310001373291,71.769996643066,18.75),
				UseDynamic	=	true,
				HeadColor	=	{
						182,
						208,
						255,
						},
				UsePrjTex	=	true,
				ProjTexture	=	{
					Forward	=	30,
					Size	=	2024,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					Size	=	1.2,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.6,
						},
				UseHead	=	true,
				UseSprite	=	true,
				Pos	=	Vector(15.039999961853,72.440002441406,18.930000305176),
				UseDynamic	=	true,
				HeadColor	=	{
						182,
						208,
						255,
						},
				UsePrjTex	=	true,
				ProjTexture	=	{
					Forward	=	30,
					Size	=	2024,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				UseBlinkers	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.3,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(19.959999084473,68.800003051758,18.360000610352),
				UseDynamic	=	true,
				RenderInner	=	true,
				Sprite	=	{
					Size	=	0.3,
						},
				RenderInner_Size	=	1.2,
				UseSprite	=	true,
					},
				{
				UseSprite	=	true,
				Pos	=	Vector(6.6100001335144,71.449996948242,19.39999961853),
				UseDynamic	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.6,
						},
				RunningColor	=	{
						246.7,
						204.14,
						218.27,
						},
				Sprite	=	{
					Size	=	0.6,
						},
					},
				{
				UseSprite	=	true,
				Pos	=	Vector(17.329999923706,-139.58000183105,20.200000762939),
				UseDynamic	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				Sprite	=	{
					Size	=	0.4,
						},
					},
				{
				UseSprite	=	true,
				Pos	=	Vector(9.6700000762939,-140.28999328613,20.229999542236),
				UseDynamic	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				Sprite	=	{
					Size	=	0.4,
						},
					},
				{
				UseSprite	=	true,
				UseBrake	=	true,
				UseDynamic	=	true,
				Pos	=	Vector(2.3599998950958,-140.97999572754,20.309999465942),
				BrakeColor	=	{
						255,
						55,
						0,
						},
				Sprite	=	{
					Size	=	0.4,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
					},
				{
				UseSprite	=	true,
				Pos	=	Vector(-12.680000305176,-140.61000061035,14.10000038147),
				UseReverse	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				Sprite	=	{
					Size	=	0.3,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.3,
						},
				UseDynamic	=	true,
					},
				{
				UseBlinkers	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.3,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(19.959999084473,-139.41000366211,23.090000152588),
				UseDynamic	=	true,
				RenderInner	=	true,
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.3,
						},
				RenderInner_Size	=	1.2,
				UseSprite	=	true,
					},
				},
		Copyright	=	"DurkaTeam @ 2025 No rights reserved",
		Author	=	"freemmaann",
}