VCModels['models/crsk_autospeugeot406_taxi.mdl']	=	{
		em_state	=	5236594989,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Siren	=	{
			Lights	=	{
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.1,
							},
					SpecSpin	=	{
						Intensity	=	1,
							},
					BGroups	=	{
						[7]	=	{
							[0]	=	"taxi",
								},
							},
					UseDynamic	=	true,
					RenderHD_Size	=	2,
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner_ClrUse	=	false,
					Dynamic	=	{
						Size	=	1,
						Brightness	=	0.1,
							},
					SpecMat	=	{
							},
					Beta_Inner3D	=	true,
					Pos	=	Vector(4.9499998092651,9.0299997329712,71.220001220703),
					IsInterior	=	true,
					RenderInner	=	true,
					Color	=	{
						r	=	220,
						b	=	255,
						a	=	255,
						g	=	225,
							},
					RenderInner_Size	=	1,
					RenderHD_Adv	=	true,
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.26,
							},
					SpecSpin	=	{
						Intensity	=	1,
							},
					IsInterior	=	true,
					RenderInner	=	true,
					RenderHD_Adv	=	true,
					SpecMat	=	{
							},
					UseSprite	=	true,
					BGroups	=	{
						[7]	=	{
							[0]	=	"taxi",
								},
							},
					Beta_Inner3D	=	true,
					Pos	=	Vector(2.210000038147,9.0299997329712,71.209999084473),
					UseDynamic	=	true,
					RenderInner_Size	=	1,
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	155,
							},
					Dynamic	=	{
						Size	=	1,
						Brightness	=	0.1,
							},
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner_ClrUse	=	false,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.2,
							},
					SpecSpin	=	{
						Intensity	=	1,
							},
					BGroups	=	{
						[7]	=	{
							[0]	=	"taxi",
								},
							},
					UseDynamic	=	true,
					RenderHD_Size	=	1.5,
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner_ClrUse	=	false,
					Dynamic	=	{
						Size	=	1,
						Brightness	=	0.1,
							},
					SpecMat	=	{
							},
					Beta_Inner3D	=	true,
					Pos	=	Vector(-0.62000000476837,9.0299997329712,71.209999084473),
					RenderHD_Adv	=	true,
					RenderInner	=	true,
					Color	=	{
						r	=	0,
						b	=	255,
						a	=	255,
						g	=	55,
							},
					RenderInner_Size	=	1,
					UseSprite	=	true,
					IsInterior	=	true,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.2,
							},
					SpecSpin	=	{
						Intensity	=	1,
							},
					BGroups	=	{
						[7]	=	{
							[0]	=	"taxi",
								},
							},
					UseDynamic	=	true,
					RenderHD_Size	=	2,
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner_ClrUse	=	false,
					Dynamic	=	{
						Size	=	1,
						Brightness	=	0.1,
							},
					SpecMat	=	{
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-3.7200000286102,9.0299997329712,71.23999786377),
					IsInterior	=	true,
					RenderInner	=	true,
					Color	=	{
						r	=	55,
						b	=	0,
						a	=	255,
						g	=	124,
							},
					RenderInner_Size	=	1,
					UseSprite	=	true,
					Beta_Inner3D	=	true,
						},
					},
			Sequences	=	{
					{
					SubSeq	=	{
							{
							Type	=	"Custom",
							Time	=	0.65,
							Stages	=	{
									{
									Lights	=	{
											1,
											3,
											},
									Time	=	0.06,
										},
									{
									Lights	=	{
											},
									Time	=	0.06,
										},
									},
								},
							{
							Type	=	"Custom",
							Time	=	0.65,
							Stages	=	{
									{
									Lights	=	{
											2,
											4,
											},
									Time	=	0.06,
										},
									{
									Lights	=	{
											},
									Time	=	0.06,
										},
									},
								},
							{
							Type	=	"Custom",
							Time	=	1.2,
							Stages	=	{
									{
									Lights	=	{
											1,
											3,
											},
									Time	=	0.27,
										},
									{
									Lights	=	{
											2,
											4,
											},
									Time	=	0.27,
										},
									},
								},
							},
					Lights_Sel	=	{
							true,
							true,
							true,
							true,
							},
						},
					{
					SubSeq	=	{
							{
							Type	=	"Custom",
							Time	=	9.6,
							Stages	=	{
									{
									Lights	=	{
											1,
											3,
											},
									Time	=	1.2,
										},
									{
									Lights	=	{
											2,
											4,
											},
									Time	=	1.2,
										},
									},
								},
							{
							Type	=	"Custom",
							Time	=	9.6,
							Stages	=	{
									{
									Lights	=	{
											1,
											3,
											},
									Time	=	0.6,
										},
									{
									Lights	=	{
											2,
											4,
											},
									Time	=	0.6,
										},
									},
								},
							{
							Type	=	"Custom",
							Time	=	9.6,
							Stages	=	{
									{
									Lights	=	{
											1,
											3,
											},
									Time	=	0.28,
										},
									{
									Lights	=	{
											2,
											4,
											},
									Time	=	0.28,
										},
									},
								},
							{
							Type	=	"Custom",
							Time	=	9.6,
							Stages	=	{
									{
									Lights	=	{
											1,
											3,
											},
									Time	=	0.12,
										},
									{
									Lights	=	{
											2,
											4,
											},
									Time	=	0.12,
										},
									},
								},
							},
					Lights_Sel	=	{
							true,
							true,
							true,
							true,
							},
						},
					{
					SubSeq	=	{
							{
							Type	=	"Custom",
							Time	=	0.65,
							Stages	=	{
									{
									Lights	=	{
											1,
											3,
											2,
											4,
											},
									Time	=	0.06,
										},
									},
								},
							},
					Codes	=	{
							true,
							},
					Lights_Sel	=	{
							true,
							true,
							true,
							true,
							},
						},
					},
				},
		Date	=	"Thu Jan 25 03:08:13 2018",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-23.809999465942,-109.31999969482,15.970000267029),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(19.799999237061,19.090000152588,30.129999160767),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(1,0,0),
				Pos	=	Vector(19.930000305176,-31.229999542236,34.040000915527),
					},
				{
				Ang	=	Angle(1,0,0),
				Pos	=	Vector(3.4300000667572,-31.229999542236,34.040000915527),
					},
				{
				Ang	=	Angle(1,0,0),
				Pos	=	Vector(-13.569999694824,-31.229999542236,34.040000915527),
					},
				},
		Copyright	=	"Copyright © 2012-2018 VCMod (freemmaann). All Rights Reserved.",
		HealthEnginePos	=	Vector(5.0599999427795,82.930000305176,34),
		DLT	=	3491063326,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	255,
					a	=	255,
					g	=	253,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(20.479999542236,113.04000091553,31.290000915527),
				UseDynamic	=	true,
				RenderInner_Size	=	0.5,
				UseSprite	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	255,
					b	=	255,
					a	=	255,
					g	=	253,
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(32.220001220703,106.01000213623,31.89999961853),
				RenderInner	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseSprite	=	true,
				RenderInner_Size	=	1,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(39.200000762939,102.44000244141,32.360000610352),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				Beta_Inner3D	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	77,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				RenderMLCenter	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(22.629999160767,-107.15000152588,37.540000915527),
				UseSprite	=	true,
				RenderInner_Size	=	2,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(27.200000762939,-106.5299987793,37.619998931885),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(32.869998931885,-105.61000061035,37.75),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(35.810001373291,-104.73000335693,37.819999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(36.950000762939,-104.08999633789,37.840000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(37.720001220703,-103.09999847412,37.849998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(38.700000762939,-101.30000305176,37.869998931885),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(31.89999961853,-105.44000244141,41.790000915527),
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(33.779998779297,-105.0299987793,41.919998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(35.560001373291,-104.31999969482,42.040000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(36.900001525879,-103.12000274658,42.099998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(37.509998321533,-101.51000213623,42.099998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Size	=	1.8,
				UseBlinkers	=	true,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				UseDynamic	=	true,
				ReverseColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				RenderInner_Clr	=	{
					r	=	247,
					b	=	255,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(25.670000076294,-106.41999816895,41.139999389648),
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	9,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(29.700000762939,-105.80000305176,41.619998931885),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Size	=	1.2,
				Beta_Inner3D	=	true,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	255,
					a	=	255,
					g	=	253,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner_Size	=	0.5,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-19.64999961853,113.16999816895,31.389999389648),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	255,
					b	=	255,
					a	=	255,
					g	=	253,
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-31.39999961853,106.11000061035,32.060001373291),
				RenderInner_Size	=	1,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseSprite	=	true,
				RenderInner	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				UsePrjTex	=	true,
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				HBeamColor	=	{
					r	=	255,
					b	=	255,
					a	=	255,
					g	=	253,
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-19.64999961853,113.16999816895,31.389999389648),
				RenderInner	=	true,
				SpecMat	=	{
						},
				UseSprite	=	true,
				RenderInner_Size	=	0.5,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				UsePrjTex	=	true,
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				HBeamColor	=	{
					r	=	255,
					b	=	255,
					a	=	255,
					g	=	253,
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(20.479999542236,113.04000091553,31.290000915527),
				RenderInner_Size	=	0.5,
				SpecMat	=	{
						},
				UseSprite	=	true,
				RenderInner	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-38.380001068115,102.44999694824,32.590000152588),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				UseDynamic	=	true,
				ReverseColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				RenderInner_Clr	=	{
					r	=	247,
					b	=	255,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-25.889999389648,-106.30999755859,41.180000305176),
				RenderInner_Size	=	1.2,
				SpecMLine	=	{
					Amount	=	9,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-29.920000076294,-105.69000244141,41.659999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-32.259998321533,-105.25,41.990001678467),
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-34.139999389648,-104.83999633789,42.119998931885),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-35.919998168945,-104.12999725342,42.240001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-37.259998321533,-102.93000030518,42.299999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-37.869998931885,-101.31999969482,42.299999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Size	=	1.8,
				RenderMLCenter	=	true,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	77,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				RenderMLCenter	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-22.969999313354,-107.15000152588,37.720001220703),
				UseSprite	=	true,
				RenderInner_Size	=	2,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-27.379999160767,-106.5299987793,37.810001373291),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-33.049999237061,-105.61000061035,37.939998626709),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-35.990001678467,-104.73000335693,38.009998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-37.130001068115,-104.08999633789,38.029998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-37.900001525879,-103.09999847412,38.040000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-38.880001068115,-101.30000305176,38.060001373291),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.01,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	55,
					b	=	0,
					a	=	255,
					g	=	255,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				IsInterior	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-15.449999809265,38.220001220703,45.700000762939),
				UseBlinkers	=	true,
				SpecRec	=	{
					Use	=	true,
					Pos2	=	Vector(-15.430000305176,38.209999084473,45.680000305176),
					Pos4	=	Vector(-15.470000267029,38.229999542236,45.720001220703),
					Pos1	=	Vector(-15.470000267029,38.209999084473,45.680000305176),
					Pos3	=	Vector(-15.430000305176,38.229999542236,45.720001220703),
						},
				UseSprite	=	true,
				BlinkerRight	=	true,
				RenderMLCenter	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-15.140000343323,38.130001068115,45.409999847412),
					UseColor	=	true,
					Pos2	=	Vector(-15.760000228882,38.310001373291,45.990001678467),
					Color	=	{
						r	=	55,
						b	=	0,
						a	=	255,
						g	=	255,
							},
					Use	=	true,
					Pos1	=	Vector(-15.140000343323,38.310001373291,45.990001678467),
					Pos3	=	Vector(-15.760000228882,38.130001068115,45.409999847412),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.01,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					Pos4	=	Vector(-17.680000305176,38.229999542236,45.720001220703),
					Pos2	=	Vector(-17.639999389648,38.209999084473,45.680000305176),
					Use	=	true,
					Pos1	=	Vector(-17.680000305176,38.209999084473,45.680000305176),
					Pos3	=	Vector(-17.639999389648,38.229999542236,45.720001220703),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				IsInterior	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-17.659999847412,38.220001220703,45.700000762939),
				RenderMLCenter	=	true,
				UseBlinkers	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-17.35000038147,38.130001068115,45.409999847412),
					UseColor	=	true,
					Pos2	=	Vector(-17.969999313354,38.310001373291,45.990001678467),
					Color	=	{
						r	=	55,
						b	=	0,
						a	=	255,
						g	=	255,
							},
					Use	=	true,
					Pos1	=	Vector(-17.35000038147,38.310001373291,45.990001678467),
					Pos3	=	Vector(-17.969999313354,38.130001068115,45.409999847412),
						},
				BlinkersColor	=	{
					r	=	55,
					b	=	0,
					a	=	255,
					g	=	255,
						},
				Beta_Inner3D	=	true,
					},
				},
		HealthEnginePosOvr	=	true,
		Fuel	=	{
			FuelLidPos	=	Vector(41.130001068115,-70.529998779297,42),
			FuelType	=	0,
			Capacity	=	70,
			FuelLidUse	=	true,
			Override	=	true,
				},
		Author	=	"CreeperTv1225 (76561198051637331)",
}