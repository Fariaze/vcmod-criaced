VCModels['models/cmbfdrvehiclesazlk_2901.mdl']	=	{
		em_state	=	5236594620,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Siren	=	{
			Sounds	=	{
					{
					Volume	=	1,
					Pitch	=	100,
					Distance	=	95,
					Name	=	"Wail",
					Sound	=	"vcmod/els/cencom/wail.wav",
						},
					{
					Volume	=	1,
					Pitch	=	100,
					Distance	=	95,
					Name	=	"Yelp",
					Sound	=	"vcmod/els/cencom/yelp.wav",
						},
					{
					Volume	=	1,
					Pitch	=	100,
					Distance	=	95,
					Name	=	"Priority",
					Sound	=	"vcmod/els/cencom/priority.wav",
						},
					},
			Sequences	=	{
					{
					SubSeq	=	{
							{
							Stages	=	{
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											1,
											2,
											},
									Time	=	0.025,
										},
									},
							Time	=	2,
							Type	=	"Custom",
								},
							},
					Lights_Sel	=	{
							true,
							true,
							},
						},
					},
			Lights	=	{
					{
					Sprite	=	{
						GlowPrxSize	=	10,
						Size	=	0.32,
							},
					SpecSpin	=	{
						Offset	=	0,
						Use	=	true,
						Speed	=	500,
							},
					Spec3D	=	{
						Mat	=	"vcmod/circle",
						Pos4	=	Vector(-12.229999542236,-13.5,78.730003356934),
						Pos2	=	Vector(-12.229999542236,-13.5,78.730003356934),
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
						Use	=	true,
						Pos1	=	Vector(-12.229999542236,-13.5,78.730003356934),
						Pos3	=	Vector(-12.229999542236,-13.5,78.730003356934),
							},
					SpecMat	=	{
							},
					Dynamic	=	{
						Size	=	0.6,
						Brightness	=	2.1,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-12.229999542236,-13.5,78.730003356934),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
						r	=	0,
						b	=	255,
						a	=	255,
						g	=	55,
							},
					UseSprite	=	true,
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner_ClrUse	=	false,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	10,
						Size	=	0.32,
							},
					SpecSpin	=	{
						Offset	=	90,
						Use	=	true,
						Speed	=	500,
							},
					Spec3D	=	{
						Mat	=	"vcmod/circle",
						Pos4	=	Vector(13.079999923706,-13.5,78.730003356934),
						Pos2	=	Vector(13.079999923706,-13.5,78.730003356934),
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
						Use	=	true,
						Pos1	=	Vector(13.079999923706,-13.5,78.730003356934),
						Pos3	=	Vector(13.079999923706,-13.5,78.730003356934),
							},
					SpecMat	=	{
							},
					Dynamic	=	{
						Size	=	0.6,
						Brightness	=	2.1,
							},
					UseSprite	=	true,
					Pos	=	Vector(13.079999923706,-13.5,78.730003356934),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
						r	=	0,
						b	=	255,
						a	=	255,
						g	=	55,
							},
					RenderHD_Adv	=	true,
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner_ClrUse	=	false,
						},
					},
				},
		Copyright	=	"Copyright © 2012-2018 VCMod (freemmaann). All Rights Reserved.",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-17.620000839233,-100.59999847412,5.3600001335144),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(16.120000839233,21.540000915527,20.450000762939),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(16.120000839233,-8.4099998474121,20.639999389648),
					},
				{
				Ang	=	Angle(0,90,0),
				Pos	=	Vector(13.760000228882,-54.25,31.090000152588),
					},
				{
				Ang	=	Angle(0,90,0),
				Pos	=	Vector(13.760000228882,-73.75,31.090000152588),
					},
				{
				Pos	=	Vector(-10.60000038147,-112.38999938965,47.25),
				DriveBy_Cant	=	true,
				Switch_Rear	=	true,
				Ang	=	Angle(0,0,180),
				Cant_Exit_Lock	=	true,
				Lay	=	true,
					},
				},
		DLT	=	3491063080,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.32,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(33.659999847412,-96.529998779297,24.260000228882),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.32,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-32.360000610352,-96.529998779297,24.260000228882),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.32,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-38.610000610352,49.150001525879,18.479999542236),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.32,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(39.810001373291,49.150001525879,18.479999542236),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8636,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-33.069999694824,100.58000183105,21.479999542236),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8636,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(33.360000610352,100.26000213623,21.479999542236),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4697,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-32.459999084473,-96.610000610352,19.459999084473),
				UseDynamic	=	true,
				UseBrake	=	true,
				UseRunning	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4697,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(33.779998779297,-96.610000610352,19.459999084473),
				UseDynamic	=	true,
				UseRunning	=	true,
				UseBrake	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.32,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-16.780000686646,106.36000061035,17.530000686646),
					Pos2	=	Vector(-29.760000228882,102.4700012207,25.180000305176),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-17.020000457764,104.69000244141,25.180000305176),
					Pos3	=	Vector(-29.790000915527,104.26000213623,17.5),
						},
				HBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				SpecMat	=	{
						},
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Pos	=	Vector(-23.549999237061,104.94999694824,21.190000534058),
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				UseSprite	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.32,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(18,106.36000061035,17.530000686646),
					Pos2	=	Vector(30.979999542236,102.4700012207,25.180000305176),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(18.239999771118,104.69000244141,25.180000305176),
					Pos3	=	Vector(31.010000228882,104.26000213623,17.5),
						},
				HBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UsePrjTex	=	true,
				Pos	=	Vector(24.770000457764,104.94999694824,21.190000534058),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				SpecMat	=	{
						},
				UseSprite	=	true,
				LBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
					},
				},
		Date	=	"Mon Feb 26 17:37:15 2018",
		Fuel	=	{
			FuelType	=	1,
			FuelLidUse	=	true,
			FuelLidPos	=	Vector(38.470001220703,-69.650001525879,19.340000152588),
				},
		Author	=	"TheCarson116 (76561198123551419)",
}