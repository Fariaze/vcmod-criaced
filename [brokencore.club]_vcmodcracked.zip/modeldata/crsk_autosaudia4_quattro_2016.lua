VCModels['models/crsk_autosaudia4_quattro_2016.mdl']	=	{
		em_state	=	5236594722,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		HealthEnginePosOvr	=	true,
		Date	=	"Tue Nov  6 11:21:02 2018",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-26.440000534058,-110.2200012207,16.35000038147),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(25.760000228882,-110.2200012207,16.35000038147),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		Copyright	=	"Copyright © 2012-2018 VCMod (freemmaann). All Rights Reserved.",
		HealthEnginePos	=	Vector(0,74.389999389648,40.569999694824),
		DLT	=	3491063148,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.0609,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseRunning	=	true,
				DD_Blnk_Run	=	true,
				SpecMat	=	{
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-35.669998168945,92.580001831055,31.229999542236),
				UseDynamic	=	true,
				RenderInner_Size	=	1.6108,
				SpecMLine	=	{
					Amount	=	54,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-35.790000915527,89.51000213623,35.360000610352),
								},
							{
							Pos	=	Vector(-20.579999923706,101.83000183105,33.270000457764),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.0286,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-29.309999465942,98.629997253418,30.319999694824),
				UseDynamic	=	true,
				RenderInner_Size	=	2.0978,
				SpecMLine	=	{
					Amount	=	45,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-29.510000228882,98.110000610352,31.420000076294),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-23.020000457764,102.05000305176,30.930000305176),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.0609,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				BlinkerLeft	=	true,
				SpecMat	=	{
						},
				RenderInner_Size	=	1.4243,
				UseSprite	=	true,
				Pos	=	Vector(-35.599998474121,90.76000213623,35.009998321533),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	54,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-20.870000839233,101.98000335693,33.040000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.0325,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBrake	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-35.590000152588,-100.80999755859,37.810001373291),
				UseDynamic	=	true,
				UseRunning	=	true,
				SpecMLine	=	{
					Amount	=	92,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-36.040000915527,-98.910003662109,42.040000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.889999389648,-103.87999725342,42.040000915527),
								},
							{
							Pos	=	Vector(-28.39999961853,-107.08000183105,42.040000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.025,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBrake	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-16,-109.87000274658,41.909999847412),
				UseDynamic	=	true,
				UseRunning	=	true,
				SpecMLine	=	{
					Amount	=	83,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-27.450000762939,-107.94000244141,42.060001373291),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.0325,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-28.89999961853,-106.7799987793,43.130001068115),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	61,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-32.409999847412,-104.30999755859,43.209999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.630001068115,-101.59999847412,43.209999084473),
								},
							{
							Pos	=	Vector(-36.380001068115,-97.629997253418,43.229999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.0978,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-7.3299999237061,-63.150001525879,44.630001068115),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	31,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(7.4899997711182,-63.720001220703,44.630001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.025,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-16,-109.87000274658,42.830001831055),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	83,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-27.60000038147,-107.94000244141,43.169998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.07,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-28.420000076294,-107.04000091553,40.180000305176),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	61,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-31.75,-105,40.240001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.740001678467,-103.15000152588,40.200000762939),
								},
							{
							Pos	=	Vector(-34.479999542236,-102.08000183105,40.180000305176),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.0325,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseRunning	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-28.35000038147,-107.25,38.060001373291),
				UseDynamic	=	true,
				UseBrake	=	true,
				SpecMLine	=	{
					Amount	=	61,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-31.860000610352,-105.34999847412,38.069999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.080001831055,-103.51000213623,38),
								},
							{
							Pos	=	Vector(-34.860000610352,-102.44000244141,38),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.025,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseReverse	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-21.950000762939,-109.01000213623,38.939998626709),
				UseDynamic	=	true,
				ReverseColor	=	{
					r	=	200,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
				SpecMLine	=	{
					Amount	=	83,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-25.930000305176,-108.5299987793,38.450000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.04,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-20.090000152588,-109.01000213623,40.959999084473),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	83,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-26.489999771118,-107.62999725342,40.779998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.450000762939,-107.76999664307,39.830001831055),
								},
							{
							Pos	=	Vector(-20.069999694824,-109,40.909999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.0325,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseRunning	=	true,
				UseSprite	=	true,
				Pos	=	Vector(35.590000152588,-100.80999755859,37.810001373291),
				UseDynamic	=	true,
				UseBrake	=	true,
				SpecMLine	=	{
					Amount	=	92,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(36.040000915527,-98.910003662109,42.040000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.889999389648,-103.87999725342,42.040000915527),
								},
							{
							Pos	=	Vector(28.39999961853,-107.08000183105,42.040000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.0325,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseRunning	=	true,
				UseSprite	=	true,
				Pos	=	Vector(28.10000038147,-107.25,38.060001373291),
				UseDynamic	=	true,
				UseBrake	=	true,
				SpecMLine	=	{
					Amount	=	61,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(31.860000610352,-105.34999847412,38.069999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.080001831055,-103.51000213623,38),
								},
							{
							Pos	=	Vector(34.860000610352,-102.44000244141,38),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.0325,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(28.89999961853,-106.7799987793,43.130001068115),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	61,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(32.409999847412,-104.30999755859,43.209999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.630001068115,-101.59999847412,43.209999084473),
								},
							{
							Pos	=	Vector(36.380001068115,-97.629997253418,43.229999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.07,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(28.14999961853,-107.04000091553,40.180000305176),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	61,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(31.75,-105,40.240001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.740001678467,-103.15000152588,40.200000762939),
								},
							{
							Pos	=	Vector(34.479999542236,-102.08000183105,40.180000305176),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.04,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(19.770000457764,-109.01000213623,40.959999084473),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	83,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(26.489999771118,-107.62999725342,40.779998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.450000762939,-107.76999664307,39.830001831055),
								},
							{
							Pos	=	Vector(20.069999694824,-109,40.909999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.025,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseRunning	=	true,
				UseSprite	=	true,
				Pos	=	Vector(15.619999885559,-109.87000274658,41.909999847412),
				UseDynamic	=	true,
				UseBrake	=	true,
				SpecMLine	=	{
					Amount	=	83,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(27.069999694824,-107.94000244141,42.060001373291),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.025,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(16,-109.87000274658,42.779998779297),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	83,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(27.340000152588,-107.94000244141,43.169998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.025,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseReverse	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(21.510000228882,-109.01000213623,38.939998626709),
				UseDynamic	=	true,
				ReverseColor	=	{
					r	=	200,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
				SpecMLine	=	{
					Amount	=	83,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(25.489999771118,-108.5299987793,38.450000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.03,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				BlinkerLeft	=	true,
				RenderInner_Size	=	2.1804,
				UseSprite	=	true,
				Pos	=	Vector(-42.270000457764,28.639999389648,47.279998779297),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	54,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-45.159999847412,26.709999084473,47.439998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-47.009998321533,24.459999084473,47.599998474121),
								},
							{
							Pos	=	Vector(-47.549999237061,21.620000839233,47.630001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.05,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-7.4499998092651,-64.75,62.029998779297),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	15,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(0,-63.950000762939,62.020000457764),
								},
							{
							Pos	=	Vector(7.0900001525879,-63.299999237061,61.990001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.7,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-34.759998321533,89.980003356934,34.450000762939),
					Pos2	=	Vector(-31.040000915527,89.550003051758,31.75),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-31.14999961853,89.339996337891,34.189998626709),
					Pos3	=	Vector(-34.799999237061,90.099998474121,32.090000152588),
						},
				SpecMat	=	{
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				ReducedVis	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-33.080001831055,91.129997253418,33.200000762939),
				Beta_Inner3D	=	true,
				Dynamic	=	{
					Size	=	0.33,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.7,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(35.409999847412,89.980003356934,34.389999389648),
					Pos2	=	Vector(31.690000534058,89.550003051758,31.690000534058),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(31.799999237061,89.339996337891,34.130001068115),
					Pos3	=	Vector(35.450000762939,90.099998474121,32.029998779297),
						},
				SpecMat	=	{
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				ReducedVis	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(33.569999694824,91.129997253418,33.069999694824),
				UseSprite	=	true,
				Dynamic	=	{
					Size	=	0.33,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-30.370000839233,94.199996948242,34.229999542236),
					Pos2	=	Vector(-24.540000915527,96.139999389648,31.520000457764),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-24.770000457764,96.089996337891,33.680000305176),
					Pos3	=	Vector(-29.85000038147,94.300003051758,32.240001678467),
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.33,
					Brightness	=	2,
						},
				Pos	=	Vector(-27.530000686646,95.830001831055,32.939998626709),
				SpecMat	=	{
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(31.069999694824,94.199996948242,34.229999542236),
					Pos2	=	Vector(25.239999771118,96.139999389648,31.520000457764),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(25.469999313354,96.089996337891,33.680000305176),
					Pos3	=	Vector(30.549999237061,94.300003051758,32.240001678467),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.33,
					Brightness	=	2,
						},
				Pos	=	Vector(28.229999542236,95.830001831055,32.939998626709),
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-25.200000762939,96.910003662109,33.75),
					Pos2	=	Vector(-21.930000305176,98.48999786377,31.290000915527),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-20.659999847412,98.889999389648,33.040000915527),
					Pos3	=	Vector(-24.799999237061,97.300003051758,31.860000610352),
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.33,
					Brightness	=	2,
						},
				Pos	=	Vector(-23.430000305176,98.699996948242,32.380001068115),
				SpecMat	=	{
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(25.969999313354,96.910003662109,33.630001068115),
					Pos2	=	Vector(22.700000762939,98.48999786377,31.170000076294),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(21.430000305176,98.889999389648,32.919998168945),
					Pos3	=	Vector(25.569999694824,97.300003051758,31.739999771118),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.33,
					Brightness	=	2,
						},
				Pos	=	Vector(24.200000762939,98.699996948242,32.259998321533),
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.0286,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(29.309999465942,98.629997253418,30.319999694824),
				UseDynamic	=	true,
				RenderInner_Size	=	2.0978,
				SpecMLine	=	{
					Amount	=	45,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(29.510000228882,98.110000610352,31.420000076294),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(23.020000457764,102.05000305176,30.930000305176),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.0609,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseRunning	=	true,
				DD_Blnk_Run	=	true,
				SpecMat	=	{
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				RenderInner_Size	=	1.6108,
				UseSprite	=	true,
				Pos	=	Vector(35.669998168945,92.580001831055,31.229999542236),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	54,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(35.790000915527,89.51000213623,35.360000610352),
								},
							{
							Pos	=	Vector(20.579999923706,101.83000183105,33.270000457764),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.0609,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				BlinkerRight	=	true,
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(35.599998474121,90.76000213623,35.009998321533),
				UseDynamic	=	true,
				RenderInner_Size	=	1.4243,
				SpecMLine	=	{
					Amount	=	54,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(20.870000839233,101.98000335693,33.040000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseBlinkers	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.03,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				BlinkerRight	=	true,
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(42.270000457764,28.639999389648,47.279998779297),
				UseDynamic	=	true,
				RenderInner_Size	=	2.1804,
				SpecMLine	=	{
					Amount	=	54,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(45.159999847412,26.709999084473,47.439998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(47.009998321533,24.459999084473,47.599998474121),
								},
							{
							Pos	=	Vector(47.549999237061,21.620000839233,47.630001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseBlinkers	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(19,0,0),
				Pos	=	Vector(16.760000228882,9.8400001525879,31.840000152588),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(19,0,0),
				Pos	=	Vector(16.760000228882,-33.669998168945,33.049999237061),
					},
				{
				Ang	=	Angle(19,0,0),
				Pos	=	Vector(-18.770000457764,-33.669998168945,33.049999237061),
					},
				{
				Ang	=	Angle(19,0,0),
				Pos	=	Vector(0,-33.669998168945,33.049999237061),
					},
				},
		Fuel	=	{
			FuelLidPos	=	Vector(38.689998626709,-69.019996643066,43.590000152588),
			FuelLidUse	=	true,
			FuelType	=	0,
			Capacity	=	58,
			FuelTypeUse	=	true,
			Override	=	true,
				},
		Author	=	"DangerKiddy(DK) (76561198132964487)",
}