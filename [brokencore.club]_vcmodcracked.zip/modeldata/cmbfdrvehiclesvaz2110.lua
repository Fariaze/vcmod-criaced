VCModels['models/cmbfdrvehiclesvaz2110.mdl']	=	{
		em_state	=	5236594587,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Copyright	=	"Copyright © 2012-2018 VCMod (freemmaann). All Rights Reserved.",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(-22.079999923706,-101.2200012207,13.659999847412),
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(15.619999885559,8.1099996566772,27.709999084473),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(-16.829999923706,-29.959999084473,27.709999084473),
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(13.159999847412,-29.959999084473,27.709999084473),
					},
				},
		DLT	=	3491063058,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.3438,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UsePrjTex	=	true,
				SpecMat	=	{
						},
				HBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner_Size	=	1,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-21.010000228882,86.309997558594,26.920000076294),
				UseHighBeams	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.3438,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				SpecMat	=	{
						},
				Beta_Inner3D	=	true,
				HBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner_Size	=	1,
				UseHighBeams	=	true,
				Pos	=	Vector(-26.25,85.48999786377,26.950000762939),
				UseSprite	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6205,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-31.959999084473,81.23999786377,26.950000762939),
				UseBlinkers	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4703,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				FogColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				SpecMat	=	{
						},
				UsePrjTex	=	true,
				Pos	=	Vector(-19.450000762939,86.639999389648,11.289999961853),
				UseFog	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				Beta_Inner3D	=	true,
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2457,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-37.599998474121,38.709999084473,28.75),
				UseBlinkers	=	true,
				RenderInner_Size	=	1,
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4395,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-25.520000457764,-97.470001220703,35.369998931885),
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	11,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-32.409999847412,-95.580001831055,35.369998931885),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-34.099998474121,-91.279998779297,35.369998931885),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2375,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseSprite	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecMat	=	{
						},
				UseBrake	=	true,
				UseRunning	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-25.520000457764,-97.470001220703,31.940000534058),
				RenderInner	=	true,
				RenderInner_Size	=	2.1781,
				SpecMLine	=	{
					Amount	=	32,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-32.409999847412,-95.580001831055,31.940000534058),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-34.099998474121,-91.279998779297,31.940000534058),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1207,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseReverse	=	true,
				SpecRec	=	{
					AmountV	=	5,
					Pos4	=	Vector(-20.020000457764,-99.269996643066,31.049999237061),
					Mid_Full	=	true,
					Pos2	=	Vector(-23.760000228882,-97.569999694824,36.189998626709),
					AmountH	=	4,
					Use	=	true,
					Pos1	=	Vector(-19.989999771118,-98.190002441406,36.189998626709),
					Pos3	=	Vector(-23.790000915527,-98.650001525879,31.049999237061),
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-21.889999389648,-98.419998168945,33.619998931885),
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.0984,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecRec	=	{
					AmountV	=	8,
					Pos4	=	Vector(-16.909999847412,-100.04000091553,31.110000610352),
					Mid_Full	=	true,
					Pos2	=	Vector(-18.549999237061,-97.900001525879,36.130001068115),
					AmountH	=	5,
					Use	=	true,
					Pos1	=	Vector(-16.790000915527,-98.279998779297,36.130001068115),
					Pos3	=	Vector(-18.670000076294,-99.660003662109,31.110000610352),
						},
				SpecMat	=	{
						},
				Beta_Inner3D	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-17.729999542236,-98.970001220703,33.619998931885),
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Size	=	2.4347,
				UseRunning	=	true,
				RenderInner	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.3438,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UsePrjTex	=	true,
				SpecMat	=	{
						},
				HBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseHighBeams	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(18.260000228882,86.309997558594,26.920000076294),
				RenderInner_Size	=	1,
				RenderInner	=	true,
				UseSprite	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.3438,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				SpecMat	=	{
						},
				UseSprite	=	true,
				HBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner_Size	=	1,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner	=	true,
				UseHighBeams	=	true,
				Pos	=	Vector(23.389999389648,85.48999786377,26.950000762939),
				Beta_Inner3D	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6205,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(29.549999237061,81.23999786377,26.950000762939),
				UseBlinkers	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4703,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				FogColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				SpecMat	=	{
						},
				UsePrjTex	=	true,
				Pos	=	Vector(16.540000915527,86.639999389648,11.289999961853),
				UseFog	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				Beta_Inner3D	=	true,
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2457,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(36.020000457764,38.709999084473,28.75),
				UseBlinkers	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4395,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				UseBlinkers	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(22.520000457764,-97.470001220703,35.369998931885),
				UseSprite	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	11,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(29.409999847412,-95.580001831055,35.369998931885),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(31.10000038147,-91.279998779297,35.369998931885),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2375,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseSprite	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecMat	=	{
						},
				UseBrake	=	true,
				UseRunning	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(22.639999389648,-97.470001220703,31.940000534058),
				RenderInner	=	true,
				RenderInner_Size	=	2.1781,
				SpecMLine	=	{
					Amount	=	32,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(29.530000686646,-95.580001831055,31.940000534058),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(31.219999313354,-91.279998779297,31.940000534058),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1207,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseReverse	=	true,
				SpecRec	=	{
					AmountV	=	5,
					Pos4	=	Vector(16.940000534058,-99.269996643066,31.049999237061),
					Mid_Full	=	true,
					Pos2	=	Vector(20.680000305176,-97.569999694824,36.189998626709),
					AmountH	=	4,
					Use	=	true,
					Pos1	=	Vector(16.909999847412,-98.190002441406,36.189998626709),
					Pos3	=	Vector(20.709999084473,-98.650001525879,31.049999237061),
						},
				SpecMat	=	{
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(18.809999465942,-98.419998168945,33.619998931885),
				UseSprite	=	true,
				RenderInner_Size	=	1,
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.0984,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecRec	=	{
					AmountV	=	8,
					Pos4	=	Vector(13.869999885559,-100.04000091553,31.110000610352),
					Mid_Full	=	true,
					Pos2	=	Vector(15.510000228882,-97.900001525879,36.130001068115),
					AmountH	=	5,
					Use	=	true,
					Pos1	=	Vector(13.75,-98.279998779297,36.130001068115),
					Pos3	=	Vector(15.630000114441,-99.660003662109,31.110000610352),
						},
				SpecMat	=	{
						},
				UseRunning	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(14.689999580383,-98.970001220703,33.619998931885),
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner	=	true,
				RenderInner_Size	=	2.4347,
				UseSprite	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	true,
					},
				},
		Date	=	"Sun Apr  1 14:37:59 2018",
		Fuel	=	{
			FuelType	=	0,
				},
		Author	=	"SGM ツ (76561197999836749)",
}