VCModels['models/black_mesa_vehicleshummertow.mdl']	=	{
		em_state	=	5236594488,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Copyright	=	"DurkaTeam @ 2025 No rights reserved",
		Exhaust	=	{
				{
				Ang	=	Angle(35,-90,0),
				Pos	=	Vector(22.450000762939,-93.050003051758,33.459999084473),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Pos	=	Vector(36.470001220703,21.069999694824,49.150001525879),
				DoorSounds	=	true,
				Ang	=	Angle(0,0,0),
				EnterRange	=	80,
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(-36.470001220703,-22.590000152588,49.150001525879),
				EnterRange	=	80,
				DoorSounds	=	true,
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(36.470001220703,-22.590000152588,49.150001525879),
				EnterRange	=	80,
				DoorSounds	=	true,
					},
				},
		DLT	=	3491062992,
		Lights	=	{
				{
				Sprite	=	{
					Size	=	0.4,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
				UseSprite	=	true,
				Pos	=	Vector(-40.389999389648,-115.06999969482,52.779998779297),
				UseDynamic	=	true,
				UseRunning	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseBrake	=	true,
					},
				{
				UseBlinkers	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.3,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(-48.729999542236,-113.48999786377,47.459999084473),
				UseDynamic	=	true,
				RenderInner	=	true,
				Sprite	=	{
					Size	=	0.3,
						},
				RenderInner_Size	=	1.2,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					Size	=	0.2,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.2,
						},
				UseReverse	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				UseDynamic	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-40.099998474121,-115.06999969482,48.939998626709),
					},
				{
				Sprite	=	{
					Size	=	1.2,
						},
				ProjTexture	=	{
					Forward	=	30,
					Size	=	2024,
					Angle	=	Angle(0,90,0),
						},
				UseHead	=	true,
				UsePrjTex	=	true,
				Pos	=	Vector(-24.030000686646,113.69999694824,46.630001068115),
				UseDynamic	=	true,
				HeadColor	=	{
						214,
						222,
						255,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.6,
						},
				UseSprite	=	true,
					},
				{
				UseBlinkers	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.3,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(-47.409999847412,113.19000244141,52.759998321533),
				UseDynamic	=	true,
				RenderInner	=	true,
				Sprite	=	{
					Size	=	0.3,
						},
				RenderInner_Size	=	1.2,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					Size	=	0.6,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.6,
						},
				UseDynamic	=	true,
				UseRunning	=	true,
				UseSprite	=	true,
				RunningColor	=	{
						233.91,
						251.75,
						254.1,
						},
				Pos	=	Vector(-24.030000686646,114.15000152588,46.630001068115),
					},
				{
				Sprite	=	{
					Size	=	0.4,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
				UseSprite	=	true,
				Pos	=	Vector(40.389999389648,-115.06999969482,52.779998779297),
				UseDynamic	=	true,
				UseRunning	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseBrake	=	true,
					},
				{
				UseBlinkers	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.3,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(48.729999542236,-113.48999786377,47.459999084473),
				UseDynamic	=	true,
				RenderInner	=	true,
				Sprite	=	{
					Size	=	0.3,
						},
				RenderInner_Size	=	1.2,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					Size	=	0.2,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.2,
						},
				UseReverse	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				UseDynamic	=	true,
				UseSprite	=	true,
				Pos	=	Vector(40.099998474121,-115.06999969482,48.939998626709),
					},
				{
				Sprite	=	{
					Size	=	1.2,
						},
				ProjTexture	=	{
					Forward	=	30,
					Size	=	2024,
					Angle	=	Angle(0,90,0),
						},
				UseHead	=	true,
				UsePrjTex	=	true,
				Pos	=	Vector(24.030000686646,113.69999694824,46.630001068115),
				UseDynamic	=	true,
				HeadColor	=	{
						214,
						222,
						255,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.6,
						},
				UseSprite	=	true,
					},
				{
				UseBlinkers	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.3,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(47.409999847412,113.19000244141,52.759998321533),
				UseDynamic	=	true,
				RenderInner	=	true,
				Sprite	=	{
					Size	=	0.3,
						},
				RenderInner_Size	=	1.2,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					Size	=	0.6,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.6,
						},
				UseDynamic	=	true,
				UseRunning	=	true,
				UseSprite	=	true,
				RunningColor	=	{
						233.91,
						251.75,
						254.1,
						},
				Pos	=	Vector(24.030000686646,114.15000152588,46.630001068115),
					},
				},
		Date	=	"06/30/15 22:32:42",
		Author	=	"freemmaann (STEAM_0:1:14528726)",
}