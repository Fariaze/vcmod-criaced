-- DurkaTeam @ 2025 Никакие права не защищены
ENT.Base 		= "base_anim"
ENT.Type 		= "anim"
ENT.PrintName	= "Fuel: Electric"
ENT.Author		= "freemmaann"
ENT.Category	= "VCMod"

ENT.Spawnable = false
ENT.AdminSpawnable = false

ENT.VC_Type = "fuel"
ENT.VC_FuelType = 2
ENT.VC_CanBeDamaged = true