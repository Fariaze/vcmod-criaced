VCModels['models/black_mesa_vehiclesjeep01.mdl']	=	{
		em_state	=	5236595064,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Siren	=	{
			Sounds	=	{
					{
					Pitch	=	100,
					Volume	=	1,
					Distance	=	95,
					Name	=	"Wail",
					Sound	=	"vcmod/els/e-q2b/wail.wav",
						},
					{
					Pitch	=	100,
					Volume	=	1,
					Distance	=	95,
					Name	=	"Yelp",
					Sound	=	"vcmod/els/e-q2b/yelp.wav",
						},
					},
			Sequences	=	{
					{
					SubSeq	=	{
							{
							Type	=	"Custom",
							Time	=	0.5,
							Stages	=	{
									{
									Lights	=	{
											1,
											2,
											3,
											4,
											5,
											6,
											7,
											},
									Time	=	0.01,
										},
									},
								},
							},
					Codes	=	{
							true,
							},
					Lights_Sel	=	{
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							},
						},
					},
			Lights	=	{
					{
					Sprite	=	{
						GlowPrxSize	=	5,
						Size	=	0.6,
							},
					Dynamic	=	{
						Brightness	=	2,
						Size	=	0.6,
							},
					Spec3D	=	{
						Mat	=	"vcmod/circle",
						Pos4	=	Vector(-17.64999961853,1.2300000190735,85.410003662109),
						Pos2	=	Vector(-17.64999961853,6.0500001907349,80.589996337891),
						Color	=	{
								0,
								0,
								0,
								},
						Use	=	true,
						Pos1	=	Vector(-17.64999961853,6.0500001907349,85.410003662109),
						Pos3	=	Vector(-17.64999961853,1.2300000190735,80.589996337891),
							},
					Beta_Inner3D	=	true,
					UseSprite	=	true,
					Pos	=	Vector(-17.64999961853,3.6400001049042,83),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					RenderHD_Adv	=	true,
					UseSiren	=	true,
					SpecSpin	=	{
						Rotated	=	true,
						Offset	=	0,
						Speed	=	500,
						Use	=	true,
						Intensity	=	0.7,
							},
						},
					{
					Sprite	=	{
						GlowPrxSize	=	5,
						Size	=	0.6,
							},
					Dynamic	=	{
						Brightness	=	2,
						Size	=	0.6,
							},
					Spec3D	=	{
						Mat	=	"vcmod/circle",
						Pos4	=	Vector(-26.379999160767,0.51999998092651,85.410003662109),
						Pos2	=	Vector(-26.379999160767,5.3400001525879,80.589996337891),
						Color	=	{
								0,
								0,
								0,
								},
						Use	=	true,
						Pos1	=	Vector(-26.379999160767,5.3400001525879,85.410003662109),
						Pos3	=	Vector(-26.379999160767,0.51999998092651,80.589996337891),
							},
					Beta_Inner3D	=	true,
					UseSprite	=	true,
					Pos	=	Vector(-26.379999160767,2.9300000667572,83),
					UseSiren	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					RenderHD_Adv	=	true,
					UseDynamic	=	true,
					SpecSpin	=	{
						Rotated	=	true,
						Offset	=	20,
						Speed	=	500,
						Use	=	true,
						Intensity	=	0.7,
							},
						},
					{
					Sprite	=	{
						GlowPrxSize	=	5,
						Size	=	0.6,
							},
					Dynamic	=	{
						Brightness	=	2,
						Size	=	0.6,
							},
					Spec3D	=	{
						Mat	=	"vcmod/circle",
						Pos4	=	Vector(-9.4700002670288,2.2999999523163,85.410003662109),
						Pos2	=	Vector(-9.4700002670288,7.1199998855591,80.589996337891),
						Color	=	{
								0,
								0,
								0,
								},
						Use	=	true,
						Pos1	=	Vector(-9.4700002670288,7.1199998855591,85.410003662109),
						Pos3	=	Vector(-9.4700002670288,2.2999999523163,80.589996337891),
							},
					Beta_Inner3D	=	true,
					UseSprite	=	true,
					Pos	=	Vector(-9.4700002670288,4.710000038147,83),
					UseSiren	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					RenderHD_Adv	=	true,
					UseDynamic	=	true,
					SpecSpin	=	{
						Rotated	=	true,
						Offset	=	-20,
						Speed	=	500,
						Use	=	true,
						Intensity	=	0.7,
							},
						},
					{
					Sprite	=	{
						GlowPrxSize	=	5,
						Size	=	0.6,
							},
					Dynamic	=	{
						Brightness	=	2,
						Size	=	0.6,
							},
					Spec3D	=	{
						Mat	=	"vcmod/circle",
						Pos4	=	Vector(17.64999961853,1.2300000190735,85.410003662109),
						Pos2	=	Vector(17.64999961853,6.0500001907349,80.589996337891),
						Color	=	{
								0,
								0,
								0,
								},
						Use	=	true,
						Pos1	=	Vector(17.64999961853,6.0500001907349,85.410003662109),
						Pos3	=	Vector(17.64999961853,1.2300000190735,80.589996337891),
							},
					Beta_Inner3D	=	true,
					UseSprite	=	true,
					Pos	=	Vector(17.64999961853,3.6400001049042,83),
					UseSiren	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					RenderHD_Adv	=	true,
					UseDynamic	=	true,
					SpecSpin	=	{
						Rotated	=	true,
						Offset	=	0,
						Speed	=	500,
						Use	=	true,
						Intensity	=	0.7,
							},
						},
					{
					Sprite	=	{
						GlowPrxSize	=	5,
						Size	=	0.6,
							},
					Dynamic	=	{
						Brightness	=	2,
						Size	=	0.6,
							},
					Spec3D	=	{
						Mat	=	"vcmod/circle",
						Pos4	=	Vector(26.379999160767,0.51999998092651,85.410003662109),
						Pos2	=	Vector(26.379999160767,5.3400001525879,80.589996337891),
						Color	=	{
								0,
								0,
								0,
								},
						Use	=	true,
						Pos1	=	Vector(26.379999160767,5.3400001525879,85.410003662109),
						Pos3	=	Vector(26.379999160767,0.51999998092651,80.589996337891),
							},
					Beta_Inner3D	=	true,
					UseSprite	=	true,
					Pos	=	Vector(26.379999160767,2.9300000667572,83),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					RenderHD_Adv	=	true,
					UseSiren	=	true,
					SpecSpin	=	{
						Rotated	=	true,
						Offset	=	20,
						Speed	=	500,
						Use	=	true,
						Intensity	=	0.7,
							},
						},
					{
					Sprite	=	{
						GlowPrxSize	=	5,
						Size	=	0.6,
							},
					Dynamic	=	{
						Brightness	=	2,
						Size	=	0.6,
							},
					Spec3D	=	{
						Mat	=	"vcmod/circle",
						Pos4	=	Vector(0.10999999940395,2.7799999713898,85.410003662109),
						Pos2	=	Vector(0.10999999940395,7.5999999046326,80.589996337891),
						Color	=	{
								0,
								0,
								0,
								},
						Use	=	true,
						Pos1	=	Vector(0.10999999940395,7.5999999046326,85.410003662109),
						Pos3	=	Vector(0.10999999940395,2.7799999713898,80.589996337891),
							},
					Beta_Inner3D	=	true,
					UseSprite	=	true,
					Pos	=	Vector(-0.12999999523163,5.25,83),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					RenderHD_Adv	=	true,
					UseSiren	=	true,
					SpecSpin	=	{
						Rotated	=	true,
						Offset	=	-40,
						Speed	=	500,
						Use	=	true,
						Intensity	=	0.7,
							},
						},
					{
					Sprite	=	{
						GlowPrxSize	=	5,
						Size	=	0.6,
							},
					Dynamic	=	{
						Brightness	=	2,
						Size	=	0.6,
							},
					Spec3D	=	{
						Mat	=	"vcmod/circle",
						Pos4	=	Vector(9.4700002670288,2.2999999523163,85.410003662109),
						Pos2	=	Vector(9.4700002670288,7.1199998855591,80.589996337891),
						Color	=	{
								0,
								0,
								0,
								},
						Use	=	true,
						Pos1	=	Vector(9.4700002670288,7.1199998855591,85.410003662109),
						Pos3	=	Vector(9.4700002670288,2.2999999523163,80.589996337891),
							},
					Beta_Inner3D	=	true,
					UseSprite	=	true,
					Pos	=	Vector(9.4700002670288,4.710000038147,83),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					RenderHD_Adv	=	true,
					UseSiren	=	true,
					SpecSpin	=	{
						Rotated	=	true,
						Offset	=	-20,
						Speed	=	500,
						Use	=	true,
						Intensity	=	0.7,
							},
						},
					},
				},
		Date	=	"07/01/15 02:46:16",
		Exhaust	=	{
				{
				Ang	=	Angle(30,-125,0),
				Pos	=	Vector(-37.180000305176,-82.029998779297,18.670000076294),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Pos	=	Vector(18.799999237061,13.550000190735,41.880001068115),
				DoorSounds	=	true,
				Ang	=	Angle(0,0,0),
				EnterRange	=	80,
				RadioControl	=	true,
					},
				{
				Cant_Exit_Lock	=	true,
				Ang	=	Angle(0,0,0),
				DoorSounds	=	true,
				Switch_Rear	=	true,
				EnterRange	=	80,
				switch_rear	=	true,
				Pos	=	Vector(-14.25,-19.190000534058,42.880001068115),
					},
				{
				Cant_Exit_Lock	=	true,
				Ang	=	Angle(0,0,0),
				DoorSounds	=	true,
				Switch_Rear	=	true,
				EnterRange	=	80,
				switch_rear	=	true,
				Pos	=	Vector(14.25,-19.190000534058,42.880001068115),
					},
				},
		DLT	=	3491063376,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.275,
						},
				UseReverse	=	true,
				UseSprite	=	true,
				SpecMLine	=	{
					Amount	=	6,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-35.299999237061,-86.75,38.240001678467),
								},
							{
							Pos	=	Vector(-33.189998626709,-88.089996337891,38.259998321533),
								},
							{
							Pos	=	Vector(-31.069999694824,-88.309997558594,38.270000457764),
								},
							},
						},
				Pos	=	Vector(-35.470001220703,-85.459999084473,38.099998474121),
				UseDynamic	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
					},
				{
				UseBlinkers	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.3,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(-35.380001068115,-85.830001831055,40.040000915527),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	4,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-34.880001068115,-86.550003051758,40.040000915527),
								},
							{
							Pos	=	Vector(-32.610000610352,-88.150001525879,40.080001831055),
								},
							{
							Pos	=	Vector(-31.459999084473,-88.339996337891,40.090000152588),
								},
							},
						},
				Sprite	=	{
					Size	=	0.1,
						},
				RenderInner_Size	=	1.2,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					Size	=	0.4,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
				UseSprite	=	true,
				Pos	=	Vector(-32.790000915527,-87.620002746582,43.759998321533),
				UseDynamic	=	true,
				UseRunning	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					Size	=	0.6,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.6,
						},
				UseDynamic	=	true,
				UseRunning	=	true,
				UseSprite	=	true,
				RunningColor	=	{
						234.35,
						203.7,
						203.05,
						},
				Pos	=	Vector(-13.739999771118,100.23999786377,41.959999084473),
					},
				{
				Sprite	=	{
					Size	=	1.2,
						},
				ProjTexture	=	{
					Forward	=	30,
					Size	=	2024,
					Angle	=	Angle(0,90,0),
						},
				UseHead	=	true,
				UsePrjTex	=	true,
				Pos	=	Vector(-29.829999923706,91.480003356934,42.860000610352),
				UseDynamic	=	true,
				HeadColor	=	{
						184,
						223,
						255,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.6,
						},
				UseSprite	=	true,
					},
				{
				UseBlinkers	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-25.209999084473,91.76000213623,36.729999542236),
				UseDynamic	=	true,
				RenderInner	=	true,
				Sprite	=	{
					Size	=	0.2,
						},
				SpecLine	=	{
					Amount	=	5,
					Pos	=	Vector(-33.349998474121,91.76000213623,36.729999542236),
					Use	=	true,
						},
				RenderInner_Size	=	1.2,
				UseSprite	=	true,
					},
				{
				UseBlinkers	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-37.209999084473,90.290000915527,35.169998168945),
				UseDynamic	=	true,
				RenderInner	=	true,
				Sprite	=	{
					Size	=	0.2,
						},
				SpecLine	=	{
					Amount	=	8,
					Pos	=	Vector(-36.240001678467,89.480003356934,44.880001068115),
					Use	=	true,
						},
				RenderInner_Size	=	1.2,
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.275,
						},
				UseReverse	=	true,
				UseSprite	=	true,
				SpecMLine	=	{
					Amount	=	6,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(35.299999237061,-86.75,38.240001678467),
								},
							{
							Pos	=	Vector(33.189998626709,-88.089996337891,38.259998321533),
								},
							{
							Pos	=	Vector(31.069999694824,-88.309997558594,38.270000457764),
								},
							},
						},
				Pos	=	Vector(35.470001220703,-85.459999084473,38.099998474121),
				UseDynamic	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
					},
				{
				UseBlinkers	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.3,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(35.380001068115,-85.830001831055,40.040000915527),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	4,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(34.880001068115,-86.550003051758,40.040000915527),
								},
							{
							Pos	=	Vector(32.610000610352,-88.150001525879,40.080001831055),
								},
							{
							Pos	=	Vector(31.459999084473,-88.339996337891,40.090000152588),
								},
							},
						},
				Sprite	=	{
					Size	=	0.1,
						},
				RenderInner_Size	=	1.2,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					Size	=	0.4,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
				UseSprite	=	true,
				Pos	=	Vector(32.790000915527,-87.620002746582,43.759998321533),
				UseDynamic	=	true,
				UseRunning	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					Size	=	0.6,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.6,
						},
				UseDynamic	=	true,
				UseRunning	=	true,
				UseSprite	=	true,
				RunningColor	=	{
						234.35,
						203.7,
						203.05,
						},
				Pos	=	Vector(13.739999771118,100.23999786377,41.959999084473),
					},
				{
				Sprite	=	{
					Size	=	1.2,
						},
				ProjTexture	=	{
					Forward	=	30,
					Size	=	2024,
					Angle	=	Angle(0,90,0),
						},
				UseHead	=	true,
				UsePrjTex	=	true,
				Pos	=	Vector(29.829999923706,91.480003356934,42.860000610352),
				UseDynamic	=	true,
				HeadColor	=	{
						184,
						223,
						255,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.6,
						},
				UseSprite	=	true,
					},
				{
				UseBlinkers	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(25.209999084473,91.76000213623,36.729999542236),
				UseDynamic	=	true,
				RenderInner	=	true,
				Sprite	=	{
					Size	=	0.2,
						},
				SpecLine	=	{
					Amount	=	5,
					Pos	=	Vector(33.349998474121,91.76000213623,36.729999542236),
					Use	=	true,
						},
				RenderInner_Size	=	1.2,
				UseSprite	=	true,
					},
				{
				UseBlinkers	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(37.209999084473,90.290000915527,35.169998168945),
				UseDynamic	=	true,
				RenderInner	=	true,
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.2,
						},
				SpecLine	=	{
					Amount	=	8,
					Pos	=	Vector(36.240001678467,89.480003356934,44.880001068115),
					Use	=	true,
						},
				RenderInner_Size	=	1.2,
				UseSprite	=	true,
					},
				},
		Copyright	=	"DurkaTeam @ 2025 No rights reserved",
		Author	=	"freemmaann (STEAM_0:1:14528726)",
}