VCModels['models/ctruck.mdl']	=	{
		IsBig	=	true,
		em_state	=	5236594674,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Date	=	"07/01/15 20:25:17",
		Exhaust	=	{
				{
				Ang	=	Angle(40,-70,0),
				Pos	=	Vector(32.299999237061,-127.55999755859,55.450000762939),
				EffectStress	=	"VC_Exhaust_Truck_Stress",
				EffectIdle	=	"VC_Exhaust_Truck",
					},
				},
		Sound_Backup	=	true,
		ExtraSeats	=	{
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(27.420000076294,122.12999725342,84.589996337891),
				RadioControl	=	true,
					},
				},
		DLT	=	3491063116,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseReverse	=	true,
				UseDynamic	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				SpecLine	=	{
					Amount	=	6,
					Use	=	true,
					Pos	=	Vector(-27.450000762939,-172,48.880001068115),
						},
				Pos	=	Vector(-27.450000762939,-172,53.220001220703),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(-37.340000152588,-172.30999755859,50.759998321533),
				UseDynamic	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1.2,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.45,
						},
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-31.889999389648,-172.30999755859,50.759998321533),
				UseDynamic	=	true,
				UseBrake	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				Pos	=	Vector(-44.689998626709,-174.74000549316,164.2799987793),
				UseSprite	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				FogColor	=	{
						255,
						55,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(-10.920000076294,-174.78999328613,164.52000427246),
				UseDynamic	=	true,
				UseFog	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				Pos	=	Vector(0,-174.78999328613,164.52000427246),
				UseSprite	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				Pos	=	Vector(-56.950000762939,-164.41000366211,62.450000762939),
				UseSprite	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				Pos	=	Vector(-56.229999542236,-160.47999572754,164.97999572754),
				UseSprite	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				Pos	=	Vector(-55.159999847412,82.029998779297,162.00999450684),
				UseSprite	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(-32.139999389648,169.02000427246,58.409999847412),
				UseDynamic	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				SpecLine	=	{
					Amount	=	9,
					Pos	=	Vector(-43.029998779297,168.94000244141,58.720001220703),
					Use	=	true,
						},
				RenderInner_Size	=	1.2,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				FogColor	=	{
						220,
						225,
						255,
						},
				UsePrjTex	=	true,
				Pos	=	Vector(-37.939998626709,168.85000610352,50.619998931885),
				UseDynamic	=	true,
				UseFog	=	true,
				UseSprite	=	true,
				ProjTexture	=	{
					Size	=	2000,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				ProjTexture	=	{
					Forward	=	30,
					Size	=	2000,
					Angle	=	Angle(0,90,0),
						},
				UseHead	=	true,
				UsePrjTex	=	true,
				Pos	=	Vector(-37.939998626709,168.85000610352,50.619998931885),
				UseDynamic	=	true,
				HeadColor	=	{
						188,
						206,
						255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseReverse	=	true,
				UseDynamic	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				SpecLine	=	{
					Amount	=	6,
					Use	=	true,
					Pos	=	Vector(27.450000762939,-172,48.880001068115),
						},
				Pos	=	Vector(27.450000762939,-172,53.220001220703),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(37.340000152588,-172.30999755859,50.759998321533),
				UseDynamic	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1.2,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.45,
						},
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(31.889999389648,-172.30999755859,50.759998321533),
				UseDynamic	=	true,
				UseBrake	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				Pos	=	Vector(44.689998626709,-174.74000549316,164.2799987793),
				UseSprite	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				FogColor	=	{
						255,
						55,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(10.920000076294,-174.78999328613,164.52000427246),
				UseDynamic	=	true,
				UseFog	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				Pos	=	Vector(56.950000762939,-164.41000366211,62.450000762939),
				UseSprite	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				Pos	=	Vector(56.229999542236,-160.47999572754,164.97999572754),
				UseSprite	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				Pos	=	Vector(55.159999847412,82.029998779297,162.00999450684),
				UseSprite	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(32.139999389648,169.02000427246,58.409999847412),
				UseDynamic	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				SpecLine	=	{
					Amount	=	9,
					Pos	=	Vector(43.029998779297,168.94000244141,58.720001220703),
					Use	=	true,
						},
				RenderInner_Size	=	1.2,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				FogColor	=	{
						220,
						225,
						255,
						},
				UsePrjTex	=	true,
				Pos	=	Vector(37.939998626709,168.85000610352,50.619998931885),
				UseDynamic	=	true,
				UseFog	=	true,
				UseSprite	=	true,
				ProjTexture	=	{
					Size	=	2000,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				ProjTexture	=	{
					Forward	=	30,
					Size	=	2000,
					Angle	=	Angle(0,90,0),
						},
				UseHead	=	true,
				UsePrjTex	=	true,
				Pos	=	Vector(37.939998626709,168.85000610352,50.619998931885),
				UseDynamic	=	true,
				HeadColor	=	{
						188,
						206,
						255,
						},
				UseSprite	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				},
		Sound_Airbrake	=	true,
		Copyright	=	"DurkaTeam @ 2025 No rights reserved",
		Author	=	"freemmaann (STEAM_0:1:14528726)",
}