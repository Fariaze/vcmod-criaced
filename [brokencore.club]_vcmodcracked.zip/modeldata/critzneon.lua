VCModels['models/critzneon.mdl']	=	{
		em_state	=	5236594569,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Copyright	=	"DurkaTeam @ 2025 No rights reserved",
		Exhaust	=	{
				{
				Ang	=	Angle(30,-45,0),
				Pos	=	Vector(15.199999809265,-100.58999633789,14.310000419617),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(18.409999847412,8.5,26.64999961853),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(-18.409999847412,-29.809999465942,29.329999923706),
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(18.409999847412,-29.809999465942,29.329999923706),
					},
				},
		DLT	=	3491063046,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				UseRunning	=	true,
				Pos	=	Vector(-29.14999961853,94.410003662109,30.10000038147),
				UseSprite	=	true,
				RunningColor	=	{
						240.06,
						219.58,
						239.32,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				SpecSpin	=	{
						},
				UseHead	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-29.299999237061,94.410003662109,30.10000038147),
				UseDynamic	=	true,
				HeadColor	=	{
						201,
						186,
						255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				ProjTexture	=	{
					Forward	=	30,
					Size	=	2000,
					Angle	=	Angle(0,90,0),
						},
				UsePrjTex	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					AmountV	=	4,
					Pos4	=	Vector(-16.700000762939,103.13999938965,26.520000457764),
					Mid	=	true,
					Pos2	=	Vector(-22.629999160767,100.7200012207,28.639999389648),
					AmountH	=	8,
					Use	=	true,
					Pos1	=	Vector(-16.559999465942,102.61000061035,28.680000305176),
					Pos3	=	Vector(-23.5,101.38999938965,26.420000076294),
						},
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1.2,
				RenderHD_Adv	=	true,
				Pos	=	Vector(-20.059999465942,102.76000213623,27.39999961853),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				UseSprite	=	true,
				UseBlinkers	=	true,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				Beta_Inner3D	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				RenderHD_Size	=	0.061,
				RenderHD_Adv	=	true,
				Pos	=	Vector(-37.479999542236,91.220001220703,22.420000076294),
				UseDynamic	=	true,
				RenderInner_Size	=	1.2,
				SpecMLine	=	{
					Amount	=	8,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-39.229999542236,84.769996643066,23.309999465942),
								},
							},
						},
				RenderInner	=	true,
				UseSprite	=	true,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				FogColor	=	{
						220,
						225,
						255,
						},
				UseSprite	=	true,
				Pos	=	Vector(-25.040000915527,100.2799987793,15.359999656677),
				UseDynamic	=	true,
				UseFog	=	true,
				ProjTexture	=	{
					Size	=	2000,
					Angle	=	Angle(0,90,0),
						},
				UsePrjTex	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				UseDynamic	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-27.360000610352,-100.2200012207,41.240001678467),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				AuxColor	=	{
						255,
						55,
						0,
						},
				FogColor	=	{
						255,
						55,
						0,
						},
				UseBrake	=	true,
				UseAux	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-31.85000038147,-97.809997558594,41.979999542236),
				UseDynamic	=	true,
				UseRunning	=	true,
				UseFog	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-3.9000000953674,-102.08000183105,49.099998474121),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	8,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(3.9000000953674,-102.08000183105,49.099998474121),
								},
							},
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				UseBrake	=	true,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				UseRunning	=	true,
				Pos	=	Vector(29.14999961853,94.410003662109,30.10000038147),
				UseSprite	=	true,
				RunningColor	=	{
						240.06,
						219.58,
						239.32,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				SpecSpin	=	{
						},
				UseHead	=	true,
				UseSprite	=	true,
				Pos	=	Vector(29.299999237061,94.410003662109,30.10000038147),
				UseDynamic	=	true,
				HeadColor	=	{
						201,
						186,
						255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				ProjTexture	=	{
					Forward	=	30,
					Size	=	2000,
					Angle	=	Angle(0,90,0),
						},
				UsePrjTex	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					Pos4	=	Vector(16.700000762939,103.13999938965,26.520000457764),
					AmountV	=	4,
					Mid	=	true,
					Pos2	=	Vector(22.629999160767,100.7200012207,28.639999389648),
					AmountH	=	8,
					Use	=	true,
					Pos1	=	Vector(16.559999465942,102.61000061035,28.680000305176),
					Pos3	=	Vector(23.5,101.38999938965,26.420000076294),
						},
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1.2,
				RenderHD_Adv	=	true,
				Pos	=	Vector(20.059999465942,102.76000213623,27.39999961853),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				UseSprite	=	true,
				UseBlinkers	=	true,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				Beta_Inner3D	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				RenderHD_Size	=	0.061,
				RenderHD_Adv	=	true,
				Pos	=	Vector(37.479999542236,91.220001220703,22.420000076294),
				UseDynamic	=	true,
				RenderInner_Size	=	1.2,
				SpecMLine	=	{
					Amount	=	8,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(39.229999542236,84.769996643066,23.309999465942),
								},
							},
						},
				RenderInner	=	true,
				UseSprite	=	true,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				FogColor	=	{
						220,
						225,
						255,
						},
				UseSprite	=	true,
				Pos	=	Vector(25.040000915527,100.2799987793,15.359999656677),
				UseDynamic	=	true,
				UseFog	=	true,
				ProjTexture	=	{
					Size	=	2000,
					Angle	=	Angle(0,90,0),
						},
				UsePrjTex	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				UseDynamic	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(27.360000610352,-100.2200012207,41.240001678467),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				AuxColor	=	{
						255,
						55,
						0,
						},
				FogColor	=	{
						255,
						55,
						0,
						},
				UseBrake	=	true,
				UseAux	=	true,
				UseSprite	=	true,
				Pos	=	Vector(31.85000038147,-97.809997558594,41.979999542236),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseFog	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
					},
				},
		Date	=	"10/18/15 16:19:47",
		Author	=	"freemmaann (76561197989323181)",
}