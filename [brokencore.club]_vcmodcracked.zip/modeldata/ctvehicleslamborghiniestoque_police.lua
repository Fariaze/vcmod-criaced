VCModels['models/ctvehicleslamborghiniestoque_police.mdl']	=	{
		em_state	=	5236594845,
		HealthEnginePosOvr	=	true,
		Date	=	"Sat May 12 03:35:13 2018",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-8.7399997711182,-115.23999786377,15.699999809265),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-3.3699998855591,-115.83000183105,15.75),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(3.3699998855591,-115.83000183105,15.75),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(8.7399997711182,-115.23999786377,15.699999809265),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		HealthEnginePos	=	Vector(0,71.5,33),
		Fuel	=	{
			FuelLidPos	=	Vector(41.209999084473,-76.129997253418,47.520000457764),
			FuelType	=	0,
			Capacity	=	75,
			FuelLidUse	=	true,
			Override	=	true,
				},
		Author	=	"𝓒𝓣𝓥𝟏𝟐𝟐𝟓 (76561198051637331)",
		Seq_BlinkRate_Off	=	0.31,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Siren	=	{
			Sounds	=	{
					{
					Volume	=	1,
					Pitch	=	100,
					Distance	=	95,
					Name	=	"Wail",
					Sound	=	"vcmod/els/smartsiren/wail.wav",
						},
					{
					Volume	=	1,
					Pitch	=	100,
					Distance	=	95,
					Name	=	"Yelp",
					Sound	=	"vcmod/els/smartsiren/yelp.wav",
						},
					{
					Volume	=	1,
					Pitch	=	100,
					Distance	=	95,
					Name	=	"Priority",
					Sound	=	"vcmod/els/smartsiren/priority.wav",
						},
					},
			Codes	=	{
				[14]	=	{
					Include	=	true,
						},
				[13]	=	{
					Include	=	true,
					Exclude_White	=	true,
						},
					},
			Sections	=	{
				[2]	=	{
						true,
						true,
						true,
						true,
						},
				[3]	=	{
					[7]	=	true,
					[8]	=	true,
					[9]	=	true,
					[10]	=	true,
					[12]	=	true,
					[13]	=	true,
					[14]	=	true,
					[15]	=	true,
						},
				[4]	=	{
					[22]	=	true,
					[21]	=	true,
					[20]	=	true,
					[18]	=	true,
					[11]	=	true,
					[16]	=	true,
					[19]	=	true,
					[17]	=	true,
						},
					},
			Lights	=	{
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.05,
							},
					SpecSpin	=	{
						Intensity	=	1,
							},
					UseDynamic	=	true,
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner_ClrUse	=	false,
					Dynamic	=	{
						Size	=	1,
						Brightness	=	2,
							},
					Spec3D	=	{
						Mat	=	"vcmod/square",
						Pos4	=	Vector(17.729999542236,7.5999999046326,58.430000305176),
						Pos2	=	Vector(27.200000762939,7.5999999046326,59.959999084473),
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
						Use	=	true,
						Pos1	=	Vector(17.729999542236,7.5999999046326,59.959999084473),
						Pos3	=	Vector(27.200000762939,7.5999999046326,58.430000305176),
							},
					SpecMat	=	{
							},
					RenderMLCenter	=	true,
					Beta_Inner3D	=	true,
					Pos	=	Vector(18.729999542236,7.5999999046326,59.200000762939),
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	55,
							},
					RenderInner_Size	=	2,
					SpecMLine	=	{
						Amount	=	20,
						Use	=	true,
						LTbl	=	{
								{
								Clr	=	{
									r	=	0,
									b	=	0,
									a	=	255,
									g	=	0,
										},
								Pos	=	Vector(26.200000762939,7.5999999046326,59.200000762939),
								Size	=	0.1,
								UseClr	=	false,
									},
								},
							},
					RenderInner	=	true,
					RenderHD_Adv	=	true,
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.05,
							},
					SpecSpin	=	{
						Intensity	=	1,
							},
					UseDynamic	=	true,
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner_ClrUse	=	false,
					Dynamic	=	{
						Size	=	1,
						Brightness	=	2,
							},
					Spec3D	=	{
						Mat	=	"vcmod/square",
						Pos4	=	Vector(10.680000305176,7.5999999046326,58.430000305176),
						Pos2	=	Vector(17.520000457764,7.5999999046326,59.959999084473),
						Color	=	{
							r	=	120,
							b	=	255,
							a	=	255,
							g	=	149,
								},
						Use	=	true,
						Pos1	=	Vector(10.680000305176,7.5999999046326,59.950000762939),
						Pos3	=	Vector(17.520000457764,7.5999999046326,58.430000305176),
							},
					SpecMat	=	{
							},
					RenderMLCenter	=	true,
					UseSprite	=	true,
					Pos	=	Vector(11.680000305176,7.5999999046326,59.200000762939),
					SpecMLine	=	{
						Amount	=	15,
						Use	=	true,
						LTbl	=	{
								{
								Pos	=	Vector(16.520000457764,7.5999999046326,59.200000762939),
								UseClr	=	false,
								Clr	=	{
									r	=	0,
									b	=	0,
									a	=	255,
									g	=	0,
										},
									},
								},
							},
					RenderInner	=	true,
					Color	=	{
						r	=	0,
						b	=	255,
						a	=	255,
						g	=	55,
							},
					RenderInner_Size	=	1,
					RenderHD_Adv	=	true,
					Beta_Inner3D	=	true,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.05,
							},
					SpecSpin	=	{
						Intensity	=	1,
							},
					UseDynamic	=	true,
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner_ClrUse	=	false,
					Dynamic	=	{
						Size	=	1,
						Brightness	=	2,
							},
					Spec3D	=	{
						Mat	=	"vcmod/square",
						Pos4	=	Vector(-10.680000305176,7.5999999046326,58.430000305176),
						Pos2	=	Vector(-17.520000457764,7.5999999046326,59.959999084473),
						Color	=	{
							r	=	120,
							b	=	255,
							a	=	255,
							g	=	149,
								},
						Use	=	true,
						Pos1	=	Vector(-10.680000305176,7.5999999046326,59.950000762939),
						Pos3	=	Vector(-17.520000457764,7.5999999046326,58.430000305176),
							},
					SpecMat	=	{
							},
					UseSprite	=	true,
					Beta_Inner3D	=	true,
					Pos	=	Vector(-11.680000305176,7.5999999046326,59.200000762939),
					Color	=	{
						r	=	0,
						b	=	255,
						a	=	255,
						g	=	55,
							},
					RenderInner_Size	=	1,
					SpecMLine	=	{
						Amount	=	15,
						Use	=	true,
						LTbl	=	{
								{
								Pos	=	Vector(-16.520000457764,7.5999999046326,59.200000762939),
								UseClr	=	false,
								Clr	=	{
									r	=	0,
									b	=	0,
									a	=	255,
									g	=	0,
										},
									},
								},
							},
					RenderInner	=	true,
					RenderHD_Adv	=	true,
					RenderMLCenter	=	true,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.05,
							},
					SpecSpin	=	{
						Intensity	=	1,
							},
					UseDynamic	=	true,
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner_ClrUse	=	false,
					Dynamic	=	{
						Size	=	1,
						Brightness	=	2,
							},
					Spec3D	=	{
						Mat	=	"vcmod/square",
						Pos4	=	Vector(-17.729999542236,7.5999999046326,58.430000305176),
						Pos2	=	Vector(-27.200000762939,7.5999999046326,59.959999084473),
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
						Use	=	true,
						Pos1	=	Vector(-17.729999542236,7.5999999046326,59.959999084473),
						Pos3	=	Vector(-27.200000762939,7.5999999046326,58.430000305176),
							},
					SpecMat	=	{
							},
					RenderMLCenter	=	true,
					RenderHD_Adv	=	true,
					Pos	=	Vector(-18.729999542236,7.5999999046326,59.200000762939),
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	55,
							},
					RenderInner_Size	=	2,
					SpecMLine	=	{
						Amount	=	20,
						Use	=	true,
						LTbl	=	{
								{
								UseClr	=	false,
								Pos	=	Vector(-26.200000762939,7.5999999046326,59.200000762939),
								Clr	=	{
									r	=	0,
									b	=	0,
									a	=	255,
									g	=	0,
										},
								Size	=	0.1,
									},
								},
							},
					RenderInner	=	true,
					UseSprite	=	true,
					Beta_Inner3D	=	true,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.2,
							},
					SpecSpin	=	{
						Intensity	=	1,
							},
					Spec3D	=	{
						Mat	=	"vcmod/square",
						Pos4	=	Vector(-7.6900000572205,10.430000305176,58.419998168945),
						Pos2	=	Vector(-10.159999847412,7.6999998092651,59.970001220703),
						Color	=	{
							r	=	120,
							b	=	255,
							a	=	255,
							g	=	149,
								},
						Use	=	true,
						Pos1	=	Vector(-7.6900000572205,10.430000305176,59.959999084473),
						Pos3	=	Vector(-10.159999847412,7.6999998092651,58.430000305176),
							},
					SpecMat	=	{
							},
					Dynamic	=	{
						Size	=	0.5,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-8.6599998474121,9.0699996948242,59.159999847412),
					UseDynamic	=	true,
					Beta_Inner3D	=	true,
					RenderHD_Size	=	5,
					RenderMLCenter	=	true,
					Color	=	{
						r	=	220,
						b	=	255,
						a	=	255,
						g	=	225,
							},
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.2,
							},
					SpecSpin	=	{
						Intensity	=	1,
							},
					Spec3D	=	{
						Mat	=	"vcmod/square",
						Pos4	=	Vector(7.6900000572205,10.430000305176,58.419998168945),
						Pos2	=	Vector(10.159999847412,7.6999998092651,59.970001220703),
						Color	=	{
							r	=	120,
							b	=	255,
							a	=	255,
							g	=	149,
								},
						Use	=	true,
						Pos1	=	Vector(7.6900000572205,10.430000305176,59.959999084473),
						Pos3	=	Vector(10.159999847412,7.6999998092651,58.430000305176),
							},
					SpecMat	=	{
							},
					Dynamic	=	{
						Size	=	0.5,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(8.6599998474121,9.0699996948242,59.159999847412),
					UseDynamic	=	true,
					Beta_Inner3D	=	true,
					Color	=	{
						r	=	220,
						b	=	255,
						a	=	255,
						g	=	225,
							},
					RenderMLCenter	=	true,
					RenderHD_Size	=	5,
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.05,
							},
					SpecSpin	=	{
						Intensity	=	1,
							},
					BGroups	=	{
						[11]	=	{
							[0]	=	"lightbar",
								},
							},
					UseDynamic	=	true,
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner_ClrUse	=	false,
					Dynamic	=	{
						Size	=	0.5,
						Brightness	=	2,
							},
					Spec3D	=	{
						Mat	=	"vcmod/square",
						Pos4	=	Vector(6.960000038147,-14.319999694824,67.830001831055),
						Pos2	=	Vector(0.49000000953674,-12.239999771118,69.680000305176),
						Color	=	{
							r	=	120,
							b	=	255,
							a	=	255,
							g	=	149,
								},
						Use	=	true,
						Pos1	=	Vector(6.9200000762939,-14.289999961853,69.669998168945),
						Pos3	=	Vector(0.46999999880791,-12.239999771118,67.720001220703),
							},
					SpecMat	=	{
							},
					RenderMLCenter	=	true,
					UseSprite	=	true,
					Pos	=	Vector(1.3999999761581,-12.5,68.779998779297),
					RenderInner_Size	=	2,
					RenderInner	=	true,
					SpecMLine	=	{
						Amount	=	12,
						Use	=	true,
						LTbl	=	{
								{
								Pos	=	Vector(6.0900001525879,-14.010000228882,68.769996643066),
								UseClr	=	false,
								Clr	=	{
									r	=	0,
									b	=	0,
									a	=	255,
									g	=	0,
										},
									},
								},
							},
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	55,
							},
					Beta_Inner3D	=	true,
					RenderHD_Adv	=	true,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.05,
							},
					SpecSpin	=	{
						Intensity	=	1,
							},
					BGroups	=	{
						[11]	=	{
							[0]	=	"lightbar",
								},
							},
					UseDynamic	=	true,
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner_ClrUse	=	false,
					Dynamic	=	{
						Size	=	0.5,
						Brightness	=	2,
							},
					Spec3D	=	{
						Mat	=	"vcmod/square",
						Pos4	=	Vector(-20.5,-18.64999961853,67.800003051758),
						Pos2	=	Vector(-14.029999732971,-16.569999694824,69.650001525879),
						Color	=	{
							r	=	120,
							b	=	255,
							a	=	255,
							g	=	149,
								},
						Use	=	true,
						Pos1	=	Vector(-20.459999084473,-18.620000839233,69.639999389648),
						Pos3	=	Vector(-14.010000228882,-16.569999694824,67.690002441406),
							},
					SpecMat	=	{
							},
					UseSprite	=	true,
					RenderHD_Adv	=	true,
					Pos	=	Vector(-15.119999885559,-16.829999923706,68.73999786377),
					RenderInner	=	true,
					RenderInner_Size	=	2,
					SpecMLine	=	{
						Amount	=	12,
						Use	=	true,
						LTbl	=	{
								{
								Pos	=	Vector(-19.420000076294,-18.260000228882,68.73999786377),
								UseClr	=	false,
								Clr	=	{
									r	=	0,
									b	=	0,
									a	=	255,
									g	=	0,
										},
									},
								},
							},
					Color	=	{
						r	=	0,
						b	=	255,
						a	=	255,
						g	=	55,
							},
					Beta_Inner3D	=	true,
					RenderMLCenter	=	true,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.05,
							},
					SpecSpin	=	{
						Intensity	=	1,
							},
					BGroups	=	{
						[11]	=	{
							[0]	=	"lightbar",
								},
							},
					UseDynamic	=	true,
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner_ClrUse	=	false,
					Dynamic	=	{
						Size	=	0.5,
						Brightness	=	2,
							},
					Spec3D	=	{
						Mat	=	"vcmod/square",
						Pos4	=	Vector(27.319999694824,-20.85000038147,67.809997558594),
						Pos2	=	Vector(20.85000038147,-18.770000457764,69.660003662109),
						Color	=	{
							r	=	120,
							b	=	255,
							a	=	255,
							g	=	149,
								},
						Use	=	true,
						Pos1	=	Vector(27.25,-20.840000152588,69.650001525879),
						Pos3	=	Vector(20.829999923706,-18.770000457764,67.699996948242),
							},
					SpecMat	=	{
							},
					RenderHD_Adv	=	true,
					UseSprite	=	true,
					Pos	=	Vector(21.809999465942,-19.059999465942,68.699996948242),
					RenderInner_Size	=	2,
					RenderInner	=	true,
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	55,
							},
					SpecMLine	=	{
						Amount	=	12,
						Use	=	true,
						LTbl	=	{
								{
								Pos	=	Vector(26.440000534058,-20.590000152588,68.699996948242),
								UseClr	=	false,
								Clr	=	{
									r	=	0,
									b	=	0,
									a	=	255,
									g	=	0,
										},
									},
								},
							},
					Beta_Inner3D	=	true,
					RenderMLCenter	=	true,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.05,
							},
					SpecSpin	=	{
						Intensity	=	1,
							},
					BGroups	=	{
						[11]	=	{
							[0]	=	"lightbar",
								},
							},
					UseDynamic	=	true,
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner_ClrUse	=	false,
					Dynamic	=	{
						Size	=	0.5,
						Brightness	=	2,
							},
					Spec3D	=	{
						Mat	=	"vcmod/square",
						Pos4	=	Vector(-27.319999694824,-20.85000038147,67.809997558594),
						Pos2	=	Vector(-20.85000038147,-18.770000457764,69.660003662109),
						Color	=	{
							r	=	120,
							b	=	255,
							a	=	255,
							g	=	149,
								},
						Use	=	true,
						Pos1	=	Vector(-27.25,-20.840000152588,69.650001525879),
						Pos3	=	Vector(-20.829999923706,-18.770000457764,67.699996948242),
							},
					SpecMat	=	{
							},
					RenderMLCenter	=	true,
					RenderHD_Adv	=	true,
					Pos	=	Vector(-21.809999465942,-19.059999465942,68.699996948242),
					RenderInner	=	true,
					RenderInner_Size	=	2,
					Color	=	{
						r	=	0,
						b	=	255,
						a	=	255,
						g	=	55,
							},
					SpecMLine	=	{
						Amount	=	12,
						Use	=	true,
						LTbl	=	{
								{
								Pos	=	Vector(-26.440000534058,-20.590000152588,68.699996948242),
								UseClr	=	false,
								Clr	=	{
									r	=	0,
									b	=	0,
									a	=	255,
									g	=	0,
										},
									},
								},
							},
					Beta_Inner3D	=	true,
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.05,
							},
					SpecSpin	=	{
						Intensity	=	1,
							},
					BGroups	=	{
						[11]	=	{
							[0]	=	"lightbar",
								},
							},
					UseDynamic	=	true,
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner_ClrUse	=	false,
					Dynamic	=	{
						Size	=	0.5,
						Brightness	=	2,
							},
					Spec3D	=	{
						Mat	=	"vcmod/square",
						Pos4	=	Vector(17.829999923706,-29.270000457764,69.650001525879),
						Pos2	=	Vector(23.680000305176,-31.260000228882,67.819999694824),
						Color	=	{
							r	=	120,
							b	=	255,
							a	=	255,
							g	=	149,
								},
						Use	=	true,
						Pos1	=	Vector(17.879999160767,-29.299999237061,67.849998474121),
						Pos3	=	Vector(23.629999160767,-31.229999542236,69.720001220703),
							},
					SpecMat	=	{
							},
					RenderMLCenter	=	true,
					RenderHD_Adv	=	true,
					Pos	=	Vector(18.639999389648,-29.520000457764,68.779998779297),
					RenderInner	=	true,
					RenderInner_Size	=	2,
					Color	=	{
						r	=	0,
						b	=	255,
						a	=	255,
						g	=	55,
							},
					SpecMLine	=	{
						Amount	=	12,
						Use	=	true,
						LTbl	=	{
								{
								Pos	=	Vector(23.079999923706,-31.030000686646,68.779998779297),
								UseClr	=	false,
								Clr	=	{
									r	=	0,
									b	=	0,
									a	=	255,
									g	=	0,
										},
									},
								},
							},
					Beta_Inner3D	=	true,
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.05,
							},
					SpecSpin	=	{
						Intensity	=	1,
							},
					BGroups	=	{
						[11]	=	{
							[0]	=	"lightbar",
								},
							},
					UseDynamic	=	true,
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner_ClrUse	=	false,
					Dynamic	=	{
						Size	=	0.5,
						Brightness	=	2,
							},
					Spec3D	=	{
						Mat	=	"vcmod/square",
						Pos4	=	Vector(20.5,-18.670000076294,67.809997558594),
						Pos2	=	Vector(14.029999732971,-16.590000152588,69.660003662109),
						Color	=	{
							r	=	120,
							b	=	255,
							a	=	255,
							g	=	149,
								},
						Use	=	true,
						Pos1	=	Vector(20.459999084473,-18.639999389648,69.650001525879),
						Pos3	=	Vector(14.010000228882,-16.590000152588,67.699996948242),
							},
					SpecMat	=	{
							},
					UseSprite	=	true,
					RenderHD_Adv	=	true,
					Pos	=	Vector(14.939999580383,-16.85000038147,68.76000213623),
					RenderInner	=	true,
					RenderInner_Size	=	2,
					SpecMLine	=	{
						Amount	=	12,
						Use	=	true,
						LTbl	=	{
								{
								Pos	=	Vector(19.629999160767,-18.360000610352,68.75),
								UseClr	=	false,
								Clr	=	{
									r	=	0,
									b	=	0,
									a	=	255,
									g	=	0,
										},
									},
								},
							},
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	55,
							},
					Beta_Inner3D	=	true,
					RenderMLCenter	=	true,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.05,
							},
					SpecSpin	=	{
						Intensity	=	1,
							},
					BGroups	=	{
						[11]	=	{
							[0]	=	"lightbar",
								},
							},
					UseDynamic	=	true,
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner_ClrUse	=	false,
					Dynamic	=	{
						Size	=	0.5,
						Brightness	=	2,
							},
					Spec3D	=	{
						Mat	=	"vcmod/square",
						Pos4	=	Vector(13.659999847412,-16.459999084473,67.839996337891),
						Pos2	=	Vector(7.1900000572205,-14.380000114441,69.690002441406),
						Color	=	{
							r	=	120,
							b	=	255,
							a	=	255,
							g	=	149,
								},
						Use	=	true,
						Pos1	=	Vector(13.619999885559,-16.430000305176,69.680000305176),
						Pos3	=	Vector(7.1700000762939,-14.380000114441,67.730003356934),
							},
					SpecMat	=	{
							},
					UseSprite	=	true,
					RenderHD_Adv	=	true,
					Pos	=	Vector(8.1000003814697,-14.640000343323,68.790000915527),
					RenderInner	=	true,
					RenderInner_Size	=	2,
					SpecMLine	=	{
						Amount	=	12,
						Use	=	true,
						LTbl	=	{
								{
								Pos	=	Vector(12.789999961853,-16.14999961853,68.779998779297),
								UseClr	=	false,
								Clr	=	{
									r	=	0,
									b	=	0,
									a	=	255,
									g	=	0,
										},
									},
								},
							},
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	55,
							},
					Beta_Inner3D	=	true,
					RenderMLCenter	=	true,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.05,
							},
					SpecSpin	=	{
						Intensity	=	1,
							},
					BGroups	=	{
						[11]	=	{
							[0]	=	"lightbar",
								},
							},
					UseDynamic	=	true,
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner_ClrUse	=	false,
					Dynamic	=	{
						Size	=	0.5,
						Brightness	=	2,
							},
					Spec3D	=	{
						Mat	=	"vcmod/square",
						Pos4	=	Vector(-6.960000038147,-14.279999732971,67.830001831055),
						Pos2	=	Vector(-0.49000000953674,-12.199999809265,69.680000305176),
						Color	=	{
							r	=	120,
							b	=	255,
							a	=	255,
							g	=	149,
								},
						Use	=	true,
						Pos1	=	Vector(-6.9200000762939,-14.25,69.669998168945),
						Pos3	=	Vector(-0.46999999880791,-12.199999809265,67.720001220703),
							},
					SpecMat	=	{
							},
					UseSprite	=	true,
					RenderHD_Adv	=	true,
					Pos	=	Vector(-1.3999999761581,-12.460000038147,68.779998779297),
					RenderInner	=	true,
					RenderInner_Size	=	2,
					SpecMLine	=	{
						Amount	=	12,
						Use	=	true,
						LTbl	=	{
								{
								Pos	=	Vector(-6.0900001525879,-13.970000267029,68.769996643066),
								UseClr	=	false,
								Clr	=	{
									r	=	0,
									b	=	0,
									a	=	255,
									g	=	0,
										},
									},
								},
							},
					Color	=	{
						r	=	0,
						b	=	255,
						a	=	255,
						g	=	55,
							},
					Beta_Inner3D	=	true,
					RenderMLCenter	=	true,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.05,
							},
					SpecSpin	=	{
						Intensity	=	1,
							},
					BGroups	=	{
						[11]	=	{
							[0]	=	"lightbar",
								},
							},
					UseDynamic	=	true,
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner_ClrUse	=	false,
					Dynamic	=	{
						Size	=	0.5,
						Brightness	=	2,
							},
					Spec3D	=	{
						Mat	=	"vcmod/square",
						Pos4	=	Vector(-13.619999885559,-16.430000305176,67.839996337891),
						Pos2	=	Vector(-7.1599998474121,-14.329999923706,69.690002441406),
						Color	=	{
							r	=	120,
							b	=	255,
							a	=	255,
							g	=	149,
								},
						Use	=	true,
						Pos1	=	Vector(-13.64999961853,-16.420000076294,69.660003662109),
						Pos3	=	Vector(-7.1399998664856,-14.329999923706,67.730003356934),
							},
					SpecMat	=	{
							},
					RenderMLCenter	=	true,
					UseSprite	=	true,
					Pos	=	Vector(-8.0699996948242,-14.590000152588,68.790000915527),
					RenderInner	=	true,
					RenderInner_Size	=	2,
					Color	=	{
						r	=	0,
						b	=	255,
						a	=	255,
						g	=	55,
							},
					SpecMLine	=	{
						Amount	=	12,
						Use	=	true,
						LTbl	=	{
								{
								Pos	=	Vector(-12.760000228882,-16.10000038147,68.779998779297),
								UseClr	=	false,
								Clr	=	{
									r	=	0,
									b	=	0,
									a	=	255,
									g	=	0,
										},
									},
								},
							},
					Beta_Inner3D	=	true,
					RenderHD_Adv	=	true,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.05,
							},
					SpecSpin	=	{
						Intensity	=	1,
							},
					BGroups	=	{
						[11]	=	{
							[0]	=	"lightbar",
								},
							},
					UseDynamic	=	true,
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner_ClrUse	=	false,
					Dynamic	=	{
						Size	=	0.5,
						Brightness	=	2,
							},
					Spec3D	=	{
						Mat	=	"vcmod/square",
						Pos4	=	Vector(-17.940000534058,-29.290000915527,69.610000610352),
						Pos2	=	Vector(-23.760000228882,-31.270000457764,67.800003051758),
						Color	=	{
							r	=	120,
							b	=	255,
							a	=	255,
							g	=	149,
								},
						Use	=	true,
						Pos1	=	Vector(-17.989999771118,-29.319999694824,67.809997558594),
						Pos3	=	Vector(-23.739999771118,-31.25,69.680000305176),
							},
					SpecMat	=	{
							},
					RenderHD_Adv	=	true,
					UseSprite	=	true,
					Pos	=	Vector(-18.60000038147,-29.5,68.75),
					RenderInner_Size	=	2,
					RenderInner	=	true,
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	55,
							},
					SpecMLine	=	{
						Amount	=	12,
						Use	=	true,
						LTbl	=	{
								{
								Pos	=	Vector(-23.190000534058,-31.049999237061,68.73999786377),
								UseClr	=	false,
								Clr	=	{
									r	=	0,
									b	=	0,
									a	=	255,
									g	=	0,
										},
									},
								},
							},
					Beta_Inner3D	=	true,
					RenderMLCenter	=	true,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.05,
							},
					SpecSpin	=	{
						Intensity	=	1,
							},
					BGroups	=	{
						[11]	=	{
							[0]	=	"lightbar",
								},
							},
					UseDynamic	=	true,
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner_ClrUse	=	false,
					Dynamic	=	{
						Size	=	0.5,
						Brightness	=	2,
							},
					Spec3D	=	{
						Mat	=	"vcmod/square",
						Pos4	=	Vector(-0.33000001311302,-23.319999694824,69.620002746582),
						Pos2	=	Vector(-6.1799998283386,-25.309999465942,67.790000915527),
						Color	=	{
							r	=	120,
							b	=	255,
							a	=	255,
							g	=	149,
								},
						Use	=	true,
						Pos1	=	Vector(-0.37999999523163,-23.35000038147,67.819999694824),
						Pos3	=	Vector(-6.1300001144409,-25.280000686646,69.690002441406),
							},
					SpecMat	=	{
							},
					RenderHD_Adv	=	true,
					UseSprite	=	true,
					Pos	=	Vector(-1.0499999523163,-23.559999465942,68.75),
					RenderInner	=	true,
					RenderInner_Size	=	2,
					SpecMLine	=	{
						Amount	=	12,
						Use	=	true,
						LTbl	=	{
								{
								Pos	=	Vector(-5.5799999237061,-25.120000839233,68.75),
								UseClr	=	false,
								Clr	=	{
									r	=	0,
									b	=	0,
									a	=	255,
									g	=	0,
										},
									},
								},
							},
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	55,
							},
					Beta_Inner3D	=	true,
					RenderMLCenter	=	true,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.05,
							},
					SpecSpin	=	{
						Intensity	=	1,
							},
					BGroups	=	{
						[11]	=	{
							[0]	=	"lightbar",
								},
							},
					UseDynamic	=	true,
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner_ClrUse	=	false,
					Dynamic	=	{
						Size	=	0.5,
						Brightness	=	2,
							},
					Spec3D	=	{
						Mat	=	"vcmod/square",
						Pos4	=	Vector(12,-27.280000686646,69.639999389648),
						Pos2	=	Vector(17.85000038147,-29.270000457764,67.809997558594),
						Color	=	{
							r	=	120,
							b	=	255,
							a	=	255,
							g	=	149,
								},
						Use	=	true,
						Pos1	=	Vector(12.050000190735,-27.309999465942,67.839996337891),
						Pos3	=	Vector(17.799999237061,-29.239999771118,69.709999084473),
							},
					SpecMat	=	{
							},
					RenderMLCenter	=	true,
					RenderHD_Adv	=	true,
					Pos	=	Vector(12.810000419617,-27.530000686646,68.769996643066),
					RenderInner_Size	=	2,
					RenderInner	=	true,
					SpecMLine	=	{
						Amount	=	12,
						Use	=	true,
						LTbl	=	{
								{
								Pos	=	Vector(17.25,-29.040000915527,68.769996643066),
								UseClr	=	false,
								Clr	=	{
									r	=	0,
									b	=	0,
									a	=	255,
									g	=	0,
										},
									},
								},
							},
					Color	=	{
						r	=	0,
						b	=	255,
						a	=	255,
						g	=	55,
							},
					Beta_Inner3D	=	true,
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.05,
							},
					SpecSpin	=	{
						Intensity	=	1,
							},
					BGroups	=	{
						[11]	=	{
							[0]	=	"lightbar",
								},
							},
					UseDynamic	=	true,
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner_ClrUse	=	false,
					Dynamic	=	{
						Size	=	0.5,
						Brightness	=	2,
							},
					Spec3D	=	{
						Mat	=	"vcmod/square",
						Pos4	=	Vector(-12,-27.280000686646,69.639999389648),
						Pos2	=	Vector(-17.85000038147,-29.270000457764,67.809997558594),
						Color	=	{
							r	=	120,
							b	=	255,
							a	=	255,
							g	=	149,
								},
						Use	=	true,
						Pos1	=	Vector(-12.050000190735,-27.309999465942,67.839996337891),
						Pos3	=	Vector(-17.799999237061,-29.239999771118,69.709999084473),
							},
					SpecMat	=	{
							},
					RenderMLCenter	=	true,
					RenderHD_Adv	=	true,
					Pos	=	Vector(-12.810000419617,-27.530000686646,68.769996643066),
					RenderInner_Size	=	2,
					RenderInner	=	true,
					SpecMLine	=	{
						Amount	=	12,
						Use	=	true,
						LTbl	=	{
								{
								Pos	=	Vector(-17.25,-29.040000915527,68.769996643066),
								UseClr	=	false,
								Clr	=	{
									r	=	0,
									b	=	0,
									a	=	255,
									g	=	0,
										},
									},
								},
							},
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	55,
							},
					Beta_Inner3D	=	true,
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.05,
							},
					SpecSpin	=	{
						Intensity	=	1,
							},
					BGroups	=	{
						[11]	=	{
							[0]	=	"lightbar",
								},
							},
					UseDynamic	=	true,
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner_ClrUse	=	false,
					Dynamic	=	{
						Size	=	0.5,
						Brightness	=	2,
							},
					Spec3D	=	{
						Mat	=	"vcmod/square",
						Pos4	=	Vector(-6.1799998283386,-25.299999237061,69.629997253418),
						Pos2	=	Vector(-12.029999732971,-27.290000915527,67.800003051758),
						Color	=	{
							r	=	120,
							b	=	255,
							a	=	255,
							g	=	149,
								},
						Use	=	true,
						Pos1	=	Vector(-6.2300000190735,-25.329999923706,67.830001831055),
						Pos3	=	Vector(-11.979999542236,-27.260000228882,69.699996948242),
							},
					SpecMat	=	{
							},
					RenderMLCenter	=	true,
					RenderHD_Adv	=	true,
					Pos	=	Vector(-6.9000000953674,-25.540000915527,68.720001220703),
					RenderInner_Size	=	2,
					RenderInner	=	true,
					SpecMLine	=	{
						Amount	=	12,
						Use	=	true,
						LTbl	=	{
								{
								Pos	=	Vector(-11.430000305176,-27.059999465942,68.720001220703),
								UseClr	=	false,
								Clr	=	{
									r	=	0,
									b	=	0,
									a	=	255,
									g	=	0,
										},
									},
								},
							},
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	55,
							},
					Beta_Inner3D	=	true,
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.05,
							},
					SpecSpin	=	{
						Intensity	=	1,
							},
					BGroups	=	{
						[11]	=	{
							[0]	=	"lightbar",
								},
							},
					UseDynamic	=	true,
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner_ClrUse	=	false,
					Dynamic	=	{
						Size	=	0.5,
						Brightness	=	2,
							},
					Spec3D	=	{
						Mat	=	"vcmod/square",
						Pos4	=	Vector(0.33000001311302,-23.329999923706,69.620002746582),
						Pos2	=	Vector(6.1799998283386,-25.319999694824,67.790000915527),
						Color	=	{
							r	=	120,
							b	=	255,
							a	=	255,
							g	=	149,
								},
						Use	=	true,
						Pos1	=	Vector(0.37999999523163,-23.360000610352,67.819999694824),
						Pos3	=	Vector(6.1300001144409,-25.290000915527,69.690002441406),
							},
					SpecMat	=	{
							},
					RenderMLCenter	=	true,
					RenderHD_Adv	=	true,
					Pos	=	Vector(1.0499999523163,-23.569999694824,68.75),
					RenderInner_Size	=	2,
					RenderInner	=	true,
					SpecMLine	=	{
						Amount	=	12,
						Use	=	true,
						LTbl	=	{
								{
								Pos	=	Vector(5.5799999237061,-25.129999160767,68.75),
								UseClr	=	false,
								Clr	=	{
									r	=	0,
									b	=	0,
									a	=	255,
									g	=	0,
										},
									},
								},
							},
					Color	=	{
						r	=	0,
						b	=	255,
						a	=	255,
						g	=	55,
							},
					Beta_Inner3D	=	true,
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	0.05,
							},
					SpecSpin	=	{
						Intensity	=	1,
							},
					BGroups	=	{
						[11]	=	{
							[0]	=	"lightbar",
								},
							},
					UseDynamic	=	true,
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner_ClrUse	=	false,
					Dynamic	=	{
						Size	=	0.5,
						Brightness	=	2,
							},
					Spec3D	=	{
						Mat	=	"vcmod/square",
						Pos4	=	Vector(6.1799998283386,-25.309999465942,69.620002746582),
						Pos2	=	Vector(12.029999732971,-27.299999237061,67.790000915527),
						Color	=	{
							r	=	120,
							b	=	255,
							a	=	255,
							g	=	149,
								},
						Use	=	true,
						Pos1	=	Vector(6.2300000190735,-25.340000152588,67.819999694824),
						Pos3	=	Vector(11.979999542236,-27.270000457764,69.690002441406),
							},
					SpecMat	=	{
							},
					RenderMLCenter	=	true,
					RenderHD_Adv	=	true,
					Pos	=	Vector(6.9000000953674,-25.549999237061,68.709999084473),
					Color	=	{
						r	=	0,
						b	=	255,
						a	=	255,
						g	=	55,
							},
					RenderInner	=	true,
					SpecMLine	=	{
						Amount	=	12,
						Use	=	true,
						LTbl	=	{
								{
								Pos	=	Vector(11.430000305176,-27.069999694824,68.709999084473),
								UseClr	=	false,
								Clr	=	{
									r	=	0,
									b	=	0,
									a	=	255,
									g	=	0,
										},
									},
								},
							},
					RenderInner_Size	=	2,
					UseSprite	=	true,
					Beta_Inner3D	=	true,
						},
					},
			Sounds_Horn	=	{
				Use	=	true,
				Volume	=	1,
				Distance	=	95,
				Pitch	=	100,
				Sound	=	"vcmod/els/smartsiren/horn.wav",
					},
			Sequences	=	{
					{
					SubSeq	=	{
							{
							Stages	=	{
									{
									Lights	=	{
											7,
											9,
											12,
											13,
											16,
											17,
											19,
											20,
											3,
											4,
											},
									Time	=	0.3,
										},
									{
									Lights	=	{
											8,
											10,
											11,
											14,
											15,
											18,
											21,
											22,
											1,
											2,
											},
									Time	=	0.3,
										},
									},
							Time	=	5,
							Type	=	"Custom",
								},
							},
					Codes	=	{
							true,
							},
					Lights_Sel	=	{
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							},
						},
					{
					SubSeq	=	{
							{
							Stages	=	{
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											9,
											7,
											12,
											13,
											11,
											18,
											21,
											22,
											1,
											4,
											2,
											3,
											},
									Time	=	0.1,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											1,
											4,
											2,
											3,
											},
									Time	=	0.1,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											9,
											7,
											12,
											13,
											11,
											18,
											21,
											22,
											},
									Time	=	0.1,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											},
									Time	=	0.1,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											14,
											15,
											8,
											10,
											16,
											19,
											20,
											17,
											1,
											4,
											2,
											3,
											},
									Time	=	0.1,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											1,
											4,
											2,
											3,
											},
									Time	=	0.1,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											14,
											15,
											8,
											10,
											16,
											19,
											20,
											17,
											},
									Time	=	0.1,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											},
									Time	=	0.1,
										},
									},
							Time	=	4,
							Type	=	"Custom",
								},
							{
							Stages	=	{
									{
									Lights	=	{
											1,
											3,
											11,
											16,
											17,
											18,
											19,
											20,
											21,
											22,
											},
									Time	=	0.1,
										},
									{
									Lights	=	{
											1,
											3,
											},
									Time	=	0.1,
										},
									{
									Lights	=	{
											8,
											10,
											15,
											14,
											7,
											12,
											13,
											9,
											2,
											4,
											},
									Time	=	0.1,
										},
									{
									Lights	=	{
											2,
											4,
											},
									Time	=	0.1,
										},
									},
							Time	=	4,
							Type	=	"Custom",
								},
							},
					Codes	=	{
						[2]	=	true,
							},
					Lights_Sel	=	{
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							},
						},
					{
					SubSeq	=	{
							{
							Stages	=	{
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.1,
											},
									Lights	=	{
											7,
											13,
											14,
											15,
											21,
											22,
											17,
											20,
											2,
											3,
											},
									Time	=	0.07,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.1,
											},
									Lights	=	{
											1,
											4,
											12,
											9,
											10,
											8,
											11,
											16,
											18,
											19,
											},
									Time	=	0.07,
										},
									},
							Time	=	4,
							Type	=	"Custom",
								},
							{
							Stages	=	{
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											9,
											7,
											14,
											10,
											20,
											18,
											19,
											22,
											2,
											3,
											},
									Time	=	0.07,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											12,
											13,
											15,
											8,
											11,
											16,
											17,
											21,
											1,
											4,
											},
									Time	=	0.07,
										},
									},
							Time	=	4,
							Type	=	"Custom",
								},
							{
							Stages	=	{
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											3,
											4,
											9,
											12,
											13,
											7,
											17,
											20,
											19,
											16,
											},
									Time	=	0.05,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											3,
											4,
											7,
											9,
											12,
											13,
											17,
											20,
											19,
											16,
											},
									Time	=	0.05,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											2,
											1,
											14,
											15,
											10,
											8,
											18,
											11,
											21,
											22,
											},
									Time	=	0.05,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											2,
											1,
											8,
											10,
											14,
											15,
											21,
											22,
											11,
											18,
											},
									Time	=	0.05,
										},
									},
							Time	=	4,
							Type	=	"Custom",
								},
							},
					Codes	=	{
						[3]	=	true,
							},
					Lights_Sel	=	{
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							},
						},
					{
					BGroups	=	{
						[11]	=	{
							[0]	=	"lightbar",
								},
							},
					SubSeq	=	{
							{
							Stages	=	{
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											9,
											12,
											13,
											7,
											11,
											16,
											18,
											19,
											20,
											21,
											22,
											17,
											1,
											2,
											},
									Time	=	0.3,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											8,
											10,
											14,
											15,
											3,
											4,
											},
									Time	=	0.3,
										},
									},
							Time	=	2,
							Type	=	"Custom",
								},
							{
							Stages	=	{
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											14,
											15,
											8,
											10,
											16,
											17,
											19,
											20,
											21,
											22,
											18,
											11,
											3,
											4,
											},
									Time	=	0.3,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.025,
											},
									Lights	=	{
											7,
											9,
											12,
											13,
											1,
											2,
											},
									Time	=	0.3,
										},
									},
							Time	=	2,
							Type	=	"Custom",
								},
							},
					Codes	=	{
						[9]	=	true,
							},
					Lights_Sel	=	{
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							},
						},
					},
			Sounds_Manual	=	{
				Use	=	true,
				Volume	=	1,
				Distance	=	95,
				Pitch	=	100,
				Sound	=	"vcmod/els/smartsiren/manual.wav",
					},
				},
		Copyright	=	"Copyright © 2012-2018 VCMod (freemmaann). All Rights Reserved.",
		Seq_BlinkRate_On	=	0.31,
		DLT	=	3491063230,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecMat	=	{
					New	=	"models/wireframe",
					Select	=	11,
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-36.869998931885,-113.86000061035,40.400001525879),
				UseSprite	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-33.759998321533,-115.69999694824,40.430000305176),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-32.340000152588,-115.70999908447,41.700000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseBlinkers	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.7,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models/wireframe",
					Select	=	11,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-26.639999389648,104.83000183105,32.25),
				UseBlinkers	=	true,
				RenderInner	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-24.420000076294,104.73000335693,30.030000686646),
					Pos2	=	Vector(-28.860000610352,104.93000030518,34.470001220703),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-24.420000076294,104.79000091553,34.470001220703),
					Pos3	=	Vector(-28.860000610352,104.87000274658,30.030000686646),
						},
				Beta_Inner3D	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.7,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(24.420000076294,104.73000335693,30.030000686646),
					Pos2	=	Vector(28.860000610352,104.93000030518,34.470001220703),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(24.420000076294,104.79000091553,34.470001220703),
					Pos3	=	Vector(28.860000610352,104.87000274658,30.030000686646),
						},
				SpecMat	=	{
					New	=	"models/wireframe",
					Select	=	11,
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(26.639999389648,104.83000183105,32.25),
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RenderInner	=	true,
				UseBlinkers	=	true,
				UseSprite	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecMat	=	{
					New	=	"models/wireframe",
					Select	=	11,
						},
				ReducedVis	=	true,
				UseBrake	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(36.869998931885,-113.86000061035,40.400001525879),
				UseSprite	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(33.759998321533,-115.69999694824,40.430000305176),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(32.340000152588,-115.70999908447,41.700000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderMLCenter	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecMat	=	{
					New	=	"models/wireframe",
					Select	=	11,
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-32.080001831055,-115.37999725342,39.310001373291),
				UseSprite	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-33.759998321533,-115.69999694824,40.430000305176),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderMLCenter	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecMat	=	{
					New	=	"models/wireframe",
					Select	=	11,
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(32.080001831055,-115.37999725342,39.310001373291),
				UseSprite	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(33.759998321533,-115.69999694824,40.430000305176),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderMLCenter	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecMat	=	{
					New	=	"models/wireframe",
					Select	=	11,
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-30.739999771118,-116.7799987793,40.720001220703),
				UseSprite	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-27.010000228882,-118.37999725342,40.759998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-25.670000076294,-118.26000213623,42.229999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseBrake	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecMat	=	{
					New	=	"models/wireframe",
					Select	=	11,
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-25.370000839233,-117.91999816895,39.450000762939),
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	12,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-27.010000228882,-118.37999725342,40.759998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderMLCenter	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecMat	=	{
					New	=	"models/wireframe",
					Select	=	11,
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(30.739999771118,-116.7799987793,40.720001220703),
				UseSprite	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(27.010000228882,-118.37999725342,40.759998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(25.670000076294,-118.26000213623,42.229999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseBrake	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecMat	=	{
					New	=	"models/wireframe",
					Select	=	11,
						},
				ReducedVis	=	true,
				UseBrake	=	true,
				UseSprite	=	true,
				Pos	=	Vector(25.370000839233,-117.91999816895,39.450000762939),
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	12,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(27.010000228882,-118.37999725342,40.759998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderMLCenter	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RenderMLCenter	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
					New	=	"models/wireframe",
					Select	=	11,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(23.25,-119.41999816895,41.020000457764),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	35,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(19.079999923706,-120.62000274658,41.029998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(17.680000305176,-120.30000305176,42.330001831055),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseSprite	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
					New	=	"models/wireframe",
					Select	=	11,
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-17.5,-120.01000213623,39.849998474121),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	12,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-19.079999923706,-120.62000274658,41.029998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RenderMLCenter	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
					New	=	"models/wireframe",
					Select	=	11,
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				UseSprite	=	true,
				Pos	=	Vector(17.5,-120.01000213623,39.849998474121),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	12,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(19.079999923706,-120.62000274658,41.029998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RenderMLCenter	=	true,
				UseBrake	=	true,
				SpecMat	=	{
					Select	=	4,
					New	=	"models/ctvehicles/lamborghini/estoque_police/redillum_on",
					Use	=	true,
						},
				ReducedVis	=	true,
				BGroups	=	{
					[12]	=	{
						[0]	=	"rearwindows_50percent",
						[2]	=	"rearwindows_notint",
							},
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-23.020000457764,-68.290000915527,59.290000915527),
				UseSprite	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	200,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-17.260000228882,-69.25,59.630001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-11.510000228882,-69.860000610352,59.889999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-5.7600002288818,-70.279998779297,60.009998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(0,-70.540000915527,60.049999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(5.7600002288818,-70.279998779297,60.009998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(11.510000228882,-69.860000610352,59.889999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(17.260000228882,-69.25,59.630001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(23.020000457764,-68.290000915527,59.259998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				RenderMLCenter	=	true,
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
					Select	=	4,
					New	=	"models/ctvehicles/lamborghini/estoque_police/redillum_on",
					Use	=	true,
						},
				ReducedVis	=	true,
				BGroups	=	{
					[11]	=	{
							"rearwindows_0percent",
							},
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(23.020000457764,-68.290000915527,59.290000915527),
				UseBrake	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	200,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(17.260000228882,-69.25,59.630001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(11.510000228882,-69.860000610352,59.889999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(5.7600002288818,-70.279998779297,60.009998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-0,-70.540000915527,60.049999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-5.7600002288818,-70.279998779297,60.009998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-11.510000228882,-69.860000610352,59.889999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-17.260000228882,-69.25,59.630001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-23.020000457764,-68.290000915527,59.259998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	158,
					a	=	255,
					g	=	0,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				HBeamColor	=	{
					r	=	195,
					b	=	225,
					a	=	255,
					g	=	195,
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-34.689998626709,100.87999725342,33.490001678467),
				SpecMat	=	{
					Select	=	3,
					New	=	"models/ctvehicles/lamborghini/estoque_police/vehiclelights_trans_on",
					Use	=	true,
						},
				UseHighBeams	=	true,
				UseSprite	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	225,
					a	=	255,
					g	=	195,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UsePrjTex	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				HBeamColor	=	{
					r	=	195,
					b	=	225,
					a	=	255,
					g	=	195,
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(34.689998626709,100.87999725342,33.490001678467),
				SpecMat	=	{
					Select	=	3,
					New	=	"models/ctvehicles/lamborghini/estoque_police/vehiclelights_trans_on",
					Use	=	true,
						},
				UseHighBeams	=	true,
				UseSprite	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	225,
					a	=	255,
					g	=	195,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UsePrjTex	=	true,
					},
				{
				UseRunning	=	true,
				SpecSpin	=	{
					Intensity	=	1,
						},
				Beta_Inner3D	=	true,
				ReducedVis	=	true,
				SpecMat	=	{
					Select	=	24,
					New	=	"models/ctvehicles/lamborghini/estoque/vehiclelights__spec_fl_on",
					Use	=	true,
						},
				RunningColor	=	{
					r	=	222,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Pos	=	Vector(-18.309999465942,22.719999313354,44.880001068115),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.08,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
					Select	=	2,
					New	=	"models/ctvehicles/lamborghini/estoque_police/led_on",
					Use	=	true,
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-38.630001068115,98.940002441406,35.209999084473),
				UseDynamic	=	true,
				Beta_Inner3D	=	true,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-37.279998779297,101.13999938965,33.889999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-35.25,103.65000152588,32.419998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-34.409999847412,105.06999969482,31.860000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-33.290000915527,107.75,31.120000839233),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.08,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
					Select	=	2,
					New	=	"models/ctvehicles/lamborghini/estoque_police/led_on",
					Use	=	true,
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				UseSprite	=	true,
				Pos	=	Vector(38.630001068115,98.940002441406,35.209999084473),
				UseDynamic	=	true,
				Beta_Inner3D	=	true,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(37.279998779297,101.13999938965,33.889999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(35.25,103.65000152588,32.419998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(34.409999847412,105.06999969482,31.860000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(33.290000915527,107.75,31.120000839233),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.08,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
					Select	=	2,
					New	=	"models/ctvehicles/lamborghini/estoque_police/led_on",
					Use	=	true,
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(30.809999465942,102.59999847412,34.049999237061),
				UseDynamic	=	true,
				UseSprite	=	true,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(29.590000152588,105.09999847412,32.700000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(27.690000534058,107.66000366211,31.209999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(26.89999961853,109.04000091553,30.610000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(25.920000076294,111.98999786377,29.610000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.08,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
					Select	=	2,
					New	=	"models/ctvehicles/lamborghini/estoque_police/led_on",
					Use	=	true,
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-30.809999465942,102.59999847412,34.049999237061),
				UseDynamic	=	true,
				UseSprite	=	true,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-29.590000152588,105.09999847412,32.700000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-27.690000534058,107.66000366211,31.209999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-26.89999961853,109.04000091553,30.610000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-25.920000076294,111.98999786377,29.610000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.08,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
					Select	=	2,
					New	=	"models/ctvehicles/lamborghini/estoque_police/led_on",
					Use	=	true,
						},
				ReducedVis	=	true,
				UseRunning	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(31.409999847412,101.06999969482,33.689998626709),
				UseDynamic	=	true,
				UseSprite	=	true,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(32.729999542236,103.48999786377,32.389999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(33.340000152588,104.48000335693,31.940000534058),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(32.889999389648,106.08000183105,31.5),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(32.240001678467,108.66999816895,30.860000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.08,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
					Select	=	2,
					New	=	"models/ctvehicles/lamborghini/estoque_police/led_on",
					Use	=	true,
						},
				ReducedVis	=	true,
				UseRunning	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-31.409999847412,101.06999969482,33.689998626709),
				UseDynamic	=	true,
				UseSprite	=	true,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-32.729999542236,103.48999786377,32.389999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-33.340000152588,104.48000335693,31.940000534058),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-32.889999389648,106.08000183105,31.5),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-32.240001678467,108.66999816895,30.860000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderMLCenter	=	true,
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.08,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
					Select	=	2,
					New	=	"models/ctvehicles/lamborghini/estoque_police/led_on",
					Use	=	true,
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(23.620000839233,105.76999664307,32.470001220703),
				UseDynamic	=	true,
				UseSprite	=	true,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(24.989999771118,108.09999847412,31.209999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(25.469999313354,109.37000274658,30.379999160767),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(24.420000076294,112.88999938965,29.489999771118),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.08,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
					Select	=	2,
					New	=	"models/ctvehicles/lamborghini/estoque_police/led_on",
					Use	=	true,
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-23.620000839233,105.76999664307,32.470001220703),
				UseDynamic	=	true,
				Beta_Inner3D	=	true,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-24.989999771118,108.09999847412,31.209999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-25.469999313354,109.37000274658,30.379999160767),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-24.420000076294,112.88999938965,29.489999771118),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
					New	=	"models/wireframe",
					Select	=	11,
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-23.25,-119.41999816895,41.020000457764),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	35,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-19.079999923706,-120.62000274658,41.029998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-17.680000305176,-120.30000305176,42.330001831055),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				UseRunning	=	true,
				SpecSpin	=	{
					Intensity	=	1,
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
					r	=	222,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Pos	=	Vector(0,-121.5299987793,26.89999961853),
				SpecMat	=	{
					Select	=	5,
					New	=	"models/ctvehicles/lamborghini/estoque_police/cop_plate__spec__on",
					Use	=	true,
						},
				ReducedVis	=	true,
				BGroups	=	{
					[2]	=	{
						[0]	=	"license_plate",
							},
						},
					},
				},
		Seq_BlinkRate_Ovr	=	true,
		Light_DD_Int	=	true,
		ExtraSeats	=	{
				{
				Ang	=	Angle(17,0,0),
				Pos	=	Vector(20.110000610352,2.8199999332428,32.729999542236),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(4,0,0),
				Pos	=	Vector(-20.610000610352,-34.700000762939,31.229999542236),
					},
				{
				Ang	=	Angle(4,0,0),
				Pos	=	Vector(20.610000610352,-34.700000762939,31.229999542236),
					},
				},
}