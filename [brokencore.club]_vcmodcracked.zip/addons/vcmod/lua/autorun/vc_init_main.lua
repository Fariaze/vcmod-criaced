-- DurkaTeam @ 2025 Никакие права не защищены

// Force players to download this file
AddCSLuaFile()

// Add client loader to the mix
AddCSLuaFile("vcmod/client/load.lua")
AddCSLuaFile("vcmod/client/load2.lua")
AddCSLuaFile("vcmod/client/load3.lua")

// Which VCMod addon is this?
vcmod_main = true

// Record version number
local old = VC_AU_Ver

// VCMod Auto Updater version nunmber
VC_AU_Ver = 9.65

// Auto Updater version missmatch check
if old and old < VC_AU_Ver then print("VCMod: Issue found, VCMod addons version incompatibility found(old: "..old..", new: "..VC_AU_Ver.."). Update all of your VCMod addons!") end

// Start the loading process
include("vcmod/init.lua")

VCModels = VCModels or {}

local vehicles, _ = file.Find('vcmod/vehicles/*', 'LUA')
for _, v in pairs(vehicles) do
    AddCSLuaFile('vcmod/vehicles/' .. v)
    include('vcmod/vehicles/' .. v)
end

if CLIENT then
    VCLanguages = VCLanguages or {}
    VCLanguagesRev = VCLanguagesRev or {}
end

local langs, _ = file.Find('vcmod/languages/*', 'LUA')
for _, v in pairs(langs) do
    if CLIENT then
        include('vcmod/languages/' .. v)
     else
        AddCSLuaFile('vcmod/languages/' .. v)
    end
end

// Check if RunString works properly обойдешься
-- if !VC.Test_RS then RunString("VC.Test_RS = true", "vc_rs_t") if !VC.Test_RS then VCPrint("ERROR: RunString is non-functional, stopping.") return end end

// Initialize the Auto Updter loading
if SERVER then
    include("vcmod/server/load.lua")
else
    include("vcmod/client/load.lua")
    include("vcmod/client/load2.lua")
    include("vcmod/client/load3.lua")
end
