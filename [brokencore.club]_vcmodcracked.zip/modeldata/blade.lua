VCModels['models/blade.mdl']	=	{
		em_state	=	5236594887,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Date	=	"Thu May  4 01:06:45 2017",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-34.479999542236,-126.76999664307,-15.949999809265),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(8.9799995422363,-126.76999664307,-15.949999809265),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Pos	=	Vector(6.4699997901917,9.789999961853,-0.079999998211861),
					},
				{
				Pos	=	Vector(-37.75,-37.919998168945,-0.079999998211861),
					},
				{
				Pos	=	Vector(6.6599998474121,-37.919998168945,-0.079999998211861),
					},
				},
		DLT	=	3491063258,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						55,
						0,
						},
				UseBlinkers	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-50.319999694824,-132.75,3.8599998950958),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				UseRunning	=	true,
				UseBrake	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-44.279998779297,-132.75,3.8599998950958),
				UseDynamic	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-43.700000762939,108.48999786377,1.9700000286102),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RunningColor	=	{
						216.03,
						195.17,
						241.79,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-50.479999542236,108.48999786377,1.9700000286102),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RunningColor	=	{
						216.03,
						195.17,
						241.79,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				HBeamColor	=	{
						233,
						208,
						255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseSprite	=	true,
				LBeamColor	=	{
						233,
						208,
						255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				UsePrjTex	=	true,
				Pos	=	Vector(-36.459999084473,108.48999786377,1.9700000286102),
				RenderInner	=	true,
				ProjTexture	=	{
					Size	=	2000,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						55,
						0,
						},
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseRunning	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(25.180000305176,-132.75,3.8599998950958),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseRunning	=	true,
				Beta_Inner3D	=	true,
				UseSprite	=	true,
				Pos	=	Vector(19.260000228882,-132.75,3.8599998950958),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBrake	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(17.790000915527,108.48999786377,1.9700000286102),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RunningColor	=	{
						216.03,
						195.17,
						241.79,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(24.739999771118,108.48999786377,1.9700000286102),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseRunning	=	true,
				RunningColor	=	{
						216.03,
						195.17,
						241.79,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				HBeamColor	=	{
						233,
						208,
						255,
						},
				ProjTexture	=	{
					Size	=	2000,
					Angle	=	Angle(0,90,0),
						},
				SpecMat	=	{
						},
				UsePrjTex	=	true,
				LBeamColor	=	{
						233,
						208,
						255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner	=	true,
				Pos	=	Vector(10.319999694824,108.48999786377,1.9700000286102),
				UseSprite	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				},
		Copyright	=	"Copyright © 2012-2017 VCMod (freemmaann). All Rights Reserved.",
		Fuel	=	{
			FuelType	=	0,
				},
		Author	=	"ᶜʳᵉᵉᵖᵉʳᵀᵛ (76561198051637331)",
}