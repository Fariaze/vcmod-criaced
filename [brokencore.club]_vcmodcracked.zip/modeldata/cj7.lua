VCModels['models/cj7.mdl']	=	{
		em_state	=	5236594443,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Copyright	=	"DurkaTeam @ 2025 No rights reserved",
		Exhaust	=	{
				{
				Ang	=	Angle(15,-45,0),
				Pos	=	Vector(23.409999847412,-16.200000762939,26.25),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(13.5,-4.3800001144409,45.209999084473),
				RadioControl	=	true,
					},
				},
		DLT	=	3491062962,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-28.60000038147,-80.290000915527,46.400001525879),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	5,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-25.479999542236,-80.209999084473,46.419998168945),
								},
							},
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				ReverseColor	=	{
						200,
						225,
						255,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					Pos4	=	Vector(-28.770000457764,-80.290000915527,41.950000762939),
					Mid	=	true,
					AmountH	=	5,
					Pos1	=	Vector(-28.760000228882,-80.199996948242,45.040000915527),
					AmountV	=	5,
					Pos2	=	Vector(-25.090000152588,-80.089996337891,45.049999237061),
					Use	=	true,
					Mid_Full	=	true,
					Pos3	=	Vector(-25,-80.180000305176,41.930000305176),
						},
				BlinkersColor	=	{
						255,
						55,
						0,
						},
				UseBrake	=	true,
				UseBlinkers	=	true,
				RenderHD_Adv	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-26.659999847412,-80.269996643066,43.540000915527),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				RenderHD_Size	=	0.5,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				RenderHD_Adv	=	true,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-30.930000305176,68.449996948242,44.659999847412),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderHD_Size	=	0.5,
				UseBlinkers	=	true,
				RenderInner_Size	=	1.2,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				RenderHD_Adv	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-13.220000267029,72.889999389648,39.080001831055),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderHD_Size	=	0.5,
				UseBlinkers	=	true,
				RenderInner_Size	=	1.2,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				SpecSpin	=	{
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseHead	=	true,
				UsePrjTex	=	true,
				Pos	=	Vector(-15.069999694824,72.779998779297,47.200000762939),
				UseDynamic	=	true,
				ProjTexture	=	{
					Forward	=	30,
					Size	=	2000,
					Angle	=	Angle(0,90,0),
						},
				RenderHD_Size	=	0.5,
				RenderHD_Adv	=	true,
				HeadColor	=	{
						196,
						181,
						255,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-15.010000228882,72.650001525879,47.150001525879),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RenderHD_Size	=	0.5,
				RenderHD_Adv	=	true,
				RunningColor	=	{
						213.67,
						211.2,
						199.85,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				UseSprite	=	true,
				Pos	=	Vector(29.049999237061,-80.290000915527,46.400001525879),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	5,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(25.930000305176,-80.209999084473,46.419998168945),
								},
							},
						},
				ReverseColor	=	{
						200,
						225,
						255,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
				SpecRec	=	{
					Pos4	=	Vector(29.319999694824,-80.290000915527,41.950000762939),
					Mid	=	true,
					AmountH	=	5,
					Pos1	=	Vector(29.309999465942,-80.199996948242,45.040000915527),
					AmountV	=	5,
					Pos2	=	Vector(25.639999389648,-80.089996337891,45.049999237061),
					Use	=	true,
					Mid_Full	=	true,
					Pos3	=	Vector(25.549999237061,-80.180000305176,41.930000305176),
						},
				UseBrake	=	true,
				RenderHD_Adv	=	true,
				UseSprite	=	true,
				Pos	=	Vector(27.209999084473,-80.269996643066,43.540000915527),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				RenderHD_Size	=	0.5,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				RenderHD_Adv	=	true,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(30.930000305176,68.449996948242,44.659999847412),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderHD_Size	=	0.5,
				UseBlinkers	=	true,
				RenderInner_Size	=	1.2,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
				RenderHD_Adv	=	true,
				Pos	=	Vector(12.670000076294,72.889999389648,39.080001831055),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderHD_Size	=	0.5,
				UseSprite	=	true,
				RenderInner_Size	=	1.2,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				SpecSpin	=	{
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseHead	=	true,
				UseSprite	=	true,
				Pos	=	Vector(14.25,72.779998779297,47.200000762939),
				UseDynamic	=	true,
				HeadColor	=	{
						196,
						181,
						255,
						},
				RenderHD_Size	=	0.5,
				RenderHD_Adv	=	true,
				UsePrjTex	=	true,
				ProjTexture	=	{
					Forward	=	30,
					Size	=	2000,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(14.159999847412,72.650001525879,47.150001525879),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RenderHD_Size	=	0.5,
				RenderHD_Adv	=	true,
				RunningColor	=	{
						213.67,
						211.2,
						199.85,
						},
				UseRunning	=	true,
					},
				},
		Date	=	"10/09/15 21:47:21",
		Author	=	"freemmaann (76561197989323181)",
}