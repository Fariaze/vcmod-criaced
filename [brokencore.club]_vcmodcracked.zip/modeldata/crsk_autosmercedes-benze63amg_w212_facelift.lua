VCModels['models/crsk_autosmercedes-benze63amg_w212_facelift.mdl']	=	{
		em_state	=	5236594839,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Date	=	"Fri Aug 10 23:41:02 2018",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(-31.950000762939,-113.98000335693,14.260000228882),
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(-25.459999084473,-115.5299987793,14.380000114441),
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(31.450000762939,-114.11000061035,14.260000228882),
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(25,-115.68000030518,14.25),
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(18.530000686646,11.659999847412,29.139999389648),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(-19.030000686646,-34.090000152588,31.139999389648),
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(15.529999732971,-34.240001678467,31.010000228882),
					},
				},
		DLT	=	3491063226,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.07,
						},
				SpecSpin	=	{
						},
				DD_Blnk_Run	=	true,
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				DD_if_LBeam	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-25.620000839233,105.75,26.989999771118),
				RenderInner_ClrUse	=	false,
				RenderInner_Size	=	1.3,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-23.579999923706,105.90000152588,27.809999465942),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-23.420000076294,105.83999633789,27.969999313354),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-23.379999160767,105.79000091553,28.110000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-23.379999160767,105.73000335693,28.270000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-23.489999771118,105.59999847412,28.510000228882),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.25,103.73000335693,31.659999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.530000686646,103.55000305176,31.930000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.920000076294,103.30000305176,32.189998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.190000534058,103.13999938965,32.340000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.5,102.98999786377,32.479999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.430000305176,101.91999816895,33.009998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.840000152588,101.69999694824,33.119998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.239999771118,101.44000244141,33.229999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.489999771118,101.25,33.299999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.840000152588,100.90000152588,33.400001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.219999313354,100.45999908447,33.509998321533),
								},
							{
							Pos	=	Vector(-31.909999847412,99.370002746582,33.709999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner	=	true,
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.07,
						},
				SpecSpin	=	{
						},
				DD_Blnk_Run	=	true,
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				DD_if_LBeam	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-32.650001525879,102.70999908447,28.079999923706),
				RenderInner_ClrUse	=	false,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	35,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-31.040000915527,103.25,28.479999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.819999694824,103.30000305176,28.569999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.690000534058,103.31999969482,28.690000534058),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.639999389648,103.30999755859,28.809999465942),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.610000610352,103.2799987793,28.920000076294),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.610000610352,103.2200012207,29.049999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.620000839233,103.15000152588,29.170000076294),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.659999847412,103.05999755859,29.309999465942),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.940000534058,101.70999908447,31.35000038147),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.229999542236,100.12000274658,33.290000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.409999847412,99.910003662109,33.529998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.569999694824,99.73999786377,33.689998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.700000762939,99.589996337891,33.810001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.919998168945,99.360000610352,33.990001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.139999389648,99.160003662109,34.130001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.369998931885,98.930000305176,34.259998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.159999847412,98.269996643066,34.540000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.819999694824,97.639999389648,34.75),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.419998168945,96.940002441406,34.939998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.169998168945,96,35.169998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.729999542236,95.199996948242,35.349998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.360000610352,94.089996337891,35.599998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.689998626709,93.349998474121,35.75),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.970001220703,92.669998168945,35.889999389648),
								},
							{
							Pos	=	Vector(-39.240001678467,91.779998779297,36.090000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Size	=	1.3,
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.07,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseSprite	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-39.520000457764,-101.11000061035,42.700000762939),
				RenderInner_Size	=	1,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-38.919998168945,-104.11000061035,42.790000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.759998321533,-104.7799987793,42.840000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.610000610352,-105.33999633789,42.880001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.430000305176,-105.98999786377,42.959999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.130001068115,-106.84999847412,43.080001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.919998168945,-107.45999908447,43.180000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.669998168945,-108.04000091553,43.290000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.450000762939,-108.55000305176,43.340000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.240001678467,-109.01000213623,43.360000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.049999237061,-109.41000366211,43.369998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.819999694824,-109.79000091553,43.389999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.490001678467,-110.2799987793,43.389999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.099998474121,-110.84999847412,43.380001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.669998168945,-111.43000030518,43.340000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.150001525879,-111.98999786377,43.299999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.630001068115,-112.44000244141,43.25),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.040000915527,-112.88999938965,43.189998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.400001525879,-113.31999969482,43.119998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.580001831055,-113.76999664307,43.009998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.780000686646,-114.16999816895,42.900001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.920000076294,-114.48000335693,42.790000915527),
								},
							},
						},
				UseBrake	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.07,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-40.349998474121,-103.65000152588,38.830001831055),
				RenderInner	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-39.740001678467,-106.5299987793,38.790000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-39.459999084473,-107.55000305176,38.759998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-39.159999847412,-108.56999969482,38.669998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.729999542236,-109.68000030518,38.529998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.419998168945,-110.33000183105,38.450000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.159999847412,-110.80999755859,38.409999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.830001831055,-111.34999847412,38.360000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.470001220703,-111.83000183105,38.319999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.119998931885,-112.25,38.290000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.689998626709,-112.69000244141,38.259998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.090000152588,-113.25,38.220001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.520000457764,-113.73000335693,38.189998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.900001525879,-114.18000030518,38.159999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.290000915527,-114.54000091553,38.139999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.549999237061,-114.9700012207,38.099998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.849998474121,-115.30000305176,38.069999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.180000305176,-115.58999633789,38.040000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.450000762939,-115.84999847412,38.009998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.219999313354,-116.59999847412,37.900001525879),
								},
							},
						},
				UseBrake	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.07,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-40.080001831055,-100.56999969482,41.740001678467),
				UseSprite	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-39.240001678467,-104.62000274658,41.799999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.840000152588,-106.08999633789,41.810001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.490001678467,-107.36000061035,41.819999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.090000152588,-108.5,41.849998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.610000610352,-109.5,41.849998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.080001831055,-110.44000244141,41.830001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.729999542236,-110.98999786377,41.810001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.310001373291,-111.55999755859,41.799999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.830001831055,-112.09999847412,41.770000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.369998931885,-112.55999755859,41.740001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.860000610352,-113,41.689998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.119998931885,-113.51999664307,41.630001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.400001525879,-113.94999694824,41.560001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.680000305176,-114.30999755859,41.5),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.760000228882,-114.7200012207,41.409999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.35000038147,-115.30999755859,41.279998779297),
								},
							},
						},
				RenderInner_Size	=	1,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.07,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-40.369998931885,-102.19999694824,40.090000152588),
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-39.430000305176,-106.20999908447,40.099998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-39.029998779297,-107.54000091553,40.099998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.590000152588,-108.73999786377,40.090000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.169998168945,-109.63999938965,40.080001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.680000305176,-110.54000091553,40.060001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.189998626709,-111.30000305176,40.029998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.720001220703,-111.93000030518,40.009998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.270000457764,-112.4700012207,39.990001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.740001678467,-112.98999786377,39.959999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.069999694824,-113.5299987793,39.919998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.509998321533,-113.91000366211,39.880001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.919998168945,-114.26999664307,39.840000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.220001220703,-114.66000366211,39.790000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.639999389648,-114.91000366211,39.75),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.700000762939,-115.2799987793,39.689998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.700000762939,-115.93000030518,39.560001373291),
								},
							},
						},
				RenderInner_Size	=	1,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.07,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-30.329999923706,-114.66000366211,42.700000762939),
				RenderMLCenter	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-27.840000152588,-115.40000152588,42.279998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.120000839233,-115.58999633789,42.150001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.229999542236,-115.80000305176,41.959999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.739999771118,-115.93000030518,41.799999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.520000457764,-116.01000213623,41.650001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.370000839233,-116.09999847412,41.459999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.260000228882,-116.19999694824,41.209999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.209999084473,-116.30000305176,40.979999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.229999542236,-116.33999633789,40.849998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.360000610352,-116.34999847412,40.75),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.520000457764,-116.34999847412,40.740001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.75,-116.30000305176,40.759998321533),
								},
							{
							Pos	=	Vector(-29.809999465942,-115.51999664307,41.209999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.07,
						},
				SpecSpin	=	{
						},
				Beta_Inner3D	=	true,
				UseRunning	=	true,
				RenderInner_Size	=	1,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-29.309999465942,-116.05000305176,39.520000457764),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-25.819999694824,-116.73999786377,39.209999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.309999465942,-116.83999633789,39.150001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.809999465942,-116.93000030518,39.069999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.559999465942,-116.98999786377,39.009998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.329999923706,-117.04000091553,38.919998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.110000610352,-117.11000061035,38.779998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-23.969999313354,-117.18000030518,38.619998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-23.809999465942,-117.25,38.409999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-23.719999313354,-117.33000183105,38.209999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-23.629999160767,-117.40000152588,37.970001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-23.629999160767,-117.45999908447,37.810001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-23.690000534058,-117.48000335693,37.689998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-23.760000228882,-117.48999786377,37.619998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-23.879999160767,-117.48999786377,37.610000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.60000038147,-116.75,37.840000152588),
								},
							},
						},
				RenderMLCenter	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				RenderMLCenter	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-37.400001525879,-107.59999847412,42.549999237061),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	3,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-36.189998626709,-109.75,42.5),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.009998321533,-110.98000335693,42.439998626709),
								},
							},
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						255,
						120,
						0,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				RenderMLCenter	=	true,
				RenderInner_Size	=	1,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-33.810001373291,-111.80999755859,42.369998931885),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	3,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-32.599998474121,-112.5,42.229999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.229999542236,-113.05000305176,42.090000152588),
								},
							},
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						255,
						120,
						0,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				RenderMLCenter	=	true,
				RenderInner_Size	=	1,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-37.75,-109.19999694824,39.279998779297),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	3,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-36.369998931885,-110.87999725342,39.169998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.189998626709,-112.06999969482,39.099998474121),
								},
							},
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						255,
						120,
						0,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				UseBrake	=	true,
				RenderInner_Size	=	1,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-33.950000762939,-112.84999847412,39.020000457764),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	4,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-32.669998168945,-113.55000305176,38.919998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.39999961853,-114.09999847412,38.840000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.959999084473,-114.58999633789,38.75),
								},
							},
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						255,
						120,
						0,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				UseSprite	=	true,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-28.940000534058,-117.01999664307,36.229999542236),
				UseDynamic	=	true,
				RenderInner_Size	=	4,
				SpecMLine	=	{
					Amount	=	12,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-31.379999160767,-116.25,36.349998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.939998626709,-115.68000030518,36.400001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.330001831055,-114.93000030518,36.450000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.330001831055,-114.2200012207,36.490001678467),
								},
							},
						},
				RenderMLCenter	=	true,
				RenderInner_Clr	=	{
						255,
						120,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				RenderInner	=	true,
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-27.920000076294,-116.91999816895,36.290000915527),
								},
							},
						},
				UseSprite	=	true,
				Pos	=	Vector(-21.620000839233,-117.54000091553,36.200000762939),
				UseDynamic	=	true,
				RenderInner_Size	=	2,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				Beta_Inner3D	=	true,
				RenderInner_Clr	=	{
						255,
						120,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				Beta_Inner3D	=	true,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner_Size	=	4,
				UseSprite	=	true,
				Pos	=	Vector(-35.689998626709,-113.98999786377,36.5),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	15,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-36.900001525879,-112.62999725342,36.5),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.279998779297,-109.93000030518,36.5),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-39.650001525879,-106.12000274658,36.560001373291),
								},
							},
						},
				RenderMLCenter	=	true,
				RenderInner_Clr	=	{
						255,
						120,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						135,
						0,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-30.809999465942,101.70999908447,30.39999961853),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				RenderInner_Clr	=	{
						255,
						120,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						135,
						0,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-31.75,100.70999908447,31.809999465942),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				RenderInner_Clr	=	{
						255,
						120,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						135,
						0,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-32.569999694824,99.569999694824,33.119998931885),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				RenderInner_Clr	=	{
						255,
						120,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						135,
						0,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-33.599998474121,98.540000915527,34.409999847412),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
						255,
						120,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						135,
						0,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-34.979999542236,97.199996948242,35.040000915527),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				RenderInner_Clr	=	{
						255,
						120,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						135,
						0,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-36.259998321533,95.809997558594,35.400001525879),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				UseSprite	=	true,
				RenderInner	=	true,
				RenderInner_Clr	=	{
						255,
						120,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						135,
						0,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-37.369998931885,94.190002441406,35.689998626709),
				UseDynamic	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
						255,
						120,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						135,
						0,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-38.099998474121,92.669998168945,36.150001525879),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				RenderInner_Clr	=	{
						255,
						120,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.07,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-25.620000839233,105.75,26.989999771118),
				RenderMLCenter	=	true,
				RenderInner_Size	=	1.3,
				SpecMLine	=	{
					Amount	=	15,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-23.579999923706,105.90000152588,27.809999465942),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-23.420000076294,105.83999633789,27.969999313354),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-23.379999160767,105.79000091553,28.110000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-23.379999160767,105.73000335693,28.270000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-23.489999771118,105.59999847412,28.510000228882),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.25,103.73000335693,31.659999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.530000686646,103.55000305176,31.930000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.920000076294,103.30000305176,32.189998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.190000534058,103.13999938965,32.340000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.5,102.98999786377,32.479999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.430000305176,101.91999816895,33.009998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.840000152588,101.69999694824,33.119998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.239999771118,101.44000244141,33.229999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.489999771118,101.25,33.299999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.840000152588,100.90000152588,33.400001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.219999313354,100.45999908447,33.509998321533),
								},
							{
							Pos	=	Vector(-31.909999847412,99.370002746582,33.709999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner	=	true,
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.07,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-32.650001525879,102.70999908447,28.079999923706),
				RenderMLCenter	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-31.040000915527,103.25,28.479999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.819999694824,103.30000305176,28.569999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.690000534058,103.31999969482,28.690000534058),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.639999389648,103.30999755859,28.809999465942),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.610000610352,103.2799987793,28.920000076294),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.610000610352,103.2200012207,29.049999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.620000839233,103.15000152588,29.170000076294),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.659999847412,103.05999755859,29.309999465942),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.940000534058,101.70999908447,31.35000038147),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.229999542236,100.12000274658,33.290000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.409999847412,99.910003662109,33.529998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.569999694824,99.73999786377,33.689998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.700000762939,99.589996337891,33.810001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.919998168945,99.360000610352,33.990001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.139999389648,99.160003662109,34.130001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.369998931885,98.930000305176,34.259998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.159999847412,98.269996643066,34.540000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.819999694824,97.639999389648,34.75),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.419998168945,96.940002441406,34.939998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.169998168945,96,35.169998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.729999542236,95.199996948242,35.349998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.360000610352,94.089996337891,35.599998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.689998626709,93.349998474121,35.75),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.970001220703,92.669998168945,35.889999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-39.240001678467,91.779998779297,36.090000152588),
								},
							},
						},
				RenderInner_Size	=	1.3,
				RunningColor	=	{
						195,
						195,
						255,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-32.979999542236,97.699996948242,28.440000534058),
					Pos2	=	Vector(-38.520000457764,97.699996948242,34.040000915527),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-33.229999542236,97.699996948242,33.830001831055),
					Pos3	=	Vector(-38.950000762939,97.699996948242,29.479999542236),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-35.959999084473,97.690002441406,31.60000038147),
				UseSprite	=	true,
				RenderMLCenter	=	true,
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.7,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-26.770000457764,101.51000213623,29.329999923706),
					Pos2	=	Vector(-28.549999237061,101.61000061035,31.110000610352),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-26.770000457764,101.51000213623,31.110000610352),
					Pos3	=	Vector(-28.549999237061,101.61000061035,29.329999923706),
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseSprite	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				SpecMat	=	{
						},
				Pos	=	Vector(-27.659999847412,101.30999755859,30.219999313354),
				Beta_Inner3D	=	true,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.03,
						},
				SpecSpin	=	{
						},
				UseSprite	=	true,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner_Size	=	3.5,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-45.909999847412,29.620000839233,48.709999084473),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-47.470001220703,28.35000038147,48.659999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-48.470001220703,27.5,48.630001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-49.470001220703,26.299999237061,48.599998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-49.970001220703,25.299999237061,48.580001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-50.099998474121,23.60000038147,48.569999694824),
								},
							},
						},
				UseBlinkers	=	true,
				RenderInner_Clr	=	{
						255,
						120,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.03,
						},
				SpecSpin	=	{
						},
				UseSprite	=	true,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner_Size	=	3.5,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-44.889999389648,30.579999923706,47.610000610352),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-46.360000610352,29.459999084473,47.599998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-48.580001831055,27.620000839233,47.599998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-49.930000305176,26.090000152588,47.569999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-50.299999237061,25.090000152588,47.569999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-50.349998474121,23.39999961853,47.569999694824),
								},
							},
						},
				RenderMLCenter	=	true,
				RenderInner_Clr	=	{
						255,
						120,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.04,
						},
				SpecSpin	=	{
						},
				Beta_Inner3D	=	true,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner_Size	=	4,
				UseSprite	=	true,
				Pos	=	Vector(-49.970001220703,25.799999237061,48.080001831055),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	5,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-50.299999237061,24.60000038147,48.069999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-50.299999237061,23.39999961853,48.069999694824),
								},
							},
						},
				UseBlinkers	=	true,
				RenderInner_Clr	=	{
						255,
						120,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.07,
						},
				SpecSpin	=	{
						},
				DD_Blnk_Run	=	true,
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				DD_if_LBeam	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(26.239999771118,105.59999847412,26.860000610352),
				RenderInner_ClrUse	=	false,
				RenderInner_Size	=	1.3,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(24.200000762939,105.75,27.680000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.040000915527,105.69000244141,27.840000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24,105.63999938965,27.979999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24,105.58000183105,28.139999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.110000610352,105.44999694824,28.379999160767),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.870000839233,103.58000183105,31.530000686646),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.14999961853,103.40000152588,31.799999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.540000915527,103.15000152588,32.060001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.809999465942,102.98999786377,32.209999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.120000839233,102.83999633789,32.349998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.049999237061,101.76999664307,32.880001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.459999084473,101.55000305176,32.990001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.860000610352,101.29000091553,33.099998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.110000610352,101.09999847412,33.169998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.459999084473,100.75,33.270000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.840000152588,100.30999755859,33.380001068115),
								},
							{
							Pos	=	Vector(32.529998779297,99.220001220703,33.580001831055),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner	=	true,
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.07,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(26.239999771118,105.59999847412,26.860000610352),
				RenderMLCenter	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	15,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(24.200000762939,105.75,27.680000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.040000915527,105.69000244141,27.840000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24,105.63999938965,27.979999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24,105.58000183105,28.139999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.110000610352,105.44999694824,28.379999160767),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.870000839233,103.58000183105,31.530000686646),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.14999961853,103.40000152588,31.799999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.540000915527,103.15000152588,32.060001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.809999465942,102.98999786377,32.209999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.120000839233,102.83999633789,32.349998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.049999237061,101.76999664307,32.880001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.459999084473,101.55000305176,32.990001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.860000610352,101.29000091553,33.099998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.110000610352,101.09999847412,33.169998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.459999084473,100.75,33.270000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.840000152588,100.30999755859,33.380001068115),
								},
							{
							Pos	=	Vector(32.529998779297,99.220001220703,33.580001831055),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Size	=	1.3,
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.07,
						},
				SpecSpin	=	{
						},
				DD_Blnk_Run	=	true,
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				DD_if_LBeam	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(33.270000457764,102.55999755859,27.959999084473),
				RenderInner_ClrUse	=	false,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	35,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(31.659999847412,103.09999847412,28.360000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.440000534058,103.15000152588,28.450000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.309999465942,103.16999816895,28.569999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.260000228882,103.16000366211,28.690000534058),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.229999542236,103.12999725342,28.799999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.229999542236,103.06999969482,28.930000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.239999771118,103,29.049999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.280000686646,102.91000366211,29.190000534058),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.560001373291,101.55999755859,31.229999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.849998474121,99.970001220703,33.169998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.029998779297,99.76000213623,33.409999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.189998626709,99.589996337891,33.569999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.319999694824,99.440002441406,33.689998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.540000915527,99.209999084473,33.869998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.759998321533,99.01000213623,34.009998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.990001678467,98.779998779297,34.139999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.779998779297,98.120002746582,34.419998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.439998626709,97.48999786377,34.630001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.040000915527,96.790000915527,34.819999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.790000915527,95.849998474121,35.049999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(38.349998474121,95.050003051758,35.229999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(38.979999542236,93.940002441406,35.479999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(39.310001373291,93.199996948242,35.630001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(39.590000152588,92.519996643066,35.770000457764),
								},
							{
							Pos	=	Vector(39.860000610352,91.629997253418,35.970001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Size	=	1.3,
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.07,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(33.240001678467,102.55999755859,27.950000762939),
				RenderMLCenter	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(31.629999160767,103.09999847412,28.35000038147),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.409999847412,103.15000152588,28.440000534058),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.280000686646,103.16999816895,28.559999465942),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.229999542236,103.16000366211,28.680000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.200000762939,103.12999725342,28.790000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.200000762939,103.06999969482,28.920000076294),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.209999084473,103,29.040000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.25,102.91000366211,29.180000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.529998779297,101.55999755859,31.219999313354),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.819999694824,99.970001220703,33.159999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34,99.76000213623,33.400001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.159999847412,99.589996337891,33.560001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.290000915527,99.440002441406,33.680000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.509998321533,99.209999084473,33.860000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.729999542236,99.01000213623,34),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.959999084473,98.779998779297,34.130001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.75,98.120002746582,34.409999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.409999847412,97.48999786377,34.619998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.009998321533,96.790000915527,34.810001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.759998321533,95.849998474121,35.040000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(38.319999694824,95.050003051758,35.220001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(38.950000762939,93.940002441406,35.470001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(39.279998779297,93.199996948242,35.619998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(39.560001373291,92.519996643066,35.759998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(39.830001831055,91.629997253418,35.959999084473),
								},
							},
						},
				RenderInner_Size	=	1.3,
				RunningColor	=	{
						195,
						195,
						255,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.7,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(27.35000038147,101.36000061035,29.200000762939),
					Pos2	=	Vector(29.129999160767,101.45999908447,30.979999542236),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(27.35000038147,101.36000061035,30.979999542236),
					Pos3	=	Vector(29.129999160767,101.45999908447,29.200000762939),
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				SpecMat	=	{
						},
				Pos	=	Vector(28.239999771118,101.16000366211,30.090000152588),
				UseSprite	=	true,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(33.569999694824,97.550003051758,28.239999771118),
					Pos2	=	Vector(39.110000610352,97.550003051758,33.840000152588),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(33.819999694824,97.550003051758,33.630001068115),
					Pos3	=	Vector(39.540000915527,97.550003051758,29.280000686646),
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(36.549999237061,97.540000915527,31.39999961853),
				RenderMLCenter	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				Beta_Inner3D	=	true,
				SpecMat	=	{
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						135,
						0,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(31.389999389648,101.55999755859,30.270000457764),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
						255,
						120,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						135,
						0,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(32.340000152588,100.55999755859,31.659999847412),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
						255,
						120,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						135,
						0,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				UseSprite	=	true,
				Pos	=	Vector(33.180000305176,99.419998168945,32.990001678467),
				UseDynamic	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
						255,
						120,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						135,
						0,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(34.099998474121,98.23999786377,34.229999542236),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				UseSprite	=	true,
				RenderInner	=	true,
				RenderInner_Clr	=	{
						255,
						120,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						135,
						0,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(35.5,97.050003051758,34.889999389648),
				UseDynamic	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
						255,
						120,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						135,
						0,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(36.880001068115,95.51000213623,35.189998626709),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
						255,
						120,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						135,
						0,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(37.799999237061,94,35.540000915527),
				UseDynamic	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
						255,
						120,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						135,
						0,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(38.599998474121,92.5,36.020000457764),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				UseSprite	=	true,
				RenderInner	=	true,
				RenderInner_Clr	=	{
						255,
						120,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.03,
						},
				SpecSpin	=	{
						},
				UseSprite	=	true,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(46.200000762939,29.39999961853,48.520000457764),
				UseDynamic	=	true,
				RenderInner_Size	=	3.5,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(47.759998321533,28.129999160767,48.470001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(48.759998321533,27.280000686646,48.439998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(49.759998321533,26.079999923706,48.409999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(50.259998321533,25.079999923706,48.389999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(50.389999389648,23.379999160767,48.380001068115),
								},
							},
						},
				UseBlinkers	=	true,
				RenderInner_Clr	=	{
						255,
						120,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.03,
						},
				SpecSpin	=	{
						},
				Beta_Inner3D	=	true,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(45.200000762939,30.39999961853,47.389999389648),
				UseDynamic	=	true,
				RenderInner_Size	=	3.5,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(46.669998168945,29.280000686646,47.380001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(48.889999389648,27.440000534058,47.380001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(50.240001678467,25.909999847412,47.349998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(50.610000610352,24.909999847412,47.349998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(50.659999847412,23.219999313354,47.349998474121),
								},
							},
						},
				UseBlinkers	=	true,
				RenderInner_Clr	=	{
						255,
						120,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.04,
						},
				SpecSpin	=	{
						},
				Beta_Inner3D	=	true,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(50.25,25.60000038147,47.799999237061),
				UseDynamic	=	true,
				RenderInner_Size	=	4,
				SpecMLine	=	{
					Amount	=	5,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(50.580001831055,24.39999961853,47.790000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(50.580001831055,23.200000762939,47.790000915527),
								},
							},
						},
				UseBlinkers	=	true,
				RenderInner_Clr	=	{
						255,
						120,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.07,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(39.099998474121,-101.29000091553,42.549999237061),
				RenderInner	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(38.5,-104.29000091553,42.639999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(38.340000152588,-104.95999908447,42.689998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(38.189998626709,-105.51999664307,42.729999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(38.009998321533,-106.16999816895,42.810001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.709999084473,-107.0299987793,42.930000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.5,-107.63999938965,43.029998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.25,-108.2200012207,43.139999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.029998779297,-108.73000335693,43.189998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.819999694824,-109.19000244141,43.209999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.630001068115,-109.58999633789,43.220001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.400001525879,-109.9700012207,43.240001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.069999694824,-110.45999908447,43.240001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.680000305176,-111.0299987793,43.229999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.25,-111.61000061035,43.189998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.729999542236,-112.16999816895,43.150001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.209999084473,-112.62000274658,43.099998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.619998931885,-113.06999969482,43.040000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.979999542236,-113.5,42.970001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.159999847412,-113.94999694824,42.860000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.360000610352,-114.34999847412,42.75),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.5,-114.66000366211,42.639999389648),
								},
							},
						},
				UseBrake	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.07,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(30,-114.80000305176,42.569999694824),
				RenderMLCenter	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(27.510000228882,-115.54000091553,42.150001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.790000915527,-115.73000335693,42.020000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.89999961853,-115.94000244141,41.830001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.409999847412,-116.06999969482,41.669998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.190000534058,-116.15000152588,41.520000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.040000915527,-116.23999786377,41.330001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.930000305176,-116.33999633789,41.080001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.879999160767,-116.44000244141,40.849998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.89999961853,-116.48000335693,40.720001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.030000686646,-116.48999786377,40.619998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.190000534058,-116.48999786377,40.610000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.420000076294,-116.44000244141,40.630001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.479999542236,-115.66000366211,41.080001831055),
								},
							},
						},
				RenderInner	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.07,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(39.700000762939,-100.69999694824,41.599998474121),
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(38.860000610352,-104.75,41.659999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(38.459999084473,-106.2200012207,41.669998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(38.110000610352,-107.48999786377,41.680000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.709999084473,-108.62999725342,41.709999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.229999542236,-109.62999725342,41.709999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.700000762939,-110.56999969482,41.689998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.349998474121,-111.12000274658,41.669998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.930000305176,-111.69000244141,41.659999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.450000762939,-112.23000335693,41.630001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.990001678467,-112.69000244141,41.599998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.479999542236,-113.12999725342,41.549999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.740001678467,-113.65000152588,41.490001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.020000457764,-114.08000183105,41.419998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.299999237061,-114.44000244141,41.360000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.379999160767,-114.84999847412,41.270000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.969999313354,-115.44000244141,41.139999389648),
								},
							},
						},
				RenderInner	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.07,
						},
				SpecSpin	=	{
						},
				UseSprite	=	true,
				UseRunning	=	true,
				RenderInner_Size	=	1,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(28.89999961853,-116.2799987793,39.389999389648),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(25.409999847412,-116.9700012207,39.080001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.89999961853,-117.06999969482,39.020000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.39999961853,-117.16000366211,38.939998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.14999961853,-117.2200012207,38.880001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(23.920000076294,-117.26999664307,38.790000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(23.700000762939,-117.33999633789,38.650001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(23.559999465942,-117.41000366211,38.490001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(23.39999961853,-117.48000335693,38.279998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(23.309999465942,-117.55999755859,38.080001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(23.219999313354,-117.62999725342,37.840000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(23.219999313354,-117.69000244141,37.680000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(23.280000686646,-117.70999908447,37.560001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(23.35000038147,-117.7200012207,37.490001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(23.469999313354,-117.7200012207,37.479999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.190000534058,-116.98000335693,37.709999084473),
								},
							},
						},
				RenderMLCenter	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.07,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(40.029998779297,-102.40000152588,39.950000762939),
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(39.090000152588,-106.41000366211,39.959999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(38.689998626709,-107.73999786377,39.959999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(38.25,-108.94000244141,39.950000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.830001831055,-109.83999633789,39.939998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.340000152588,-110.73999786377,39.919998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.849998474121,-111.5,39.889999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.380001068115,-112.12999725342,39.869998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.930000305176,-112.66999816895,39.849998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.400001525879,-113.19000244141,39.819999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.729999542236,-113.73000335693,39.779998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.169998168945,-114.11000061035,39.740001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.580001831055,-114.4700012207,39.700000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.880001068115,-114.86000061035,39.650001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.299999237061,-115.11000061035,39.610000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.360000610352,-115.48000335693,39.549999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.360000610352,-116.12999725342,39.419998168945),
								},
							},
						},
				RenderInner	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.07,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseSprite	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(39.919998168945,-103.90000152588,38.700000762939),
				RenderInner	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(39.310001373291,-106.7799987793,38.659999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(39.029998779297,-107.80000305176,38.630001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(38.729999542236,-108.81999969482,38.540000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(38.299999237061,-109.93000030518,38.400001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.990001678467,-110.58000183105,38.319999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.729999542236,-111.05999755859,38.279998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.400001525879,-111.59999847412,38.229999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.040000915527,-112.08000183105,38.189998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.689998626709,-112.5,38.159999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.259998321533,-112.94000244141,38.130001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.659999847412,-113.5,38.090000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.090000152588,-113.98000335693,38.060001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.470001220703,-114.43000030518,38.029998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.860000610352,-114.79000091553,38.009998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.119998931885,-115.2200012207,37.970001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.419998168945,-115.55000305176,37.939998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.75,-115.83999633789,37.909999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.020000457764,-116.09999847412,37.880001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.790000915527,-116.84999847412,37.770000457764),
								},
							},
						},
				UseBrake	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				RenderInner	=	true,
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(27.700000762939,-117.06999969482,36.189998626709),
								},
							},
						},
				UseSprite	=	true,
				Pos	=	Vector(21.39999961853,-117.69000244141,36.099998474121),
				UseDynamic	=	true,
				RenderInner_Size	=	2,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				Beta_Inner3D	=	true,
				RenderInner_Clr	=	{
						255,
						120,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				Beta_Inner3D	=	true,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner_Size	=	4,
				UseSprite	=	true,
				Pos	=	Vector(35.200000762939,-114.13999938965,36.299999237061),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	15,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(36.409999847412,-112.7799987793,36.299999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.790000915527,-110.08000183105,36.299999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(39.159999847412,-106.26999664307,36.360000610352),
								},
							},
						},
				UseBlinkers	=	true,
				RenderInner_Clr	=	{
						255,
						120,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				Beta_Inner3D	=	true,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner_Size	=	4,
				UseSprite	=	true,
				Pos	=	Vector(28.479999542236,-117.16999816895,36.069999694824),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	12,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(30.920000076294,-116.40000152588,36.189998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.479999542236,-115.83000183105,36.240001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.869998931885,-115.08000183105,36.290000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.869998931885,-114.37000274658,36.299999237061),
								},
							},
						},
				UseBlinkers	=	true,
				RenderInner_Clr	=	{
						255,
						120,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				UseBrake	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(33.599998474121,-113,38.900001525879),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	4,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(32.319999694824,-113.69999694824,38.799999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.049999237061,-114.25,38.720001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.610000610352,-114.73999786377,38.630001068115),
								},
							},
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						255,
						120,
						0,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				RenderMLCenter	=	true,
				RenderInner_Size	=	1,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				UseSprite	=	true,
				Pos	=	Vector(37.400001525879,-109.06999969482,39.139999389648),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	3,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(36.020000457764,-110.75,39.029998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.840000152588,-111.94000244141,38.959999084473),
								},
							},
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						255,
						120,
						0,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				UseBrake	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(36.990001678467,-107.44999694824,42.419998168945),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	3,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(35.779998779297,-109.59999847412,42.369998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.599998474121,-110.83000183105,42.310001373291),
								},
							},
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						255,
						120,
						0,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				UseBrake	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(33.5,-111.95999908447,42.220001220703),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	3,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(32.290000915527,-112.65000152588,42.080001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.920000076294,-113.19999694824,41.939998626709),
								},
							},
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						255,
						120,
						0,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	122,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-13.029999732971,-93.110000610352,52.189998626709),
				RenderMLCenter	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	60,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-6.5999999046326,-93.889999389648,52.220001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-0.30000001192093,-94.099998474121,52.25),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(5.960000038147,-93.959999084473,52.189998626709),
								},
							{
							Pos	=	Vector(12.800000190735,-93.199996948242,52.130001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner	=	true,
				UseSprite	=	true,
				UseBrake	=	true,
					},
				},
		Copyright	=	"Copyright © 2012-2018 VCMod (freemmaann). All Rights Reserved.",
		Fuel	=	{
			FuelLidPos	=	Vector(0,0,0),
			Capacity	=	66,
			Override	=	true,
			FuelType	=	0,
				},
		Author	=	"𝓒𝓣𝓥 (76561198051637331)",
}