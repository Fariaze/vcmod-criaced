VCModels['models/crsk_autosfordcrownvictoria_1987.mdl']	=	{
		em_state	=	5236594794,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Copyright	=	"Copyright © 2012-2018 VCMod (freemmaann). All Rights Reserved.",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(32.200000762939,-105.81999969482,12.569999694824),
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(16,0,0),
				Pos	=	Vector(18.760000228882,15.949999809265,29.25),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(19,0,0),
				Pos	=	Vector(-21.10000038147,-22.020000457764,29.89999961853),
					},
				{
				Ang	=	Angle(19,0,0),
				Pos	=	Vector(21.10000038147,-22.020000457764,29.89999961853),
					},
				{
				Ang	=	Angle(19,0,0),
				Pos	=	Vector(0,-22,29.89999961853),
					},
				},
		DLT	=	3491063196,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5928,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Use	=	true,
					UseColor	=	true,
					Pos2	=	Vector(-37.669998168945,109.54000091553,32.529998779297),
					Color	=	{
						r	=	255,
						b	=	172,
						a	=	255,
						g	=	175,
							},
					Pos4	=	Vector(-30.700000762939,109.66999816895,28.25),
					Pos1	=	Vector(-30.459999084473,109.66999816895,32.470001220703),
					Pos3	=	Vector(-37.619998931885,109.66999816895,28.14999961853),
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				HBeamColor	=	{
					r	=	255,
					b	=	172,
					a	=	255,
					g	=	175,
						},
				ReducedVis	=	true,
				UseRunning	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-33.990001678467,109.66999816895,30.39999961853),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				UseSprite	=	true,
				RenderHD_Adv	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	172,
					a	=	255,
					g	=	175,
						},
				SpecMat	=	{
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5928,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Use	=	true,
					UseColor	=	true,
					Pos2	=	Vector(37.669998168945,109.54000091553,32.529998779297),
					Color	=	{
						r	=	255,
						b	=	172,
						a	=	255,
						g	=	175,
							},
					Pos4	=	Vector(30.700000762939,109.66999816895,28.25),
					Pos1	=	Vector(30.459999084473,109.66999816895,32.470001220703),
					Pos3	=	Vector(37.619998931885,109.66999816895,28.14999961853),
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				HBeamColor	=	{
					r	=	255,
					b	=	172,
					a	=	255,
					g	=	175,
						},
				ReducedVis	=	true,
				UseRunning	=	true,
				RenderHD_Adv	=	true,
				Pos	=	Vector(33.990001678467,109.66999816895,30.39999961853),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	172,
					a	=	255,
					g	=	175,
						},
				SpecMat	=	{
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	255,
					b	=	172,
					a	=	255,
					g	=	175,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Use	=	true,
					UseColor	=	true,
					Pos2	=	Vector(-29.85000038147,109.54000091553,32.529998779297),
					Color	=	{
						r	=	255,
						b	=	172,
						a	=	255,
						g	=	175,
							},
					Pos4	=	Vector(-22.879999160767,109.66999816895,28.25),
					Pos1	=	Vector(-22.639999389648,109.66999816895,32.470001220703),
					Pos3	=	Vector(-29.799999237061,109.66999816895,28.14999961853),
						},
				HBeamColor	=	{
					r	=	255,
					b	=	172,
					a	=	255,
					g	=	175,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-26.170000076294,109.66999816895,30.39999961853),
				SpecMat	=	{
						},
				RenderInner	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				RenderInner_Size	=	1,
				RenderHD_Adv	=	true,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	255,
					b	=	172,
					a	=	255,
					g	=	175,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Use	=	true,
					UseColor	=	true,
					Pos2	=	Vector(29.85000038147,109.54000091553,32.529998779297),
					Color	=	{
						r	=	255,
						b	=	172,
						a	=	255,
						g	=	175,
							},
					Pos4	=	Vector(22.879999160767,109.66999816895,28.25),
					Pos1	=	Vector(22.639999389648,109.66999816895,32.470001220703),
					Pos3	=	Vector(29.799999237061,109.66999816895,28.14999961853),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderHD_Adv	=	true,
				Pos	=	Vector(26.170000076294,109.66999816895,30.39999961853),
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				RenderInner_Size	=	1,
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				HBeamColor	=	{
					r	=	255,
					b	=	172,
					a	=	255,
					g	=	175,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				SpecMat	=	{
					Select	=	19,
					New	=	"models\crskautos\ford\crownvictoria_1987\neworangeprib_on",
					Use	=	true,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-21.659999847412,110.83999633789,26.319999694824),
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1.5929,
				SpecMLine	=	{
					Amount	=	11,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-28.229999542236,110.83999633789,26.319999694824),
								},
							{
							Pos	=	Vector(-38.369998931885,110.83999633789,26.319999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RenderHD_Adv	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				SpecMat	=	{
					Select	=	20,
					New	=	"models\crskautos\ford\crownvictoria_1987\newdash_on",
					Use	=	true,
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(21.659999847412,110.83999633789,26.319999694824),
				RenderHD_Adv	=	true,
				RenderInner_Size	=	1.5929,
				SpecMLine	=	{
					Amount	=	12,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(28.229999542236,110.83999633789,26.319999694824),
								},
							{
							Pos	=	Vector(38.369998931885,110.83999633789,26.319999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.276,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-21.659999847412,110.83999633789,26.319999694824),
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1.5929,
				SpecMLine	=	{
					Amount	=	7,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-28.229999542236,110.83999633789,26.319999694824),
								},
							{
							Size	=	0.1,
							Pos	=	Vector(-38.369998931885,110.83999633789,26.319999694824),
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							UseClr	=	false,
								},
							},
						},
				RenderInner	=	true,
				RenderHD_Adv	=	true,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.276,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(21.659999847412,110.83999633789,26.319999694824),
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	7,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(28.229999542236,110.83999633789,26.319999694824),
								},
							{
							Size	=	0.1,
							Pos	=	Vector(38.369998931885,110.83999633789,26.319999694824),
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							UseClr	=	false,
								},
							},
						},
				RenderInner_Size	=	1.5929,
				RenderHD_Adv	=	true,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.13,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				RenderHD_Adv	=	true,
				Pos	=	Vector(-36.919998168945,-107.54000091553,30.510000228882),
				RenderInner	=	true,
				RenderInner_Size	=	2.3286,
				SpecMLine	=	{
					Amount	=	11,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-29.469999313354,-107.54000091553,30.510000228882),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.13,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBrake	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(36.919998168945,-107.54000091553,30.510000228882),
				RenderInner_Size	=	2.3286,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	11,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(29.469999313354,-107.54000091553,30.510000228882),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderHD_Adv	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.13,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				RenderHD_Adv	=	true,
				Pos	=	Vector(-36.919998168945,-108.59999847412,27.950000762939),
				UseSprite	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	11,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-29.469999313354,-108.59999847412,27.950000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Size	=	2.3286,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.13,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(36.919998168945,-108.59999847412,27.950000762939),
				UseBrake	=	true,
				RenderInner_Size	=	2.3286,
				SpecMLine	=	{
					Amount	=	11,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(29.469999313354,-108.59999847412,27.950000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderHD_Adv	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.13,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-36.919998168945,-107.25,33.060001373291),
				RenderHD_Adv	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	11,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-29.469999313354,-107.25,33.060001373291),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Size	=	2.3286,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.13,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(36.919998168945,-107.25,33.060001373291),
				RenderInner	=	true,
				RenderInner_Size	=	2.3286,
				SpecMLine	=	{
					Amount	=	11,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(29.469999313354,-107.25,33.060001373291),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderHD_Adv	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.13,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				RenderHD_Adv	=	true,
				Pos	=	Vector(-36.919998168945,-105.98999786377,35.680000305176),
				Beta_Inner3D	=	true,
				RenderInner_Size	=	2.3286,
				SpecMLine	=	{
					Amount	=	11,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-29.469999313354,-105.98999786377,35.680000305176),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.13,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(36.919998168945,-105.98999786377,35.680000305176),
				RenderInner_Size	=	2.3286,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	11,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(29.469999313354,-105.98999786377,35.680000305176),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderHD_Adv	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.07,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				RenderInner_Size	=	2.3286,
				UseSprite	=	true,
				SpecMat	=	{
						},
				RenderGlow_Size	=	0.3041,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-29.530000686646,-109.11000061035,24.719999313354),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderHD_Adv	=	true,
				Pos	=	Vector(-36.979999542236,-109.11000061035,24.719999313354),
				UseDynamic	=	true,
				RenderInner	=	true,
				ReverseColor	=	{
					r	=	200,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.07,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				RenderGlow_Size	=	0.3041,
				RenderHD_Adv	=	true,
				SpecMat	=	{
						},
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(29.530000686646,-109.11000061035,24.719999313354),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseSprite	=	true,
				Pos	=	Vector(36.979999542236,-109.11000061035,24.719999313354),
				UseDynamic	=	true,
				RenderInner_Size	=	2.3286,
				ReverseColor	=	{
					r	=	200,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				},
		Date	=	"Sun Feb  4 21:29:18 2018",
		Fuel	=	{
			FuelLidPos	=	Vector(-41.930000305176,-71.330001831055,34.419998168945),
			FuelType	=	0,
			Capacity	=	70,
			Override	=	true,
			FuelLidUse	=	true,
				},
		Author	=	"CrushingSkirmish (76561198017348899)",
}