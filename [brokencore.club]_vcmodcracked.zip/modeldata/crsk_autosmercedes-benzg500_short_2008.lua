VCModels['models/crsk_autosmercedes-benzg500_short_2008.mdl']	=	{
		em_state	=	5236594701,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Date	=	"04/28/17 01:03:51",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(-49.700000762939,-26.10000038147,11.079999923706),
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(-47.959999084473,-31.10000038147,10.220000267029),
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(12,0,0),
				Pos	=	Vector(20.809999465942,-0.86000001430511,45.759998321533),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(12,0,0),
				Pos	=	Vector(-20.809999465942,-41.529998779297,47.759998321533),
					},
				{
				Ang	=	Angle(12,0,0),
				Pos	=	Vector(20.809999465942,-41.569999694824,47.799999237061),
					},
				{
				Ang	=	Angle(12,0,0),
				Pos	=	Vector(0,-41.569999694824,47.759998321533),
					},
				{
				Cant_Exit_Lock	=	true,
				DriveBy_Cant	=	true,
				Ang	=	Angle(180,-14,-90),
				Pos	=	Vector(-5.6300001144409,-73.580001831055,37.880001068115),
				Switch_Cant	=	true,
				Switch_Rear	=	true,
					},
				},
		DLT	=	3491063134,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.7,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				SpecCircle	=	{
					Use	=	true,
						},
				UseSprite	=	true,
				LBeamColor	=	{
						195,
						195,
						255,
						},
				UseDynamic	=	true,
				RenderInner	=	true,
				Pos	=	Vector(-29.690000534058,87.309997558594,41.819999694824),
				RenderInner_Size	=	1,
				UsePrjTex	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.7,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				SpecCircle	=	{
					Use	=	true,
						},
				UseSprite	=	true,
				LBeamColor	=	{
						195,
						195,
						255,
						},
				UseDynamic	=	true,
				RenderInner	=	true,
				Pos	=	Vector(29.629999160767,87.309997558594,41.810001373291),
				RenderInner_Size	=	1,
				UsePrjTex	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				BGroups	=	{
					[4]	=	{
						[0]	=	"perednii_b_stock",
							},
						},
				UseSprite	=	true,
				Pos	=	Vector(-27.889999389648,91.639999389648,23.290000915527),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6343,
					Brightness	=	2,
						},
				RunningColor	=	{
						230,
						170,
						240,
						},
				RenderInner_Size	=	1,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				BGroups	=	{
					[4]	=	{
						[0]	=	"perednii_b_stock",
							},
						},
				UseSprite	=	true,
				Pos	=	Vector(27.879999160767,91.639999389648,23.290000915527),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6343,
					Brightness	=	2,
						},
				RunningColor	=	{
						230,
						170,
						240,
						},
				RenderInner_Size	=	1,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3485,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				FogColor	=	{
						255,
						0,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				BGroups	=	{
					[5]	=	{
						[0]	=	"zadnii_b_stock",
							},
						},
				UseSprite	=	true,
				Pos	=	Vector(-31.010000228882,-97.129997253418,22.790000915527),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseFog	=	true,
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
				RenderInner_Size	=	1,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3485,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseReverse	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				BGroups	=	{
					[5]	=	{
						[0]	=	"zadnii_b_stock",
							},
						},
				UseSprite	=	true,
				Pos	=	Vector(30.659999847412,-97.129997253418,22.690000534058),
				UseDynamic	=	true,
				RenderInner	=	true,
				ReverseColor	=	{
						255,
						225,
						255,
						},
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
				RenderInner_Size	=	1,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				HBeamColor	=	{
						195,
						195,
						255,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner_Size	=	1,
				UsePrjTex	=	true,
				Pos	=	Vector(-29.639999389648,87.730003356934,41.790000915527),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecCircle	=	{
					Use	=	true,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				SpecMat	=	{
						},
				HBeamColor	=	{
						195,
						195,
						255,
						},
				ReducedVis	=	true,
				RenderInner_Size	=	1,
				UsePrjTex	=	true,
				Pos	=	Vector(29.64999961853,87.879997253418,41.709999084473),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecCircle	=	{
					Use	=	true,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3485,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-33.590000152588,78.110000610352,50.810001373291),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				RenderInner_Size	=	1,
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3485,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(33.560001373291,78.220001220703,50.810001373291),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
				RenderInner	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1364,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-46.310001373291,21.309999465942,62.5),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	6,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-49.909999847412,18.620000839233,62.580001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-51.169998168945,16.739999771118,62.529998779297),
								},
							},
						},
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
				RenderInner_Size	=	1,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1364,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(46.810001373291,21.049999237061,62.229999542236),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	6,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(50.369998931885,18.590000152588,62.209999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(49.689998626709,16.610000610352,62.159999847412),
								},
							},
						},
				UseBlinkers	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3485,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseRunning	=	true,
				UseBrake	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner_Size	=	1,
				UseSprite	=	true,
				Pos	=	Vector(-30.39999961853,-94.940002441406,32.25),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	2,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-33.680000305176,-94.459999084473,32.200000762939),
								},
							},
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						0,
						0,
						},
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3485,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseRunning	=	true,
				UseBrake	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(34.259998321533,-94.940002441406,31.829999923706),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	2,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(30.979999542236,-94.459999084473,31.780000686646),
								},
							},
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						0,
						0,
						},
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3485,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-37.619998931885,-94.940002441406,32.240001678467),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				RenderInner_Size	=	1,
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3485,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(37.590000152588,-94.940002441406,31.889999389648),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				RenderInner_Size	=	1,
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1364,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(5.3099999427795,-87.419998168945,79.120002746582),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-5.0799999237061,-87.309997558594,79.169998168945),
								},
							},
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner	=	true,
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3485,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				FogColor	=	{
						255,
						0,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				BGroups	=	{
					[8]	=	{
							"krysha",
							},
						},
				UseSprite	=	true,
				Pos	=	Vector(-24.870000839233,-88.230003356934,95.48999786377),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				UseFog	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3485,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseReverse	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				BGroups	=	{
					[8]	=	{
							"krysha",
							},
						},
				UseSprite	=	true,
				Pos	=	Vector(25.969999313354,-88.230003356934,95.029998779297),
				UseDynamic	=	true,
				RenderInner	=	true,
				ReverseColor	=	{
						255,
						225,
						255,
						},
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
				RenderInner_Size	=	1,
					},
				},
		Copyright	=	"Copyright © 2012-2017 VCMod (freemmaann). All Rights Reserved.",
		Fuel	=	{
			FuelLidPos	=	Vector(41.869998931885,-83.449996948242,40.419998168945),
			FuelType	=	0,
			Capacity	=	96,
			Override	=	true,
			FuelLidUse	=	true,
				},
		Author	=	"CrushingSkirmish (76561198017348899)",
}