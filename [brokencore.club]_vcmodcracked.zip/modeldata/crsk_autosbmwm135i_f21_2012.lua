VCModels['models/crsk_autosbmwm135i_f21_2012.mdl']	=	{
		em_state	=	5236594668,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		HealthEnginePosOvr	=	true,
		Date	=	"Sun Jan 21 23:26:38 2018",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(-20.139999389648,-106.98999786377,13.670000076294),
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(20.139999389648,-106.98999786377,13.670000076294),
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(18.489999771118,-2.1600000858307,27.540000915527),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(-17.489999771118,-38.729999542236,29.540000915527),
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(14.989999771118,-38.229999542236,29.540000915527),
					},
				},
		HealthEnginePos	=	Vector(0.5,58,33.5),
		DLT	=	3491063112,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.07,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-27.629999160767,-99.980003356934,40.409999847412),
				RenderInner_Size	=	1,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	40,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-30.690000534058,-98.639999389648,40.439998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.369998931885,-97.370002746582,40.470001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.799999237061,-97.160003662109,40.490001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.020000457764,-97.059997558594,40.5),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.220001220703,-96.949996948242,40.520000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.380001068115,-96.849998474121,40.549999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.569999694824,-96.709999084473,40.610000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.779998779297,-96.559997558594,40.689998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.939998626709,-96.400001525879,40.770000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.040000915527,-96.300003051758,40.840000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.150001525879,-96.160003662109,40.950000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.25,-95.900001525879,41.119998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.299999237061,-95.599998474121,41.330001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.330001831055,-94.809997558594,42.069999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.340000152588,-94.5,42.340000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.360000610352,-94.379997253418,42.419998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.389999389648,-94.199996948242,42.509998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.430000305176,-94.040000915527,42.560001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.5,-93.809997558594,42.560001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.590000152588,-93.5,42.549999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.680000305176,-93.180000305176,42.540000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.790000915527,-92.809997558594,42.520000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.919998168945,-92.339996337891,42.490001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.159999847412,-91.379997253418,42.400001525879),
								},
							},
						},
				RenderMLCenter	=	true,
				RunningColor	=	{
						255,
						0,
						0,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.07,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RenderMLCenter	=	true,
				UseRunning	=	true,
				RenderInner_Size	=	1,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-28.040000915527,-99.970001220703,38.919998168945),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	40,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-29.629999160767,-99.330001831055,38.930000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.190000534058,-98.669998168945,38.930000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.989999771118,-98.309997558594,38.939998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.630001068115,-98.019996643066,38.939998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.139999389648,-97.76000213623,38.950000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.630001068115,-97.470001220703,38.950000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.110000610352,-97.150001525879,38.950000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.619998931885,-96.800003051758,38.950000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.040000915527,-96.480003356934,38.959999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.340000152588,-96.169998168945,38.959999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.580001831055,-95.900001525879,38.959999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.759998321533,-95.690002441406,38.959999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.959999084473,-95.410003662109,38.959999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.119998931885,-95.129997253418,38.959999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.330001831055,-94.680000305176,38.950000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.650001525879,-93.800003051758,38.930000305176),
								},
							},
						},
				UseSprite	=	true,
				RunningColor	=	{
						255,
						0,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.07,
						},
				SpecSpin	=	{
					Speed	=	0,
					Intensity	=	1,
						},
				RenderMLCenter	=	true,
				UseRunning	=	true,
				RenderInner	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(27.35000038147,-100.09999847412,40.290000915527),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	40,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(30.409999847412,-98.76000213623,40.319999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.090000152588,-97.48999786377,40.349998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.520000457764,-97.279998779297,40.369998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.740001678467,-97.180000305176,40.380001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.939998626709,-97.069999694824,40.400001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.099998474121,-96.970001220703,40.430000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.290000915527,-96.830001831055,40.490001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.5,-96.680000305176,40.569999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.659999847412,-96.519996643066,40.650001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.759998321533,-96.419998168945,40.720001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.869998931885,-96.279998779297,40.830001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.970001220703,-96.019996643066,41),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.020000457764,-95.720001220703,41.209999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.049999237061,-94.930000305176,41.950000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.060001373291,-94.620002746582,42.220001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.080001831055,-94.5,42.299999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.110000610352,-94.319999694824,42.389999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.150001525879,-94.160003662109,42.439998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.220001220703,-93.930000305176,42.439998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.310001373291,-93.620002746582,42.430000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.400001525879,-93.300003051758,42.419998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.509998321533,-92.930000305176,42.400001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.639999389648,-92.459999084473,42.369998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.880001068115,-91.5,42.279998779297),
								},
							},
						},
				UseSprite	=	true,
				RunningColor	=	{
						255,
						0,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.07,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RenderMLCenter	=	true,
				UseRunning	=	true,
				RenderInner	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(27.680000305176,-100.19999694824,38.770000457764),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	40,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(29.270000457764,-99.559997558594,38.779998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.829999923706,-98.900001525879,38.779998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.629999160767,-98.540000915527,38.790000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.270000457764,-98.25,38.790000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.779998779297,-97.98999786377,38.799999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.270000457764,-97.699996948242,38.799999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.75,-97.379997253418,38.799999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.259998321533,-97.029998779297,38.799999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.680000305176,-96.709999084473,38.810001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.979999542236,-96.400001525879,38.810001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.220001220703,-96.129997253418,38.810001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.400001525879,-95.919998168945,38.810001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.599998474121,-95.639999389648,38.810001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.759998321533,-95.360000610352,38.810001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.970001220703,-94.910003662109,38.799999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.290000915527,-94.029998779297,38.779998779297),
								},
							},
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
						255,
						0,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-36.279998779297,82.139999389648,31.430000305176),
				RenderMLCenter	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-36.229999542236,82.139999389648,31.89999961853),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.169998168945,82.139999389648,32.200000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.049999237061,82.139999389648,32.569999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.919998168945,82.139999389648,32.819999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.729999542236,82.139999389648,33.110000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.5,82.139999389648,33.340000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.240001678467,82.139999389648,33.540000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.040000915527,82.150001525879,33.659999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.709999084473,82.139999389648,33.779998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.360000610352,82.139999389648,33.860000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.950000762939,82.139999389648,33.900001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.419998168945,82.139999389648,33.939998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.419998168945,82.139999389648,33.939998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.920000076294,82.139999389648,33.900001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.60000038147,82.139999389648,33.849998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.35000038147,82.139999389648,33.799999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.090000152588,82.139999389648,33.740001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.799999237061,82.139999389648,33.610000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.430000305176,82.139999389648,33.380001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.200000762939,82.139999389648,33.200000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.969999313354,82.139999389648,32.889999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.799999237061,82.139999389648,32.540000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.690000534058,82.139999389648,32.180000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.590000152588,82.139999389648,31.729999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.569999694824,82.139999389648,31.409999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.569999694824,82.139999389648,30.909999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.590000152588,82.139999389648,30.579999923706),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.64999961853,82.139999389648,30.270000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.709999084473,82.139999389648,30.010000228882),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.799999237061,82.139999389648,29.739999771118),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.920000076294,82.139999389648,29.440000534058),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.030000686646,82.139999389648,29.239999771118),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.170000076294,82.139999389648,29.079999923706),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.329999923706,82.139999389648,28.930000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.559999465942,82.139999389648,28.75),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.799999237061,82.139999389648,28.610000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.170000076294,82.139999389648,28.450000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.530000686646,82.139999389648,28.35000038147),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.950000762939,82.139999389648,28.290000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.419998168945,82.139999389648,28.25),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.930000305176,82.139999389648,28.229999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.400001525879,82.139999389648,28.260000228882),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.900001525879,82.139999389648,28.280000686646),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.319999694824,82.139999389648,28.340000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.630001068115,82.139999389648,28.39999961853),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.840000152588,82.139999389648,28.459999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.099998474121,82.139999389648,28.590000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.400001525879,82.139999389648,28.770000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.639999389648,82.139999389648,28.969999313354),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.819999694824,82.139999389648,29.200000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.979999542236,82.139999389648,29.5),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.099998474121,82.139999389648,29.819999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.209999084473,82.150001525879,30.229999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.270000457764,82.139999389648,30.719999313354),
								},
							{
							Pos	=	Vector(-36.279998779297,82.139999389648,31.450000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Size	=	1,
				RunningColor	=	{
					r	=	255,
					b	=	255,
					a	=	255,
					g	=	254,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(36.810001373291,81.919998168945,31.309999465942),
				RenderMLCenter	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(36.759998321533,81.919998168945,31.780000686646),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.700000762939,81.919998168945,32.080001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.580001831055,81.919998168945,32.450000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.450000762939,81.919998168945,32.700000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.259998321533,81.919998168945,32.990001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.029998779297,81.919998168945,33.220001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.770000457764,81.919998168945,33.419998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.569999694824,81.930000305176,33.540000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.240001678467,81.919998168945,33.659999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.889999389648,81.919998168945,33.740001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.479999542236,81.919998168945,33.779998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.950000762939,81.919998168945,33.819999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.950000762939,81.919998168945,33.819999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.450000762939,81.919998168945,33.779998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.130001068115,81.919998168945,33.729999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.879999160767,81.919998168945,33.680000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.620000839233,81.919998168945,33.619998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.329999923706,81.919998168945,33.490001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.959999084473,81.919998168945,33.259998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.729999542236,81.919998168945,33.080001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.5,81.919998168945,32.770000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.329999923706,81.919998168945,32.419998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.219999313354,81.919998168945,32.060001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.120000839233,81.919998168945,31.610000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.10000038147,81.919998168945,31.290000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.10000038147,81.919998168945,30.790000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.120000839233,81.919998168945,30.459999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.180000305176,81.919998168945,30.14999961853),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.239999771118,81.919998168945,29.889999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.329999923706,81.919998168945,29.620000839233),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.450000762939,81.919998168945,29.319999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.559999465942,81.919998168945,29.120000839233),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.700000762939,81.919998168945,28.959999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.860000610352,81.919998168945,28.809999465942),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.090000152588,81.919998168945,28.629999160767),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.329999923706,81.919998168945,28.489999771118),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.700000762939,81.919998168945,28.329999923706),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.060001373291,81.919998168945,28.229999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.479999542236,81.919998168945,28.170000076294),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.950000762939,81.919998168945,28.129999160767),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.459999084473,81.919998168945,28.110000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.930000305176,81.919998168945,28.139999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.430000305176,81.919998168945,28.159999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.849998474121,81.919998168945,28.219999313354),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.159999847412,81.919998168945,28.280000686646),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.369998931885,81.919998168945,28.340000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.630001068115,81.919998168945,28.469999313354),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.930000305176,81.919998168945,28.64999961853),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.169998168945,81.919998168945,28.85000038147),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.349998474121,81.919998168945,29.079999923706),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.509998321533,81.919998168945,29.379999160767),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.630001068115,81.919998168945,29.700000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.740001678467,81.930000305176,30.110000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.799999237061,81.919998168945,30.60000038147),
								},
							{
							Pos	=	Vector(36.810001373291,81.919998168945,31.329999923706),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	255,
					a	=	255,
					g	=	254,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.08,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-28.219999313354,87.5,31.780000686646),
				RenderMLCenter	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-28.219999313354,87.5,31.540000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.200000762939,87.5,31.25),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.139999389648,87.5,30.979999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.950000762939,87.5,30.64999961853),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.670000076294,87.5,30.39999961853),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.379999160767,87.5,30.260000228882),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27,87.5,30.10000038147),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.520000457764,87.5,30.020000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.020000457764,87.5,30.020000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.510000228882,87.5,30.049999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.959999084473,87.5,30.120000839233),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.680000305176,87.5,30.209999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.450000762939,87.5,30.35000038147),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.25,87.5,30.479999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.059999465942,87.5,30.700000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-23.940000534058,87.5,30.909999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-23.840000152588,87.5,31.170000076294),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-23.809999465942,87.5,31.389999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-23.790000915527,87.5,31.639999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-23.790000915527,87.5,32.139999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-23.819999694824,87.5,32.389999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-23.89999961853,87.5,32.610000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-23.959999084473,87.5,32.759998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.059999465942,87.5,32.889999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.159999847412,87.5,33.009998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.290000915527,87.5,33.139999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.459999084473,87.5,33.25),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.690000534058,87.5,33.369998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.959999084473,87.5,33.459999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.409999847412,87.5,33.520000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.790000915527,87.5,33.549999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.14999961853,87.5,33.549999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.64999961853,87.5,33.520000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.069999694824,87.5,33.470001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.340000152588,87.5,33.400001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.569999694824,87.5,33.270000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.719999313354,87.5,33.130001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.89999961853,87.5,32.939998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.010000228882,87.5,32.729999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.090000152588,87.5,32.520000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.159999847412,87.5,32.279998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.190000534058,87.5,32.090000152588),
								},
							{
							Pos	=	Vector(-28.219999313354,87.5,31.760000228882),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Size	=	1,
				RunningColor	=	{
					r	=	255,
					b	=	255,
					a	=	255,
					g	=	254,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.08,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(28.790000915527,87.400001525879,31.590000152588),
				RenderMLCenter	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(28.790000915527,87.400001525879,31.35000038147),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.770000457764,87.400001525879,31.059999465942),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.709999084473,87.400001525879,30.790000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.520000457764,87.400001525879,30.459999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.239999771118,87.400001525879,30.209999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.950000762939,87.400001525879,30.069999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.569999694824,87.400001525879,29.909999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.090000152588,87.400001525879,29.829999923706),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.590000152588,87.400001525879,29.829999923706),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.079999923706,87.400001525879,29.860000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.530000686646,87.400001525879,29.930000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.25,87.400001525879,30.020000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.020000457764,87.400001525879,30.159999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.819999694824,87.400001525879,30.290000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.629999160767,87.400001525879,30.510000228882),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.510000228882,87.400001525879,30.719999313354),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.409999847412,87.400001525879,30.979999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.379999160767,87.400001525879,31.200000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.360000610352,87.400001525879,31.450000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.360000610352,87.400001525879,31.950000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.389999389648,87.400001525879,32.200000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.469999313354,87.400001525879,32.419998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.530000686646,87.400001525879,32.569999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.629999160767,87.400001525879,32.700000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.729999542236,87.400001525879,32.819999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.860000610352,87.400001525879,32.950000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.030000686646,87.400001525879,33.060001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.260000228882,87.400001525879,33.180000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.530000686646,87.400001525879,33.270000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.979999542236,87.400001525879,33.330001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.360000610352,87.400001525879,33.360000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.719999313354,87.400001525879,33.360000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.219999313354,87.400001525879,33.330001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.639999389648,87.400001525879,33.279998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.909999847412,87.400001525879,33.209999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.139999389648,87.400001525879,33.080001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.290000915527,87.400001525879,32.939998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.469999313354,87.400001525879,32.75),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.579999923706,87.400001525879,32.540000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.659999847412,87.400001525879,32.330001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.729999542236,87.400001525879,32.090000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.760000228882,87.400001525879,31.89999961853),
								},
							{
							Pos	=	Vector(28.790000915527,87.400001525879,31.569999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Size	=	1,
				RunningColor	=	{
					r	=	255,
					b	=	255,
					a	=	255,
					g	=	254,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.06,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RenderMLCenter	=	true,
				UseRunning	=	true,
				RenderInner_Size	=	1,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-35.729999542236,79.430000305176,34.400001525879),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-35.580001831055,79.73999786377,34.380001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.450000762939,79.959999084473,34.369998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.229999542236,80.309997558594,34.349998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.020000457764,80.610000610352,34.340000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.830001831055,80.879997253418,34.319999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.169998168945,81.709999084473,34.259998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.909999847412,82.019996643066,34.229999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.450000762939,82.519996643066,34.180000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.659999847412,83.349998474121,34.099998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.530000686646,84.459999084473,33.959999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.379999160767,85.48999786377,33.819999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.5,86.209999084473,33.720001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.520000457764,86.919998168945,33.610000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.290000915527,87.769996643066,33.470001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.059999465942,88.519996643066,33.330001831055),
								},
							},
						},
				UseSprite	=	true,
				RunningColor	=	{
						255,
						254,
						255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.06,
						},
				SpecSpin	=	{
					Speed	=	0,
					Intensity	=	1,
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(36.259998321533,79.330001831055,34.25),
				RenderMLCenter	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(36.110000610352,79.639999389648,34.229999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.979999542236,79.860000610352,34.220001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.759998321533,80.209999084473,34.200000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.549999237061,80.51000213623,34.189998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.360000610352,80.779998779297,34.169998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.700000762939,81.610000610352,34.110000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.439998626709,81.919998168945,34.080001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.979999542236,82.419998168945,34.029998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.189998626709,83.25,33.950000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.060001373291,84.360000610352,33.810001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.909999847412,85.389999389648,33.669998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.030000686646,86.110000610352,33.569999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.049999237061,86.819999694824,33.459999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.819999694824,87.669998168945,33.319999694824),
								},
							{
							Pos	=	Vector(26.590000152588,88.419998168945,33.180000305176),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	255,
					a	=	255,
					g	=	254,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-23.590000152588,87.120002746582,29.430000305176),
					Pos2	=	Vector(-28.409999847412,87.120002746582,34.25),
					Color	=	{
							0,
							0,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(-23.590000152588,87.120002746582,34.25),
					Pos3	=	Vector(-28.409999847412,87.120002746582,29.430000305176),
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-26,84.620002746582,31.840000152588),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderInner_Size	=	1,
				UseSprite	=	true,
				RenderMLCenter	=	true,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(24.110000610352,87,29.280000686646),
					Pos2	=	Vector(28.930000305176,87,34.099998474121),
					Color	=	{
							0,
							0,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(24.110000610352,87,34.099998474121),
					Pos3	=	Vector(28.930000305176,87,29.280000686646),
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(26.520000457764,84.5,31.690000534058),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				RenderInner	=	true,
				UseSprite	=	true,
				RenderMLCenter	=	true,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderHD_Size	=	3,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-31.079999923706,81.839996337891,29.280000686646),
					Pos2	=	Vector(-34.860000610352,81.839996337891,33.060001373291),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-31.079999923706,81.839996337891,33.060001373291),
					Pos3	=	Vector(-34.860000610352,81.839996337891,29.280000686646),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-32.970001220703,81.339996337891,31.170000076294),
				RenderMLCenter	=	true,
				Beta_Inner3D	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderHD_Size	=	3,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(31.579999923706,81.680000305176,29.129999160767),
					Pos2	=	Vector(35.360000610352,81.680000305176,32.909999847412),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(31.579999923706,81.680000305176,32.909999847412),
					Pos3	=	Vector(35.360000610352,81.680000305176,29.129999160767),
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(33.470001220703,81.180000305176,31.020000457764),
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseSprite	=	true,
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RenderInner_Size	=	1,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-28.559999465942,-100.36000061035,35.909999847412),
					UseColor	=	true,
					Pos2	=	Vector(-36.830001831055,-95.620002746582,37.310001373291),
					Color	=	{
							255,
							80,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(-27.780000686646,-100.69999694824,37.529998779297),
					Pos3	=	Vector(-36.75,-95,35.169998168945),
						},
				FogColor	=	{
						255,
						0,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-33.220001220703,-96.900001525879,36.709999084473),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseFog	=	true,
				Beta_Inner3D	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.7,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseBrake	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-26.329999923706,-100.48999786377,42.919998168945),
					UseColor	=	true,
					Pos2	=	Vector(-32.840000152588,-92.370002746582,46.080001831055),
					Color	=	{
							255,
							80,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(-26.270000457764,-100.26999664307,44.569999694824),
					Pos3	=	Vector(-35,-93.879997253418,42.799999237061),
						},
				RenderInner	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-32.009998321533,-92.330001831055,44.049999237061),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				UseSprite	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.7,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(25.920000076294,-100.66999816895,42.799999237061),
					UseColor	=	true,
					Pos2	=	Vector(32.430000305176,-92.550003051758,45.959999084473),
					Color	=	{
							255,
							80,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(25.860000610352,-100.44999694824,44.450000762939),
					Pos3	=	Vector(34.590000152588,-94.059997558594,42.680000305176),
						},
				UseBrake	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(31.60000038147,-92.51000213623,43.930000305176),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderInner_Size	=	1,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderMLCenter	=	true,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-26.89999961853,-100.5,42.080001831055),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	15,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-33.939998626709,-96.959999084473,42.169998168945),
								},
							},
						},
				RenderInner_Size	=	2,
				UseSprite	=	true,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(26.489999771118,-100.80000305176,41.970001220703),
				UseDynamic	=	true,
				RenderInner_Size	=	2,
				SpecMLine	=	{
					Amount	=	15,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(33.529998779297,-97.26000213623,42.060001373291),
								},
							},
						},
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseDynamic	=	true,
				BrakeColor	=	{
						255,
						0,
						0,
						},
				RenderInner_Clr	=	{
						255,
						100,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-8.5,-86.98999786377,62.880001068115),
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(0.019999999552965,-87.440002441406,63.020000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(8.4300003051758,-87,62.799999237061),
								},
							},
						},
				RenderInner_Size	=	2,
				RenderMLCenter	=	true,
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.03,
						},
				SpecSpin	=	{
					Speed	=	0,
					Intensity	=	1,
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						255,
						100,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-42.319999694824,17.909999847412,47.650001525879),
				Beta_Inner3D	=	true,
				RenderInner_Size	=	3,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-44.919998168945,16.620000839233,47.810001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-46.419998168945,15.800000190735,47.909999847412),
								},
							},
						},
				RenderInner	=	true,
				RenderMLCenter	=	true,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.03,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						255,
						100,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-46.419998168945,15.800000190735,47.909999847412),
				Beta_Inner3D	=	true,
				RenderInner_Size	=	3,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-47.229999542236,15.109999656677,47.950000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-47.659999847412,14.619999885559,47.990001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-48.060001373291,13.880000114441,48.040000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-48.240001678467,12.89999961853,48.080001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-48.220001220703,11.800000190735,48.150001525879),
								},
							},
						},
				RenderInner	=	true,
				RenderMLCenter	=	true,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
					Double	=	true,
					Speed	=	2000,
					Intensity	=	1,
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(28.370000839233,-100.36000061035,35.770000457764),
					Pos2	=	Vector(36.639999389648,-95.620002746582,37.169998168945),
					Color	=	{
							255,
							100,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(27.590000152588,-100.69999694824,37.389999389648),
					Pos3	=	Vector(36.560001373291,-95,35.029998779297),
						},
				Beta_Inner3D	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				UseSprite	=	true,
				Pos	=	Vector(33.029998779297,-96.900001525879,36.569999694824),
				UseDynamic	=	true,
				RenderInner	=	true,
				ReverseColor	=	{
						255,
						245,
						255,
						},
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.03,
						},
				SpecSpin	=	{
					Intensity	=	1,
					Speed	=	0,
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						255,
						100,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(42.689998626709,16.60000038147,47.419998168945),
				UseSprite	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(45.009998321533,14.890000343323,47.590000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(46.240001678467,13.85000038147,47.680000305176),
								},
							},
						},
				RenderInner_Size	=	3,
				UseBlinkers	=	true,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.03,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	100,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(46.240001678467,13.85000038147,47.680000305176),
				UseBlinkers	=	true,
				RenderInner_Size	=	3,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(46.919998168945,13.039999961853,47.740001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(47.290000915527,12.39999961853,47.790000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(47.400001525879,11.880000114441,47.810001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(47.439998626709,11.140000343323,47.860000610352),
								},
							{
							Pos	=	Vector(47.130001068115,9.4899997711182,47.970001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner	=	true,
				UseSprite	=	true,
				RenderMLCenter	=	true,
					},
				},
		Copyright	=	"Copyright © 2012-2018 VCMod (freemmaann). All Rights Reserved.",
		Fuel	=	{
			FuelLidPos	=	Vector(38.25,-74.150001525879,43.069999694824),
			FuelType	=	0,
			Capacity	=	52,
			Override	=	true,
			FuelLidUse	=	true,
				},
		Author	=	"𝓒𝓣𝓥𝟏𝟐𝟐𝟓 (76561198051637331)",
}