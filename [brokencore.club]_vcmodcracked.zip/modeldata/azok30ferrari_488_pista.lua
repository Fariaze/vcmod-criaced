VCModels['models/azok30ferrari_488_pista.mdl']	=	{
		em_state	=	5236594689,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Date	=	"Fri Jan 29 00:14:10 2021",
		Exhaust	=	{
				{
				Pos	=	Vector(-17.219999313354,-117.09999847412,13.60000038147),
				Invulnerable	=	true,
				EffectIdle	=	"VC_Exhaust",
				Ang	=	Angle(0,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
					},
				{
				Pos	=	Vector(17.219999313354,-117.09999847412,13.60000038147),
				Invulnerable	=	true,
				EffectIdle	=	"VC_Exhaust",
				Ang	=	Angle(0,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
					},
				},
		ExtraSeats	=	{
				{
				Pos	=	Vector(15.880000114441,2.710000038147,17.180000305176),
					},
				},
		DLT	=	3491063126,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				UseRunning	=	true,
				Pos	=	Vector(-39.020000457764,73.980003356934,30.809999465942),
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseRunning	=	true,
				Pos	=	Vector(-39.959999084473,73.669998168945,30.979999542236),
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseRunning	=	true,
				Pos	=	Vector(-38.680000305176,76.540000915527,29.860000610352),
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Pos	=	Vector(-39.549999237061,76.050003051758,30),
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Pos	=	Vector(-38.430000305176,78.980003356934,29),
				UseSprite	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				Pos	=	Vector(-39.240001678467,78.580001831055,29.129999160767),
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseRunning	=	true,
				Pos	=	Vector(-38.080001831055,81.199996948242,27.940000534058),
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Pos	=	Vector(-38.849998474121,81.029998779297,28.200000762939),
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Pos	=	Vector(-37.669998168945,82.980003356934,27.10000038147),
				UseSprite	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				Pos	=	Vector(-38.520000457764,82.980003356934,27.35000038147),
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseRunning	=	true,
				Pos	=	Vector(-37.319999694824,84.919998168945,26.159999847412),
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				Pos	=	Vector(-38.220001220703,84.919998168945,26.409999847412),
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				HBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UsePrjTex	=	true,
				Pos	=	Vector(-34.150001525879,89.389999389648,22.889999389648),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				UseSprite	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				inner_AsSpheres	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				UseSprite	=	true,
				Pos	=	Vector(-30.780000686646,91.120002746582,22.440000534058),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				RenderInner_Size	=	1.9137931034483,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				inner_AsSpheres	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				UseSprite	=	true,
				Pos	=	Vector(-30.780000686646,91.629997253418,21.60000038147),
				UseDynamic	=	true,
				RenderInner_Size	=	1.9137931034483,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				inner_AsSpheres	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				UseSprite	=	true,
				Pos	=	Vector(-30.020000457764,92.98999786377,21.39999961853),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				RenderInner_Size	=	1.9137931034483,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				inner_AsSpheres	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				UseSprite	=	true,
				Pos	=	Vector(-30.020000457764,92.430000305176,22.239999771118),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderInner_Size	=	1.9137931034483,
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				inner_AsSpheres	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				UseSprite	=	true,
				Pos	=	Vector(-29.139999389648,93.870002746582,21.989999771118),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				RenderInner_Size	=	1.9137931034483,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				inner_AsSpheres	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				UseSprite	=	true,
				Pos	=	Vector(-29.139999389648,94.279998779297,21.110000610352),
				UseDynamic	=	true,
				RenderInner_Size	=	1.9137931034483,
				UseBlinkers	=	true,
				RenderInner	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Pos	=	Vector(39.020000457764,73.980003356934,30.809999465942),
				UseSprite	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Pos	=	Vector(39.959999084473,73.669998168945,30.979999542236),
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Pos	=	Vector(38.680000305176,76.540000915527,29.860000610352),
				UseSprite	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				UseRunning	=	true,
				Pos	=	Vector(39.549999237061,76.050003051758,30),
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				UseRunning	=	true,
				Pos	=	Vector(38.430000305176,78.980003356934,29),
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Pos	=	Vector(39.240001678467,78.580001831055,29.129999160767),
				UseSprite	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Pos	=	Vector(38.080001831055,81.199996948242,27.940000534058),
				UseSprite	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Pos	=	Vector(38.849998474121,81.029998779297,28.200000762939),
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				UseRunning	=	true,
				Pos	=	Vector(37.669998168945,82.980003356934,27.10000038147),
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Pos	=	Vector(38.520000457764,82.980003356934,27.35000038147),
				UseSprite	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Pos	=	Vector(37.319999694824,84.919998168945,26.159999847412),
				UseSprite	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				UseRunning	=	true,
				Pos	=	Vector(38.220001220703,84.919998168945,26.409999847412),
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				HBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UsePrjTex	=	true,
				Pos	=	Vector(34.150001525879,89.389999389648,22.889999389648),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				UseSprite	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				inner_AsSpheres	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				UseSprite	=	true,
				Pos	=	Vector(30.780000686646,91.120002746582,22.440000534058),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				RenderInner_Size	=	1.9137931034483,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				inner_AsSpheres	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				UseSprite	=	true,
				Pos	=	Vector(30.780000686646,91.629997253418,21.60000038147),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				RenderInner_Size	=	1.9137931034483,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				inner_AsSpheres	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				UseSprite	=	true,
				Pos	=	Vector(30.020000457764,92.98999786377,21.39999961853),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderInner_Size	=	1.9137931034483,
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				inner_AsSpheres	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				UseSprite	=	true,
				Pos	=	Vector(30.020000457764,92.430000305176,22.239999771118),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				RenderInner_Size	=	1.9137931034483,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				inner_AsSpheres	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				UseSprite	=	true,
				Pos	=	Vector(29.139999389648,93.870002746582,21.989999771118),
				UseDynamic	=	true,
				RenderInner_Size	=	1.9137931034483,
				RenderInner	=	true,
				UseBlinkers	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				inner_AsSpheres	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				UseSprite	=	true,
				Pos	=	Vector(29.139999389648,94.279998779297,21.110000610352),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				RenderInner_Size	=	1.9137931034483,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				RenderInner_ClrUse	=	false,
					},
				{
				UseBlinkers	=	true,
				inner_AsSpheres	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner	=	true,
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				UseSprite	=	true,
				Pos	=	Vector(-37.459999084473,-98.980003356934,33.430000305176),
				UseDynamic	=	true,
				RenderInner_Size	=	1.6034482758621,
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				SpecCircle	=	{
					Amount	=	15,
					Use	=	true,
					Radius	=	1.46,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-37.459999084473,-98.980003356934,33.430000305176),
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	25,
					Use	=	true,
					Radius	=	3.32,
						},
				RenderInner_Size	=	1.1206896551724,
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				inner_AsSpheres	=	true,
				UseReverse	=	true,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				UseSprite	=	true,
				Pos	=	Vector(-37.459999084473,-98.980003356934,33.430000305176),
				UseDynamic	=	true,
				RenderInner	=	true,
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner_Size	=	1.6034482758621,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				UseBlinkers	=	true,
				inner_AsSpheres	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				RenderInner_Size	=	1.6034482758621,
				UseSprite	=	true,
				Pos	=	Vector(37.459999084473,-98.980003356934,33.430000305176),
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	15,
					Use	=	true,
					Radius	=	1.46,
						},
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Size	=	1.1206896551724,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(37.459999084473,-98.980003356934,33.430000305176),
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	25,
					Use	=	true,
					Radius	=	3.32,
						},
				RenderInner	=	true,
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				inner_AsSpheres	=	true,
				UseReverse	=	true,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				UseSprite	=	true,
				Pos	=	Vector(37.459999084473,-98.980003356934,33.430000305176),
				UseDynamic	=	true,
				RenderInner	=	true,
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner_Size	=	1.6034482758621,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				UseBrake	=	true,
				RenderInner	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-8.6700000762939,-107.63999938965,40.549999237061),
				UseDynamic	=	true,
				RenderInner_Size	=	1.1551724137931,
				SpecMLine	=	{
					Amount	=	31,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(9.1300001144409,-107.48999786377,40.389999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				UseBrake	=	true,
				RenderInner_Size	=	1.5,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-37.459999084473,-98.980003356934,33.430000305176),
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	25,
					Use	=	true,
					Radius	=	3.32,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				UseBrake	=	true,
				RenderInner_Size	=	1.5,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(37.459999084473,-98.980003356934,33.430000305176),
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	25,
					Use	=	true,
					Radius	=	3.32,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				inner_AsSpheres	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				UseSprite	=	true,
				Pos	=	Vector(-46.720001220703,36.380001068115,24.090000152588),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderInner_Size	=	4,
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				inner_AsSpheres	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				UseSprite	=	true,
				Pos	=	Vector(46.720001220703,36.380001068115,24.090000152588),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				RenderInner_Size	=	4,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
				RenderInner_ClrUse	=	false,
					},
				},
		Copyright	=	"Copyright © 2021 VCMod (freemmaann). All Rights Reserved.",
		Fuel	=	{
			FuelType	=	0,
				},
		Author	=	"Azok30 (76561198183398967)",
}