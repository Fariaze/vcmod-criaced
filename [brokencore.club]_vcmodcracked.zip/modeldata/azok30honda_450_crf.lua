VCModels['models/azok30honda_450_crf.mdl']	=	{
		ExtraSeats	=	{
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(0,-25.200000762939,38.299999237061),
				RadioControl	=	true,
					},
				},
		em_state	=	5236594545,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		DLT	=	3491063030,
		Date	=	"Tue Jan  1 22:18:40 2019",
		Copyright	=	"Copyright © 2012-2019 VCMod (freemmaann). All Rights Reserved.",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(4.2300000190735,-29.829999923706,28.340000152588),
				EffectIdle	=	"VC_Exhaust",
					},
				},
		Author	=	"Azok30 (76561198183398967)",
}