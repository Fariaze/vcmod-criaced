VCModels['models/crsk_autosnissan370z_2016.mdl']	=	{
		em_state	=	5236594809,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		HealthEnginePosOvr	=	true,
		Date	=	"Mon Dec 11 01:25:14 2017",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-100,0),
				Pos	=	Vector(-21.729999542236,-105.30000305176,11.539999961853),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-80,0),
				Pos	=	Vector(21.459999084473,-105.40000152588,11.449999809265),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		Indication	=	{
			speedo_mph	=	{
				max	=	1,
				pp	=	"vehicle_guage",
				top	=	155,
					},
				},
		ExtraSeats	=	{
				{
				Pos	=	Vector(20.510000228882,-1.9400000572205,29.389999389648),
				DoorSounds	=	true,
				Ang	=	Angle(25,0,0),
				EnterRange	=	80,
				RadioControl	=	true,
					},
				},
		HealthEnginePos	=	Vector(0,66,34.5),
		DLT	=	3491063206,
		Lights	=	{
				{
				Sprite	=	{
					Size	=	0.2,
						},
				UseBrake	=	true,
				UseDynamic	=	true,
				RenderHD_Size	=	1.75,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	189,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderHD_Adv	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-9.1999998092651,-95.5,47.669998168945),
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	12,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-0.050000000745058,-96,47.630001068115),
								},
							{
							Pos	=	Vector(8.9799995422363,-95.5,47.610000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner	=	true,
				SpecSpin	=	{
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					Size	=	0.1,
						},
				UseBrake	=	true,
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	200,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-32.709999084473,-87.379997253418,44.049999237061),
				RenderInner_Size	=	1,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	2,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-32.119998931885,-87.480003356934,44.060001373291),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderHD_Adv	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecSpin	=	{
						},
					},
				{
				Sprite	=	{
					Size	=	0.1,
						},
				UseBrake	=	true,
				UseDynamic	=	true,
				RenderHD_Size	=	0.5,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				SpecSpin	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-32.630001068115,-89.940002441406,42.689998626709),
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	3,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-31.440000534058,-90.099998474121,42.669998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderMLCenter	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderHD_Adv	=	true,
					},
				{
				Sprite	=	{
					Size	=	0.1,
						},
				UseBrake	=	true,
				UseDynamic	=	true,
				RenderHD_Size	=	0.75,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				SpecSpin	=	{
						},
				RenderHD_Adv	=	true,
				Pos	=	Vector(-32.770000457764,-92.180000305176,41.169998168945),
				RenderInner_Size	=	1,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	4,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-30.809999465942,-92.389999389648,41.220001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseSprite	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					Size	=	0.1,
						},
				UseBrake	=	true,
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-33.009998321533,-94.019996643066,39.779998779297),
				RenderInner_Size	=	1,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	5,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-30.170000076294,-94.379997253418,39.790000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderHD_Adv	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecSpin	=	{
						},
					},
				{
				UseBlinkers	=	true,
				SpecSpin	=	{
						},
				UseSprite	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RenderInner_Size	=	1,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-30.930000305176,78.930000305176,36.049999237061),
					Pos2	=	Vector(-35.069999694824,79.019996643066,40.189998626709),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-30.930000305176,78.930000305176,40.189998626709),
					Pos3	=	Vector(-35.069999694824,79.019996643066,36.049999237061),
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-33.020000457764,78.529998779297,38.099998474121),
				UseDynamic	=	true,
				RenderInner	=	true,
				Sprite	=	{
					Size	=	0.5,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-28.60000038147,87.73999786377,31.049999237061),
					Pos2	=	Vector(-34.840000152588,87.73999786377,37.290000915527),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-28.60000038147,87.73999786377,37.290000915527),
					Pos3	=	Vector(-34.840000152588,87.73999786377,31.049999237061),
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				ReducedVis	=	true,
				SpecCircle	=	{
					InnerCenterOnly	=	true,
					Use	=	true,
						},
				Beta_Inner3D	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-31.75,87.970001220703,34.150001525879),
				SpecMat	=	{
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.6,
						},
					},
				{
				Sprite	=	{
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-27.780000686646,-93.800003051758,41.110000610352),
				UseDynamic	=	true,
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Pos4	=	Vector(-24.909999847412,-98.860000610352,39.659999847412),
					Pos2	=	Vector(-30.129999160767,-93.879997253418,42.389999389648),
					Use	=	true,
					Pos1	=	Vector(-27.270000457764,-95.190002441406,42.299999237061),
					Pos3	=	Vector(-28.89999961853,-97.269996643066,39.630001068115),
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-24.569999694824,-99.180000305176,39.479999542236),
					UseColor	=	true,
					Pos2	=	Vector(-30.469999313354,-93.559997558594,42.569999694824),
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	190,
							},
					Use	=	true,
					Pos1	=	Vector(-27.049999237061,-94.910003662109,42.650001525879),
					Pos3	=	Vector(-29.120000839233,-97.550003051758,39.279998779297),
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
				UseBlinkers	=	true,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					Size	=	0.1,
						},
				UseBrake	=	true,
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	200,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				SpecSpin	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(32.470001220703,-87.519996643066,43.900001525879),
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	2,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(31.879999160767,-87.620002746582,43.909999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Size	=	1,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderHD_Adv	=	true,
					},
				{
				Sprite	=	{
					Size	=	0.1,
						},
				UseBrake	=	true,
				UseDynamic	=	true,
				RenderHD_Size	=	0.5,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				RenderHD_Adv	=	true,
				Pos	=	Vector(32.389999389648,-90.110000610352,42.540000915527),
				UseSprite	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	3,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(31.200000762939,-90.269996643066,42.520000457764),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				SpecSpin	=	{
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					Size	=	0.1,
						},
				UseBrake	=	true,
				UseDynamic	=	true,
				RenderHD_Size	=	0.75,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(32.490001678467,-92.319999694824,41.020000457764),
				RenderInner	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	4,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(30.530000686646,-92.529998779297,41.069999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseSprite	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderHD_Adv	=	true,
					},
				{
				UseBlinkers	=	true,
				SpecSpin	=	{
						},
				Sprite	=	{
					Size	=	0.5,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(31.459999084473,78.769996643066,35.889999389648),
					Pos2	=	Vector(35.599998474121,78.860000610352,40.029998779297),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(31.459999084473,78.769996643066,40.029998779297),
					Pos3	=	Vector(35.599998474121,78.860000610352,35.889999389648),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner_Size	=	1,
				Beta_Inner3D	=	true,
				Pos	=	Vector(33.549999237061,78.370002746582,37.939998626709),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(29.139999389648,87.580001831055,30.89999961853),
					Pos2	=	Vector(35.380001068115,87.580001831055,37.139999389648),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	0,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(29.139999389648,87.580001831055,37.139999389648),
					Pos3	=	Vector(35.380001068115,87.580001831055,30.89999961853),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.6,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(32.290000915527,87.809997558594,34),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				SpecCircle	=	{
					InnerCenterOnly	=	true,
					Use	=	true,
						},
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Pos4	=	Vector(24.620000839233,-99,39.520000457764),
					Pos2	=	Vector(29.840000152588,-94.019996643066,42.25),
					Use	=	true,
					Pos1	=	Vector(26.979999542236,-95.330001831055,42.159999847412),
					Pos3	=	Vector(28.610000610352,-97.410003662109,39.490001678467),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(27.489999771118,-93.940002441406,40.970001220703),
				UseDynamic	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseSprite	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(24.280000686646,-99.319999694824,39.340000152588),
					UseColor	=	true,
					Pos2	=	Vector(30.180000305176,-93.699996948242,42.430000305176),
					Color	=	{
						r	=	255,
						b	=	0,
						a	=	255,
						g	=	190,
							},
					Use	=	true,
					Pos1	=	Vector(26.760000228882,-95.050003051758,42.509998321533),
					Pos3	=	Vector(28.829999923706,-97.690002441406,39.139999389648),
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Pos4	=	Vector(-27.639999389648,-93.879997253418,43.040000915527),
					Pos2	=	Vector(-30.610000610352,-89.76000213623,44.340000152588),
					Use	=	true,
					Pos1	=	Vector(-29.469999313354,-89.080001831055,45.090000152588),
					Pos3	=	Vector(-30.10000038147,-92.26000213623,43.310001373291),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-29.60000038147,-88.599998474121,43.659999847412),
				UseDynamic	=	true,
				ReverseColor	=	{
					r	=	255,
					b	=	255,
					a	=	255,
					g	=	255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-26.790000915527,-95.050003051758,42.659999847412),
					UseColor	=	true,
					Pos2	=	Vector(-31.459999084473,-88.589996337891,44.720001220703),
					Color	=	{
						r	=	255,
						b	=	253,
						a	=	255,
						g	=	255,
							},
					Use	=	true,
					Pos1	=	Vector(-29.219999313354,-87.790000915527,45.810001373291),
					Pos3	=	Vector(-30.35000038147,-93.550003051758,42.590000152588),
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Pos4	=	Vector(27.39999961853,-93.98999786377,42.900001525879),
					Pos2	=	Vector(30.370000839233,-89.870002746582,44.200000762939),
					Use	=	true,
					Pos1	=	Vector(29.229999542236,-89.190002441406,44.950000762939),
					Pos3	=	Vector(29.860000610352,-92.370002746582,43.169998168945),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(29.360000610352,-88.709999084473,43.520000457764),
				UseDynamic	=	true,
				ReverseColor	=	{
					r	=	255,
					b	=	255,
					a	=	255,
					g	=	255,
						},
				UseSprite	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(26.549999237061,-95.160003662109,42.520000457764),
					UseColor	=	true,
					Pos2	=	Vector(31.219999313354,-88.699996948242,44.580001831055),
					Color	=	{
						r	=	255,
						b	=	253,
						a	=	255,
						g	=	255,
							},
					Use	=	true,
					Pos1	=	Vector(28.979999542236,-87.900001525879,45.669998168945),
					Pos3	=	Vector(30.110000610352,-93.660003662109,42.450000762939),
						},
					},
				{
				Sprite	=	{
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	253,
					a	=	255,
					g	=	255,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner_Size	=	1,
				UseSprite	=	true,
				Pos	=	Vector(-35.720001220703,87.419998168945,32.729999542236),
				UseDynamic	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	253,
					a	=	255,
					g	=	255,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
				UseSprite	=	true,
				Pos	=	Vector(36.229999542236,87.199996948242,32.549999237061),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.07,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					AmountV	=	5,
					Pos4	=	Vector(1.2999999523163,-104.19999694824,13.680000305176),
					Mid_Full	=	true,
					Pos2	=	Vector(-2.2000000476837,-104.69999694824,17.780000686646),
					AmountH	=	5,
					Use	=	true,
					Pos1	=	Vector(1.7999999523163,-104.69999694824,17.780000686646),
					Pos3	=	Vector(-1.7000000476837,-104.19999694824,13.680000305176),
						},
				UseDynamic	=	true,
				RenderHD_Size	=	1.7,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	100,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4607,
						},
				FogColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-0.20000000298023,-105.11000061035,15.869999885559),
				RenderInner	=	true,
				UseFog	=	true,
				UseSprite	=	true,
				RenderInner_Size	=	3,
				RenderHD_Adv	=	true,
					},
				{
				RenderMLCenter	=	true,
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-38.189998626709,95.300003051758,19.89999961853),
				Sprite	=	{
					Size	=	0.2,
						},
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	3,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-35.520000457764,96.910003662109,19.75),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Beta_Inner3D	=	true,
					},
				{
				RenderMLCenter	=	true,
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(38.689998626709,95.199996948242,19.709999084473),
				Sprite	=	{
					Size	=	0.2,
						},
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	3,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(36.020000457764,96.809997558594,19.559999465942),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	0,
								g	=	0,
									},
								},
							},
						},
				RenderInner	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseSprite	=	true,
					},
				{
				RenderMLCenter	=	true,
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-34.099998474121,97.709999084473,19.670000076294),
				Sprite	=	{
					Size	=	0.2,
						},
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	3,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-30.739999771118,99.379997253418,19.530000686646),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Size	=	1,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Beta_Inner3D	=	true,
					},
				{
				RenderMLCenter	=	true,
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(34.599998474121,97.610000610352,19.510000228882),
				Sprite	=	{
					Size	=	0.2,
						},
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	3,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(31.239999771118,99.279998779297,19.370000839233),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Size	=	1,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					Size	=	0.1,
						},
				UseBrake	=	true,
				DD_HD	=	true,
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	200,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderHD_Adv	=	true,
				Pos	=	Vector(-32.810001373291,-84.279998779297,45.279998779297),
				SpecSpin	=	{
						},
				RenderInner	=	true,
				RenderInner_Size	=	1,
				Beta_Inner3D	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					Size	=	0.1,
						},
				UseBrake	=	true,
				DD_HD	=	true,
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	200,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(32.580001831055,-84.449996948242,45.119998931885),
				UseSprite	=	true,
				RenderInner	=	true,
				SpecSpin	=	{
						},
				RenderHD_Adv	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Size	=	1,
					},
				{
				Sprite	=	{
					Size	=	0.12,
						},
				UseBrake	=	true,
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	200,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderHD_Adv	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-33.430000305176,-93.160003662109,38.220001220703),
				RenderInner	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	2,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-32.189998626709,-94.639999389648,38.220001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseSprite	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecSpin	=	{
						},
					},
				{
				Sprite	=	{
					Size	=	0.12,
						},
				UseBrake	=	true,
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	200,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				RenderHD_Adv	=	true,
				Pos	=	Vector(33.150001525879,-93.300003051758,38.060001373291),
				RenderInner_Size	=	1,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	2,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(31.909999847412,-94.779998779297,38.060001373291),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecSpin	=	{
						},
					},
				{
				Sprite	=	{
					Size	=	0.12,
						},
				UseBrake	=	true,
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	200,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-28.510000228882,-97.080001831055,38.299999237061),
				RenderInner	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	4,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-24.690000534058,-98.360000610352,38.380001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderHD_Adv	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					Size	=	0.12,
						},
				UseBrake	=	true,
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	200,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				RenderHD_Adv	=	true,
				Pos	=	Vector(28.180000305176,-97.199996948242,38.159999847412),
				RenderInner	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	4,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(24.360000610352,-98.480003356934,38.240001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					Size	=	0.12,
						},
				UseBrake	=	true,
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	200,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				RenderHD_Adv	=	true,
				Pos	=	Vector(-30.940000534058,-95.629997253418,38.240001678467),
				RenderInner_Size	=	1,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	2,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-29.719999313354,-96.610000610352,38.25),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecSpin	=	{
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.12,
						},
				UseBrake	=	true,
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	200,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				UseSprite	=	true,
				Pos	=	Vector(30.659999847412,-95.76000213623,38.090000152588),
				RenderInner_Size	=	1,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	2,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(29.440000534058,-96.73999786377,38.099998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderHD_Adv	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					Size	=	0.01,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Pos4	=	Vector(-14.630000114441,17.209999084473,45.680000305176),
					Pos2	=	Vector(-14.550000190735,17.190000534058,45.549999237061),
					Use	=	true,
					Pos1	=	Vector(-14.640000343323,17.200000762939,45.549999237061),
					Pos3	=	Vector(-14.539999961853,17.190000534058,45.680000305176),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				IsInterior	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-14.529999732971,17.159999847412,45.569999694824),
				UseBlinkers	=	true,
				BlinkersColor	=	{
					r	=	55,
					b	=	0,
					a	=	255,
					g	=	255,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/indicator_single",
					Pos4	=	Vector(-14.35000038147,17.159999847412,45.270000457764),
					UseColor	=	true,
					Pos2	=	Vector(-14.829999923706,17.239999771118,45.959999084473),
					Color	=	{
						r	=	55,
						b	=	0,
						a	=	255,
						g	=	255,
							},
					Use	=	true,
					Pos1	=	Vector(-14.35000038147,17.190000534058,45.959999084473),
					Pos3	=	Vector(-14.829999923706,17.200000762939,45.270000457764),
						},
				BlinkerRight	=	true,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.01,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Pos4	=	Vector(-22.39999961853,17.229999542236,45.709999084473),
					Pos2	=	Vector(-22.479999542236,17.209999084473,45.580001831055),
					Use	=	true,
					Pos1	=	Vector(-22.389999389648,17.219999313354,45.580001831055),
					Pos3	=	Vector(-22.489999771118,17.209999084473,45.709999084473),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				IsInterior	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-22.5,17.180000305176,45.599998474121),
				UseBlinkers	=	true,
				Beta_Inner3D	=	true,
				BlinkersColor	=	{
					r	=	55,
					b	=	0,
					a	=	255,
					g	=	255,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/indicator_single",
					Pos4	=	Vector(-22.680000305176,17.180000305176,45.299999237061),
					UseColor	=	true,
					Pos2	=	Vector(-22.200000762939,17.260000228882,45.990001678467),
					Color	=	{
						r	=	55,
						b	=	0,
						a	=	255,
						g	=	255,
							},
					Use	=	true,
					Pos1	=	Vector(-22.680000305176,17.209999084473,45.990001678467),
					Pos3	=	Vector(-22.200000762939,17.219999313354,45.299999237061),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.1,
						},
				UseBrake	=	true,
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2.1,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(32.729999542236,-94.180000305176,39.619998931885),
				RenderInner	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	5,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(29.889999389648,-94.540000915527,39.630001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderHD_Adv	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecSpin	=	{
						},
					},
				{
				Sprite	=	{
					Size	=	0.5,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-29.60000038147,-88.599998474121,43.659999847412),
				RenderInner	=	true,
				ReverseColor	=	{
					r	=	255,
					b	=	255,
					a	=	255,
					g	=	255,
						},
				Beta_Inner3D	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	0,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					Size	=	0.5,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(29.360000610352,-88.709999084473,43.520000457764),
				RenderInner	=	true,
				ReverseColor	=	{
					r	=	255,
					b	=	255,
					a	=	255,
					g	=	255,
						},
				Beta_Inner3D	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	0,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
				UseSprite	=	true,
				Pos	=	Vector(-27.780000686646,-93.800003051758,41.110000610352),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				Beta_Inner3D	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	0,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(27.489999771118,-93.940002441406,40.970001220703),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
				Beta_Inner3D	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	0,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.6,
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(32.290000915527,86.809997558594,34),
				RenderInner	=	true,
				SpecMat	=	{
						},
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.6,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-31.75,86.970001220703,34.150001525879),
				RenderInner_Size	=	1,
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				},
		Copyright	=	"Copyright © 2012-2017 VCMod (freemmaann). All Rights Reserved.",
		Fuel	=	{
			FuelLidPos	=	Vector(39.270000457764,-73.910003662109,41.580001831055),
			FuelLidUse	=	true,
			FuelType	=	0,
			Capacity	=	72,
			FuelTypeUse	=	true,
			Override	=	true,
				},
		Author	=	"CгεερεгƬv (76561198051637331)",
}