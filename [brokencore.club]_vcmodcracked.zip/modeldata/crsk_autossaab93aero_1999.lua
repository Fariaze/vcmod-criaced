VCModels['models/crsk_autossaab93aero_1999.mdl']	=	{
		Light_DD_Int	=	true,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Date	=	"05/10/17 22:24:43",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-23.229999542236,-106.48000335693,15.569999694824),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		Copyright	=	"Copyright © 2012-2017 VCMod (freemmaann). All Rights Reserved.",
		ExtraSeats	=	{
				{
				Pos	=	Vector(17.450000762939,12.270000457764,27.129999160767),
					},
				{
				Pos	=	Vector(17.450000762939,-31.479999542236,27.129999160767),
					},
				{
				Pos	=	Vector(-17.450000762939,-31.479999542236,27.129999160767),
					},
				{
				Pos	=	Vector(-1.9199999570847,-31.479999542236,27.129999160767),
					},
				},
		DLT	=	3491062910,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-27.459999084473,-102.54000091553,42.139999389648),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseRunning	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(27.459999084473,-102.54000091553,42.139999389648),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseRunning	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-19.340000152588,-102.54000091553,42.139999389648),
				UseDynamic	=	true,
				RenderInner	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(19.340000152588,-102.54000091553,42.139999389648),
				UseDynamic	=	true,
				RenderInner	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-24.049999237061,-102.54000091553,38.380001068115),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	4,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-31.479999542236,-101.36000061035,38.549999237061),
								},
							},
						},
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(24.049999237061,-102.54000091553,38.380001068115),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	4,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(31.479999542236,-101.36000061035,38.549999237061),
								},
							},
						},
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-18.420000076294,-102.54000091553,38.400001525879),
				UseDynamic	=	true,
				RenderInner	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(18.420000076294,-102.54000091553,38.400001525879),
				UseDynamic	=	true,
				RenderInner	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				UseBlinkers	=	true,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				RenderInner	=	true,
				SpecMat	=	{
						},
				Pos	=	Vector(-40.439998626709,49.220001220703,27.440000534058),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				UseBlinkers	=	true,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				RenderInner	=	true,
				SpecMat	=	{
						},
				Pos	=	Vector(40.439998626709,49.220001220703,27.440000534058),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				UseBlinkers	=	true,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				RenderInner	=	true,
				SpecMat	=	{
						},
				Pos	=	Vector(35.689998626709,90.580001831055,31.680000305176),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				UseBlinkers	=	true,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				RenderInner	=	true,
				SpecMat	=	{
						},
				Pos	=	Vector(-35.689998626709,90.580001831055,31.680000305176),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UsePrjTex	=	true,
				Pos	=	Vector(33.25,97.900001525879,31.680000305176),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner	=	true,
				LBeamColor	=	{
						255,
						175,
						100,
						},
				UseSprite	=	true,
				HBeamColor	=	{
						255,
						175,
						100,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UsePrjTex	=	true,
				Pos	=	Vector(-33.25,97.900001525879,31.680000305176),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseHighBeams	=	true,
				LBeamColor	=	{
						255,
						175,
						100,
						},
				UseSprite	=	true,
				HBeamColor	=	{
						255,
						175,
						100,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(24.729999542236,104.01000213623,31.680000305176),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseRunning	=	true,
				RunningColor	=	{
						255,
						175,
						100,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-24.729999542236,104.01000213623,31.680000305176),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseRunning	=	true,
				RunningColor	=	{
						255,
						175,
						100,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				FogColor	=	{
						255,
						175,
						100,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(26.770000457764,105.93000030518,14.729999542236),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseFog	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				FogColor	=	{
						255,
						175,
						100,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-26.770000457764,105.93000030518,14.729999542236),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseFog	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				},
		em_state	=	5236594365,
		Fuel	=	{
			FuelLidPos	=	Vector(37.659999847412,-74.940002441406,44.200000762939),
			FuelType	=	0,
			Capacity	=	64,
			FuelLidUse	=	true,
			Override	=	true,
				},
		Author	=	"CrushingSkirmish (76561198017348899)",
}