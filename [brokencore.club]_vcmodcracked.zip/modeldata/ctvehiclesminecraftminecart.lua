VCModels['models/ctvehiclesminecraftminecart.mdl']	=	{
		em_state	=	5236594545,
		Date	=	"Sun Aug 11 14:23:12 2019",
		NoRadio	=	true,
		Copyright	=	"Copyright © 2012-2019 VCMod (freemmaann). All Rights Reserved.",
		NoDoorSound	=	true,
		HealthDisabled	=	true,
		NoHorn	=	true,
		DLT	=	3491063030,
		Fuel	=	{
			Disabled	=	true,
				},
		Author	=	"𝓒𝓣𝓥 (76561198051637331)",
}