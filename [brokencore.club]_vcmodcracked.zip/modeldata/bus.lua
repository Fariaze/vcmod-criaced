VCModels['models/bus.mdl']	=	{
		IsBig	=	true,
		Light_DD_Int	=	true,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Date	=	"10/09/15 22:53:26",
		Exhaust	=	{
				{
				Ang	=	Angle(30,-90,0),
				Pos	=	Vector(44.540000915527,-144.83000183105,27.889999389648),
				EffectStress	=	"VC_Exhaust_Truck_Stress",
				EffectIdle	=	"VC_Exhaust_Truck",
					},
				},
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				FogColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-34.479999542236,-166,73.099998474121),
				UseDynamic	=	true,
				UseBrake	=	true,
				UseFog	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Pos	=	Vector(-45.490001678467,-165.99000549316,73.099998474121),
				UseSprite	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(-31.889999389648,-165.97999572754,125.63999938965),
				UseDynamic	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1.2,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				Pos	=	Vector(-44.680000305176,-165.7799987793,125.63999938965),
				UseSprite	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				Pos	=	Vector(-7.6999998092651,-165.82000732422,131.52000427246),
				UseSprite	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				Pos	=	Vector(0,-166.03999328613,131.52000427246),
				UseSprite	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				FogColor	=	{
						220,
						225,
						255,
						},
				UseSprite	=	true,
				Pos	=	Vector(-45.080001831055,178.17999267578,57.729999542236),
				UseDynamic	=	true,
				UseFog	=	true,
				ProjTexture	=	{
					Size	=	2000,
					Angle	=	Angle(0,90,0),
						},
				UsePrjTex	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				SpecSpin	=	{
						},
				UseHead	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-44.819999694824,177.74000549316,57.729999542236),
				UseDynamic	=	true,
				HeadColor	=	{
						223,
						190,
						255,
						},
				ProjTexture	=	{
					Forward	=	30,
					Size	=	2000,
					Angle	=	Angle(0,90,0),
						},
				UsePrjTex	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				Pos	=	Vector(6.6799998283386,109.45999908447,137.50999450684),
				UseSprite	=	true,
				RunningColor	=	{
						226.25,
						252.16,
						236.5,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				Pos	=	Vector(0,109.88999938965,137.69000244141),
				UseSprite	=	true,
				RunningColor	=	{
						211.56,
						242.77,
						229.56,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(-32.680000305176,108.73000335693,128.5),
				UseDynamic	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1.2,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Pos	=	Vector(-42.630001068115,109.0299987793,127.51999664307),
				UseSprite	=	true,
				RunningColor	=	{
						216.62,
						188.43,
						191.33,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				FogColor	=	{
						255,
						55,
						0,
						},
				UseBrake	=	true,
				UseSprite	=	true,
				Pos	=	Vector(34.479999542236,-166,73.099998474121),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseFog	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Pos	=	Vector(45.490001678467,-165.99000549316,73.099998474121),
				UseSprite	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(31.889999389648,-165.97999572754,125.63999938965),
				UseDynamic	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1.2,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				Pos	=	Vector(44.680000305176,-165.7799987793,125.63999938965),
				UseSprite	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				Pos	=	Vector(7.6999998092651,-165.82000732422,131.52000427246),
				UseSprite	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				FogColor	=	{
						220,
						225,
						255,
						},
				UseSprite	=	true,
				Pos	=	Vector(45.080001831055,178.17999267578,57.729999542236),
				UseDynamic	=	true,
				UseFog	=	true,
				ProjTexture	=	{
					Size	=	2000,
					Angle	=	Angle(0,90,0),
						},
				UsePrjTex	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				SpecSpin	=	{
						},
				UseHead	=	true,
				UseSprite	=	true,
				Pos	=	Vector(44.819999694824,177.74000549316,57.729999542236),
				UseDynamic	=	true,
				HeadColor	=	{
						223,
						190,
						255,
						},
				ProjTexture	=	{
					Forward	=	30,
					Size	=	2000,
					Angle	=	Angle(0,90,0),
						},
				UsePrjTex	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				Pos	=	Vector(-6.6799998283386,109.45999908447,137.50999450684),
				UseSprite	=	true,
				RunningColor	=	{
						226.25,
						252.16,
						236.5,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(32.680000305176,108.73000335693,128.5),
				UseDynamic	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1.2,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Pos	=	Vector(42.630001068115,109.0299987793,127.51999664307),
				UseSprite	=	true,
				RunningColor	=	{
						216.62,
						188.43,
						191.33,
						},
				UseRunning	=	true,
					},
				},
		Copyright	=	"DurkaTeam @ 2025 No rights reserved",
		ExtraSeats	=	{
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(30,-141.19000244141,86.209999084473),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(-30,-141.19000244141,86.209999084473),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(0,-141.19000244141,86.209999084473),
				RadioControl	=	true,
					},
				},
		DLT	=	3491063118,
		Sound_Airbrake	=	true,
		em_state	=	5236594677,
		Sound_Backup	=	true,
		Author	=	"freemmaann (76561197989323181)",
}