VCModels['models/crsk_autosavtovaz2106.mdl']	=	{
		em_state	=	5236594761,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		HealthEnginePosOvr	=	true,
		Date	=	"Sat Apr 13 22:44:46 2019",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(11.470000267029,-98.199996948242,12.25),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust_Truck",
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(19,0,0),
				Pos	=	Vector(15.550000190735,14.550000190735,29.159999847412),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(22,0,0),
				Pos	=	Vector(-19.239999771118,-20.620000839233,31.940000534058),
					},
				{
				Ang	=	Angle(22,0,0),
				Pos	=	Vector(18.920000076294,-20.620000839233,31.940000534058),
					},
				{
				Ang	=	Angle(22,0,0),
				Pos	=	Vector(1.0499999523163,-20.620000839233,31.940000534058),
					},
				},
		HealthEnginePos	=	Vector(2.0899999141693,65.860000610352,36.979999542236),
		DLT	=	3491063174,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				Pos	=	Vector(-29.979999542236,85.73999786377,23.879999160767),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				Pos	=	Vector(30.39999961853,85.73999786377,23.879999160767),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseBlinkers	=	true,
				Pos	=	Vector(-35.950000762939,81.040000915527,32.619998931885),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseBlinkers	=	true,
				Pos	=	Vector(36.290000915527,81.040000915527,32.619998931885),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMLine	=	{
					Amount	=	3,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(28.469999313354,-94.410003662109,29.700000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.479999542236,-94.110000610352,27.709999084473),
								},
							},
						},
				UseBlinkers	=	true,
				Pos	=	Vector(28.520000457764,-94.519996643066,31.360000610352),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMLine	=	{
					Amount	=	3,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-28.729999542236,-94.410003662109,29.700000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.739999771118,-94.110000610352,27.709999084473),
								},
							},
						},
				UseBlinkers	=	true,
				Pos	=	Vector(-28.780000686646,-94.519996643066,31.360000610352),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				UseRunning	=	true,
				SpecMLine	=	{
					Amount	=	3,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(18.290000915527,-95.480003356934,29.809999465942),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(18.299999237061,-95.180000305176,27.819999694824),
								},
							},
						},
				UseSprite	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				Pos	=	Vector(18.340000152588,-95.589996337891,31.469999313354),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				UseRunning	=	true,
				SpecMLine	=	{
					Amount	=	3,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-18.840000152588,-95.480003356934,29.780000686646),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-18.85000038147,-95.180000305176,27.790000915527),
								},
							},
						},
				UseSprite	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				Pos	=	Vector(-18.889999389648,-95.589996337891,31.440000534058),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				UseBrake	=	true,
				SpecMLine	=	{
					Amount	=	3,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-21.969999313354,-94.870002746582,31.739999771118),
								},
							},
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(-25.690000534058,-94.599998474121,31.680000305176),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				UseBrake	=	true,
				SpecMLine	=	{
					Amount	=	3,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(21.25,-94.870002746582,31.739999771118),
								},
							},
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(24.969999313354,-94.599998474121,31.680000305176),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseReverse	=	true,
				ReverseColor	=	{
						255,
						225,
						255,
						},
				SpecMLine	=	{
					Amount	=	3,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-21.930000305176,-94.699996948242,29.569999694824),
								},
							},
						},
				UseDynamic	=	true,
				Pos	=	Vector(-25.64999961853,-94.430000305176,29.510000228882),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseReverse	=	true,
				ReverseColor	=	{
						255,
						225,
						255,
						},
				SpecMLine	=	{
					Amount	=	3,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(21.299999237061,-94.790000915527,29.569999694824),
								},
							},
						},
				UseDynamic	=	true,
				Pos	=	Vector(25.020000457764,-94.519996643066,29.510000228882),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	3,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-21.870000839233,-94.480003356934,27.819999694824),
								},
							},
						},
				FogColor	=	{
						255,
						85,
						55,
						},
				UseFog	=	true,
				Pos	=	Vector(-25.590000152588,-94.209999084473,27.760000228882),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	3,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(21.180000305176,-94.480003356934,27.819999694824),
								},
							},
						},
				FogColor	=	{
						255,
						85,
						55,
						},
				UseFog	=	true,
				Pos	=	Vector(24.89999961853,-94.209999084473,27.760000228882),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(-23.60000038147,84.910003662109,26.840000152588),
					UseColor	=	true,
					Pos2	=	Vector(-31.799999237061,84.709999084473,34.680000305176),
					Color	=	{
						r	=	220,
						b	=	140,
						a	=	255,
						g	=	170,
							},
					Use	=	true,
					Pos1	=	Vector(-23.489999771118,84.709999084473,34.689998626709),
					Pos3	=	Vector(-31.709999084473,84.709999084473,26.870000839233),
						},
				HBeamColor	=	{
					r	=	220,
					b	=	140,
					a	=	255,
					g	=	170,
						},
				UsePrjTex	=	true,
				Pos	=	Vector(-27.719999313354,84.709999084473,30.809999465942),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseSprite	=	true,
				SpecCircle	=	{
					Amount	=	4,
					Use	=	true,
					Radius	=	1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(-14.890000343323,85.279998779297,26.840000152588),
					UseColor	=	true,
					Pos2	=	Vector(-23.090000152588,85.080001831055,34.680000305176),
					Color	=	{
						r	=	220,
						b	=	140,
						a	=	255,
						g	=	170,
							},
					Use	=	true,
					Pos1	=	Vector(-14.779999732971,85.080001831055,34.689998626709),
					Pos3	=	Vector(-23,85.080001831055,26.870000839233),
						},
				UseSprite	=	true,
				Pos	=	Vector(-19.010000228882,85.080001831055,30.809999465942),
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	4,
					Use	=	true,
					Radius	=	1,
						},
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	220,
					b	=	140,
					a	=	255,
					g	=	170,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(15.449999809265,85.180000305176,26.840000152588),
					UseColor	=	true,
					Pos2	=	Vector(23.64999961853,84.980003356934,34.680000305176),
					Color	=	{
						r	=	220,
						b	=	140,
						a	=	255,
						g	=	170,
							},
					Use	=	true,
					Pos1	=	Vector(15.340000152588,84.980003356934,34.689998626709),
					Pos3	=	Vector(23.559999465942,84.980003356934,26.870000839233),
						},
				UsePrjTex	=	true,
				Pos	=	Vector(19.569999694824,84.980003356934,30.809999465942),
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	4,
					Use	=	true,
					Radius	=	1,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				LBeamColor	=	{
					r	=	220,
					b	=	140,
					a	=	255,
					g	=	170,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(24.25,84.690002441406,26.840000152588),
					UseColor	=	true,
					Pos2	=	Vector(32.450000762939,84.48999786377,34.680000305176),
					Color	=	{
						r	=	220,
						b	=	140,
						a	=	255,
						g	=	170,
							},
					Use	=	true,
					Pos1	=	Vector(24.139999389648,84.48999786377,34.689998626709),
					Pos3	=	Vector(32.360000610352,84.48999786377,26.870000839233),
						},
				HBeamColor	=	{
					r	=	220,
					b	=	140,
					a	=	255,
					g	=	170,
						},
				UsePrjTex	=	true,
				Pos	=	Vector(28.370000839233,84.48999786377,30.809999465942),
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	4,
					Use	=	true,
					Radius	=	1,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseSprite	=	true,
				UseHighBeams	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				UseSprite	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				Pos	=	Vector(26.89999961853,85.73999786377,23.879999160767),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				UseSprite	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				Pos	=	Vector(-26.479999542236,85.73999786377,23.879999160767),
					},
				},
		Copyright	=	"Copyright © 2012-2019 VCMod (freemmaann). All Rights Reserved.",
		Fuel	=	{
			FuelLidPos	=	Vector(37,-67.769996643066,34.880001068115),
			FuelLidUse	=	true,
			FuelType	=	0,
			Capacity	=	39,
			Override	=	true,
			FuelTypeUse	=	true,
				},
		Author	=	"CrushingSkirmish (76561198017348899)",
}