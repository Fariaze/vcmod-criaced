VCModels['models/azok30peugeot_208_gti.mdl']	=	{
		em_state	=	5236594485,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Date	=	"Sun Nov 18 01:45:11 2018",
		Exhaust	=	{
				{
				Ang	=	Angle(15,-90,0),
				Pos	=	Vector(18.180000305176,-78.389999389648,3.0999999046326),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(16.969999313354,16.520000457764,23.690000534058),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(-18.520000457764,-19.25,25.290000915527),
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(18.520000457764,-19.25,25.290000915527),
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(0.5,-20.299999237061,25.559999465942),
					},
				},
		DLT	=	3491062990,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				UseBlinkers	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-32.650001525879,75.339996337891,31.049999237061),
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	5,
					Use	=	true,
					Ang	=	Angle(0,45,0),
					Radius	=	1,
						},
				RenderInner_Size	=	1,
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				RenderInner	=	true,
				RenderInner_Size	=	1,
				UseSprite	=	true,
				Pos	=	Vector(32.650001525879,75.339996337891,31.049999237061),
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	5,
					Use	=	true,
					Ang	=	Angle(0,135,0),
					Radius	=	1,
						},
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-26.590000152588,86.800003051758,28.85000038147),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	17,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-27.909999847412,82.800003051758,30.340000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-29.420000076294,78.800003051758,31.829999923706),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(26.590000152588,86.800003051758,28.85000038147),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	17,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(27.909999847412,82.800003051758,30.340000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(29.420000076294,78.800003051758,31.829999923706),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(-27.459999084473,85.449996948242,24.969999313354),
					Pos2	=	Vector(-32.299999237061,85.449996948242,29.809999465942),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-27.459999084473,85.449996948242,29.809999465942),
					Pos3	=	Vector(-32.299999237061,85.449996948242,24.969999313354),
						},
				SpecMat	=	{
						},
				UsePrjTex	=	true,
				Pos	=	Vector(-29.879999160767,85.449996948242,27.389999389648),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				HBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(27.459999084473,85.449996948242,24.969999313354),
					Pos2	=	Vector(32.299999237061,85.449996948242,29.809999465942),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(27.459999084473,85.449996948242,29.809999465942),
					Pos3	=	Vector(32.299999237061,85.449996948242,24.969999313354),
						},
				SpecMat	=	{
						},
				UsePrjTex	=	true,
				Pos	=	Vector(29.879999160767,85.449996948242,27.389999389648),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				HBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(-26.620000839233,91.279998779297,25.879999160767),
					Pos2	=	Vector(-24.60000038147,91.459999084473,23.879999160767),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-26.620000839233,91.279998779297,23.879999160767),
					Pos3	=	Vector(-24.60000038147,91.459999084473,25.879999160767),
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-25.610000610352,91.370002746582,24.879999160767),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(26.620000839233,91.279998779297,25.879999160767),
					Pos2	=	Vector(24.60000038147,91.459999084473,23.879999160767),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(26.620000839233,91.279998779297,23.879999160767),
					Pos3	=	Vector(24.60000038147,91.459999084473,25.879999160767),
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(25.610000610352,91.370002746582,24.879999160767),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(-26.790000915527,93.209999084473,4.9800000190735),
					Pos2	=	Vector(-31.729999542236,93.209999084473,9.9200000762939),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-26.790000915527,93.209999084473,9.9200000762939),
					Pos3	=	Vector(-31.729999542236,93.209999084473,4.9800000190735),
						},
				FogColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-29.260000228882,93.209999084473,7.4499998092651),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseFog	=	true,
				RenderInner_Size	=	4,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(26.790000915527,93.209999084473,4.9800000190735),
					Pos2	=	Vector(31.729999542236,93.209999084473,9.9200000762939),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(26.790000915527,93.209999084473,9.9200000762939),
					Pos3	=	Vector(31.729999542236,93.209999084473,4.9800000190735),
						},
				FogColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(29.260000228882,93.209999084473,7.4499998092651),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseFog	=	true,
				RenderInner_Size	=	4,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_Size	=	1,
				UseSprite	=	true,
				Pos	=	Vector(-24.159999847412,-68.459999084473,31.39999961853),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	72,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-24.940000534058,-67.98999786377,32.290000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-25.860000610352,-67.470001220703,33.290000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-26.840000152588,-66.699996948242,34.200000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-27.889999389648,-65.919998168945,35.049999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-28.770000457764,-65.319999694824,35.630001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-29.690000534058,-64.559997558594,36.049999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-30.639999389648,-63.759998321533,36.450000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-31.670000076294,-62.709999084473,36.680000305176),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-25.770000457764,-68.459999084473,31.340000152588),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	72,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-26.469999313354,-67.809997558594,32.229999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-27.340000152588,-67.099998474121,33.229999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-28.270000457764,-66.279998779297,34.139999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-29.229999542236,-65.430000305176,34.990001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-30.090000152588,-64.629997253418,35.569999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-30.860000610352,-63.900001525879,35.990001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-31.860000610352,-62.709999084473,36.330001831055),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_Size	=	1,
				UseSprite	=	true,
				Pos	=	Vector(-27.190000534058,-68.339996337891,31.329999923706),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	72,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-27.739999771118,-67.76000213623,32.220001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-28.459999084473,-66.980003356934,33.220001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-29.360000610352,-66.080001831055,34.090000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-30.299999237061,-65.110000610352,34.979999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-31.129999160767,-64.220001220703,35.560001373291),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-31.940000534058,-63.189998626709,35.979999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					Use	=	true,
					Mid	=	true,
					AmountH	=	2,
					Pos1	=	Vector(-23.840000152588,-68.650001525879,30.709999084473),
					AmountV	=	2,
					Mid_V	=	true,
					Pos2	=	Vector(-24.200000762939,-68.650001525879,30.709999084473),
					Pos4	=	Vector(-23.840000152588,-68.650001525879,30.35000038147),
					Mid_Full	=	true,
					Pos3	=	Vector(-24.200000762939,-68.650001525879,30.35000038147),
						},
				SpecMat	=	{
						},
				UseRunning	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-24.020000457764,-68.650001525879,30.530000686646),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					Pos4	=	Vector(-25.440000534058,-68.430000305176,30.35000038147),
					Mid	=	true,
					AmountH	=	2,
					Pos1	=	Vector(-25.440000534058,-68.430000305176,30.709999084473),
					AmountV	=	2,
					Mid_V	=	true,
					Pos2	=	Vector(-25.799999237061,-68.430000305176,30.709999084473),
					Use	=	true,
					Mid_Full	=	true,
					Pos3	=	Vector(-25.799999237061,-68.430000305176,30.35000038147),
						},
				SpecMat	=	{
						},
				UseRunning	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-25.620000839233,-68.430000305176,30.530000686646),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					Use	=	true,
					Mid	=	true,
					AmountH	=	2,
					Pos1	=	Vector(-26.989999771118,-68.25,30.709999084473),
					AmountV	=	2,
					Mid_V	=	true,
					Pos2	=	Vector(-27.35000038147,-68.25,30.709999084473),
					Pos4	=	Vector(-26.989999771118,-68.25,30.35000038147),
					Mid_Full	=	true,
					Pos3	=	Vector(-27.35000038147,-68.25,30.35000038147),
						},
				SpecMat	=	{
						},
				UseRunning	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-27.170000076294,-68.25,30.530000686646),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					Pos4	=	Vector(-28.459999084473,-67.790000915527,30.35000038147),
					Mid	=	true,
					AmountH	=	2,
					Pos1	=	Vector(-28.459999084473,-67.790000915527,30.709999084473),
					AmountV	=	2,
					Mid_V	=	true,
					Pos2	=	Vector(-28.819999694824,-67.790000915527,30.709999084473),
					Use	=	true,
					Mid_Full	=	true,
					Pos3	=	Vector(-28.819999694824,-67.790000915527,30.35000038147),
						},
				SpecMat	=	{
						},
				UseRunning	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-28.639999389648,-67.790000915527,30.530000686646),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					Use	=	true,
					Mid	=	true,
					AmountH	=	2,
					Pos1	=	Vector(-29.799999237061,-67.110000610352,30.709999084473),
					AmountV	=	2,
					Mid_V	=	true,
					Pos2	=	Vector(-30.159999847412,-67.110000610352,30.709999084473),
					Pos4	=	Vector(-29.799999237061,-67.110000610352,30.35000038147),
					Mid_Full	=	true,
					Pos3	=	Vector(-30.159999847412,-67.110000610352,30.35000038147),
						},
				SpecMat	=	{
						},
				UseRunning	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-29.979999542236,-67.110000610352,30.530000686646),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					Pos4	=	Vector(-31.209999084473,-66.110000610352,30.35000038147),
					Mid	=	true,
					AmountH	=	2,
					Pos1	=	Vector(-31.209999084473,-66.110000610352,30.709999084473),
					AmountV	=	2,
					Mid_V	=	true,
					Pos2	=	Vector(-31.569999694824,-66.110000610352,30.709999084473),
					Use	=	true,
					Mid_Full	=	true,
					Pos3	=	Vector(-31.569999694824,-66.110000610352,30.35000038147),
						},
				SpecMat	=	{
						},
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseSprite	=	true,
				Pos	=	Vector(-31.389999389648,-66.110000610352,30.530000686646),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.55,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.55,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-30.959999084473,-64.660003662109,33.669998168945),
				UseDynamic	=	true,
				RenderInner	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(-28.479999542236,-68.620002746582,29.780000686646),
					Pos2	=	Vector(-33.599998474121,-62.380001068115,35.569999694824),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-28.89999961853,-65.459999084473,33.689998626709),
					Pos3	=	Vector(-32.759998321533,-64.480003356934,31.610000610352),
						},
				RenderInner_Size	=	4,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(-29.159999847412,-68.660003662109,28.209999084473),
					Pos2	=	Vector(-33.409999847412,-63.759998321533,31.479999542236),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-29.35000038147,-66.23999786377,30.370000839233),
					Pos3	=	Vector(-33.209999084473,-65.26000213623,28.290000915527),
						},
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-31.409999847412,-65.440002441406,30.35000038147),
				UseDynamic	=	true,
				RenderInner_Size	=	4,
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(24.159999847412,-68.459999084473,31.39999961853),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	72,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(24.940000534058,-67.98999786377,32.290000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(25.860000610352,-67.470001220703,33.290000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(26.840000152588,-66.699996948242,34.200000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(27.889999389648,-65.919998168945,35.049999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(28.770000457764,-65.319999694824,35.630001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(29.690000534058,-64.559997558594,36.049999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(30.639999389648,-63.759998321533,36.450000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(31.670000076294,-62.709999084473,36.680000305176),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_Size	=	1,
				UseSprite	=	true,
				Pos	=	Vector(25.770000457764,-68.459999084473,31.340000152588),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	72,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(26.469999313354,-67.809997558594,32.229999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(27.340000152588,-67.099998474121,33.229999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(28.270000457764,-66.279998779297,34.139999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(29.229999542236,-65.430000305176,34.990001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(30.090000152588,-64.629997253418,35.569999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(30.860000610352,-63.900001525879,35.990001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(31.860000610352,-62.709999084473,36.330001831055),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(27.190000534058,-68.339996337891,31.329999923706),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	72,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(27.739999771118,-67.76000213623,32.220001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(28.459999084473,-66.980003356934,33.220001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(29.360000610352,-66.080001831055,34.090000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(30.299999237061,-65.110000610352,34.979999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(31.129999160767,-64.220001220703,35.560001373291),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(31.940000534058,-63.189998626709,35.979999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					Pos4	=	Vector(23.840000152588,-68.650001525879,30.35000038147),
					Mid	=	true,
					AmountH	=	2,
					Pos1	=	Vector(23.840000152588,-68.650001525879,30.709999084473),
					AmountV	=	2,
					Mid_V	=	true,
					Pos2	=	Vector(24.200000762939,-68.650001525879,30.709999084473),
					Use	=	true,
					Mid_Full	=	true,
					Pos3	=	Vector(24.200000762939,-68.650001525879,30.35000038147),
						},
				SpecMat	=	{
						},
				UseRunning	=	true,
				UseSprite	=	true,
				Pos	=	Vector(24.020000457764,-68.650001525879,30.530000686646),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					Use	=	true,
					Mid	=	true,
					AmountH	=	2,
					Pos1	=	Vector(25.440000534058,-68.430000305176,30.709999084473),
					AmountV	=	2,
					Mid_V	=	true,
					Pos2	=	Vector(25.799999237061,-68.430000305176,30.709999084473),
					Pos4	=	Vector(25.440000534058,-68.430000305176,30.35000038147),
					Mid_Full	=	true,
					Pos3	=	Vector(25.799999237061,-68.430000305176,30.35000038147),
						},
				SpecMat	=	{
						},
				UseRunning	=	true,
				UseSprite	=	true,
				Pos	=	Vector(25.620000839233,-68.430000305176,30.530000686646),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					Pos4	=	Vector(26.989999771118,-68.25,30.35000038147),
					Mid	=	true,
					AmountH	=	2,
					Pos1	=	Vector(26.989999771118,-68.25,30.709999084473),
					AmountV	=	2,
					Mid_V	=	true,
					Pos2	=	Vector(27.35000038147,-68.25,30.709999084473),
					Use	=	true,
					Mid_Full	=	true,
					Pos3	=	Vector(27.35000038147,-68.25,30.35000038147),
						},
				SpecMat	=	{
						},
				UseRunning	=	true,
				UseSprite	=	true,
				Pos	=	Vector(27.170000076294,-68.25,30.530000686646),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					Use	=	true,
					Mid	=	true,
					AmountH	=	2,
					Pos1	=	Vector(28.459999084473,-67.790000915527,30.709999084473),
					AmountV	=	2,
					Mid_V	=	true,
					Pos2	=	Vector(28.819999694824,-67.790000915527,30.709999084473),
					Pos4	=	Vector(28.459999084473,-67.790000915527,30.35000038147),
					Mid_Full	=	true,
					Pos3	=	Vector(28.819999694824,-67.790000915527,30.35000038147),
						},
				SpecMat	=	{
						},
				UseRunning	=	true,
				UseSprite	=	true,
				Pos	=	Vector(28.639999389648,-67.790000915527,30.530000686646),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					Pos4	=	Vector(29.799999237061,-67.110000610352,30.35000038147),
					Mid	=	true,
					AmountH	=	2,
					Pos1	=	Vector(29.799999237061,-67.110000610352,30.709999084473),
					AmountV	=	2,
					Mid_V	=	true,
					Pos2	=	Vector(30.159999847412,-67.110000610352,30.709999084473),
					Use	=	true,
					Mid_Full	=	true,
					Pos3	=	Vector(30.159999847412,-67.110000610352,30.35000038147),
						},
				SpecMat	=	{
						},
				UseRunning	=	true,
				UseSprite	=	true,
				Pos	=	Vector(29.979999542236,-67.110000610352,30.530000686646),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					Use	=	true,
					Mid	=	true,
					AmountH	=	2,
					Pos1	=	Vector(31.209999084473,-66.110000610352,30.709999084473),
					AmountV	=	2,
					Mid_V	=	true,
					Pos2	=	Vector(31.569999694824,-66.110000610352,30.709999084473),
					Pos4	=	Vector(31.209999084473,-66.110000610352,30.35000038147),
					Mid_Full	=	true,
					Pos3	=	Vector(31.569999694824,-66.110000610352,30.35000038147),
						},
				SpecMat	=	{
						},
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseSprite	=	true,
				Pos	=	Vector(31.389999389648,-66.110000610352,30.530000686646),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.55,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(28.479999542236,-68.620002746582,29.780000686646),
					Pos2	=	Vector(33.599998474121,-62.380001068115,35.569999694824),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(28.89999961853,-65.459999084473,33.689998626709),
					Pos3	=	Vector(32.759998321533,-64.480003356934,31.610000610352),
						},
				SpecMat	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				Dynamic	=	{
					Size	=	0.55,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(30.959999084473,-64.660003662109,33.669998168945),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderInner_Size	=	4,
				UseBlinkers	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(29.159999847412,-68.660003662109,28.209999084473),
					Pos2	=	Vector(33.409999847412,-63.759998321533,31.479999542236),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(29.35000038147,-66.23999786377,30.370000839233),
					Pos3	=	Vector(33.209999084473,-65.26000213623,28.290000915527),
						},
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(31.409999847412,-65.440002441406,30.35000038147),
				UseDynamic	=	true,
				RenderInner_Size	=	4,
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				UseBrake	=	true,
				RenderInner_Size	=	1,
				UseSprite	=	true,
				Pos	=	Vector(-10.590000152588,-56.200000762939,52.020000457764),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	40,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(9.710000038147,-56.270000457764,52.029998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseBrake	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-24.159999847412,-68.190002441406,29.579999923706),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-24.75,-68.190002441406,28.719999313354),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-25.5,-68.23999786377,27.809999465942),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-26.25,-68.279998779297,27.010000228882),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-26.940000534058,-68.300003051758,26.270000457764),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-25.520000457764,-68.059997558594,29.540000915527),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-25.920000076294,-68.129997253418,28.829999923706),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-26.450000762939,-68.199996948242,28.090000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-26.950000762939,-68.190002441406,27.39999961853),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-27.829999923706,-68.150001525879,26.450000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseBrake	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-26.670000076294,-67.819999694824,29.540000915527),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-27.010000228882,-67.889999389648,28.909999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-27.450000762939,-67.959999084473,28.280000686646),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-27.870000839233,-67.949996948242,27.709999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-28.700000762939,-67.879997253418,26.739999771118),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				UseBrake	=	true,
				RenderInner_Size	=	1,
				UseSprite	=	true,
				Pos	=	Vector(10.590000152588,-56.200000762939,52.020000457764),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	40,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-9.710000038147,-56.270000457764,52.029998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(24.159999847412,-68.190002441406,29.579999923706),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(24.75,-68.190002441406,28.719999313354),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(25.5,-68.23999786377,27.809999465942),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(26.25,-68.279998779297,27.010000228882),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(26.940000534058,-68.300003051758,26.270000457764),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(25.520000457764,-68.059997558594,29.540000915527),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(25.920000076294,-68.129997253418,28.829999923706),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(26.450000762939,-68.199996948242,28.090000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(26.950000762939,-68.190002441406,27.39999961853),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(27.829999923706,-68.150001525879,26.450000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(26.670000076294,-67.819999694824,29.540000915527),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(27.010000228882,-67.889999389648,28.909999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(27.450000762939,-67.959999084473,28.280000686646),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(27.870000839233,-67.949996948242,27.709999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(28.700000762939,-67.879997253418,26.739999771118),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				},
		Copyright	=	"Copyright © 2012-2018 VCMod (freemmaann). All Rights Reserved.",
		Fuel	=	{
			FuelType	=	0,
				},
		Author	=	"Azok30 (76561198183398967)",
}