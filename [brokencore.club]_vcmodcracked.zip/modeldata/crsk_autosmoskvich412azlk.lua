VCModels['models/crsk_autosmoskvich412azlk.mdl']	=	{
		em_state	=	5236594437,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Date	=	"Wed Jul 26 15:06:46 2017",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(19.719999313354,-107.48000335693,14.659999847412),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust_Truck",
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(17,0,0),
				Pos	=	Vector(14.39999961853,9.6499996185303,36.340000152588),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(17,0,0),
				Pos	=	Vector(-21.159999847412,-33.930000305176,36.340000152588),
					},
				{
				Ang	=	Angle(17,0,0),
				Pos	=	Vector(21.159999847412,-33.930000305176,36.340000152588),
					},
				{
				Ang	=	Angle(17,0,0),
				Pos	=	Vector(0,-33.930000305176,36.340000152588),
					},
				},
		DLT	=	3491062958,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				SpecRec	=	{
					AmountV	=	2,
					Pos4	=	Vector(-24.920000076294,-111.19000244141,30.680000305176),
					Pos2	=	Vector(-19.190000534058,-111.19000244141,34.819999694824),
					AmountH	=	6,
					Use	=	true,
					Pos1	=	Vector(-23.479999542236,-111.19000244141,34.849998474121),
					Pos3	=	Vector(-19.260000228882,-111.19000244141,30.770000457764),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-21.35000038147,-111.09999847412,32.790000915527),
				UseDynamic	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				Beta_Inner3D	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-24.420000076294,-111.19000244141,30.530000686646),
					UseColor	=	true,
					Pos2	=	Vector(-18.799999237061,-111.19000244141,34.860000610352),
					Color	=	{
							200,
							225,
							255,
							},
					Use	=	true,
					Pos1	=	Vector(-24.280000686646,-111.19000244141,34.860000610352),
					Pos3	=	Vector(-18.799999237061,-111.19000244141,30.579999923706),
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5.1742,
					Size	=	0.12,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Pos4	=	Vector(-31.879999160767,-110.45999908447,37.029998779297),
					AmountV	=	4,
					Pos2	=	Vector(-34.939998626709,-110.45999908447,39.840000152588),
					AmountH	=	3,
					Use	=	true,
					Pos1	=	Vector(-31.879999160767,-110.45999908447,39.919998168945),
					Pos3	=	Vector(-34.939998626709,-110.45999908447,36.950000762939),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-33.409999847412,-110.45999908447,38.560001373291),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.3358,
					Brightness	=	1.8284,
						},
				BlinkersColor	=	{
						200,
						125,
						0,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.12,
						},
				SpecSpin	=	{
						},
				Beta_Inner3D	=	true,
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Pos4	=	Vector(-28.299999237061,-111.29000091553,30.059999465942),
					AmountV	=	4,
					Pos2	=	Vector(-31.360000610352,-111.29000091553,34.799999237061),
					AmountH	=	3,
					Use	=	true,
					Pos1	=	Vector(-28.299999237061,-111.29000091553,34.090000152588),
					Pos3	=	Vector(-31.360000610352,-111.29000091553,31.120000839233),
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBrake	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-29.829999923706,-111.29000091553,32.729999542236),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseRunning	=	true,
				BrakeColor	=	{
						200,
						0,
						0,
						},
				RunningColor	=	{
						200,
						0,
						0,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-28.299999237061,-111.29000091553,30.469999313354),
					UseColor	=	true,
					Pos2	=	Vector(-31.360000610352,-111.29000091553,34.799999237061),
					Color	=	{
							255,
							155,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(-28.299999237061,-111.29000091553,34.799999237061),
					Pos3	=	Vector(-31.360000610352,-111.29000091553,30.469999313354),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-34.680000305176,96.059997558594,24.25),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				UseSprite	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.12,
						},
				SpecSpin	=	{
						},
				RunningColor	=	{
						255,
						195,
						120,
						},
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Pos4	=	Vector(-27.979999542236,96.059997558594,22.690000534058),
					AmountV	=	4,
					Pos2	=	Vector(-31.670000076294,96.059997558594,25.5),
					AmountH	=	3,
					Use	=	true,
					Pos1	=	Vector(-28.610000610352,96.059997558594,25.579999923706),
					Pos3	=	Vector(-32.279998779297,96.059997558594,22.610000610352),
						},
				Beta_Inner3D	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-27.719999313354,96.059997558594,22.690000534058),
					UseColor	=	true,
					Pos2	=	Vector(-32.290000915527,96.059997558594,25.75),
					Color	=	{
							225,
							225,
							155,
							},
					Use	=	true,
					Pos1	=	Vector(-27.719999313354,96.059997558594,25.75),
					Pos3	=	Vector(-32.290000915527,96.059997558594,22.690000534058),
						},
				UseSprite	=	true,
				Pos	=	Vector(-30.139999389648,96.059997558594,24.219999313354),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
						255,
						225,
						200,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/stadium_2x6",
					Pos4	=	Vector(-23.020000457764,96.639999389648,26.379999160767),
					UseColor	=	true,
					Pos2	=	Vector(-33.430000305176,97.400001525879,35.75),
					Color	=	{
							225,
							225,
							155,
							},
					Use	=	true,
					Pos1	=	Vector(-23.309999465942,97.150001525879,35.650001525879),
					Pos3	=	Vector(-33.389999389648,96.690002441406,26.200000762939),
						},
				SpecMat	=	{
						},
				HBeamColor	=	{
						255,
						225,
						155,
						},
				UsePrjTex	=	true,
				LBeamColor	=	{
						255,
						225,
						155,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				Pos	=	Vector(-28.360000610352,97.160003662109,30.840000152588),
				UseSprite	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5.1742,
					Size	=	0.12,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Pos4	=	Vector(31.879999160767,-110.45999908447,37.029998779297),
					AmountV	=	4,
					Pos2	=	Vector(34.939998626709,-110.45999908447,39.840000152588),
					AmountH	=	3,
					Use	=	true,
					Pos1	=	Vector(31.879999160767,-110.45999908447,39.919998168945),
					Pos3	=	Vector(34.939998626709,-110.45999908447,36.950000762939),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(33.409999847412,-110.45999908447,38.560001373291),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				Beta_Inner3D	=	true,
				Dynamic	=	{
					Size	=	0.3358,
					Brightness	=	1.8284,
						},
				BlinkersColor	=	{
						200,
						125,
						0,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.12,
						},
				SpecSpin	=	{
						},
				UseBrake	=	true,
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Pos4	=	Vector(27.940000534058,-111.29000091553,29.889999389648),
					AmountV	=	4,
					Pos2	=	Vector(31,-111.29000091553,34.630001068115),
					AmountH	=	3,
					Use	=	true,
					Pos1	=	Vector(27.940000534058,-111.29000091553,33.919998168945),
					Pos3	=	Vector(31,-111.29000091553,30.950000762939),
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				UseSprite	=	true,
				Pos	=	Vector(29.469999313354,-111.29000091553,32.560001373291),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseRunning	=	true,
				BrakeColor	=	{
						200,
						0,
						0,
						},
				RunningColor	=	{
						200,
						0,
						0,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(27.940000534058,-111.29000091553,30.299999237061),
					UseColor	=	true,
					Pos2	=	Vector(31,-111.29000091553,34.630001068115),
					Color	=	{
							255,
							155,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(27.940000534058,-111.29000091553,34.630001068115),
					Pos3	=	Vector(31,-111.29000091553,30.299999237061),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(34.680000305176,96.059997558594,24.25),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				Beta_Inner3D	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.12,
						},
				SpecSpin	=	{
						},
				RunningColor	=	{
						255,
						195,
						120,
						},
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Pos4	=	Vector(28.389999389648,96.059997558594,22.510000228882),
					AmountV	=	4,
					Pos2	=	Vector(32.080001831055,96.059997558594,25.319999694824),
					AmountH	=	3,
					Use	=	true,
					Pos1	=	Vector(29.020000457764,96.059997558594,25.39999961853),
					Pos3	=	Vector(32.689998626709,96.059997558594,22.430000305176),
						},
				Beta_Inner3D	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(28.129999160767,96.059997558594,22.510000228882),
					UseColor	=	true,
					Pos2	=	Vector(32.700000762939,96.059997558594,25.569999694824),
					Color	=	{
							225,
							225,
							155,
							},
					Use	=	true,
					Pos1	=	Vector(28.129999160767,96.059997558594,25.569999694824),
					Pos3	=	Vector(32.700000762939,96.059997558594,22.510000228882),
						},
				UseSprite	=	true,
				Pos	=	Vector(30.549999237061,96.059997558594,24.040000915527),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
						255,
						225,
						200,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/stadium_2x6",
					Pos4	=	Vector(23.200000762939,96.639999389648,26.379999160767),
					UseColor	=	true,
					Pos2	=	Vector(33.610000610352,97.400001525879,35.75),
					Color	=	{
							225,
							225,
							155,
							},
					Use	=	true,
					Pos1	=	Vector(23.489999771118,97.150001525879,35.650001525879),
					Pos3	=	Vector(33.569999694824,96.690002441406,26.200000762939),
						},
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UsePrjTex	=	true,
				LBeamColor	=	{
						255,
						225,
						155,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				HBeamColor	=	{
						255,
						225,
						155,
						},
				Pos	=	Vector(28.540000915527,97.160003662109,30.840000152588),
				UseSprite	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-37.659999847412,42.950000762939,42.990001678467),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				UseSprite	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(38.25,42.759998321533,42.939998626709),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				UseSprite	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				SpecRec	=	{
					AmountV	=	2,
					Pos4	=	Vector(24.139999389648,-111.19000244141,30.680000305176),
					Pos2	=	Vector(18.409999847412,-111.19000244141,34.819999694824),
					AmountH	=	6,
					Use	=	true,
					Pos1	=	Vector(22.700000762939,-111.19000244141,34.849998474121),
					Pos3	=	Vector(18.479999542236,-111.19000244141,30.770000457764),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(20.569999694824,-111.09999847412,32.790000915527),
				UseDynamic	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				UseSprite	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(23.639999389648,-111.19000244141,30.530000686646),
					UseColor	=	true,
					Pos2	=	Vector(18.020000457764,-111.19000244141,34.860000610352),
					Color	=	{
							200,
							225,
							255,
							},
					Use	=	true,
					Pos1	=	Vector(23.5,-111.19000244141,34.860000610352),
					Pos3	=	Vector(18.020000457764,-111.19000244141,30.579999923706),
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
					},
				},
		Copyright	=	"Copyright © 2012-2017 VCMod (freemmaann). All Rights Reserved.",
		Fuel	=	{
			FuelLidPos	=	Vector(26.739999771118,-96.930000305176,42.650001525879),
			FuelType	=	0,
			Capacity	=	46,
			Override	=	true,
			FuelLidUse	=	true,
				},
		Author	=	"CrushingSkirmish (76561198017348899)",
}