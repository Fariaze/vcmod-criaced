-- DurkaTeam @ 2025 Никакие права не защищены

include('shared.lua')

ENT.RenderGroup = RENDERGROUP_BOTH

function ENT:Initialize() self.VC_PVsb = util.GetPixelVisibleHandle() end

local ID = "Fuel_station"
function ENT:Draw(...) if VC and VC.CodeEnt[ID] and VC.CodeEnt[ID].Draw then return VC.CodeEnt[ID].Draw(self, ...) end end