VCModels['models/crsk_autosaudis5_2017.mdl']	=	{
		em_state	=	5236595052,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		HealthEnginePosOvr	=	true,
		Date	=	"Mon Jan 15 17:29:35 2018",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-29.629999160767,-105.29000091553,15.090000152588),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(29.139999389648,-105.29000091553,15.090000152588),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(24.059999465942,-106.2200012207,15.090000152588),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-24.889999389648,-106.2200012207,15.090000152588),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(19,0,0),
				Pos	=	Vector(16.760000228882,4.0599999427795,28.120000839233),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(19,0,0),
				Pos	=	Vector(16.760000228882,-31.920000076294,28.209999084473),
					},
				{
				Ang	=	Angle(19,0,0),
				Pos	=	Vector(-18.770000457764,-31.110000610352,28.209999084473),
					},
				{
				Ang	=	Angle(19,0,0),
				Pos	=	Vector(0,-31.989999771118,28.209999084473),
					},
				},
		HealthEnginePos	=	Vector(0,74.389999389648,40.569999694824),
		DLT	=	3491063368,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.0609,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-36.799999237061,88.449996948242,33.380001068115),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	54,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-22.450000762939,99.419998168945,31.120000839233),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.0325,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseRunning	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-35.590000152588,-93.959999084473,36.639999389648),
				UseDynamic	=	true,
				UseBrake	=	true,
				SpecMLine	=	{
					Amount	=	92,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-36.040000915527,-92.059997558594,40.869998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.889999389648,-97.029998779297,40.869998931885),
								},
							{
							Pos	=	Vector(-27.809999465942,-100.55999755859,40.869998931885),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.0978,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
				UseBrake	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-7.3299999237061,-63.150001525879,44.630001068115),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	31,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(7.4899997711182,-63.720001220703,44.630001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.0609,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				DD_Blnk_Run	=	true,
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(37.270000457764,89.519996643066,30.489999771118),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	54,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(37.110000610352,88.410003662109,33.169998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	0,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(23.35000038147,99.650001525879,31.110000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.0325,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(35.590000152588,-93.940002441406,36.639999389648),
				UseDynamic	=	true,
				UseBrake	=	true,
				SpecMLine	=	{
					Amount	=	92,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(36.040000915527,-92.040000915527,40.869998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.889999389648,-97.01000213623,40.869998931885),
								},
							{
							Pos	=	Vector(27.809999465942,-100.54000091553,40.869998931885),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.0325,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(27.129999160767,-100.83000183105,37.229999542236),
				UseDynamic	=	true,
				UseBrake	=	true,
				SpecMLine	=	{
					Amount	=	61,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(30.889999389648,-98.930000305176,37.240001678467),
								},
							{
							Pos	=	Vector(33.110000610352,-97.089996337891,37.169998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.03,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(27.639999389648,-101.12000274658,40.180000305176),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	61,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(32.450000762939,-98.279998779297,40.240001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.04,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(18.610000610352,-102.76999664307,38.209999084473),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	83,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(25.329999923706,-101.38999938965,38.029998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.290000915527,-101.5299987793,37.080001831055),
								},
							{
							Pos	=	Vector(18.909999847412,-102.76000213623,38.159999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.025,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(15.619999885559,-104.66999816895,40.819999694824),
				UseDynamic	=	true,
				UseBrake	=	true,
				SpecMLine	=	{
					Amount	=	83,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(27.069999694824,-101.13999938965,40.970001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.025,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(15.090000152588,-103.98000335693,40.040000915527),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	83,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(26.430000305176,-102.05000305176,40.139999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.025,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseReverse	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(17.159999847412,-104.29000091553,39.529998779297),
				UseDynamic	=	true,
				ReverseColor	=	{
					r	=	200,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
				SpecMLine	=	{
					Amount	=	83,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(21.319999694824,-102.91999816895,39.419998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.03,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-41.270000457764,28.270000457764,44.849998474121),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	54,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-45.159999847412,26.360000610352,45.009998321533),
								},
							{
							Pos	=	Vector(-47.009998321533,24.110000610352,45),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	0,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-47.549999237061,21.270000457764,44.939998626709),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.03,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(42.580001831055,27.819999694824,44.580001831055),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	54,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(45.470001220703,25.889999389648,44.659999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(47.319999694824,23.639999389648,44.770000457764),
								},
							{
							Pos	=	Vector(47.860000610352,20.799999237061,44.770000457764),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/stadium_2x4",
					Pos4	=	Vector(-32.209999084473,89.089996337891,29.620000839233),
					Pos2	=	Vector(-36.290000915527,89.089996337891,32.220001220703),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-32.290000915527,89.089996337891,32.299999237061),
					Pos3	=	Vector(-36.279998779297,89.089996337891,29.690000534058),
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				ReducedVis	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseHighBeams	=	true,
				SpecMat	=	{
						},
				Pos	=	Vector(-34.299999237061,89.089996337891,30.979999542236),
				Beta_Inner3D	=	true,
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.0609,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				DD_Blnk_Run	=	true,
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-36.930000305176,89.519996643066,30.489999771118),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	54,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-36.770000457764,88.410003662109,33.169998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	0,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-22.690000534058,99.650001525879,31.110000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.0609,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(37.020000457764,88.449996948242,33.169998168945),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	54,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(22.670000076294,99.419998168945,30.909999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.0325,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-27.209999084473,-100.83000183105,37.229999542236),
				UseDynamic	=	true,
				UseBrake	=	true,
				SpecMLine	=	{
					Amount	=	61,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-30.969999313354,-98.930000305176,37.240001678467),
								},
							{
							Pos	=	Vector(-33.189998626709,-97.089996337891,37.169998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.03,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-27.920000076294,-100.70999908447,40.180000305176),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	61,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-32.729999542236,-97.870002746582,40.240001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.025,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-15.859999656677,-104.45999908447,40.819999694824),
				UseDynamic	=	true,
				UseBrake	=	true,
				SpecMLine	=	{
					Amount	=	83,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-27.309999465942,-100.93000030518,40.970001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.025,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-15.579999923706,-103.98000335693,40.040000915527),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	83,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-26.920000076294,-102.05000305176,40.139999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.025,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseReverse	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-17.159999847412,-104.29000091553,39.529998779297),
				UseDynamic	=	true,
				ReverseColor	=	{
					r	=	200,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
				SpecMLine	=	{
					Amount	=	83,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-21.319999694824,-102.91999816895,39.419998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.04,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-18.610000610352,-102.76999664307,38.209999084473),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	83,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-25.329999923706,-101.38999938965,38.029998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.290000915527,-101.5299987793,37.080001831055),
								},
							{
							Pos	=	Vector(-18.909999847412,-102.76000213623,38.159999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/stadium_2x4",
					Pos4	=	Vector(-27.110000610352,95.209999084473,28.940000534058),
					Pos2	=	Vector(-31.139999389648,95.209999084473,31.590000152588),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-27.090000152588,95.209999084473,31.60000038147),
					Pos3	=	Vector(-31.129999160767,95.230003356934,28.870000839233),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseHighBeams	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-29.14999961853,95.209999084473,30.25),
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/stadium_2x4",
					Pos4	=	Vector(32.759998321533,88.930000305176,29.479999542236),
					Pos2	=	Vector(36.840000152588,88.930000305176,32.080001831055),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(32.840000152588,88.930000305176,32.159999847412),
					Pos3	=	Vector(36.799999237061,88.930000305176,29.469999313354),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseHighBeams	=	true,
				Pos	=	Vector(34.849998474121,88.930000305176,30.840000152588),
				Beta_Inner3D	=	true,
				UseSprite	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/stadium_2x4",
					Pos4	=	Vector(27.64999961853,95.059997558594,28.770000457764),
					Pos2	=	Vector(31.680000305176,95.059997558594,31.420000076294),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(27.629999160767,95.059997558594,31.430000305176),
					Pos3	=	Vector(31.670000076294,95.080001831055,28.700000762939),
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseHighBeams	=	true,
				Pos	=	Vector(29.690000534058,95.059997558594,30.079999923706),
				Beta_Inner3D	=	true,
				SpecMat	=	{
						},
					},
				},
		Copyright	=	"Copyright © 2012-2018 VCMod (freemmaann). All Rights Reserved.",
		Fuel	=	{
			FuelLidPos	=	Vector(38.849998474121,-63.099998474121,42.560001373291),
			Override	=	true,
			FuelType	=	0,
			Capacity	=	58,
			FuelLidUse	=	true,
			FuelTypeUse	=	true,
				},
		Author	=	"𝓒𝓣𝓥𝟏𝟐𝟐𝟓 (76561198051637331)",
}