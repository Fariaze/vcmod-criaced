VCModels['models/crsk_autosskodaoctavia_mk1_1999.mdl']	=	{
		em_state	=	5236594917,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Copyright	=	"Copyright © 2012-2018 VCMod (freemmaann). All Rights Reserved.",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(15.340000152588,-119.44000244141,12.699999809265),
				EffectIdle	=	"VC_Exhaust",
					},
				},
		Indication	=	{
			speedo_kmph	=	{
				max	=	1,
				pp	=	"vehicle_guage",
				min	=	0,
				top	=	240,
					},
			fuel	=	{
				max	=	1,
				pp	=	"fuel_needle",
				min	=	0,
				top	=	1,
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(16,0,0),
				Pos	=	Vector(16.870000839233,0.0099999997764826,31.559999465942),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(16,0,0),
				Pos	=	Vector(-20.139999389648,-39.220001220703,31.590000152588),
					},
				{
				Ang	=	Angle(16,0,0),
				Pos	=	Vector(20.139999389648,-39.220001220703,31.590000152588),
					},
				{
				Ang	=	Angle(16,0,0),
				Pos	=	Vector(0,-35.909999847412,31.579999923706),
					},
				},
		DLT	=	3491063278,
		Lights	=	{
				{
				UseRunning	=	true,
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
					Select	=	10,
					New	=	"models\crskautos\skoda\octavia_mk1_1999\gauges_on__spec_on",
					Use	=	true,
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Pos	=	Vector(-20.5,12.359999656677,45.880001068115),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-34.069999694824,79.199996948242,31.739999771118),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(34.610000610352,78.970001220703,31.489999771118),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-41.459999084473,31.709999084473,32.669998168945),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(41.529998779297,31.379999160767,32.509998321533),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/stadium_2x4_texture",
					Pos4	=	Vector(-27.889999389648,83.050003051758,35.110000610352),
					UseColor	=	true,
					Pos2	=	Vector(-15.439999580383,89.48999786377,26.930000305176),
					Color	=	{
						r	=	255,
						b	=	138,
						a	=	255,
						g	=	209,
							},
					Use	=	true,
					Pos1	=	Vector(-16.64999961853,85.480003356934,35.380001068115),
					Pos3	=	Vector(-27.5,86.25,27.39999961853),
						},
				HBeamColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				SpecMat	=	{
						},
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Pos	=	Vector(-21.60000038147,85.230003356934,31.170000076294),
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				UseSprite	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-33.220001220703,-117.01999664307,41.779998779297),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	11,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-26.75,-119.55000305176,41.680000305176),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(32.209999084473,-117.26000213623,41.810001373291),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	11,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(26.75,-120.58000183105,41.990001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-32.700000762939,-118.40000152588,44.689998626709),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	14,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-27.360000610352,-120.19000244141,44.430000305176),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(31.809999465942,-118.30999755859,45.040000915527),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	11,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(27.10000038147,-120.08000183105,44.830001831055),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(33.529998779297,-117.76000213623,36.209999084473),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	6,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(24.950000762939,-120.20999908447,36.209999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-33.729999542236,-117.98000335693,37.009998321533),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	9,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-25.110000610352,-119.68000030518,36.759998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseReverse	=	true,
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-33.299999237061,-117.90000152588,39.680000305176),
				UseDynamic	=	true,
				ReverseColor	=	{
					r	=	200,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				SpecMLine	=	{
					Amount	=	11,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-27.040000915527,-121.12000274658,39.639999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseReverse	=	true,
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(32.610000610352,-118.08999633789,39.560001373291),
				UseDynamic	=	true,
				ReverseColor	=	{
					r	=	200,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				SpecMLine	=	{
					Amount	=	11,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(26.719999313354,-121.12000274658,39.400001525879),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(-31.389999389648,82.980003356934,32.869998931885),
					UseColor	=	true,
					Pos2	=	Vector(-28.420000076294,83.01000213623,29.89999961853),
					Color	=	{
						r	=	220,
						b	=	206,
						a	=	255,
						g	=	225,
							},
					Use	=	true,
					Pos1	=	Vector(-28.409999847412,82.98999786377,32.889999389648),
					Pos3	=	Vector(-31.430000305176,83.099998474121,29.840000152588),
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-29.979999542236,82.980003356934,31.39999961853),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseInter	=	true,
				InterColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				SpecMat	=	{
					Select	=	26,
					New	=	"models\crskautos\skoda\octavia_mk1_1999\newinterlight_on",
					Use	=	true,
						},
				IsInterior	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-2.7699999809265,-4.1500000953674,65.919998168945),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	8,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-2.8800001144409,-0.68000000715256,65.25),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.55,
					Brightness	=	1.1,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseInter	=	true,
				InterColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				SpecMat	=	{
					Select	=	26,
					New	=	"models\crskautos\skoda\octavia_mk1_1999\newinterlight_on",
					Use	=	true,
						},
				IsInterior	=	true,
				UseSprite	=	true,
				Pos	=	Vector(3.1900000572205,-4.1500000953674,65.919998168945),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	8,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(3.2999999523163,-0.68000000715256,65.25),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.55,
					Brightness	=	1.1,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				UseRunning	=	true,
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
					Select	=	17,
					New	=	"models\crskautos\skoda\octavia_mk1_1999\newwhitesped_on",
					Use	=	true,
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Pos	=	Vector(-14.819999694824,12.359999656677,45.880001068115),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(31.879999160767,82.879997253418,32.770000457764),
					UseColor	=	true,
					Pos2	=	Vector(28.909999847412,82.910003662109,29.799999237061),
					Color	=	{
						r	=	220,
						b	=	206,
						a	=	255,
						g	=	225,
							},
					Use	=	true,
					Pos1	=	Vector(28.89999961853,82.889999389648,32.790000915527),
					Pos3	=	Vector(31.920000076294,83,29.739999771118),
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(30.469999313354,82.879997253418,31.299999237061),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/stadium_2x4_texture",
					Pos4	=	Vector(28.510000228882,82.959999084473,35.110000610352),
					UseColor	=	true,
					Pos2	=	Vector(16.059999465942,89.400001525879,26.930000305176),
					Color	=	{
						r	=	255,
						b	=	138,
						a	=	255,
						g	=	209,
							},
					Use	=	true,
					Pos1	=	Vector(17.270000457764,85.389999389648,35.380001068115),
					Pos3	=	Vector(28.120000839233,86.160003662109,27.39999961853),
						},
				HBeamColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				UsePrjTex	=	true,
				Pos	=	Vector(22.219999313354,85.139999389648,31.170000076294),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				UseSprite	=	true,
				SpecMat	=	{
						},
				LBeamColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				},
		Date	=	"Sun Mar  4 21:04:21 2018",
		Fuel	=	{
			FuelLidPos	=	Vector(37.580001831055,-92.319999694824,43.5),
			FuelType	=	0,
			Capacity	=	55,
			FuelLidUse	=	true,
			Override	=	true,
				},
		Author	=	"CrushingSkirmish (76561198017348899)",
}