VCModels['models/clcarstoyotacorolla_2014.mdl']	=	{
		Seq_BlinkRate_Ovr	=	true,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		HealthEnginePosOvr	=	true,
		Date	=	"Sun Sep 30 16:16:34 2018",
		Copyright	=	"Copyright © 2012-2018 VCMod (freemmaann). All Rights Reserved.",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(27.299999237061,-111.26999664307,18.110000610352),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		em_state	=	5236594311,
		ExtraSeats	=	{
				{
				Ang	=	Angle(8,0,0),
				Pos	=	Vector(18.829999923706,9.1000003814697,31.5),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(-15.829999923706,-33.400001525879,31),
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(15.829999923706,-33.400001525879,31),
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(1.3300000429153,-33.400001525879,31),
					},
				},
		Seq_BlinkRate_On	=	0.34,
		HealthEnginePos	=	Vector(0,84,40),
		DLT	=	3491062874,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				inner_AsSpheres	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-27.790000915527,97.970001220703,34.220001220703),
				UseDynamic	=	true,
				RenderInner_Size	=	0.3,
				UseRunning	=	true,
				UseBlinkers	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				inner_AsSpheres	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				RenderInner_Size	=	0.3,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(27.760000228882,97.980003356934,34.220001220703),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseRunning	=	true,
				UseBlinkers	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(29.549999237061,96.519996643066,39.049999237061),
					UseColor	=	true,
					Pos2	=	Vector(33.209999084473,96.040000915527,35.389999389648),
					Color	=	{
						r	=	255,
						b	=	236,
						a	=	255,
						g	=	236,
							},
					Use	=	true,
					Pos1	=	Vector(29.549999237061,96.519996643066,35.389999389648),
					Pos3	=	Vector(33.209999084473,96.040000915527,39.049999237061),
						},
				SpecMat	=	{
						},
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	255,
					b	=	170,
					a	=	255,
					g	=	211,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseSprite	=	true,
				Pos	=	Vector(31.379999160767,96.279998779297,37.220001220703),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				SpecMat	=	{
						},
				RenderInner_Size	=	0.25,
				UseSprite	=	true,
				UsePrjTex	=	true,
				Pos	=	Vector(24.090000152588,100.83000183105,36),
				RenderInner	=	true,
				UseHighBeams	=	true,
				HBeamColor	=	{
					r	=	255,
					b	=	120,
					a	=	255,
					g	=	186,
						},
				inner_AsSpheres	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	240,
					a	=	255,
					g	=	240,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				SpecMat	=	{
						},
				RenderInner_Size	=	0.25,
				UseSprite	=	true,
				UsePrjTex	=	true,
				Pos	=	Vector(-24.090000152588,100.83000183105,35.959999084473),
				RenderInner	=	true,
				UseHighBeams	=	true,
				HBeamColor	=	{
					r	=	255,
					b	=	120,
					a	=	255,
					g	=	186,
						},
				inner_AsSpheres	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	240,
					a	=	255,
					g	=	240,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-29.530000686646,96.519996643066,39.020000457764),
					UseColor	=	true,
					Pos2	=	Vector(-33.189998626709,96.040000915527,35.360000610352),
					Color	=	{
						r	=	255,
						b	=	236,
						a	=	255,
						g	=	236,
							},
					Use	=	true,
					Pos1	=	Vector(-29.530000686646,96.519996643066,35.360000610352),
					Pos3	=	Vector(-33.189998626709,96.040000915527,39.020000457764),
						},
				SpecMat	=	{
						},
				UsePrjTex	=	true,
				Pos	=	Vector(-31.360000610352,96.279998779297,37.189998626709),
				UseSprite	=	true,
				LBeamColor	=	{
					r	=	255,
					b	=	170,
					a	=	255,
					g	=	211,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(36.049999237061,91.430000305176,38.799999237061),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-36.049999237061,91.379997253418,38.799999237061),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(29.549999237061,96.519996643066,39.049999237061),
					UseColor	=	true,
					Pos2	=	Vector(33.209999084473,96.040000915527,35.389999389648),
					Color	=	{
						r	=	255,
						b	=	236,
						a	=	255,
						g	=	236,
							},
					Use	=	true,
					Pos1	=	Vector(29.549999237061,96.519996643066,35.389999389648),
					Pos3	=	Vector(33.209999084473,96.040000915527,39.049999237061),
						},
				UseHighBeams	=	true,
				HBeamColor	=	{
					r	=	255,
					b	=	170,
					a	=	255,
					g	=	211,
						},
				Pos	=	Vector(31.379999160767,96.279998779297,37.220001220703),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				HBeamColor	=	{
					r	=	255,
					b	=	170,
					a	=	255,
					g	=	211,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-29.530000686646,96.519996643066,39.020000457764),
					UseColor	=	true,
					Pos2	=	Vector(-33.189998626709,96.040000915527,35.360000610352),
					Color	=	{
						r	=	255,
						b	=	236,
						a	=	255,
						g	=	236,
							},
					Use	=	true,
					Pos1	=	Vector(-29.530000686646,96.519996643066,35.360000610352),
					Pos3	=	Vector(-33.189998626709,96.040000915527,39.020000457764),
						},
				UseHighBeams	=	true,
				SpecMat	=	{
						},
				Pos	=	Vector(-31.360000610352,96.279998779297,37.189998626709),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				inner_AsSpheres	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner	=	true,
				SpecMat	=	{
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-33.020000457764,-107.76000213623,45.630001068115),
				UseDynamic	=	true,
				RenderInner_Size	=	0.4,
				UseBrake	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseBrake	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner	=	true,
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseRunning	=	true,
				UseSprite	=	true,
				Pos	=	Vector(33.020000457764,-107.76000213623,45.630001068115),
				UseDynamic	=	true,
				RenderInner_Size	=	0.4,
				inner_AsSpheres	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				UseBlinkers	=	true,
				inner_AsSpheres	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-32.139999389648,-105.09999847412,49.150001525879),
				UseDynamic	=	true,
				RenderInner_Size	=	0.5,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				UseBlinkers	=	true,
				RenderInner_Size	=	0.5,
				UseSprite	=	true,
				Pos	=	Vector(32.139999389648,-105.09999847412,49.150001525879),
				UseDynamic	=	true,
				RenderInner	=	true,
				inner_AsSpheres	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseReverse	=	true,
				SpecMat	=	{
						},
				inner_AsSpheres	=	true,
				RenderInner_Size	=	0.5,
				UseSprite	=	true,
				Pos	=	Vector(-24.270000457764,-109.5299987793,48.569999694824),
				UseDynamic	=	true,
				RenderInner	=	true,
				ReverseColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	236,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseReverse	=	true,
				SpecMat	=	{
						},
				inner_AsSpheres	=	true,
				RenderInner_Size	=	0.5,
				UseSprite	=	true,
				Pos	=	Vector(24.270000457764,-109.5299987793,48.569999694824),
				UseDynamic	=	true,
				RenderInner	=	true,
				ReverseColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	236,
					a	=	255,
					g	=	255,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-31.520000457764,101.09999847412,22.780000686646),
					UseColor	=	true,
					Pos2	=	Vector(-35.819999694824,98.699996948242,17.89999961853),
					Color	=	{
						r	=	255,
						b	=	236,
						a	=	255,
						g	=	236,
							},
					Use	=	true,
					Pos1	=	Vector(-31.520000457764,101.09999847412,17.89999961853),
					Pos3	=	Vector(-35.819999694824,98.699996948242,22.780000686646),
						},
				FogColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				SpecMat	=	{
						},
				UsePrjTex	=	true,
				Pos	=	Vector(-33.700000762939,98.849998474121,20.200000762939),
				UseFog	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(31.520000457764,101.09999847412,22.780000686646),
					UseColor	=	true,
					Pos2	=	Vector(35.819999694824,98.699996948242,17.89999961853),
					Color	=	{
						r	=	255,
						b	=	236,
						a	=	255,
						g	=	236,
							},
					Use	=	true,
					Pos1	=	Vector(31.520000457764,101.09999847412,17.89999961853),
					Pos3	=	Vector(35.819999694824,98.699996948242,22.780000686646),
						},
				FogColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				SpecMat	=	{
						},
				UsePrjTex	=	true,
				Pos	=	Vector(33.700000762939,98.849998474121,20.200000762939),
				UseFog	=	true,
				UseSprite	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				},
		Seq_BlinkRate_Off	=	0.34,
		Fuel	=	{
			FuelType	=	0,
			Capacity	=	49.967,
			Override	=	true,
				},
		Author	=	"𝓒𝓣𝓥 (76561198051637331)",
}