VCModels['models/azok30renault_twingo_1_limo.mdl']	=	{
		em_state	=	5236594884,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Copyright	=	"Copyright © 2012-2019 VCMod (freemmaann). All Rights Reserved.",
		Exhaust	=	{
				{
				Pos	=	Vector(18.799999237061,-144.61000061035,4.5),
				Invulnerable	=	true,
				EffectIdle	=	"VC_Exhaust",
				Ang	=	Angle(15,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(0,-180,0),
				Pos	=	Vector(-10.550000190735,4.3400001525879,22.079999923706),
					},
				{
				Ang	=	Angle(0,-180,0),
				Pos	=	Vector(10.550000190735,4.3400001525879,22.079999923706),
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(10.550000190735,-88.660003662109,22.079999923706),
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(15.949999809265,62.840000152588,21.579999923706),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(-10.550000190735,-88.660003662109,22.079999923706),
					},
				},
		DLT	=	3491063256,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseSprite	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				Pos	=	Vector(-23.770000457764,129.63000488281,24.569999694824),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				HBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UsePrjTex	=	true,
				Pos	=	Vector(-23.770000457764,129.63000488281,24.569999694824),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseSprite	=	true,
				Pos	=	Vector(-20.659999847412,135.10000610352,21.010000228882),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	44,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-27.670000076294,133.30999755859,20.920000076294),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				UseSprite	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Pos	=	Vector(23.770000457764,129.63000488281,24.569999694824),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				HBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseSprite	=	true,
				Pos	=	Vector(23.770000457764,129.63000488281,24.569999694824),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				UsePrjTex	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseSprite	=	true,
				Pos	=	Vector(20.659999847412,135.10000610352,21.010000228882),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	44,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(27.670000076294,133.30999755859,20.920000076294),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	10,
					Size	=	0.7,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseSprite	=	true,
				Pos	=	Vector(-30.579999923706,-140.58999633789,27.629999160767),
				UseDynamic	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(-28.409999847412,-141.14999389648,25.430000305176),
					Pos2	=	Vector(-32.75,-140.0299987793,29.829999923706),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-28.409999847412,-141.14999389648,29.829999923706),
					Pos3	=	Vector(-32.75,-140.0299987793,25.430000305176),
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	10,
					Size	=	0.7,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseSprite	=	true,
				Pos	=	Vector(30.579999923706,-140.58999633789,27.629999160767),
				UseDynamic	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(28.409999847412,-141.14999389648,25.430000305176),
					Pos2	=	Vector(32.75,-140.0299987793,29.829999923706),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(28.409999847412,-141.14999389648,29.829999923706),
					Pos3	=	Vector(32.75,-140.0299987793,25.430000305176),
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				UseSprite	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Pos	=	Vector(30.950000762939,-139.13000488281,32),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				UseSprite	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Pos	=	Vector(-30.950000762939,-139.13000488281,32),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseSprite	=	true,
				Pos	=	Vector(30.950000762939,-139.13000488281,23.079999923706),
				UseDynamic	=	true,
				RenderInner_Size	=	4,
				RenderInner	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				UseSprite	=	true,
				Pos	=	Vector(-30.950000762939,-139.13000488281,23.079999923706),
				UseDynamic	=	true,
				RenderInner_Size	=	4,
				RenderInner	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseReverse	=	true,
				Pos	=	Vector(30.950000762939,-139.13000488281,32),
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseDynamic	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				UseSprite	=	true,
					},
				},
		Date	=	"Sun Jun 16 02:04:11 2019",
		Fuel	=	{
			FuelType	=	0,
				},
		Author	=	"Azok30 - SWEETRP.FR (76561198183398967)",
}