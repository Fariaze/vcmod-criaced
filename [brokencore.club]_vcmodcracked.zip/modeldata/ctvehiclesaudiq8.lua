VCModels['models/ctvehiclesaudiq8.mdl']	=	{
		Seq_BlinkRate_Off	=	0.36,
		Seq_BlinkRate_Ovr	=	true,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		HealthEnginePosOvr	=	true,
		Date	=	"Tue Jan  7 18:22:22 2020",
		Copyright	=	"Copyright © 2012-2020 VCMod (freemmaann). All Rights Reserved.",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-34.75,-121.76999664307,23.489999771118),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(34.75,-121.76999664307,23.489999771118),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(6,0,0),
				Pos	=	Vector(19.639999389648,7.0599999427795,40.520000457764),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(7,0,0),
				Pos	=	Vector(-19.129999160767,-40.340000152588,43.819999694824),
					},
				{
				Ang	=	Angle(7,0,0),
				Pos	=	Vector(19.129999160767,-40.340000152588,43.819999694824),
					},
				{
				Ang	=	Angle(7,0,0),
				Pos	=	Vector(0.070000000298023,-40.340000152588,43.819999694824),
					},
				},
		Seq_BlinkRate_On	=	0.36,
		Light_DD_Int	=	true,
		HealthEnginePos	=	Vector(0,74,46),
		DLT	=	3491063016,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.03,
						},
				SpecMat	=	{
					Use	=	true,
					New	=	"models\ctvehicles\audi\q8\rear_running_on",
					Select	=	5,
						},
				RenderMLCenter	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-0.58999997377396,-122.75,55.470001220703),
				DD_Glow	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderGlow_Size	=	0,
				SpecMLine	=	{
					Amount	=	85,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-8.8500003814697,-122.5,55.439998626709),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-17.110000610352,-121.58999633789,55.430000305176),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-25.370000839233,-119.93000030518,55.400001525879),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-33.630001068115,-117.09999847412,55.299999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.03,
						},
				SpecMat	=	{
					Use	=	true,
					New	=	"models\ctvehicles\audi\q8\rear_running_on",
					Select	=	5,
						},
				RenderMLCenter	=	true,
				UseSprite	=	true,
				Pos	=	Vector(0.58999997377396,-122.75,55.470001220703),
				DD_Glow	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderGlow_Size	=	0,
				SpecMLine	=	{
					Amount	=	85,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(8.8500003814697,-122.5,55.439998626709),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(17.110000610352,-121.58999633789,55.430000305176),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(25.370000839233,-119.93000030518,55.400001525879),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(33.630001068115,-117.09999847412,55.299999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Pos	=	Vector(-24.790000915527,-117.81999969482,52.25),
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-24.719999313354,-119.44999694824,51.979999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-24.64999961853,-121.08000183105,50.779998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				SpecMat	=	{
					Use	=	true,
					New	=	"models\ctvehicles\audi\q8\rear_running_on",
					Select	=	5,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Pos	=	Vector(24.790000915527,-117.81999969482,52.25),
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(24.719999313354,-119.44999694824,51.979999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(24.64999961853,-121.08000183105,50.779998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				SpecMat	=	{
					Use	=	true,
					New	=	"models\ctvehicles\audi\q8\rear_running_on",
					Select	=	5,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Pos	=	Vector(-26.180000305176,-117.4700012207,52.25),
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseSprite	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-26.110000610352,-119.09999847412,51.979999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-25.989999771118,-120.73000335693,50.779998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				SpecMat	=	{
					Use	=	true,
					New	=	"models\ctvehicles\audi\q8\rear_running_on",
					Select	=	5,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Pos	=	Vector(26.180000305176,-117.4700012207,52.25),
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseSprite	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(26.110000610352,-119.09999847412,51.979999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(25.989999771118,-120.73000335693,50.779998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				SpecMat	=	{
					Use	=	true,
					New	=	"models\ctvehicles\audi\q8\rear_running_on",
					Select	=	5,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Pos	=	Vector(-27.680000305176,-117.05000305176,52.25),
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseSprite	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-27.559999465942,-118.68000030518,51.979999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-27.430000305176,-120.30999755859,50.779998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				SpecMat	=	{
					Use	=	true,
					New	=	"models\ctvehicles\audi\q8\rear_running_on",
					Select	=	5,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				SpecMat	=	{
					Use	=	true,
					New	=	"models\ctvehicles\audi\q8\rear_running_on",
					Select	=	5,
						},
				RenderMLCenter	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseSprite	=	true,
				Pos	=	Vector(-0.58999997377396,-122.75,55.380001068115),
				UseDynamic	=	true,
				seq_stay	=	true,
				SpecMLine	=	{
					Amount	=	155,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-8.8500003814697,-122.5,55.439998626709),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-17.110000610352,-121.58999633789,55.430000305176),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-25.370000839233,-119.93000030518,55.400001525879),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-33.630001068115,-117.09999847412,55.299999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-37.490001678467,-114.75,55.139999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-39.549999237061,-113,55.049999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-40.439998626709,-111.93000030518,54.959999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-41.340000152588,-110.84999847412,54.709999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-42.310001373291,-109.37000274658,53.479999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-43,-108.30999755859,52.25),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-44.229999542236,-106.4700012207,49.799999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				seq_use	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				SpecMat	=	{
					Use	=	true,
					New	=	"models\ctvehicles\audi\q8\rear_running_on",
					Select	=	5,
						},
				RenderMLCenter	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseSprite	=	true,
				Pos	=	Vector(0.58999997377396,-122.75,55.380001068115),
				UseDynamic	=	true,
				seq_stay	=	true,
				SpecMLine	=	{
					Amount	=	155,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(8.8500003814697,-122.5,55.439998626709),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(17.110000610352,-121.58999633789,55.430000305176),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(25.370000839233,-119.93000030518,55.400001525879),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(33.630001068115,-117.09999847412,55.299999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(37.490001678467,-114.75,55.139999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(39.549999237061,-113,55.049999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(40.439998626709,-111.93000030518,54.959999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(41.340000152588,-110.84999847412,54.709999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(42.310001373291,-109.37000274658,53.479999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(43,-108.30999755859,52.25),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(44.229999542236,-106.4700012207,49.799999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				seq_use	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.03,
						},
				SpecMat	=	{
					Use	=	true,
					New	=	"models\ctvehicles\audi\q8\rear_running_on",
					Select	=	5,
						},
				RenderMLCenter	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-34.5,-116.76000213623,55.299999237061),
				DD_Glow	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderGlow_Size	=	0,
				SpecMLine	=	{
					Amount	=	50,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-37.490001678467,-114.75,55.139999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-39.549999237061,-113,55.049999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-40.439998626709,-111.93000030518,54.959999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-41.340000152588,-110.84999847412,54.709999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-42.310001373291,-109.37000274658,53.479999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-43,-108.30999755859,52.25),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-44.229999542236,-106.4700012207,49.799999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.03,
						},
				SpecMat	=	{
					Use	=	true,
					New	=	"models\ctvehicles\audi\q8\rear_running_on",
					Select	=	5,
						},
				UseRunning	=	true,
				UseSprite	=	true,
				Pos	=	Vector(34.5,-116.76000213623,55.299999237061),
				DD_Glow	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				SpecMLine	=	{
					Amount	=	50,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(37.490001678467,-114.75,55.139999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(39.549999237061,-113,55.049999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(40.439998626709,-111.93000030518,54.959999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(41.340000152588,-110.84999847412,54.709999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(42.310001373291,-109.37000274658,53.479999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(43,-108.30999755859,52.25),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(44.229999542236,-106.4700012207,49.799999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderGlow_Size	=	0,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Pos	=	Vector(-29.120000839233,-116.65000152588,52.25),
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseSprite	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-29,-118.2799987793,51.979999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-28.870000839233,-119.91000366211,50.779998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				SpecMat	=	{
					Use	=	true,
					New	=	"models\ctvehicles\audi\q8\rear_running_on",
					Select	=	5,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Pos	=	Vector(29.120000839233,-116.65000152588,52.25),
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseSprite	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(29,-118.2799987793,51.979999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(28.870000839233,-119.91000366211,50.779998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				SpecMat	=	{
					Use	=	true,
					New	=	"models\ctvehicles\audi\q8\rear_running_on",
					Select	=	5,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Pos	=	Vector(-30.639999389648,-116.18000030518,52.25),
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseSprite	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-30.520000457764,-117.80999755859,51.979999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-30.389999389648,-119.44000244141,50.779998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				SpecMat	=	{
					Use	=	true,
					New	=	"models\ctvehicles\audi\q8\rear_running_on",
					Select	=	5,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Pos	=	Vector(30.639999389648,-116.18000030518,52.25),
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseSprite	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(30.520000457764,-117.80999755859,51.979999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(30.389999389648,-119.44000244141,50.779998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				SpecMat	=	{
					Use	=	true,
					New	=	"models\ctvehicles\audi\q8\rear_running_on",
					Select	=	5,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Pos	=	Vector(27.680000305176,-117.05000305176,52.25),
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseSprite	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(27.559999465942,-118.68000030518,51.979999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(27.430000305176,-120.30999755859,50.779998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				SpecMat	=	{
					Use	=	true,
					New	=	"models\ctvehicles\audi\q8\rear_running_on",
					Select	=	5,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Pos	=	Vector(-34.330001831055,-114.68000030518,52.25),
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseSprite	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-34.240001678467,-116.30999755859,51.979999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-34.159999847412,-117.94000244141,50.779998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				SpecMat	=	{
					Use	=	true,
					New	=	"models\ctvehicles\audi\q8\rear_running_on",
					Select	=	5,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Pos	=	Vector(32.200000762939,-115.73000335693,52.25),
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseSprite	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(32.080001831055,-117.36000061035,51.979999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(31.950000762939,-118.98999786377,50.779998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				SpecMat	=	{
					Use	=	true,
					New	=	"models\ctvehicles\audi\q8\rear_running_on",
					Select	=	5,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Pos	=	Vector(-32.200000762939,-115.73000335693,52.25),
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseSprite	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-32.080001831055,-117.36000061035,51.979999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-31.950000762939,-118.98999786377,50.779998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				SpecMat	=	{
					Use	=	true,
					New	=	"models\ctvehicles\audi\q8\rear_running_on",
					Select	=	5,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Pos	=	Vector(-35.900001525879,-114.05000305176,52.25),
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseSprite	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-35.849998474121,-115.68000030518,51.979999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-35.770000457764,-117.30999755859,50.779998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				SpecMat	=	{
					Use	=	true,
					New	=	"models\ctvehicles\audi\q8\rear_running_on",
					Select	=	5,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Pos	=	Vector(-37.459999084473,-112.88999938965,52.25),
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseSprite	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-37.409999847412,-114.51999664307,51.979999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-37.360000610352,-116.15000152588,50.779998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				SpecMat	=	{
					Use	=	true,
					New	=	"models\ctvehicles\audi\q8\rear_running_on",
					Select	=	5,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Pos	=	Vector(37.459999084473,-112.88999938965,52.25),
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseSprite	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(37.409999847412,-114.51999664307,51.979999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(37.360000610352,-116.15000152588,50.779998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				SpecMat	=	{
					Use	=	true,
					New	=	"models\ctvehicles\audi\q8\rear_running_on",
					Select	=	5,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Pos	=	Vector(35.900001525879,-114.05000305176,52.25),
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseSprite	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(35.849998474121,-115.68000030518,51.979999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(35.770000457764,-117.30999755859,50.779998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				SpecMat	=	{
					Use	=	true,
					New	=	"models\ctvehicles\audi\q8\rear_running_on",
					Select	=	5,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Pos	=	Vector(34.330001831055,-114.68000030518,52.25),
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseSprite	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(34.240001678467,-116.30999755859,51.979999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(34.159999847412,-117.94000244141,50.779998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				SpecMat	=	{
					Use	=	true,
					New	=	"models\ctvehicles\audi\q8\rear_running_on",
					Select	=	5,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Pos	=	Vector(-38.909999847412,-111.73000335693,52.25),
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseSprite	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-38.880001068115,-113.36000061035,51.979999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-38.840000152588,-114.98999786377,50.779998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				SpecMat	=	{
					Use	=	true,
					New	=	"models\ctvehicles\audi\q8\rear_running_on",
					Select	=	5,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Pos	=	Vector(38.909999847412,-111.73000335693,52.25),
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseSprite	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(38.880001068115,-113.36000061035,51.979999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(38.840000152588,-114.98999786377,50.779998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				SpecMat	=	{
					Use	=	true,
					New	=	"models\ctvehicles\audi\q8\rear_running_on",
					Select	=	5,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Pos	=	Vector(-40.369998931885,-110.18000030518,52.209999084473),
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseSprite	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-40.340000152588,-111.80999755859,51.939998626709),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-40.299999237061,-113.44000244141,50.740001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				SpecMat	=	{
					Use	=	true,
					New	=	"models\ctvehicles\audi\q8\rear_running_on",
					Select	=	5,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Pos	=	Vector(40.369998931885,-110.18000030518,52.209999084473),
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseSprite	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(40.340000152588,-111.80999755859,51.939998626709),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(40.299999237061,-113.44000244141,50.740001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				SpecMat	=	{
					Use	=	true,
					New	=	"models\ctvehicles\audi\q8\rear_running_on",
					Select	=	5,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Pos	=	Vector(-41.779998779297,-108.12999725342,52.220001220703),
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseSprite	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-41.700000762939,-109.76000213623,51.950000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-41.630001068115,-111.38999938965,50.75),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				SpecMat	=	{
					Use	=	true,
					New	=	"models\ctvehicles\audi\q8\rear_running_on",
					Select	=	5,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Pos	=	Vector(41.779998779297,-108.12999725342,52.220001220703),
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseSprite	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(41.700000762939,-109.76000213623,51.950000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(41.630001068115,-111.38999938965,50.75),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				SpecMat	=	{
					Use	=	true,
					New	=	"models\ctvehicles\audi\q8\rear_running_on",
					Select	=	5,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				inner_AsSpheres	=	true,
				UseDynamic	=	true,
				RenderHD_Size	=	1.5,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseBrake	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-10.300000190735,-94.580001831055,75.830001831055),
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	107,
						},
				RenderInner_Size	=	1.9138,
				SpecMLine	=	{
					Amount	=	18,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(0,-95,75.910003662109),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(10.300000190735,-94.580001831055,75.830001831055),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner	=	true,
				RenderHD_Adv	=	true,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				UseBrake	=	true,
				SpecRec	=	{
					Pos4	=	Vector(-32.959999084473,-114.73000335693,52.840000152588),
					Use	=	true,
					Pos2	=	Vector(-25.010000228882,-117.06999969482,50.590000152588),
					AmountH	=	10,
					Mid_Full	=	true,
					Pos1	=	Vector(-32.709999084473,-114.73000335693,50.669998168945),
					Pos3	=	Vector(-24.840000152588,-117.2799987793,52.819999694824),
						},
				SpecMat	=	{
					Select	=	26,
					New	=	"models/ctvehicles/audi/q8/blinker_on",
					Use	=	true,
						},
				UseSprite	=	true,
				Pos	=	Vector(-31.729999542236,-115.11000061035,51.669998168945),
				UseDynamic	=	true,
				RenderHD_Adv	=	true,
				RenderHD_Size	=	1.5,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				UseBrake	=	true,
				SpecRec	=	{
					Use	=	true,
					Pos4	=	Vector(32.959999084473,-114.73000335693,52.840000152588),
					Pos2	=	Vector(25.010000228882,-117.06999969482,50.590000152588),
					AmountH	=	10,
					Pos1	=	Vector(32.709999084473,-114.73000335693,50.669998168945),
					Mid_Full	=	true,
					Pos3	=	Vector(24.840000152588,-117.2799987793,52.819999694824),
						},
				SpecMat	=	{
					Select	=	26,
					New	=	"models/ctvehicles/audi/q8/blinker_on",
					Use	=	true,
						},
				UseSprite	=	true,
				Pos	=	Vector(31.729999542236,-115.11000061035,51.669998168945),
				UseDynamic	=	true,
				RenderHD_Adv	=	true,
				RenderHD_Size	=	1.5,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				UseBrake	=	true,
				SpecRec	=	{
					Pos4	=	Vector(-41.130001068115,-108.43000030518,52.599998474121),
					Use	=	true,
					Pos2	=	Vector(-33.450000762939,-113.79000091553,50.729999542236),
					AmountH	=	10,
					Mid_Full	=	true,
					Pos1	=	Vector(-41.029998779297,-108.23000335693,50.810001373291),
					Pos3	=	Vector(-33.689998626709,-114.01999664307,52.810001373291),
						},
				SpecMat	=	{
					Select	=	26,
					New	=	"models/ctvehicles/audi/q8/blinker_on",
					Use	=	true,
						},
				UseSprite	=	true,
				Pos	=	Vector(-40.400001525879,-110.62999725342,51.669998168945),
				UseDynamic	=	true,
				RenderHD_Adv	=	true,
				RenderHD_Size	=	1.5,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				UseBrake	=	true,
				SpecRec	=	{
					Use	=	true,
					Pos4	=	Vector(41.130001068115,-108.43000030518,52.599998474121),
					Pos2	=	Vector(33.450000762939,-113.79000091553,50.729999542236),
					AmountH	=	10,
					Pos1	=	Vector(41.029998779297,-108.23000335693,50.810001373291),
					Mid_Full	=	true,
					Pos3	=	Vector(33.689998626709,-114.01999664307,52.810001373291),
						},
				SpecMat	=	{
					Select	=	26,
					New	=	"models/ctvehicles/audi/q8/blinker_on",
					Use	=	true,
						},
				UseSprite	=	true,
				Pos	=	Vector(40.400001525879,-110.62999725342,51.669998168945),
				UseDynamic	=	true,
				RenderHD_Adv	=	true,
				RenderHD_Size	=	1.5,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	158,
						},
				SpecMat	=	{
					Select	=	10,
					New	=	"models\ctvehicles\audi\q8\blinker_on",
					Use	=	true,
						},
				RenderMLCenter	=	true,
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				UseSprite	=	true,
				Pos	=	Vector(-24.200000762939,-118.12999725342,53.490001678467),
				UseDynamic	=	true,
				seq_stay	=	true,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-31.719999313354,-115.90000152588,53.380001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-35.720001220703,-113.94000244141,53.299999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-39.729999542236,-110.29000091553,53.150001525879),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				seq_use	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderHD_Adv	=	true,
					},
				{
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	158,
						},
				SpecMat	=	{
					Select	=	9,
					New	=	"models\ctvehicles\audi\q8\blinker_on",
					Use	=	true,
						},
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				RenderMLCenter	=	true,
				RenderHD_Adv	=	true,
				Pos	=	Vector(24.170000076294,-118.12999725342,53.490001678467),
				UseDynamic	=	true,
				seq_stay	=	true,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(31.719999313354,-115.90000152588,53.380001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(35.720001220703,-113.94000244141,53.299999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(39.729999542236,-110.29000091553,53.150001525879),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				seq_use	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.12,
						},
				inner_AsSpheres	=	true,
				UseReverse	=	true,
				UseDynamic	=	true,
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				RenderMLCenter	=	true,
				RenderHD_Adv	=	true,
				Pos	=	Vector(-22.389999389648,-118.9700012207,54.220001220703),
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	107,
						},
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	6,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-25.489999771118,-118.30999755859,54.209999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-28.579999923706,-117.48999786377,54.159999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderHD_Size	=	1.5,
				RenderInner	=	true,
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.12,
						},
				inner_AsSpheres	=	true,
				UseReverse	=	true,
				UseDynamic	=	true,
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				RenderMLCenter	=	true,
				UseSprite	=	true,
				Pos	=	Vector(22.389999389648,-118.9700012207,54.220001220703),
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	107,
						},
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	6,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(25.489999771118,-118.30999755859,54.209999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(28.579999923706,-117.48999786377,54.159999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderHD_Size	=	1.5,
				RenderInner	=	true,
				RenderHD_Adv	=	true,
					},
				{
				UseBlinkers	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	158,
						},
				SpecMat	=	{
					Select	=	10,
					New	=	"models\ctvehicles\audi\q8\blinker_on",
					Use	=	true,
						},
				UseSprite	=	true,
				Pos	=	Vector(-54.849998474121,19.780000686646,60.689998626709),
				SpecMLine	=	{
					Amount	=	15,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-54.509998321533,22.60000038147,60.680000305176),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-53.409999847412,25.420000076294,60.590000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderMLCenter	=	true,
					},
				{
				UseBlinkers	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	158,
						},
				SpecMat	=	{
					Select	=	9,
					New	=	"models\ctvehicles\audi\q8\blinker_on",
					Use	=	true,
						},
				UseSprite	=	true,
				Pos	=	Vector(54.849998474121,19.840000152588,60.689998626709),
				SpecMLine	=	{
					Amount	=	15,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(54.509998321533,22.60000038147,60.680000305176),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(53.409999847412,25.420000076294,60.590000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderMLCenter	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				DD_Blnk_Run	=	true,
				SpecMat	=	{
					Use	=	true,
					New	=	"models\ctvehicles\audi\q8\led_on",
					Select	=	6,
						},
				UseSprite	=	true,
				Pos	=	Vector(-42.680000305176,88.660003662109,46.779998779297),
				UseDynamic	=	true,
				RenderMLCenter	=	true,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-42.430000305176,90.889999389648,45.380001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-42.040000915527,92.330001831055,44.259998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-41.430000305176,93.110000610352,43.970001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-37.139999389648,98.019996643066,43.479999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-32.849998474121,101.58999633789,42.990001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-37.830001831055,92.25,44.389999389648),
					Pos2	=	Vector(-40.869998931885,92.25,46.369998931885),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-37.849998474121,92.25,46.430000305176),
					Pos3	=	Vector(-40.860000610352,92.25,44.349998474121),
						},
				HBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseSprite	=	true,
				LBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Pos	=	Vector(-39.360000610352,91.599998474121,45.369998931885),
				UseHighBeams	=	true,
				RenderHD_Size	=	5,
				UsePrjTex	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(37.830001831055,92.25,44.389999389648),
					Pos2	=	Vector(40.869998931885,92.25,46.369998931885),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(37.849998474121,92.25,46.430000305176),
					Pos3	=	Vector(40.860000610352,92.25,44.349998474121),
						},
				HBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseSprite	=	true,
				LBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderMLCenter	=	true,
				UseHighBeams	=	true,
				RenderHD_Size	=	5,
				Pos	=	Vector(39.360000610352,91.599998474121,45.369998931885),
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UsePrjTex	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-36.159999847412,96.459999084473,43.799999237061),
					Pos2	=	Vector(-33.119998931885,96.459999084473,45.779998779297),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-36.139999389648,96.459999084473,45.840000152588),
					Pos3	=	Vector(-33.189998626709,96.459999084473,43.849998474121),
						},
				HBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseSprite	=	true,
				Pos	=	Vector(-34.619998931885,96.040000915527,44.819999694824),
				RenderMLCenter	=	true,
				UseHighBeams	=	true,
				RenderHD_Size	=	3.5,
				RenderHD_Adv	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				LBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(36.159999847412,96.459999084473,43.799999237061),
					Pos2	=	Vector(33.119998931885,96.459999084473,45.779998779297),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(36.139999389648,96.459999084473,45.840000152588),
					Pos3	=	Vector(33.189998626709,96.459999084473,43.849998474121),
						},
				HBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseSprite	=	true,
				Pos	=	Vector(34.619998931885,96.040000915527,44.819999694824),
				RenderMLCenter	=	true,
				UseHighBeams	=	true,
				RenderHD_Size	=	3.5,
				RenderHD_Adv	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				LBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					Use	=	true,
					New	=	"models\ctvehicles\audi\q8\blinker_on",
					Select	=	6,
						},
				UseBlinkers	=	true,
				UseDynamic	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-42.580001831055,88.660003662109,46.779998779297),
				seq_rev	=	true,
				seq_stay	=	true,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-42.430000305176,90.889999389648,45.380001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-42.040000915527,92.330001831055,44.259998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-41.430000305176,93.110000610352,43.970001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-37.139999389648,98.019996643066,43.479999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-32.849998474121,101.58999633789,42.990001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				seq_use	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					Use	=	true,
					New	=	"models\ctvehicles\audi\q8\blinker_on",
					Select	=	7,
						},
				UseBlinkers	=	true,
				UseDynamic	=	true,
				UseSprite	=	true,
				Pos	=	Vector(42.520000457764,88.660003662109,46.779998779297),
				seq_rev	=	true,
				seq_stay	=	true,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(42.430000305176,90.889999389648,45.380001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(42.040000915527,92.330001831055,44.259998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(41.430000305176,93.110000610352,43.970001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(37.139999389648,98.019996643066,43.479999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(32.849998474121,101.58999633789,42.990001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				seq_use	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				DD_Blnk_Run	=	true,
				SpecMat	=	{
					Use	=	true,
					New	=	"models\ctvehicles\audi\q8\led_on",
					Select	=	7,
						},
				UseSprite	=	true,
				Pos	=	Vector(42.610000610352,88.660003662109,46.779998779297),
				UseDynamic	=	true,
				UseRunning	=	true,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(42.430000305176,90.889999389648,45.380001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(42.040000915527,92.330001831055,44.259998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(41.430000305176,93.110000610352,43.970001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(37.139999389648,98.019996643066,43.479999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(32.849998474121,101.58999633789,42.990001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2.1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-29.469999313354,98.300003051758,43.209999084473),
					Pos2	=	Vector(-32.130001068115,97.75,46.139999389648),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-29.5,98.26000213623,45.869998931885),
					Pos3	=	Vector(-32.119998931885,97.879997253418,43.279998779297),
						},
				HBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderHD_Adv	=	true,
				Pos	=	Vector(-30.879999160767,98.279998779297,44.659999847412),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderHD_Size	=	3,
				UseSprite	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2.1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(29.469999313354,98.300003051758,43.209999084473),
					Pos2	=	Vector(32.130001068115,97.75,46.139999389648),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(29.5,98.26000213623,45.869998931885),
					Pos3	=	Vector(32.119998931885,97.879997253418,43.279998779297),
						},
				HBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseSprite	=	true,
				Pos	=	Vector(30.879999160767,98.279998779297,44.659999847412),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderHD_Size	=	3,
				RenderMLCenter	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderHD_Adv	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2.1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/stadium_2x4_texture",
					Pos4	=	Vector(42.400001525879,93.419998168945,39.130001068115),
					Pos2	=	Vector(37.959999084473,93.419998168945,41.680000305176),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(42.380001068115,93.419998168945,41.779998779297),
					Pos3	=	Vector(38.049999237061,93.419998168945,39.080001831055),
						},
				HBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseSprite	=	true,
				Pos	=	Vector(40.220001220703,93,40.369998931885),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderHD_Size	=	5,
				RenderHD_Adv	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2.1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/stadium_2x4_texture",
					Pos4	=	Vector(-42.400001525879,93.419998168945,39.130001068115),
					Pos2	=	Vector(-37.959999084473,93.419998168945,41.680000305176),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-42.380001068115,93.419998168945,41.779998779297),
					Pos3	=	Vector(-38.049999237061,93.419998168945,39.080001831055),
						},
				HBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseSprite	=	true,
				Pos	=	Vector(-40.220001220703,93,40.369998931885),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderHD_Size	=	5,
				RenderHD_Adv	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderMLCenter	=	true,
					},
				},
		em_state	=	5236594524,
		Fuel	=	{
			FuelLidPos	=	Vector(45.090000152588,-81.199996948242,55.240001678467),
			FuelTypeUse	=	true,
			FuelType	=	1,
			Capacity	=	85,
			FuelLidUse	=	true,
			Override	=	true,
				},
		Author	=	"𝓒𝓣𝓥 (76561198051637331)",
}