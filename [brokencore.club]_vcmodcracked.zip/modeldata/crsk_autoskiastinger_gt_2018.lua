VCModels['models/crsk_autoskiastinger_gt_2018.mdl']	=	{
		em_state	=	5236594449,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		HealthEnginePosOvr	=	true,
		Date	=	"Mon Apr 16 13:20:24 2018",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-26.610000610352,-127.44000244141,15.930000305176),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-32.520000457764,-126.23000335693,15.939999580383),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(32.090000152588,-126.23000335693,15.75),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(25.950000762939,-127.44000244141,15.729999542236),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		Indication	=	{
			fuel	=	{
				max	=	1,
				pp	=	"fuel_needle",
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(15,0,0),
				Pos	=	Vector(19.209999084473,2.789999961853,32.150001525879),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(25,0,0),
				Pos	=	Vector(-22.75,-45.599998474121,32.150001525879),
					},
				{
				Ang	=	Angle(25,0,0),
				Pos	=	Vector(20.579999923706,-45.599998474121,32.150001525879),
					},
				{
				Ang	=	Angle(25,0,0),
				Pos	=	Vector(-0.79000002145767,-45.599998474121,32.150001525879),
					},
				},
		HealthEnginePos	=	Vector(0,76.559997558594,40.709999084473),
		DLT	=	3491062966,
		Lights	=	{
				{
				UseRunning	=	true,
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
					Select	=	14,
					New	=	"models\crskautos\kia\stinger_gt_2018\gauge_on",
					Use	=	true,
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Pos	=	Vector(-21.780000686646,22.659999847412,52.200000762939),
					},
				{
				UseRunning	=	true,
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
					Select	=	13,
					New	=	"models\crskautos\kia\stinger_gt_2018\gauge2_on",
					Use	=	true,
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Pos	=	Vector(-14.039999961853,22.559999465942,52.580001831055),
					},
				{
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseInter	=	true,
				InterColor	=	{
					r	=	225,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				SpecMat	=	{
					Select	=	27,
					New	=	"models\crskautos\kia\stinger_gt_2018\interiorlight_on",
					Use	=	true,
						},
				Pos	=	Vector(3.0199999809265,22.559999465942,52.580001831055),
				IsInterior	=	true,
					},
				{
				UseRunning	=	true,
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
					Select	=	15,
					New	=	"models\crskautos\kia\stinger_gt_2018\redillum_on",
					Use	=	true,
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Pos	=	Vector(-10.699999809265,20.209999084473,52.580001831055),
					},
				{
				UseRunning	=	true,
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
					Select	=	11,
					New	=	"models\crskautos\kia\stinger_gt_2018\sym_diff_on",
					Use	=	true,
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Pos	=	Vector(-8.0299997329712,20.209999084473,52.580001831055),
					},
				{
				UseRunning	=	true,
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
					Select	=	26,
					New	=	"models\crskautos\kia\stinger_gt_2018\front_runninglights_on",
					Use	=	true,
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Pos	=	Vector(-21.780000686646,73.529998779297,52.200000762939),
					},
				{
				UseRunning	=	true,
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
					Select	=	22,
					New	=	"models\crskautos\kia\stinger_gt_2018\rear_runninglights_on",
					Use	=	true,
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Pos	=	Vector(-21.780000686646,-119.41000366211,52.200000762939),
					},
				{
				UseBlinkers	=	true,
				Pos	=	Vector(-30.530000686646,73.529998779297,52.200000762939),
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					Select	=	29,
					New	=	"models\crskautos\kia\stinger_gt_2018\turnsignal_left_on",
					Use	=	true,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
					},
				{
				UseBlinkers	=	true,
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					Select	=	28,
					New	=	"models\crskautos\kia\stinger_gt_2018\turnsignal_right_on",
					Use	=	true,
						},
				Pos	=	Vector(33.659999847412,73.529998779297,52.200000762939),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-32.259998321533,99.589996337891,36.959999084473),
					Pos2	=	Vector(-29.14999961853,99.680000305176,34.060001373291),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-28.920000076294,99.580001831055,37.009998321533),
					Pos3	=	Vector(-32.009998321533,99.76000213623,33.930000305176),
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UsePrjTex	=	true,
				Pos	=	Vector(-30.680000305176,99.459999084473,35.490001678467),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseSprite	=	true,
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\front_runninglights_on",
					Select	=	26,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(41.130001068115,92.699996948242,37.900001525879),
					Pos2	=	Vector(35.990001678467,92.790000915527,34.290000915527),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(35.930000305176,92.690002441406,38.310001373291),
					Pos3	=	Vector(40.389999389648,92.870002746582,34.080001831055),
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\front_runninglights_on",
					Select	=	26,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UsePrjTex	=	true,
				Pos	=	Vector(38.419998168945,92.569999694824,36.159999847412),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-40.520000457764,92.699996948242,38.069999694824),
					Pos2	=	Vector(-35.380001068115,92.790000915527,34.459999084473),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-35.319999694824,92.690002441406,38.479999542236),
					Pos3	=	Vector(-39.779998779297,92.870002746582,34.25),
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\front_runninglights_on",
					Select	=	26,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UsePrjTex	=	true,
				Pos	=	Vector(-37.810001373291,92.569999694824,36.330001831055),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(32.819999694824,99.589996337891,36.880001068115),
					Pos2	=	Vector(29.709999084473,99.680000305176,33.979999542236),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(29.479999542236,99.580001831055,36.930000305176),
					Pos3	=	Vector(32.569999694824,99.76000213623,33.849998474121),
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\front_runninglights_on",
					Select	=	26,
						},
				UsePrjTex	=	true,
				Pos	=	Vector(31.239999771118,99.459999084473,35.409999847412),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseSprite	=	true,
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.04,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\front_runninglights_on",
					Select	=	26,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-33.669998168945,97.980003356934,35.380001068115),
				UseDynamic	=	true,
				UseRunning	=	true,
				SpecMLine	=	{
					Amount	=	75,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-33.520000457764,99.300003051758,35.139999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-33.020000457764,101.16999816895,34.439998626709),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-32.110000610352,102.40000152588,33.860000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-31.030000686646,103.19000244141,33.740001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-29.309999465942,104.33999633789,33.630001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-27.729999542236,105.5299987793,33.659999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.05,
					Brightness	=	1.25,
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.04,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\front_runninglights_on",
					Select	=	26,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(42.139999389648,90.389999389648,35.779998779297),
				UseDynamic	=	true,
				UseRunning	=	true,
				SpecMLine	=	{
					Amount	=	75,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(42.049999237061,91.709999084473,35.330001831055),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(41.650001525879,93.120002746582,34.610000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(41.200000762939,94.120002746582,34.229999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(40.409999847412,95.290000915527,33.979999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(38.130001068115,97.669998168945,33.830001831055),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(36.819999694824,98.870002746582,33.779998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(35.459999084473,99.98999786377,33.680000305176),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(34.369998931885,100.84999847412,33.669998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.05,
					Brightness	=	1.25,
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.04,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\front_runninglights_on",
					Select	=	26,
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-41.580001831055,90.389999389648,35.959999084473),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.05,
					Brightness	=	1.25,
						},
				SpecMLine	=	{
					Amount	=	75,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-41.490001678467,91.709999084473,35.509998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-41.090000152588,93.120002746582,34.790000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-40.639999389648,94.120002746582,34.409999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-39.849998474121,95.290000915527,34.159999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-37.569999694824,97.669998168945,34.009998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-36.259998321533,98.870002746582,33.959999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-34.900001525879,99.98999786377,33.860000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-33.810001373291,100.84999847412,33.849998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.04,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\front_runninglights_on",
					Select	=	26,
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(34.180000305176,97.980003356934,35.220001220703),
				UseDynamic	=	true,
				UseRunning	=	true,
				SpecMLine	=	{
					Amount	=	75,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(34.029998779297,99.300003051758,34.979999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(33.520000457764,101.18000030518,34.110000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(32.619998931885,102.40000152588,33.700000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(31.540000915527,103.19000244141,33.580001831055),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(29.840000152588,104.41999816895,33.470001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(28.39999961853,105.30999755859,33.540000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.05,
					Brightness	=	1.25,
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\turnsignal_right_on",
					Select	=	28,
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(42.75,86.660003662109,37.590000152588),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseSprite	=	true,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\turnsignal_right_on",
					Select	=	28,
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-42.580001831055,86.580001831055,37.590000152588),
				UseDynamic	=	true,
				UseSprite	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\turnsignal_right_on",
					Select	=	28,
						},
				UseSprite	=	true,
				Pos	=	Vector(-40.790000915527,94.199996948242,33.340000152588),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\turnsignal_right_on",
					Select	=	28,
						},
				UseSprite	=	true,
				Pos	=	Vector(-36.259998321533,98.629997253418,33.159999847412),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\turnsignal_right_on",
					Select	=	28,
						},
				UseSprite	=	true,
				Pos	=	Vector(-39.229999542236,95.589996337891,33.159999847412),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\turnsignal_right_on",
					Select	=	28,
						},
				UseSprite	=	true,
				Pos	=	Vector(-37.770000457764,97.160003662109,33.150001525879),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\turnsignal_right_on",
					Select	=	28,
						},
				UseSprite	=	true,
				Pos	=	Vector(-40.290000915527,94.980003356934,32.529998779297),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\turnsignal_right_on",
					Select	=	28,
						},
				UseSprite	=	true,
				Pos	=	Vector(-38.810001373291,96.360000610352,32.439998626709),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\turnsignal_right_on",
					Select	=	28,
						},
				UseSprite	=	true,
				Pos	=	Vector(-37.25,97.769996643066,32.419998168945),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\turnsignal_right_on",
					Select	=	28,
						},
				UseSprite	=	true,
				Pos	=	Vector(-38.169998168945,96.819999694824,31.670000076294),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\turnsignal_right_on",
					Select	=	28,
						},
				UseSprite	=	true,
				Pos	=	Vector(-39.659999847412,95.400001525879,31.790000915527),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\turnsignal_right_on",
					Select	=	28,
						},
				UseSprite	=	true,
				Pos	=	Vector(41.209999084473,94.199996948242,33.200000762939),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\turnsignal_right_on",
					Select	=	28,
						},
				UseSprite	=	true,
				Pos	=	Vector(39.799999237061,95.589996337891,33.020000457764),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\turnsignal_right_on",
					Select	=	28,
						},
				UseSprite	=	true,
				Pos	=	Vector(38.330001831055,97.160003662109,33.040000915527),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\turnsignal_right_on",
					Select	=	28,
						},
				UseSprite	=	true,
				Pos	=	Vector(36.840000152588,98.629997253418,33),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\turnsignal_right_on",
					Select	=	28,
						},
				UseSprite	=	true,
				Pos	=	Vector(37.840000152588,97.769996643066,32.209999084473),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\turnsignal_right_on",
					Select	=	28,
						},
				UseSprite	=	true,
				Pos	=	Vector(39.319999694824,96.360000610352,32.310001373291),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\turnsignal_right_on",
					Select	=	28,
						},
				UseSprite	=	true,
				Pos	=	Vector(40.689998626709,94.980003356934,32.369998931885),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\turnsignal_right_on",
					Select	=	28,
						},
				UseSprite	=	true,
				Pos	=	Vector(40.139999389648,95.400001525879,31.620000839233),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\turnsignal_right_on",
					Select	=	28,
						},
				UseSprite	=	true,
				Pos	=	Vector(38.709999084473,96.819999694824,31.530000686646),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.04,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseBrake	=	true,
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\front_runninglights_on",
					Select	=	26,
						},
				ReducedVis	=	true,
				UseRunning	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-18.549999237061,-126.66999816895,46.029998779297),
				UseDynamic	=	true,
				Beta_Inner3D	=	true,
				SpecMLine	=	{
					Amount	=	154,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-19.739999771118,-126.62999725342,45.080001831055),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-21.049999237061,-126.62999725342,44.349998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-22.889999389648,-126.62999725342,43.240001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-24.270000457764,-126.5299987793,42.520000457764),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-26.229999542236,-126.12999725342,42.099998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-29.370000839233,-124.87999725342,42.060001373291),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-32.009998321533,-123.56999969482,42.099998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-34.650001525879,-122.05000305176,42.229999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-36.400001525879,-120.69000244141,42.349998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-37.819999694824,-119.18000030518,42.450000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-37.869998931885,-118.84999847412,42.900001525879),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-37.529998779297,-118.80000305176,43.779998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-36.659999847412,-119.30999755859,44.599998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-35.319999694824,-119.95999908447,45.150001525879),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-33.950000762939,-120.83000183105,45.659999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-32.549999237061,-121.81999969482,46.090000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-30.729999542236,-122.62000274658,46.529998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-28.709999084473,-123.37000274658,46.799999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-26.790000915527,-124.05000305176,47.080001831055),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-25.200000762939,-124.37000274658,47.169998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-22.889999389648,-124.98999786377,47.369998931885),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-20.889999389648,-125.34999847412,47.479999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-18.790000915527,-125.73999786377,47.479999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-18.059999465942,-126.45999908447,46.790000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-18.379999160767,-126.69000244141,46.080001831055),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0.05,
					Brightness	=	1.25,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.04,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseBrake	=	true,
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\front_runninglights_on",
					Select	=	26,
						},
				ReducedVis	=	true,
				UseRunning	=	true,
				UseSprite	=	true,
				Pos	=	Vector(18.170000076294,-126.83000183105,45.889999389648),
				UseDynamic	=	true,
				Beta_Inner3D	=	true,
				SpecMLine	=	{
					Amount	=	154,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(19.360000610352,-126.79000091553,44.939998626709),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(20.670000076294,-126.79000091553,44.209999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(22.510000228882,-126.79000091553,43.099998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(23.889999389648,-126.69000244141,42.380001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(25.85000038147,-126.29000091553,41.959999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(28.989999771118,-125.04000091553,41.919998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(31.629999160767,-123.73000335693,41.959999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(34.270000457764,-122.20999908447,42.090000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(36.020000457764,-120.84999847412,42.209999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(37.439998626709,-119.33999633789,42.310001373291),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(37.490001678467,-119.01000213623,42.759998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(37.150001525879,-118.95999908447,43.639999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(36.279998779297,-119.4700012207,44.459999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(34.939998626709,-120.12000274658,45.009998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(33.569999694824,-120.98999786377,45.520000457764),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(32.169998168945,-121.98000335693,45.950000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(30.35000038147,-122.7799987793,46.389999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(28.329999923706,-123.5299987793,46.659999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(26.409999847412,-124.20999908447,46.939998626709),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(24.819999694824,-124.5299987793,47.029998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(22.510000228882,-125.15000152588,47.229999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(20.510000228882,-125.51000213623,47.340000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(18.409999847412,-125.90000152588,47.340000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(17.680000305176,-126.62000274658,46.650001525879),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Size	=	0.1,
							Pos	=	Vector(18,-126.7799987793,45.869998931885),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0.05,
					Brightness	=	1.25,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\turnsignal_right_on",
					Select	=	28,
						},
				UseSprite	=	true,
				Pos	=	Vector(-29.389999389648,-122.79000091553,45.450000762939),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\turnsignal_right_on",
					Select	=	28,
						},
				UseSprite	=	true,
				Pos	=	Vector(-31.069999694824,-122.05999755859,45.430000305176),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\turnsignal_right_on",
					Select	=	28,
						},
				UseSprite	=	true,
				Pos	=	Vector(-29.170000076294,-123.19000244141,44.680000305176),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\turnsignal_right_on",
					Select	=	28,
						},
				UseSprite	=	true,
				Pos	=	Vector(-30.930000305176,-122.33000183105,44.790000915527),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\turnsignal_right_on",
					Select	=	28,
						},
				UseSprite	=	true,
				Pos	=	Vector(-32.680000305176,-121.18000030518,44.819999694824),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\turnsignal_right_on",
					Select	=	28,
						},
				UseSprite	=	true,
				Pos	=	Vector(-28.879999160767,-123.48000335693,44.009998321533),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\turnsignal_right_on",
					Select	=	28,
						},
				UseSprite	=	true,
				Pos	=	Vector(-30.75,-122.61000061035,44.029998779297),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\turnsignal_right_on",
					Select	=	28,
						},
				UseSprite	=	true,
				Pos	=	Vector(-32.540000915527,-121.55000305176,44.069999694824),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\turnsignal_right_on",
					Select	=	28,
						},
				UseSprite	=	true,
				Pos	=	Vector(-34.400001525879,-120.4700012207,44.119998931885),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\turnsignal_right_on",
					Select	=	28,
						},
				UseSprite	=	true,
				Pos	=	Vector(28.5,-123.48000335693,43.880001068115),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\turnsignal_right_on",
					Select	=	28,
						},
				UseSprite	=	true,
				Pos	=	Vector(28.719999313354,-123.19000244141,44.569999694824),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\turnsignal_right_on",
					Select	=	28,
						},
				UseSprite	=	true,
				Pos	=	Vector(28.879999160767,-122.79000091553,45.349998474121),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\turnsignal_right_on",
					Select	=	28,
						},
				UseSprite	=	true,
				Pos	=	Vector(30.569999694824,-122.05999755859,45.310001373291),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\turnsignal_right_on",
					Select	=	28,
						},
				UseSprite	=	true,
				Pos	=	Vector(30.409999847412,-122.33000183105,44.639999389648),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\turnsignal_right_on",
					Select	=	28,
						},
				UseSprite	=	true,
				Pos	=	Vector(30.25,-122.61000061035,43.909999847412),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\turnsignal_right_on",
					Select	=	28,
						},
				UseSprite	=	true,
				Pos	=	Vector(32.220001220703,-121.18000030518,44.650001525879),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\turnsignal_right_on",
					Select	=	28,
						},
				UseSprite	=	true,
				Pos	=	Vector(32.099998474121,-121.55000305176,43.990001678467),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\turnsignal_right_on",
					Select	=	28,
						},
				UseSprite	=	true,
				Pos	=	Vector(33.880001068115,-120.4700012207,44.060001373291),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.07,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\turnsignal_right_on",
					Select	=	28,
						},
				UseSprite	=	true,
				Pos	=	Vector(39.319999694824,-116.16999816895,42.389999389648),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0.05,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.07,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\turnsignal_right_on",
					Select	=	28,
						},
				UseSprite	=	true,
				Pos	=	Vector(-39.319999694824,-115.94000244141,42.509998321533),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0.05,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-22.739999771118,-125.41999816895,45.540000915527),
					Pos2	=	Vector(-26.819999694824,-124.44999694824,44.229999542236),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-27.010000228882,-124.16000366211,45.459999084473),
					Pos3	=	Vector(-24.170000076294,-125.33000183105,44.439998626709),
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\turnsignal_right_on",
					Select	=	28,
						},
				UseSprite	=	true,
				Pos	=	Vector(-24.329999923706,-123.65000152588,45.029998779297),
				UseDynamic	=	true,
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(22.14999961853,-125.41999816895,45.400001525879),
					Pos2	=	Vector(26.229999542236,-124.44999694824,44.090000152588),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(26.549999237061,-124.16000366211,45.340000152588),
					Pos3	=	Vector(23.579999923706,-125.33000183105,44.299999237061),
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\turnsignal_right_on",
					Select	=	28,
						},
				UseSprite	=	true,
				Pos	=	Vector(23.739999771118,-123.65000152588,44.889999389648),
				UseDynamic	=	true,
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.04,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\turnsignal_right_on",
					Select	=	28,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-48.529998779297,22,47.889999389648),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	26,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-49.909999847412,20.770000457764,47.990001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-51.650001525879,18.950000762939,48.330001831055),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-52.409999847412,17.090000152588,48.560001373291),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-52.810001373291,15.010000228882,48.659999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.05,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\turnsignal_right_on",
					Select	=	28,
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-47.060001373291,18.940000534058,45.959999084473),
				UseDynamic	=	true,
				UseSprite	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.05,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\turnsignal_right_on",
					Select	=	28,
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(47.490001678467,18.659999847412,45.830001831055),
				UseDynamic	=	true,
				UseSprite	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.05,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.04,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\turnsignal_right_on",
					Select	=	28,
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(48.810001373291,22,47.529998779297),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	26,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(50.189998626709,20.770000457764,47.630001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(51.930000305176,18.950000762939,47.970001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(52.689998626709,17.090000152588,48.200000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(53.090000152588,15.010000228882,48.299999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.05,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseInter	=	true,
				InterColor	=	{
					r	=	225,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\interiorlight_on",
					Select	=	27,
						},
				IsInterior	=	true,
				UseSprite	=	true,
				Pos	=	Vector(3.4100000858307,-1.039999961853,62.580001831055),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.15,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseInter	=	true,
				InterColor	=	{
					r	=	225,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				SpecMat	=	{
					New	=	"models\crskautos\kia\stinger_gt_2018\interiorlight_on",
					Select	=	27,
						},
				IsInterior	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-3.0699999332428,-1.039999961853,62.580001831055),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.15,
					Brightness	=	2,
						},
					},
				},
		Copyright	=	"Copyright © 2012-2018 VCMod (freemmaann). All Rights Reserved.",
		Fuel	=	{
			FuelLidPos	=	Vector(-42.659999847412,-88.349998474121,46.229999542236),
			FuelLidUse	=	true,
			FuelType	=	0,
			Capacity	=	60,
			Override	=	true,
			FuelTypeUse	=	true,
				},
		Author	=	"CrushingSkirmish (76561198017348899)",
}