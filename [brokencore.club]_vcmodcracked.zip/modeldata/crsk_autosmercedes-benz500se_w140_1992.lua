VCModels['models/crsk_autosmercedes-benz500se_w140_1992.mdl']	=	{
		em_state	=	5236594809,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		HealthEnginePosOvr	=	true,
		Date	=	"Wed Feb 14 00:00:25 2018",
		Exhaust	=	{
				{
				Ang	=	Angle(50,-90,0),
				Pos	=	Vector(-19.840000152588,-109.91000366211,13.289999961853),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(50,-90,0),
				Pos	=	Vector(-15.180000305176,-109.88999938965,13.569999694824),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		Indication	=	{
			speedo_kmph	=	{
				max	=	1,
				pp	=	"vehicle_guage",
				min	=	0,
				top	=	240,
					},
			fuel	=	{
				max	=	1,
				pp	=	"fuel_needle",
				min	=	0,
				top	=	1,
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(15,0,0),
				Pos	=	Vector(20.729999542236,17.360000610352,33.069999694824),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(20,0,0),
				Pos	=	Vector(19.729999542236,-23.840000152588,33.069999694824),
					},
				{
				Ang	=	Angle(20,0,0),
				Pos	=	Vector(-20.229999542236,-23.840000152588,33.069999694824),
					},
				{
				Ang	=	Angle(20,0,0),
				Pos	=	Vector(-0.73000001907349,-23.840000152588,33.069999694824),
					},
				},
		HealthEnginePos	=	Vector(0,83,39.729999542236),
		DLT	=	3491063206,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	255,
					b	=	166,
					a	=	255,
					g	=	233,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(37.490001678467,115.05999755859,28.409999847412),
					UseColor	=	true,
					Pos2	=	Vector(26.620000839233,113.68000030518,36.759998321533),
					Color	=	{
						r	=	255,
						b	=	166,
						a	=	255,
						g	=	233,
							},
					Use	=	true,
					Pos1	=	Vector(37.689998626709,111.25,36.569999694824),
					Pos3	=	Vector(26.190000534058,117.7799987793,28.549999237061),
						},
				HBeamColor	=	{
					r	=	255,
					b	=	166,
					a	=	255,
					g	=	233,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(32.060001373291,111.5,32.509998321533),
				RenderInner	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1,
				SpecMat	=	{
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.7,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_blur",
					Pos4	=	Vector(26.450000762939,118.20999908447,27.60000038147),
					UseColor	=	true,
					Pos2	=	Vector(21.969999313354,114.90000152588,36.659999847412),
					Color	=	{
						r	=	255,
						b	=	166,
						a	=	255,
						g	=	233,
							},
					Use	=	true,
					Pos1	=	Vector(26.780000686646,113.73000335693,37.209999084473),
					Pos3	=	Vector(19.290000915527,119.26000213623,27.930000305176),
						},
				HBeamColor	=	{
					r	=	255,
					b	=	166,
					a	=	255,
					g	=	233,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(23.299999237061,114.65000152588,31.989999771118),
				RenderInner	=	true,
				SpecMat	=	{
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	166,
					a	=	255,
					g	=	233,
						},
				RenderInner_Size	=	1,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				Beta_Inner3D	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RenderInner_Size	=	4,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(39.450000762939,108.44999694824,35.340000152588),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	4,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(39.159999847412,112.30000305176,29.219999313354),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.02,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					Use	=	true,
					Mid	=	true,
					AmountH	=	30,
					Pos1	=	Vector(34.549999237061,-111.95999908447,36.790000915527),
					InnerCenterOnly	=	true,
					AmountV	=	20,
					Pos2	=	Vector(24.10000038147,-112.51999664307,36.819999694824),
					Pos4	=	Vector(34.549999237061,-111.94000244141,33.450000762939),
					Mid_Full	=	true,
					Pos3	=	Vector(21.409999847412,-112.62000274658,33.490001678467),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(31.709999084473,-112.12999725342,35.259998321533),
				UseDynamic	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.025,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					Use	=	true,
					Mid	=	true,
					AmountH	=	10,
					Pos1	=	Vector(37.5,-110.69999694824,36.720001220703),
					InnerCenterOnly	=	true,
					AmountV	=	10,
					Pos2	=	Vector(34.549999237061,-111.95999908447,36.790000915527),
					Pos4	=	Vector(37.5,-110.69999694824,33.319999694824),
					Mid_Full	=	true,
					Pos3	=	Vector(34.549999237061,-111.94000244141,33.450000762939),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseRunning	=	true,
				UseSprite	=	true,
				Pos	=	Vector(36.299999237061,-111.37000274658,35.020000457764),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.02,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					Use	=	true,
					Mid	=	true,
					AmountH	=	15,
					Pos1	=	Vector(37.5,-110.69999694824,36.720001220703),
					InnerCenterOnly	=	true,
					AmountV	=	15,
					Pos2	=	Vector(38.279998779297,-106.62999725342,36.689998626709),
					Pos4	=	Vector(37.5,-110.69999694824,33.319999694824),
					Mid_Full	=	true,
					Pos3	=	Vector(38.299999237061,-106.16000366211,33.310001373291),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseRunning	=	true,
				UseSprite	=	true,
				Pos	=	Vector(37.799999237061,-108.87000274658,35.020000457764),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(34.310001373291,-112.12999725342,31.020000457764),
					Pos2	=	Vector(27.809999465942,-112.40000152588,33.020000457764),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(34.310001373291,-112.12999725342,33.020000457764),
					Pos3	=	Vector(27.809999465942,-112.40000152588,31.020000457764),
						},
				RenderInner	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(31.309999465942,-112.12999725342,32.020000457764),
				UseDynamic	=	true,
				RenderInner_Size	=	4,
				ReverseColor	=	{
					r	=	255,
					b	=	255,
					a	=	255,
					g	=	255,
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.06,
						},
				SpecSpin	=	{
						},
				UseBlinkers	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RenderInner	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				UseSprite	=	true,
				Pos	=	Vector(25.260000228882,-112.09999847412,37.590000152588),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	40,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(35.020000457764,-111.44999694824,37.619998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.130001068115,-111.2799987793,37.599998474121),
								},
							{
							Pos	=	Vector(36.689998626709,-111.12000274658,37.599998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				UseBlinkers	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RenderInner	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				UseSprite	=	true,
				Pos	=	Vector(36.689998626709,-111.12000274658,37.599998474121),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	29,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(37.180000305176,-110.7200012207,37.599998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.459999084473,-110.20999908447,37.599998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.659999847412,-109.56999969482,37.599998474121),
								},
							{
							Pos	=	Vector(38.439998626709,-105.83000183105,37.540000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.06,
						},
				SpecSpin	=	{
						},
				RenderMLCenter	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RenderInner_Size	=	1,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(27.159999847412,-111.62000274658,39.889999389648),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	35,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(36.029998779297,-111.44999694824,39.919998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.830001831055,-111.08999633789,39.930000305176),
								},
							{
							Pos	=	Vector(37.279998779297,-110.51000213623,39.950000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.06,
						},
				SpecSpin	=	{
						},
				UseBlinkers	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RenderInner	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				UseSprite	=	true,
				Pos	=	Vector(37.279998779297,-110.51000213623,39.950000762939),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(38.279998779297,-107.01000213623,39.950000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-34.709999084473,-112.01000213623,31.10000038147),
					Pos2	=	Vector(-28.209999084473,-112.2799987793,33.099998474121),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-34.709999084473,-112.01000213623,33.099998474121),
					Pos3	=	Vector(-28.209999084473,-112.2799987793,31.10000038147),
						},
				RenderInner	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-31.709999084473,-112.01000213623,32.099998474121),
				UseDynamic	=	true,
				RenderInner_Size	=	4,
				ReverseColor	=	{
					r	=	255,
					b	=	255,
					a	=	255,
					g	=	255,
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				RenderMLCenter	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RenderInner	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-37.270000457764,-111.05999755859,37.729999542236),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	29,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-37.759998321533,-110.66000366211,37.729999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.040000915527,-110.15000152588,37.729999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.240001678467,-109.51000213623,37.729999542236),
								},
							{
							Pos	=	Vector(-39.020000457764,-105.76999664307,37.669998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.06,
						},
				SpecSpin	=	{
						},
				RenderMLCenter	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RenderInner	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-37.840000152588,-110.19999694824,40.060001373291),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-38.840000152588,-106.69999694824,40.060001373291),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.06,
						},
				SpecSpin	=	{
						},
				UseBlinkers	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RenderInner_Size	=	1,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-27.719999313354,-111.40000152588,40),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	35,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-36.590000152588,-111.23000335693,40.029998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.389999389648,-110.87000274658,40.040000915527),
								},
							{
							Pos	=	Vector(-37.840000152588,-110.29000091553,40.060001373291),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.06,
						},
				SpecSpin	=	{
						},
				RenderMLCenter	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RenderInner	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-25.840000152588,-112.04000091553,37.720001220703),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	40,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-35.599998474121,-111.38999938965,37.75),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.709999084473,-111.2200012207,37.729999542236),
								},
							{
							Pos	=	Vector(-37.270000457764,-111.05999755859,37.729999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.02,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					Use	=	true,
					Mid	=	true,
					AmountH	=	30,
					Pos1	=	Vector(-34.930000305176,-111.87999725342,36.819999694824),
					InnerCenterOnly	=	true,
					AmountV	=	20,
					Pos2	=	Vector(-24.479999542236,-112.44000244141,36.849998474121),
					Pos4	=	Vector(-34.930000305176,-111.86000061035,33.479999542236),
					Mid_Full	=	true,
					Pos3	=	Vector(-21.790000915527,-112.54000091553,33.520000457764),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-32.090000152588,-112.05000305176,35.290000915527),
				UseDynamic	=	true,
				UseSprite	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.025,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					Use	=	true,
					Mid	=	true,
					AmountH	=	10,
					Pos1	=	Vector(-38.150001525879,-110.59999847412,36.720001220703),
					InnerCenterOnly	=	true,
					AmountV	=	10,
					Pos2	=	Vector(-34.930000305176,-111.87999725342,36.819999694824),
					Pos4	=	Vector(-38.150001525879,-110.59999847412,33.319999694824),
					Mid_Full	=	true,
					Pos3	=	Vector(-34.930000305176,-111.86000061035,33.479999542236),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseRunning	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-36.950000762939,-111.26999664307,35.020000457764),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.02,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					Use	=	true,
					Mid	=	true,
					AmountH	=	15,
					Pos1	=	Vector(-38.150001525879,-110.59999847412,36.720001220703),
					InnerCenterOnly	=	true,
					AmountV	=	15,
					Pos2	=	Vector(-38.630001068115,-106.43000030518,36.75),
					Pos4	=	Vector(-38.150001525879,-110.59999847412,33.319999694824),
					Mid_Full	=	true,
					Pos3	=	Vector(-38.650001525879,-105.95999908447,33.369998931885),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseRunning	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-38.150001525879,-108.66999816895,35.080001831055),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				UseSprite	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				UseSprite	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RenderInner_Size	=	4,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-38.950000762939,108.90000152588,35.340000152588),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	4,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-38.659999847412,112.75,29.219999313354),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.7,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_blur",
					Pos4	=	Vector(-25.85000038147,118.26000213623,27.709999084473),
					UseColor	=	true,
					Pos2	=	Vector(-21.370000839233,114.94999694824,36.770000457764),
					Color	=	{
						r	=	255,
						b	=	166,
						a	=	255,
						g	=	233,
							},
					Use	=	true,
					Pos1	=	Vector(-26.180000305176,113.7799987793,37.319999694824),
					Pos3	=	Vector(-18.690000534058,119.30999755859,28.040000915527),
						},
				HBeamColor	=	{
					r	=	255,
					b	=	166,
					a	=	255,
					g	=	233,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-22.700000762939,114.69999694824,32.099998474121),
				RenderInner_Size	=	1,
				SpecMat	=	{
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	166,
					a	=	255,
					g	=	233,
						},
				RenderInner	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	255,
					b	=	166,
					a	=	255,
					g	=	233,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-36.830001831055,115.26000213623,28.5),
					UseColor	=	true,
					Pos2	=	Vector(-25.959999084473,113.87999725342,36.849998474121),
					Color	=	{
						r	=	255,
						b	=	166,
						a	=	255,
						g	=	233,
							},
					Use	=	true,
					Pos1	=	Vector(-37.029998779297,111.44999694824,36.659999847412),
					Pos3	=	Vector(-25.530000686646,117.98000335693,28.639999389648),
						},
				HBeamColor	=	{
					r	=	255,
					b	=	166,
					a	=	255,
					g	=	233,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-31.39999961853,111.69999694824,32.599998474121),
				RenderInner_Size	=	1,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				SpecMat	=	{
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				Beta_Inner3D	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBrake	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-36.459999084473,-109.83999633789,35.220001220703),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderInner_Size	=	1,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				Beta_Inner3D	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBrake	=	true,
				UseSprite	=	true,
				Pos	=	Vector(36.290000915527,-109.83999633789,34.990001678467),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderInner_Size	=	1,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				UseRunning	=	true,
				SpecSpin	=	{
						},
				SpecMat	=	{
					Select	=	8,
					New	=	"models\crskautos\mercedes-benz\500se_w140_1992\illum_but1_on",
					Use	=	true,
						},
				RunningColor	=	{
					r	=	255,
					b	=	111,
					a	=	255,
					g	=	175,
						},
				Pos	=	Vector(0,33.189998626709,35.060001373291),
					},
				{
				UseRunning	=	true,
				SpecSpin	=	{
						},
				SpecMat	=	{
					Select	=	7,
					New	=	"models\crskautos\mercedes-benz\500se_w140_1992\illum_but2_on",
					Use	=	true,
						},
				RunningColor	=	{
					r	=	255,
					b	=	111,
					a	=	255,
					g	=	175,
						},
				Pos	=	Vector(0,34.159999847412,42.099998474121),
					},
				{
				UseRunning	=	true,
				SpecSpin	=	{
						},
				SpecMat	=	{
					Select	=	6,
					New	=	"models\crskautos\mercedes-benz\500se_w140_1992\illum_priborka_on",
					Use	=	true,
						},
				RunningColor	=	{
					r	=	255,
					b	=	111,
					a	=	255,
					g	=	175,
						},
				Pos	=	Vector(-18.760000228882,34.159999847412,43.049999237061),
					},
				{
				UseRunning	=	true,
				SpecSpin	=	{
						},
				SpecMat	=	{
					Select	=	3,
					New	=	"models\crskautos\mercedes-benz\500se_w140_1992\yellowneedle_on",
					Use	=	true,
						},
				RunningColor	=	{
					r	=	255,
					b	=	111,
					a	=	255,
					g	=	175,
						},
				Pos	=	Vector(-15.050000190735,34.159999847412,43.049999237061),
					},
				},
		Copyright	=	"Copyright © 2012-2018 VCMod (freemmaann). All Rights Reserved.",
		Fuel	=	{
			FuelLidPos	=	Vector(-38.400001525879,-87.029998779297,37.090000152588),
			FuelType	=	0,
			Capacity	=	100,
			FuelLidUse	=	true,
			Override	=	true,
				},
		Author	=	"CrushingSkirmish (76561198017348899)",
}