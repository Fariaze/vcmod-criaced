VCModels['models/betadiggerdigger.mdl']	=	{
		em_state	=	5236594842,
		DLT	=	3491063228,
		Date	=	"10/19/15 09:30:12",
		Copyright	=	"DurkaTeam @ 2025 No rights reserved",
		Author	=	"freemmaann (76561197989323181)",
}