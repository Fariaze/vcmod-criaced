VCModels['models/crsk_autostoyotalandcruiser_200_2013.mdl']	=	{
		em_state	=	5236594836,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		HealthEnginePosOvr	=	true,
		Date	=	"Fri Nov 23 17:18:53 2018",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(-22.079999923706,-110.44999694824,14.199999809265),
				EffectIdle	=	"VC_Exhaust",
					},
				},
		Indication	=	{
			fuel	=	{
				max	=	1,
				pp	=	"fuel_needle",
				top	=	1,
					},
				},
		Copyright	=	"Copyright © 2012-2018 VCMod (freemmaann). All Rights Reserved.",
		HealthEnginePos	=	Vector(-2.1700000762939,90.069999694824,48.869998931885),
		DLT	=	3491063224,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
					New	=	"models\crskautos\toyota\landcruiser_200_2013\under200a_illum_on",
					Select	=	23,
						},
				UseSprite	=	true,
				Pos	=	Vector(24.920000076294,122.33999633789,43.599998474121),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
					New	=	"models\crskautos\shared\vmt\white_illum_on",
					Select	=	24,
						},
				UseSprite	=	true,
				Pos	=	Vector(26.989999771118,121.76999664307,43.729999542236),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(29.020000457764,121.15000152588,43.909999847412),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(31.040000915527,120.31999969482,43.930000305176),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(33.110000610352,119.7200012207,44.080001831055),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(35.060001373291,119,44.169998168945),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-25.430000305176,122.33999633789,43.549999237061),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-27.5,121.76999664307,43.650001525879),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-29.569999694824,121.15000152588,43.740001678467),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-31.579999923706,120.31999969482,43.869998931885),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-33.599998474121,119.7200012207,43.970001220703),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-35.560001373291,119,44.080001831055),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				FogColor	=	{
					r	=	225,
					b	=	185,
					a	=	255,
					g	=	215,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-38.860000610352,118.5,31.620000839233),
				UseDynamic	=	true,
				UseFog	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				FogColor	=	{
					r	=	225,
					b	=	185,
					a	=	255,
					g	=	215,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-38.209999084473,118.62000274658,32.770000457764),
				UseDynamic	=	true,
				UseFog	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				FogColor	=	{
					r	=	225,
					b	=	185,
					a	=	255,
					g	=	215,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-39.349998474121,118.41000366211,32.790000915527),
				UseDynamic	=	true,
				UseFog	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				FogColor	=	{
					r	=	225,
					b	=	185,
					a	=	255,
					g	=	215,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-39.849998474121,117.45999908447,31.559999465942),
				UseDynamic	=	true,
				UseFog	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				FogColor	=	{
					r	=	225,
					b	=	185,
					a	=	255,
					g	=	215,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-39.380001068115,117.73999786377,30.590000152588),
				UseDynamic	=	true,
				UseFog	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				FogColor	=	{
					r	=	225,
					b	=	185,
					a	=	255,
					g	=	215,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-38.200000762939,118.25,30.5),
				UseDynamic	=	true,
				UseFog	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				FogColor	=	{
					r	=	225,
					b	=	185,
					a	=	255,
					g	=	215,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-37.560001373291,118.38999938965,31.5),
				UseDynamic	=	true,
				UseFog	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				FogColor	=	{
					r	=	225,
					b	=	185,
					a	=	255,
					g	=	215,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(38.319999694824,118.69000244141,31.64999961853),
				UseDynamic	=	true,
				UseFog	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				FogColor	=	{
					r	=	225,
					b	=	185,
					a	=	255,
					g	=	215,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(37.680000305176,117.9700012207,32.779998779297),
				UseDynamic	=	true,
				UseFog	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				FogColor	=	{
					r	=	225,
					b	=	185,
					a	=	255,
					g	=	215,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(38.720001220703,117.62000274658,32.810001373291),
				UseDynamic	=	true,
				UseFog	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				FogColor	=	{
					r	=	225,
					b	=	185,
					a	=	255,
					g	=	215,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(39.349998474121,118.05000305176,31.680000305176),
				UseDynamic	=	true,
				UseFog	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				FogColor	=	{
					r	=	225,
					b	=	185,
					a	=	255,
					g	=	215,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(37.110000610352,118.38999938965,31.639999389648),
				UseDynamic	=	true,
				UseFog	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				FogColor	=	{
					r	=	225,
					b	=	185,
					a	=	255,
					g	=	215,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(37.669998168945,118.25,30.680000305176),
				UseDynamic	=	true,
				UseFog	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				FogColor	=	{
					r	=	225,
					b	=	185,
					a	=	255,
					g	=	215,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(38.860000610352,117.73999786377,30.700000762939),
				UseDynamic	=	true,
				UseFog	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.12,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-44.939998626709,102.26999664307,53.930000305176),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	26,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-41.220001220703,110.19000244141,53.930000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-42.970001220703,110.33000183105,51.810001373291),
								},
							{
							Pos	=	Vector(-45.310001373291,102.20999908447,52.5),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.65,
					Brightness	=	2,
						},
				SpecMat	=	{
					Select	=	17,
					New	=	"models\crskautos\toyota\landcruiser_200_2013\glass_headlights_on",
					Use	=	true,
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(38.610000610352,115.9700012207,48.819999694824),
				RenderInner	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.65,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-38.959999084473,115.9700012207,48.990001678467),
				RenderInner	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				HBeamColor	=	{
					r	=	174,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-24.39999961853,118.59999847412,42.860000610352),
					Pos2	=	Vector(-35.220001220703,118.59999847412,53.680000305176),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-24.39999961853,118.59999847412,53.680000305176),
					Pos3	=	Vector(-35.220001220703,118.59999847412,42.860000610352),
						},
				RenderInner_Size	=	1,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-29.809999465942,118.59999847412,48.270000457764),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				UseSprite	=	true,
				Dynamic	=	{
					Size	=	0.65,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Beta_Inner3D	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(34.450000762939,118.5,43.040000915527),
					Pos2	=	Vector(23.989999771118,118.5,53.5),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(34.450000762939,118.5,53.5),
					Pos3	=	Vector(23.989999771118,118.5,43.040000915527),
						},
				RenderInner	=	true,
				HBeamColor	=	{
					r	=	174,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				ReducedVis	=	true,
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(29.219999313354,118.5,48.270000457764),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Size	=	1,
				Dynamic	=	{
					Size	=	0.65,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseReverse	=	true,
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-34.349998474121,-109.56999969482,48.200000762939),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	13,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-33.479999542236,-109.45999908447,49.700000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.010000228882,-110.45999908447,49.650001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.639999389648,-110.54000091553,49.080001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.459999084473,-110.30000305176,47.930000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.209999084473,-109.59999847412,48.009998321533),
								},
							},
						},
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
				ReverseColor	=	{
						255,
						255,
						255,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseReverse	=	true,
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(34.349998474121,-109.56999969482,48.200000762939),
				UseDynamic	=	true,
				ReverseColor	=	{
					r	=	255,
					b	=	255,
					a	=	255,
					g	=	255,
						},
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
				SpecMLine	=	{
					Amount	=	13,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(33.479999542236,-109.45999908447,49.700000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.010000228882,-110.45999908447,49.650001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.639999389648,-110.54000091553,49.080001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.459999084473,-110.30000305176,47.930000305176),
								},
							{
							Pos	=	Vector(34.209999084473,-109.59999847412,48.009998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseBlinkers	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RenderInner_Size	=	1,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				UseSprite	=	true,
				Pos	=	Vector(42.819999694824,-100.65000152588,55.180000305176),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	46,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(42.459999084473,-108.55000305176,55.159999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(38.889999389648,-109.13999938965,55.270000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(38.220001220703,-109.15000152588,54.049999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(38.369998931885,-109.16000366211,53.290000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(39.419998168945,-109.05000305176,52.659999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(42.400001525879,-108.58000183105,52.700000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(43.069999694824,-100.69999694824,52.810001373291),
								},
							{
							Pos	=	Vector(43.159999847412,-100.79000091553,54.009998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseSprite	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				RenderInner	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner_Size	=	1.2,
				Beta_Inner3D	=	true,
				Pos	=	Vector(31.940000534058,-109.54000091553,54.150001525879),
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	35,
					Use	=	true,
					Radius	=	2.77,
						},
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
						255,
						100,
						0,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				RenderInner	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner_Size	=	1.2,
				UseSprite	=	true,
				Pos	=	Vector(-31.940000534058,-109.54000091553,54.150001525879),
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	35,
					Use	=	true,
					Radius	=	2.77,
						},
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
						255,
						100,
						0,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseDynamic	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						255,
						100,
						0,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBrake	=	true,
				UseSprite	=	true,
				Pos	=	Vector(41.090000152588,-108.69999694824,56.520000457764),
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	46,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(40.549999237061,-108.66000366211,56.659999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(39.900001525879,-108.62999725342,56.729999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(38.689998626709,-108.56999969482,56.770000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.799999237061,-108.51000213623,56.529998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.150001525879,-108.48999786377,55.909999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.709999084473,-108.5,55.040000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.459999084473,-108.51999664307,54.110000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.680000305176,-108.54000091553,53.060001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.099998474121,-108.54000091553,52.240001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.540000915527,-108.55999755859,51.610000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(38.279998779297,-108.62000274658,51.220001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(39.659999847412,-108.7200012207,51.229999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(40.779998779297,-108.63999938965,51.490001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(41.599998474121,-108.62000274658,51.779998779297),
								},
							},
						},
				RenderInner_Size	=	1.2,
				RunningColor	=	{
						255,
						55,
						0,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseDynamic	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						255,
						100,
						0,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-41.090000152588,-108.69999694824,56.520000457764),
				UseSprite	=	true,
				RenderInner_Size	=	1.2,
				SpecMLine	=	{
					Amount	=	46,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-40.549999237061,-108.66000366211,56.659999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-39.900001525879,-108.62999725342,56.729999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.689998626709,-108.56999969482,56.770000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.799999237061,-108.51000213623,56.529998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.150001525879,-108.48999786377,55.909999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.709999084473,-108.5,55.040000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.459999084473,-108.51999664307,54.110000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.680000305176,-108.54000091553,53.060001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.099998474121,-108.54000091553,52.240001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.540000915527,-108.55999755859,51.610000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.279998779297,-108.62000274658,51.220001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-39.659999847412,-108.7200012207,51.229999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-40.779998779297,-108.63999938965,51.490001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-41.599998474121,-108.62000274658,51.779998779297),
								},
							},
						},
				RenderInner	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-42.819999694824,-100.65000152588,55.180000305176),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	46,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-42.459999084473,-108.55000305176,55.159999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.889999389648,-109.13999938965,55.270000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.220001220703,-109.15000152588,54.049999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.369998931885,-109.16000366211,53.290000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-39.419998168945,-109.05000305176,52.659999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-42.400001525879,-108.58000183105,52.700000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-43.069999694824,-100.69999694824,52.810001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-43.159999847412,-100.79000091553,54.009998321533),
								},
							},
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.12,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(44.650001525879,102.26999664307,53.930000305176),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	26,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(40.930000305176,110.19000244141,53.930000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(42.680000305176,110.33000183105,51.810001373291),
								},
							{
							Pos	=	Vector(45.020000457764,102.20999908447,52.5),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner_Size	=	1,
				UseSprite	=	true,
				Pos	=	Vector(43.549999237061,-99.430000305176,50.330001831055),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	46,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(40.830001831055,-107.33000183105,50.180000305176),
							UseClr	=	false,
							Clr	=	{
									0,
									0,
									0,
									},
								},
							{
							Pos	=	Vector(39.619998931885,-107.91999816895,50.169998168945),
							UseClr	=	false,
							Clr	=	{
									0,
									0,
									0,
									},
								},
							{
							Pos	=	Vector(36.540000915527,-108.7799987793,50.080001831055),
							UseClr	=	false,
							Clr	=	{
									0,
									0,
									0,
									},
								},
							{
							Pos	=	Vector(36.520000457764,-108.80000305176,48.470001220703),
							UseClr	=	false,
							Clr	=	{
									0,
									0,
									0,
									},
								},
							{
							Pos	=	Vector(39.75,-107.83000183105,48.360000610352),
							UseClr	=	false,
							Clr	=	{
									0,
									0,
									0,
									},
								},
							{
							Pos	=	Vector(40.990001678467,-107.48999786377,48.369998931885),
							UseClr	=	false,
							Clr	=	{
									0,
									0,
									0,
									},
								},
							{
							Pos	=	Vector(43.799999237061,-99.480003356934,48.479999542236),
							UseClr	=	false,
							Clr	=	{
									0,
									0,
									0,
									},
								},
							{
							Pos	=	Vector(43.889999389648,-99.569999694824,49.430000305176),
							UseClr	=	true,
							Clr	=	{
									255,
									55,
									0,
									},
								},
							},
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseBrake	=	true,
				UseSprite	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-43.549999237061,-99.430000305176,50.330001831055),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	46,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-40.830001831055,-107.33000183105,50.180000305176),
							UseClr	=	false,
							Clr	=	{
									0,
									0,
									0,
									},
								},
							{
							Pos	=	Vector(-39.619998931885,-107.91999816895,50.169998168945),
							UseClr	=	false,
							Clr	=	{
									0,
									0,
									0,
									},
								},
							{
							Pos	=	Vector(-36.540000915527,-108.7799987793,50.080001831055),
							UseClr	=	false,
							Clr	=	{
									0,
									0,
									0,
									},
								},
							{
							Pos	=	Vector(-36.520000457764,-108.80000305176,48.470001220703),
							UseClr	=	false,
							Clr	=	{
									0,
									0,
									0,
									},
								},
							{
							Pos	=	Vector(-39.75,-107.83000183105,48.360000610352),
							UseClr	=	false,
							Clr	=	{
									0,
									0,
									0,
									},
								},
							{
							Pos	=	Vector(-40.990001678467,-107.48999786377,48.369998931885),
							UseClr	=	false,
							Clr	=	{
									0,
									0,
									0,
									},
								},
							{
							Pos	=	Vector(-43.799999237061,-99.480003356934,48.479999542236),
							UseClr	=	false,
							Clr	=	{
									0,
									0,
									0,
									},
								},
							{
							Pos	=	Vector(-43.889999389648,-99.569999694824,49.430000305176),
							UseClr	=	true,
							Clr	=	{
									255,
									55,
									0,
									},
								},
							},
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						0,
						0,
						0,
						},
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-3.8699998855591,-99.860000610352,82.349998474121),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	4,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-1.2000000476837,-99.779998779297,82.349998474121),
							UseClr	=	false,
							Clr	=	{
									0,
									0,
									0,
									},
								},
							{
							Pos	=	Vector(1.1299999952316,-99.779998779297,82.349998474121),
							UseClr	=	false,
							Clr	=	{
									0,
									0,
									0,
									},
								},
							{
							Pos	=	Vector(3.7999999523163,-99.76000213623,82.339996337891),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
				UseBrake	=	true,
					},
				{
				UseRunning	=	true,
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
					Select	=	22,
					New	=	"models\crskautos\toyota\landcruiser_200_2013\under200a_illum_on",
					Use	=	true,
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Pos	=	Vector(25.590000152588,87.690002441406,43.549999237061),
					},
				{
				UseRunning	=	true,
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
					Use	=	true,
					New	=	"models\crskautos\shared\vmt\white_illum_on",
					Select	=	23,
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Pos	=	Vector(27.690000534058,80.199996948242,43.650001525879),
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(18,0,0),
				Pos	=	Vector(22.170000076294,27.870000839233,48.470001220703),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(18,0,0),
				Pos	=	Vector(-23.940000534058,-23.670000076294,48.740001678467),
					},
				{
				Ang	=	Angle(18,0,0),
				Pos	=	Vector(20.969999313354,-23.670000076294,48.740001678467),
					},
				{
				Ang	=	Angle(18,0,0),
				Pos	=	Vector(-1.2300000190735,-23.670000076294,48.759998321533),
					},
				},
		Fuel	=	{
			FuelLidPos	=	Vector(48.340000152588,-78.559997558594,49.439998626709),
			Override	=	true,
			FuelType	=	0,
			Capacity	=	93,
			FuelLidUse	=	true,
			FuelTypeUse	=	true,
				},
		Author	=	"CrushingSkirmish (76561198017348899)",
}