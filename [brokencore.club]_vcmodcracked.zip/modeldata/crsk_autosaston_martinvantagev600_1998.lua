VCModels['models/crsk_autosaston_martinvantagev600_1998.mdl']	=	{
		em_state	=	5236595058,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Date	=	"Mon Sep  4 16:19:52 2017",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-29.940000534058,-126.05000305176,16.670000076294),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(29.479999542236,-126.05000305176,16.479999542236),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Pos	=	Vector(19.159999847412,-8.8100004196167,30.290000915527),
				DoorSounds	=	true,
				Ang	=	Angle(25,0,0),
				EnterRange	=	80,
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(20,0,0),
				Pos	=	Vector(19.229999542236,-46.650001525879,32.479999542236),
				EnterRange	=	80,
				DoorSounds	=	true,
					},
				{
				Ang	=	Angle(20,0,0),
				Pos	=	Vector(-19.229999542236,-46.650001525879,32.479999542236),
				EnterRange	=	80,
				DoorSounds	=	true,
					},
				{
				Ang	=	Angle(20,0,0),
				Pos	=	Vector(0,-46.650001525879,32.479999542236),
				EnterRange	=	80,
				DoorSounds	=	true,
					},
				},
		DLT	=	3491063372,
		Lights	=	{
				{
				UseBlinkers	=	true,
				UseBrake	=	true,
				BlinkersColor	=	{
						255,
						55,
						0,
						},
				SpecMat	=	{
						},
				Sprite	=	{
					Size	=	0.1,
						},
				UseRunning	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-33.479999542236,-123.58999633789,41.439998626709),
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	11,
					Use	=	true,
					Radius	=	2.88,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				SpecSpin	=	{
						},
					},
				{
				Sprite	=	{
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseBrake	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-25.280000686646,-126.38999938965,41.540000915527),
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	11,
					Use	=	true,
					Radius	=	2.88,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
					},
				{
				UseBlinkers	=	true,
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				Sprite	=	{
					Size	=	0.4,
						},
				UseSprite	=	true,
				Pos	=	Vector(-22.239999771118,100.44999694824,24.75),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	8,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-24.360000610352,100.05999755859,24.760000228882),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.39999961853,99.639999389648,24.819999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.219999313354,99.139999389648,24.85000038147),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.069999694824,98.629997253418,24.879999160767),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.479999542236,98.180000305176,24.879999160767),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.130001068115,97.580001831055,24.940000534058),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.700000762939,96.930000305176,25),
								},
							},
						},
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1.2,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
					},
				{
				Sprite	=	{
					Size	=	1.2,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				HBeamColor	=	{
						248,
						214,
						255,
						},
				ProjTexture	=	{
					Size	=	2024,
					Angle	=	Angle(0,90,0),
						},
				UsePrjTex	=	true,
				LBeamColor	=	{
						248,
						214,
						190,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				SpecMat	=	{
						},
				Pos	=	Vector(-28.559999465942,90.449996948242,31.659999847412),
				UseSprite	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.6,
						},
					},
				{
				Sprite	=	{
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-34.020000457764,87.580001831055,31.569999694824),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
						247,
						211,
						190,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.6,
						},
					},
				{
				Sprite	=	{
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-23.209999084473,92.349998474121,31.639999389648),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
						247,
						211,
						190,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.6,
						},
					},
				{
				Sprite	=	{
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-11.89999961853,-109.58000183105,25.680000305176),
				UseDynamic	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				SpecMLine	=	{
					Amount	=	3,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-11.840000152588,-108.73000335693,22.430000305176),
								},
							},
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.3,
						},
					},
				{
				UseBlinkers	=	true,
				UseBrake	=	true,
				BlinkersColor	=	{
						255,
						55,
						0,
						},
				SpecMat	=	{
						},
				SpecSpin	=	{
						},
				Sprite	=	{
					Size	=	0.1,
						},
				UseSprite	=	true,
				Pos	=	Vector(33.009998321533,-123.58999633789,41.360000610352),
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	11,
					Use	=	true,
					Radius	=	2.88,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseBrake	=	true,
				UseSprite	=	true,
				Pos	=	Vector(24.819999694824,-126.38999938965,41.540000915527),
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	11,
					Use	=	true,
					Radius	=	2.88,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					Size	=	1.2,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				HBeamColor	=	{
						248,
						214,
						190,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.6,
						},
				UsePrjTex	=	true,
				LBeamColor	=	{
						248,
						214,
						190,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				SpecMat	=	{
						},
				Pos	=	Vector(28.559999465942,90.449996948242,31.659999847412),
				UseSprite	=	true,
				ProjTexture	=	{
					Size	=	2024,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(34.520000457764,87.779998779297,31.569999694824),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
						247,
						211,
						190,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.6,
						},
					},
				{
				Sprite	=	{
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(23.60000038147,92.349998474121,31.639999389648),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
						247,
						211,
						190,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.6,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(11.89999961853,-110.30000305176,25.680000305176),
				UseDynamic	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				SpecMLine	=	{
					Amount	=	3,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(11.840000152588,-109.44999694824,22.430000305176),
								},
							},
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.3,
						},
					},
				{
				UseBlinkers	=	true,
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				Sprite	=	{
					Size	=	0.4,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(22.239999771118,100.44999694824,24.75),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	8,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(24.360000610352,100.05999755859,24.760000228882),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.39999961853,99.639999389648,24.819999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.219999313354,99.139999389648,24.85000038147),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.069999694824,98.629997253418,24.879999160767),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.479999542236,98.180000305176,24.879999160767),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.130001068115,97.580001831055,24.940000534058),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.700000762939,96.930000305176,25),
								},
							},
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
				RenderInner_Size	=	1.2,
				UseSprite	=	true,
					},
				{
				UseBlinkers	=	true,
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(44.060001373291,21.950000762939,38.169998168945),
				UseDynamic	=	true,
				RenderInner	=	true,
				Sprite	=	{
					Size	=	0.4,
						},
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1.2,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.2,
						},
					},
				{
				UseBlinkers	=	true,
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-44.060001373291,21.950000762939,38.169998168945),
				UseDynamic	=	true,
				RenderInner_Size	=	1.2,
				UseSprite	=	true,
				RenderInner	=	true,
				Sprite	=	{
					Size	=	0.4,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Use	=	true,
					Pos2	=	Vector(-28.340000152588,-128.58000183105,27.059999465942),
					Pos4	=	Vector(-23.590000152588,-128.86000061035,29.5),
					Pos1	=	Vector(-28.280000686646,-128.39999389648,29.290000915527),
					Pos3	=	Vector(-23.579999923706,-129.0299987793,27.239999771118),
						},
				FogColor	=	{
						255,
						55,
						0,
						},
				SpecMat	=	{
						},
				RenderInner_Size	=	1.2,
				UseSprite	=	true,
				Pos	=	Vector(-25.75,-128.71000671387,28.10000038147),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseFog	=	true,
				Beta_Inner3D	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-23.030000686646,-128.75999450684,29.620000839233),
					Pos2	=	Vector(-28.659999847412,-127.90000152588,26.770000457764),
					Use	=	true,
					Pos1	=	Vector(-28.770000457764,-128,29.579999923706),
					Pos3	=	Vector(-23.110000610352,-128.55000305176,26.85000038147),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Use	=	true,
					Pos2	=	Vector(27.879999160767,-128.58000183105,26.879999160767),
					Pos4	=	Vector(23.129999160767,-128.86000061035,29.319999694824),
					Pos1	=	Vector(27.819999694824,-128.39999389648,29.110000610352),
					Pos3	=	Vector(23.120000839233,-129.0299987793,27.059999465942),
						},
				FogColor	=	{
						255,
						55,
						0,
						},
				SpecMat	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(22.569999694824,-128.75999450684,29.440000534058),
					Pos2	=	Vector(28.200000762939,-127.90000152588,26.590000152588),
					Use	=	true,
					Pos1	=	Vector(28.309999465942,-128,29.39999961853),
					Pos3	=	Vector(22.64999961853,-128.55000305176,26.670000076294),
						},
				UseSprite	=	true,
				Pos	=	Vector(25.290000915527,-128.71000671387,27.920000076294),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseFog	=	true,
				RenderInner_Size	=	1.2,
				Beta_Inner3D	=	true,
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.2,
						},
					},
				},
		Copyright	=	"Copyright © 2012-2017 VCMod (freemmaann). All Rights Reserved.",
		Fuel	=	{
			FuelLidPos	=	Vector(0,0,0),
			Capacity	=	80,
			Override	=	true,
			FuelType	=	0,
				},
		Author	=	"CrushingSkirmish (76561198017348899)",
}