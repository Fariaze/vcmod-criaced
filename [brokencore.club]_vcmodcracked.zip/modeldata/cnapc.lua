VCModels['models/cnapc.mdl']	=	{
		Lights	=	{
				{
				Sprite	=	{
					Size	=	0.4,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
				UseSprite	=	true,
				Pos	=	Vector(-45.520000457764,-171.9700012207,79.029998779297),
				UseDynamic	=	true,
				UseBrake	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
					},
				{
				UseSprite	=	true,
				Pos	=	Vector(-36.979999542236,117.91000366211,73.129997253418),
				UseDynamic	=	true,
				Sprite	=	{
					Size	=	0.4,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
				RunningColor	=	{
						200,
						225,
						255,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					Size	=	1.2,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.6,
						},
				UseHead	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-46.180000305176,117.9700012207,72.73999786377),
				UseDynamic	=	true,
				HeadColor	=	{
						216,
						214,
						255,
						},
				UsePrjTex	=	true,
				ProjTexture	=	{
					Forward	=	30,
					Size	=	2024,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					Size	=	0.4,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
				UseSprite	=	true,
				Pos	=	Vector(45.520000457764,-171.9700012207,79.029998779297),
				UseDynamic	=	true,
				UseBrake	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
					},
				{
				UseSprite	=	true,
				Pos	=	Vector(36.979999542236,117.91000366211,73.129997253418),
				UseDynamic	=	true,
				Sprite	=	{
					Size	=	0.4,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.4,
						},
				RunningColor	=	{
						200,
						225,
						255,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					Size	=	1.2,
						},
				Dynamic	=	{
					Brightness	=	2,
					Size	=	0.6,
						},
				UseHead	=	true,
				UseSprite	=	true,
				Pos	=	Vector(46.180000305176,117.9700012207,72.73999786377),
				UseDynamic	=	true,
				HeadColor	=	{
						216,
						214,
						255,
						},
				UsePrjTex	=	true,
				ProjTexture	=	{
					Forward	=	30,
					Size	=	2024,
					Angle	=	Angle(0,90,0),
						},
					},
				},
		Exhaust	=	{
				{
				Ang	=	Angle(45,-90,0),
				Pos	=	Vector(6.1700000762939,-173.80999755859,70.620002746582),
				EffectStress	=	"VC_Exhaust_Truck_Stress",
				EffectIdle	=	"VC_Exhaust_Truck",
					},
				},
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		DLT	=	3491063376,
		Date	=	"05/29/14 12:27:09",
		ExtraSeats	=	{
				},
		Z_Copyright	=	"This data is copyrighted material of: freemmaann vcmod.net, steam ID: STEAM_0:1:14528726, creation date: 05/29/14 12:27:09.",
		Author	=	"freemmaann vcmod.net",
}