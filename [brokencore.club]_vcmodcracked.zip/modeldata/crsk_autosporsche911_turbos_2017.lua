VCModels['models/crsk_autosporsche911_turbos_2017.mdl']	=	{
		em_state	=	5236594377,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		HealthEnginePosOvr	=	true,
		Date	=	"Fri Feb  1 18:44:24 2019",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(24.090000152588,-106.65000152588,15.270000457764),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(30.329999923706,-105.0299987793,15.210000038147),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-24.420000076294,-106.54000091553,15.529999732971),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-30.629999160767,-104.91999816895,15.539999961853),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(20,0,0),
				Pos	=	Vector(17.559999465942,2.960000038147,26),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(5,0,0),
				Pos	=	Vector(17.340000152588,-29.010000228882,28),
					},
				{
				Ang	=	Angle(5,0,0),
				Pos	=	Vector(-14.840000152588,-29.010000228882,28),
					},
				},
		HealthEnginePos	=	Vector(0,-92.480003356934,35.5),
		DLT	=	3491062918,
		Lights	=	{
				{
				UseBlinkers	=	true,
				DD_Blnk_Run	=	true,
				UseDynamic	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.0514,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(35.569999694824,96.599998474121,23.389999389648),
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	35,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(23.35000038147,104.25,23.139999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Size	=	1,
				RunningColor	=	{
					r	=	200,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner	=	true,
				UseRunning	=	true,
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-21.920000076294,-100.84999847412,37.409999847412),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	95,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-25.520000457764,-99.480003356934,37.270000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.239999771118,-98.73999786377,37.169998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.059999465942,-98.330001831055,37.119998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.889999389648,-97.830001831055,37.049999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.10000038147,-97,36.959999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.200000762939,-96.160003662109,36.860000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.719999313354,-95.730003356934,36.799999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.220001220703,-95.279998779297,36.75),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.759998321533,-94.76000213623,36.680000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.630001068115,-93.860000610352,36.560001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.479999542236,-92.879997253418,36.450000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.599998474121,-91.440002441406,36.279998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.580001831055,-90.059997558594,36.110000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.310001373291,-88.940002441406,35.970001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.970001220703,-87.790000915527,35.840000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.729999542236,-86.389999389648,35.680000305176),
								},
							{
							Pos	=	Vector(-39.770000457764,-84.290000915527,35.419998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	100,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.03,
						},
				UseReverse	=	true,
				UseDynamic	=	true,
				RenderGlow_Size	=	0.406,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				ReverseColor	=	{
					r	=	245,
					b	=	245,
					a	=	255,
					g	=	245,
						},
				RenderInner	=	true,
				ReducedVis	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				UseSprite	=	true,
				Pos	=	Vector(-23.459999084473,-101.13999938965,36.25),
				RenderHD_Size	=	0.15,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	91,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-25.049999237061,-100.58999633789,36.189998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.549999237061,-99.949996948242,36.139999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.219999313354,-99.069999694824,36.080001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.760000228882,-98.040000915527,35.990001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.5,-96.660003662109,35.900001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.159999847412,-95.050003051758,35.799999237061),
								},
							{
							Pos	=	Vector(-34.639999389648,-93.339996337891,35.700000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderHD_Adv	=	true,
				Beta_Inner3D	=	true,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.03,
						},
				UseReverse	=	true,
				UseDynamic	=	true,
				ReverseColor	=	{
					r	=	245,
					b	=	245,
					a	=	255,
					g	=	245,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				RenderGlow_Size	=	0.406,
				RenderInner_Size	=	1,
				ReducedVis	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				UseSprite	=	true,
				Pos	=	Vector(23.159999847412,-101.25,36.139999389648),
				RenderHD_Size	=	0.15,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	91,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(24.75,-100.69999694824,36.080001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.25,-100.05999755859,36.029998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.920000076294,-99.180000305176,35.970001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.459999084473,-98.150001525879,35.880001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.200000762939,-96.769996643066,35.790000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.860000610352,-95.160003662109,35.689998626709),
								},
							{
							Pos	=	Vector(34.340000152588,-93.449996948242,35.590000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderHD_Adv	=	true,
				Beta_Inner3D	=	true,
				RenderMLCenter	=	true,
					},
				{
				UseBlinkers	=	true,
				UseDynamic	=	true,
				RenderHD_Size	=	0.4,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RenderInner	=	true,
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-23.940000534058,-100.19000244141,35.330001831055),
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	255,
						},
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	23,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-25.040000915527,-99.779998779297,35.319999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.129999160767,-99.300003051758,35.299999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.209999084473,-98.75,35.290000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.309999465942,-98.129997253418,35.259998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.25,-97.519996643066,35.240001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.120000839233,-96.910003662109,35.229999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31,-96.230003356934,35.209999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.770000457764,-95.599998474121,35.189998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.470001220703,-94.949996948242,35.180000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.25,-94.160003662109,35.159999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.930000305176,-93.440002441406,35.159999847412),
								},
							{
							Pos	=	Vector(-34.599998474121,-92.699996948242,35.169998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.11,
						},
				RenderHD_Adv	=	true,
				Beta_Inner3D	=	true,
					},
				{
				UseBlinkers	=	true,
				DD_Blnk_Run	=	true,
				UseDynamic	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.0525,
						},
				UseSprite	=	true,
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(35.490001678467,96.599998474121,21.969999313354),
				RenderInner_Size	=	1,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	35,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(22.760000228882,104.36000061035,21.64999961853),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RunningColor	=	{
					r	=	200,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(29.139999389648,84.019996643066,35.090000152588),
				RenderInner_Size	=	2,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	75,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(29.049999237061,84.839996337891,34.470001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.059999465942,85.610000610352,33.840000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.159999847412,86.339996337891,33.25),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.360000610352,87.019996643066,32.669998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.680000305176,87.680000305176,32.069999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.379999160767,88.430000305176,31.290000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.219999313354,88.910003662109,30.64999961853),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.920000076294,89.069999694824,30.35000038147),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.020000457764,89,30.129999160767),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.709999084473,88.75,30.120000839233),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.759998321533,88.160003662109,30.239999771118),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.639999389648,87.410003662109,30.520000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.389999389648,86.720001220703,30.829999923706),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.060001373291,85.800003051758,31.409999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.569999694824,84.959999084473,31.959999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(38.110000610352,83.76000213623,32.799999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(38.409999847412,82.660003662109,33.630001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(38.470001220703,81.470001220703,34.689998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(38.360000610352,80.629997253418,35.490001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(38.090000152588,79.879997253418,36.279998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.549999237061,79.019996643066,37.229999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.029998779297,78.569999694824,37.790000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.509998321533,78.290000915527,38.25),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.930000305176,78.150001525879,38.580001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.380001068115,78.040000915527,38.729999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.619998931885,78.150001525879,38.840000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.779998779297,78.330001831055,38.869998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.020000457764,78.660003662109,38.740001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.159999847412,79.180000305176,38.459999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.170000076294,79.930000305176,37.919998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.379999160767,80.949996948242,37.25),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.559999465942,82.430000305176,36.209999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.309999465942,83.169998168945,35.720001220703),
								},
							{
							Pos	=	Vector(29.180000305176,83.830001831055,35.209999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
					r	=	200,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				UseBrake	=	true,
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	133,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-34.900001525879,-93.089996337891,36.049999237061),
				RenderMLCenter	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-34.540000915527,-93.599998474121,36.090000152588),
							UseClr	=	false,
							Clr	=	{
									0,
									0,
									0,
									},
								},
							{
							Pos	=	Vector(-34.150001525879,-94.120002746582,36.130001068115),
							UseClr	=	false,
							Clr	=	{
									0,
									0,
									0,
									},
								},
							{
							Pos	=	Vector(-33.720001220703,-94.660003662109,36.180000305176),
							UseClr	=	false,
							Clr	=	{
									0,
									0,
									0,
									},
								},
							{
							Pos	=	Vector(-33.270000457764,-95.180000305176,36.240001678467),
							UseClr	=	false,
							Clr	=	{
									0,
									0,
									0,
									},
								},
							{
							Pos	=	Vector(-32.959999084473,-95.48999786377,36.270000457764),
							UseClr	=	false,
							Clr	=	{
									0,
									0,
									0,
									},
								},
							{
							Pos	=	Vector(-32.689998626709,-95.75,36.290000915527),
							UseClr	=	false,
							Clr	=	{
									0,
									0,
									0,
									},
								},
							{
							Pos	=	Vector(-32.360000610352,-96.059997558594,36.319999694824),
							UseClr	=	false,
							Clr	=	{
									0,
									0,
									0,
									},
								},
							{
							Pos	=	Vector(-31.85000038147,-96.51000213623,36.369998931885),
							UseClr	=	false,
							Clr	=	{
									0,
									0,
									0,
									},
								},
							{
							Pos	=	Vector(-31.319999694824,-96.910003662109,36.419998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	200,
								b	=	255,
								a	=	255,
								g	=	225,
									},
								},
							},
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_Size	=	0.7,
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				UseBrake	=	true,
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(34.599998474121,-93.25,35.880001068115),
				RenderInner_Clr	=	{
					r	=	200,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner_Size	=	0.7,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(34.240001678467,-93.76000213623,35.919998168945),
							UseClr	=	false,
							Clr	=	{
									0,
									0,
									0,
									},
								},
							{
							Pos	=	Vector(33.849998474121,-94.279998779297,35.959999084473),
							UseClr	=	false,
							Clr	=	{
									0,
									0,
									0,
									},
								},
							{
							Pos	=	Vector(33.419998168945,-94.819999694824,36.009998321533),
							UseClr	=	false,
							Clr	=	{
									0,
									0,
									0,
									},
								},
							{
							Pos	=	Vector(32.970001220703,-95.339996337891,36.069999694824),
							UseClr	=	false,
							Clr	=	{
									0,
									0,
									0,
									},
								},
							{
							Pos	=	Vector(32.659999847412,-95.650001525879,36.099998474121),
							UseClr	=	false,
							Clr	=	{
									0,
									0,
									0,
									},
								},
							{
							Pos	=	Vector(32.389999389648,-95.910003662109,36.119998931885),
							UseClr	=	false,
							Clr	=	{
									0,
									0,
									0,
									},
								},
							{
							Pos	=	Vector(32.060001373291,-96.220001220703,36.150001525879),
							UseClr	=	false,
							Clr	=	{
									0,
									0,
									0,
									},
								},
							{
							Pos	=	Vector(31.549999237061,-96.669998168945,36.200000762939),
							UseClr	=	false,
							Clr	=	{
									0,
									0,
									0,
									},
								},
							{
							Pos	=	Vector(31.020000457764,-97.069999694824,36.25),
							UseClr	=	false,
							Clr	=	{
								r	=	200,
								b	=	255,
								a	=	255,
								g	=	225,
									},
								},
							},
						},
				RenderInner	=	true,
				UseSprite	=	true,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				UseBrake	=	true,
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	133,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-27.840000152588,-99.230003356934,36.689998626709),
				RenderMLCenter	=	true,
				RenderInner_Size	=	0.8,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-26.809999465942,-99.769996643066,36.740001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.760000228882,-100.25,36.799999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.729999542236,-100.68000030518,36.849998474121),
								},
							{
							Pos	=	Vector(-23.709999084473,-101.05999755859,36.880001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner	=	true,
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				UseBrake	=	true,
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-27.670000076294,-99.519996643066,34.110000610352),
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	133,
						},
				RenderInner_Size	=	1.1,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-27.020000457764,-99.900001525879,34.130001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.319999694824,-100.26000213623,34.130001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.700000762939,-100.56999969482,34.139999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.010000228882,-100.86000061035,34.159999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.420000076294,-101.08999633789,34.189998626709),
								},
							{
							Pos	=	Vector(-23.889999389648,-101.25,34.220001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner	=	true,
				UseSprite	=	true,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				UseBrake	=	true,
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	200,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(27.309999465942,-99.629997253418,34),
				RenderMLCenter	=	true,
				RenderInner_Size	=	1.1,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(26.659999847412,-100.01000213623,34.020000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.959999084473,-100.37000274658,34.020000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.340000152588,-100.68000030518,34.029998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.64999961853,-100.9700012207,34.049999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.059999465942,-101.19999694824,34.080001831055),
								},
							{
							Pos	=	Vector(23.530000686646,-101.36000061035,34.110000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner	=	true,
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				UseBrake	=	true,
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	133,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-34.419998168945,-93.790000915527,34.130001068115),
				RenderMLCenter	=	true,
				RenderInner_Size	=	1.2,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-33.580001831055,-94.790000915527,34.139999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.139999389648,-95.290000915527,34.139999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.669998168945,-95.790000915527,34.139999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.240001678467,-96.209999084473,34.139999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.709999084473,-96.690002441406,34.139999389648),
								},
							{
							Pos	=	Vector(-30.75,-97.48999786377,34.130001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner	=	true,
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				UseBrake	=	true,
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(34.139999389648,-94.019996643066,33.959999084473),
				RenderInner_Clr	=	{
					r	=	200,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner_Size	=	1.2,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(33.299999237061,-95.019996643066,33.970001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.860000610352,-95.519996643066,33.970001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.389999389648,-96.019996643066,33.970001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.959999084473,-96.440002441406,33.970001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.430000305176,-96.919998168945,33.970001220703),
								},
							{
							Pos	=	Vector(30.469999313354,-97.720001220703,33.959999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner	=	true,
				UseSprite	=	true,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				UseBrake	=	true,
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	200,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(27.489999771118,-99.360000610352,36.580001831055),
				RenderMLCenter	=	true,
				RenderInner_Size	=	0.8,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(26.459999084473,-99.900001525879,36.630001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.409999847412,-100.37999725342,36.689998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.379999160767,-100.80999755859,36.740001678467),
								},
							{
							Pos	=	Vector(23.360000610352,-101.19000244141,36.770000457764),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner	=	true,
				UseSprite	=	true,
					},
				{
				UseBlinkers	=	true,
				UseDynamic	=	true,
				RenderHD_Size	=	0.5,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RenderInner	=	true,
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(23.610000610352,-100.37000274658,35.220001220703),
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	255,
						},
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	23,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(24.709999084473,-99.959999084473,35.209999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.799999237061,-99.480003356934,35.189998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.879999160767,-98.930000305176,35.180000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.979999542236,-98.309997558594,35.150001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.920000076294,-97.699996948242,35.130001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.790000915527,-97.089996337891,35.119998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.670000076294,-96.410003662109,35.099998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.440000534058,-95.779998779297,35.080001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.150001525879,-95.110000610352,35.060001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.919998168945,-94.339996337891,35.049999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.599998474121,-93.620002746582,35.049999237061),
								},
							{
							Pos	=	Vector(34.270000457764,-92.879997253418,35.060001373291),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderHD_Adv	=	true,
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.11,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				UseBrake	=	true,
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				ReducedVis	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-11.529999732971,-104.05999755859,43.909999847412),
				DD_Glow	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	71,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-8.8199996948242,-104.33000183105,43.919998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-4.3400001525879,-104.62999725342,43.990001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-0.20999999344349,-104.79000091553,44),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(4.0199999809265,-104.62000274658,43.950000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(8.5500001907349,-104.2799987793,43.880001068115),
								},
							{
							Pos	=	Vector(11.25,-104.01000213623,43.849998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	99,
						},
				Beta_Inner3D	=	true,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UsePrjTex	=	true,
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-31.360000610352,80.98999786377,34.830001831055),
					Pos2	=	Vector(-36.279998779297,80.98999786377,38.25),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-30.860000610352,80.98999786377,38.25),
					Pos3	=	Vector(-35.779998779297,80.98999786377,34.830001831055),
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-33.569999694824,80.98999786377,36.540000915527),
				RenderInner_Size	=	1,
				RenderInner	=	true,
				UseSprite	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UsePrjTex	=	true,
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(31.819999694824,80.889999389648,34.669998168945),
					Pos2	=	Vector(36.740001678467,80.889999389648,38.090000152588),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(31.319999694824,80.889999389648,38.090000152588),
					Pos3	=	Vector(36.240001678467,80.889999389648,34.669998168945),
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(34.029998779297,80.889999389648,36.380001068115),
				RenderInner_Size	=	1,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-35.049999237061,85.809997558594,31.069999694824),
					Pos2	=	Vector(-30.129999160767,85.809997558594,34.490001678467),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-35.549999237061,85.809997558594,34.490001678467),
					Pos3	=	Vector(-30.629999160767,85.809997558594,30.569999694824),
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-32.840000152588,85.809997558594,32.779998779297),
				RenderInner_Size	=	1,
				UseSprite	=	true,
				RenderInner	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(35.549999237061,85.699996948242,30.909999847412),
					Pos2	=	Vector(30.629999160767,85.699996948242,34.330001831055),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(36.049999237061,85.699996948242,34.330001831055),
					Pos3	=	Vector(31.129999160767,85.699996948242,30.409999847412),
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(33.340000152588,85.699996948242,32.619998931885),
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				ReducedVis	=	true,
				RenderInner_Size	=	1,
				UseSprite	=	true,
				Pos	=	Vector(-43.25,75.660003662109,29.629999160767),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	53,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-42.110000610352,79.580001831055,29.60000038147),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Beta_Inner3D	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				ReducedVis	=	true,
				RenderInner_Size	=	1,
				Beta_Inner3D	=	true,
				Pos	=	Vector(43.669998168945,75.620002746582,29.409999847412),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	53,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(42.529998779297,79.540000915527,29.379999160767),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseSprite	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner	=	true,
				UseRunning	=	true,
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(21.610000610352,-100.94000244141,37.290000915527),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	95,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(25.209999084473,-99.569999694824,37.150001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.930000305176,-98.830001831055,37.049999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.75,-98.419998168945,37),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.579999923706,-97.919998168945,36.930000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.790000915527,-97.089996337891,36.810001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.940000534058,-96.209999084473,36.700000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.409999847412,-95.830001831055,36.650001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.959999084473,-95.339996337891,36.599998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.450000762939,-94.849998474121,36.549999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.319999694824,-93.949996948242,36.439998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.169998168945,-92.970001220703,36.330001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.290000915527,-91.529998779297,36.159999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.270000457764,-90.150001525879,35.990001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37,-89.040000915527,35.840000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.669998168945,-87.870002746582,35.689998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(38.419998168945,-86.480003356934,35.5),
								},
							{
							Pos	=	Vector(39.459999084473,-84.379997253418,35.200000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_Clr	=	{
					r	=	200,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				UseBlinkers	=	true,
				BlinkersColor	=	{
					r	=	55,
					b	=	0,
					a	=	255,
					g	=	255,
						},
				RenderType	=	2,
				ReducedVis	=	true,
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.01,
						},
				UseSprite	=	true,
				Pos	=	Vector(-15.619999885559,24.290000915527,42.049999237061),
				Beta_Inner3D	=	true,
				RenderMLCenter	=	true,
				BlinkerRight	=	true,
				SpecRec	=	{
					Use	=	true,
					Pos2	=	Vector(-15.710000038147,24.260000228882,42.069999694824),
					Pos4	=	Vector(-15.680000305176,24.239999771118,42.020000457764),
					Pos1	=	Vector(-15.680000305176,24.260000228882,42.069999694824),
					Pos3	=	Vector(-15.720000267029,24.239999771118,42.020000457764),
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/indicator_single",
					Pos4	=	Vector(-15.470000267029,24.170000076294,41.75),
					UseColor	=	true,
					Pos2	=	Vector(-15.920000076294,24.329999923706,42.340000152588),
					Color	=	{
						r	=	55,
						b	=	0,
						a	=	255,
						g	=	255,
							},
					Use	=	true,
					Pos1	=	Vector(-15.470000267029,24.329999923706,42.340000152588),
					Pos3	=	Vector(-15.930000305176,24.170000076294,41.75),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.01,
						},
				SpecRec	=	{
					Pos4	=	Vector(-16.229999542236,24.280000686646,42.189998626709),
					Pos2	=	Vector(-16.290000915527,24.270000457764,42.130001068115),
					Use	=	true,
					Pos1	=	Vector(-16.229999542236,24.270000457764,42.130001068115),
					Pos3	=	Vector(-16.290000915527,24.280000686646,42.189998626709),
						},
				RenderType	=	2,
				HBeamColor	=	{
					r	=	150,
					b	=	255,
					a	=	255,
					g	=	150,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-16.260000228882,24.299999237061,42.159999847412),
				UseHighBeams	=	true,
				Beta_Inner3D	=	true,
				RenderMLCenter	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/highbeam",
					Pos4	=	Vector(-16.450000762939,24.239999771118,41.970001220703),
					UseColor	=	true,
					Pos2	=	Vector(-16.069999694824,24.309999465942,42.349998474121),
					Color	=	{
						r	=	150,
						b	=	255,
						a	=	255,
						g	=	150,
							},
					Use	=	true,
					Pos1	=	Vector(-16.450000762939,24.309999465942,42.349998474121),
					Pos3	=	Vector(-16.069999694824,24.239999771118,41.970001220703),
						},
					},
				{
				UseBlinkers	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/indicator_single",
					Pos4	=	Vector(-17.049999237061,24.170000076294,41.75),
					UseColor	=	true,
					Pos2	=	Vector(-16.60000038147,24.329999923706,42.340000152588),
					Color	=	{
						r	=	55,
						b	=	0,
						a	=	255,
						g	=	255,
							},
					Use	=	true,
					Pos1	=	Vector(-17.049999237061,24.329999923706,42.340000152588),
					Pos3	=	Vector(-16.590000152588,24.170000076294,41.75),
						},
				RenderType	=	2,
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-16.89999961853,24.290000915527,42.049999237061),
				RenderMLCenter	=	true,
				SpecRec	=	{
					Use	=	true,
					Pos2	=	Vector(-16.809999465942,24.260000228882,42.069999694824),
					Pos4	=	Vector(-16.840000152588,24.239999771118,42.020000457764),
					Pos1	=	Vector(-16.840000152588,24.260000228882,42.069999694824),
					Pos3	=	Vector(-16.799999237061,24.239999771118,42.020000457764),
						},
				Beta_Inner3D	=	true,
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.01,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				BlinkersColor	=	{
					r	=	55,
					b	=	0,
					a	=	255,
					g	=	255,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.01,
						},
				UseLowBeams	=	true,
				SpecRec	=	{
					Use	=	true,
					Pos2	=	Vector(-20.35000038147,23.799999237061,39.139999389648),
					Pos4	=	Vector(-20.370000839233,23.799999237061,39.110000610352),
					Pos1	=	Vector(-20.370000839233,23.809999465942,39.139999389648),
					Pos3	=	Vector(-20.35000038147,23.809999465942,39.110000610352),
						},
				RenderType	=	2,
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				LBeamColor	=	{
					r	=	55,
					b	=	0,
					a	=	255,
					g	=	255,
						},
				Pos	=	Vector(-20.360000610352,23.85000038147,39.099998474121),
				UseSprite	=	true,
				RenderMLCenter	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				Spec3D	=	{
					Mat	=	"vcmod/gui/icons/dashboard/lowbeams.png",
					Pos4	=	Vector(-20.64999961853,23.75,38.880001068115),
					UseColor	=	true,
					Pos2	=	Vector(-20.129999160767,23.909999847412,39.380001068115),
					Color	=	{
						r	=	55,
						b	=	0,
						a	=	255,
						g	=	255,
							},
					Use	=	true,
					Pos1	=	Vector(-20.629999160767,23.89999961853,39.380001068115),
					Pos3	=	Vector(-20.120000839233,23.75,38.830001831055),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.01,
						},
				Spec3D	=	{
					Mat	=	"vcmod/dashboard/running_light",
					Pos4	=	Vector(-28.579999923706,18.959999084473,34.840000152588),
					UseColor	=	true,
					Pos2	=	Vector(-28.39999961853,19.010000228882,35),
					Color	=	{
						r	=	200,
						b	=	255,
						a	=	255,
						g	=	225,
							},
					Use	=	true,
					Pos1	=	Vector(-28.579999923706,19.010000228882,35),
					Pos3	=	Vector(-28.39999961853,18.959999084473,34.840000152588),
						},
				RenderType	=	2,
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-28.489999771118,19.020000457764,34.900001525879),
				RenderMLCenter	=	true,
				RunningColor	=	{
					r	=	200,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.005,
						},
				SpecRec	=	{
					Use	=	true,
					Pos2	=	Vector(-29.420000076294,19.520000457764,35.200000762939),
					Pos4	=	Vector(-29.430000305176,19.520000457764,35.200000762939),
					Pos1	=	Vector(-29.430000305176,19.520000457764,35.200000762939),
					Pos3	=	Vector(-29.420000076294,19.520000457764,35.200000762939),
						},
				RenderType	=	2,
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-29.450000762939,19.549999237061,35.180000305176),
				Spec3D	=	{
					Mat	=	"vcmod/dashboard/fog_light",
					Pos4	=	Vector(-29.559999465942,19.469999313354,35.060001373291),
					UseColor	=	true,
					Pos2	=	Vector(-29.290000915527,19.569999694824,35.340000152588),
					Color	=	{
						r	=	200,
						b	=	255,
						a	=	255,
						g	=	225,
							},
					Use	=	true,
					Pos1	=	Vector(-29.559999465942,19.549999237061,35.349998474121),
					Pos3	=	Vector(-29.290000915527,19.489999771118,35.049999237061),
						},
				RunningColor	=	{
					r	=	200,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseRunning	=	true,
				UseSprite	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.005,
						},
				SpecRec	=	{
					Pos4	=	Vector(-27.969999313354,19.680000305176,35.889999389648),
					Pos2	=	Vector(-27.959999084473,19.680000305176,35.889999389648),
					Use	=	true,
					Pos1	=	Vector(-27.969999313354,19.680000305176,35.889999389648),
					Pos3	=	Vector(-27.959999084473,19.680000305176,35.889999389648),
						},
				RenderType	=	2,
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-27.989999771118,19.709999084473,35.869998931885),
				Spec3D	=	{
					Mat	=	"vcmod/lights/positionlights",
					Pos4	=	Vector(-28.129999160767,19.709999084473,35.689998626709),
					UseColor	=	true,
					Pos2	=	Vector(-27.799999237061,19.790000915527,36.090000152588),
					Color	=	{
						r	=	200,
						b	=	255,
						a	=	255,
						g	=	225,
							},
					Use	=	true,
					Pos1	=	Vector(-28.129999160767,19.790000915527,36.090000152588),
					Pos3	=	Vector(-27.799999237061,19.709999084473,35.689998626709),
						},
				RunningColor	=	{
					r	=	200,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseRunning	=	true,
				Beta_Inner3D	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.005,
						},
				SpecRec	=	{
					Use	=	true,
					Pos2	=	Vector(-27.639999389648,19.639999389648,35.430000305176),
					Pos4	=	Vector(-27.639999389648,19.639999389648,35.430000305176),
					Pos1	=	Vector(-27.639999389648,19.629999160767,35.430000305176),
					Pos3	=	Vector(-27.639999389648,19.639999389648,35.430000305176),
						},
				RenderType	=	2,
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-27.639999389648,19.60000038147,35.409999847412),
				Spec3D	=	{
					Mat	=	"vcmod/dashboard/low_beam",
					Pos4	=	Vector(-27.790000915527,19.620000839233,35.310001373291),
					UseColor	=	true,
					Pos2	=	Vector(-27.489999771118,19.659999847412,35.549999237061),
					Color	=	{
						r	=	200,
						b	=	255,
						a	=	255,
						g	=	225,
							},
					Use	=	true,
					Pos1	=	Vector(-27.790000915527,19.670000076294,35.549999237061),
					Pos3	=	Vector(-27.489999771118,19.60000038147,35.310001373291),
						},
				RunningColor	=	{
					r	=	200,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseRunning	=	true,
				UseSprite	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.005,
						},
				RenderMLCenter	=	true,
				RunningColor	=	{
					r	=	200,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderType	=	2,
				UseRunning	=	true,
				ReducedVis	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-28.479999542236,19.309999465942,35.619998931885),
				UseSprite	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	3,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-28.479999542236,19.329999923706,35.669998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-29.139999389648,84.019996643066,35.090000152588),
				RenderInner	=	true,
				RenderInner_Size	=	2,
				SpecMLine	=	{
					Amount	=	75,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-29.049999237061,84.839996337891,34.470001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.059999465942,85.610000610352,33.840000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.159999847412,86.339996337891,33.25),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.360000610352,87.019996643066,32.669998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.680000305176,87.680000305176,32.069999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.379999160767,88.430000305176,31.290000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.219999313354,88.910003662109,30.64999961853),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.920000076294,89.069999694824,30.35000038147),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.020000457764,89,30.129999160767),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.709999084473,88.75,30.120000839233),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.759998321533,88.160003662109,30.239999771118),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.639999389648,87.410003662109,30.520000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.389999389648,86.720001220703,30.829999923706),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.060001373291,85.800003051758,31.409999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.569999694824,84.959999084473,31.959999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.110000610352,83.76000213623,32.799999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.409999847412,82.660003662109,33.630001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.470001220703,81.470001220703,34.689998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.360000610352,80.629997253418,35.490001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.090000152588,79.879997253418,36.279998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.549999237061,79.019996643066,37.229999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.029998779297,78.569999694824,37.790000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.509998321533,78.290000915527,38.25),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.930000305176,78.150001525879,38.580001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.380001068115,78.040000915527,38.729999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.619998931885,78.150001525879,38.840000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.779998779297,78.330001831055,38.869998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.020000457764,78.660003662109,38.740001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.159999847412,79.180000305176,38.459999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.170000076294,79.930000305176,37.919998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.379999160767,80.949996948242,37.25),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.559999465942,82.430000305176,36.209999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.309999465942,83.169998168945,35.720001220703),
								},
							{
							Pos	=	Vector(-29.180000305176,83.830001831055,35.209999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
					r	=	200,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderMLCenter	=	true,
					},
				{
				UseBlinkers	=	true,
				DD_Blnk_Run	=	true,
				UseDynamic	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RenderMLCenter	=	true,
				Beta_Inner3D	=	true,
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-35.490001678467,96.599998474121,21.969999313354),
				RenderInner_Size	=	1,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	35,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-22.760000228882,104.36000061035,21.64999961853),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RunningColor	=	{
					r	=	200,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.0525,
						},
					},
				{
				UseBlinkers	=	true,
				DD_Blnk_Run	=	true,
				UseDynamic	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RenderMLCenter	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-35.569999694824,96.599998474121,23.389999389648),
				UseSprite	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	35,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-23.35000038147,104.25,23.139999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Size	=	1,
				RunningColor	=	{
					r	=	200,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.0514,
						},
					},
				},
		Copyright	=	"Copyright © 2012-2019 VCMod (freemmaann). All Rights Reserved.",
		Fuel	=	{
			FuelLidPos	=	Vector(41,45.319999694824,38.580001831055),
			FuelLidUse	=	true,
			FuelType	=	0,
			Capacity	=	68,
			FuelTypeUse	=	true,
			Override	=	true,
				},
		Author	=	"DangerKiddy(DK) (76561198132964487)",
}