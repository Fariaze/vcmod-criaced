VCModels['models/crsk_autoszil130_bortovoi.mdl']	=	{
		IsBig	=	true,
		em_state	=	5236594875,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Copyright	=	"Copyright © 2012-2017 VCMod (freemmaann). All Rights Reserved.",
		Exhaust	=	{
				{
				Ang	=	Angle(75,-145,0),
				Pos	=	Vector(-18.420000076294,-55.209999084473,23.39999961853),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust_Truck",
					},
				},
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Use	=	true,
					UseColor	=	true,
					Pos2	=	Vector(33.25,121.25,56.020000457764),
					Color	=	{
							255,
							225,
							200,
							},
					Pos4	=	Vector(43.709999084473,121.25,45.560001373291),
					Pos1	=	Vector(43.709999084473,121.25,56.020000457764),
					Pos3	=	Vector(33.25,121.25,45.560001373291),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(38.479999542236,121.25,50.790000915527),
				UseDynamic	=	true,
				UseRunning	=	true,
				UseSprite	=	true,
				RunningColor	=	{
						255,
						175,
						100,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(41.529998779297,-155.94999694824,40.759998321533),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(44.119998931885,-156.11999511719,38.169998168945),
					Pos2	=	Vector(38.939998626709,-155.91999816895,43.349998474121),
					Color	=	{
							0,
							0,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(44.119998931885,-155.66000366211,43.349998474121),
					Pos3	=	Vector(38.939998626709,-156.2799987793,38.169998168945),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(39.080001831055,121.26999664307,59.720001220703),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(51.299999237061,107.13999938965,62.990001678467),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(38.069999694824,-156.11999511719,38.169998168945),
					Pos2	=	Vector(32.889999389648,-155.91999816895,43.349998474121),
					Color	=	{
							0,
							0,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(38.069999694824,-155.66000366211,43.349998474121),
					Pos3	=	Vector(32.889999389648,-156.2799987793,38.169998168945),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(35.5,-155.94999694824,40.759998321533),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(32.389999389648,-156.11999511719,38.169998168945),
					Pos2	=	Vector(27.209999084473,-155.91999816895,43.349998474121),
					Color	=	{
							0,
							0,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(32.389999389648,-155.66000366211,43.349998474121),
					Pos3	=	Vector(27.209999084473,-156.2799987793,38.169998168945),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(29.819999694824,-155.94999694824,40.759998321533),
				UseDynamic	=	true,
				UseBrake	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Use	=	true,
					UseColor	=	true,
					Pos2	=	Vector(33.290000915527,121.25,56.020000457764),
					Color	=	{
							255,
							225,
							200,
							},
					Pos4	=	Vector(43.75,121.25,45.560001373291),
					Pos1	=	Vector(43.75,121.25,56.020000457764),
					Pos3	=	Vector(33.290000915527,121.25,45.560001373291),
						},
				Beta_Inner3D	=	true,
				HBeamColor	=	{
						255,
						175,
						100,
						},
				ReducedVis	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UsePrjTex	=	true,
				LBeamColor	=	{
						255,
						175,
						100,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Pos	=	Vector(38.520000457764,121.25,50.790000915527),
				UseSprite	=	true,
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Use	=	true,
					UseColor	=	true,
					Pos2	=	Vector(-32.619998931885,121.25,56.020000457764),
					Color	=	{
							255,
							225,
							200,
							},
					Pos4	=	Vector(-43.080001831055,121.25,45.560001373291),
					Pos1	=	Vector(-43.080001831055,121.25,56.020000457764),
					Pos3	=	Vector(-32.619998931885,121.25,45.560001373291),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-37.849998474121,121.25,50.790000915527),
				UseDynamic	=	true,
				UseRunning	=	true,
				UseSprite	=	true,
				RunningColor	=	{
						255,
						175,
						100,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-43,-155.94999694824,40.759998321533),
				UseDynamic	=	true,
				UseSprite	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-45.590000152588,-156.11999511719,38.169998168945),
					Pos2	=	Vector(-40.409999847412,-155.91999816895,43.349998474121),
					Color	=	{
							0,
							0,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(-45.590000152588,-155.66000366211,43.349998474121),
					Pos3	=	Vector(-40.409999847412,-156.2799987793,38.169998168945),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-38.099998474121,121.26999664307,59.720001220703),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-50.680000305176,107.13999938965,62.990001678467),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-39.810001373291,-156.11999511719,38.169998168945),
					Pos2	=	Vector(-34.630001068115,-155.91999816895,43.349998474121),
					Color	=	{
							0,
							0,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(-39.810001373291,-155.66000366211,43.349998474121),
					Pos3	=	Vector(-34.630001068115,-156.2799987793,38.169998168945),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-37.240001678467,-155.94999694824,40.759998321533),
				UseDynamic	=	true,
				UseSprite	=	true,
				UseRunning	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-33.990001678467,-156.11999511719,38.169998168945),
					Pos2	=	Vector(-28.809999465942,-155.91999816895,43.349998474121),
					Color	=	{
							0,
							0,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(-33.990001678467,-155.66000366211,43.349998474121),
					Pos3	=	Vector(-28.809999465942,-156.2799987793,38.169998168945),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-31.420000076294,-155.94999694824,40.759998321533),
				UseDynamic	=	true,
				UseBrake	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Use	=	true,
					UseColor	=	true,
					Pos2	=	Vector(-32.709999084473,121.25,56.020000457764),
					Color	=	{
							255,
							225,
							200,
							},
					Pos4	=	Vector(-43.169998168945,121.25,45.560001373291),
					Pos1	=	Vector(-43.169998168945,121.25,56.020000457764),
					Pos3	=	Vector(-32.709999084473,121.25,45.560001373291),
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				HBeamColor	=	{
						255,
						175,
						100,
						},
				UsePrjTex	=	true,
				LBeamColor	=	{
						255,
						175,
						100,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Pos	=	Vector(-37.939998626709,121.25,50.790000915527),
				Beta_Inner3D	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseSprite	=	true,
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(12,0,0),
				Pos	=	Vector(3.0799999237061,31.659999847412,69.680000305176),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(12,0,0),
				Pos	=	Vector(24.860000610352,31.659999847412,69.680000305176),
				RadioControl	=	true,
					},
				},
		DLT	=	3491063250,
		Sound_Airbrake	=	true,
		Date	=	"Thu Aug 10 14:34:12 2017",
		Fuel	=	{
			FuelLidPos	=	Vector(-48.630001068115,-24.079999923706,49.509998321533),
			Override	=	true,
			FuelType	=	0,
			Capacity	=	175,
			FuelLidUse	=	true,
			FuelTypeUse	=	true,
				},
		Author	=	"CrushingSkirmish (76561198017348899)",
}