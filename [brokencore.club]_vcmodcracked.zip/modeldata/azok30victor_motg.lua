VCModels['models/azok30victor_motg.mdl']	=	{
		em_state	=	5236594737,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Siren	=	{
			Sounds	=	{
					{
					Volume	=	1,
					Pitch	=	100,
					Distance	=	100,
					Name	=	"DEUX TONS",
					Sound	=	"els_fr/fr_gendarmerie.wav",
						},
					},
			Sequences	=	{
					{
					SubSeq	=	{
							{
							Stages	=	{
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.5,
											},
									Lights	=	{
											1,
											3,
											4,
											},
									Time	=	0.5,
										},
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.5,
											},
									Lights	=	{
											2,
											3,
											4,
											},
									Time	=	0.5,
										},
									},
							Time	=	0.5,
							Type	=	"Custom",
								},
							},
					Codes	=	{
							true,
							},
					Lights_Sel	=	{
							true,
							true,
							true,
							true,
							},
						},
					},
			Lights	=	{
					{
					Sprite	=	{
						GlowPrxSize	=	1.169,
						Size	=	0.292,
							},
					Dynamic	=	{
						Size	=	0.6,
						Brightness	=	2.1,
							},
					SpecRec	=	{
						AmountV	=	3,
						Use	=	true,
						Pos2	=	Vector(14.470000267029,28.069999694824,36.840000152588),
						AmountH	=	6,
						Pos4	=	Vector(20.020000457764,28.069999694824,35.779998779297),
						Pos1	=	Vector(19.969999313354,28.129999160767,36.840000152588),
						Pos3	=	Vector(14.479999542236,28.069999694824,35.830001831055),
							},
					UseSprite	=	true,
					SpecModel	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
						scale	=	1,
						scaleVector	=	Vector(1000,1000,1000),
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(17.270000457764,28.069999694824,36.380001068115),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
						r	=	0,
						b	=	255,
						a	=	255,
						g	=	17,
							},
					RenderInner_Size	=	1,
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner_ClrUse	=	false,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	1.169,
						Size	=	0.292,
							},
					Dynamic	=	{
						Size	=	0.6,
						Brightness	=	2.1,
							},
					SpecRec	=	{
						Use	=	true,
						AmountV	=	3,
						Pos2	=	Vector(-14.470000267029,28.069999694824,36.840000152588),
						AmountH	=	6,
						Pos4	=	Vector(-20.020000457764,28.069999694824,35.779998779297),
						Pos1	=	Vector(-19.969999313354,28.129999160767,36.840000152588),
						Pos3	=	Vector(-14.479999542236,28.069999694824,35.830001831055),
							},
					RenderHD_Adv	=	true,
					SpecModel	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
						scale	=	1,
						scaleVector	=	Vector(1000,1000,1000),
							},
					UseSprite	=	true,
					Pos	=	Vector(-17.270000457764,28.069999694824,36.380001068115),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
						r	=	0,
						b	=	255,
						a	=	255,
						g	=	17,
							},
					RenderInner_Size	=	1,
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner_ClrUse	=	false,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	1.169,
						Size	=	0.2802,
							},
					SpecSpin	=	{
						Use	=	true,
						Speed	=	708,
						Intensity	=	1,
							},
					Spec3D	=	{
						Mat	=	"vcmod/circle",
						Pos4	=	Vector(2.7400000095367,-41.599998474121,55.599998474121),
						Pos2	=	Vector(2.2400000095367,-41.599998474121,56.099998474121),
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
						Use	=	true,
						Pos1	=	Vector(2.7400000095367,-41.599998474121,56.099998474121),
						Pos3	=	Vector(2.2400000095367,-41.599998474121,55.599998474121),
							},
					Dynamic	=	{
						Size	=	1.3656,
						Brightness	=	2.1,
							},
					SpecModel	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
						scale	=	1,
						scaleVector	=	Vector(1000,1000,1000),
							},
					UseSprite	=	true,
					RenderHD_Adv	=	true,
					Pos	=	Vector(2.4900000095367,-42.599998474121,55.599998474121),
					UseDynamic	=	true,
					RenderInner_Size	=	1,
					Color	=	{
						r	=	0,
						b	=	255,
						a	=	255,
						g	=	17,
							},
					RenderInner	=	true,
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner_ClrUse	=	false,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	1.169,
						Size	=	0,
							},
					Dynamic	=	{
						Size	=	1.3656,
						Brightness	=	2.1,
							},
					SpecRec	=	{
						Use	=	true,
						AmountV	=	6,
						Pos2	=	Vector(2.7200000286102,-42.419998168945,55.610000610352),
						AmountH	=	14,
						Pos4	=	Vector(1.8200000524521,-42.950000762939,54.889999389648),
						Pos1	=	Vector(1.8099999427795,-42.689998626709,55.639999389648),
						Pos3	=	Vector(3.7699999809265,-39.229999542236,55.490001678467),
							},
					RenderHD_Adv	=	true,
					RenderInner_Size	=	1,
					UseSprite	=	true,
					Pos	=	Vector(2.4900000095367,-42.599998474121,55.599998474121),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
						r	=	0,
						b	=	255,
						a	=	255,
						g	=	17,
							},
					SpecModel	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
						scale	=	1,
						scaleVector	=	Vector(1000,1000,1000),
							},
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner_ClrUse	=	false,
						},
					},
				},
		Copyright	=	"Copyright © 2012-2019 VCMod (freemmaann). All Rights Reserved.",
		Exhaust	=	{
				{
				EffectStress	=	"VC_Exhaust_Stress",
				Invulnerable	=	true,
				EffectIdle	=	"VC_Exhaust",
				Ang	=	Angle(-15,-90,0),
				Pos	=	Vector(9.0600004196167,-60.299999237061,19.389999389648),
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(0,-31.459999084473,37.299999237061),
				RadioControl	=	true,
					},
				},
		DLT	=	3491063158,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseSprite	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				Pos	=	Vector(-5.710000038147,32.150001525879,31.020000457764),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseSprite	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				Pos	=	Vector(5.710000038147,32.150001525879,31.020000457764),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				HBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UsePrjTex	=	true,
				Pos	=	Vector(-5.710000038147,32.150001525879,31.020000457764),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				HBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UsePrjTex	=	true,
				Pos	=	Vector(5.710000038147,32.150001525879,31.020000457764),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				UseSprite	=	true,
				Pos	=	Vector(-12.279999732971,24,24.139999389648),
				UseDynamic	=	true,
				RenderInner_Size	=	3.7069,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-10.069999694824,28.170000076294,23.040000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-11.189999580383,25.549999237061,21.790000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-12.279999732971,24,24.139999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				UseSprite	=	true,
				Pos	=	Vector(12.279999732971,24,24.139999389648),
				UseDynamic	=	true,
				RenderInner_Size	=	3.7069,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(10.069999694824,28.170000076294,23.040000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(11.189999580383,25.549999237061,21.790000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(12.279999732971,24,24.139999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				UseSprite	=	true,
				Pos	=	Vector(-6.5100002288818,-49.099998474121,31.940000534058),
				UseDynamic	=	true,
				RenderInner_Size	=	3.7069,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-7.3600001335144,-46.459999084473,30.950000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				UseSprite	=	true,
				Pos	=	Vector(6.5100002288818,-49.099998474121,31.940000534058),
				UseDynamic	=	true,
				RenderInner_Size	=	3.7069,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(7.3600001335144,-46.459999084473,30.950000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Size	=	3.7069,
				UseSprite	=	true,
				Pos	=	Vector(4.4499998092651,-50.560001373291,35.130001068115),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-4.3400001525879,-51.400001525879,35.509998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(4.4499998092651,-50.560001373291,35.130001068115),
				UseDynamic	=	true,
				RenderInner_Size	=	3.7069,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-4.3400001525879,-51.400001525879,35.509998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	true,
					},
				},
		Date	=	"Sat Oct  5 12:24:19 2019",
		Fuel	=	{
			FuelType	=	0,
				},
		Author	=	"Krys (76561198159585387)",
}