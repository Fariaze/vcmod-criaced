VCModels['models/crsk_autosalfaromeogiulia_quadrifoglio_2017.mdl']	=	{
		em_state	=	5236594713,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Copyright	=	"Copyright © 2012-2017 VCMod (freemmaann). All Rights Reserved.",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-24.979999542236,-117.86000061035,14.569999694824),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(24.219999313354,-117.86000061035,14.569999694824),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-30.020000457764,-117.86000061035,13.560000419617),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(29.190000534058,-117.86000061035,13.560000419617),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(20,0,0),
				Pos	=	Vector(16.889999389648,3.9400000572205,28.879999160767),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(20,0,0),
				Pos	=	Vector(-16.639999389648,-39.360000610352,29.819999694824),
					},
				{
				Ang	=	Angle(20,0,0),
				Pos	=	Vector(15.569999694824,-39.360000610352,29.819999694824),
					},
				{
				Ang	=	Angle(20,0,0),
				Pos	=	Vector(0,-39.360000610352,29.819999694824),
					},
				},
		DLT	=	3491063142,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.0662,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RenderInner_Size	=	1.3129,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseBrake	=	true,
				SpecMat	=	{
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-17.180000305176,-116.06999969482,40.779998779297),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	64,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-28.670000076294,-111.87000274658,41.270000457764),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.0662,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RenderInner_Size	=	1.3129,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseBrake	=	true,
				SpecMat	=	{
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(17.180000305176,-116.06999969482,40.779998779297),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	64,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(28.670000076294,-111.87000274658,41.270000457764),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.0662,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RenderInner	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseBrake	=	true,
				SpecMat	=	{
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-28.950000762939,-111.33999633789,36.439998626709),
				UseDynamic	=	true,
				RenderInner_Size	=	1.3129,
				SpecMLine	=	{
					Amount	=	64,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-33.709999084473,-107.88999938965,37.659999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.669998168945,-106,38.409999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.25,-103.51000213623,39.5),
								},
							{
							Pos	=	Vector(-37.520000457764,-101.69000244141,41.209999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.310001373291,-103.87000274658,41.259998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.470001220703,-106.55000305176,41.330001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.700000762939,-108.37000274658,41.330001831055),
								},
							{
							Pos	=	Vector(-30.510000228882,-110.11000061035,41.330001831055),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.0662,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RenderInner_Size	=	1.3129,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseBrake	=	true,
				SpecMat	=	{
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(28.950000762939,-111.33999633789,36.439998626709),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	64,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(33.709999084473,-107.88999938965,37.659999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.669998168945,-106,38.409999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.25,-103.51000213623,39.5),
								},
							{
							Pos	=	Vector(37.520000457764,-101.69000244141,41.209999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.310001373291,-103.87000274658,41.259998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.470001220703,-106.55000305176,41.330001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.700000762939,-108.37000274658,41.330001831055),
								},
							{
							Pos	=	Vector(30.510000228882,-110.11000061035,41.330001831055),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecMat	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(34.930000305176,-106.06999969482,39.150001525879),
					Pos2	=	Vector(29.790000915527,-111.58000183105,40.090000152588),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(35.840000152588,-106.19000244141,40.380001068115),
					Pos3	=	Vector(29.290000915527,-111.56999969482,37.650001525879),
						},
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(32.180000305176,-108.75,39.049999237061),
				UseDynamic	=	true,
				RenderInner_Size	=	1.3129,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-34.930000305176,-106.06999969482,39.150001525879),
					Pos2	=	Vector(-29.930000305176,-111.58000183105,40.290000915527),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-35.840000152588,-106.19000244141,40.380001068115),
					Pos3	=	Vector(-29.569999694824,-111.56999969482,37.75),
						},
				SpecMat	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-32.180000305176,-108.75,39.049999237061),
				UseDynamic	=	true,
				RenderInner_Size	=	1.3129,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RenderInner_Size	=	1.3129,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(24.010000228882,-114.19000244141,37.509998321533),
					Pos2	=	Vector(17.909999847412,-115.61000061035,40.349998474121),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(24.670000076294,-113.33000183105,40.25),
					Pos3	=	Vector(17.969999313354,-115.62000274658,39.209999084473),
						},
				FogColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(21.680000305176,-114.98999786377,39.169998168945),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseFog	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RenderInner	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-24.010000228882,-114.19000244141,37.509998321533),
					Pos2	=	Vector(-17.909999847412,-115.61000061035,40.349998474121),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-24.670000076294,-113.33000183105,40.25),
					Pos3	=	Vector(-17.969999313354,-115.62000274658,39.209999084473),
						},
				FogColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-21.680000305176,-114.98999786377,39.169998168945),
				UseDynamic	=	true,
				RenderInner_Size	=	1.3129,
				UseFog	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.0375,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseRunning	=	true,
				SpecMat	=	{
						},
				RunningColor	=	{
					r	=	200,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-30.409999847412,88.370002746582,31.719999313354),
				UseDynamic	=	true,
				RenderInner_Size	=	1.3129,
				SpecMLine	=	{
					Amount	=	236,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-26.780000686646,90.730003356934,31.170000076294),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-16.760000228882,96.230003356934,29.709999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-17.639999389648,95.910003662109,29.020000457764),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-22.889999389648,92.75,29.049999237061),
								},
							{
							Pos	=	Vector(-23.959999084473,92.25,30.239999771118),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.0375,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseRunning	=	true,
				SpecMat	=	{
						},
				RunningColor	=	{
					r	=	200,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(30.89999961853,88.370002746582,31.670000076294),
				UseDynamic	=	true,
				RenderInner_Size	=	1.3129,
				SpecMLine	=	{
					Amount	=	236,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(27.270000457764,90.730003356934,31.120000839233),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(17.25,96.230003356934,29.659999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(18.129999160767,95.910003662109,28.969999313354),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							UseClr	=	false,
							Pos	=	Vector(23.379999160767,92.75,29),
								},
							{
							Pos	=	Vector(24.450000762939,92.25,30.190000534058),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-27.5,-113.80000305176,37.619998931885),
					Pos2	=	Vector(-24.540000915527,-114.55000305176,40.029998779297),
					Color	=	{
						r	=	195,
						b	=	225,
						a	=	255,
						g	=	195,
							},
					Use	=	true,
					Pos1	=	Vector(-28.180000305176,-113.09999847412,40.159999847412),
					Pos3	=	Vector(-23.709999084473,-114.7799987793,37.430000305176),
						},
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-26.25,-114.40000152588,38.880001068115),
				UseDynamic	=	true,
				RenderInner_Size	=	1.3129,
				ReverseColor	=	{
					r	=	195,
					b	=	225,
					a	=	255,
					g	=	195,
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(27.5,-113.80000305176,37.619998931885),
					Pos2	=	Vector(24.540000915527,-114.55000305176,40.029998779297),
					Color	=	{
						r	=	195,
						b	=	225,
						a	=	255,
						g	=	195,
							},
					Use	=	true,
					Pos1	=	Vector(28.180000305176,-113.09999847412,40.159999847412),
					Pos3	=	Vector(23.709999084473,-114.7799987793,37.430000305176),
						},
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(26.25,-114.40000152588,38.880001068115),
				UseDynamic	=	true,
				RenderInner	=	true,
				ReverseColor	=	{
					r	=	195,
					b	=	225,
					a	=	255,
					g	=	195,
						},
				RenderInner_Size	=	1.3129,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.0662,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				UseBrake	=	true,
				RenderInner_Size	=	1.3129,
				UseSprite	=	true,
				Pos	=	Vector(6.5599999427795,-94.23999786377,51.330001831055),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	64,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-6.9000000953674,-94.199996948242,51.349998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.02,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-45.770000457764,18.139999389648,46.419998168945),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	64,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-48.029998779297,14.470000267029,47.049999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-48.700000762939,12.170000076294,47.290000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Size	=	1.3129,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.02,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(46.099998474121,18.139999389648,46.189998626709),
				UseDynamic	=	true,
				RenderInner_Size	=	1.3129,
				SpecMLine	=	{
					Amount	=	64,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(48.360000610352,14.470000267029,46.819999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(49.029998779297,12.170000076294,47.060001373291),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecMat	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(38.799999237061,84.779998779297,29.909999847412),
					Pos2	=	Vector(40.139999389648,78.73999786377,33.029998779297),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(37.200000762939,86.569999694824,32.119998931885),
					Pos3	=	Vector(41.110000610352,78.050003051758,32.119998931885),
						},
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(39.669998168945,82.269996643066,31.739999771118),
				UseDynamic	=	true,
				RenderInner_Size	=	1.3129,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecMat	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-38.259998321533,84.779998779297,30.090000152588),
					Pos2	=	Vector(-39.720001220703,78.73999786377,33.209999084473),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-36.689998626709,86.569999694824,32.299999237061),
					Pos3	=	Vector(-40.810001373291,78.050003051758,32.299999237061),
						},
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-39.25,82.269996643066,31.920000076294),
				UseDynamic	=	true,
				RenderInner_Size	=	1.3129,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5.4621,
					Size	=	0.2,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.93,
					Brightness	=	1.9776,
						},
				UseSprite	=	true,
				Pos	=	Vector(-27.270000457764,90.839996337891,28.459999084473),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseHighBeams	=	true,
				RenderInner_Size	=	1.3129,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5.4621,
					Size	=	0.2,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.93,
					Brightness	=	1.9776,
						},
				UseSprite	=	true,
				Pos	=	Vector(-28.819999694824,89.76000213623,28.389999389648),
				UseDynamic	=	true,
				RenderInner_Size	=	1.3129,
				UseHighBeams	=	true,
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5.4621,
					Size	=	0.2,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.93,
					Brightness	=	1.9776,
						},
				UseSprite	=	true,
				Pos	=	Vector(-25.879999160767,91.970001220703,28.610000610352),
				UseDynamic	=	true,
				RenderInner_Size	=	1.3129,
				UseHighBeams	=	true,
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5.4621,
					Size	=	0.2,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.93,
					Brightness	=	1.9776,
						},
				UseSprite	=	true,
				Pos	=	Vector(-30.059999465942,88.889999389648,28.409999847412),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderInner_Size	=	1.3129,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5.4621,
					Size	=	0.8,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.7836,
					Brightness	=	1.9776,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-31.809999465942,87.819999694824,28.64999961853),
					Pos2	=	Vector(-35.009998321533,87.819999694824,31.85000038147),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-31.809999465942,87.819999694824,31.85000038147),
					Pos3	=	Vector(-35.009998321533,87.819999694824,28.64999961853),
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-33.409999847412,86.319999694824,30.25),
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1.3129,
				SpecMat	=	{
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5.4621,
					Size	=	0.2,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.93,
					Brightness	=	1.9776,
						},
				UseSprite	=	true,
				Pos	=	Vector(26.35000038147,91.919998168945,28.520000457764),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderInner_Size	=	1.3129,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5.4621,
					Size	=	0.2,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.93,
					Brightness	=	1.9776,
						},
				UseSprite	=	true,
				Pos	=	Vector(27.729999542236,90.839996337891,28.420000076294),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderInner_Size	=	1.3129,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5.4621,
					Size	=	0.2,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.9328,
					Brightness	=	1.9776,
						},
				UseSprite	=	true,
				Pos	=	Vector(29.25,89.76000213623,28.280000686646),
				UseDynamic	=	true,
				RenderInner_Size	=	1.3129,
				UseHighBeams	=	true,
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5.4621,
					Size	=	0.2,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.93,
					Brightness	=	1.9776,
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				ReducedVis	=	true,
				UseHighBeams	=	true,
				UseSprite	=	true,
				Pos	=	Vector(30.510000228882,88.889999389648,28.280000686646),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderInner_Size	=	1.3129,
				Beta_Inner3D	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5.4621,
					Size	=	0.8,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.7836,
					Brightness	=	1.9776,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(32.319999694824,87.669998168945,28.5),
					Pos2	=	Vector(35.520000457764,87.669998168945,31.700000762939),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(32.319999694824,87.669998168945,31.700000762939),
					Pos3	=	Vector(35.520000457764,87.669998168945,28.5),
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(33.919998168945,86.169998168945,30.10000038147),
				RenderInner	=	true,
				UseSprite	=	true,
				RenderInner_Size	=	1.3129,
				SpecMat	=	{
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				},
		Date	=	"Sat Dec 16 19:08:38 2017",
		Fuel	=	{
			FuelLidPos	=	Vector(-41.009998321533,-82.639999389648,41.790000915527),
			Override	=	true,
			FuelType	=	0,
			Capacity	=	58,
			FuelLidUse	=	true,
			FuelTypeUse	=	true,
				},
		Author	=	"CrushingSkirmish (76561198017348899)",
}