VCModels['models/crsk_autosvolvoxc90_t8_2015.mdl']	=	{
		em_state	=	5236594449,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		HealthEnginePosOvr	=	true,
		Date	=	"Fri Jun 29 23:20:40 2018",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(-29.829999923706,-144.30000305176,19.700000762939),
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(28.840000152588,-144.30000305176,19.440000534058),
				EffectIdle	=	"VC_Exhaust",
					},
				},
		Copyright	=	"Copyright © 2012-2018 VCMod (freemmaann). All Rights Reserved.",
		HealthEnginePos	=	Vector(0,53.299999237061,52.680000305176),
		DLT	=	3491062966,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.08,
						},
				SpecSpin	=	{
						},
				DD_Blnk_Run	=	true,
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2.1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					Select	=	15,
					New	=	"models\crskautos\volvo\xc90_t8_2015\int_symbols_on",
					Use	=	true,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-40.240001678467,76.129997253418,40.450000762939),
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	21,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-40.259998321533,75.459999084473,41.080001831055),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-40.470001220703,74.800003051758,42.020000457764),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-40.540000915527,74.080001831055,42.650001525879),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-40.569999694824,73.440002441406,43.180000305176),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-40.599998474121,72.580001831055,44.020000457764),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-40.650001525879,71.800003051758,44.669998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-40.729999542236,71.029998779297,45.360000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseBlinkers	=	true,
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.08,
						},
				SpecSpin	=	{
						},
				DD_Blnk_Run	=	true,
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2.1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					Select	=	11,
					New	=	"models\crskautos\volvo\xc90_t8_2015\runninglights_front_on",
					Use	=	true,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-26.370000839233,86.930000305176,41.590000152588),
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	31,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-27.870000839233,86.139999389648,41.709999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-29.479999542236,85.080001831055,41.860000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-31.049999237061,83.930000305176,41.970001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-32.759998321533,82.690002441406,42.189998626709),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-34.330001831055,81.519996643066,42.349998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-35.700000762939,80.139999389648,42.529998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-37.009998321533,78.839996337891,42.650001525879),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-38.560001373291,77.019996643066,42.720001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Pos	=	Vector(-40.020000457764,75.169998168945,42.869998931885),
							Size	=	0.1,
							UseClr	=	false,
								},
							},
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.035,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2.1,
						},
				SpecMat	=	{
					Select	=	7,
					New	=	"models\crskautos\volvo\xc90_t8_2015\reverselights_on",
					Use	=	true,
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-36.020000457764,-138.38000488281,52.919998168945),
				UseDynamic	=	true,
				RenderInner	=	true,
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				SpecMLine	=	{
					Amount	=	29,
					Use	=	true,
					LTbl	=	{
							{
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Pos	=	Vector(-38.090000152588,-136.80999755859,52.830001831055),
							Size	=	0.1,
							UseClr	=	false,
								},
							{
							Pos	=	Vector(-39.880001068115,-135.16000366211,52.880001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-40.470001220703,-133.7200012207,52.840000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-40.580001831055,-132.10000610352,52.779998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.03,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
					Select	=	9,
					New	=	"models\crskautos\volvo\xc90_t8_2015\running_rear_on",
					Use	=	true,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-40.319999694824,-132.61000061035,54.400001525879),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2.1,
						},
				SpecMLine	=	{
					Amount	=	54,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-39.900001525879,-134.61000061035,54.349998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-38.770000457764,-135.36000061035,55.229999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-37.849998474121,-136.11999511719,56.759998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-36.459999084473,-136.86000061035,57.830001831055),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-34.770000457764,-137.44999694824,59.159999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-33.060001373291,-136.99000549316,60.970001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-32.520000457764,-135.75,63.259998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-32.130001068115,-134.07000732422,64.98999786377),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-31.680000305176,-131.91999816895,67.01000213623),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-31.290000915527,-129.11999511719,69.589996337891),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-30.360000610352,-124.29000091553,73.620002746582),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.015,
						},
				SpecSpin	=	{
						},
				FogColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(-37.680000305176,-138.07000732422,46.990001678467),
				UseDynamic	=	true,
				UseFog	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
					},
				{
				Pos	=	Vector(-35.150001525879,-139.69999694824,54.119998931885),
				SpecMat	=	{
					Select	=	5,
					New	=	"models\crskautos\volvo\xc90_t8_2015\brake_lights_on",
					Use	=	true,
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseBrake	=	true,
				SpecSpin	=	{
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UsePrjTex	=	true,
				Pos	=	Vector(-32.720001220703,75.389999389648,43.919998168945),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2.1,
						},
				SpecMat	=	{
					Select	=	12,
					New	=	"models\crskautos\volvo\xc90_t8_2015\runninglights_front_on",
					Use	=	true,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseSprite	=	true,
				Pos	=	Vector(-30.420000076294,77.319999694824,43.919998168945),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2.1,
						},
				SpecMat	=	{
					Select	=	12,
					New	=	"models\crskautos\volvo\xc90_t8_2015\runninglights_front_on",
					Use	=	true,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				SpecMat	=	{
					Select	=	12,
					New	=	"models\crskautos\volvo\xc90_t8_2015\runninglights_front_on",
					Use	=	true,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseSprite	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2.1,
						},
				UsePrjTex	=	true,
				Pos	=	Vector(-36.130001068115,71.73999786377,44.169998168945),
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				SpecMat	=	{
					Select	=	12,
					New	=	"models\crskautos\volvo\xc90_t8_2015\runninglights_front_on",
					Use	=	true,
						},
				UseSprite	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2.1,
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Pos	=	Vector(-38.240001678467,71.279998779297,44.169998168945),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
					Select	=	12,
					New	=	"models\crskautos\volvo\xc90_t8_2015\runninglights_front_on",
					Use	=	true,
						},
				UseSprite	=	true,
				Pos	=	Vector(30.930000305176,77.319999694824,43.759998321533),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2.1,
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
					Select	=	12,
					New	=	"models\crskautos\volvo\xc90_t8_2015\runninglights_front_on",
					Use	=	true,
						},
				UsePrjTex	=	true,
				Pos	=	Vector(33.130001068115,75.389999389648,43.869998931885),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2.1,
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseSprite	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2.1,
						},
				UsePrjTex	=	true,
				Pos	=	Vector(36.610000610352,71.73999786377,43.959999084473),
				SpecMat	=	{
					Select	=	12,
					New	=	"models\crskautos\volvo\xc90_t8_2015\runninglights_front_on",
					Use	=	true,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseSprite	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				SpecMat	=	{
					Select	=	12,
					New	=	"models\crskautos\volvo\xc90_t8_2015\runninglights_front_on",
					Use	=	true,
						},
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2.1,
						},
				Pos	=	Vector(38.599998474121,71.279998779297,44.169998168945),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				SpecMat	=	{
					Select	=	12,
					New	=	"models\crskautos\volvo\xc90_t8_2015\runninglights_front_on",
					Use	=	true,
						},
				UseSprite	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2.1,
						},
				Pos	=	Vector(-37.290000915527,74.800003051758,40.459999084473),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseSprite	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				SpecMat	=	{
					Select	=	12,
					New	=	"models\crskautos\volvo\xc90_t8_2015\runninglights_front_on",
					Use	=	true,
						},
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2.1,
						},
				Pos	=	Vector(-35.139999389648,75.25,40.330001831055),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				SpecMat	=	{
					Select	=	12,
					New	=	"models\crskautos\volvo\xc90_t8_2015\runninglights_front_on",
					Use	=	true,
						},
				UseSprite	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2.1,
						},
				Pos	=	Vector(35.75,75.25,40.189998626709),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				SpecMat	=	{
					Select	=	12,
					New	=	"models\crskautos\volvo\xc90_t8_2015\runninglights_front_on",
					Use	=	true,
						},
				UseSprite	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2.1,
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Pos	=	Vector(37.669998168945,74.800003051758,40.340000152588),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.08,
						},
				SpecSpin	=	{
						},
				DD_Blnk_Run	=	true,
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2.1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					Select	=	11,
					New	=	"models\crskautos\volvo\xc90_t8_2015\runninglights_front_on",
					Use	=	true,
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(27.059999465942,86.930000305176,41.430000305176),
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	31,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(28.559999465942,86.139999389648,41.549999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(30.170000076294,85.080001831055,41.700000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(31.739999771118,83.930000305176,41.810001373291),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(33.450000762939,82.690002441406,42.029998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(35.020000457764,81.519996643066,42.189998626709),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(36.389999389648,80.139999389648,42.369998931885),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(37.700000762939,78.839996337891,42.490001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(39.25,77.019996643066,42.560001373291),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							UseClr	=	false,
							Pos	=	Vector(40.709999084473,75.169998168945,42.709999084473),
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Size	=	0.1,
								},
							},
						},
				UseBlinkers	=	true,
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.08,
						},
				SpecSpin	=	{
						},
				DD_Blnk_Run	=	true,
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2.1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					Select	=	15,
					New	=	"models\crskautos\volvo\xc90_t8_2015\int_symbols_on",
					Use	=	true,
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(40.810001373291,76.129997253418,40.130001068115),
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	21,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(40.830001831055,75.459999084473,40.759998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(41.040000915527,74.800003051758,41.700000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(41.110000610352,74.080001831055,42.330001831055),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(41.139999389648,73.440002441406,42.860000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(41.169998168945,72.580001831055,43.700000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(41.220001220703,71.800003051758,44.349998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(41.299999237061,71.029998779297,45.040000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseBlinkers	=	true,
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseSprite	=	true,
					},
				{
				UseBlinkers	=	true,
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\blinker_r_on",
					Select	=	10,
						},
				Pos	=	Vector(37.130001068115,-139.69999694824,51.319999694824),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.035,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2.1,
						},
				SpecMat	=	{
					Select	=	7,
					New	=	"models\crskautos\volvo\xc90_t8_2015\reverselights_on",
					Use	=	true,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(35.729999542236,-138.38000488281,52.680000305176),
				UseDynamic	=	true,
				RenderInner	=	true,
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				SpecMLine	=	{
					Amount	=	29,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(37.799999237061,-136.80999755859,52.590000152588),
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Size	=	0.1,
								},
							{
							Pos	=	Vector(39.590000152588,-135.16000366211,52.639999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(40.180000305176,-133.7200012207,52.599998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(40.290000915527,-132.10000610352,52.540000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.015,
						},
				SpecSpin	=	{
						},
				FogColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(-36.959999084473,-138.35000610352,46.990001678467),
				UseDynamic	=	true,
				UseFog	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.015,
						},
				SpecSpin	=	{
						},
				FogColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecMat	=	{
					Select	=	8,
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Use	=	true,
						},
				UseSprite	=	true,
				Pos	=	Vector(-36.290000915527,-138.69999694824,46.990001678467),
				UseDynamic	=	true,
				UseFog	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.015,
						},
				SpecSpin	=	{
						},
				FogColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(37.209999084473,-138.07000732422,46.810001373291),
				UseDynamic	=	true,
				UseFog	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.015,
						},
				SpecSpin	=	{
						},
				FogColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(36.509998321533,-138.35000610352,46.810001373291),
				UseDynamic	=	true,
				UseFog	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.015,
						},
				SpecSpin	=	{
						},
				FogColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(35.799999237061,-138.69999694824,46.840000152588),
				UseDynamic	=	true,
				UseFog	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(37.240001678467,-138.07000732422,48.049999237061),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(37.240001678467,-137.99000549316,49.209999084473),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(37.240001678467,-137.91000366211,50.409999847412),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(37.180000305176,-137.83000183105,51.549999237061),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(36.529998779297,-138.46000671387,48.049999237061),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					Select	=	10,
					New	=	"models\crskautos\volvo\xc90_t8_2015\blinker_r_on",
					Use	=	true,
						},
				UseSprite	=	true,
				Pos	=	Vector(36.529998779297,-138.33000183105,49.220001220703),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(36.529998779297,-138.22999572754,50.400001525879),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(36.459999084473,-138.16000366211,51.569999694824),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(35.849998474121,-138.75,48.049999237061),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(35.849998474121,-138.61999511719,49.25),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(35.849998474121,-138.5,50.389999389648),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(35.740001678467,-138.44999694824,51.549999237061),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					Select	=	6,
					New	=	"models\crskautos\volvo\xc90_t8_2015\blinker_l_on",
					Use	=	true,
						},
				UseSprite	=	true,
				Pos	=	Vector(-36.220001220703,-138.44999694824,51.720001220703),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\blinker_r_on",
					Select	=	10,
						},
				UseSprite	=	true,
				Pos	=	Vector(-36.919998168945,-138.16000366211,51.709999084473),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(-37.619998931885,-137.83000183105,51.75),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(-37.720001220703,-137.91000366211,50.630001068115),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(-36.970001220703,-138.22999572754,50.580001831055),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(-36.270000457764,-138.5,50.569999694824),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(-36.290000915527,-138.61999511719,49.400001525879),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(-37,-138.33000183105,49.389999389648),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(-37.689998626709,-137.99000549316,49.430000305176),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(-37.650001525879,-138.07000732422,48.25),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(-36.979999542236,-138.46000671387,48.279998779297),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(-36.279998779297,-138.75,48.25),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(37.119998931885,-138.17999267578,45.639999389648),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(-37.630001068115,-138.17999267578,45.830001831055),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(36.439998626709,-138.52000427246,45.639999389648),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(-36.909999847412,-138.52000427246,45.860000610352),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(35.720001220703,-138.83999633789,45.639999389648),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(-36.279998779297,-138.83999633789,45.849998474121),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.03,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
					Select	=	9,
					New	=	"models\crskautos\volvo\xc90_t8_2015\running_rear_on",
					Use	=	true,
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(39.919998168945,-132.75,54.119998931885),
				UseDynamic	=	true,
				UseRunning	=	true,
				SpecMLine	=	{
					Amount	=	54,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(39.5,-134.75,54.069999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(38.369998931885,-135.5,54.950000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(37.450000762939,-136.25999450684,56.479999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(36.060001373291,-137,57.549999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(34.369998931885,-137.58999633789,58.880001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(32.659999847412,-137.5299987793,60.689998626709),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(32.119998931885,-135.88999938965,62.979999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(31.729999542236,-134.21000671387,64.709999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(31.280000686646,-132.05999755859,66.730003356934),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(30.889999389648,-129.25999450684,69.309997558594),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(29.959999084473,-124.43000030518,73.339996337891),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2.1,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.03,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
					Select	=	9,
					New	=	"models\crskautos\volvo\xc90_t8_2015\running_rear_on",
					Use	=	true,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-41.069999694824,-132.85000610352,51.380001068115),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2.1,
						},
				SpecMLine	=	{
					Amount	=	54,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-40.330001831055,-134.85000610352,51.330001831055),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-39.110000610352,-136.17999267578,51.270000457764),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-39.209999084473,-136.36999511719,49.110000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-39.130001068115,-136.5299987793,47.060001373291),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-38.810001373291,-136.75999450684,45.299999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-37.310001373291,-138.16999816895,44.900001525879),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-35.450000762939,-139.28999328613,44.430000305176),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.03,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
					Select	=	9,
					New	=	"models\crskautos\volvo\xc90_t8_2015\running_rear_on",
					Use	=	true,
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(40.349998474121,-133.24000549316,51.090000152588),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2.1,
						},
				SpecMLine	=	{
					Amount	=	54,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(39.610000610352,-135.24000549316,51.040000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(38.389999389648,-136.57000732422,50.979999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(38.490001678467,-136.75999450684,48.819999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(38.409999847412,-136.91999816895,46.770000457764),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(38.090000152588,-137.14999389648,45.009998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(36.590000152588,-138.55999755859,44.610000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(34.729999542236,-139.67999267578,44.139999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.27,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-41.009998321533,-133.96000671387,47.180000305176),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				UseSprite	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.27,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
					Select	=	10,
					New	=	"models\crskautos\volvo\xc90_t8_2015\blinker_r_on",
					Use	=	true,
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(41.009998321533,-133.96000671387,47.180000305176),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
				UseSprite	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(37.069999694824,-137.58000183105,53.950000762939),
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(36.389999389648,-137.94999694824,53.959999084473),
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(35.669998168945,-138.27000427246,53.970001220703),
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(36.610000610352,-137.61999511719,55.220001220703),
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(35.900001525879,-137.96000671387,55.220001220703),
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(35.229999542236,-138.25,55.220001220703),
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(35.130001068115,-138.13000488281,56.540000915527),
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(34.419998168945,-138.44999694824,56.540000915527),
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(33.740001678467,-138.80000305176,56.540000915527),
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(33.599998474121,-138.42999267578,57.700000762939),
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(32.900001525879,-138.77000427246,57.700000762939),
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(32.790000915527,-138.7200012207,58.590000152588),
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(-36.009998321533,-138.27000427246,54.130001068115),
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(-36.700000762939,-137.94999694824,54.119998931885),
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(-37.369998931885,-137.58000183105,54.099998474121),
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(-36.939998626709,-137.61999511719,55.340000152588),
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(-36.270000457764,-137.96000671387,55.340000152588),
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(-35.569999694824,-138.25,55.369998931885),
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(-35.459999084473,-138.13000488281,56.639999389648),
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(-34.770000457764,-138.44999694824,56.680000305176),
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(-34.060001373291,-138.80000305176,56.669998168945),
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(-33.909999847412,-138.42999267578,57.869998931885),
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(-33.220001220703,-138.77000427246,57.860000610352),
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				UseSprite	=	true,
				Pos	=	Vector(-33.090000152588,-138.7200012207,58.740001678467),
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2.1,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.035,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\reverselights_on",
					Select	=	7,
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2.1,
						},
				UseSprite	=	true,
				Pos	=	Vector(-51.380001068115,1.1200000047684,57.869998931885),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	29,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-50.970001220703,2.6900000572205,57.689998626709),
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Size	=	0.1,
								},
							{
							Pos	=	Vector(-50.470001220703,4.3400001525879,57.590000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-49.939998626709,5.5599999427795,57.509998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Beta_Inner3D	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.035,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\reverselights_on",
					Select	=	7,
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2.1,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(51.270000457764,0.87000000476837,57.680000305176),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	29,
					Use	=	true,
					LTbl	=	{
							{
							Size	=	0.1,
							Pos	=	Vector(50.860000610352,2.4400000572205,57.5),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(50.360000610352,4.0900001525879,57.400001525879),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(49.830001831055,5.3099999427795,57.319999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseSprite	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.09,
						},
				SpecSpin	=	{
						},
				UseInter	=	true,
				InterColor	=	{
					r	=	225,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				IsInterior	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-2.5199999809265,-13.590000152588,75.160003662109),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	1,
					Brightness	=	2.1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.09,
						},
				SpecSpin	=	{
						},
				UseInter	=	true,
				InterColor	=	{
					r	=	225,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				SpecMat	=	{
					New	=	"models\crskautos\volvo\xc90_t8_2015\rearfog_on",
					Select	=	8,
						},
				IsInterior	=	true,
				UseSprite	=	true,
				Pos	=	Vector(2.7000000476837,-13.590000152588,75.160003662109),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	1,
					Brightness	=	2.1,
						},
					},
				},
		ExtraSeats	=	{
				{
				Pos	=	Vector(18.209999084473,-10.420000076294,43.950000762939),
				Ang	=	Angle(15,0,0),
				ExitAnim	=	"exit2",
				RadioControl	=	true,
				EnterAnim	=	"enter2",
					},
				{
				Ang	=	Angle(15,0,0),
				Pos	=	Vector(-18.209999084473,-56.810001373291,42.490001678467),
				ExitAnim	=	"exit3",
				EnterAnim	=	"enter3",
					},
				{
				Ang	=	Angle(15,0,0),
				Pos	=	Vector(18.209999084473,-56.810001373291,42.490001678467),
				EnterAnim	=	"enter4",
				ExitAnim	=	"exit4",
					},
				{
				Ang	=	Angle(15,0,0),
				Pos	=	Vector(-1.210000038147,-56.810001373291,42.490001678467),
				ExitAnim	=	"exit4",
				EnterAnim	=	"enter4",
					},
				},
		Fuel	=	{
			FuelLidPos	=	Vector(44.139999389648,-98.080001831055,50.790000915527),
			Override	=	true,
			FuelType	=	0,
			Capacity	=	70,
			FuelTypeUse	=	true,
			FuelLidUse	=	true,
				},
		Author	=	"CrushingSkirmish (76561198017348899)",
}