VCModels['models/critzcamry.mdl']	=	{
		em_state	=	5236594866,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Copyright	=	"DurkaTeam @ 2025 No rights reserved",
		Exhaust	=	{
				{
				Ang	=	Angle(-15,-90,0),
				Pos	=	Vector(29.270000457764,-113.93000030518,6.4899997711182),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(18.729999542236,9.1499996185303,24.889999389648),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(-18.729999542236,-30.079999923706,24.889999389648),
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(18.729999542236,-30.079999923706,24.889999389648),
					},
				},
		DLT	=	3491063244,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-39.009998321533,95.25,26.870000839233),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
						255,
						155,
						0,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				Pos	=	Vector(-33.509998321533,100.93000030518,26),
				UseSprite	=	true,
				RunningColor	=	{
						198.53,
						192.61,
						234.75,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				UseHead	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-27.639999389648,102.87999725342,24.370000839233),
				UseDynamic	=	true,
				HeadColor	=	{
						201,
						216,
						255,
						},
				ProjTexture	=	{
					Forward	=	30,
					Size	=	2000,
					Angle	=	Angle(0,90,0),
						},
				UsePrjTex	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(-38.880001068115,95.25,26.870000839233),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
				RenderInner_Size	=	1.2,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-35.720001220703,-110.69999694824,35.689998626709),
					UseColor	=	true,
					Pos2	=	Vector(-28.010000228882,-113.70999908447,30.799999237061),
					Color	=	{
							255,
							55,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(-30.010000228882,-113.2799987793,35.229999542236),
					Pos3	=	Vector(-36.450000762939,-110.51999664307,31.959999084473),
						},
				UseSprite	=	true,
				Pos	=	Vector(-33.040000915527,-112.51000213623,33.799999237061),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseRunning	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-28.190000534058,-113.20999908447,34.419998168945),
					UseColor	=	true,
					Pos2	=	Vector(-19.770000457764,-116.01000213623,29.479999542236),
					Color	=	{
							255,
							55,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(-21.770000457764,-115.58000183105,33.909999847412),
					Pos3	=	Vector(-27.290000915527,-114.5,30.989999771118),
						},
				UseSprite	=	true,
				Pos	=	Vector(-24.459999084473,-114.80999755859,32.479999542236),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-36.209999084473,-110.23999786377,37.740001678467),
					Pos2	=	Vector(-30.049999237061,-113.7200012207,35.099998474121),
					Color	=	{
							255,
							55,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(-31.389999389648,-113.16999816895,37.470001220703),
					Pos3	=	Vector(-36.950000762939,-109.88999938965,35.619998931885),
						},
				UseSprite	=	true,
				Pos	=	Vector(-33.720001220703,-111.66999816895,36.479999542236),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
				RenderInner_Size	=	1.2,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-29.129999160767,-113.58000183105,37.259998321533),
					Pos2	=	Vector(-22.659999847412,-115.5299987793,34.319999694824),
					Color	=	{
							255,
							55,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(-23.809999465942,-114.93000030518,36.979999542236),
					Pos3	=	Vector(-28.280000686646,-114.5,34.619998931885),
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-26.090000152588,-114.43000030518,35.889999389648),
				UseDynamic	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-4.210000038147,-90.589996337891,47.759998321533),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(4.210000038147,-90.589996337891,47.759998321533),
								},
							},
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(39.009998321533,95.25,26.870000839233),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
						255,
						155,
						0,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				Pos	=	Vector(33.509998321533,100.93000030518,26),
				UseSprite	=	true,
				RunningColor	=	{
						198.53,
						192.61,
						234.75,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				UseHead	=	true,
				UsePrjTex	=	true,
				Pos	=	Vector(27.639999389648,102.87999725342,24.370000839233),
				UseDynamic	=	true,
				HeadColor	=	{
						201,
						216,
						255,
						},
				UseSprite	=	true,
				ProjTexture	=	{
					Forward	=	30,
					Size	=	2000,
					Angle	=	Angle(0,90,0),
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(38.880001068115,95.25,26.870000839233),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
				RenderInner_Size	=	1.2,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(35.720001220703,-110.69999694824,35.689998626709),
					UseColor	=	true,
					Pos2	=	Vector(28.010000228882,-113.70999908447,30.799999237061),
					Color	=	{
							255,
							55,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(30.010000228882,-113.2799987793,35.229999542236),
					Pos3	=	Vector(36.450000762939,-110.51999664307,31.959999084473),
						},
				UseSprite	=	true,
				Pos	=	Vector(33.040000915527,-112.51000213623,33.799999237061),
				UseDynamic	=	true,
				UseRunning	=	true,
				UseBrake	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(28.190000534058,-113.20999908447,34.419998168945),
					UseColor	=	true,
					Pos2	=	Vector(19.770000457764,-116.01000213623,29.479999542236),
					Color	=	{
							255,
							55,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(21.770000457764,-115.58000183105,33.909999847412),
					Pos3	=	Vector(27.290000915527,-114.5,30.989999771118),
						},
				UseSprite	=	true,
				Pos	=	Vector(24.459999084473,-114.80999755859,32.479999542236),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(36.209999084473,-110.23999786377,37.740001678467),
					Pos2	=	Vector(30.049999237061,-113.7200012207,35.099998474121),
					Color	=	{
							255,
							55,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(31.389999389648,-113.16999816895,37.470001220703),
					Pos3	=	Vector(36.950000762939,-109.88999938965,35.619998931885),
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(33.720001220703,-111.66999816895,36.479999542236),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
				RenderInner_Size	=	1.2,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(29.129999160767,-113.58000183105,37.259998321533),
					Pos2	=	Vector(22.659999847412,-115.5299987793,34.319999694824),
					Color	=	{
							255,
							55,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(23.809999465942,-114.93000030518,36.979999542236),
					Pos3	=	Vector(28.280000686646,-114.5,34.619998931885),
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(26.090000152588,-114.43000030518,35.889999389648),
				UseDynamic	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
					},
				},
		Date	=	"10/18/15 15:23:56",
		Author	=	"freemmaann (76561197989323181)",
}