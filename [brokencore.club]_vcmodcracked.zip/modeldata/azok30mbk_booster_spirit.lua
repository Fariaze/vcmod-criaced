VCModels['models/azok30mbk_booster_spirit.mdl']	=	{
		em_state	=	5236594371,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Date	=	"Sun Dec  2 22:26:17 2018",
		Exhaust	=	{
				{
				EffectStress	=	"VC_Exhaust_Stress",
				Invulnerable	=	true,
				EffectIdle	=	"VC_Exhaust",
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(8.3500003814697,-14.829999923706,2.0899999141693),
					},
				},
		ExtraSeats	=	{
				{
				Pos	=	Vector(-0.5,-21.489999771118,30.459999084473),
					},
				},
		DLT	=	3491062914,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(-0.28999999165535,24.760000228882,23.170000076294),
					Pos2	=	Vector(-4.6900000572205,24.760000228882,27.569999694824),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-0.28999999165535,24.760000228882,27.569999694824),
					Pos3	=	Vector(-4.6900000572205,24.760000228882,23.170000076294),
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-2.4900000095367,24.760000228882,25.370000839233),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(4.0999999046326,24.760000228882,23.170000076294),
					Pos2	=	Vector(-0.30000001192093,24.760000228882,27.569999694824),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(4.0999999046326,24.760000228882,27.569999694824),
					Pos3	=	Vector(-0.30000001192093,24.760000228882,23.170000076294),
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(1.8999999761581,24.760000228882,25.370000839233),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(4.1100001335144,-35,19.64999961853),
					Pos2	=	Vector(-2.289999961853,-32.5,22.549999237061),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(2.1099998950958,-33,22.549999237061),
					Pos3	=	Vector(-4.289999961853,-35,19.64999961853),
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-0.090000003576279,-35,20.85000038147),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(4.1100001335144,-35,19.64999961853),
					Pos2	=	Vector(-2.289999961853,-32.5,22.549999237061),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(2.1099998950958,-33,22.549999237061),
					Pos3	=	Vector(-4.289999961853,-35,19.64999961853),
						},
				SpecMat	=	{
						},
				UseBrake	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-0.090000003576279,-35,20.85000038147),
				UseDynamic	=	true,
				RenderInner_Size	=	4,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(4.1100001335144,-35,19.64999961853),
					Pos2	=	Vector(-2.289999961853,-32.5,22.549999237061),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(2.1099998950958,-33,22.549999237061),
					Pos3	=	Vector(-4.289999961853,-35,19.64999961853),
						},
				SpecMat	=	{
						},
				UseBrake	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-0.090000003576279,-35,20.85000038147),
				UseDynamic	=	true,
				RenderInner_Size	=	4,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(4.1100001335144,-35,19.64999961853),
					Pos2	=	Vector(-2.289999961853,-32.5,22.549999237061),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(2.1099998950958,-33,22.549999237061),
					Pos3	=	Vector(-4.289999961853,-35,19.64999961853),
						},
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-0.090000003576279,-35,20.85000038147),
				UseDynamic	=	true,
				RenderInner_Size	=	4,
				UseBrake	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-4.289999961853,24.479999542236,25.290000915527),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	15,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-4.25,24.510000228882,23.989999771118),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-3.3099999427795,24.549999237061,23.629999160767),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Size	=	1.431,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(5.5900001525879,-31.950000762939,20.590000152588),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	15,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(5.75,-33.020000457764,18.559999465942),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-5.9099998474121,-31.950000762939,20.590000152588),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	15,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-5.75,-33.020000457764,18.559999465942),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(0.28999999165535,24.760000228882,23.170000076294),
					Pos2	=	Vector(4.6900000572205,24.760000228882,27.569999694824),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(0.28999999165535,24.760000228882,27.569999694824),
					Pos3	=	Vector(4.6900000572205,24.760000228882,23.170000076294),
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(2.4900000095367,24.760000228882,25.370000839233),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(-4.0999999046326,24.760000228882,23.170000076294),
					Pos2	=	Vector(0.30000001192093,24.760000228882,27.569999694824),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-4.0999999046326,24.760000228882,27.569999694824),
					Pos3	=	Vector(0.30000001192093,24.760000228882,23.170000076294),
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-1.8999999761581,24.760000228882,25.370000839233),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-4.1100001335144,-35,19.64999961853),
					Pos2	=	Vector(2.289999961853,-32.5,22.549999237061),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-2.1099998950958,-33,22.549999237061),
					Pos3	=	Vector(4.289999961853,-35,19.64999961853),
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(0.090000003576279,-35,20.85000038147),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-4.1100001335144,-35,19.64999961853),
					Pos2	=	Vector(2.289999961853,-32.5,22.549999237061),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-2.1099998950958,-33,22.549999237061),
					Pos3	=	Vector(4.289999961853,-35,19.64999961853),
						},
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				RenderInner_Size	=	4,
				UseSprite	=	true,
				Pos	=	Vector(0.090000003576279,-35,20.85000038147),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBrake	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(4.289999961853,24.479999542236,25.290000915527),
				UseDynamic	=	true,
				RenderInner_Size	=	1.431,
				SpecMLine	=	{
					Amount	=	15,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(4.25,24.510000228882,23.989999771118),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(3.3099999427795,24.549999237061,23.629999160767),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-5.5900001525879,-31.950000762939,20.590000152588),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	15,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-5.75,-33.020000457764,18.559999465942),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(5.9099998474121,-31.950000762939,20.590000152588),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	15,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(5.75,-33.020000457764,18.559999465942),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				},
		Copyright	=	"Copyright © 2012-2018 VCMod (freemmaann). All Rights Reserved.",
		Fuel	=	{
			FuelType	=	0,
				},
		Author	=	"Azok30 (76561198183398967)",
}