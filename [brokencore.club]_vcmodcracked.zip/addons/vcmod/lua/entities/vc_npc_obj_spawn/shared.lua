-- DurkaTeam @ 2025 Никакие права не защищены

ENT.Base 		= "base_anim"
ENT.Type 		= "anim"
ENT.PrintName	= "NPC spawn platform"
ENT.Author		= "freemmaann"
ENT.Category	= "VCMod"

ENT.Spawnable = false
ENT.AdminSpawnable = false
