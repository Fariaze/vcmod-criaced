VCModels['models/bgapc.mdl']	=	{
		Date	=	"10/20/14 19:45:50",
		Author	=	"freemmaann",
		Z_Copyright	=	"This data is copyrighted material of: freemmaann, steam ID: STEAM_0:1:14528726, creation date: 10/20/14 19:45:50.",
		DLT	=	3491063156,
}