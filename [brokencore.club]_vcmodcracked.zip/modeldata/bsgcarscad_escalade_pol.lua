VCModels['models/bsgcarscad_escalade_pol.mdl']	=	{
		em_state	=	5236595067,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Siren	=	{
			Sounds	=	{
					{
					Volume	=	1,
					Pitch	=	100,
					Distance	=	95,
					Name	=	"Wail",
					Sound	=	"vcmod/els/cencom/wail.wav",
						},
					{
					Volume	=	1,
					Pitch	=	100,
					Distance	=	95,
					Name	=	"Yelp",
					Sound	=	"vcmod/els/cencom/yelp.wav",
						},
					{
					Volume	=	1,
					Pitch	=	100,
					Distance	=	95,
					Name	=	"Priority",
					Sound	=	"vcmod/els/cencom/priority.wav",
						},
					},
			Sequences	=	{
					{
					SubSeq	=	{
							{
							Stages	=	{
									{
									Lights	=	{
											1,
											2,
											3,
											4,
											},
									Time	=	0.2,
										},
									{
									Lights	=	{
											5,
											6,
											7,
											8,
											},
									Time	=	0.2,
										},
									},
							Time	=	5,
								},
							{
							Stages	=	{
									{
									Lights	=	{
											1,
											2,
											3,
											4,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											1,
											2,
											3,
											4,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											5,
											6,
											7,
											8,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											5,
											6,
											7,
											8,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									},
							Time	=	5,
								},
							{
							Stages	=	{
									{
									Lights	=	{
											1,
											5,
											},
									Time	=	0.075,
										},
									{
									Lights	=	{
											2,
											6,
											},
									Time	=	0.075,
										},
									{
									Lights	=	{
											3,
											7,
											},
									Time	=	0.075,
										},
									{
									Lights	=	{
											4,
											8,
											},
									Time	=	0.075,
										},
									{
									Lights	=	{
											3,
											7,
											},
									Time	=	0.075,
										},
									{
									Lights	=	{
											2,
											6,
											},
									Time	=	0.075,
										},
									},
							Time	=	5,
								},
							},
					Codes	=	{
						[6]	=	true,
							},
					Lights_Sel	=	{
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							},
						},
					{
					SubSeq	=	{
							{
							Stages	=	{
									{
									Lights	=	{
											9,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											10,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									},
							Time	=	5,
								},
							{
							Stages	=	{
									{
									Lights	=	{
											9,
											10,
											},
									Time	=	0.2,
										},
									{
									Lights	=	{
											},
									Time	=	0.2,
										},
									},
							Time	=	2,
								},
							{
							Stages	=	{
									{
									Lights	=	{
											9,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											9,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											9,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											9,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											9,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											10,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											10,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											10,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											10,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											10,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									},
							Time	=	5,
								},
							},
					Codes	=	{
						[6]	=	true,
							},
					Lights_Sel	=	{
						[10]	=	true,
						[9]	=	true,
							},
						},
					{
					SubSeq	=	{
							{
							Stages	=	{
									{
									Lights	=	{
											11,
											12,
											13,
											14,
											15,
											16,
											},
									Time	=	0.2,
										},
									{
									Lights	=	{
											17,
											18,
											19,
											20,
											21,
											22,
											},
									Time	=	0.2,
										},
									},
							Time	=	5,
								},
							{
							Stages	=	{
									{
									Lights	=	{
											11,
											12,
											13,
											14,
											15,
											16,
											},
									Time	=	0.1,
										},
									{
									Lights	=	{
											},
									Time	=	0.1,
										},
									},
							Time	=	1,
								},
							{
							Stages	=	{
									{
									Lights	=	{
											17,
											18,
											19,
											20,
											21,
											22,
											},
									Time	=	0.1,
										},
									{
									Lights	=	{
											},
									Time	=	0.1,
										},
									},
							Time	=	1,
								},
							{
							Stages	=	{
									{
									Lights	=	{
											11,
											12,
											13,
											14,
											15,
											16,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											11,
											12,
											13,
											14,
											15,
											16,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											11,
											12,
											13,
											14,
											15,
											16,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											11,
											12,
											13,
											14,
											15,
											16,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											11,
											12,
											13,
											14,
											15,
											16,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											17,
											18,
											19,
											20,
											21,
											22,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											17,
											18,
											19,
											20,
											21,
											22,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											17,
											18,
											19,
											20,
											21,
											22,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											17,
											18,
											19,
											20,
											21,
											22,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											17,
											18,
											19,
											20,
											21,
											22,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									},
							Time	=	5,
								},
							{
							Stages	=	{
									{
									Lights	=	{
											11,
											12,
											13,
											14,
											15,
											16,
											17,
											18,
											19,
											20,
											21,
											22,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											11,
											12,
											13,
											14,
											15,
											16,
											17,
											18,
											19,
											20,
											21,
											22,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											11,
											12,
											13,
											14,
											15,
											16,
											17,
											18,
											19,
											20,
											21,
											22,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											11,
											12,
											13,
											14,
											15,
											16,
											17,
											18,
											19,
											20,
											21,
											22,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											11,
											12,
											13,
											14,
											15,
											16,
											17,
											18,
											19,
											20,
											21,
											22,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.5,
										},
									},
							Time	=	2,
								},
							},
					Codes	=	{
						[6]	=	true,
							},
					Lights_Sel	=	{
						[11]	=	true,
						[12]	=	true,
						[13]	=	true,
						[14]	=	true,
						[15]	=	true,
						[16]	=	true,
						[17]	=	true,
						[18]	=	true,
						[19]	=	true,
						[20]	=	true,
						[21]	=	true,
						[22]	=	true,
							},
						},
					{
					SubSeq	=	{
							{
							Stages	=	{
									{
									Lights	=	{
											24,
											25,
											},
									Time	=	0.3,
										},
									{
									Lights	=	{
											23,
											26,
											},
									Time	=	0.3,
										},
									},
							Time	=	5,
								},
							},
					Codes	=	{
						[6]	=	true,
							},
					Lights_Sel	=	{
						[23]	=	true,
						[26]	=	true,
						[25]	=	true,
						[24]	=	true,
							},
						},
					},
			Sections	=	{
				[1]	=	{
						true,
						true,
						true,
						true,
						true,
						true,
						true,
						true,
						},
				[3]	=	{
					[11]	=	true,
					[12]	=	true,
					[13]	=	true,
					[14]	=	true,
					[15]	=	true,
					[16]	=	true,
					[17]	=	true,
					[18]	=	true,
					[19]	=	true,
					[20]	=	true,
					[21]	=	true,
					[22]	=	true,
						},
				[5]	=	{
					[10]	=	true,
					[9]	=	true,
						},
					},
			Lights	=	{
					{
					Sprite	=	{
						Size	=	0.1,
							},
					Dynamic	=	{
						Size	=	0.5,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-12.60000038147,126.11000061035,41.799999237061),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					SpecLine	=	{
						Amount	=	5,
						Pos	=	Vector(-10.560000419617,126.11000061035,41.799999237061),
						Use	=	true,
							},
					UseSprite	=	true,
					Beta_Inner3D	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.1,
							},
					Dynamic	=	{
						Size	=	0.5,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-10,126.11000061035,41.799999237061),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					SpecLine	=	{
						Amount	=	5,
						Pos	=	Vector(-7.960000038147,126.11000061035,41.799999237061),
						Use	=	true,
							},
					UseSprite	=	true,
					Beta_Inner3D	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.1,
							},
					Dynamic	=	{
						Size	=	0.5,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-7.6599998474121,126.11000061035,41.799999237061),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					SpecLine	=	{
						Amount	=	5,
						Pos	=	Vector(-5.6199998855591,126.11000061035,41.799999237061),
						Use	=	true,
							},
					UseSprite	=	true,
					Beta_Inner3D	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.1,
							},
					Dynamic	=	{
						Size	=	0.5,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-5.0599999427795,126.11000061035,41.799999237061),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					SpecLine	=	{
						Amount	=	5,
						Pos	=	Vector(-3.0199999809265,126.11000061035,41.799999237061),
						Use	=	true,
							},
					UseSprite	=	true,
					Beta_Inner3D	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.1,
							},
					Dynamic	=	{
						Size	=	0.5,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(12.60000038147,126.11000061035,41.799999237061),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							0,
							55,
							255,
							},
					SpecLine	=	{
						Amount	=	5,
						Pos	=	Vector(10.560000419617,126.11000061035,41.799999237061),
						Use	=	true,
							},
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.1,
							},
					Dynamic	=	{
						Size	=	0.5,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(10,126.11000061035,41.799999237061),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							0,
							55,
							255,
							},
					SpecLine	=	{
						Amount	=	5,
						Pos	=	Vector(7.960000038147,126.11000061035,41.799999237061),
						Use	=	true,
							},
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.1,
							},
					Dynamic	=	{
						Size	=	0.5,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(7.6599998474121,126.11000061035,41.799999237061),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							0,
							55,
							255,
							},
					SpecLine	=	{
						Amount	=	5,
						Pos	=	Vector(5.6199998855591,126.11000061035,41.799999237061),
						Use	=	true,
							},
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.1,
							},
					Dynamic	=	{
						Size	=	0.5,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(5.0599999427795,126.11000061035,41.799999237061),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							0,
							55,
							255,
							},
					SpecLine	=	{
						Amount	=	5,
						Pos	=	Vector(3.0199999809265,126.11000061035,41.799999237061),
						Use	=	true,
							},
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.15,
							},
					Dynamic	=	{
						Size	=	0.55,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-11.970000267029,-112.44999694824,75.650001525879),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					SpecLine	=	{
						Amount	=	8,
						Pos	=	Vector(-7.8000001907349,-112.44999694824,75.650001525879),
						Use	=	true,
							},
					UseSprite	=	true,
					Beta_Inner3D	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.15,
							},
					Dynamic	=	{
						Size	=	0.55,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(11.970000267029,-112.44999694824,75.650001525879),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							0,
							55,
							255,
							},
					SpecLine	=	{
						Amount	=	8,
						Pos	=	Vector(7.8000001907349,-112.44999694824,75.650001525879),
						Use	=	true,
							},
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.15,
							},
					Dynamic	=	{
						Size	=	0.55,
						Brightness	=	2,
							},
					SpecRec	=	{
						Pos4	=	Vector(-11.770000457764,-11.300000190735,86.730003356934),
						AmountV	=	3,
						Pos2	=	Vector(-7.5999999046326,-11.300000190735,88),
						AmountH	=	5,
						Use	=	true,
						Pos1	=	Vector(-11.770000457764,-11.300000190735,88),
						Pos3	=	Vector(-7.5999999046326,-11.300000190735,86.730003356934),
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-9.6899995803833,-11.300000190735,87.370002746582),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							0,
							55,
							255,
							},
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.15,
							},
					Dynamic	=	{
						Size	=	0.55,
						Brightness	=	2,
							},
					SpecRec	=	{
						AmountV	=	3,
						Pos4	=	Vector(-18.64999961853,-11.300000190735,86.730003356934),
						Pos2	=	Vector(-14.380000114441,-11.300000190735,88),
						AmountH	=	5,
						Use	=	true,
						Pos1	=	Vector(-18.64999961853,-11.300000190735,88),
						Pos3	=	Vector(-14.380000114441,-11.300000190735,86.730003356934),
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-16.510000228882,-11.300000190735,87.370002746582),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							0,
							55,
							255,
							},
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.15,
							},
					Dynamic	=	{
						Size	=	0.55,
						Brightness	=	2,
							},
					SpecRec	=	{
						Pos4	=	Vector(-25,-9.8000001907349,86.730003356934),
						AmountV	=	3,
						Pos2	=	Vector(-20.780000686646,-11.300000190735,88),
						AmountH	=	5,
						Use	=	true,
						Pos1	=	Vector(-25,-9.8000001907349,88),
						Pos3	=	Vector(-20.780000686646,-11.300000190735,86.730003356934),
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-22.889999389648,-10.550000190735,87.370002746582),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							0,
							55,
							255,
							},
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.15,
							},
					Dynamic	=	{
						Size	=	0.55,
						Brightness	=	2,
							},
					SpecRec	=	{
						AmountV	=	3,
						Pos4	=	Vector(-11.770000457764,-0.69999998807907,86.730003356934),
						Pos2	=	Vector(-7.5999999046326,-0.69999998807907,88),
						AmountH	=	5,
						Use	=	true,
						Pos1	=	Vector(-11.770000457764,-0.69999998807907,88),
						Pos3	=	Vector(-7.5999999046326,-0.69999998807907,86.730003356934),
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-9.6899995803833,-0.69999998807907,87.370002746582),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							0,
							55,
							255,
							},
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.15,
							},
					Dynamic	=	{
						Size	=	0.55,
						Brightness	=	2,
							},
					SpecRec	=	{
						Pos4	=	Vector(-18.64999961853,-0.69999998807907,86.730003356934),
						AmountV	=	3,
						Pos2	=	Vector(-14.380000114441,-0.69999998807907,88),
						AmountH	=	5,
						Use	=	true,
						Pos1	=	Vector(-18.64999961853,-0.69999998807907,88),
						Pos3	=	Vector(-14.380000114441,-0.69999998807907,86.730003356934),
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-16.510000228882,-0.69999998807907,87.370002746582),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							0,
							55,
							255,
							},
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.15,
							},
					Dynamic	=	{
						Size	=	0.55,
						Brightness	=	2,
							},
					SpecRec	=	{
						AmountV	=	3,
						Pos4	=	Vector(-25,-2.2999999523163,86.730003356934),
						Pos2	=	Vector(-20.780000686646,-0.69999998807907,88),
						AmountH	=	5,
						Use	=	true,
						Pos1	=	Vector(-25,-2.2999999523163,88),
						Pos3	=	Vector(-20.780000686646,-0.69999998807907,86.730003356934),
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-22.889999389648,-1.5,87.370002746582),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							0,
							55,
							255,
							},
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.15,
							},
					Dynamic	=	{
						Size	=	0.55,
						Brightness	=	2,
							},
					SpecRec	=	{
						AmountV	=	3,
						Pos4	=	Vector(11.770000457764,-11.300000190735,86.730003356934),
						Pos2	=	Vector(7.5999999046326,-11.300000190735,88),
						AmountH	=	5,
						Use	=	true,
						Pos1	=	Vector(11.770000457764,-11.300000190735,88),
						Pos3	=	Vector(7.5999999046326,-11.300000190735,86.730003356934),
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(9.6899995803833,-11.300000190735,87.370002746582),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					UseSprite	=	true,
					Beta_Inner3D	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.15,
							},
					Dynamic	=	{
						Size	=	0.55,
						Brightness	=	2,
							},
					SpecRec	=	{
						Pos4	=	Vector(18.64999961853,-11.300000190735,86.730003356934),
						AmountV	=	3,
						Pos2	=	Vector(14.380000114441,-11.300000190735,88),
						AmountH	=	5,
						Use	=	true,
						Pos1	=	Vector(18.64999961853,-11.300000190735,88),
						Pos3	=	Vector(14.380000114441,-11.300000190735,86.730003356934),
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(16.510000228882,-11.300000190735,87.370002746582),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					UseSprite	=	true,
					Beta_Inner3D	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.15,
							},
					Dynamic	=	{
						Size	=	0.55,
						Brightness	=	2,
							},
					SpecRec	=	{
						AmountV	=	3,
						Pos4	=	Vector(25,-9.8000001907349,86.730003356934),
						Pos2	=	Vector(20.780000686646,-11.300000190735,88),
						AmountH	=	5,
						Use	=	true,
						Pos1	=	Vector(25,-9.8000001907349,88),
						Pos3	=	Vector(20.780000686646,-11.300000190735,86.730003356934),
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(22.889999389648,-10.550000190735,87.370002746582),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					UseSprite	=	true,
					Beta_Inner3D	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.15,
							},
					Dynamic	=	{
						Size	=	0.55,
						Brightness	=	2,
							},
					SpecRec	=	{
						Pos4	=	Vector(11.770000457764,-0.69999998807907,86.730003356934),
						AmountV	=	3,
						Pos2	=	Vector(7.5999999046326,-0.69999998807907,88),
						AmountH	=	5,
						Use	=	true,
						Pos1	=	Vector(11.770000457764,-0.69999998807907,88),
						Pos3	=	Vector(7.5999999046326,-0.69999998807907,86.730003356934),
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(9.6899995803833,-0.69999998807907,87.370002746582),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					UseSprite	=	true,
					Beta_Inner3D	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.15,
							},
					Dynamic	=	{
						Size	=	0.55,
						Brightness	=	2,
							},
					SpecRec	=	{
						AmountV	=	3,
						Pos4	=	Vector(18.64999961853,-0.69999998807907,86.730003356934),
						Pos2	=	Vector(14.380000114441,-0.69999998807907,88),
						AmountH	=	5,
						Use	=	true,
						Pos1	=	Vector(18.64999961853,-0.69999998807907,88),
						Pos3	=	Vector(14.380000114441,-0.69999998807907,86.730003356934),
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(16.510000228882,-0.69999998807907,87.370002746582),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					UseSprite	=	true,
					Beta_Inner3D	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.15,
							},
					Dynamic	=	{
						Size	=	0.55,
						Brightness	=	2,
							},
					SpecRec	=	{
						Pos4	=	Vector(25,-2.2999999523163,86.730003356934),
						AmountV	=	3,
						Pos2	=	Vector(20.780000686646,-0.69999998807907,88),
						AmountH	=	5,
						Use	=	true,
						Pos1	=	Vector(25,-2.2999999523163,88),
						Pos3	=	Vector(20.780000686646,-0.69999998807907,86.730003356934),
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(22.889999389648,-1.5,87.370002746582),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					UseSprite	=	true,
					Beta_Inner3D	=	true,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	5,
						Size	=	0.4,
							},
					Dynamic	=	{
						Size	=	0.4,
						Brightness	=	2,
							},
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							196.13,
							205.61,
							232.07,
							},
					Pos	=	Vector(29.159999847412,113.62000274658,20.909999847412),
					UseSprite	=	true,
					RenderHD_Adv	=	true,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	5,
						Size	=	0.3,
							},
					Dynamic	=	{
						Size	=	0.3,
						Brightness	=	2,
							},
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							200,
							225,
							255,
							},
					Pos	=	Vector(-38.130001068115,-120.01000213623,39.650001525879),
					UseSprite	=	true,
					RenderHD_Adv	=	true,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	5,
						Size	=	0.4,
							},
					Dynamic	=	{
						Size	=	0.4,
						Brightness	=	2,
							},
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							196.13,
							205.61,
							232.07,
							},
					Pos	=	Vector(-29.159999847412,113.62000274658,20.909999847412),
					UseSprite	=	true,
					RenderHD_Adv	=	true,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	5,
						Size	=	0.3,
							},
					Dynamic	=	{
						Size	=	0.3,
						Brightness	=	2,
							},
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							200,
							225,
							255,
							},
					Pos	=	Vector(38.130001068115,-120.01000213623,39.650001525879),
					UseSprite	=	true,
					RenderHD_Adv	=	true,
						},
					},
			Sounds_Horn	=	{
				Use	=	true,
				Volume	=	1,
				Distance	=	95,
				Pitch	=	100,
				Sound	=	"vcmod/els/cencom/bullhorn.wav",
					},
			Codes	=	{
				[13]	=	{
					Include	=	true,
						},
				[8]	=	{
					SSeq_Ovr_SSeq	=	4,
					Sz	=	true,
					SSeq_Ovr	=	true,
					OvrC	=	6,
					Spd_Stg	=	true,
					Spd_Stg_M	=	5,
					Spd_Sub	=	true,
					SzM	=	2,
					Spd_Sub_M	=	5,
						},
				[9]	=	{
					SSeq_Ovr_SSeq	=	1,
					Spd_Stg_M	=	3,
					SSeq_Ovr	=	true,
					OvrC	=	6,
					Spd_Stg	=	true,
						},
					},
			Sounds_Manual	=	{
				Use	=	true,
				Volume	=	1,
				Distance	=	95,
				Pitch	=	100,
				Sound	=	"vcmod/els/cencom/wail.wav",
					},
				},
		Date	=	"03/05/15 19:43:26",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-25.829999923706,-122.91000366211,19.35000038147),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(25.829999923706,-122.91000366211,19.35000038147),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(19.999900817871,19.995100021362,46.200000762939),
				RadioControl	=	true,
					},
				{
				Pos	=	Vector(-19.999900817871,-15.004899978638,46.200000762939),
				Ang	=	Angle(0,0,0),
				Switch_Rear	=	true,
				Cant_Exit_Lock	=	true,
				switch_rear	=	true,
					},
				{
				Pos	=	Vector(20,-15,46.200000762939),
				Ang	=	Angle(0,0,0),
				Switch_Rear	=	true,
				Cant_Exit_Lock	=	true,
				switch_rear	=	true,
					},
				{
				Pos	=	Vector(-20,-66.769996643066,46.200000762939),
				Ang	=	Angle(0,0,0),
				Switch_Rear	=	true,
				Cant_Exit_Lock	=	true,
				switch_rear	=	true,
					},
				{
				Pos	=	Vector(20,-66.769996643066,46.200000762939),
				Ang	=	Angle(0,0,0),
				Switch_Rear	=	true,
				Cant_Exit_Lock	=	true,
				switch_rear	=	true,
					},
				},
		DLT	=	3491063378,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseReverse	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				UseDynamic	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-38.130001068115,-120.01000213623,39.650001525879),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				UseBrake	=	true,
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				SpecLine	=	{
					Amount	=	16,
					Pos	=	Vector(-36.25,-120.36000061035,56.150001525879),
					Use	=	true,
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(-37.060001373291,-120.08000183105,42.080001831055),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				Pos	=	Vector(-38.400001525879,-119.19999694824,42.139999389648),
				UseRunning	=	true,
				SpecLine	=	{
					Amount	=	6,
					Pos	=	Vector(-38.200000762939,-119.19999694824,47.740001678467),
					Use	=	true,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				Pos	=	Vector(-38.200000762939,-119.19999694824,48.729999542236),
				UseRunning	=	true,
				SpecLine	=	{
					Amount	=	8,
					Pos	=	Vector(-36.919998168945,-119.19999694824,56.470001220703),
					Use	=	true,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				Pos	=	Vector(-39.599998474121,-119.19999694824,42.139999389648),
				UseRunning	=	true,
				SpecLine	=	{
					Amount	=	6,
					Pos	=	Vector(-39.400001525879,-119.19999694824,47.740001678467),
					Use	=	true,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				Pos	=	Vector(-39.400001525879,-119.19999694824,48.729999542236),
				UseRunning	=	true,
				SpecLine	=	{
					Amount	=	8,
					Pos	=	Vector(-38.099998474121,-119.19999694824,56.470001220703),
					Use	=	true,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-40.979999542236,-117.80000305176,42.25),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				SpecLine	=	{
					Amount	=	6,
					Pos	=	Vector(-40.819999694824,-117.80000305176,47.639999389648),
					Use	=	true,
						},
				RenderInner_Size	=	1.2,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-40.810001373291,-117.80000305176,48.709999084473),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				SpecLine	=	{
					Amount	=	8,
					Pos	=	Vector(-39.409999847412,-117.80000305176,56.75),
					Use	=	true,
						},
				RenderInner_Size	=	1.2,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				UseBrake	=	true,
				FogColor	=	{
						255,
						55,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(-25.280000686646,-112.29000091553,80.150001525879),
				UseDynamic	=	true,
				UseFog	=	true,
				SpecLine	=	{
					Amount	=	19,
					Pos	=	Vector(-7.0999999046326,-113.5299987793,80.620002746582),
					Use	=	true,
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				UseBrake	=	true,
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				SpecLine	=	{
					Amount	=	12,
					Pos	=	Vector(6,-113.56999969482,80.639999389648),
					Use	=	true,
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(-6,-113.56999969482,80.639999389648),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-49.889999389648,39.380001068115,56.930000305176),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				RenderInner_Size	=	1.2,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-40.810001373291,105.31999969482,47.060001373291),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				SpecLine	=	{
					Amount	=	13,
					Pos	=	Vector(-40.909999847412,107.58000183105,36.939998626709),
					Use	=	true,
						},
				RenderInner_Size	=	1.2,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseHead	=	true,
				UsePrjTex	=	true,
				Pos	=	Vector(-36.709999084473,107.41000366211,47.459999084473),
				UseDynamic	=	true,
				HeadColor	=	{
						185,
						211,
						255,
						},
				UseSprite	=	true,
				ProjTexture	=	{
					Forward	=	30,
					Size	=	2000,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				FogColor	=	{
						220,
						225,
						255,
						},
				UsePrjTex	=	true,
				Pos	=	Vector(-29.159999847412,113.62000274658,20.909999847412),
				UseDynamic	=	true,
				UseFog	=	true,
				UseSprite	=	true,
				ProjTexture	=	{
					Size	=	2000,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-36.330001831055,109.66999816895,21.190000534058),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				RenderInner_Size	=	1.2,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				Pos	=	Vector(-32.810001373291,110.08000183105,43.970001220703),
				UseSprite	=	true,
				RunningColor	=	{
						196.13,
						205.61,
						232.07,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				Pos	=	Vector(-32.349998474121,111.33999633789,39.830001831055),
				UseSprite	=	true,
				RunningColor	=	{
						196.13,
						205.61,
						232.07,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseReverse	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				UseDynamic	=	true,
				UseSprite	=	true,
				Pos	=	Vector(38.130001068115,-120.01000213623,39.650001525879),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				UseBrake	=	true,
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				SpecLine	=	{
					Amount	=	16,
					Pos	=	Vector(36.25,-120.36000061035,56.150001525879),
					Use	=	true,
						},
				UseSprite	=	true,
				Pos	=	Vector(37.060001373291,-120.08000183105,42.080001831055),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				Pos	=	Vector(38.400001525879,-119.19999694824,42.139999389648),
				UseRunning	=	true,
				SpecLine	=	{
					Amount	=	6,
					Pos	=	Vector(38.200000762939,-119.19999694824,47.740001678467),
					Use	=	true,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				Pos	=	Vector(38.200000762939,-119.19999694824,48.729999542236),
				UseRunning	=	true,
				SpecLine	=	{
					Amount	=	8,
					Pos	=	Vector(36.919998168945,-119.19999694824,56.470001220703),
					Use	=	true,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				Pos	=	Vector(39.599998474121,-119.19999694824,42.139999389648),
				UseRunning	=	true,
				SpecLine	=	{
					Amount	=	6,
					Pos	=	Vector(39.400001525879,-119.19999694824,47.740001678467),
					Use	=	true,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				Pos	=	Vector(39.400001525879,-119.19999694824,48.729999542236),
				UseRunning	=	true,
				SpecLine	=	{
					Amount	=	8,
					Pos	=	Vector(38.099998474121,-119.19999694824,56.470001220703),
					Use	=	true,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(40.979999542236,-117.80000305176,42.25),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				SpecLine	=	{
					Amount	=	6,
					Pos	=	Vector(40.819999694824,-117.80000305176,47.639999389648),
					Use	=	true,
						},
				RenderInner_Size	=	1.2,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(40.810001373291,-117.80000305176,48.709999084473),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				SpecLine	=	{
					Amount	=	8,
					Pos	=	Vector(39.409999847412,-117.80000305176,56.75),
					Use	=	true,
						},
				RenderInner_Size	=	1.2,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				UseBrake	=	true,
				FogColor	=	{
						255,
						55,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(25.280000686646,-112.29000091553,80.150001525879),
				UseDynamic	=	true,
				UseFog	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				SpecLine	=	{
					Amount	=	19,
					Pos	=	Vector(7.0999999046326,-113.5299987793,80.620002746582),
					Use	=	true,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(49.889999389648,39.380001068115,56.930000305176),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				RenderInner_Size	=	1.2,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(40.810001373291,105.31999969482,47.060001373291),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				SpecLine	=	{
					Amount	=	13,
					Pos	=	Vector(40.909999847412,107.58000183105,36.939998626709),
					Use	=	true,
						},
				RenderInner_Size	=	1.2,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseHead	=	true,
				UsePrjTex	=	true,
				Pos	=	Vector(36.709999084473,107.41000366211,47.459999084473),
				UseDynamic	=	true,
				HeadColor	=	{
						185,
						211,
						255,
						},
				UseSprite	=	true,
				ProjTexture	=	{
					Forward	=	30,
					Size	=	2000,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				FogColor	=	{
						220,
						225,
						255,
						},
				UsePrjTex	=	true,
				Pos	=	Vector(29.159999847412,113.62000274658,20.909999847412),
				UseDynamic	=	true,
				UseFog	=	true,
				UseSprite	=	true,
				ProjTexture	=	{
					Size	=	2000,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(36.330001831055,109.66999816895,21.190000534058),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				RenderInner_Size	=	1.2,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				Pos	=	Vector(32.810001373291,110.08000183105,43.970001220703),
				UseSprite	=	true,
				RunningColor	=	{
						196.13,
						205.61,
						232.07,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				UseSprite	=	true,
				Pos	=	Vector(32.349998474121,111.33999633789,39.830001831055),
				RunningColor	=	{
						196.13,
						205.61,
						232.07,
						},
				UseRunning	=	true,
					},
				},
		Copyright	=	"DurkaTeam @ 2025 No rights reserved",
		Author	=	"freemmaann",
}