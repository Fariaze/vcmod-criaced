-- DurkaTeam @ 2025 Никакие права не защищены
ENT.Base 		= "base_anim"
ENT.Type 		= "anim"
ENT.PrintName	= "Vehicle part: wheel"
ENT.Author		= "freemmaann"
ENT.Category	= "VCMod"

ENT.Spawnable = true
ENT.AdminSpawnable = true

ENT.VC_Type = "carpart"
ENT.VC_Method = "wheel"
ENT.VC_CanBeDamaged = false