VCModels['models/crsk_autosskodafabia_mk1_2001.mdl']	=	{
		em_state	=	5236594536,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		HealthEnginePosOvr	=	true,
		Date	=	"Wed Feb 27 21:59:57 2019",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-15.14999961853,-88.959999084473,12.539999961853),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		Indication	=	{
			fuel	=	{
				max	=	1,
				pp	=	"fuel_needle",
				top	=	1,
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(16,0,0),
				Pos	=	Vector(16.870000839233,17.549999237061,33.310001373291),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(15.800000190735,0,0),
				Pos	=	Vector(-20.139999389648,-30.639999389648,32.020000457764),
					},
				{
				Ang	=	Angle(15.800000190735,0,0),
				Pos	=	Vector(20.139999389648,-30.639999389648,32.020000457764),
					},
				{
				Ang	=	Angle(16,0,0),
				Pos	=	Vector(0,-30.639999389648,31.940000534058),
					},
				},
		HealthEnginePos	=	Vector(0,68.470001220703,41.209999084473),
		DLT	=	3491063024,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-29.379999160767,93.779998779297,32.040000915527),
					Pos2	=	Vector(-34.479999542236,87.26000213623,37.290000915527),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-29.440000534058,90.279998779297,37.349998474121),
					Pos3	=	Vector(-33.380001068115,90.830001831055,32.650001525879),
						},
				UseSprite	=	true,
				Pos	=	Vector(-31.639999389648,90.120002746582,34.950000762939),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				Pos	=	Vector(-38.450000762939,48.080001831055,35.25),
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				Pos	=	Vector(38.909999847412,47.900001525879,35.150001525879),
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				UseSprite	=	true,
				RenderInner_Size	=	2.0862,
				RenderHD_Adv	=	true,
				Pos	=	Vector(-33.729999542236,-83.660003662109,33.069999694824),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	21,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-28.35000038147,-86.769996643066,32.409999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-28.469999313354,-86.650001525879,30.610000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-31.190000534058,-85.639999389648,31.129999160767),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-33.900001525879,-84.620002746582,32.110000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				UseRunning	=	true,
				Pos	=	Vector(-25.409999847412,43.569999694824,51.619998931885),
				SpecMat	=	{
					Select	=	18,
					New	=	"models\crskautos\skoda\fabia_mk1_2001\fabia_dash_on",
					Use	=	true,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(29.89999961853,93.599998474121,31.840000152588),
					Pos2	=	Vector(35,87.400001525879,37.159999847412),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(29.959999084473,90.099998474121,37.150001525879),
					Pos3	=	Vector(33.900001525879,90.650001525879,32.450000762939),
						},
				UseSprite	=	true,
				Pos	=	Vector(32.159999847412,89.940002441406,34.75),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-22.440000534058,97.069999694824,31.559999465942),
					UseColor	=	true,
					Pos2	=	Vector(-28.709999084473,90.180000305176,37.159999847412),
					Color	=	{
						r	=	255,
						b	=	141,
						a	=	255,
						g	=	209,
							},
					Use	=	true,
					Pos1	=	Vector(-22.420000076294,92.309997558594,37.130001068115),
					Pos3	=	Vector(-28.870000839233,94.449996948242,31.860000610352),
						},
				UseSprite	=	true,
				Pos	=	Vector(-25.819999694824,93.120002746582,34.950000762939),
				UseDynamic	=	true,
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RunningColor	=	{
					r	=	255,
					b	=	141,
					a	=	255,
					g	=	209,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-22.440000534058,97.069999694824,31.559999465942),
					UseColor	=	true,
					Pos2	=	Vector(-28.709999084473,90.180000305176,37.159999847412),
					Color	=	{
						r	=	255,
						b	=	141,
						a	=	255,
						g	=	209,
							},
					Use	=	true,
					Pos1	=	Vector(-22.420000076294,92.309997558594,37.130001068115),
					Pos3	=	Vector(-28.870000839233,94.449996948242,31.860000610352),
						},
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	255,
					b	=	141,
					a	=	255,
					g	=	209,
						},
				UseDynamic	=	true,
				UseSprite	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				Pos	=	Vector(-25.819999694824,93.120002746582,34.950000762939),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(22.840000152588,97.069999694824,31.299999237061),
					UseColor	=	true,
					Pos2	=	Vector(29.110000610352,90.180000305176,36.900001525879),
					Color	=	{
						r	=	255,
						b	=	141,
						a	=	255,
						g	=	209,
							},
					Use	=	true,
					Pos1	=	Vector(22.819999694824,92.309997558594,36.869998931885),
					Pos3	=	Vector(29.270000457764,94.449996948242,31.60000038147),
						},
				UseSprite	=	true,
				Pos	=	Vector(26.219999313354,93.120002746582,34.689998626709),
				UseDynamic	=	true,
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RunningColor	=	{
					r	=	255,
					b	=	141,
					a	=	255,
					g	=	209,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(22.840000152588,97.069999694824,31.299999237061),
					UseColor	=	true,
					Pos2	=	Vector(29.110000610352,90.180000305176,36.900001525879),
					Color	=	{
						r	=	255,
						b	=	141,
						a	=	255,
						g	=	209,
							},
					Use	=	true,
					Pos1	=	Vector(22.819999694824,92.309997558594,36.869998931885),
					Pos3	=	Vector(29.270000457764,94.449996948242,31.60000038147),
						},
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	255,
					b	=	141,
					a	=	255,
					g	=	209,
						},
				UseDynamic	=	true,
				UseSprite	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				Pos	=	Vector(26.219999313354,93.120002746582,34.689998626709),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-17.379999160767,97.980003356934,31.559999465942),
					UseColor	=	true,
					Pos2	=	Vector(-22.049999237061,92.180000305176,37.110000610352),
					Color	=	{
						r	=	255,
						b	=	141,
						a	=	255,
						g	=	209,
							},
					Use	=	true,
					Pos1	=	Vector(-17.360000610352,94.279998779297,37.200000762939),
					Pos3	=	Vector(-22.14999961853,96.639999389648,31.860000610352),
						},
				HBeamColor	=	{
					r	=	255,
					b	=	141,
					a	=	255,
					g	=	209,
						},
				UsePrjTex	=	true,
				Pos	=	Vector(-19.989999771118,94.370002746582,34.540000915527),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(17.959999084473,97.879997253418,31.5),
					UseColor	=	true,
					Pos2	=	Vector(22.629999160767,92.080001831055,37.049999237061),
					Color	=	{
						r	=	255,
						b	=	141,
						a	=	255,
						g	=	209,
							},
					Use	=	true,
					Pos1	=	Vector(17.940000534058,94.180000305176,37.139999389648),
					Pos3	=	Vector(22.729999542236,96.540000915527,31.799999237061),
						},
				HBeamColor	=	{
					r	=	255,
					b	=	141,
					a	=	255,
					g	=	209,
						},
				UsePrjTex	=	true,
				Pos	=	Vector(20.569999694824,94.269996643066,34.479999542236),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.098,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseReverse	=	true,
				RenderHD_Adv	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseSprite	=	true,
				Pos	=	Vector(-33.729999542236,-83.470001220703,36.700000762939),
				UseDynamic	=	true,
				RenderInner_Size	=	1.3276,
				SpecMLine	=	{
					Amount	=	15,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-29.139999389648,-86.379997253418,36.779998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-28.440000534058,-86.680000305176,34.950000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-33.630001068115,-83.5,35.860000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseSprite	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner	=	true,
				RenderHD_Adv	=	true,
				Pos	=	Vector(-33.930000305176,-83.730003356934,40.580001831055),
				UseDynamic	=	true,
				RenderInner_Size	=	1.3276,
				SpecMLine	=	{
					Amount	=	17,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-30.110000610352,-85.160003662109,41.470001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-29.170000076294,-85.089996337891,40.200000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-33,-83.540000915527,40.369998931885),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseBlinkers	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.09,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseBrake	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_Size	=	1.3966,
				UseSprite	=	true,
				Pos	=	Vector(-33.729999542236,-83.290000915527,43.959999084473),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	26,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-30.479999542236,-84.23999786377,45.159999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-29.959999084473,-84.940002441406,43.630001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-32.799999237061,-83.800003051758,43.889999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.09,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseBrake	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(33.779998779297,-83.290000915527,43.959999084473),
				UseDynamic	=	true,
				RenderInner_Size	=	1.3966,
				SpecMLine	=	{
					Amount	=	26,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(30.530000686646,-84.23999786377,45.159999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(30.010000228882,-84.940002441406,43.630001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(32.909999847412,-83.800003051758,43.849998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(33.319999694824,-83.730003356934,40.430000305176),
				UseDynamic	=	true,
				RenderInner_Size	=	1.3276,
				SpecMLine	=	{
					Amount	=	17,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(29.5,-85.290000915527,41.319999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(28.559999465942,-85.970001220703,40.049999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(32.389999389648,-84.300003051758,40.220001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderHD_Adv	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseReverse	=	true,
				RenderHD_Adv	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseSprite	=	true,
				Pos	=	Vector(33.299999237061,-83.470001220703,36.790000915527),
				UseDynamic	=	true,
				RenderInner_Size	=	1.3276,
				SpecMLine	=	{
					Amount	=	15,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(28.709999084473,-86.379997253418,36.869998931885),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(28.010000228882,-86.680000305176,35.040000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(33.200000762939,-83.5,35.950000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				UseSprite	=	true,
				RenderInner	=	true,
				RenderHD_Adv	=	true,
				Pos	=	Vector(33.330001831055,-84.110000610352,33.069999694824),
				UseDynamic	=	true,
				RenderInner_Size	=	2.0862,
				SpecMLine	=	{
					Amount	=	21,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(27.950000762939,-87.220001220703,32.409999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(28.069999694824,-87.099998474121,30.610000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(30.790000915527,-86.089996337891,31.129999160767),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(33.5,-85.069999694824,32.110000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	false,
					},
				},
		Copyright	=	"Copyright © 2012-2019 VCMod (freemmaann). All Rights Reserved.",
		Fuel	=	{
			FuelLidPos	=	Vector(38.080001831055,-70.099998474121,42.819999694824),
			Override	=	true,
			FuelType	=	0,
			Capacity	=	45,
			FuelLidUse	=	true,
			FuelTypeUse	=	true,
				},
		Author	=	"CrushingSkirmish (76561198017348899)",
}