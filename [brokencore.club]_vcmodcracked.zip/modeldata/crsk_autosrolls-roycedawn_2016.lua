VCModels['models/crsk_autosrolls-roycedawn_2016.mdl']	=	{
		em_state	=	5236594878,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Date	=	"Mon Sep 11 13:42:22 2017",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-26.239999771118,-125.48000335693,16.159999847412),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-21.799999237061,-126.70999908447,16.14999961853),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(26,-125.48000335693,16.159999847412),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(21.530000686646,-126.70999908447,16.579999923706),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(20,0,0),
				Pos	=	Vector(17.680000305176,-3.0799999237061,33.659999847412),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(20,0,0),
				Pos	=	Vector(-16.540000915527,-42.560001373291,32.139999389648),
					},
				{
				Ang	=	Angle(20,0,0),
				Pos	=	Vector(16.479999542236,-42.930000305176,32.139999389648),
					},
				},
		DLT	=	3491063252,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner_Size	=	1,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-23.14999961853,102.5,28.5),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	7,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-32.430000305176,98.190002441406,28.920000076294),
								},
							},
						},
				UseSprite	=	true,
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
						195,
						195,
						255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-30.719999313354,94.870002746582,36.090000152588),
					Pos2	=	Vector(-32.869998931885,94.819999694824,38.220001220703),
					Color	=	{
							255,
							100,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(-30.85000038147,94.900001525879,38.270000457764),
					Pos3	=	Vector(-32.900001525879,94.790000915527,36.080001831055),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-31.889999389648,95.029998779297,37.169998168945),
				RenderMLCenter	=	true,
				UseSprite	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				HBeamColor	=	{
						195,
						195,
						255,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
						},
				RenderMLCenter	=	true,
				UseRunning	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-22.889999389648,100.59999847412,38.299999237061),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	71,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-22.440000534058,101.51000213623,36.419998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-22.579999923706,101.61000061035,35.950000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.799999237061,99.220001220703,35.919998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.659999847412,98.800003051758,35.709999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.629999160767,98.389999389648,35),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.530000686646,97.949996948242,34.840000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.779998779297,96.139999389648,34.840000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.470001220703,95.650001525879,35.419998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.639999389648,95.209999084473,36.909999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.509998321533,95,38.209999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.130001068115,95.089996337891,38.459999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.64999961853,96.580001831055,38.630001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.760000228882,99.830001831055,38.619998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.10000038147,100.16999816895,38.590000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-23.420000076294,100.5299987793,38.5),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-22.889999389648,100.59999847412,38.299999237061),
								},
							},
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
						195,
						195,
						255,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Use	=	true,
					AmountV	=	4,
					Pos2	=	Vector(33.299999237061,-117.62999725342,44.360000610352),
					AmountH	=	4,
					Pos4	=	Vector(28.479999542236,-120.84999847412,39.580001831055),
					Pos1	=	Vector(30.420000076294,-118.51000213623,45.299999237061),
					Pos3	=	Vector(34.439998626709,-117.7799987793,39.720001220703),
						},
				UseDynamic	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(28.360000610352,-121.08999633789,39.25),
					UseColor	=	true,
					Pos2	=	Vector(33.279998779297,-117.5299987793,45.099998474121),
					Color	=	{
							255,
							100,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(30.770000457764,-118.30000305176,45.349998474121),
					Pos3	=	Vector(34.540000915527,-117.83000183105,39.009998321533),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(31.610000610352,-117.95999908447,41.840000152588),
				UseBlinkers	=	true,
				RenderInner_Size	=	2,
				BlinkersColor	=	{
						255,
						55,
						0,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.075,
						},
				SpecSpin	=	{
						},
				UseRunning	=	true,
				Beta_Inner3D	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(28.340000152588,-121.58000183105,38.759998321533),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	50,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(29.069999694824,-120.91000366211,40.970001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.799999237061,-120.26000213623,42.709999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.35000038147,-119.58999633789,43.919998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.909999847412,-119.05000305176,44.700000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.110000610352,-118.86000061035,44.880001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.659999847412,-118.48999786377,44.909999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.479999542236,-118.01999664307,44.729999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.709999084473,-117.86000061035,44.630001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33,-117.76999664307,44.380001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.450000762939,-117.61000061035,43.849998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.979999542236,-117.61000061035,42.569999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.380001068115,-117.68000030518,40.979999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.549999237061,-117.79000091553,39.709999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.520000457764,-117.93000030518,38.950000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.220001220703,-118.2200012207,38.560001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.439998626709,-119.75,38.5),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.579999923706,-120.7799987793,38.509998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.610000610352,-121.56999969482,38.610000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.389999389648,-121.55999755859,38.790000915527),
								},
							},
						},
				RenderInner	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(29.170000076294,-120.05000305176,39.240001678467),
								},
							},
						},
				UseSprite	=	true,
				Pos	=	Vector(33.729999542236,-118.09999847412,39.229999542236),
				UseDynamic	=	true,
				RenderInner	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				RenderInner_Size	=	1,
				Beta_Inner3D	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.0758,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				UseSprite	=	true,
				Pos	=	Vector(41.080001831055,87.599998474121,36.049999237061),
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	3,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(41.580001831055,85.73999786377,36.040000915527),
								},
							},
						},
				RenderInner	=	true,
				RunningColor	=	{
						255,
						155,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseBrake	=	true,
				Beta_Inner3D	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-7.8699998855591,-97.75,52.470001220703),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	35,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(7.8099999427795,-97.75,52.470001220703),
								},
							},
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.0758,
						},
				SpecSpin	=	{
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-41.650001525879,88.01000213623,36.330001831055),
				UseSprite	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	3,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-42.150001525879,86.150001525879,36.319999694824),
								},
							},
						},
				RenderInner_Size	=	1,
				RunningColor	=	{
						255,
						155,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
						195,
						195,
						255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(30.159999847412,94.860000610352,36.090000152588),
					Pos2	=	Vector(32.310001373291,94.809997558594,38.220001220703),
					Color	=	{
							255,
							100,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(30.290000915527,94.889999389648,38.270000457764),
					Pos3	=	Vector(32.340000152588,94.779998779297,36.080001831055),
						},
				HBeamColor	=	{
						195,
						195,
						255,
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(31.329999923706,95.019996643066,37.169998168945),
				RenderMLCenter	=	true,
				UseSprite	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				SpecMat	=	{
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
						},
				RenderMLCenter	=	true,
				UseRunning	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(22.420000076294,100.59999847412,38.299999237061),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	71,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(21.969999313354,101.51000213623,36.419998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(22.110000610352,101.61000061035,35.950000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.329999923706,99.220001220703,35.919998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.190000534058,98.800003051758,35.709999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.159999847412,98.389999389648,35),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.059999465942,97.949996948242,34.840000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.310001373291,96.139999389648,34.840000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34,95.650001525879,35.419998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.169998168945,95.209999084473,36.909999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.040000915527,95,38.209999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.659999847412,95.089996337891,38.459999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.180000305176,96.580001831055,38.630001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.290000915527,99.830001831055,38.619998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(23.629999160767,100.16999816895,38.590000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(22.950000762939,100.5299987793,38.5),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(22.420000076294,100.59999847412,38.299999237061),
								},
							},
						},
				UseSprite	=	true,
				RunningColor	=	{
						195,
						195,
						255,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.075,
						},
				SpecSpin	=	{
						},
				UseRunning	=	true,
				Beta_Inner3D	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-28.860000610352,-121.58000183105,38.759998321533),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	50,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-29.590000152588,-120.91000366211,40.970001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.319999694824,-120.26000213623,42.709999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.870000839233,-119.58999633789,43.919998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.430000305176,-119.05000305176,44.700000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.629999160767,-118.86000061035,44.880001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.180000305176,-118.48999786377,44.909999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33,-118.01999664307,44.729999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.229999542236,-117.86000061035,44.630001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.520000457764,-117.76999664307,44.380001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.970001220703,-117.61000061035,43.849998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.5,-117.61000061035,42.569999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.900001525879,-117.68000030518,40.979999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.069999694824,-117.79000091553,39.709999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.040000915527,-117.93000030518,38.950000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.740001678467,-118.2200012207,38.560001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.959999084473,-119.75,38.5),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.10000038147,-120.7799987793,38.509998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.129999160767,-121.56999969482,38.610000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.909999847412,-121.55999755859,38.790000915527),
								},
							},
						},
				RenderInner	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Use	=	true,
					AmountV	=	4,
					Pos2	=	Vector(-33.950000762939,-117.62999725342,44.360000610352),
					AmountH	=	4,
					Pos4	=	Vector(-29.129999160767,-120.84999847412,39.580001831055),
					Pos1	=	Vector(-31.069999694824,-118.51000213623,45.299999237061),
					Pos3	=	Vector(-35.090000152588,-117.7799987793,39.720001220703),
						},
				UseDynamic	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-29.010000228882,-121.08999633789,39.25),
					UseColor	=	true,
					Pos2	=	Vector(-33.930000305176,-117.5299987793,45.099998474121),
					Color	=	{
							255,
							100,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(-31.420000076294,-118.30000305176,45.349998474121),
					Pos3	=	Vector(-35.189998626709,-117.83000183105,39.009998321533),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-32.259998321533,-117.95999908447,41.840000152588),
				UseBrake	=	true,
				RenderInner	=	true,
				BlinkersColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Size	=	2,
				UseSprite	=	true,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-34.270000457764,-118.09999847412,39.229999542236),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-29.709999084473,-120.05000305176,39.240001678467),
								},
							},
						},
				ReverseColor	=	{
						200,
						225,
						255,
						},
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	2,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(23.14999961853,102.5,28.5),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	7,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(32.430000305176,98.190002441406,28.920000076294),
								},
							},
						},
				Beta_Inner3D	=	true,
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
				RenderMLCenter	=	true,
					},
				},
		Copyright	=	"Copyright © 2012-2017 VCMod (freemmaann). All Rights Reserved.",
		Fuel	=	{
			FuelLidPos	=	Vector(40.229999542236,-97.650001525879,41.580001831055),
			FuelType	=	0,
			Capacity	=	82,
			Override	=	true,
			FuelLidUse	=	true,
				},
		Author	=	"CrushingSkirmish (76561198017348899)",
}