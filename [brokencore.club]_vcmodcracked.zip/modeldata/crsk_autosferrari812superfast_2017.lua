VCModels['models/crsk_autosferrari812superfast_2017.mdl']	=	{
		em_state	=	5236594359,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Copyright	=	"Copyright © 2012-2017 VCMod (freemmaann). All Rights Reserved.",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-35.720001220703,-113.58999633789,13.510000228882),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(35.360000610352,-113.76000213623,13.409999847412),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-29.940000534058,-116.12999725342,13.550000190735),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(29.530000686646,-116.25,13.430000305176),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(20,0,0),
				Pos	=	Vector(21.430000305176,-21.889999389648,22.75),
				RadioControl	=	true,
					},
				},
		DLT	=	3491062906,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderHD_Size	=	0.6,
				RenderInner_Clr	=	{
						200,
						225,
						255,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(39.680000305176,75.610000610352,35.689998626709),
				RenderMLCenter	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	2,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(40.680000305176,74.599998474121,35.610000610352),
								},
							},
						},
				RenderInner	=	true,
				RunningColor	=	{
						255,
						255,
						253,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderHD_Size	=	0.6,
				RenderInner_Clr	=	{
						200,
						225,
						255,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(39.330001831055,77.580001831055,34.860000610352),
				RenderMLCenter	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(40.450000762939,76.540000915527,34.759998321533),
								},
							},
					Use	=	true,
						},
				RenderInner_Size	=	1,
				RunningColor	=	{
						255,
						255,
						253,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderHD_Size	=	0.6,
				RenderInner_Clr	=	{
						200,
						225,
						255,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(38.919998168945,79.650001525879,34.069999694824),
				RenderMLCenter	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(40.110000610352,78.470001220703,33.990001678467),
								},
							},
					Use	=	true,
						},
				RenderInner	=	true,
				RunningColor	=	{
						255,
						255,
						253,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				LBeamColor	=	{
						200,
						225,
						255,
						},
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	8,
					Use	=	true,
					InnerCenterOnly	=	true,
					Radius	=	1,
						},
				RenderInner_Clr	=	{
						200,
						225,
						255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				UseSprite	=	true,
				Pos	=	Vector(35.669998168945,83.73999786377,30.870000839233),
				RenderHD_Adv	=	true,
				RenderInner_Size	=	4,
				Beta_Inner3D	=	true,
				UseHighBeams	=	true,
				HBeamColor	=	{
						200,
						225,
						255,
						},
				RenderInner	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.07,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderHD_Size	=	1.1,
				RenderInner_Clr	=	{
						200,
						225,
						255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(25.590000152588,98.050003051758,24.870000839233),
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	2,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(26.440000534058,97.519996643066,24.909999847412),
								},
							},
						},
				RenderMLCenter	=	true,
				RenderInner	=	true,
				RenderHD_Adv	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.07,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderHD_Size	=	1.1,
				RenderInner_Clr	=	{
						200,
						225,
						255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				UseSprite	=	true,
				Pos	=	Vector(26.979999542236,96.690002441406,25.639999389648),
				RenderHD_Adv	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(27.829999923706,96.160003662109,25.680000305176),
								},
							},
					Use	=	true,
						},
				UseBlinkers	=	true,
				RenderInner_Size	=	1,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.07,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderHD_Size	=	1.1,
				RenderInner_Clr	=	{
						200,
						225,
						255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				RenderHD_Adv	=	true,
				Pos	=	Vector(28.409999847412,95.459999084473,26.440000534058),
				UseSprite	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	2,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(29.260000228882,94.930000305176,26.479999542236),
								},
							},
						},
				RenderMLCenter	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	35,
					Use	=	true,
					Radius	=	1.84,
						},
				RenderHD_Size	=	1.1,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						255,
						190,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(34.830001831055,-105.69999694824,37.060001373291),
				RenderInner_Size	=	2,
				UseBrake	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
						200,
						225,
						255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
						200,
						225,
						255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(35.669998168945,84.23999786377,30.870000839233),
				RenderMLCenter	=	true,
				RenderInner	=	true,
				HBeamColor	=	{
						200,
						225,
						255,
						},
				UseSprite	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				RenderInner_Size	=	1,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.06,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderHD_Size	=	1.1,
				RenderInner_Clr	=	{
						255,
						255,
						0,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(34.720001220703,-108.51999664307,34.209999084473),
				RenderInner	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	70,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(34.919998168945,-108.45999908447,34.209999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.130001068115,-108.37999725342,34.240001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.349998474121,-108.30000305176,34.279998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.549999237061,-108.2200012207,34.319999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.770000457764,-108.12000274658,34.380001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36,-108.0299987793,34.459999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.220001220703,-107.94000244141,34.580001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.430000305176,-107.84999847412,34.720001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.680000305176,-107.73999786377,34.900001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.880001068115,-107.63999938965,35.110000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.090000152588,-107.54000091553,35.349998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.270000457764,-107.44000244141,35.650001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.389999389648,-107.37000274658,35.880001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.5,-107.29000091553,36.130001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.560001373291,-107.25,36.360000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.610000610352,-107.19999694824,36.599998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.639999389648,-107.16000366211,36.830001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.650001525879,-107.12999725342,37.069999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.639999389648,-107.11000061035,37.319999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.599998474121,-107.09999847412,37.590000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.540000915527,-107.09999847412,37.849998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.439998626709,-107.11000061035,38.130001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.349998474121,-107.12000274658,38.340000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.25,-107.13999938965,38.509998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.150001525879,-107.16000366211,38.680000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.020000457764,-107.19000244141,38.860000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.840000152588,-107.23999786377,39.060001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.669998168945,-107.30999755859,39.229999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.5,-107.36000061035,39.360000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.290000915527,-107.41999816895,39.5),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.060001373291,-107.48999786377,39.619998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.830001831055,-107.56999969482,39.709999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.590000152588,-107.65000152588,39.790000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.369998931885,-107.73999786377,39.849998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.099998474121,-107.83000183105,39.889999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.840000152588,-107.91999816895,39.900001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.520000457764,-108.0299987793,39.889999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.259998321533,-108.12999725342,39.849998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.979999542236,-108.23000335693,39.790000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.75,-108.33000183105,39.720001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.529998779297,-108.41999816895,39.630001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.299999237061,-108.5299987793,39.509998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.130001068115,-108.59999847412,39.389999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.990001678467,-108.66999816895,39.270000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.75,-108.7799987793,39.060001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.540000915527,-108.87999725342,38.819999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.349998474121,-108.9700012207,38.529998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.259998321533,-109.01999664307,38.369998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.169998168945,-109.06999969482,38.159999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.119998931885,-109.09999847412,38.029998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.049999237061,-109.15000152588,37.819999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.989999771118,-109.19999694824,37.610000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.959999084473,-109.23000335693,37.380001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.950000762939,-109.26000213623,37.110000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.940000534058,-109.2799987793,36.889999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.959999084473,-109.30000305176,36.590000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.029998779297,-109.30000305176,36.330001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.099998474121,-109.30000305176,36.110000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.209999084473,-109.29000091553,35.819999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.340000152588,-109.26000213623,35.599998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.490001678467,-109.23000335693,35.360000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.619998931885,-109.19999694824,35.200000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.759998321533,-109.18000030518,35.060001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(32.919998168945,-109.12999725342,34.909999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.099998474121,-109.08000183105,34.759998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.290000915527,-109.01999664307,34.630001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.470001220703,-108.9700012207,34.529998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.669998168945,-108.90000152588,34.430000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.869998931885,-108.83000183105,34.349998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.090000152588,-108.76000213623,34.290000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.270000457764,-108.69999694824,34.259998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.490001678467,-108.61000061035,34.229999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.720001220703,-108.51999664307,34.209999084473),
								},
							},
						},
				RenderMLCenter	=	true,
				RunningColor	=	{
						255,
						0,
						0,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	35,
					Use	=	true,
					Radius	=	1.84,
						},
				RenderHD_Size	=	1.1,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						255,
						190,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(27.020000457764,-109.80000305176,37.430000305176),
				RenderInner	=	true,
				UseBrake	=	true,
				RenderInner_Size	=	2,
				Beta_Inner3D	=	true,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.06,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderHD_Size	=	1.1,
				RenderInner_Clr	=	{
						255,
						255,
						255,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(26.89999961853,-112.58000183105,34.610000610352),
				RenderInner_Size	=	1,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	70,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(27.10000038147,-112.51999664307,34.610000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.309999465942,-112.44000244141,34.639999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.530000686646,-112.36000061035,34.680000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.729999542236,-112.2799987793,34.720001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.950000762939,-112.18000030518,34.779998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.180000305176,-112.08999633789,34.860000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.39999961853,-112,34.979999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.610000610352,-111.91000366211,35.119998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.860000610352,-111.80000305176,35.299999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.059999465942,-111.69999694824,35.509998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.270000457764,-111.59999847412,35.75),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.450000762939,-111.5,36.049999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.569999694824,-111.43000030518,36.279998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.680000305176,-111.34999847412,36.529998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.739999771118,-111.30999755859,36.759998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.790000915527,-111.26000213623,37),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.819999694824,-111.2200012207,37.229999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.829999923706,-111.19000244141,37.470001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.819999694824,-111.16999816895,37.720001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.780000686646,-111.16000366211,37.990001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.719999313354,-111.16000366211,38.25),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.620000839233,-111.16999816895,38.529998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.530000686646,-111.18000030518,38.740001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.430000305176,-111.19999694824,38.909999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.329999923706,-111.2200012207,39.080001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.200000762939,-111.25,39.259998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(29.020000457764,-111.30000305176,39.459999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.85000038147,-111.37000274658,39.630001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.680000305176,-111.41999816895,39.759998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.469999313354,-111.48000335693,39.900001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.239999771118,-111.55000305176,40.020000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.010000228882,-111.62999725342,40.110000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.770000457764,-111.70999908447,40.189998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.549999237061,-111.80000305176,40.25),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.280000686646,-111.88999938965,40.290000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(27.020000457764,-111.98000335693,40.299999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.700000762939,-112.08999633789,40.290000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.440000534058,-112.19000244141,40.25),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.159999847412,-112.29000091553,40.189998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.930000305176,-112.38999938965,40.119998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.709999084473,-112.48000335693,40.029998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.479999542236,-112.58999633789,39.909999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.309999465942,-112.66000366211,39.790000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.170000076294,-112.73000335693,39.669998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.930000305176,-112.83999633789,39.459999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.719999313354,-112.94000244141,39.220001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.530000686646,-113.0299987793,38.930000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.440000534058,-113.08000183105,38.770000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.35000038147,-113.12999725342,38.560001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.299999237061,-113.16000366211,38.430000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.229999542236,-113.20999908447,38.220001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.170000076294,-113.26000213623,38.009998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.139999389648,-113.29000091553,37.779998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.129999160767,-113.31999969482,37.509998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.120000839233,-113.33999633789,37.290000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.139999389648,-113.36000061035,36.990001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.209999084473,-113.36000061035,36.729999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.280000686646,-113.36000061035,36.509998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.389999389648,-113.34999847412,36.220001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.520000457764,-113.31999969482,36),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.670000076294,-113.29000091553,35.759998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.799999237061,-113.26000213623,35.599998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(24.940000534058,-113.23999786377,35.459999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.10000038147,-113.19000244141,35.310001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.280000686646,-113.13999938965,35.159999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.469999313354,-113.08000183105,35.029998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.64999961853,-113.0299987793,34.930000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.85000038147,-112.95999908447,34.830001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.049999237061,-112.88999938965,34.75),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.270000457764,-112.81999969482,34.689998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.450000762939,-112.76000213623,34.659999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.670000076294,-112.66999816895,34.630001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(26.89999961853,-112.58000183105,34.610000610352),
								},
							},
						},
				RenderMLCenter	=	true,
				RunningColor	=	{
						255,
						0,
						0,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
						255,
						255,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(36.540000915527,-106.01999664307,35.349998474121),
					UseColor	=	true,
					Pos2	=	Vector(33.119998931885,-106.01999664307,38.770000457764),
					Color	=	{
							255,
							255,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(36.540000915527,-106.01999664307,38.770000457764),
					Pos3	=	Vector(33.119998931885,-106.01999664307,35.349998474121),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(34.830001831055,-106.01999664307,37.060001373291),
				UseSprite	=	true,
				RenderInner_Size	=	1,
				RenderMLCenter	=	true,
				UseBlinkers	=	true,
				RenderInner	=	true,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				UseDynamic	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				RenderInner_Clr	=	{
						255,
						255,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(28.870000839233,-110.05999755859,35.630001068115),
					Pos2	=	Vector(25.170000076294,-110.05999755859,39.330001831055),
					Color	=	{
							0,
							0,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(28.870000839233,-110.05999755859,39.330001831055),
					Pos3	=	Vector(25.170000076294,-110.05999755859,35.630001068115),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(27.020000457764,-110.05999755859,37.479999542236),
				RenderInner_Size	=	1,
				RenderMLCenter	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderHD_Size	=	0.5,
				BrakeColor	=	{
						255,
						0,
						0,
						},
				RenderInner_Clr	=	{
						255,
						255,
						0,
						},
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBrake	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-12.869999885559,-57,56.909999847412),
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	55,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-6.5100002288818,-57,57.200000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-0.15000000596046,-56.990001678467,57.270000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(6.3600001335144,-57.049999237061,57.169998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(12.869999885559,-57.049999237061,56.869998931885),
								},
							},
						},
				RenderInner	=	true,
				RenderHD_Adv	=	true,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.04,
						},
				SpecSpin	=	{
						},
				RenderMLCenter	=	true,
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Pos4	=	Vector(32.229999542236,85.660003662109,30.409999847412),
					Pos2	=	Vector(31.89999961853,85.970001220703,30.719999313354),
					AmountH	=	4,
					Use	=	true,
					Pos1	=	Vector(32.229999542236,85.650001525879,30.719999313354),
					Pos3	=	Vector(31.920000076294,85.970001220703,30.409999847412),
						},
				RenderInner_Size	=	4,
				HBeamColor	=	{
						200,
						225,
						255,
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				UseSprite	=	true,
				Pos	=	Vector(32.040000915527,85.800003051758,30.569999694824),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				SpecMat	=	{
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
						200,
						225,
						255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.14,
						},
				SpecSpin	=	{
						},
				UseBlinkers	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(47.880001068115,33.659999847412,23.909999847412),
					Pos2	=	Vector(47.880001068115,35.299999237061,25.549999237061),
					Color	=	{
							0,
							0,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(47.880001068115,33.659999847412,25.549999237061),
					Pos3	=	Vector(47.880001068115,35.299999237061,23.909999847412),
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(47.880001068115,34.479999542236,24.729999542236),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				RenderInner	=	true,
				RenderMLCenter	=	true,
				RenderInner_Clr	=	{
						255,
						255,
						0,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.14,
						},
				SpecSpin	=	{
						},
				UseBlinkers	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-47.630001068115,33.880001068115,24.159999847412),
					Pos2	=	Vector(-47.630001068115,35.520000457764,25.799999237061),
					Color	=	{
							0,
							0,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(-47.630001068115,33.880001068115,25.799999237061),
					Pos3	=	Vector(-47.630001068115,35.520000457764,24.159999847412),
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-47.630001068115,34.700000762939,24.979999542236),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderInner_Size	=	1,
				RenderMLCenter	=	true,
				RenderInner_Clr	=	{
						255,
						255,
						0,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				UseDynamic	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				RenderInner_Clr	=	{
						255,
						255,
						0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-29.239999771118,-109.93000030518,35.740001678467),
					Pos2	=	Vector(-25.540000915527,-109.93000030518,39.439998626709),
					Use	=	true,
					Pos1	=	Vector(-29.239999771118,-109.93000030518,39.439998626709),
					Pos3	=	Vector(-25.540000915527,-109.93000030518,35.740001678467),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-27.389999389648,-109.93000030518,37.590000152588),
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				RenderMLCenter	=	true,
				RenderInner_Size	=	1,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderHD_Size	=	1.1,
				RenderInner_Clr	=	{
						255,
						255,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-36.869998931885,-105.84999847412,35.529998779297),
					Pos2	=	Vector(-33.450000762939,-105.84999847412,38.950000762939),
					Color	=	{
							0,
							0,
							0,
							},
					Use	=	true,
					Pos1	=	Vector(-36.869998931885,-105.84999847412,38.950000762939),
					Pos3	=	Vector(-33.450000762939,-105.84999847412,35.529998779297),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-35.159999847412,-105.84999847412,37.240001678467),
				UseSprite	=	true,
				RenderInner	=	true,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				RenderInner_Size	=	1,
				UseBlinkers	=	true,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.04,
						},
				SpecSpin	=	{
						},
				RenderMLCenter	=	true,
				SpecRec	=	{
					InnerCenterOnly	=	true,
					Pos4	=	Vector(-31.709999084473,85.800003051758,30.559999465942),
					Pos2	=	Vector(-31.379999160767,86.110000610352,30.870000839233),
					AmountH	=	4,
					Use	=	true,
					Pos1	=	Vector(-31.709999084473,85.790000915527,30.870000839233),
					Pos3	=	Vector(-31.39999961853,86.110000610352,30.559999465942),
						},
				RenderInner_Size	=	4,
				HBeamColor	=	{
						200,
						225,
						255,
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-31.520000457764,85.940002441406,30.719999313354),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				SpecMat	=	{
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
						200,
						225,
						255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				LBeamColor	=	{
						200,
						225,
						255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
						200,
						225,
						255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				HBeamColor	=	{
						200,
						225,
						255,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-35.240001678467,83.879997253418,31),
				RenderHD_Adv	=	true,
				RenderInner_Size	=	4,
				UseSprite	=	true,
				SpecCircle	=	{
					Amount	=	8,
					Use	=	true,
					InnerCenterOnly	=	true,
					Radius	=	1,
						},
				RenderMLCenter	=	true,
				RenderInner	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderHD_Size	=	0.6,
				RenderInner_Clr	=	{
						200,
						225,
						255,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-38.400001525879,79.839996337891,34.240001678467),
				RenderMLCenter	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	2,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-39.590000152588,78.660003662109,34.159999847412),
								},
							},
						},
				RenderInner_Size	=	1,
				RunningColor	=	{
						255,
						255,
						253,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderHD_Size	=	0.6,
				RenderInner_Clr	=	{
						200,
						225,
						255,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-38.840000152588,77.709999084473,35.029998779297),
				RenderMLCenter	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-39.959999084473,76.669998168945,34.930000305176),
								},
							},
					Use	=	true,
						},
				RenderInner	=	true,
				RunningColor	=	{
						255,
						255,
						253,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderHD_Size	=	0.6,
				RenderInner_Clr	=	{
						200,
						225,
						255,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				SpecMat	=	{
					New	=	"models/xqm/lightlinesred_tool",
					Select	=	3,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-39.200000762939,75.769996643066,35.869998931885),
				RenderMLCenter	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	2,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-40.200000762939,74.76000213623,35.790000915527),
								},
							},
						},
				RenderInner_Size	=	1,
				RunningColor	=	{
						255,
						255,
						253,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.07,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderHD_Size	=	1.1,
				RenderInner_Clr	=	{
						200,
						225,
						255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-27.879999160767,95.559997558594,26.579999923706),
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	2,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-28.729999542236,95.029998779297,26.620000839233),
								},
							},
						},
				RenderMLCenter	=	true,
				RenderInner	=	true,
				RenderHD_Adv	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.07,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderHD_Size	=	1.1,
				RenderInner_Clr	=	{
						200,
						225,
						255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				RenderHD_Adv	=	true,
				Pos	=	Vector(-26.430000305176,96.809997558594,25.760000228882),
				UseSprite	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-27.280000686646,96.279998779297,25.799999237061),
								},
							},
					Use	=	true,
						},
				RenderMLCenter	=	true,
				RenderInner_Size	=	1,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.07,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderHD_Size	=	1.1,
				RenderInner_Clr	=	{
						200,
						225,
						255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	1,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				RenderHD_Adv	=	true,
				Pos	=	Vector(-25.020000457764,98.160003662109,24.979999542236),
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	2,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-25.870000839233,97.629997253418,25.020000457764),
								},
							},
						},
				UseBlinkers	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
						200,
						225,
						255,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
						200,
						225,
						255,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				HBeamColor	=	{
						200,
						225,
						255,
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				RenderHD_Adv	=	true,
				Pos	=	Vector(-35.240001678467,84.379997253418,31),
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				RenderInner_Size	=	1,
				SpecMat	=	{
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.06,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderHD_Size	=	1.1,
				RenderInner_Clr	=	{
						255,
						255,
						255,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-27.280000686646,-112.43000030518,34.779998779297),
				Beta_Inner3D	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	70,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-27.479999542236,-112.37000274658,34.779998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.690000534058,-112.29000091553,34.810001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.909999847412,-112.20999908447,34.849998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.110000610352,-112.12999725342,34.889999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.329999923706,-112.0299987793,34.950000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.559999465942,-111.94000244141,35.029998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.780000686646,-111.84999847412,35.150001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.989999771118,-111.76000213623,35.290000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.239999771118,-111.65000152588,35.470001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.440000534058,-111.55000305176,35.680000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.64999961853,-111.44999694824,35.919998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.829999923706,-111.34999847412,36.220001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.950000762939,-111.2799987793,36.450000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.059999465942,-111.19999694824,36.700000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.120000839233,-111.16000366211,36.930000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.170000076294,-111.11000061035,37.169998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.200000762939,-111.06999969482,37.400001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.209999084473,-111.04000091553,37.639999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.200000762939,-111.01999664307,37.889999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.159999847412,-111.01000213623,38.159999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.10000038147,-111.01000213623,38.419998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30,-111.01999664307,38.700000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.909999847412,-111.0299987793,38.909999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.809999465942,-111.05000305176,39.080001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.709999084473,-111.06999969482,39.25),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.579999923706,-111.09999847412,39.430000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.39999961853,-111.15000152588,39.630001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.229999542236,-111.2200012207,39.799999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-29.059999465942,-111.26999664307,39.930000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.85000038147,-111.33000183105,40.069999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.620000839233,-111.40000152588,40.189998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.389999389648,-111.48000335693,40.279998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.14999961853,-111.55999755859,40.360000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.930000305176,-111.65000152588,40.419998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.659999847412,-111.73999786377,40.459999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.39999961853,-111.83000183105,40.470001220703),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.079999923706,-111.94000244141,40.459999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.819999694824,-112.04000091553,40.419998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.540000915527,-112.13999938965,40.360000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.309999465942,-112.23999786377,40.290000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.090000152588,-112.33000183105,40.200000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.860000610352,-112.44000244141,40.080001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.690000534058,-112.51000213623,39.959999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.549999237061,-112.58000183105,39.840000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.309999465942,-112.69000244141,39.630001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.10000038147,-112.79000091553,39.389999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.909999847412,-112.87999725342,39.099998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.819999694824,-112.93000030518,38.939998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.729999542236,-112.98000335693,38.729999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.680000305176,-113.01000213623,38.599998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.610000610352,-113.05999755859,38.389999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.549999237061,-113.11000061035,38.180000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.520000457764,-113.13999938965,37.950000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.510000228882,-113.16999816895,37.680000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.5,-113.19000244141,37.459999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.520000457764,-113.20999908447,37.159999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.590000152588,-113.20999908447,36.900001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.659999847412,-113.20999908447,36.680000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.770000457764,-113.19999694824,36.389999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-24.89999961853,-113.16999816895,36.169998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.049999237061,-113.13999938965,35.930000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.180000305176,-113.11000061035,35.770000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.319999694824,-113.08999633789,35.630001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.479999542236,-113.04000091553,35.479999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.659999847412,-112.98999786377,35.330001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-25.85000038147,-112.93000030518,35.200000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.030000686646,-112.87999725342,35.099998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.229999542236,-112.80999755859,35),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.430000305176,-112.73999786377,34.919998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.64999961853,-112.66999816895,34.860000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.829999923706,-112.61000061035,34.830001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.049999237061,-112.51999664307,34.799999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-27.280000686646,-112.43000030518,34.779998779297),
								},
							},
						},
				RenderMLCenter	=	true,
				RunningColor	=	{
						255,
						0,
						0,
						},
				RenderInner_Size	=	1,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.06,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				RenderHD_Size	=	1.1,
				RenderInner_Clr	=	{
						255,
						255,
						0,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-35.090000152588,-108.34999847412,34.380001068115),
				UseSprite	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	70,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-35.290000915527,-108.29000091553,34.380001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.5,-108.20999908447,34.409999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.720001220703,-108.12999725342,34.450000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.919998168945,-108.05000305176,34.490001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.139999389648,-107.94999694824,34.549999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.369998931885,-107.86000061035,34.630001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.590000152588,-107.76999664307,34.75),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.799999237061,-107.68000030518,34.889999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.049999237061,-107.56999969482,35.069999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.25,-107.4700012207,35.279998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.459999084473,-107.37000274658,35.520000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.639999389648,-107.26999664307,35.819999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.759998321533,-107.19999694824,36.049999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.869998931885,-107.12000274658,36.299999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.930000305176,-107.08000183105,36.529998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.979999542236,-107.0299987793,36.770000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.009998321533,-106.98999786377,37),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.020000457764,-106.95999908447,37.240001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-38.009998321533,-106.94000244141,37.490001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.970001220703,-106.93000030518,37.759998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.909999847412,-106.93000030518,38.020000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.810001373291,-106.94000244141,38.299999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.720001220703,-106.94999694824,38.509998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.619998931885,-106.9700012207,38.680000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.520000457764,-106.98999786377,38.849998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.389999389648,-107.01999664307,39.029998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.209999084473,-107.06999969482,39.229999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.040000915527,-107.13999938965,39.400001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.869998931885,-107.19000244141,39.529998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.659999847412,-107.25,39.669998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.430000305176,-107.31999969482,39.790000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.200000762939,-107.40000152588,39.880001068115),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.959999084473,-107.48000335693,39.959999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.740001678467,-107.56999969482,40.020000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.470001220703,-107.66000366211,40.060001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.209999084473,-107.75,40.069999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.889999389648,-107.86000061035,40.060001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.630001068115,-107.95999908447,40.020000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.349998474121,-108.05999755859,39.959999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.119998931885,-108.16000366211,39.889999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.900001525879,-108.25,39.799999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.669998168945,-108.36000061035,39.680000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.5,-108.43000030518,39.560001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.360000610352,-108.5,39.439998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.119998931885,-108.61000061035,39.229999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.909999847412,-108.70999908447,38.990001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.720001220703,-108.80000305176,38.700000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.630001068115,-108.84999847412,38.540000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.540000915527,-108.90000152588,38.330001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.490001678467,-108.93000030518,38.200000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.419998168945,-108.98000335693,37.990001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.360000610352,-109.0299987793,37.779998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.330001831055,-109.05999755859,37.549999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.319999694824,-109.08999633789,37.279998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.310001373291,-109.11000061035,37.060001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.330001831055,-109.12999725342,36.759998321533),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.400001525879,-109.12999725342,36.5),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.470001220703,-109.12999725342,36.279998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.580001831055,-109.12000274658,35.990001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.709999084473,-109.08999633789,35.770000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.860000610352,-109.05999755859,35.529998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.990001678467,-109.0299987793,35.369998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.130001068115,-109.01000213623,35.229999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.290000915527,-108.95999908447,35.080001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.470001220703,-108.91000366211,34.930000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.659999847412,-108.84999847412,34.799999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.840000152588,-108.80000305176,34.700000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.040000915527,-108.73000335693,34.599998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.240001678467,-108.66000366211,34.520000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.459999084473,-108.58999633789,34.459999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.639999389648,-108.5299987793,34.430000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.860000610352,-108.44000244141,34.400001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.090000152588,-108.34999847412,34.380001068115),
								},
							},
						},
				RenderMLCenter	=	true,
				RunningColor	=	{
						255,
						0,
						0,
						},
				RenderInner_Size	=	1,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	35,
					Use	=	true,
					Radius	=	1.84,
						},
				RenderHD_Size	=	1.1,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						255,
						190,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-27.329999923706,-109.69999694824,37.599998474121),
				RenderInner	=	true,
				UseBrake	=	true,
				RenderInner_Size	=	2,
				UseSprite	=	true,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	35,
					Use	=	true,
					Radius	=	1.84,
						},
				RenderHD_Size	=	1.1,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						255,
						190,
						0,
						},
				RenderInner_ClrUse	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-35.130001068115,-105.59999847412,37.220001220703),
				RenderInner	=	true,
				UseSprite	=	true,
				RenderInner_Size	=	2,
				RenderMLCenter	=	true,
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.01,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				SpecRec	=	{
					Use	=	true,
					Pos2	=	Vector(-23.889999389648,3.210000038147,41.360000610352),
					Pos4	=	Vector(-23.920000076294,3.2000000476837,41.349998474121),
					Pos1	=	Vector(-23.89999961853,3.210000038147,41.340000152588),
					Pos3	=	Vector(-23.89999961853,3.2000000476837,41.330001831055),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				IsInterior	=	true,
				Beta_Inner3D	=	true,
				LBeamColor	=	{
					r	=	55,
					b	=	0,
					a	=	255,
					g	=	255,
						},
				UseSprite	=	true,
				RenderHD_Size	=	1.1,
				RenderMLCenter	=	true,
				Pos	=	Vector(-23.89999961853,3.1500000953674,41.349998474121),
				Spec3D	=	{
					Mat	=	"vcmod/gui/icons/dashboard/lowbeams.png",
					Pos4	=	Vector(-24.14999961853,3.1800000667572,41.130001068115),
					UseColor	=	true,
					Pos2	=	Vector(-23.659999847412,3.2799999713898,41.610000610352),
					Color	=	{
						r	=	55,
						b	=	0,
						a	=	255,
						g	=	255,
							},
					Use	=	true,
					Pos1	=	Vector(-24.14999961853,3.2799999713898,41.590000152588),
					Pos3	=	Vector(-23.659999847412,3.1800000667572,41.099998474121),
						},
					},
				},
		Date	=	"Mon Dec 11 00:51:14 2017",
		Fuel	=	{
			FuelType	=	0,
			FuelLidPos	=	Vector(0,0,0),
				},
		Author	=	"CгεερεгƬv (76561198051637331)",
}