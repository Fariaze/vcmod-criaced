VCModels['models/crsk_autosgaz24_volga.mdl']	=	{
		em_state	=	5236594641,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Copyright	=	"Copyright © 2012-2017 VCMod (freemmaann). All Rights Reserved.",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(16.940000534058,-121.80000305176,17.319999694824),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust_Truck",
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(20,0,0),
				Pos	=	Vector(18.670000076294,13.130000114441,34.319999694824),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(20,0,0),
				Pos	=	Vector(-24.030000686646,-31.430000305176,34.319999694824),
					},
				{
				Ang	=	Angle(20,0,0),
				Pos	=	Vector(20.770000457764,-31.430000305176,34.319999694824),
					},
				{
				Ang	=	Angle(20,0,0),
				Pos	=	Vector(-3.2599999904633,-32.049999237061,34.319999694824),
					},
				{
				Ang	=	Angle(20,0,0),
				Pos	=	Vector(0,14.779999732971,34.319999694824),
				BGroups	=	{
					[12]	=	{
							"siduha_centr",
							},
						},
					},
				},
		DLT	=	3491063094,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(42.569999694824,95.900001525879,41.459999084473),
				UseDynamic	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				UseBlinkers	=	true,
				RenderInner_Clr	=	{
						200,
						225,
						255,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(38.869998931885,99.569999694824,29.040000915527),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	6,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(41.369998931885,98.980003356934,29.030000686646),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(41.939998626709,96.269996643066,28.790000915527),
								},
							},
						},
				UseSprite	=	true,
				RenderInner_Clr	=	{
						200,
						225,
						255,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					Use	=	true,
					Pos2	=	Vector(32.180000305176,-132.69999694824,37.610000610352),
					Pos4	=	Vector(39.450000762939,-132.21000671387,35.299999237061),
					Pos1	=	Vector(39.220001220703,-132.71000671387,37.689998626709),
					Pos3	=	Vector(32.639999389648,-132.21000671387,35.220001220703),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(35.909999847412,-132.21000671387,36.290000915527),
				UseDynamic	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(38.639999389648,-131.89999389648,35.299999237061),
					Pos2	=	Vector(32.709999084473,-132.69999694824,37.680000305176),
					Color	=	{
							255,
							225,
							200,
							},
					Use	=	true,
					Pos1	=	Vector(39.110000610352,-132.44000244141,37.689998626709),
					Pos3	=	Vector(33.169998168945,-132.21000671387,35.220001220703),
						},
				UseBlinkers	=	true,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					Pos4	=	Vector(39.360000610352,-132.75,38.700000762939),
					Pos2	=	Vector(33.819999694824,-131.80999755859,42.360000610352),
					Use	=	true,
					Pos1	=	Vector(38.599998474121,-131.67999267578,42.330001831055),
					Pos3	=	Vector(32.979999542236,-132.78999328613,38.740001678467),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(36.459999084473,-132.44999694824,40.169998168945),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
				UseRunning	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(39.430000305176,-132.75,38.700000762939),
					Pos2	=	Vector(33.950000762939,-131.80999755859,42.360000610352),
					Color	=	{
							255,
							225,
							200,
							},
					Use	=	true,
					Pos1	=	Vector(38.720001220703,-131.67999267578,42.330001831055),
					Pos3	=	Vector(32.990001678467,-132.78999328613,38.740001678467),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBrake	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(33.520000457764,-132.55000305176,37.990001678467),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(38.549999237061,-132.55000305176,37.959999084473),
								},
							},
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						200,
						225,
						255,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(-38.75,101.4700012207,33.159999847412),
					UseColor	=	true,
					Pos2	=	Vector(-28.180000305176,101.4700012207,43.479999542236),
					Color	=	{
							255,
							225,
							200,
							},
					Use	=	true,
					Pos1	=	Vector(-38.409999847412,101.4700012207,43.490001678467),
					Pos3	=	Vector(-27.860000610352,101.4700012207,33.049999237061),
						},
				HBeamColor	=	{
						255,
						185,
						150,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
						255,
						185,
						150,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				Pos	=	Vector(-33.349998474121,101.4700012207,38.319999694824),
				UseSprite	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/stadium_2x6_texture",
					Pos4	=	Vector(-35.909999847412,100.90000152588,27.719999313354),
					UseColor	=	true,
					Pos2	=	Vector(-29.10000038147,101.08999633789,30.790000915527),
					Color	=	{
							255,
							225,
							200,
							},
					Use	=	true,
					Pos1	=	Vector(-36.139999389648,100.79000091553,30.729999542236),
					Pos3	=	Vector(-29.270000457764,101.12000274658,27.680000305176),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-34.220001220703,100.40000152588,29.239999771118),
				UseDynamic	=	true,
				UseRunning	=	true,
				SpecMLine	=	{
					Amount	=	6,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-30.530000686646,100.38999938965,29.219999313354),
								},
							},
						},
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
				RunningColor	=	{
						255,
						185,
						150,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-41.930000305176,95.900001525879,41.459999084473),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				UseBlinkers	=	true,
				RenderInner_Clr	=	{
						200,
						225,
						255,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-38.189998626709,99.569999694824,29.040000915527),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	6,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-40.689998626709,98.980003356934,29.030000686646),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-41.259998321533,96.269996643066,28.790000915527),
								},
							},
						},
				Beta_Inner3D	=	true,
				RenderInner_Clr	=	{
						200,
						225,
						255,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				SpecRec	=	{
					Use	=	true,
					Pos2	=	Vector(-34.270000457764,-131.91999816895,35.409999847412),
					Pos4	=	Vector(-39.020000457764,-131.33000183105,31.959999084473),
					Pos1	=	Vector(-38.409999847412,-131.94999694824,36),
					Pos3	=	Vector(-33.009998321533,-131.30999755859,31.930000305176),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-36.580001831055,-131.86999511719,33.150001525879),
				UseDynamic	=	true,
				ReverseColor	=	{
						255,
						185,
						150,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-38.360000610352,-130.67999267578,31.60000038147),
					UseColor	=	true,
					Pos2	=	Vector(-33.360000610352,-132.00999450684,35.470001220703),
					Color	=	{
							255,
							225,
							200,
							},
					Use	=	true,
					Pos1	=	Vector(-38.970001220703,-131.83000183105,35.409999847412),
					Pos3	=	Vector(-34.439998626709,-130.94999694824,31.590000152588),
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					Pos4	=	Vector(-39.909999847412,-132.0299987793,35.419998168945),
					Pos2	=	Vector(-32.639999389648,-132.52000427246,37.729999542236),
					Use	=	true,
					Pos1	=	Vector(-39.680000305176,-132.5299987793,37.810001373291),
					Pos3	=	Vector(-33.099998474121,-132.0299987793,35.340000152588),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-36.369998931885,-132.0299987793,36.409999847412),
				UseDynamic	=	true,
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseBlinkers	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-39.099998474121,-131.63999938965,35.419998168945),
					Pos2	=	Vector(-33.169998168945,-132.66999816895,37.799999237061),
					Color	=	{
							255,
							225,
							200,
							},
					Use	=	true,
					Pos1	=	Vector(-39.569999694824,-132.28999328613,37.810001373291),
					Pos3	=	Vector(-33.630001068115,-132.0299987793,35.340000152588),
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-39.430000305176,-132.75,38.700000762939),
					Pos2	=	Vector(-33.950000762939,-131.80999755859,42.360000610352),
					Color	=	{
							255,
							225,
							200,
							},
					Use	=	true,
					Pos1	=	Vector(-38.720001220703,-131.67999267578,42.330001831055),
					Pos3	=	Vector(-32.990001678467,-132.78999328613,38.740001678467),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-36.459999084473,-132.44999694824,40.169998168945),
				UseDynamic	=	true,
				UseRunning	=	true,
				Beta_Inner3D	=	true,
				SpecRec	=	{
					Use	=	true,
					Pos2	=	Vector(-33.819999694824,-131.80999755859,42.360000610352),
					Pos4	=	Vector(-39.360000610352,-132.75,38.700000762939),
					Pos1	=	Vector(-38.599998474121,-131.67999267578,42.330001831055),
					Pos3	=	Vector(-32.979999542236,-132.78999328613,38.740001678467),
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBrake	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-33.759998321533,-132.21000671387,38.119998931885),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-38.810001373291,-132.21000671387,38.090000152588),
								},
							},
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RenderInner_Clr	=	{
						200,
						225,
						255,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/stadium_2x6_texture",
					Pos4	=	Vector(36.380001068115,100.90000152588,27.569999694824),
					UseColor	=	true,
					Pos2	=	Vector(29.569999694824,100.90000152588,30.639999389648),
					Color	=	{
							255,
							225,
							200,
							},
					Use	=	true,
					Pos1	=	Vector(36.610000610352,100.79000091553,30.579999923706),
					Pos3	=	Vector(29.739999771118,100.95999908447,27.530000686646),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(34.689998626709,100.40000152588,29.090000152588),
				UseDynamic	=	true,
				UseRunning	=	true,
				SpecMLine	=	{
					Amount	=	6,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(31,100.38999938965,29.069999694824),
								},
							},
						},
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
				RunningColor	=	{
						255,
						185,
						150,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(39.639999389648,101.23999786377,33.080001831055),
					UseColor	=	true,
					Pos2	=	Vector(29.069999694824,101.23999786377,43.400001525879),
					Color	=	{
							255,
							225,
							200,
							},
					Use	=	true,
					Pos1	=	Vector(39.299999237061,101.23999786377,43.409999847412),
					Pos3	=	Vector(28.75,101.23999786377,32.970001220703),
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				HBeamColor	=	{
						255,
						185,
						150,
						},
				ReducedVis	=	true,
				SpecMat	=	{
						},
				UsePrjTex	=	true,
				LBeamColor	=	{
						255,
						185,
						150,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				UseSprite	=	true,
				Pos	=	Vector(34.240001678467,101.23999786377,38.240001678467),
				Beta_Inner3D	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				SpecRec	=	{
					Pos4	=	Vector(38.729999542236,-131.58999633789,31.959999084473),
					Pos2	=	Vector(33.979999542236,-132.17999267578,35.409999847412),
					Use	=	true,
					Pos1	=	Vector(38.119998931885,-132.21000671387,36),
					Pos3	=	Vector(32.720001220703,-131.57000732422,31.930000305176),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(36.290000915527,-132.13000488281,33.150001525879),
				UseDynamic	=	true,
				ReverseColor	=	{
						255,
						185,
						150,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(38.069999694824,-130.94000244141,31.60000038147),
					UseColor	=	true,
					Pos2	=	Vector(33.069999694824,-132.27000427246,35.470001220703),
					Color	=	{
							255,
							225,
							200,
							},
					Use	=	true,
					Pos1	=	Vector(38.680000305176,-132.08999633789,35.409999847412),
					Pos3	=	Vector(34.150001525879,-131.21000671387,31.590000152588),
						},
				UseSprite	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				},
		Date	=	"Wed Sep  6 19:20:22 2017",
		Fuel	=	{
			FuelLidPos	=	Vector(-42.319999694824,-118.76999664307,33.569999694824),
			FuelType	=	0,
			Capacity	=	55,
			Override	=	true,
			FuelLidUse	=	true,
				},
		Author	=	"CrushingSkirmish (76561198017348899)",
}