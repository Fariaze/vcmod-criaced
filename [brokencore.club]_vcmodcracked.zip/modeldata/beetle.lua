VCModels['models/beetle.mdl']	=	{
		em_state	=	5236594515,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Copyright	=	"DurkaTeam @ 2025 No rights reserved",
		Exhaust	=	{
				{
				Ang	=	Angle(30,-90,0),
				Pos	=	Vector(13.10000038147,-53.700000762939,13.260000228882),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(13.789999961853,7.6700000762939,22.680000305176),
				RadioControl	=	true,
					},
				},
		DLT	=	3491063010,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-25.35000038147,-63.840000152588,22.030000686646),
				UseDynamic	=	true,
				UseBrake	=	true,
				UseRunning	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				SpecSpin	=	{
						},
				UseHead	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-20.260000228882,68.190002441406,24.290000915527),
				UseDynamic	=	true,
				HeadColor	=	{
						189,
						216,
						255,
						},
				ProjTexture	=	{
					Forward	=	30,
					Size	=	2000,
					Angle	=	Angle(0,90,0),
						},
				UsePrjTex	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Pos	=	Vector(-20.14999961853,68.150001525879,24.340000152588),
				UseSprite	=	true,
				RunningColor	=	{
						229.07,
						221.34,
						241.83,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(25.35000038147,-63.840000152588,22.030000686646),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseRunning	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				SpecSpin	=	{
						},
				UseHead	=	true,
				UsePrjTex	=	true,
				Pos	=	Vector(20.260000228882,68.190002441406,24.290000915527),
				UseDynamic	=	true,
				HeadColor	=	{
						189,
						216,
						255,
						},
				UseSprite	=	true,
				ProjTexture	=	{
					Forward	=	30,
					Size	=	2000,
					Angle	=	Angle(0,90,0),
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Pos	=	Vector(20.14999961853,68.150001525879,24.340000152588),
				UseSprite	=	true,
				RunningColor	=	{
						229.07,
						221.34,
						241.83,
						},
				UseRunning	=	true,
					},
				},
		Date	=	"10/09/15 22:31:27",
		Author	=	"freemmaann (76561197989323181)",
}