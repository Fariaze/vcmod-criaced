VCModels['models/bsgcarschev_camzl1_und.mdl']	=	{
		em_state	=	5236594374,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Siren	=	{
			Sounds	=	{
					{
					Volume	=	1,
					Pitch	=	100,
					Distance	=	95,
					Name	=	"Wail",
					Sound	=	"vcmod/els/cencom/wail.wav",
						},
					{
					Volume	=	1,
					Pitch	=	100,
					Distance	=	95,
					Name	=	"Yelp",
					Sound	=	"vcmod/els/cencom/yelp.wav",
						},
					{
					Volume	=	1,
					Pitch	=	100,
					Distance	=	95,
					Name	=	"Priority",
					Sound	=	"vcmod/els/cencom/priority.wav",
						},
					},
			Sequences	=	{
					{
					SubSeq	=	{
							{
							Stages	=	{
									{
									Lights	=	{
											2,
											},
									Time	=	0.2,
										},
									{
									Lights	=	{
											1,
											},
									Time	=	0.2,
										},
									},
							Time	=	5,
								},
							{
							Stages	=	{
									{
									Lights	=	{
											2,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											2,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											1,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											1,
											},
									Time	=	0.05,
										},
									{
									Lights	=	{
											},
									Time	=	0.05,
										},
									},
							Time	=	5,
								},
							},
					Codes	=	{
						[7]	=	true,
							},
					Lights_Sel	=	{
							true,
							true,
							},
						},
					{
					SubSeq	=	{
							{
							Stages	=	{
									{
									Lights	=	{
											7,
											3,
											},
									Time	=	0.075,
										},
									{
									Lights	=	{
											8,
											4,
											},
									Time	=	0.075,
										},
									{
									Lights	=	{
											9,
											5,
											},
									Time	=	0.075,
										},
									{
									Lights	=	{
											10,
											6,
											},
									Time	=	0.075,
										},
									{
									Lights	=	{
											9,
											5,
											},
									Time	=	0.075,
										},
									{
									Lights	=	{
											8,
											4,
											},
									Time	=	0.075,
										},
									},
							Time	=	5,
								},
							{
							Stages	=	{
									{
									Lights	=	{
											7,
											8,
											9,
											10,
											},
									Time	=	0.3,
										},
									{
									Lights	=	{
											3,
											4,
											5,
											6,
											},
									Time	=	0.3,
										},
									},
							Time	=	3,
								},
							{
							Stages	=	{
									{
									Lights	=	{
											7,
											},
									Time	=	0.1,
										},
									{
									Lights	=	{
											8,
											},
									Time	=	0.1,
										},
									{
									Lights	=	{
											9,
											},
									Time	=	0.1,
										},
									{
									Lights	=	{
											10,
											},
									Time	=	0.1,
										},
									{
									Lights	=	{
											6,
											},
									Time	=	0.1,
										},
									{
									Lights	=	{
											5,
											},
									Time	=	0.1,
										},
									{
									Lights	=	{
											4,
											},
									Time	=	0.1,
										},
									{
									Lights	=	{
											3,
											},
									Time	=	0.1,
										},
									{
									Lights	=	{
											4,
											},
									Time	=	0.1,
										},
									{
									Lights	=	{
											5,
											},
									Time	=	0.1,
										},
									{
									Lights	=	{
											6,
											},
									Time	=	0.1,
										},
									{
									Lights	=	{
											10,
											},
									Time	=	0.1,
										},
									{
									Lights	=	{
											9,
											},
									Time	=	0.1,
										},
									{
									Lights	=	{
											8,
											},
									Time	=	0.1,
										},
									},
							Time	=	3,
								},
							},
					Codes	=	{
						[7]	=	true,
							},
					Lights_Sel	=	{
						[3]	=	true,
						[4]	=	true,
						[5]	=	true,
						[6]	=	true,
						[7]	=	true,
						[8]	=	true,
						[9]	=	true,
						[10]	=	true,
							},
						},
					{
					SubSeq	=	{
							{
							Stages	=	{
									{
									Lights	=	{
											15,
											16,
											17,
											18,
											},
									Time	=	0.1,
										},
									{
									Lights	=	{
											11,
											12,
											13,
											14,
											},
									Time	=	0.1,
										},
									},
							Time	=	5,
								},
							{
							Stages	=	{
									{
									Lights	=	{
											15,
											16,
											17,
											18,
											},
									Time	=	0.2,
										},
									{
									Lights	=	{
											11,
											12,
											13,
											14,
											},
									Time	=	0.2,
										},
									},
							Time	=	2,
								},
							{
							Stages	=	{
									{
									Lights	=	{
											15,
											16,
											17,
											18,
											},
									Time	=	0.5,
										},
									{
									Lights	=	{
											11,
											12,
											13,
											14,
											},
									Time	=	0.5,
										},
									},
							Time	=	2,
								},
							},
					Codes	=	{
						[7]	=	true,
							},
					Lights_Sel	=	{
						[11]	=	true,
						[12]	=	true,
						[13]	=	true,
						[14]	=	true,
						[15]	=	true,
						[16]	=	true,
						[17]	=	true,
						[18]	=	true,
							},
						},
					},
			Sections	=	{
				[1]	=	{
					[3]	=	true,
					[4]	=	true,
					[5]	=	true,
					[6]	=	true,
					[7]	=	true,
					[8]	=	true,
					[9]	=	true,
					[10]	=	true,
						},
				[2]	=	{
					[11]	=	true,
					[12]	=	true,
					[13]	=	true,
					[14]	=	true,
					[15]	=	true,
					[16]	=	true,
					[17]	=	true,
					[18]	=	true,
						},
				[5]	=	{
					[3]	=	true,
					[4]	=	true,
					[5]	=	true,
					[6]	=	true,
					[7]	=	true,
					[8]	=	true,
					[9]	=	true,
					[10]	=	true,
						},
					},
			Lights	=	{
					{
					Sprite	=	{
						Size	=	0.15,
							},
					Dynamic	=	{
						Size	=	0.55,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(16.700000762939,-73,56.799999237061),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							0,
							55,
							255,
							},
					SpecLine	=	{
						Amount	=	8,
						Use	=	true,
						Pos	=	Vector(20.870000839233,-73.019996643066,56.799999237061),
							},
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.15,
							},
					Dynamic	=	{
						Size	=	0.55,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-16.700000762939,-73,56.799999237061),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					SpecLine	=	{
						Amount	=	8,
						Use	=	true,
						Pos	=	Vector(-20.870000839233,-73.019996643066,56.799999237061),
							},
					UseSprite	=	true,
					Beta_Inner3D	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.075,
							},
					Dynamic	=	{
						Size	=	0.45,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(16.719999313354,109.59999847412,34.790000915527),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							0,
							55,
							255,
							},
					SpecLine	=	{
						Amount	=	6,
						Use	=	true,
						Pos	=	Vector(14.89999961853,110.23999786377,34.680000305176),
							},
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.075,
							},
					Dynamic	=	{
						Size	=	0.45,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(14.369999885559,110.30000305176,34.580001831055),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							0,
							55,
							255,
							},
					SpecLine	=	{
						Amount	=	6,
						Use	=	true,
						Pos	=	Vector(12.550000190735,110.94000244141,34.470001220703),
							},
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.075,
							},
					Dynamic	=	{
						Size	=	0.45,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(12.069999694824,111.19999694824,34.540000915527),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							0,
							55,
							255,
							},
					SpecLine	=	{
						Amount	=	6,
						Use	=	true,
						Pos	=	Vector(10.25,111.83999633789,34.430000305176),
							},
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.075,
							},
					Dynamic	=	{
						Size	=	0.45,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(9.6999998092651,112.19999694824,34.540000915527),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							0,
							55,
							255,
							},
					SpecLine	=	{
						Amount	=	6,
						Use	=	true,
						Pos	=	Vector(7.8800001144409,112.83999633789,34.430000305176),
							},
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.075,
							},
					Dynamic	=	{
						Size	=	0.45,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-16.719999313354,109.59999847412,34.790000915527),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					SpecLine	=	{
						Amount	=	6,
						Use	=	true,
						Pos	=	Vector(-14.89999961853,110.23999786377,34.680000305176),
							},
					UseSprite	=	true,
					Beta_Inner3D	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.075,
							},
					Dynamic	=	{
						Size	=	0.45,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-14.369999885559,110.30000305176,34.580001831055),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					SpecLine	=	{
						Amount	=	6,
						Use	=	true,
						Pos	=	Vector(-12.550000190735,110.94000244141,34.470001220703),
							},
					UseSprite	=	true,
					Beta_Inner3D	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.075,
							},
					Dynamic	=	{
						Size	=	0.45,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-12.069999694824,111.19999694824,34.540000915527),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					SpecLine	=	{
						Amount	=	6,
						Use	=	true,
						Pos	=	Vector(-10.25,111.83999633789,34.430000305176),
							},
					UseSprite	=	true,
					Beta_Inner3D	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.075,
							},
					Dynamic	=	{
						Size	=	0.45,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-9.6999998092651,112.19999694824,34.540000915527),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					SpecLine	=	{
						Amount	=	6,
						Use	=	true,
						Pos	=	Vector(-7.8800001144409,112.83999633789,34.430000305176),
							},
					UseSprite	=	true,
					Beta_Inner3D	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.075,
							},
					Dynamic	=	{
						Size	=	0.45,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(8.5500001907349,36.400001525879,51.700000762939),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							0,
							55,
							255,
							},
					SpecLine	=	{
						Amount	=	6,
						Use	=	true,
						Pos	=	Vector(6.9000000953674,36.400001525879,51.700000762939),
							},
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.075,
							},
					Dynamic	=	{
						Size	=	0.45,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(6.5599999427795,36.400001525879,51.700000762939),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							0,
							55,
							255,
							},
					SpecLine	=	{
						Amount	=	6,
						Use	=	true,
						Pos	=	Vector(4.9099998474121,36.400001525879,51.700000762939),
							},
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.075,
							},
					Dynamic	=	{
						Size	=	0.45,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(4.5,36.400001525879,51.700000762939),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							0,
							55,
							255,
							},
					SpecLine	=	{
						Amount	=	6,
						Use	=	true,
						Pos	=	Vector(2.8499999046326,36.400001525879,51.700000762939),
							},
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.075,
							},
					Dynamic	=	{
						Size	=	0.45,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(2.6099998950958,36.400001525879,51.700000762939),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							0,
							55,
							255,
							},
					SpecLine	=	{
						Amount	=	6,
						Use	=	true,
						Pos	=	Vector(0.95999997854233,36.400001525879,51.700000762939),
							},
					UseSprite	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.075,
							},
					Dynamic	=	{
						Size	=	0.45,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-8.5500001907349,36.400001525879,51.700000762939),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					SpecLine	=	{
						Amount	=	6,
						Use	=	true,
						Pos	=	Vector(-6.9000000953674,36.400001525879,51.700000762939),
							},
					UseSprite	=	true,
					Beta_Inner3D	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.075,
							},
					Dynamic	=	{
						Size	=	0.45,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-6.5599999427795,36.400001525879,51.700000762939),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					SpecLine	=	{
						Amount	=	6,
						Use	=	true,
						Pos	=	Vector(-4.9099998474121,36.400001525879,51.700000762939),
							},
					UseSprite	=	true,
					Beta_Inner3D	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.075,
							},
					Dynamic	=	{
						Size	=	0.45,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-4.5,36.400001525879,51.700000762939),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					SpecLine	=	{
						Amount	=	6,
						Use	=	true,
						Pos	=	Vector(-2.8499999046326,36.400001525879,51.700000762939),
							},
					UseSprite	=	true,
					Beta_Inner3D	=	true,
						},
					{
					Sprite	=	{
						Size	=	0.075,
							},
					Dynamic	=	{
						Size	=	0.45,
						Brightness	=	2,
							},
					RenderHD_Adv	=	true,
					Pos	=	Vector(-2.6099998950958,36.400001525879,51.700000762939),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
							255,
							55,
							0,
							},
					SpecLine	=	{
						Amount	=	6,
						Use	=	true,
						Pos	=	Vector(-0.95999997854233,36.400001525879,51.700000762939),
							},
					UseSprite	=	true,
					Beta_Inner3D	=	true,
						},
					},
			Sounds_Horn	=	{
				Use	=	true,
				Volume	=	1,
				Distance	=	95,
				Pitch	=	100,
				Sound	=	"vcmod/els/cencom/bullhorn.wav",
					},
			Codes	=	{
				[8]	=	{
					SSeq_Ovr_SSeq	=	2,
					Spd_Stg_M	=	0.5,
					SSeq_Ovr	=	true,
					OvrC	=	7,
					Spd_Stg	=	true,
						},
				[13]	=	{
					Include	=	true,
						},
				[6]	=	{
					SSeq_Ovr_SSeq	=	2,
					OvrC	=	7,
					SSeq_Ovr	=	true,
						},
					},
			Sounds_Manual	=	{
				Use	=	true,
				Volume	=	1,
				Distance	=	95,
				Pitch	=	100,
				Sound	=	"vcmod/els/cencom/wail.wav",
					},
				},
		Date	=	"03/05/15 19:52:39",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-30.75,-107.73000335693,17.530000686646),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-25.780000686646,-109.76000213623,17.360000610352),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(30.75,-107.73000335693,17.530000686646),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(25.780000686646,-109.76000213623,17.360000610352),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(18.899900436401,-1,33.200000762939),
				RadioControl	=	true,
					},
				{
				Pos	=	Vector(-18.899900436401,-31.60000038147,33.200000762939),
				Ang	=	Angle(0,0,0),
				Switch_Rear	=	true,
				Cant_Exit_Lock	=	true,
				switch_rear	=	true,
					},
				{
				Pos	=	Vector(18.89999961853,-31.60000038147,33.200000762939),
				Ang	=	Angle(0,0,0),
				Switch_Rear	=	true,
				Cant_Exit_Lock	=	true,
				switch_rear	=	true,
					},
				},
		DLT	=	3491062916,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						55,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(-33.959999084473,-104.37999725342,45.159999847412),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				UseBrake	=	true,
				FogColor	=	{
						255,
						55,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(-23.110000610352,-108.69999694824,44.770000457764),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseFog	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				UseReverse	=	true,
				UseDynamic	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				SpecLine	=	{
					Amount	=	5,
					Pos	=	Vector(-23.159999847412,-113.48999786377,32.299999237061),
					Use	=	true,
						},
				Pos	=	Vector(-27.090000152588,-112.45999908447,32.180000305176),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-46,99.269996643066,30.639999389648),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				SpecLine	=	{
					Amount	=	5,
					Pos	=	Vector(-47.150001525879,94.279998779297,31.079999923706),
					Use	=	true,
						},
				RenderInner_Size	=	1.2,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseHead	=	true,
				UsePrjTex	=	true,
				Pos	=	Vector(-34.220001220703,101.44000244141,35.090000152588),
				UseDynamic	=	true,
				HeadColor	=	{
						222,
						199,
						255,
						},
				UseSprite	=	true,
				ProjTexture	=	{
					Forward	=	30,
					Size	=	2000,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-38.880001068115,104.5,17.430000305176),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				RenderInner_Size	=	1.2,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				FogColor	=	{
						220,
						225,
						255,
						},
				UsePrjTex	=	true,
				Pos	=	Vector(-38.619998931885,103.31999969482,23.110000610352),
				UseDynamic	=	true,
				UseFog	=	true,
				UseSprite	=	true,
				ProjTexture	=	{
					Size	=	2000,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				Pos	=	Vector(-25.75,106.61000061035,33.799999237061),
				UseSprite	=	true,
				RunningColor	=	{
						211.89,
						190.74,
						241.27,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				UseBrake	=	true,
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				BrakeColor	=	{
						255,
						55,
						0,
						},
				SpecLine	=	{
					Amount	=	24,
					Pos	=	Vector(9.5699996948242,-112.91000366211,52.279998779297),
					Use	=	true,
						},
				UseSprite	=	true,
				Pos	=	Vector(-9.5699996948242,-112.91000366211,52.279998779297),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						55,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(33.959999084473,-105.37999725342,45.159999847412),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				UseBrake	=	true,
				FogColor	=	{
						255,
						55,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(23.110000610352,-109.69999694824,44.770000457764),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseFog	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				UseReverse	=	true,
				UseDynamic	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				SpecLine	=	{
					Amount	=	5,
					Pos	=	Vector(23.159999847412,-113.48999786377,32.299999237061),
					Use	=	true,
						},
				Pos	=	Vector(27.090000152588,-112.45999908447,32.180000305176),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(46,99.269996643066,30.639999389648),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				SpecLine	=	{
					Amount	=	5,
					Pos	=	Vector(47.150001525879,94.279998779297,31.079999923706),
					Use	=	true,
						},
				RenderInner_Size	=	1.2,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseHead	=	true,
				UsePrjTex	=	true,
				Pos	=	Vector(34.220001220703,101.44000244141,35.090000152588),
				UseDynamic	=	true,
				HeadColor	=	{
						222,
						199,
						255,
						},
				UseSprite	=	true,
				ProjTexture	=	{
					Forward	=	30,
					Size	=	2000,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(38.880001068115,104.5,17.430000305176),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				RenderInner_Size	=	1.2,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				FogColor	=	{
						220,
						225,
						255,
						},
				UsePrjTex	=	true,
				Pos	=	Vector(38.619998931885,103.31999969482,23.110000610352),
				UseDynamic	=	true,
				UseFog	=	true,
				UseSprite	=	true,
				ProjTexture	=	{
					Size	=	2000,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				UseSprite	=	true,
				Pos	=	Vector(25.75,106.61000061035,33.799999237061),
				RunningColor	=	{
						211.89,
						190.74,
						241.27,
						},
				UseRunning	=	true,
					},
				},
		Copyright	=	"DurkaTeam @ 2025 No rights reserved",
		Author	=	"freemmaann",
}