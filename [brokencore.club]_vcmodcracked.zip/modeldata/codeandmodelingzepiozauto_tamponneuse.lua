VCModels['models/codeandmodelingzepiozauto_tamponneuse.mdl']	=	{
		em_state	=	5236594893,
		Date	=	"Mon Nov 26 21:44:40 2018",
		HealthNoEffects	=	true,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				Invulnerable	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Use	=	true,
					Pos2	=	Vector(-24.540000915527,32.349998474121,1.8300000429153),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Pos4	=	Vector(-22.540000915527,32.349998474121,-0.17000000178814),
					Pos1	=	Vector(-22.540000915527,32.349998474121,1.8300000429153),
					Pos3	=	Vector(-24.540000915527,32.349998474121,-0.17000000178814),
						},
				SpecMat	=	{
						},
				UsePrjTex	=	true,
				Pos	=	Vector(-23.540000915527,32.349998474121,0.8299999833107),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseRunning	=	true,
				UseSprite	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				Invulnerable	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Use	=	true,
					Pos2	=	Vector(24.540000915527,32.349998474121,1.8300000429153),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Pos4	=	Vector(22.540000915527,32.349998474121,-0.17000000178814),
					Pos1	=	Vector(22.540000915527,32.349998474121,1.8300000429153),
					Pos3	=	Vector(24.540000915527,32.349998474121,-0.17000000178814),
						},
				SpecMat	=	{
						},
				UsePrjTex	=	true,
				Pos	=	Vector(23.540000915527,32.349998474121,0.8299999833107),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseRunning	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				Invulnerable	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Use	=	true,
					Pos2	=	Vector(-17.75,37.759998321533,1.0499999523163),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Pos4	=	Vector(-15.75,37.759998321533,-0.94999998807907),
					Pos1	=	Vector(-15.75,37.759998321533,1.0499999523163),
					Pos3	=	Vector(-17.75,37.759998321533,-0.94999998807907),
						},
				SpecMat	=	{
						},
				RenderInner	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseSprite	=	true,
				Pos	=	Vector(-16.75,37.759998321533,0.050000000745058),
				UseDynamic	=	true,
				RenderInner_Size	=	2.9828,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				Invulnerable	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Use	=	true,
					Pos2	=	Vector(17.75,37.759998321533,1.0499999523163),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Pos4	=	Vector(15.75,37.759998321533,-0.94999998807907),
					Pos1	=	Vector(15.75,37.759998321533,1.0499999523163),
					Pos3	=	Vector(17.75,37.759998321533,-0.94999998807907),
						},
				SpecMat	=	{
						},
				RenderInner_Size	=	2.9828,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseSprite	=	true,
				Pos	=	Vector(16.75,37.759998321533,0.050000000745058),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				Invulnerable	=	true,
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(-18.360000610352,-28.870000839233,3.6800000667572),
				UseDynamic	=	true,
				RenderGlow_Size	=	0.6624,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				Invulnerable	=	true,
				SpecMat	=	{
						},
				UseSprite	=	true,
				Pos	=	Vector(18.360000610352,-28.870000839233,3.6800000667572),
				UseDynamic	=	true,
				RenderGlow_Size	=	0.6624,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				Invulnerable	=	true,
				UseBrake	=	true,
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-17.989999771118,-30.110000610352,4.0500001907349),
				UseDynamic	=	true,
				RenderInner_Size	=	4,
				RenderGlow_Size	=	0.6624,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
						},
				Invulnerable	=	true,
				UseBrake	=	true,
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(17.989999771118,-30.110000610352,4.0500001907349),
				UseDynamic	=	true,
				RenderInner_Size	=	4,
				RenderGlow_Size	=	0.6624,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	true,
					},
				},
		HealthDisabled	=	true,
		DLT	=	3491063262,
		Dmg_Wheel_Inv	=	true,
		Copyright	=	"Copyright © 2012-2018 VCMod (freemmaann). All Rights Reserved.",
		Fuel	=	{
			FuelType	=	0,
			Disabled	=	true,
				},
		Author	=	"Azok30 (76561198183398967)",
}