VCModels['models/azok30peugeot_bipper.mdl']	=	{
		em_state	=	5236594641,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Date	=	"Sun Nov 18 12:38:47 2018",
		Exhaust	=	{
				{
				Ang	=	Angle(15,-90,0),
				Pos	=	Vector(18.530000686646,-77.419998168945,1.6499999761581),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(0,0.10000000149012,0),
				Pos	=	Vector(19.819999694824,19.829999923706,28.950000762939),
				RadioControl	=	true,
					},
				},
		DLT	=	3491063094,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Pos	=	Vector(-29,84.269996643066,33.680000305176),
				UseRunning	=	true,
				SpecMat	=	{
						},
				RunningColor	=	{
					r	=	195,
					b	=	225,
					a	=	255,
					g	=	195,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Pos	=	Vector(29,84.269996643066,33.680000305176),
				UseRunning	=	true,
				SpecMat	=	{
						},
				RunningColor	=	{
					r	=	195,
					b	=	225,
					a	=	255,
					g	=	195,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				Pos	=	Vector(-32.689998626709,77.059997558594,37.869998931885),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				Pos	=	Vector(32.689998626709,77.059997558594,37.869998931885),
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				SpecSpin	=	{
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				HBeamColor	=	{
					r	=	195,
					b	=	225,
					a	=	255,
					g	=	195,
						},
				SpecMat	=	{
						},
				UseHighBeams	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-28.60000038147,83.970001220703,33.380001068115),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UsePrjTex	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				SpecSpin	=	{
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				HBeamColor	=	{
					r	=	195,
					b	=	225,
					a	=	255,
					g	=	195,
						},
				SpecMat	=	{
						},
				UseHighBeams	=	true,
				UseSprite	=	true,
				Pos	=	Vector(28.60000038147,83.970001220703,33.380001068115),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UsePrjTex	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				SpecMat	=	{
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseSprite	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	225,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Pos	=	Vector(-28.60000038147,83.970001220703,33.380001068115),
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	1.2,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				SpecMat	=	{
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseSprite	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	225,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Pos	=	Vector(28.60000038147,83.970001220703,33.380001068115),
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/sgmsquare_tex",
					Pos4	=	Vector(-29.639999389648,95.169998168945,18.190000534058),
					Pos2	=	Vector(-33.639999389648,95.169998168945,22.190000534058),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-29.639999389648,95.169998168945,22.190000534058),
					Pos3	=	Vector(-33.639999389648,95.169998168945,18.190000534058),
						},
				FogColor	=	{
					r	=	195,
					b	=	225,
					a	=	255,
					g	=	195,
						},
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-31.639999389648,95.169998168945,20.190000534058),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseFog	=	true,
				RenderInner_Size	=	4,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/sgmsquare_tex",
					Pos4	=	Vector(29.639999389648,95.169998168945,18.190000534058),
					Pos2	=	Vector(33.639999389648,95.169998168945,22.190000534058),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(29.639999389648,95.169998168945,22.190000534058),
					Pos3	=	Vector(33.639999389648,95.169998168945,18.190000534058),
						},
				FogColor	=	{
					r	=	195,
					b	=	225,
					a	=	255,
					g	=	195,
						},
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(31.639999389648,95.169998168945,20.190000534058),
				UseDynamic	=	true,
				RenderInner_Size	=	4,
				UseFog	=	true,
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				UseBlinkers	=	true,
				RenderInner_Size	=	0.0517,
				RenderHD_Adv	=	true,
				Pos	=	Vector(-35.729999542236,-77.379997253418,41.470001220703),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecCircle	=	{
					Amount	=	15,
					Use	=	true,
						},
				UseSprite	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				UseBlinkers	=	true,
				RenderInner_Size	=	0.0517,
				RenderHD_Adv	=	true,
				Pos	=	Vector(35.729999542236,-77.379997253418,41.470001220703),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecCircle	=	{
					Amount	=	15,
					Use	=	true,
						},
				UseSprite	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseBrake	=	true,
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-8.6400003433228,-77.180000305176,66.830001831055),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	21,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(2.2000000476837,-77.339996337891,66.949996948242),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				RenderInner	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecMat	=	{
						},
				RenderHD_Adv	=	true,
				RenderInner_Size	=	0.0517,
				UseSprite	=	true,
				Pos	=	Vector(-35.560001373291,-77.849998474121,33.299999237061),
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	15,
					Use	=	true,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				RenderInner	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecMat	=	{
						},
				RenderHD_Adv	=	true,
				RenderInner_Size	=	0.0517,
				UseSprite	=	true,
				Pos	=	Vector(35.560001373291,-77.849998474121,33.299999237061),
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	15,
					Use	=	true,
						},
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseSprite	=	true,
				UseBrake	=	true,
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderInner	=	true,
				RenderHD_Adv	=	true,
				Pos	=	Vector(-35.240001678467,-77.849998474121,45.619998931885),
				UseDynamic	=	true,
				RenderInner_Size	=	0.0517,
				SpecCircle	=	{
					Amount	=	15,
					Use	=	true,
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				RenderHD_Adv	=	true,
				UseBrake	=	true,
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderInner_Size	=	0.0517,
				UseSprite	=	true,
				Pos	=	Vector(35.240001678467,-77.849998474121,45.619998931885),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecCircle	=	{
					Amount	=	15,
					Use	=	true,
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseSprite	=	true,
				UseInter	=	true,
				InterColor	=	{
					r	=	225,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				SpecMat	=	{
						},
				RenderInner_Size	=	0.0517,
				RenderInner	=	true,
				RenderHD_Adv	=	true,
				Pos	=	Vector(0.30000001192093,20.14999961853,65.809997558594),
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	5,
					Use	=	true,
						},
				RenderType	=	2,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				RenderInner	=	true,
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderInner_Size	=	0.0517,
				UseSprite	=	true,
				Pos	=	Vector(-35.560001373291,-77.849998474121,36.75),
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	7,
					Use	=	true,
						},
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderHD_Adv	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseSprite	=	true,
				UseInter	=	true,
				InterColor	=	{
					r	=	225,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				SpecMat	=	{
						},
				RenderInner	=	true,
				RenderInner_Size	=	0.0517,
				RenderHD_Adv	=	true,
				Pos	=	Vector(-0.30000001192093,20.14999961853,65.809997558594),
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	5,
					Use	=	true,
						},
				RenderType	=	2,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				RenderInner_Size	=	0.0517,
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(35.560001373291,-77.849998474121,36.75),
				UseDynamic	=	true,
				SpecCircle	=	{
					Amount	=	7,
					Use	=	true,
						},
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderHD_Adv	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				},
		Copyright	=	"Copyright © 2012-2018 VCMod (freemmaann). All Rights Reserved.",
		Fuel	=	{
			FuelType	=	0,
				},
		Author	=	"Azok30 (76561198183398967)",
}