VCModels['models/azok30renault_scenic_3.mdl']	=	{
		em_state	=	5236594710,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Copyright	=	"Copyright © 2012-2019 VCMod (freemmaann). All Rights Reserved.",
		Exhaust	=	{
				{
				EffectStress	=	"VC_Exhaust_Stress",
				Invulnerable	=	true,
				EffectIdle	=	"VC_Exhaust",
				Ang	=	Angle(15,-90,0),
				Pos	=	Vector(22.620000839233,-87.790000915527,0.079999998211861),
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(16.469999313354,11.670000076294,24.079999923706),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(-19.85000038147,-29.540000915527,24.079999923706),
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(19.85000038147,-29.540000915527,24.079999923706),
					},
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(-0.20999999344349,-29.540000915527,24.079999923706),
					},
				},
		DLT	=	3491063140,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Pos	=	Vector(-25.069999694824,86.580001831055,25.409999847412),
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				UseRunning	=	true,
				Pos	=	Vector(25.069999694824,86.580001831055,25.409999847412),
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(-28.079999923706,86.930000305176,22.569999694824),
					Pos2	=	Vector(-33.759998321533,86.930000305176,28.25),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-28.079999923706,86.930000305176,28.25),
					Pos3	=	Vector(-33.759998321533,86.930000305176,22.569999694824),
						},
				HBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UsePrjTex	=	true,
				Pos	=	Vector(-30.920000076294,86.930000305176,25.409999847412),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				UseSprite	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(28.079999923706,86.930000305176,22.569999694824),
					Pos2	=	Vector(33.759998321533,86.930000305176,28.25),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(28.079999923706,86.930000305176,28.25),
					Pos3	=	Vector(33.759998321533,86.930000305176,22.569999694824),
						},
				HBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UsePrjTex	=	true,
				Pos	=	Vector(30.920000076294,86.930000305176,25.409999847412),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				UseSprite	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(-32.419998168945,89.779998779297,7.5999999046326),
					Pos2	=	Vector(-36.180000305176,89.779998779297,11.359999656677),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-32.419998168945,89.779998779297,11.359999656677),
					Pos3	=	Vector(-36.180000305176,89.779998779297,7.5999999046326),
						},
				FogColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseSprite	=	true,
				Pos	=	Vector(-34.299999237061,89.779998779297,9.4799995422363),
				UseDynamic	=	true,
				UseFog	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(32.419998168945,89.779998779297,7.5999999046326),
					Pos2	=	Vector(36.180000305176,89.779998779297,11.359999656677),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(32.419998168945,89.779998779297,11.359999656677),
					Pos3	=	Vector(36.180000305176,89.779998779297,7.5999999046326),
						},
				FogColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseSprite	=	true,
				Pos	=	Vector(34.299999237061,89.779998779297,9.4799995422363),
				UseDynamic	=	true,
				UseFog	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-27.069999694824,87.809997558594,29.090000152588),
				UseDynamic	=	true,
				RenderInner_Size	=	2.7069,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-30.020000457764,81.540000915527,31.629999160767),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-34.799999237061,75.970001220703,32.409999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-32.409999847412,82.370002746582,30.139999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-27.489999771118,88,29.389999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				UseSprite	=	true,
				Pos	=	Vector(27.069999694824,87.809997558594,29.090000152588),
				UseDynamic	=	true,
				RenderInner_Size	=	2.7069,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(30.020000457764,81.540000915527,31.629999160767),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(34.799999237061,75.970001220703,32.409999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(32.409999847412,82.370002746582,30.139999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(27.489999771118,88,29.389999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-33.520000457764,-76.470001220703,35.400001525879),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	13,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-21.040000915527,-83.800003051758,34.630001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(32.639999389648,-78.540000915527,36.049999237061),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	45,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(27.450000762939,-73.73999786377,50.919998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-32.639999389648,-78.540000915527,36.049999237061),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	45,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-27.450000762939,-73.73999786377,50.919998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-6.4499998092651,-72.839996337891,59.110000610352),
				UseDynamic	=	true,
				RenderInner_Size	=	1.5345,
				SpecMLine	=	{
					Amount	=	13,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(6.4200000762939,-72.48999786377,59.159999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(33.520000457764,-76.470001220703,35.400001525879),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	13,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(21.040000915527,-83.800003051758,34.630001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				UseBrake	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(6.4499998092651,-72.839996337891,59.110000610352),
				UseDynamic	=	true,
				RenderInner_Size	=	1.5345,
				SpecMLine	=	{
					Amount	=	13,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-6.4200000762939,-72.48999786377,59.159999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.02,
						},
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
				UseReverse	=	true,
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner_Clr	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseSprite	=	true,
				Pos	=	Vector(-25.670000076294,-82.790000915527,35.069999694824),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	97,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-21.739999771118,-83.569999694824,34.599998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Size	=	4,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.02,
						},
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
				UseReverse	=	true,
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(25.670000076294,-82.790000915527,35.069999694824),
				UseDynamic	=	true,
				RenderInner_Size	=	4,
				SpecMLine	=	{
					Amount	=	97,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(21.739999771118,-83.569999694824,34.599998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				RenderInner_Clr	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-31.920000076294,-78.76000213623,35.150001525879),
				UseDynamic	=	true,
				RenderInner_Size	=	2.1207,
				SpecMLine	=	{
					Amount	=	97,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-27.989999771118,-79.540000915527,34.680000305176),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(31.920000076294,-78.76000213623,35.150001525879),
				UseDynamic	=	true,
				RenderInner_Size	=	2.1207,
				SpecMLine	=	{
					Amount	=	97,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(27.989999771118,-79.540000915527,34.680000305176),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseBlinkers	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-47.209999084473,30.129999160767,39.119998931885),
				UseDynamic	=	true,
				RenderInner_Size	=	2.1207,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(47.209999084473,30.129999160767,39.119998931885),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				RenderInner_Size	=	2.1207,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
						},
				RenderInner_ClrUse	=	true,
					},
				},
		Date	=	"Tue Feb 12 23:29:41 2019",
		Fuel	=	{
			FuelType	=	0,
				},
		Author	=	"Azok30 (76561198183398967)",
}