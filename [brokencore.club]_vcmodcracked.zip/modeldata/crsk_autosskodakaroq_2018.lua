VCModels['models/crsk_autosskodakaroq_2018.mdl']	=	{
		em_state	=	5236594959,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Date	=	"Thu Jul 19 00:24:41 2018",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(-29.530000686646,-112.98000335693,15.14999961853),
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(27.670000076294,-112.98000335693,15.14999961853),
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Pos	=	Vector(17.459999084473,-6.3000001907349,35.919998168945),
				Ang	=	Angle(12,0,0),
				EnterAnim	=	"enter2",
				RadioControl	=	true,
				ExitAnim	=	"exit2",
					},
				{
				Ang	=	Angle(12,0,0),
				Pos	=	Vector(-17.459999084473,-44.490001678467,36.25),
				EnterAnim	=	"enter4",
				ExitAnim	=	"exit4",
					},
				{
				Ang	=	Angle(12,0,0),
				Pos	=	Vector(17.459999084473,-44.490001678467,36.25),
				ExitAnim	=	"exit4",
				EnterAnim	=	"enter4",
					},
				{
				Ang	=	Angle(12,0,0),
				Pos	=	Vector(0,-44.490001678467,36.25),
				EnterAnim	=	"enter4",
				ExitAnim	=	"exit4",
					},
				},
		DLT	=	3491063306,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.05,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				DD_Blnk_Run	=	true,
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-23.159999847412,86.51000213623,35.759998321533),
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	76,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-25.190000534058,85.470001220703,35.919998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-28.319999694824,83.559997558594,36.240001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-31.579999923706,81.069999694824,36.529998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-35.290000915527,77.519996643066,36.790000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-38.490001678467,73.620002746582,37.060001373291),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseBlinkers	=	true,
				RunningColor	=	{
					r	=	195,
					b	=	225,
					a	=	255,
					g	=	195,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.05,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				DD_Blnk_Run	=	true,
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.5,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(23.579999923706,86.51000213623,35.590000152588),
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	76,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(25.610000610352,85.470001220703,35.75),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(28.739999771118,83.559997558594,36.069999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(32,81.069999694824,36.360000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(35.709999084473,77.519996643066,36.619998931885),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(39,73.339996337891,36.889999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseSprite	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.07,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-32.049999237061,-112.56999969482,40.450000762939),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	124,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-33.939998626709,-111.12000274658,40.950000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-36.069999694824,-109.48000335693,41.639999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-37.599998474121,-107.01000213623,41.830001831055),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-39.180000305176,-103.98999786377,42.240001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-38.319999694824,-107.69000244141,46.599998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-35.180000305176,-109.88999938965,46.419998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-32.049999237061,-112.25,46.319999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.08,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(32.049999237061,-112.56999969482,40.450000762939),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	124,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(33.939998626709,-111.12000274658,40.950000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(36.069999694824,-109.48000335693,41.639999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(37.599998474121,-107.01000213623,41.830001831055),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(39.180000305176,-103.98999786377,42.240001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(38.319999694824,-107.69000244141,46.599998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(35.180000305176,-109.88999938965,46.419998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(32.049999237061,-112.25,46.319999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.08,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(31.059999465942,-112.94000244141,46.310001373291),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	47,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(27.629999160767,-114.23000335693,46.090000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(23.139999389648,-115.41999816895,46.020000457764),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.06,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-31.299999237061,-112.91999816895,46.349998474121),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	47,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-27.870000839233,-114.20999908447,46.130001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-23.379999160767,-115.40000152588,46.060001373291),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.04,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
					r	=	195,
					b	=	225,
					a	=	255,
					g	=	195,
						},
				UseRunning	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-24.280000686646,84.980003356934,36.220001220703),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	9,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-24.930000305176,82.76000213623,36.380001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	195,
								b	=	225,
								a	=	255,
								g	=	195,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.04,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseRunning	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-26.120000839233,83.870002746582,36.220001220703),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	9,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-26.790000915527,81.48999786377,36.5),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.04,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseSprite	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseRunning	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-27.930000305176,82.559997558594,36.450000762939),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	9,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-28.680000305176,79.75,36.729999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.04,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseSprite	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseRunning	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-29.909999847412,80.919998168945,36.540000915527),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	18,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-30.590000152588,78.110000610352,36.819999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-31.079999923706,74.779998779297,37.240001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.04,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseSprite	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseRunning	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-31.870000839233,79.199996948242,36.759998321533),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	18,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-32.360000610352,76.389999389648,37.040000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-32.900001525879,73.059997558594,37.459999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.04,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseSprite	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseRunning	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-34.020000457764,77.220001220703,37.009998321533),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	9,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-34.770000457764,74.410003662109,37.290000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.04,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseSprite	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseRunning	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-35.759998321533,75.150001525879,36.930000305176),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	9,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-36.409999847412,72.839996337891,37.209999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.04,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseRunning	=	true,
				SpecMat	=	{
					Select	=	10,
					New	=	"models\crskautos\skoda\karoq_2018\karoq_int_a_illum_on",
					Use	=	true,
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-37.909999847412,73.059997558594,37.270000457764),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	4,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-38.099998474121,71.980003356934,37.549999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.04,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseSprite	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseRunning	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-36.180000305176,78.120002746582,30.700000762939),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	9,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-36.470001220703,75.309997558594,30.719999313354),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.04,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseSprite	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseRunning	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-37.200000762939,77.400001525879,30.700000762939),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	9,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-37.490001678467,74.589996337891,30.790000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.04,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseSprite	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseRunning	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-38.25,76.209999084473,30.770000457764),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	9,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-38.540000915527,73.980003356934,30.860000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.04,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseSprite	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseRunning	=	true,
				SpecMat	=	{
					Select	=	27,
					New	=	"models\crskautos\skoda\karoq_2018\karoq_int_c_illum_on",
					Use	=	true,
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(24.60000038147,84.980003356934,36.220001220703),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	9,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(25.25,82.76000213623,36.380001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.04,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseRunning	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(26.39999961853,83.870002746582,36.220001220703),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	9,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(27.069999694824,81.48999786377,36.5),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.04,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseRunning	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(28.329999923706,82.559997558594,36.450000762939),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	9,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(29.079999923706,79.75,36.729999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.04,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseRunning	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(30.319999694824,80.919998168945,36.540000915527),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	18,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(31,78.110000610352,36.819999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(31.489999771118,74.779998779297,37.240001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.04,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseRunning	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(32.220001220703,79.199996948242,36.759998321533),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	18,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(32.709999084473,76.389999389648,37.040000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(33.25,73.059997558594,37.459999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.04,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseRunning	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(34.240001678467,77.220001220703,37.009998321533),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	9,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(34.990001678467,74.410003662109,37.290000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.04,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseRunning	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(36.180000305176,75.150001525879,36.930000305176),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	9,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(36.830001831055,72.839996337891,37.209999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.04,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseRunning	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(38.299999237061,73.059997558594,37.270000457764),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	4,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(38.490001678467,71.980003356934,37.549999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.04,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseRunning	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(36.450000762939,78.120002746582,30.700000762939),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	9,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(36.740001678467,75.309997558594,30.719999313354),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.04,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseRunning	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(37.560001373291,77.400001525879,30.700000762939),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	9,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(37.849998474121,74.589996337891,30.790000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.04,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseSprite	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseRunning	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(38.569999694824,76.209999084473,30.770000457764),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	9,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(38.860000610352,73.980003356934,30.860000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.3,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-35.150001525879,70.51000213623,39.319999694824),
				RenderInner	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				SpecMat	=	{
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.3,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(35.409999847412,70.51000213623,39.200000762939),
				RenderInner	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				SpecMat	=	{
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.3,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Dynamic	=	{
					Size	=	1.5,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-28.809999465942,74.129997253418,38.740001678467),
				UseDynamic	=	true,
				RenderInner	=	true,
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.2,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				RenderInner	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UsePrjTex	=	true,
				Pos	=	Vector(-25.530000686646,77.180000305176,38.740001678467),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				UseSprite	=	true,
				Dynamic	=	{
					Size	=	1.5,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.2,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				RenderInner	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UsePrjTex	=	true,
				Pos	=	Vector(25.659999847412,77.180000305176,38.740001678467),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				UseSprite	=	true,
				Dynamic	=	{
					Size	=	1.5,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.3,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Dynamic	=	{
					Size	=	1.5,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(28.809999465942,74.129997253418,38.740001678467),
				UseDynamic	=	true,
				RenderInner	=	true,
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseHighBeams	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.3,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				FogColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-37.060001373291,75.099998474121,32.75),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseFog	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.3,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				FogColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(37.259998321533,75.099998474121,32.75),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseFog	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.08,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseBrake	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(38.340000152588,-107.2200012207,47.680000305176),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	47,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(35.830001831055,-109.38999938965,47.599998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(32.189998626709,-111.69000244141,47.560001373291),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.3,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(31.659999847412,-111.66000366211,45.080001831055),
					Pos2	=	Vector(35,-109.88999938965,41.909999847412),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(34.849998474121,-109.37999725342,45.189998626709),
					Pos3	=	Vector(30.719999313354,-113.55000305176,40.590000152588),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(33.259998321533,-110.87999725342,43.330001831055),
				UseDynamic	=	true,
				RenderInner	=	true,
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.08,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseBrake	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-38.340000152588,-107.2200012207,47.930000305176),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	47,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-35.830001831055,-109.38999938965,47.849998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-32.189998626709,-111.69000244141,47.810001373291),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.3,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-36.889999389648,-107.75,44.080001831055),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-34.889999389648,-109.83000183105,45.25),
					Pos2	=	Vector(-38.360000610352,-105.76999664307,42.889999389648),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-37.380001068115,-106.48000335693,44.990001678467),
					Pos3	=	Vector(-35.319999694824,-110.08000183105,42.330001831055),
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.03,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(46.040000915527,20.020000457764,52.279998779297),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	47,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(49.090000152588,17.60000038147,52.720001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(50.169998168945,15.25,53.020000457764),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.03,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-45.419998168945,20.340000152588,52.560001373291),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	47,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-48.470001220703,17.920000076294,53),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-49.549999237061,15.569999694824,53.299999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.3,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(36.580001831055,-107.93000030518,43.959999084473),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(34.470001220703,-109.86000061035,45.090000152588),
					Pos2	=	Vector(38.049999237061,-105.94999694824,42.770000457764),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(37.069999694824,-106.66000366211,44.869998931885),
					Pos3	=	Vector(34.759998321533,-110.25,42.229999542236),
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.3,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseReverse	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-32.150001525879,-111.44000244141,45.180000305176),
					Pos2	=	Vector(-35.490001678467,-109.66999816895,42.009998321533),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-35.340000152588,-109.16000366211,45.290000915527),
					Pos3	=	Vector(-31.209999084473,-113.33000183105,40.689998626709),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-33.770000457764,-111.01999664307,43.569999694824),
				UseDynamic	=	true,
				RenderInner	=	true,
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	1,
					Size	=	0.08,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseBrake	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-7.5100002288818,-98.98999786377,69.919998168945),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	47,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-0.070000000298023,-99.110000610352,70.029998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(6.6500000953674,-98.709999084473,69.849998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				},
		Copyright	=	"Copyright © 2012-2018 VCMod (freemmaann). All Rights Reserved.",
		Fuel	=	{
			FuelLidPos	=	Vector(43.099998474121,-85.099998474121,43.529998779297),
			Override	=	true,
			FuelType	=	0,
			Capacity	=	55,
			FuelTypeUse	=	true,
			FuelLidUse	=	true,
				},
		Author	=	"CrushingSkirmish (76561198017348899)",
}