VCModels['models/crsk_autosw_motorsfenyr_supersport.mdl']	=	{
		em_state	=	5236595007,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Copyright	=	"Copyright © 2012-2018 VCMod (freemmaann). All Rights Reserved.",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-19.200000762939,-97.540000915527,13.279999732971),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(19.200000762939,-97.540000915527,13.279999732971),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(16.89999961853,12.159999847412,21.25),
				RadioControl	=	true,
					},
				},
		DLT	=	3491063338,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.12,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(38.909999847412,89.23999786377,29.799999237061),
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(38.680000305176,90.339996337891,28.159999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(38.409999847412,91.669998168945,25.989999771118),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(38.189998626709,92.709999084473,24.190000534058),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.939998626709,93.650001525879,22.459999084473),
								},
							{
							Pos	=	Vector(37.450000762939,95,19.770000457764),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
					r	=	155,
					b	=	185,
					a	=	255,
					g	=	155,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(39.490001678467,85.730003356934,30.64999961853),
					Pos2	=	Vector(35.029998779297,85.730003356934,35.110000610352),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(39.490001678467,85.730003356934,35.110000610352),
					Pos3	=	Vector(35.029998779297,85.730003356934,30.64999961853),
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(37.259998321533,85.73999786377,32.880001068115),
				RenderMLCenter	=	true,
				Beta_Inner3D	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				SpecMat	=	{
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				DD_Blnk_Run	=	true,
				UseDynamic	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(24.319999694824,100.7200012207,29.549999237061),
				UseBlinkers	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(29.629999160767,95.370002746582,31.5),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.819999694824,92.98999786377,32.279998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.310001373291,91.370002746582,32.770000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.729999542236,89.889999389648,32.950000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.729999542236,85.430000305176,33.330001831055),
								},
							},
						},
				RenderMLCenter	=	true,
				RunningColor	=	{
						155,
						155,
						185,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				DD_Blnk_Run	=	true,
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	125,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	125,
					b	=	0,
					a	=	255,
					g	=	100,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				UseSprite	=	true,
				Pos	=	Vector(16.610000610352,-105.20999908447,38.930000305176),
				RenderInner	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	94,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(24.020000457764,-101.68000030518,38.310001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(30.379999160767,-98.279998779297,38.069999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.810001373291,-95.529998779297,38.090000152588),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(40.389999389648,-93.050003051758,38.139999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(40.430000305176,-93.550003051758,37.450000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.810001373291,-95.330001831055,37.290000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(33.069999694824,-97.389999389648,37.169998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(28.790000915527,-99.419998168945,37.360000610352),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(17.170000076294,-105.37000274658,38.540000915527),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(17.540000915527,-104.95999908447,37.950000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(25.950000762939,-101.12000274658,36.909999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(31.75,-98.23999786377,36.240001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.360000610352,-96.800003051758,36.479999542236),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(39.020000457764,-94.919998168945,37.180000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(37.529998779297,-96.389999389648,36.310001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.159999847412,-97.449996948242,35.659999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.720001220703,-97.540000915527,35.770000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.139999389648,-98.410003662109,35.400001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.479999542236,-98.199996948242,33.900001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(35.470001220703,-97.900001525879,32.200000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.159999847412,-98.150001525879,35.279998779297),
								},
							{
							Pos	=	Vector(33.450000762939,-97.419998168945,35.840000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseBrake	=	true,
				RunningColor	=	{
					r	=	125,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseBrake	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(1.5,-55.380001068115,53.669998168945),
					Pos2	=	Vector(-1.4700000286102,-50.310001373291,54.959999084473),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(1.539999961853,-50.380001068115,54.959999084473),
					Pos3	=	Vector(-1.4299999475479,-55.400001525879,53.659999847412),
						},
				Beta_Inner3D	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(0,-53.669998168945,54.369998931885),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				DD_Blnk_Run	=	true,
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-23.809999465942,100.66999816895,29.700000762939),
				RenderMLCenter	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-29.120000839233,95.319999694824,31.64999961853),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.309999465942,92.940002441406,32.430000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-32.799999237061,91.319999694824,32.919998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.220001220703,89.839996337891,33.099998474121),
								},
							{
							Pos	=	Vector(-34.220001220703,85.379997253418,33.479999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Beta_Inner3D	=	true,
				RunningColor	=	{
					r	=	155,
					b	=	185,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.12,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderBeam	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-38.319999694824,89.349998474121,30.030000686646),
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-38.090000152588,90.449996948242,28.389999389648),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.819999694824,91.779998779297,26.219999313354),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.599998474121,92.819999694824,24.420000076294),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.349998474121,93.76000213623,22.690000534058),
								},
							{
							Pos	=	Vector(-36.860000610352,95.110000610352,20),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderMLCenter	=	true,
				RunningColor	=	{
					r	=	155,
					b	=	185,
					a	=	255,
					g	=	155,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-38.860000610352,85.889999389648,30.860000610352),
					Pos2	=	Vector(-34.400001525879,85.889999389648,35.319999694824),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-38.860000610352,85.889999389648,35.319999694824),
					Pos3	=	Vector(-34.400001525879,85.889999389648,30.860000610352),
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-36.630001068115,85.900001525879,33.090000152588),
				RenderMLCenter	=	true,
				Beta_Inner3D	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				SpecMat	=	{
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				DD_Blnk_Run	=	true,
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	125,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	true,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	125,
					b	=	0,
					a	=	255,
					g	=	100,
						},
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-16.790000915527,-104.94999694824,39.189998626709),
				UseSprite	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	94,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-24.200000762939,-101.41999816895,38.569999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-30.559999465942,-98.019996643066,38.330001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.990001678467,-95.269996643066,38.349998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-40.569999694824,-92.790000915527,38.400001525879),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-40.610000610352,-93.290000915527,37.709999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.990001678467,-95.069999694824,37.549999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-33.25,-97.129997253418,37.430000305176),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-28.969999313354,-99.160003662109,37.619998931885),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-17.35000038147,-105.11000061035,38.799999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-17.719999313354,-104.69999694824,38.209999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-26.129999160767,-100.86000061035,37.169998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-31.930000305176,-97.980003356934,36.5),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.540000915527,-96.540000915527,36.740001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-39.200000762939,-94.660003662109,37.439998626709),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-37.709999084473,-96.129997253418,36.569999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.340000152588,-97.190002441406,35.919998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.900001525879,-97.279998779297,36.029998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.319999694824,-98.150001525879,35.659999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.659999847412,-97.940002441406,34.159999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-35.650001525879,-97.639999389648,32.459999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-34.340000152588,-97.889999389648,35.540000915527),
								},
							{
							Pos	=	Vector(-33.630001068115,-97.160003662109,36.099998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Size	=	1,
				RunningColor	=	{
					r	=	125,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				SpecRec	=	{
					AmountV	=	6,
					Pos4	=	Vector(1.3400000333786,-103.65000152588,13.760000228882),
					Mid_Full	=	true,
					Pos2	=	Vector(-1.7200000286102,-103.65000152588,18.299999237061),
					AmountH	=	5,
					Use	=	true,
					Pos1	=	Vector(1.4400000572205,-103.69000244141,18.299999237061),
					Pos3	=	Vector(-1.7400000095367,-103.63999938965,13.819999694824),
						},
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(0,-103.65000152588,16.10000038147),
				RenderInner	=	true,
				UseBrake	=	true,
				RenderInner_Size	=	1,
				UseSprite	=	true,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				DD_Blnk_Run	=	true,
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	125,
					b	=	0,
					a	=	255,
					g	=	100,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-42.099998474121,27.239999771118,46.220001220703),
				RenderMLCenter	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-44.75,25.489999771118,46.25),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-46.599998474121,24.10000038147,46.270000457764),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-48.270000457764,22.760000228882,46.240001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-49.680000305176,21.620000839233,46.200000762939),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-50.520000457764,20.709999084473,46.159999847412),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-50.810001373291,19.370000839233,46.150001525879),
								},
							{
							Pos	=	Vector(-50.680000305176,18,46.130001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseSprite	=	true,
				UseBlinkers	=	true,
				RenderInner	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				DD_Blnk_Run	=	true,
				UseDynamic	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	125,
					b	=	0,
					a	=	255,
					g	=	100,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(42.439998626709,27.020000457764,46.049999237061),
				UseBlinkers	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(45.090000152588,25.270000457764,46.080001831055),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(46.939998626709,23.879999160767,46.099998474121),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(48.610000610352,22.540000915527,46.069999694824),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(50.020000457764,21.39999961853,46.029998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(50.860000610352,20.489999771118,45.990001678467),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(51.150001525879,19.14999961853,45.979999542236),
								},
							{
							Pos	=	Vector(51.020000457764,17.780000686646,45.959999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseSprite	=	true,
				RenderMLCenter	=	true,
				RenderInner	=	true,
					},
				},
		Date	=	"Wed Jan 17 21:06:19 2018",
		Fuel	=	{
			FuelType	=	0,
			FuelLidPos	=	Vector(0,0,0),
				},
		Author	=	"𝓒𝓣𝓥𝟏𝟐𝟐𝟓 (76561198051637331)",
}