VCModels['models/cmbfdrvehiclesraf_2203_police.mdl']	=	{
		em_state	=	5236594404,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Siren	=	{
			Sounds	=	{
					{
					Pitch	=	100,
					Volume	=	1,
					Distance	=	95,
					Name	=	"Wail",
					Sound	=	"vcmod/els/smartsiren/wail.wav",
						},
					{
					Pitch	=	100,
					Volume	=	1,
					Distance	=	95,
					Name	=	"Yelp",
					Sound	=	"vcmod/els/smartsiren/yelp.wav",
						},
					{
					Pitch	=	100,
					Volume	=	1,
					Distance	=	95,
					Name	=	"Priority",
					Sound	=	"vcmod/els/smartsiren/priority.wav",
						},
					},
			Lights	=	{
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	2,
							},
					SpecSpin	=	{
						Double	=	true,
						Use	=	true,
						Speed	=	295,
							},
					Spec3D	=	{
						Mat	=	"vcmod/circle",
						Pos4	=	Vector(-10.819999694824,40.240001678467,207.96000671387),
						Pos2	=	Vector(-10.819999694824,40.240001678467,207.96000671387),
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
						Use	=	true,
						Pos1	=	Vector(-10.819999694824,40.240001678467,207.96000671387),
						Pos3	=	Vector(-10.819999694824,40.240001678467,207.96000671387),
							},
					Dynamic	=	{
						Size	=	1,
						Brightness	=	2,
							},
					SpecModel	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
					BGroups	=	{
							{
							[0]	=	"police_sign",
								},
							},
					UseSprite	=	true,
					Pos	=	Vector(-5.4099998474121,20.120000839233,103.98000335693),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
						r	=	0,
						b	=	255,
						a	=	255,
						g	=	55,
							},
					RenderHD_Adv	=	true,
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner_ClrUse	=	false,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	2,
							},
					SpecSpin	=	{
						Speed	=	295,
						Use	=	true,
							},
					Spec3D	=	{
						Mat	=	"vcmod/circle",
						Pos4	=	Vector(-10.890000343323,40.369998931885,212.49000549316),
						Pos2	=	Vector(-10.890000343323,40.369998931885,212.49000549316),
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
						Use	=	true,
						Pos1	=	Vector(-10.890000343323,40.369998931885,212.49000549316),
						Pos3	=	Vector(-10.890000343323,40.369998931885,212.49000549316),
							},
					Dynamic	=	{
						Size	=	1,
						Brightness	=	2,
							},
					SpecModel	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
					BGroups	=	{
							{
								"police_sign2",
								},
							},
					UseSprite	=	true,
					Pos	=	Vector(-5.4800000190735,20.25,108.51000213623),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
						r	=	0,
						b	=	255,
						a	=	255,
						g	=	55,
							},
					RenderHD_Adv	=	true,
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner_ClrUse	=	false,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	2,
							},
					SpecSpin	=	{
						Double	=	true,
						Use	=	true,
						Speed	=	295,
							},
					Spec3D	=	{
						Mat	=	"vcmod/circle",
						Pos4	=	Vector(11.630000114441,41.590000152588,205.25),
						Pos2	=	Vector(11.630000114441,41.590000152588,205.25),
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
						Use	=	true,
						Pos1	=	Vector(11.630000114441,41.590000152588,205.25),
						Pos3	=	Vector(11.630000114441,41.590000152588,205.25),
							},
					Dynamic	=	{
						Size	=	1,
						Brightness	=	2,
							},
					SpecModel	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
					BGroups	=	{
							{
								"police_sign2",
								},
							},
					UseSprite	=	true,
					Pos	=	Vector(17.040000915527,21.469999313354,101.26999664307),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
						r	=	0,
						b	=	255,
						a	=	255,
						g	=	55,
							},
					RenderHD_Adv	=	true,
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner_ClrUse	=	false,
						},
					{
					Sprite	=	{
						GlowPrxSize	=	2,
						Size	=	2,
							},
					SpecSpin	=	{
						Double	=	true,
						Use	=	true,
						Reversed	=	true,
						Speed	=	295,
							},
					Spec3D	=	{
						Mat	=	"vcmod/circle",
						Pos4	=	Vector(-33.270000457764,41.330001831055,204.75999450684),
						Pos2	=	Vector(-33.270000457764,41.330001831055,204.75999450684),
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
						Use	=	true,
						Pos1	=	Vector(-33.270000457764,41.330001831055,204.75999450684),
						Pos3	=	Vector(-33.270000457764,41.330001831055,204.75999450684),
							},
					Dynamic	=	{
						Size	=	1,
						Brightness	=	2,
							},
					SpecModel	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
					BGroups	=	{
							{
								"police_sign2",
								},
							},
					UseSprite	=	true,
					Pos	=	Vector(-27.860000610352,21.209999084473,100.7799987793),
					UseDynamic	=	true,
					RenderInner	=	true,
					Color	=	{
						r	=	0,
						b	=	255,
						a	=	255,
						g	=	55,
							},
					RenderHD_Adv	=	true,
					RenderInner_Clr	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					RenderInner_ClrUse	=	false,
						},
					},
			Sounds_Horn	=	{
				Use	=	true,
				Volume	=	1,
				Distance	=	95,
				Pitch	=	100,
				Sound	=	"vcmod/els/smartsiren/horn.wav",
					},
			Sequences	=	{
					{
					SubSeq	=	{
							{
							Stages	=	{
									{
									[1]	=	{
										Lights	=	{
												},
										Time	=	0.1,
											},
									Lights	=	{
											1,
											2,
											3,
											4,
											},
									Time	=	0.1,
										},
									},
							Time	=	2,
							Type	=	"Custom",
								},
							},
					Codes	=	{
							true,
							},
					Lights_Sel	=	{
							true,
							true,
							true,
							true,
							},
						},
					},
			Sounds_Manual	=	{
				Use	=	true,
				Volume	=	1,
				Distance	=	95,
				Pitch	=	100,
				Sound	=	"vcmod/els/smartsiren/manual.wav",
					},
				},
		Date	=	"Sat Jun  1 11:41:05 2019",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(7.1599998474121,-129.9700012207,18.209999084473),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		Copyright	=	"Copyright © 2012-2019 VCMod (freemmaann). All Rights Reserved.",
		ExtraSeats	=	{
				{
				Ang	=	Angle(14.10000038147,0,0),
				Pos	=	Vector(22.190000534058,45.889999389648,49.619998931885),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(-3.9000000953674,1.1000000238419,0),
				Pos	=	Vector(-38.810001373291,1.7300000190735,46.279998779297),
					},
				{
				Ang	=	Angle(10.60000038147,0,0),
				Pos	=	Vector(24.090000152588,-36.959999084473,46.380001068115),
					},
				{
				Ang	=	Angle(10.60000038147,0,0),
				Pos	=	Vector(24.639999389648,-79.480003356934,47.200000762939),
					},
				{
				Ang	=	Angle(10.60000038147,0,0),
				Pos	=	Vector(4.3499999046326,-79.480003356934,47.200000762939),
					},
				{
				Ang	=	Angle(10.60000038147,0,0),
				Pos	=	Vector(-16.459999084473,-79.480003356934,47.200000762939),
					},
				{
				Ang	=	Angle(10.60000038147,0,0),
				Pos	=	Vector(-38.509998321533,-79.480003356934,47.200000762939),
					},
				{
				Ang	=	Angle(-3.9000000953674,1.1000000238419,0),
				Pos	=	Vector(-38.810001373291,-41.590000152588,46.279998779297),
					},
				{
				Ang	=	Angle(-3.9000000953674,1.1000000238419,0),
				Pos	=	Vector(-17,-41.590000152588,46.279998779297),
					},
				{
				Ang	=	Angle(-3.9000000953674,1.1000000238419,0),
				Pos	=	Vector(-17.299999237061,1.7300000190735,46.279998779297),
					},
				{
				Ang	=	Angle(-3.9000000953674,1.1000000238419,0),
				Pos	=	Vector(4.7199997901917,1.7300000190735,46.279998779297),
					},
				},
		HealthEnginePos	=	Vector(-5.8200001716614,75.160003662109,45.900001525879),
		DLT	=	3491062936,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseLowBeams	=	true,
				HBeamColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseSprite	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderHD_Size	=	5,
				Pos	=	Vector(-39.169998168945,90.769996643066,40.119998931885),
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				RenderHD_Adv	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				UseSprite	=	true,
				Pos	=	Vector(-47.659999847412,90.459999084473,25.670000076294),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderHD_Size	=	5,
				RenderHD_Adv	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				UseSprite	=	true,
				Pos	=	Vector(-48.700000762939,19.379999160767,59.069999694824),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderHD_Size	=	5,
				RenderHD_Adv	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderHD_Adv	=	true,
				Pos	=	Vector(-44.439998626709,-138.83999633789,40.75),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderHD_Size	=	5,
				UseSprite	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3652,
						},
				UseBrake	=	true,
				RenderHD_Adv	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-44.610000610352,-138.64999389648,36.450000762939),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderHD_Size	=	5,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3652,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseReverse	=	true,
				UseSprite	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderHD_Adv	=	true,
				Pos	=	Vector(-44.509998321533,-138.61000061035,32.340000152588),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderHD_Size	=	5,
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseLowBeams	=	true,
				HBeamColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseSprite	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderHD_Size	=	5,
				Pos	=	Vector(28.159999847412,90.050003051758,40.090000152588),
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				RenderHD_Adv	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseSprite	=	true,
				Pos	=	Vector(36,91.430000305176,25.389999389648),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderHD_Size	=	5,
				RenderHD_Adv	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				UseSprite	=	true,
				Pos	=	Vector(39.450000762939,19.469999313354,59.340000152588),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderHD_Size	=	5,
				RenderHD_Adv	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				UseSprite	=	true,
				Pos	=	Vector(33.889999389648,-138.46000671387,40.700000762939),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderHD_Size	=	5,
				RenderHD_Adv	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3652,
						},
				UseBrake	=	true,
				UseSprite	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseRunning	=	true,
				RenderHD_Adv	=	true,
				Pos	=	Vector(34.009998321533,-138.63999938965,36.560001373291),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderHD_Size	=	5,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3652,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseReverse	=	true,
				UseSprite	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderHD_Adv	=	true,
				Pos	=	Vector(33.930000305176,-138.13000488281,32.650001525879),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderHD_Size	=	5,
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseSprite	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseRunning	=	true,
				RenderHD_Adv	=	true,
				Pos	=	Vector(20.930000305176,89.660003662109,25.549999237061),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderHD_Size	=	5,
				RunningColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseSprite	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	100,
					a	=	255,
					g	=	175,
						},
				UseRunning	=	true,
				RenderHD_Adv	=	true,
				Pos	=	Vector(-32.689998626709,89.660003662109,25.549999237061),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderHD_Size	=	5,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				Dynamic	=	{
					Size	=	0.8,
					Brightness	=	2,
						},
				FogColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				BGroups	=	{
					[2]	=	{
							"police_lights",
							},
						},
				UsePrjTex	=	true,
				Pos	=	Vector(-34.790000915527,41.110000610352,98.959999084473),
				UseDynamic	=	true,
				UseFog	=	true,
				UseSprite	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				Dynamic	=	{
					Size	=	0.8,
					Brightness	=	2,
						},
				FogColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				BGroups	=	{
					[2]	=	{
							"police_lights",
							},
						},
				UsePrjTex	=	true,
				Pos	=	Vector(23.489999771118,41.340000152588,98.48999786377),
				UseDynamic	=	true,
				UseFog	=	true,
				UseSprite	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				},
		HealthEnginePosOvr	=	true,
		Fuel	=	{
			FuelType	=	0,
				},
		Author	=	"DangerKiddy(DK) (76561198132964487)",
}