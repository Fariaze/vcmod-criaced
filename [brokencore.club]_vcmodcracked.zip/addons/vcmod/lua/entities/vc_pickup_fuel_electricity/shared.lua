-- DurkaTeam @ 2025 Никакие права не защищены
ENT.Base 		= "base_anim"
ENT.Type 		= "anim"
ENT.PrintName	= "Car battery, 1.3 kWh"
ENT.Author		= "freemmaann"
ENT.Category	= "VCMod"

ENT.Spawnable = true
ENT.AdminSpawnable = true

ENT.VC_Type = "fuel"
ENT.VC_FuelType = 2
ENT.VC_Storage = 0.7645
ENT.VC_MaxStorage = 0.7645