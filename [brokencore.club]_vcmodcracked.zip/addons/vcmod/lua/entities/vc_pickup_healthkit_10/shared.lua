-- DurkaTeam @ 2025 Никакие права не защищены
ENT.Base 		= "base_anim"
ENT.Type 		= "anim"
ENT.PrintName	= "Repair kit 10%"
ENT.Author		= "freemmaann"
ENT.Category	= "VCMod"

ENT.Spawnable = true
ENT.AdminSpawnable = true
