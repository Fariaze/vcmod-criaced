VCModels['models/crsk_autoslexuslx570_2016.mdl']	=	{
		em_state	=	5236594572,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Copyright	=	"Copyright © 2012-2018 VCMod (freemmaann). All Rights Reserved.",
		Exhaust	=	{
				{
				Ang	=	Angle(15,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(-23.049999237061,-135.07000732422,17.090000152588),
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(17,0,0),
				Pos	=	Vector(19.340000152588,-0.79000002145767,41.990001678467),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(16,0,0),
				Pos	=	Vector(-19.340000152588,-45.159999847412,40.349998474121),
					},
				{
				Ang	=	Angle(16,0,0),
				Pos	=	Vector(19.340000152588,-45.159999847412,40.349998474121),
					},
				{
				Ang	=	Angle(16,0,0),
				Pos	=	Vector(-1.210000038147,-45.159999847412,40.349998474121),
					},
				},
		DLT	=	3491063048,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					AmountV	=	2,
					Use	=	true,
					Pos2	=	Vector(21.120000839233,-136.7799987793,53.369998931885),
					AmountH	=	10,
					Pos4	=	Vector(37.299999237061,-133.82000732422,51.919998168945),
					Pos1	=	Vector(37.139999389648,-133.74000549316,53.459999084473),
					Pos3	=	Vector(22.829999923706,-136.2799987793,52.209999084473),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(37.299999237061,-133.82000732422,51.919998168945),
					Pos2	=	Vector(21.120000839233,-136.7799987793,53.369998931885),
					Use	=	true,
					Pos1	=	Vector(37.139999389648,-133.74000549316,53.459999084473),
					Pos3	=	Vector(22.829999923706,-136.2799987793,52.209999084473),
						},
				UseSprite	=	true,
				Pos	=	Vector(30.540000915527,-134.96000671387,52.790000915527),
				UseDynamic	=	true,
				UseRunning	=	true,
				Beta_Inner3D	=	true,
				RenderMLCenter	=	true,
				RunningColor	=	{
						255,
						0,
						0,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(42.930000305176,-131.22999572754,54.169998168945),
					Pos2	=	Vector(37.819999694824,-134.16999816895,55.169998168945),
					Use	=	true,
					Pos1	=	Vector(41.319999694824,-132.36999511719,56.130001068115),
					Pos3	=	Vector(37.770000457764,-134.00999450684,54.439998626709),
						},
				UseRunning	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(40.169998168945,-132.53999328613,55.060001373291),
				UseDynamic	=	true,
				Beta_Inner3D	=	true,
				SpecRec	=	{
					AmountV	=	2,
					Pos4	=	Vector(42.930000305176,-131.22999572754,54.169998168945),
					Pos2	=	Vector(37.819999694824,-134.16999816895,55.169998168945),
					AmountH	=	4,
					Use	=	true,
					Pos1	=	Vector(41.319999694824,-132.36999511719,56.130001068115),
					Pos3	=	Vector(37.770000457764,-134.00999450684,54.439998626709),
						},
				BrakeColor	=	{
						255,
						0,
						0,
						},
				RunningColor	=	{
						255,
						0,
						0,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(43.040000915527,-131.13999938965,54.689998626709),
					Pos2	=	Vector(41.919998168945,-131.69999694824,57.709999084473),
					Use	=	true,
					Pos1	=	Vector(42.830001831055,-131.19999694824,57.279998779297),
					Pos3	=	Vector(41.509998321533,-132.0299987793,56.189998626709),
						},
				UseRunning	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(42.069999694824,-130.88000488281,57.700000762939),
				UseDynamic	=	true,
				UseSprite	=	true,
				SpecRec	=	{
					AmountV	=	2,
					Use	=	true,
					Pos2	=	Vector(41.919998168945,-131.69999694824,57.709999084473),
					AmountH	=	2,
					Pos4	=	Vector(43.040000915527,-131.13999938965,54.689998626709),
					Pos1	=	Vector(42.830001831055,-131.19999694824,57.279998779297),
					Pos3	=	Vector(41.509998321533,-132.0299987793,56.189998626709),
						},
				BrakeColor	=	{
						255,
						0,
						0,
						},
				RunningColor	=	{
						255,
						0,
						0,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(41.75,-128.91000366211,60.389999389648),
					Pos2	=	Vector(41.919998168945,-131.91999816895,57.419998168945),
					Use	=	true,
					Pos1	=	Vector(42.779998779297,-131.32000732422,56.979999542236),
					Pos3	=	Vector(41.229999542236,-129.67999267578,60.319999694824),
						},
				UseRunning	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(42.110000610352,-130.83999633789,58.049999237061),
				UseDynamic	=	true,
				UseSprite	=	true,
				SpecRec	=	{
					Use	=	true,
					AmountV	=	3,
					Pos2	=	Vector(42.040000915527,-131.88000488281,57.319999694824),
					AmountH	=	2,
					Pos4	=	Vector(41.75,-128.91000366211,60.389999389648),
					Pos1	=	Vector(42.779998779297,-131.32000732422,56.979999542236),
					Pos3	=	Vector(41.229999542236,-129.67999267578,60.319999694824),
						},
				BrakeColor	=	{
						255,
						0,
						0,
						},
				RunningColor	=	{
						255,
						0,
						0,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(37.580001831055,-134.16999816895,54.479999542236),
					Pos2	=	Vector(18.909999847412,-136.41999816895,55.150001525879),
					Use	=	true,
					Pos1	=	Vector(37.360000610352,-134.17999267578,55.169998168945),
					Pos3	=	Vector(20.079999923706,-136.38999938965,54.139999389648),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(21.139999389648,-136.38000488281,54.680000305176),
				UseDynamic	=	true,
				Beta_Inner3D	=	true,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(28.799999237061,-135.44000244141,54.779998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(36.459999084473,-134.13999938965,54.950000762939),
								},
							},
						},
				UseRunning	=	true,
				RunningColor	=	{
						255,
						0,
						0,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(44.740001678467,-130,51.700000762939),
					Pos2	=	Vector(37.779998779297,-133.86000061035,53.830001831055),
					Use	=	true,
					Pos1	=	Vector(43.220001220703,-130.96000671387,53.470001220703),
					Pos3	=	Vector(38.189998626709,-133.47999572754,51.639999389648),
						},
				UseRunning	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(41.310001373291,-132.58000183105,52.470001220703),
				UseDynamic	=	true,
				UseSprite	=	true,
				SpecRec	=	{
					Use	=	true,
					Pos4	=	Vector(44.740001678467,-130,51.700000762939),
					Pos2	=	Vector(37.779998779297,-133.86000061035,53.830001831055),
					AmountH	=	4,
					AmountV	=	2,
					Pos1	=	Vector(43.220001220703,-130.96000671387,53.470001220703),
					Pos3	=	Vector(38.189998626709,-133.47999572754,51.639999389648),
						},
				BrakeColor	=	{
						255,
						0,
						0,
						},
				RunningColor	=	{
						255,
						0,
						0,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(44.930000305176,-128.63000488281,51.389999389648),
					Pos2	=	Vector(43.270000457764,-130.88000488281,57.139999389648),
					Use	=	true,
					Pos1	=	Vector(44.099998474121,-129.44000244141,57.139999389648),
					Pos3	=	Vector(43.409999847412,-130.91999816895,53.869998931885),
						},
				SpecRec	=	{
					Use	=	true,
					AmountV	=	3,
					Pos2	=	Vector(43.270000457764,-130.88000488281,57.139999389648),
					AmountH	=	2,
					Pos4	=	Vector(44.930000305176,-128.63000488281,51.389999389648),
					Pos1	=	Vector(44.099998474121,-129.44000244141,57.139999389648),
					Pos3	=	Vector(43.409999847412,-130.91999816895,53.869998931885),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBrake	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(43.810001373291,-130.0299987793,55.869998931885),
				UseDynamic	=	true,
				UseSprite	=	true,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				BrakeColor	=	{
						255,
						0,
						0,
						},
				RunningColor	=	{
						255,
						0,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(43.509998321533,-130.86999511719,56.639999389648),
					Pos2	=	Vector(43.319999694824,-127.91999816895,60.040000915527),
					Use	=	true,
					Pos1	=	Vector(42.849998474121,-128.61999511719,60.110000610352),
					Pos3	=	Vector(44.130001068115,-129.53999328613,56.650001525879),
						},
				SpecRec	=	{
					Use	=	true,
					AmountV	=	2,
					Pos2	=	Vector(43.319999694824,-127.91999816895,60.040000915527),
					AmountH	=	3,
					Pos4	=	Vector(43.509998321533,-130.86999511719,56.639999389648),
					Pos1	=	Vector(42.849998474121,-128.61999511719,60.110000610352),
					Pos3	=	Vector(44.130001068115,-129.53999328613,56.650001525879),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBrake	=	true,
				UseSprite	=	true,
				Pos	=	Vector(43.810001373291,-130.13999938965,56.099998474121),
				UseDynamic	=	true,
				Beta_Inner3D	=	true,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				BrakeColor	=	{
						255,
						0,
						0,
						},
				RunningColor	=	{
						255,
						0,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(19.659999847412,-135.80000305176,55.849998474121),
				UseDynamic	=	true,
				RenderInner	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				Beta_Inner3D	=	true,
				SpecMLine	=	{
					Amount	=	16,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(36.139999389648,-134.11000061035,56.259998321533),
								},
							},
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				FogColor	=	{
						255,
						55,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(41.020000457764,-134.57000732422,29.25),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseFog	=	true,
				UseSprite	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(40.490001678467,-130.64999389648,58.590000152588),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(39.700000762939,-132.38000488281,56.880001068115),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				seq_stay	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(24.629999160767,107.05000305176,43.349998474121),
				UseBlinkers	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(35.009998321533,102.01999664307,44.419998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(40.200000762939,99.160003662109,44.959999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(42.790000915527,97.139999389648,45.310001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(44.090000152588,95.449996948242,45.549999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(44.900001525879,93.190002441406,45.75),
								},
							{
							Pos	=	Vector(45.389999389648,90.129997253418,45.950000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				seq_use	=	true,
				UseSprite	=	true,
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(56.770000457764,19.040000915527,64.470001220703),
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	8,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(56.430000305176,21.950000762939,64.230003356934),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(52.810001373291,24.860000610352,63.990001678467),
								},
							},
						},
				RenderMLCenter	=	true,
				Beta_Inner3D	=	true,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(45.080001831055,98.23999786377,31.170000076294),
					Pos2	=	Vector(41.799999237061,98.23999786377,34.450000762939),
					Use	=	true,
					Pos1	=	Vector(45.080001831055,98.23999786377,34.450000762939),
					Pos3	=	Vector(41.799999237061,98.23999786377,31.170000076294),
						},
				FogColor	=	{
						195,
						195,
						255,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(43.439998626709,98.23999786377,32.810001373291),
				UseFog	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UsePrjTex	=	true,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(31.10000038147,98.930000305176,47.950000762939),
					Pos2	=	Vector(29.209999084473,98.919998168945,48.860000610352),
					Use	=	true,
					Pos1	=	Vector(31.549999237061,98.610000610352,49.020000457764),
					Pos3	=	Vector(28.739999771118,99.01000213623,47.799999237061),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(30.139999389648,98.930000305176,48.479999542236),
				UseDynamic	=	true,
				Beta_Inner3D	=	true,
				RenderMLCenter	=	true,
				UseRunning	=	true,
				RunningColor	=	{
						195,
						195,
						255,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(35.990001678467,95.48999786377,48.889999389648),
					Pos2	=	Vector(34.099998474121,95.480003356934,49.799999237061),
					Use	=	true,
					Pos1	=	Vector(36.439998626709,95.169998168945,49.959999084473),
					Pos3	=	Vector(33.630001068115,95.569999694824,48.740001678467),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Beta_Inner3D	=	true,
				LBeamColor	=	{
						195,
						195,
						255,
						},
				UseDynamic	=	true,
				Pos	=	Vector(35.029998779297,95.48999786377,49.419998168945),
				UsePrjTex	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RenderMLCenter	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(40.919998168945,92.050003051758,49.950000762939),
					Pos2	=	Vector(39.029998779297,92.040000915527,50.860000610352),
					Use	=	true,
					Pos1	=	Vector(41.369998931885,91.730003356934,51.020000457764),
					Pos3	=	Vector(38.560001373291,92.129997253418,49.799999237061),
						},
				HBeamColor	=	{
						195,
						195,
						255,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				UsePrjTex	=	true,
				Pos	=	Vector(39.959999084473,92.050003051758,50.479999542236),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderMLCenter	=	true,
				Beta_Inner3D	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					Use	=	true,
					AmountV	=	2,
					Pos2	=	Vector(-21.700000762939,-136.7799987793,53.369998931885),
					AmountH	=	10,
					Pos4	=	Vector(-37.880001068115,-133.82000732422,51.919998168945),
					Pos1	=	Vector(-37.720001220703,-133.74000549316,53.459999084473),
					Pos3	=	Vector(-23.409999847412,-136.2799987793,52.209999084473),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-37.880001068115,-133.82000732422,51.919998168945),
					Pos2	=	Vector(-21.700000762939,-136.7799987793,53.369998931885),
					Use	=	true,
					Pos1	=	Vector(-37.720001220703,-133.74000549316,53.459999084473),
					Pos3	=	Vector(-23.409999847412,-136.2799987793,52.209999084473),
						},
				UseSprite	=	true,
				Pos	=	Vector(-31.120000839233,-134.96000671387,52.790000915527),
				UseDynamic	=	true,
				UseRunning	=	true,
				Beta_Inner3D	=	true,
				RenderMLCenter	=	true,
				RunningColor	=	{
						255,
						0,
						0,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-43.490001678467,-131.22999572754,54.169998168945),
					Pos2	=	Vector(-38.380001068115,-134.16999816895,55.169998168945),
					Use	=	true,
					Pos1	=	Vector(-41.880001068115,-132.36999511719,56.130001068115),
					Pos3	=	Vector(-38.330001831055,-134.00999450684,54.439998626709),
						},
				UseRunning	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-40.729999542236,-132.53999328613,55.060001373291),
				UseDynamic	=	true,
				Beta_Inner3D	=	true,
				SpecRec	=	{
					Pos4	=	Vector(-43.490001678467,-131.22999572754,54.169998168945),
					AmountV	=	2,
					Pos2	=	Vector(-38.380001068115,-134.16999816895,55.169998168945),
					AmountH	=	4,
					Use	=	true,
					Pos1	=	Vector(-41.880001068115,-132.36999511719,56.130001068115),
					Pos3	=	Vector(-38.330001831055,-134.00999450684,54.439998626709),
						},
				BrakeColor	=	{
						255,
						0,
						0,
						},
				RunningColor	=	{
						255,
						0,
						0,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					Use	=	true,
					AmountV	=	2,
					Pos2	=	Vector(-42.330001831055,-131.69999694824,57.709999084473),
					AmountH	=	2,
					Pos4	=	Vector(-43.450000762939,-131.13999938965,54.689998626709),
					Pos1	=	Vector(-43.240001678467,-131.19999694824,57.279998779297),
					Pos3	=	Vector(-41.919998168945,-132.0299987793,56.189998626709),
						},
				UseRunning	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-43.450000762939,-131.13999938965,54.689998626709),
					Pos2	=	Vector(-42.330001831055,-131.69999694824,57.709999084473),
					Use	=	true,
					Pos1	=	Vector(-43.240001678467,-131.19999694824,57.279998779297),
					Pos3	=	Vector(-41.919998168945,-132.0299987793,56.189998626709),
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-42.479999542236,-130.88000488281,57.700000762939),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				UseSprite	=	true,
				BrakeColor	=	{
						255,
						0,
						0,
						},
				RunningColor	=	{
						255,
						0,
						0,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					AmountV	=	3,
					Use	=	true,
					Pos2	=	Vector(-42.479999542236,-131.88000488281,57.319999694824),
					AmountH	=	2,
					Pos4	=	Vector(-42.189998626709,-128.91000366211,60.389999389648),
					Pos1	=	Vector(-43.220001220703,-131.32000732422,56.979999542236),
					Pos3	=	Vector(-41.669998168945,-129.67999267578,60.319999694824),
						},
				UseRunning	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-42.189998626709,-128.91000366211,60.389999389648),
					Pos2	=	Vector(-42.360000610352,-131.91999816895,57.419998168945),
					Use	=	true,
					Pos1	=	Vector(-43.220001220703,-131.32000732422,56.979999542236),
					Pos3	=	Vector(-41.669998168945,-129.67999267578,60.319999694824),
						},
				Beta_Inner3D	=	true,
				Pos	=	Vector(-42.549999237061,-130.83999633789,58.049999237061),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				UseSprite	=	true,
				BrakeColor	=	{
						255,
						0,
						0,
						},
				RunningColor	=	{
						255,
						0,
						0,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-38.069999694824,-134.16999816895,54.479999542236),
					Pos2	=	Vector(-19.39999961853,-136.41999816895,55.150001525879),
					Use	=	true,
					Pos1	=	Vector(-37.849998474121,-134.17999267578,55.169998168945),
					Pos3	=	Vector(-20.569999694824,-136.38999938965,54.139999389648),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-21.629999160767,-136.38000488281,54.680000305176),
				UseDynamic	=	true,
				Beta_Inner3D	=	true,
				SpecMLine	=	{
					Amount	=	25,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-29.290000915527,-135.44000244141,54.779998779297),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-36.950000762939,-134.13999938965,54.950000762939),
								},
							},
						},
				UseRunning	=	true,
				RunningColor	=	{
						255,
						0,
						0,
						},
				RenderMLCenter	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-45.270000457764,-130,51.700000762939),
					Pos2	=	Vector(-38.310001373291,-133.86000061035,53.830001831055),
					Use	=	true,
					Pos1	=	Vector(-43.75,-130.96000671387,53.470001220703),
					Pos3	=	Vector(-38.720001220703,-133.47999572754,51.639999389648),
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseRunning	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-41.840000152588,-132.58000183105,52.470001220703),
				UseDynamic	=	true,
				Beta_Inner3D	=	true,
				SpecRec	=	{
					Use	=	true,
					Pos4	=	Vector(-45.270000457764,-130,51.700000762939),
					Pos2	=	Vector(-38.310001373291,-133.86000061035,53.830001831055),
					AmountH	=	4,
					AmountV	=	2,
					Pos1	=	Vector(-43.75,-130.96000671387,53.470001220703),
					Pos3	=	Vector(-38.720001220703,-133.47999572754,51.639999389648),
						},
				BrakeColor	=	{
						255,
						0,
						0,
						},
				RunningColor	=	{
						255,
						0,
						0,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-45.400001525879,-128.63000488281,51.389999389648),
					Pos2	=	Vector(-43.740001678467,-130.88000488281,57.139999389648),
					Use	=	true,
					Pos1	=	Vector(-44.569999694824,-129.44000244141,57.139999389648),
					Pos3	=	Vector(-43.880001068115,-130.91999816895,53.869998931885),
						},
				SpecRec	=	{
					AmountV	=	3,
					Use	=	true,
					Pos2	=	Vector(-43.740001678467,-130.88000488281,57.139999389648),
					AmountH	=	2,
					Pos4	=	Vector(-45.400001525879,-128.63000488281,51.389999389648),
					Pos1	=	Vector(-44.569999694824,-129.44000244141,57.139999389648),
					Pos3	=	Vector(-43.880001068115,-130.91999816895,53.869998931885),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseRunning	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-44.279998779297,-130.0299987793,55.869998931885),
				UseDynamic	=	true,
				UseSprite	=	true,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				BrakeColor	=	{
						255,
						0,
						0,
						},
				RunningColor	=	{
						255,
						0,
						0,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
						},
				SpecRec	=	{
					AmountV	=	2,
					Use	=	true,
					Pos2	=	Vector(-43.75,-127.91999816895,60.040000915527),
					AmountH	=	3,
					Pos4	=	Vector(-43.939998626709,-130.86999511719,56.639999389648),
					Pos1	=	Vector(-43.279998779297,-128.61999511719,60.110000610352),
					Pos3	=	Vector(-44.560001373291,-129.53999328613,56.650001525879),
						},
				UseRunning	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-43.939998626709,-130.86999511719,56.639999389648),
					Pos2	=	Vector(-43.75,-127.91999816895,60.040000915527),
					Use	=	true,
					Pos1	=	Vector(-43.279998779297,-128.61999511719,60.110000610352),
					Pos3	=	Vector(-44.560001373291,-129.53999328613,56.650001525879),
						},
				UseSprite	=	true,
				Pos	=	Vector(-44.240001678467,-130.13999938965,56.099998474121),
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
				BrakeColor	=	{
						255,
						0,
						0,
						},
				RunningColor	=	{
						255,
						0,
						0,
						},
				UseBrake	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				SpecSpin	=	{
						},
				UseReverse	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-19.909999847412,-135.66000366211,55.799999237061),
				UseDynamic	=	true,
				RenderInner	=	true,
				ReverseColor	=	{
						200,
						225,
						255,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				SpecMLine	=	{
					Amount	=	16,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-36.599998474121,-133.86999511719,56.459999084473),
								},
							},
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				FogColor	=	{
						255,
						55,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-41.590000152588,-134.57000732422,29.25),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseFog	=	true,
				UseSprite	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-40.819999694824,-130.64999389648,58.819999694824),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseBlinkers	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-40.130001068115,-132.36999511719,57.110000610352),
				UseDynamic	=	true,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseBlinkers	=	true,
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				UseDynamic	=	true,
				seq_stay	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-23.909999847412,107.05000305176,43.349998474121),
				UseSprite	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	20,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-34.290000915527,102.01999664307,44.419998168945),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-39.479999542236,99.160003662109,44.959999084473),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-42.069999694824,97.139999389648,45.310001373291),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-43.369998931885,95.449996948242,45.549999237061),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-44.180000305176,93.190002441406,45.75),
								},
							{
							Pos	=	Vector(-44.669998168945,90.129997253418,45.950000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				seq_use	=	true,
				RenderMLCenter	=	true,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				SpecSpin	=	{
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-56.770000457764,19.040000915527,64.470001220703),
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	8,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-56.430000305176,21.950000762939,64.230003356934),
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-52.810001373291,24.860000610352,63.990001678467),
								},
							},
						},
				UseSprite	=	true,
				RenderMLCenter	=	true,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/circle",
					Pos4	=	Vector(-44.560001373291,98.26000213623,31.309999465942),
					Pos2	=	Vector(-41.279998779297,98.26000213623,34.590000152588),
					Use	=	true,
					Pos1	=	Vector(-44.560001373291,98.26000213623,34.590000152588),
					Pos3	=	Vector(-41.279998779297,98.26000213623,31.309999465942),
						},
				FogColor	=	{
						195,
						195,
						255,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-42.919998168945,98.26000213623,32.950000762939),
				UseFog	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseSprite	=	true,
				UsePrjTex	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-30.530000686646,98.930000305176,48.060001373291),
					Pos2	=	Vector(-28.639999389648,98.919998168945,48.970001220703),
					Use	=	true,
					Pos1	=	Vector(-30.979999542236,98.610000610352,49.130001068115),
					Pos3	=	Vector(-28.170000076294,99.01000213623,47.909999847412),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-29.569999694824,98.930000305176,48.590000152588),
				UseDynamic	=	true,
				RenderMLCenter	=	true,
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseRunning	=	true,
				RunningColor	=	{
						195,
						195,
						255,
						},
				Beta_Inner3D	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-35.369998931885,95.48999786377,49.110000610352),
					Pos2	=	Vector(-33.479999542236,95.480003356934,50.020000457764),
					Use	=	true,
					Pos1	=	Vector(-35.819999694824,95.169998168945,50.180000305176),
					Pos3	=	Vector(-33.009998321533,95.569999694824,48.959999084473),
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UsePrjTex	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-34.409999847412,95.48999786377,49.639999389648),
				UseDynamic	=	true,
				LBeamColor	=	{
						195,
						195,
						255,
						},
				RenderMLCenter	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				Beta_Inner3D	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
						},
				Spec3D	=	{
					Mat	=	"vcmod/square",
					Pos4	=	Vector(-40.360000610352,92.050003051758,50.209999084473),
					Pos2	=	Vector(-38.470001220703,92.040000915527,51.119998931885),
					Use	=	true,
					Pos1	=	Vector(-40.810001373291,91.730003356934,51.279998779297),
					Pos3	=	Vector(-38,92.129997253418,50.060001373291),
						},
				HBeamColor	=	{
						195,
						195,
						255,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UsePrjTex	=	true,
				Pos	=	Vector(-39.400001525879,92.050003051758,50.740001678467),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Beta_Inner3D	=	true,
				UseSprite	=	true,
				RenderMLCenter	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				SpecSpin	=	{
						},
				UseBrake	=	true,
				UseSprite	=	true,
				Dynamic	=	{
					Size	=	0.35,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				RenderMLCenter	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-5.1100001335144,-122.06999969482,83.940002441406),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	10,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(4.8899998664856,-122.06999969482,83.940002441406),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				},
		Date	=	"Sat Mar 24 02:04:42 2018",
		Fuel	=	{
			FuelLidPos	=	Vector(48.369998931885,-102.76000213623,47.049999237061),
			FuelType	=	1,
			Capacity	=	93,
			Override	=	true,
			FuelLidUse	=	true,
				},
		Author	=	"𝓒𝓣𝓥𝟏𝟐𝟐𝟓 (76561198051637331)",
}