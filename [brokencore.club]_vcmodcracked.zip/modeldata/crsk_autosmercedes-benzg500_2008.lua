VCModels['models/crsk_autosmercedes-benzg500_2008.mdl']	=	{
		em_state	=	5236594539,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Copyright	=	"Copyright © 2012-2018 VCMod (freemmaann). All Rights Reserved.",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(-49.700000762939,-44.860000610352,11.079999923706),
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				EffectStress	=	"VC_Exhaust_Stress",
				Pos	=	Vector(-47.959999084473,-49.860000610352,10.220000267029),
				EffectIdle	=	"VC_Exhaust",
					},
				},
		Indication	=	{
			speedo_kmph	=	{
				max	=	1,
				pp	=	"vehicle_guage",
				min	=	0,
				top	=	240,
					},
			fuel	=	{
				max	=	1,
				pp	=	"fuel_needle",
				min	=	0,
				top	=	1,
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(20,0,0),
				Pos	=	Vector(20.809999465942,-3.5699999332428,45.759998321533),
				RadioControl	=	true,
					},
				{
				Ang	=	Angle(12,0,0),
				Pos	=	Vector(-20.809999465942,-41.529998779297,47.759998321533),
					},
				{
				Ang	=	Angle(12,0,0),
				Pos	=	Vector(20.809999465942,-41.569999694824,47.799999237061),
					},
				{
				Ang	=	Angle(12,0,0),
				Pos	=	Vector(0,-41.569999694824,47.759998321533),
					},
				{
				Cant_Exit_Lock	=	true,
				DriveBy_Cant	=	true,
				Switch_Cant	=	true,
				Pos	=	Vector(-5.6300001144409,-88.029998779297,37.880001068115),
				Switch_Rear	=	true,
				Ang	=	Angle(180,0,-90),
					},
				},
		DLT	=	3491063026,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.7,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	255,
					b	=	199,
					a	=	255,
					g	=	213,
						},
				UseDynamic	=	true,
				SpecCircle	=	{
					Use	=	true,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				HBeamColor	=	{
					r	=	255,
					b	=	199,
					a	=	255,
					g	=	213,
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-29.690000534058,86.900001525879,41.819999694824),
				RenderInner	=	true,
				UseHighBeams	=	true,
				SpecMat	=	{
						},
				RenderInner_Size	=	1,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.7,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	255,
					b	=	199,
					a	=	255,
					g	=	213,
						},
				UseDynamic	=	true,
				SpecCircle	=	{
					Use	=	true,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				Dynamic	=	{
					Size	=	0.2,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(30.190000534058,86.860000610352,41.810001373291),
				RenderInner_Size	=	1,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				HBeamColor	=	{
					r	=	255,
					b	=	199,
					a	=	255,
					g	=	213,
						},
				RenderInner	=	true,
				UseHighBeams	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseRunning	=	true,
				SpecMat	=	{
					Select	=	2,
					New	=	"models\crskautos\mercedes-benz\g500_2008\spedillum_on",
					Use	=	true,
						},
				ReducedVis	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	199,
					a	=	255,
					g	=	213,
						},
				UseSprite	=	true,
				Pos	=	Vector(-27.889999389648,91.319999694824,23.719999313354),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				Dynamic	=	{
					Size	=	0.73,
					Brightness	=	2,
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.5,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseRunning	=	true,
				SpecMat	=	{
					Select	=	6,
					New	=	"models\crskautos\mercedes-benz\g500_2008\whiteillum_on",
					Use	=	true,
						},
				ReducedVis	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	199,
					a	=	255,
					g	=	213,
						},
				UseSprite	=	true,
				Pos	=	Vector(27.879999160767,91.319999694824,23.379999160767),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				Dynamic	=	{
					Size	=	0.73,
					Brightness	=	2,
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3485,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				FogColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-31.010000228882,-115.80000305176,22.790000915527),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				UseFog	=	true,
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3485,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseReverse	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(30.659999847412,-115.31999969482,22.690000534058),
				UseDynamic	=	true,
				RenderInner	=	true,
				ReverseColor	=	{
					r	=	255,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3485,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-33.590000152588,78.110000610352,50.810001373291),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3485,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(33.560001373291,78.220001220703,50.810001373291),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderInner_Size	=	1,
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1364,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-46.310001373291,21.309999465942,62.5),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	6,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(-49.909999847412,18.620000839233,62.580001831055),
								},
							{
							Pos	=	Vector(-51.169998168945,16.739999771118,62.529998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1364,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(46.810001373291,21.049999237061,62.229999542236),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	6,
					Use	=	true,
					LTbl	=	{
							{
							UseClr	=	false,
							Pos	=	Vector(50.369998931885,18.590000152588,62.209999084473),
								},
							{
							Pos	=	Vector(49.689998626709,16.610000610352,62.159999847412),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3485,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-30.39999961853,-114.08000183105,32.25),
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	2,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-33.680000305176,-113.59999847412,32.200000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseBrake	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_Size	=	1,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3485,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseDynamic	=	true,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
				UseRunning	=	true,
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseSprite	=	true,
				Pos	=	Vector(34.259998321533,-113.23000335693,31.829999923706),
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	2,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(30.979999542236,-112.75,31.780000686646),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseBrake	=	true,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3485,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-37.619998931885,-113.41999816895,32.240001678467),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderInner_Size	=	1,
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.3485,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				SpecMat	=	{
						},
				ReducedVis	=	true,
				UseBlinkers	=	true,
				UseSprite	=	true,
				Pos	=	Vector(37.590000152588,-113.62000274658,31.889999389648),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderInner_Size	=	1,
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1364,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseBrake	=	true,
				RenderInner_Size	=	1,
				RenderMLCenter	=	true,
				SpecMat	=	{
						},
				ReducedVis	=	true,
				Dynamic	=	{
					Size	=	0,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(5.3200001716614,-105.98000335693,79.330001831055),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	30,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-5.0799999237061,-105.93000030518,79.169998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseInter	=	true,
				InterColor	=	{
					r	=	225,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				SpecMat	=	{
					Select	=	25,
					New	=	"models\crskautos\mercedes-benz\g500_2008\newinterlight_on",
					Use	=	true,
						},
				ReducedVis	=	true,
				IsInterior	=	true,
				Pos	=	Vector(27.879999160767,35.450000762939,72.269996643066),
				RenderInner	=	true,
				RenderInner_Size	=	1,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				},
		Date	=	"Tue Feb 27 16:21:40 2018",
		Fuel	=	{
			FuelLidPos	=	Vector(41.869998931885,-102.73000335693,40.419998168945),
			FuelType	=	0,
			Capacity	=	96,
			Override	=	true,
			FuelLidUse	=	true,
				},
		Author	=	"CrushingSkirmish (76561198017348899)",
}