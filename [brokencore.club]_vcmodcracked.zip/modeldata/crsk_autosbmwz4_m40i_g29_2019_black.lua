VCModels['models/crsk_autosbmwz4_m40i_g29_2019_black.mdl']	=	{
		em_state	=	5236594461,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Copyright	=	"Copyright © 2012-2019 VCMod (freemmaann). All Rights Reserved.",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-24.829999923706,-98.220001220703,13.279999732971),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(24.829999923706,-98.220001220703,13.279999732971),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(20,0,0),
				Pos	=	Vector(17.270000457764,-8.1800003051758,27.569999694824),
				RadioControl	=	true,
					},
				},
		DLT	=	3491062974,
		Lights	=	{
				{
				UseRunning	=	true,
				Pos	=	Vector(-19.780000686646,11.270000457764,40.310001373291),
				SpecMat	=	{
					Select	=	32,
					New	=	"models\crskautos\bmw\z4_m40i_g29_2019\dho_fari_pered_on",
					Use	=	true,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
					},
				{
				UseRunning	=	true,
				Pos	=	Vector(-18.610000610352,11.270000457764,40.310001373291),
				SpecMat	=	{
					Select	=	31,
					New	=	"models\crskautos\bmw\z4_m40i_g29_2019\dho_fari_pered_tr_on",
					Use	=	true,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
					},
				{
				UseRunning	=	true,
				Pos	=	Vector(-15.170000076294,11.279999732971,40.419998168945),
				SpecMat	=	{
					Select	=	11,
					New	=	"models\crskautos\bmw\z4_m40i_g29_2019\int_symbols_illum_on",
					Use	=	true,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
					},
				{
				UseRunning	=	true,
				Pos	=	Vector(-17.229999542236,11.270000457764,40.310001373291),
				SpecMat	=	{
					Select	=	30,
					New	=	"models\crskautos\bmw\z4_m40i_g29_2019\glasslines_on",
					Use	=	true,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseLowBeams	=	true,
				SpecMat	=	{
					Select	=	27,
					New	=	"models\crskautos\bmw\z4_m40i_g29_2019\gls_clear_light_032_diff_on",
					Use	=	true,
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseSprite	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Pos	=	Vector(-32.819999694824,85.349998474121,30.299999237061),
				UsePrjTex	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.0576,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				DD_Blnk_Run	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-27.64999961853,91.639999389648,31.35000038147),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				SpecMLine	=	{
					Amount	=	22,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-31.709999084473,83.209999084473,33.700000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-37.450000762939,74.610000610352,35.860000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.0599,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-28.950000762939,87.860000610352,28.530000686646),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	14,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-29.950000762939,86.919998168945,27.85000038147),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-35.270000457764,84.519996643066,28.420000076294),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-36.75,83.680000305176,30.60000038147),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-36.279998779297,83.540000915527,31.719999313354),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.0599,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-33.540000915527,78.389999389648,33.569999694824),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	8,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-34.069999694824,78.319999694824,33.009998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-36.729999542236,76.589996337891,32.869998931885),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-37.900001525879,76.110000610352,34.040000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-37.049999237061,75.959999084473,34.650001525879),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1061,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseBrake	=	true,
				RenderInner_Size	=	1.5675,
				UseSprite	=	true,
				Pos	=	Vector(-22.239999771118,-96.080001831055,37.330001831055),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	16,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-27.819999694824,-94.559997558594,37.479999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-32.049999237061,-92.559997558594,37.5),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-35.349998474121,-89.970001220703,37.639999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1133,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseBlinkers	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				UseSprite	=	true,
				Pos	=	Vector(-23.440000534058,-96,36.669998168945),
				UseDynamic	=	true,
				RenderInner_Size	=	1.3821,
				SpecMLine	=	{
					Amount	=	24,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-27.489999771118,-94.959999084473,36.639999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-29.940000534058,-93.870002746582,36.540000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-32.290000915527,-92.849998474121,36.490001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-34.779998779297,-91.269996643066,36.470001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-36.580001831055,-89.330001831055,36.389999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-38.25,-85.419998168945,36.439998626709),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2728,
						},
				UseBrake	=	true,
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-36.299999237061,-89.01000213623,37.779998779297),
				UseDynamic	=	true,
				RenderInner_Size	=	1.5675,
				SpecMLine	=	{
					Amount	=	4,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-37.540000915527,-80.76000213623,39.419998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseReverse	=	true,
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				UseSprite	=	true,
				Pos	=	Vector(-23.790000915527,-94.410003662109,38.740001678467),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				SpecMLine	=	{
					Amount	=	11,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-33.270000457764,-88.360000610352,39.150001525879),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseLowBeams	=	true,
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				UseSprite	=	true,
				LBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseDynamic	=	true,
				UseHighBeams	=	true,
				Pos	=	Vector(32.819999694824,85.349998474121,30.299999237061),
				UsePrjTex	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				SpecMat	=	{
					Select	=	27,
					New	=	"models\crskautos\bmw\z4_m40i_g29_2019\gls_clear_light_032_diff_on",
					Use	=	true,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.0576,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				DD_Blnk_Run	=	true,
				UseSprite	=	true,
				Pos	=	Vector(27.64999961853,91.639999389648,31.35000038147),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				SpecMLine	=	{
					Amount	=	22,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(31.709999084473,83.209999084473,33.700000762939),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(37.450000762939,74.610000610352,35.860000610352),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.0599,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(28.950000762939,87.860000610352,28.530000686646),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	14,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(29.950000762939,86.919998168945,27.85000038147),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(35.270000457764,84.519996643066,28.420000076294),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(36.75,83.680000305176,30.60000038147),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(36.279998779297,83.540000915527,31.719999313354),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.0599,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(33.540000915527,78.389999389648,33.569999694824),
				UseDynamic	=	true,
				SpecMLine	=	{
					Amount	=	8,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(34.069999694824,78.319999694824,33.009998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(36.729999542236,76.589996337891,32.869998931885),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(37.900001525879,76.110000610352,34.040000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(37.049999237061,75.959999084473,34.650001525879),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RunningColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1061,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseBrake	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseRunning	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(22.239999771118,-96.080001831055,37.330001831055),
				UseDynamic	=	true,
				RenderInner_Size	=	1.5675,
				SpecMLine	=	{
					Amount	=	16,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(27.819999694824,-94.559997558594,37.479999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(32.049999237061,-92.559997558594,37.5),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(35.349998474121,-89.970001220703,37.639999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1133,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseBlinkers	=	true,
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				UseSprite	=	true,
				Pos	=	Vector(23.440000534058,-96,36.669998168945),
				UseDynamic	=	true,
				RenderInner_Size	=	1.3821,
				SpecMLine	=	{
					Amount	=	24,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(27.489999771118,-94.959999084473,36.639999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(29.940000534058,-93.870002746582,36.540000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(32.290000915527,-92.849998474121,36.490001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(34.779998779297,-91.269996643066,36.470001220703),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(36.580001831055,-89.330001831055,36.389999389648),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(38.25,-85.419998168945,36.439998626709),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2728,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseBrake	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				UseRunning	=	true,
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(36.299999237061,-89.01000213623,37.779998779297),
				UseDynamic	=	true,
				RenderInner_Size	=	1.5675,
				SpecMLine	=	{
					Amount	=	4,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(37.540000915527,-80.76000213623,39.419998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.15,
						},
				Dynamic	=	{
					Size	=	0.3,
					Brightness	=	2,
						},
				UseReverse	=	true,
				RenderInner	=	true,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				UseSprite	=	true,
				Pos	=	Vector(23.790000915527,-94.410003662109,38.740001678467),
				UseDynamic	=	true,
				RenderInner_Size	=	1,
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				SpecMLine	=	{
					Amount	=	11,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(33.270000457764,-88.360000610352,39.150001525879),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
						},
				RenderInner_ClrUse	=	false,
					},
				},
		Date	=	"Sat Jun  8 21:39:18 2019",
		Fuel	=	{
			FuelType	=	0,
				},
		Author	=	"CrushingSkirmish (76561198017348899)",
}