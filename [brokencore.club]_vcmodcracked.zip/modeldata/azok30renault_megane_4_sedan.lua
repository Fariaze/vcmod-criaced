VCModels['models/azok30renault_megane_4_sedan.mdl']	=	{
		em_state	=	5236594608,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Date	=	"Sat Nov 24 18:22:37 2018",
		Exhaust	=	{
				{
				Ang	=	Angle(15,-90,0),
				Pos	=	Vector(-20.079999923706,-115.66000366211,6.8099999427795),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Pos	=	Vector(16.790000915527,9.3100004196167,26.379999160767),
					},
				{
				Pos	=	Vector(-0.20000000298023,-36.680000305176,23.610000610352),
					},
				{
				Pos	=	Vector(17.299999237061,-36.680000305176,23.110000610352),
					},
				{
				Pos	=	Vector(-17.299999237061,-36.680000305176,23.110000610352),
					},
				},
		DLT	=	3491063072,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				SpecMat	=	{
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-26.079999923706,102.56999969482,29.370000839233),
				UseDynamic	=	true,
				RenderInner_Size	=	1.5,
				SpecMLine	=	{
					Amount	=	170,
					Use	=	true,
					LTbl	=	{
							{
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Pos	=	Vector(-29.989999771118,99.519996643066,29.829999923706),
							Size	=	0.1,
							UseClr	=	false,
								},
							{
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Pos	=	Vector(-35.119998931885,94.23999786377,30.299999237061),
							Size	=	0.1,
							UseClr	=	false,
								},
							{
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Pos	=	Vector(-38.090000152588,90.069999694824,30.760000228882),
							Size	=	0.1,
							UseClr	=	false,
								},
							{
							Size	=	0.1,
							Pos	=	Vector(-40.529998779297,85.910003662109,31.229999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Pos	=	Vector(-41.229999542236,87.709999084473,29.219999313354),
							Size	=	0.1,
							UseClr	=	false,
								},
							{
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Pos	=	Vector(-41.220001220703,89.51000213623,27.219999313354),
							Size	=	0.1,
							UseClr	=	false,
								},
							{
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Pos	=	Vector(-40.990001678467,91.319999694824,25.219999313354),
							Size	=	0.1,
							UseClr	=	false,
								},
							{
							Size	=	0.1,
							Pos	=	Vector(-40.360000610352,93.120002746582,22.979999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Pos	=	Vector(-38.860000610352,95.129997253418,22.030000686646),
							Size	=	0.1,
							UseClr	=	false,
								},
							{
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Pos	=	Vector(-37.360000610352,97.139999389648,21.760000228882),
							Size	=	0.1,
							UseClr	=	false,
								},
							{
							Size	=	1.855,
							Pos	=	Vector(-34.369998931885,101.16000366211,21.379999160767),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseRunning	=	true,
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseRunning	=	true,
				SpecMat	=	{
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(26.079999923706,102.56999969482,29.370000839233),
				UseDynamic	=	true,
				RenderInner_Size	=	1.5,
				SpecMLine	=	{
					Amount	=	170,
					Use	=	true,
					LTbl	=	{
							{
							Size	=	0.1,
							Pos	=	Vector(29.989999771118,99.519996643066,29.829999923706),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Size	=	0.1,
							Pos	=	Vector(35.119998931885,94.23999786377,30.299999237061),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Size	=	0.1,
							Pos	=	Vector(38.090000152588,90.069999694824,30.760000228882),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							UseClr	=	false,
							Pos	=	Vector(40.529998779297,85.910003662109,31.229999542236),
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Size	=	0.1,
								},
							{
							Size	=	0.1,
							Pos	=	Vector(41.229999542236,87.709999084473,29.219999313354),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Size	=	0.1,
							Pos	=	Vector(41.220001220703,89.51000213623,27.219999313354),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Size	=	0.1,
							Pos	=	Vector(40.990001678467,91.319999694824,25.219999313354),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							UseClr	=	false,
							Pos	=	Vector(40.360000610352,93.120002746582,22.979999542236),
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Size	=	0.1,
								},
							{
							Size	=	0.1,
							Pos	=	Vector(38.860000610352,95.129997253418,22.030000686646),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Size	=	0.1,
							Pos	=	Vector(37.360000610352,97.139999389648,21.760000228882),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							UseClr	=	false,
							Pos	=	Vector(34.369998931885,101.16000366211,21.379999160767),
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Size	=	1.855,
								},
							},
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				RunningColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-28.010000228882,97.230003356934,26.389999389648),
					Pos2	=	Vector(-33.630001068115,96.660003662109,29.309999465942),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-28.139999389648,97.080001831055,29.329999923706),
					Pos3	=	Vector(-33.740001678467,96.809997558594,26.370000839233),
						},
				SpecMat	=	{
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
				UsePrjTex	=	true,
				Pos	=	Vector(-31.459999084473,96.949996948242,27.85000038147),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderGlow_Size	=	0,
				UseSprite	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(28.010000228882,97.230003356934,26.389999389648),
					Pos2	=	Vector(33.630001068115,96.660003662109,29.309999465942),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(28.139999389648,97.080001831055,29.329999923706),
					Pos3	=	Vector(33.740001678467,96.809997558594,26.370000839233),
						},
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(31.459999084473,96.949996948242,27.85000038147),
				UseDynamic	=	true,
				UseHighBeams	=	true,
				RenderGlow_Size	=	0,
				UsePrjTex	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				HBeamColor	=	{
					r	=	195,
					b	=	255,
					a	=	255,
					g	=	195,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-34.889999389648,90.550003051758,26.909999847412),
					Pos2	=	Vector(-39.919998168945,90.059997558594,30.569999694824),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-34.610000610352,90.75,29.89999961853),
					Pos3	=	Vector(-40.430000305176,89.839996337891,27.629999160767),
						},
				SpecMat	=	{
						},
				UsePrjTex	=	true,
				LBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseDynamic	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				RenderGlow_Size	=	0,
				UseSprite	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				Pos	=	Vector(-38.040000915527,90.309997558594,28.739999771118),
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseLowBeams	=	true,
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(34.889999389648,90.550003051758,26.909999847412),
					Pos2	=	Vector(39.919998168945,90.059997558594,30.569999694824),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(34.610000610352,90.75,29.89999961853),
					Pos3	=	Vector(40.430000305176,89.839996337891,27.629999160767),
						},
				SpecMat	=	{
						},
				UsePrjTex	=	true,
				Pos	=	Vector(38.040000915527,90.309997558594,28.739999771118),
				UseDynamic	=	true,
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				RenderGlow_Size	=	0,
				UseSprite	=	true,
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				LBeamColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				RenderGlow_Size	=	0,
				UseSprite	=	true,
				Pos	=	Vector(-24.799999237061,107.09999847412,13.89999961853),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	41,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-33.819999694824,101.90000152588,14.319999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-40.029998779297,96.699996948242,14.75),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Size	=	4,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				RenderGlow_Size	=	0,
				UseSprite	=	true,
				Pos	=	Vector(24.799999237061,107.09999847412,13.89999961853),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	41,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(33.819999694824,101.90000152588,14.319999694824),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(40.029998779297,96.699996948242,14.75),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Size	=	4,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(-37.740001678467,98.180000305176,12.840000152588),
					Pos2	=	Vector(-32.860000610352,99.860000610352,7.8600001335144),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-37.740001678467,98.180000305176,7.8600001335144),
					Pos3	=	Vector(-32.860000610352,99.860000610352,12.840000152588),
						},
				FogColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(-35.299999237061,99.019996643066,10.35000038147),
				UseDynamic	=	true,
				RenderInner_Size	=	4,
				UseFog	=	true,
				RenderGlow_Size	=	0,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.25,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/circle_texture",
					Pos4	=	Vector(37.740001678467,98.180000305176,12.840000152588),
					Pos2	=	Vector(32.860000610352,99.860000610352,7.8600001335144),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(37.740001678467,98.180000305176,7.8600001335144),
					Pos3	=	Vector(32.860000610352,99.860000610352,12.840000152588),
						},
				FogColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.45,
					Brightness	=	2,
						},
				RenderInner_Size	=	4,
				UseSprite	=	true,
				Pos	=	Vector(35.299999237061,99.019996643066,10.35000038147),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseFog	=	true,
				RenderGlow_Size	=	0,
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				RenderInner_Size	=	2.1207,
				SpecMLine	=	{
					Amount	=	56,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-32.669998168945,-111.56999969482,37.770000457764),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				UseSprite	=	true,
				Pos	=	Vector(-36.259998321533,-107.41999816895,37.479999542236),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderGlow_Size	=	0,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				BlinkersColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	155,
						},
				UseBlinkers	=	true,
				SpecMat	=	{
						},
				SpecMLine	=	{
					Amount	=	56,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(32.669998168945,-111.56999969482,37.770000457764),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner_Size	=	2.1207,
				UseSprite	=	true,
				Pos	=	Vector(36.259998321533,-107.41999816895,37.479999542236),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderGlow_Size	=	0,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseReverse	=	true,
				RenderInner	=	true,
				SpecMat	=	{
						},
				SpecMLine	=	{
					Amount	=	34,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-27.040000915527,-115.29000091553,37.439998626709),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				UseSprite	=	true,
				Pos	=	Vector(-30.389999389648,-112.41999816895,37.409999847412),
				UseDynamic	=	true,
				RenderInner_Size	=	0,
				RenderGlow_Size	=	0,
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.05,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseReverse	=	true,
				RenderGlow_Size	=	0,
				SpecMat	=	{
						},
				SpecMLine	=	{
					Amount	=	34,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(27.040000915527,-115.29000091553,37.439998626709),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				RenderInner	=	true,
				UseSprite	=	true,
				Pos	=	Vector(30.389999389648,-112.41999816895,37.409999847412),
				UseDynamic	=	true,
				RenderInner_Size	=	0,
				ReverseColor	=	{
					r	=	220,
					b	=	255,
					a	=	255,
					g	=	225,
						},
				Dynamic	=	{
					Size	=	0.25,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	0,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	false,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.02,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RenderGlow_Size	=	0,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
				RenderInner_Size	=	2.5345,
				UseSprite	=	true,
				Pos	=	Vector(-5.9200000762939,-118.23000335693,37.389999389648),
				UseDynamic	=	true,
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	199,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-13.109999656677,-117.93000030518,37.240001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-16.700000762939,-117.79000091553,37.340000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-18.5,-117.70999908447,37.400001525879),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-20.290000915527,-117.63999938965,37.169998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-23.110000610352,-117.04000091553,35.790000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-26.690000534058,-116.44999694824,33.840000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-28.60000038147,-115.48999786377,33.369998931885),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-30.510000228882,-114.5299987793,33.380001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-34.330001831055,-112.61000061035,33.590000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-36.779998779297,-109.33000183105,33.259998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-38,-107.69000244141,33.259998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-39.220001220703,-106.05999755859,33.840000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-39.540000915527,-104.79000091553,35.029998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-39.400001525879,-103.5299987793,36.209999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-39.240001678467,-102.26000213623,37.529998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							UseClr	=	false,
							Pos	=	Vector(-39.029998779297,-101,38.849998474121),
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
							Size	=	0.1,
								},
							},
						},
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.02,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RenderInner_Size	=	2.5345,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				SpecMat	=	{
						},
				SpecMLine	=	{
					Amount	=	199,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(13.109999656677,-117.93000030518,37.240001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(16.700000762939,-117.79000091553,37.340000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(18.5,-117.70999908447,37.400001525879),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(20.290000915527,-117.63999938965,37.169998168945),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(23.110000610352,-117.04000091553,35.790000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(26.690000534058,-116.44999694824,33.840000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(28.60000038147,-115.48999786377,33.369998931885),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(30.510000228882,-114.5299987793,33.380001068115),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(34.330001831055,-112.61000061035,33.590000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(36.779998779297,-109.33000183105,33.259998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(38,-107.69000244141,33.259998321533),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(39.220001220703,-106.05999755859,33.840000152588),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(39.540000915527,-104.79000091553,35.029998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(39.400001525879,-103.5299987793,36.209999084473),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(39.240001678467,-102.26000213623,37.529998779297),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Size	=	0.1,
							Pos	=	Vector(39.029998779297,-101,38.849998474121),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(5.9200000762939,-118.23000335693,37.389999389648),
				UseDynamic	=	true,
				RenderInner	=	true,
				RenderGlow_Size	=	0,
				UseRunning	=	true,
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.02,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				UseBrake	=	true,
				SpecMLine	=	{
					Amount	=	199,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(-20.489999771118,-116.37000274658,38.25),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-26.870000839233,-114.2799987793,38.729999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-30.530000686646,-112.58999633789,39.290000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-33.169998168945,-110.59999847412,39.5),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-35.299999237061,-107.76999664307,39.580001831055),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-37.849998474121,-104.69999694824,40.020000457764),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(-38.959999084473,-100.81999969482,39.990001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				SpecMat	=	{
						},
				RenderInner	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
				UseSprite	=	true,
				Pos	=	Vector(-5.9200000762939,-118.23000335693,37.75),
				UseDynamic	=	true,
				RenderInner_Size	=	2.5345,
				RenderGlow_Size	=	0,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.02,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				RenderInner	=	true,
				SpecMLine	=	{
					Amount	=	199,
					Use	=	true,
					LTbl	=	{
							{
							Pos	=	Vector(20.489999771118,-116.37000274658,38.25),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(26.870000839233,-114.2799987793,38.729999542236),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(30.530000686646,-112.58999633789,39.290000915527),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(33.169998168945,-110.59999847412,39.5),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(35.299999237061,-107.76999664307,39.580001831055),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(37.849998474121,-104.69999694824,40.020000457764),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							{
							Pos	=	Vector(38.959999084473,-100.81999969482,39.990001678467),
							UseClr	=	false,
							Clr	=	{
								r	=	0,
								b	=	0,
								a	=	255,
								g	=	0,
									},
								},
							},
						},
				SpecMat	=	{
						},
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
				UseBrake	=	true,
				UseSprite	=	true,
				Pos	=	Vector(5.9200000762939,-118.23000335693,37.75),
				UseDynamic	=	true,
				RenderInner_Size	=	2.5345,
				RenderGlow_Size	=	0,
				BrakeColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	55,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.02,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(-38.200000762939,-110.73000335693,11.390000343323),
					Pos2	=	Vector(-31.329999923706,-115.41000366211,9.3900003433228),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(-37.200000762939,-111.41999816895,9.3900003433228),
					Pos3	=	Vector(-29.450000762939,-116.84999847412,11.390000343323),
						},
				FogColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				SpecMat	=	{
						},
				RenderGlow_Size	=	0,
				RenderInner_Size	=	2.5345,
				UseSprite	=	true,
				Pos	=	Vector(-33.860000610352,-113.79000091553,10.390000343323),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseFog	=	true,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.02,
						},
				SpecSpin	=	{
					Intensity	=	1,
						},
				Spec3D	=	{
					Mat	=	"vcmod/lights/3d/square_texture",
					Pos4	=	Vector(38.200000762939,-110.73000335693,11.390000343323),
					Pos2	=	Vector(31.329999923706,-115.41000366211,9.3900003433228),
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					Use	=	true,
					Pos1	=	Vector(37.200000762939,-111.41999816895,9.3900003433228),
					Pos3	=	Vector(29.450000762939,-116.84999847412,11.390000343323),
						},
				FogColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				SpecMat	=	{
						},
				RenderInner	=	true,
				UseFog	=	true,
				UseSprite	=	true,
				Pos	=	Vector(33.860000610352,-113.79000091553,10.390000343323),
				UseDynamic	=	true,
				RenderInner_Size	=	2.5345,
				RenderGlow_Size	=	0,
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
				RenderInner_Clr	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	0,
						},
				RenderInner_ClrUse	=	true,
					},
				},
		Copyright	=	"Copyright © 2012-2018 VCMod (freemmaann). All Rights Reserved.",
		Fuel	=	{
			FuelType	=	0,
				},
		Author	=	"Azok30 (76561198183398967)",
}