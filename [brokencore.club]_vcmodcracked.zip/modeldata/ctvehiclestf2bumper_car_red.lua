VCModels['models/ctvehiclestf2bumper_car_red.mdl']	=	{
		Light_DD_Int	=	true,
		Date	=	"Sun Aug  1 00:34:38 2021",
		hornData	=	{
			Volume	=	1,
			Distance	=	75,
			Pitch	=	100,
			Sound	=	"vehicles/ctvehicles/tf2_bumper_car/horn.wav",
				},
		NoRadio	=	true,
		em_state	=	5236594947,
		hornUseCustom	=	true,
		Copyright	=	"Copyright © 2021 VCMod (freemmaann). All Rights Reserved.",
		NoDoorSound	=	true,
		DLT	=	3491063298,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				Invulnerable	=	true,
				SpecMat	=	{
					Use	=	true,
					New	=	"models\ctvehicles\tf2\bumper_car\running_red_on",
					Select	=	4,
						},
				UsePrjTex	=	true,
				Pos	=	Vector(6.210000038147,27.360000610352,12),
				UseRunning	=	true,
				RenderHD_Size	=	3.8415,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	36,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.1,
						},
				ProjTexture	=	{
					Size	=	2048,
					Angle	=	Angle(0,90,0),
						},
				Invulnerable	=	true,
				SpecMat	=	{
					Use	=	true,
					New	=	"models\ctvehicles\tf2\bumper_car\running_red_on",
					Select	=	4,
						},
				UseSprite	=	true,
				Pos	=	Vector(-6.210000038147,27.360000610352,12),
				UseRunning	=	true,
				RenderHD_Size	=	3.8415,
				RunningColor	=	{
					r	=	255,
					b	=	0,
					a	=	255,
					g	=	36,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				UsePrjTex	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
				Invulnerable	=	true,
				SpecMat	=	{
					Use	=	true,
					New	=	"models\ctvehicles\tf2\bumper_car\running_red_on",
					Select	=	4,
						},
				UseSprite	=	true,
				Pos	=	Vector(-10.359999656677,-18.360000610352,13.609999656677),
				UseDynamic	=	true,
				RunningColor	=	{
					r	=	204,
					b	=	0,
					a	=	255,
					g	=	44,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.1,
					Brightness	=	2,
						},
				Invulnerable	=	true,
				SpecMat	=	{
					Use	=	true,
					New	=	"models\ctvehicles\tf2\bumper_car\running_red_on",
					Select	=	4,
						},
				UseSprite	=	true,
				Pos	=	Vector(10.359999656677,-18.360000610352,13.609999656677),
				UseDynamic	=	true,
				UseRunning	=	true,
				RunningColor	=	{
					r	=	204,
					b	=	0,
					a	=	255,
					g	=	44,
						},
				SpecModel	=	{
					Color	=	{
						r	=	0,
						b	=	0,
						a	=	255,
						g	=	0,
							},
					scale	=	1,
					scaleVector	=	Vector(1000,1000,1000),
					glow	=	{
						Color	=	{
							r	=	0,
							b	=	0,
							a	=	255,
							g	=	0,
								},
							},
						},
					},
				},
		HealthDisabled	=	true,
		Fuel	=	{
			Disabled	=	true,
			FuelType	=	0,
				},
		Author	=	"󠀡󠀡⁧⁧ 𝓒𝓣𝓥 (76561198051637331)",
}