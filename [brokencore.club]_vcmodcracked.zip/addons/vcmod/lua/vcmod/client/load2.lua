
VC.HornTable = {
    original = {
        Name = "Original"
    },
    light = {
        Name = "Light",
        Sound = "vcmod/horn/light.wav",
        Pitch = 100,
        Volume = 1,
        Level = 85
    },
    heavy = {
        Name = "Heavy",
        Sound = "vcmod/horn/heavy.wav",
        Pitch = 100,
        Volume = 1,
        Level = 85
    },
    general_lee = {
        Name = "General Lee",
        Sound = "vcmod/horn/general_lee.wav",
        Pitch = 100,
        Volume = 1,
        Level = 85
    },
    simple = {
        Name = "Simple",
        Sound = "vcmod/horn/simple.wav",
        Pitch = 100,
        Volume = 1,
        Level = 85
    },
    simple2 = {
        Name = "Simple2",
        Sound = "vcmod/horn/simple2.wav",
        Pitch = 100,
        Volume = 1,
        Level = 85
    },
}

function VC.HandleAudio_VC2(ent, Elec)
end

function VC.getHornSoundData(ent, script)
    local ret = nil
    if not script then script = VC_suckfreemmann(ent) end
    local data = ent:GetNWString("VC_Horn_Custom", "")
    if data ~= "" then
        local data = util.JSONToTable(data)
        ret = {
            Name = data.n,
            Sound = data.s,
            Pitch = data.p or 100,
            Volume = data.v or 1,
            Level = data.l
        }
    else
        if script.hornData then
            ret = script.hornData
        else
            ret = VC.IsBig(ent) and VC.HornTable.heavy or VC.HornTable.light
        end
    end

    if VC.getServerSetting("Enabled_ELS") and VC.getServerSetting("ELS_Sounds") and ((VC.GetState(ent, "ELS_ManualOn") or VC.GetState(ent, "ELS_Snd_Sel", 0) > 0) and not VC.GetState(ent, "ELS_S_Disabled") and script.Siren and script.Siren.Sounds_Horn and script.Siren.Sounds_Horn.Use) and VC.BGroups_Check(ent, "ELS Sound", VC_suckfreemmann(ent).Siren.Sound_BGroups) then
        ent.VC_Horn_EnableELSOnHornEnd = true
        ret = script.Siren.Sounds_Horn
    end
    return ret
end

local function handleHorn(ent, EntLN, Elec)
    if VC.GetState(ent, "HornOn") and Elec and VC.EngineAboveWater(ent) then
        if not ent.VC_Sounds.Horn or not ent.VC_Sounds.Horn:IsPlaying() then
            local script = VC_suckfreemmann(ent)
            local data = VC.getHornSoundData(ent, script)
            if ent.VC_Horn_EnableELSOnHornEnd then
                local hookData = hook.Call("VC_soundEmit_ELS", GAMEMODE, ent, "bullhorn", data)
                if hookData == false then
                    data = nil
                elseif type(hookData) == "table" then
                    data = hookData
                end
            end

            if data then
                ent.VC_HornTable = {
                    Sound = data.Sound or (VC.IsBig(ent) and "vcmod/horn/heavy.wav" or "vcmod/horn/light.wav"),
                    Pitch = data.Pitch or 100,
                    Distance = data.Distance or 85,
                    Volume = (data.Volume or 1) * VC.getServerSetting("Horn_Volume", 1)
                }

                ent.VC_Sounds.Horn = VC.SoundEmit(ent, ent.VC_HornTable.Sound, ent.VC_HornTable.Pitch, ent.VC_HornTable.Distance, ent.VC_HornTable.Volume, nil, true)
                ent.VC_Siren_BullHorn = ent.VC_Horn_EnableELSOnHornEnd and true or false
            end
        end
    elseif ent.VC_Sounds.Horn and ent.VC_Sounds.Horn:IsPlaying() then
        if ent.VC_Horn_EnableELSOnHornEnd then ent.VC_Horn_EnableELSOnHornEnd = nil end
        ent.VC_Sounds.Horn:ChangeVolume(0, 0.01)
        timer.Simple(0.001, function() if IsValid(ent) and ent.VC_Sounds and ent.VC_Sounds.Horn then ent.VC_Sounds.Horn:Stop() end end)
    end
end

function VC.HandleAudio(ent, EntLN)
    local Elec = VC.ElectronicsOn(ent)
    if not ent.VC_Sounds then ent.VC_Sounds = {} end
    if VC.ELS_Audio then VC.ELS_Audio(ent, EntLN, Elec) end
    if VC.handleSurface then VC.handleSurface(ent, EntLN, Elec) end
    handleHorn(ent, EntLN, Elec)
end


net.Receive("VC_SetStateBool", function(len)
    local ent, id, state, snd = net.ReadEntity(), net.ReadString(), net.ReadBool(), net.ReadTable()
    if not snd[1] then snd = nil end
    if IsValid(ent) then VC.SetStateBool(ent, id, state, nil, nil, true, snd) end
end)

net.Receive("VC_SetStateInt", function(len)
    local ent, id, state, snd = net.ReadEntity(), net.ReadString(), net.ReadInt(8), net.ReadTable()
    if not snd[1] then snd = nil end
    if IsValid(ent) then VC.SetStateInt(ent, id, state, nil, nil, true, snd) end
end)

net.Receive("VC_StatesRequestInit", function(len)
    local ent, tbl = net.ReadEntity(), net.ReadTable()
    if IsValid(ent) and tbl then
        ent.VC_States = ent.VC_States or {}
        for k, v in pairs(tbl) do
            if not ent.VC_States[k] then ent.VC_States[k] = v end
        end
    end
end)

concommand.Add("VC_Horn", function(ply, cmd, arg)
    local ent, HA = ply:GetVehicle(), tonumber(arg[1])
    if not HA then HA = 0 end
    if IsValid(ent) and ent.VC_IsNotPrisonerPod then
        local on = VC.GetState(ent, "HornOn")
        if HA == 2 or HA == 0 and on then
            VC.HornOff(ent)
        else
            VC.HornOn(ent)
        end
    end
end)


if not VC.Loaded then VC.Loaded = {} end
local id = "main"
if VC.Loaded[id] then return end
VC.Loaded[id] = CurTime()
VC.Versions.vcmod1 = 1.7892
VCMod1 = VC.Versions.vcmod1
vcmod1 = VC.Versions.vcmod1
VC.AU_CanFuel = true or VC_AU_Ver and VC_AU_Ver_Online and VC_AU_Ver >= 7

VC.StateAdd("RunningLightsOn", "Running", "RunningLightsOn", "RunningLightsOff")
function VC.RunningLightsOn(ent, silent, caller)
    if not VC.getServerSetting("Enabled") or not VC.getSetting("Enabled") then return end
    if VC.getServerSetting("Lights_Running") and not VC.GetState(ent, "RunningLightsOn") and VC_suckfreemmann(ent).LightTable and VC_suckfreemmann(ent).LightTable.Running then
        if hook.Call("VC_canToggleLights", GAMEMODE, ent, "running", false) == false then return end
        local snd = nil
        if not silent then snd = {"c"} end
        VC.SetStateBool(ent, "RunningLightsOn", true, nil, caller, nil, snd)
        if VC.IndicationCheck then VC.IndicationCheck(ent, "lights_running", true) end
        return true
    end
end

function VC.RunningLightsOff(ent, silent, caller)
    if VC.GetState(ent, "RunningLightsOn") then
        if hook.Call("VC_canToggleLights", GAMEMODE, ent, "running", true) == false then return end
        local snd = nil
        if not silent then snd = {"c"} end
        VC.SetStateBool(ent, "RunningLightsOn", false, nil, caller, nil, snd)
        if VC.IndicationCheck then VC.IndicationCheck(ent, "lights_running", false) end
        return true
    end
end

VC.StateAdd("LowBeamsOn", "LBeam", "LowBeamsOn", "LowBeamsOff")
function VC.LowBeamsOn(ent, silent, caller)
    if not VC.getServerSetting("Enabled") or not VC.getSetting("Enabled") then return end
    if VC.getServerSetting("HeadLights") and not VC.GetState(ent, "LowBeamsOn") and VC_suckfreemmann(ent).LightTable and VC_suckfreemmann(ent).LightTable.LBeam then
        if hook.Call("VC_canToggleLights", GAMEMODE, ent, "lowbeam", false) == false then return end
        local snd = nil
        if not silent then snd = {"c"} end
        VC.SetStateBool(ent, "LowBeamsOn", true, nil, caller, nil, snd)
        if VC.IndicationCheck then VC.IndicationCheck(ent, "lights_lowbeams", true) end
        return true
    end
end

function VC.LowBeamsOff(ent, silent, caller)
    if VC.GetState(ent, "LowBeamsOn") then
        if hook.Call("VC_canToggleLights", GAMEMODE, ent, "lowbeam", true) == false then return end
        local snd = nil
        if not silent then snd = {"c"} end
        VC.SetStateBool(ent, "LowBeamsOn", false, nil, caller, nil, snd)
        if VC.IndicationCheck then VC.IndicationCheck(ent, "lights_lowbeams", false) end
        return true
    end
end

VC.StateAdd("HighBeamsOn", "HBeam", "HighBeamsOn", "HighBeamsOff")
function VC.HighBeamsOn(ent, silent, caller)
    if not VC.getServerSetting("Enabled") or not VC.getSetting("Enabled") then return end
    if VC.getServerSetting("HeadLights") and not VC.GetState(ent, "HighBeamsOn") and VC_suckfreemmann(ent).LightTable and VC_suckfreemmann(ent).LightTable.HBeam then
        if hook.Call("VC_canToggleLights", GAMEMODE, ent, "highbeam", false) == false then return end
        local snd = nil
        if not silent then snd = {"c"} end
        VC.SetStateBool(ent, "HighBeamsOn", true, nil, caller, nil, snd)
        if VC.IndicationCheck then VC.IndicationCheck(ent, "lights_highbeams", true) end
        return true
    end
end

function VC.HighBeamsOff(ent, silent, caller)
    if VC.GetState(ent, "HighBeamsOn") then
        if hook.Call("VC_canToggleLights", GAMEMODE, ent, "highbeam", true) == false then return end
        local snd = nil
        if not silent then snd = {"c"} end
        VC.SetStateBool(ent, "HighBeamsOn", false, nil, caller, nil, snd)
        if VC.IndicationCheck then VC.IndicationCheck(ent, "lights_highbeams", false) end
        return true
    end
end

VC.StateAdd("FogLightsOn", "Fog", "FogLightsOn", "FogLightsOff")
function VC.FogLightsOn(ent, silent, caller)
    if not VC.getServerSetting("Enabled") or not VC.getSetting("Enabled") then return end
    if VC.getServerSetting("FogLights") and not VC.GetState(ent, "FogLightsOn") and VC_suckfreemmann(ent).LightTable and VC_suckfreemmann(ent).LightTable.Fog then
        if hook.Call("VC_canToggleLights", GAMEMODE, ent, "fog", false) == false then return end
        local snd = nil
        if not silent then snd = {"c"} end
        VC.SetStateBool(ent, "FogLightsOn", true, nil, caller, nil, snd)
        if VC.IndicationCheck then VC.IndicationCheck(ent, "lights_fog", true) end
        return true
    end
end

function VC.FogLightsOff(ent, silent, caller)
    if VC.GetState(ent, "FogLightsOn") then
        if hook.Call("VC_canToggleLights", GAMEMODE, ent, "fog", true) == false then return end
        local snd = nil
        if not silent then snd = {"c"} end
        VC.SetStateBool(ent, "FogLightsOn", false, nil, caller, nil, snd)
        if VC.IndicationCheck then VC.IndicationCheck(ent, "lights_fog", false) end
        return true
    end
end

VC.StateAdd("HazardLightsOn", "Hazards", "HazardLightsOn", "HazardLightsOff")
function VC.HazardLightsOn(ent, silent, caller)
    if not VC.getServerSetting("Enabled") or not VC.getSetting("Enabled") then return end
    if not VC.GetState(ent, "HazardLightsOn") and VC_suckfreemmann(ent).LightTable and VC_suckfreemmann(ent).LightTable.Blinker then
        if hook.Call("VC_canToggleLights", GAMEMODE, ent, "hazards", false) == false then return end
        ent.VC_TrnLOnT = nil
        ent.VC_TrnLOffT = 0
        ent.VC_TrnROnT = nil
        ent.VC_TrnROffT = 0
        ent.VC_HazardLightsOnT = 0
        ent.VC_HazLOffT = 0
        local snd = nil
        if not silent then snd = {"c"} end
        VC.SetStateBool(ent, "HazardLightsOn", true, nil, caller, nil, snd)
        if VC.IndicationCheck then VC.IndicationCheck(ent, "lights_hazard", true) end
        return true
    end
end

function VC.HazardLightsOff(ent, silent, caller)
    if VC.GetState(ent, "HazardLightsOn") then
        if hook.Call("VC_canToggleLights", GAMEMODE, ent, "hazards", true) == false then return end
        local snd = nil
        if not silent then snd = {"c"} end
        VC.SetStateBool(ent, "HazardLightsOn", false, nil, caller, nil, snd)
        if VC.IndicationCheck then VC.IndicationCheck(ent, "lights_hazard", false) end
        return true
    end
end

VC.StateAdd("TurnLightLeftOn", "BlinkerLeft", "TurnLightLeftOn", "TurnLightLeftOff")
function VC.TurnLightLeftOn(ent, silent, caller)
    if not VC.getServerSetting("Enabled") or not VC.getSetting("Enabled") then return end
    if not VC.GetState(ent, "TurnLightLeftOn") and VC_suckfreemmann(ent).LightTable and VC_suckfreemmann(ent).LightTable.Blinker then
        if hook.Call("VC_canToggleLights", GAMEMODE, ent, "blinkers_left", false) == false then return end
        ent.VC_TrnLOnT = 0
        ent.VC_TrnLOffT = 0
        local snd = nil
        if not silent then snd = {VC.GetState(ent, "TurnLightRightOn") and "vcmod/switch.wav" or "vcmod/switch_on.wav"} end
        VC.TurnLightRightOff(ent, true)
        VC.SetStateBool(ent, "TurnLightLeftOn", true, nil, caller, nil, snd)
        if VC.IndicationCheck then VC.IndicationCheck(ent, "blinkers_left", true) end
        return true
    end
end

function VC.TurnLightLeftOff(ent, silent, caller)
    if VC.GetState(ent, "TurnLightLeftOn") then
        if hook.Call("VC_canToggleLights", GAMEMODE, ent, "blinkers_left", true) == false then return end
        local snd = nil
        if not silent then snd = {"vcmod/switch_off.wav"} end
        VC.SetStateBool(ent, "TurnLightLeftOn", false, nil, caller, nil, snd)
        if VC.IndicationCheck then VC.IndicationCheck(ent, "blinkers_left", false) end
        return true
    end
end

VC.StateAdd("TurnLightRightOn", "BlinkerRight", "TurnLightRightOn", "TurnLightRightOff")
function VC.TurnLightRightOn(ent, silent, caller)
    if not VC.getServerSetting("Enabled") or not VC.getSetting("Enabled") then return end
    if not VC.GetState(ent, "TurnLightRightOn") and VC_suckfreemmann(ent).LightTable and VC_suckfreemmann(ent).LightTable.Blinker then
        if hook.Call("VC_canToggleLights", GAMEMODE, ent, "blinkers_right", false) == false then return end
        ent.VC_TrnLOnT = 0
        ent.VC_TrnLOffT = 0
        local snd = nil
        if not silent then snd = {VC.GetState(ent, "TurnLightLeftOn") and "vcmod/switch.wav" or "vcmod/switch_on.wav"} end
        VC.TurnLightLeftOff(ent, true)
        VC.SetStateBool(ent, "TurnLightRightOn", true, nil, caller, nil, snd)
        if VC.IndicationCheck then VC.IndicationCheck(ent, "blinkers_right", true) end
        return true
    end
end

function VC.TurnLightRightOff(ent, silent, caller)
    if VC.GetState(ent, "TurnLightRightOn") then
        if hook.Call("VC_canToggleLights", GAMEMODE, ent, "blinkers_right", true) == false then return end
        local snd = nil
        if not silent then snd = {"vcmod/switch_off.wav"} end
        VC.SetStateBool(ent, "TurnLightRightOn", false, nil, caller, nil, snd)
        if VC.IndicationCheck then VC.IndicationCheck(ent, "blinkers_right", false) end
        return true
    end
end

VC.StateAdd("CruiseOn", "Cruiser", "CruiseOn", "CruiseOff")
function VC.CruiseOn(ent, silent, caller)
    if not VC.getServerSetting("Enabled") or not VC.getSetting("Enabled") then return end
    if hook.Call("VC_canUseCruiseControl", GAMEMODE, caller, ent) == false then return end
    if VC.ElectronicsOn(ent) and not VC.GetState(ent, "CruiseOn") and ent.VC_IsNotPrisonerPod and VC.getServerSetting("Cruise_Enabled") then
        ent.VC_CruiseVel = ent.VC_Speed_Forward or 0
        if ent.VC_CruiseVel < 50 then ent.VC_CruiseVel = 50 end
        ent:SetNWInt("VC_Cruise_Spd", ent.VC_CruiseVel)
        local snd = nil
        if not silent then snd = {"c"} end
        VC.SetStateBool(ent, "CruiseOn", true, nil, caller, nil, snd)
        if VC.IndicationCheck then VC.IndicationCheck(ent, "cruise", true) end
        return true
    end
end

function VC.CruiseOff(ent, silent, caller)
    if VC.GetState(ent, "CruiseOn") then
        ent.VC_CruiseVel = nil
        ent:SetNWInt("VC_Cruise_Spd", 0)
        local snd = nil
        if not silent then snd = {"c"} end
        VC.SetStateBool(ent, "CruiseOn", false, nil, caller, nil, snd)
        if VC.IndicationCheck then VC.IndicationCheck(ent, "cruise", false) end
        return true
    end
end

function VC.HeadLightsOn(ent, silent, caller)
    VC.LowBeamsOn(ent, silent, caller)
end

function VC.HeadLightsOff(ent, silent, caller)
    VC.LowBeamsOff(ent, silent, caller)
    VC.HighBeamsOff(ent, silent, caller)
end

function VC.HL_HighBeam_On(ent, silent, caller)
    VC.HighBeamsOn(ent, silent, caller)
end

function VC.HL_HighBeam_Off(ent, silent, caller)
    VC.HighBeamsOff(ent, silent, caller)
end


local data = {
    cmd = "vc_hazards_onoff",
    menu = "controls",
    keyhold = true,
    info = "HazardLights",
    default = {
        key = "MOUSE_MIDDLE",
        hold = "0",
        mouse = "1"
    }
}

VC.controlInsert(data)
local data = {
    cmd = "vc_blinker_left",
    menu = "controls",
    keyhold = true,
    info = "BlinkerLeft",
    default = {
        key = "MOUSE_LEFT",
        hold = "0",
        mouse = "1"
    }
}

VC.controlInsert(data)
local data = {
    cmd = "vc_blinker_right",
    menu = "controls",
    keyhold = true,
    info = "BlinkerRight",
    default = {
        key = "MOUSE_RIGHT",
        hold = "0",
        mouse = "1"
    }
}

VC.controlInsert(data)
local data = {
    cmd = "vc_lights_switch",
    menu = "controls",
    info = "LightsSwitch",
    default = {
        key = "KEY_F",
        hold = "0"
    }
}

VC.controlInsert(data)
local data = {
    cmd = "vc_foglights_onoff",
    menu = "controls",
    keyhold = true,
    info = "FogLights",
    default = {
        key = "KEY_F",
        hold = "0"
    }
}

VC.controlInsert(data)
local data = {
    cmd = "vc_highbeams_toggle",
    menu = "controls",
    keyhold = false,
    info = "HighBeams",
    default = {
        key = "KEY_F",
        hold = "1"
    }
}

VC.controlInsert(data)
local data = {
    cmd = "vc_highbeams",
    menu = "controls",
    NoCheckBox = true,
    carg1 = "1",
    carg2 = "2",
    info = "HighBeamsFlash",
    default = {
        key = "KEY_H",
        hold = "1"
    }
}

VC.controlInsert(data)
local data = {
    cmd = "vc_cruise_onoff",
    menu = "controls",
    info = "Cruise",
    default = {
        key = "KEY_B",
        hold = "0"
    }
}

VC.controlInsert(data)
local data = {
    cmd = "vc_trailer_detach",
    menu = "controls",
    info = "DetachTrailer",
    default = {
        key = "KEY_B",
        hold = "1"
    }
}

VC.controlInsert(data)
local data = {
    cmd = "vc_viewlookbehind",
    menu = "controls",
    NoCheckBox = true,
    carg1 = "1",
    carg2 = "2",
    info = "LookBehind",
    default = {
        key = "MOUSE_MIDDLE",
        hold = "1",
        mouse = "1"
    },
    desk = "Look behind the vehicle."
}

VC.controlInsert(data)
local data = {
    cmd = "vc_inside_doors_onoff",
    menu = "controls",
    info = "LockUnlock",
    keyhold = true,
    default = {
        key = "KEY_N",
        hold = "0"
    },
    desk = "Lock the vehicle from within."
}

VC.controlInsert(data)
local data = {
    cmd = "vc_drivebymode_toggle",
    menu = "controls",
    info = "DriveBy",
    default = {
        key = "KEY_SPACE",
        hold = "0"
    },
    desk = "Toggle drive by shooting mode from passenger seats."
}

VC.controlInsert(data)
function VC.isFuelConsumptionEnabled(ent)
    return not ent:GetNWBool("VC_FuelDisabled", false)
end

function VC.isTrailer(ent)
    return ent.VC_isTrailer
end

function VC.isTrailerSupported(ent)
    return VC_suckfreemmann(ent).UseSocket and VC_suckfreemmann(ent).SocketPos
end

function VC.getTrailer(ent)
    local ret = nil
    local time = nil
    local trailer = SERVER and ent.VC_HookVeh or ent:GetNWEntity("VC_HookedVh")
    if IsValid(trailer) then
        ret = trailer
        time = SERVER and trailer.VC_HookedVhAtcT or trailer:GetNWInt("VC_HookedVhAtcT") or 0
    end

    if not IsValid(ret) then
        ret = nil
        time = nil
    end
    return ret, time
end

function VC.getAttachedTo(ent)
    local ret = nil
    local time = nil
    local trailer = SERVER and ent.VC_SocketVeh or ent:GetNWEntity("VC_SocketVeh")
    if IsValid(trailer) then
        ret = trailer
        time = SERVER and ent.VC_HookedVhAtcT or ent:GetNWInt("VC_HookedVhAtcT") or 0
    end

    if not IsValid(ret) then
        ret = nil
        time = nil
    end
    return ret, time
end

function VC.CD_getInfo(ent)
    if ent:GetClass() == "vc_npc_cardealer" then
        local name = ent:GetNWString("VC_Name", VC.CD.Default.Name)
        local model = ent:GetModel()
        local id = ent:GetNWInt("VC_Int", 0)
        local data = ent.VC_Options or {}
        return id, name, model, data
    end
end

function VC.RM_getInfo(ent)
    if ent:GetClass() == "vc_npc_repair" then
        local name = ent:GetNWString("VC_Name", VC.CD.Default.Name)
        local model = ent:GetModel()
        local id = ent:GetNWInt("VC_Int", 0)
        local data = ent.VC_Options or {}
        return id, name, model, data
    end
end

function VC.getCruise(ent)
    local ret = nil
    if VC.GetState(ent, "CruiseOn") then ret = ent:GetNWInt("VC_Cruise_Spd", 0) end
    return ret
end

VC.DriveByRestrictedWeapons = {"vc_wrench", "vc_jerrycan", "vc_spikestrip_wep", "weapon_crossbow", "weapon_frag", "weapon_slam", "weapon_physcannon", "weapon_rpg", "weapon_crowbar", "weapon_gravgun", "weapon_physgun", "weapon_bugbait", "door_ram", "weapon_stunstick", "gmod_tool"}
VC.FuelTypes = {
    [0] = {
        name = "Petrol",
        shrt = "95",
        mult = 0,
        clr = Color(25, 155, 45, 250),
        mdl = "models/props_junk/metalgascan.mdl"
    },
    [1] = {
        name = "Diesel",
        shrt = "D",
        mult = 0.77,
        clr = Color(55, 100, 255, 250),
        mdl = "models/props_junk/gascan001a.mdl"
    },
    [2] = {
        name = "Electricity",
        shrt = "Elec",
        mult = 0.2,
        clr = Color(55, 200, 55, 250),
        mdl = "models/items/car_battery01.mdl"
    },
}

if CLIENT then
    function VC.GetPartIcon(obj)
        local icon = nil
        if obj == "engine" then
            icon = VC.Material.icon_engine
        elseif obj == "light" then
            icon = VC.Material.icon_running
        elseif obj == "light_els" then
            icon = VC.Material.icon_els
        elseif obj == "wheel" then
            icon = VC.Material.icon_wheel
        elseif obj == "exhaust" then
            icon = VC.Material.icon_exhaust
        end
        return icon
    end
end

function VC.GetPartInfo(obj, byHand)
    local datatbl = VC.Settings
    if CLIENT then datatbl = VC.ServerSettings end
    local repMult = byHand and datatbl.Damage_Repair_TimeMult or datatbl.RM_RepairSpeedMult or 1
    local info = {
        price = 0,
        time = 0
    }

    if obj == "engine" then
        info.price = datatbl.RM_Price_Engine or 500
        info.time = 75 * repMult
    elseif obj == "light" then
        info.price = datatbl.RM_Price_Light or 10
        info.time = 10 * repMult
    elseif obj == "light_els" then
        info.price = datatbl.RM_Price_Light or 10
        info.time = 10 * repMult
    elseif obj == "wheel" then
        info.price = datatbl.RM_Price_Tire or 20
        info.time = 5 * repMult
    elseif obj == "exhaust" then
        info.price = datatbl.RM_Price_Exhaust or 50
        info.time = 15 * repMult
    end
    return info
end

VC.CD.Default = {
    Model = "models/barney.mdl",
    Name = "Car Dealer",
    Pos = Vector(0, 0, 0),
    Ang = Angle(0, 0, 0),
    Platforms = {},
    Vehicles = {}
}

VC.RM.Default = {
    Model = "models/barney.mdl",
    Name = "Vehicle Repair Man",
    Pos = Vector(0, 0, 0),
    Ang = Angle(0, 0, 0)
}

function VC.CD.GetDataFromName(ID)
    local tbl = string.Explode("$$$_VC_$$$", ID)
    return {
        Model = tbl[1],
        Name = tbl[2],
        Skin = tbl[2]
    }
end

function VC.CD.getName(mdl, nm, skin)
    return (mdl or "") .. "$$$_VC_$$$" .. (nm or "Unknown") .. "$$$_VC_$$$" .. (skin or "0")
end

function VC.CD.getVehicleDataFromID(ID)
    local data = VC.CD.GetDataFromName(ID)
    return data.Model or "", data.Model or "Unknown", data.Skin or "0"
end

local function getLightPos(ent, int)
    local pos = Vector(0, 0, 0)
    local OD = VC_suckfreemmann(ent)
    if SERVER then
        if OD.Lights and OD.Lights[int] then pos = VC_freemannmegaobosr(ent, OD.Lights[int]) end
    else
        pos = OD.LPT and OD.LPT[int] and OD.LPT[int].Pos
    end
    return pos or Vector(0, 0, 0)
end

local function getExhaustPos(ent, int)
    local pos = nil
    local OD = VC_suckfreemmann(ent)
    if SERVER then
        pos = OD[int] and OD.Exhaust[int].Pos
    else
        pos = OD.Exhaust and OD.Exhaust[int] and OD.Exhaust[int].Pos
    end
    return pos or Vector(0, 0, 0)
end

function VC.GetWheelPos(ent, int)
    local pos = ent:GetPos()
    local has = nil
    if type(int) == "number" then int = VC.Wheels[int] end
    local atc = ent:LookupAttachment(int)
    if atc ~= 0 then
        has = true
        pos = ent:GetAttachment(atc).Pos
    end
    return pos, has
end

function VC.GetObjectPos(ent, part, int, kkl)
    if not kkl or kkl ~= 137 then return end
    local pos = Vector(0, 0, 0)
    if part == "engine" then
        pos = ent:WorldToLocal(VC.getEnginePos(ent))
    elseif part == "wheel" then
        pos = ent:WorldToLocal(VC.GetWheelPos(ent, int))
    elseif part == "light" then
        pos = getLightPos(ent, int)
    elseif part == "exhaust" then
        pos = getExhaustPos(ent, int)
    end
    return pos or Vector(0, 0, 0)
end

local function CheckTables(tbl, job, rank)
    local restjob, restrank = tbl and tbl.JobRestrict and job and tbl.JobRestrict[job], tbl and tbl.RankRestrict and rank and tbl.RankRestrict[rank]
    if restjob then
        return "job"
    elseif restrank then
        return "rank"
    end
end

function VC.isPlayerRestricted(ply, tbl_veh, tbl_npc, dontprint)
    local rank = ply:GetUserGroup()
    local JobName = ply.getJobTable and ply:getJobTable() and ply:getJobTable().name or "Unknown"
    local isRestrictedVeh, isRestrictedNPC = CheckTables(tbl_veh, JobName, rank), CheckTables(tbl_npc, JobName, rank)
    local isRestricted = nil
    if isRestrictedNPC then
        isRestricted = {
            type = "npc",
            restriction = isRestrictedNPC
        }
    elseif isRestrictedVeh then
        isRestricted = {
            type = "veh",
            restriction = isRestrictedVeh
        }
    end

    if isRestricted and not dontprint then
        if SERVER then
            VCMsg("Access restricted", ply)
        else
            VCPopup(VC.Lng("AccessRestricted") .. " " .. (isRestricted.type == "npc" and VC.Lng("CantBeUsedBy") or VC.Lng("CantBeSpawnedBy")) .. (isRestricted.restriction == "rank" and (' "' .. rank .. '"') or ' "' .. JobName .. '"') .. ".", "cross", 8)
        end
    end
    return isRestricted
end

function VC.CD.GetSpawnPosAng(ply, tbl, ent)
    local pos, ang = nil, nil
    if tbl.Platforms and table.Count(tbl.Platforms) > 0 then
        for k, v in pairs(tbl.Platforms) do
            local ar, af, au = v.Ang:Right() * 142, v.Ang:Forward() * 71, v.Ang:Up() * 50
            if not util.TraceLine({
                start = v.Pos + ar + af,
                endpos = v.Pos - ar - af + au
            }).Hit and not util.TraceLine({
                start = v.Pos - ar + af + au,
                endpos = v.Pos + ar - af
            }).Hit then
                pos = v.Pos + Vector(0, 0, 10)
                ang = v.Ang
                break
            end
        end
    else
        local tang = (ply:GetPos() - ent:GetPos()):Angle()
        tang.p = 0
        pos = ent:GetPos() + Vector(0, 0, 10) - tang:Right() * 150
        ang = tang - Angle(0, 90, 0)
    end
    return pos, ang
end

function VC.CD.getVehicleIDFromData(mdl, name, skin)
    return VC.CD.getName(mdl, name, skin)
end

function VC.CD.getVehicleID(ent)
    local mdl, name, skin = VC.GetModel(ent), VC.getName(ent, "Unknown"), ent:GetSkin()
    return VC.CD.getName(mdl, name, skin)
end


game.AddParticles("particles/vc_explosion.pcf")
game.AddParticles("particles/vc_damage.pcf")
game.AddParticles("particles/vc_surface.pcf")
game.AddParticles("particles/vc_exhaust.pcf")
PrecacheParticleSystem("VC_WheelSparks")
PrecacheParticleSystem("VC_Wheel_Fix")
PrecacheParticleSystem("VC_WheelDust")
PrecacheParticleSystem("VC_Wheel_Deflate")
PrecacheParticleSystem("VC_WheelSmoke_Asphalt")
PrecacheParticleSystem("VC_Wheelsmoke_Dirt_Burnout_Debris")
PrecacheParticleSystem("VC_WheelSmoke_Sand_2")
PrecacheParticleSystem("VC_Wheelsmoke_BurnoutLeft")
PrecacheParticleSystem("VC_Wheelsmoke_Dirt_Burnout")
PrecacheParticleSystem("VC_WheelSmoke_Sand")
PrecacheParticleSystem("VC_BackFire")
PrecacheParticleSystem("VC_BackFire_Sparks")
PrecacheParticleSystem("VC_Crash")
PrecacheParticleSystem("VC_Crash_Sparks")
PrecacheParticleSystem("VC_Crash_Sparklies")
PrecacheParticleSystem("VC_Engine_Fire")
PrecacheParticleSystem("VC_Engine_Smoke")
PrecacheParticleSystem("VC_Engine_Fire_Sparks_B")
PrecacheParticleSystem("Car_Explosion")
PrecacheParticleSystem("VC_Glass_Fix")
PrecacheParticleSystem("VC_Glass_Light")
PrecacheParticleSystem("VC_Exhaust")
PrecacheParticleSystem("VC_Exhaust_Stress")
PrecacheParticleSystem("VC_Exhaust_Truck")
PrecacheParticleSystem("VC_Exhaust_Truck_Stress")
local dir = "vcmod/collision/spring/"
for k, v in pairs(file.Find("sound/" .. dir .. "*", "GAME")) do
    util.PrecacheSound("sound/" .. dir .. v)
end

local dir = "vcmod/collision/light/"
for k, v in pairs(file.Find("sound/" .. dir .. "*", "GAME")) do
    util.PrecacheSound("sound/" .. dir .. v)
end

local dir = "vcmod/collision/medium/"
for k, v in pairs(file.Find("sound/" .. dir .. "*", "GAME")) do
    util.PrecacheSound("sound/" .. dir .. v)
end

local dir = "vcmod/collision/heavy/"
for k, v in pairs(file.Find("sound/" .. dir .. "*", "GAME")) do
    util.PrecacheSound("sound/" .. dir .. v)
end


local settings = {
    Wheel_Lock = true,
    Brake_Lock = true,
    Door_Sounds = true,
    Truck_BackUp_Sounds = true,
    Exit_Velocity = true,
    Exit_Velocity_Damage = true,
    Exit_NoCollision = true,
    Exhaust_Effect = true,
    Exhaust_Effect_BackFireHealthLow = true,
    Passenger_Seats = true,
    ExitPoint_OverrideDriver = true,
    Seat_Switch = true,
    Lock_From_Inside = true,
    DriveBy = true,
    DriveBy_NoSwitch = false,
    RepairTool_Speed_M = 1,
    Lights_Running = true,
    Lights_HandBrake = false,
    Lights_Interior = true,
    Lights_Blinker_OffOnExit = false,
    HeadLights = true,
    LightsOffTime = 300,
    HLightsOffTime = 60,
    HLights_Dist_M = 0.5,
    FogLights = true,
    FogLightsOffTime = 30,
    FogLights_Dist_M = 0.5,
    Cruise_Enabled = true,
    Cruise_OffOnExit = true,
    UnlockVehicleOnSpawnerUsePostLock = true,
    CD_Enabled = true,
    CD_ReturnLimitByDistance = true,
    CD_ReturnLimitByDistanceDist = 1000,
    CD_EnterVehicleOnSpawn = false,
    CD_AutoReturnOnDisconnect = false,
    CD_TowingTooFar = false,
    CD_TowingTooFar_Distance = 1500,
    CD_Towing = true,
    CD_OnlyAllowOne = false,
    CD_TowingPrice = 1500,
    CD_Distance = 1500,
    CD_RefundPrice = 75,
    CD_Remove = true,
    CD_Remove_Time = 1000,
    CD_Veh_RemTool = false,
    CD_Hum = true,
    CD_Persistent = true,
    CD_StoreInfo = true,
    CD_TestDrive = true,
    CD_TestDriveTime = 30,
    CD_Text_Dist = 500,
    CD_UnlockVehicleOnSpawnerUse = true,
    TP_Override = false,
    RM_Enabled = true,
    RM_Text_Dist = 500,
    RM_Persistent = true,
    RM_Hum = true,
    RM_RepairSpeedMult = 1,
    RM_Distance = 350,
    RM_Repair_Time_Cost = 1,
    RM_Price_Engine = 500,
    RM_Price_Light = 10,
    RM_Price_Tire = 20,
    RM_Price_Exhaust = 50,
    Fuel = true,
    Fuel_Pickup_Touch = false,
    Fuel_Pickup_Touch_Elec = true,
    Fuel_Pickup_Explode = true,
    Fuel_Pickup_Pickup = true,
    Fuel_Persistent = true,
    Fuel_lidNeedUnlocked = true,
    Fuel_Pickups_Beside_Stations = true,
    Fuel_Cons_Mult = 1,
    Refuel_Mult_Station = 1,
    Fuel_StartMult = 1,
    Refuel_MaxCapacity = 100,
    Refuel_Mult_Hand = 1,
    Fuel_PPL_0 = 1.3,
    Fuel_PPL_1 = 1.01,
    Fuel_PPL_2 = 0.29,
    Trl_Enabled = true,
    Trl_Dist = 200,
    Trl_Strength = 1,
    Trl_Enabled_Reg = true,
    TP_Props = true,
    Indication = true,
    Damage = true,
    Damage_Phys_MinVel = 75,
    Sound_Damage_Custom = true,
    Damage_explosion_drain_fuel = true,
    Damage_FuelLid = true,
    Damage_FuelLid_Explode = true,
    Damage_FuelLid_DrainFuel = true,
    Damage_Lights = true,
    Damage_Wheels = true,
    Damage_Wheels_ELSOff = false,
    Damage_Exhaust = true,
    Damage_Exhaust_Backfire = true,
    Damage_Explode = true,
    Damage_CanEnterIfDestroyed = true,
    Damage_Repair_GiveWrenchToDriver = true,
    Damage_Repair_GiveWrenchToCarPartUser = true,
    Damage_Repair_NeedPart = true,
    Damage_Repair_TimeMult = 1,
    Damage_Expl_Rem = true,
    Damage_Ignite = true,
    Damage_Expl_Rem_Time = 400,
    Dmg_Fire_Duration = 30,
    Dmg_Smoke_Duration = 15,
    SpikeStrip_auto_give_els = false,
    SpikeStrip_damage_players = true,
    SpikeStrip_Ignore_ELS = false,
    SpikeStrip_auto_remove_death = true,
    HealthRepairBulletDamage = true,
    PhysicalDamage = true,
    PhysicalDamage_PlyDmgMult = 1,
    PhysicalDamage_PlyDisable = true,
    PhysicalDamageWPhysGun = true,
    OnlyWithPassengers = false,
    PhysicalDamage_Mult = 1,
    Health_Multiplier = 1,
    CarsCantDamagePlayers = false,
    ShootPlayers = true,
    ShootPlayers_Prec_Mult = 1,
    ShootPlayers_OverrideDefault = true,
    Effect_Repair = true,
    Effect_Light = true,
    Effect_Light_Damaged = true,
    Effect_Wheel = true,
    Effect_Exhaust = true,
    Effect_Damage_Sparks = true,
    Effect_Explosion_Custom = true,
    Effect_Exhaust_Custom = true,
    Effect_Slide = true,
    Tiretracks = true,
    Compat_CH_Fire_System = true,
}

VC.SettingsAdd(settings, true)

local settings = {
    HUD_Height = 35,
    HUD_Name = true,
    HUD_Name_Height = 0.75,
    HUD_PickUp = true,
    HUD_Health = true,
    HUD_Health_Adv = true,
    HUD_Fuel = true,
    HUD_FuelLidPosition = true,
    HUD_DriveBy = true,
    HUD_Icons = true,
    HUD_Cruise = true,
    HUD_MPh = false,
    TireTracks_Enabled = true,
    TireTracks_Dist = 4000,
    TireTracks_FadeOutTime = 4,
    TireTracks_Detail = 50,
    TireTracks_Sparks = true,
    Surface_Enabled = true,
    Surface_Normal = true,
    Surface_Brakes = true,
    Surface_Brakes_Audio = true,
    Surface_Sparks = true,
    Surface_Sparks_Audio = true,
    ThirdPerson_Use = true,
    ThirdPerson_Dynamic = true,
    ThirdPerson_Auto = true,
    ThirdPerson_Vec_Stf = 100,
    ThirdPerson_Ang_Stf = 15,
    ThirdPerson_Auto_Pitch = 5,
    ThirdPerson_Ang_Pitch = true,
    ThirdPerson_Auto_Back = true,
    ThirdPerson_Switch = false,
    ThirdPerson_Cam_Trl = true,
    ThirdPerson_Speed = true,
    ThirdPerson_Hight_Auto = true,
    ThirdPerson_Type = 1,
    Anim_PassengerLegBending = true,
    Anim_OverrieDriverAnimPos = true,
}

VC.SettingsAdd(settings)
local function DamagedObject_light_categorize(ent, int, state)
    local OD = VC_suckfreemmann(ent)
    if OD.LPT and OD.LPT[int] and ent.VC_DamagedObjects then
        if OD.LPT[int].els then
            if state then
                if not ent.VC_DamagedObjects then ent.VC_DamagedObjects = {} end
                if not ent.VC_DamagedObjects.L_ELS then ent.VC_DamagedObjects.L_ELS = 0 end
                ent.VC_DamagedObjects.L_ELS = ent.VC_DamagedObjects.L_ELS + 1
            elseif ent.VC_DamagedObjects.L_ELS then
                ent.VC_DamagedObjects.L_ELS = ent.VC_DamagedObjects.L_ELS - 1
                if ent.VC_DamagedObjects.L_ELS <= 0 then ent.VC_DamagedObjects.L_ELS = nil end
                if table.Count(ent.VC_DamagedObjects) == 0 then ent.VC_DamagedObjects = nil end
            end
        else
            local pos = OD.LPT[int].Pos
            local pint = 1
            if pos.x < 0 then
                if pos.y < 0 then pint = 3 end
            else
                if pos.y < 0 then
                    pint = 4
                else
                    pint = 2
                end
            end

            if state then
                if not ent.VC_DamagedObjects then ent.VC_DamagedObjects = {} end
                if not ent.VC_DamagedObjects.LPT then ent.VC_DamagedObjects.LPT = {} end
                ent.VC_DamagedObjects.LPT[pint] = (ent.VC_DamagedObjects.LPT[pint] or 0) + 1
            elseif ent.VC_DamagedObjects.LPT and ent.VC_DamagedObjects.LPT[pint] then
                ent.VC_DamagedObjects.LPT[pint] = ent.VC_DamagedObjects.LPT[pint] - 1
                if ent.VC_DamagedObjects.LPT[pint] <= 0 then ent.VC_DamagedObjects.LPT[pint] = nil end
                if table.Count(ent.VC_DamagedObjects.LPT) <= 0 then ent.VC_DamagedObjects.LPT = nil end
                if table.Count(ent.VC_DamagedObjects) == 0 then ent.VC_DamagedObjects = nil end
            end
        end
    end
end

function VC.handleSurface(ent, EntLN, Elec)
    if ent.VC_WheelSparkTable and table.Count(ent.VC_WheelSparkTable) > 0 and VC.getSetting("Surface_Sparks_Audio") then
        if not ent.VC_Sounds.WheelGrind then ent.VC_Sounds.WheelGrind = VC.SoundEmit(ent, "vcmod/surface_grind.wav", 100, 70, 0, nil, true) end
        local Vel = ent.VC_InBurnout and ent.VC_RPM / ent.VC_Engine.RPM_Max / 1000 or (ent.VC_VelLength - 100)
        ent.VC_Sounds.WheelGrind:ChangePitch(100 + Vel / 100, 0, 25, 0)
        ent.VC_Sounds.WheelGrind:ChangeVolume(math.Clamp(0.2 + math.Clamp(Vel / 500, 0, 0.3 + table.Count(ent.VC_WheelSparkTable) / 2.8) * 0.8, 0, 1), 0)
    elseif ent.VC_Sounds.WheelGrind then
        ent.VC_Sounds.WheelGrind:FadeOut(0.1)
        ent.VC_Sounds.WheelGrind = nil
    end

    if VC.getSetting("Surface_Brakes_Audio") then
        if ent.VC_SurfaceData and ent.VC_SurfaceData.onAsphalt and (ent.VC_WheelBrakeDustTable and table.Count(ent.VC_WheelBrakeDustTable) > 0 or ent.VC_BurnoutDustTable and table.Count(ent.VC_BurnoutDustTable) > 0) then
            if not ent.VC_Sounds.WheelBrake_Asphalt then ent.VC_Sounds.WheelBrake_Asphalt = VC.SoundEmit(ent, "vcmod/surface_asphalt.wav", 100, 95, 0, nil, true) end
            local Vel = (ent.VC_BurnoutDustTable and table.Count(ent.VC_BurnoutDustTable) > 0 and ent.VC_RPM / 7 or ent.VC_VelLength) - 100
            ent.VC_Sounds.WheelBrake_Asphalt:ChangePitch(95 + math.Clamp(Vel / 80, 0, 50), 0)
            ent.VC_Sounds.WheelBrake_Asphalt:ChangeVolume(math.Clamp(math.Clamp(Vel / 250, 0, 1), 0, 1), 0.1)
        elseif ent.VC_Sounds.WheelBrake_Asphalt then
            ent.VC_Sounds.WheelBrake_Asphalt:FadeOut(0.2)
            ent.VC_Sounds.WheelBrake_Asphalt = nil
        end

        if ent.VC_SurfaceData and ent.VC_SurfaceData.onNotAsphalt and (ent.VC_WheelBrakeDustTable and table.Count(ent.VC_WheelBrakeDustTable) > 0) then
            if not ent.VC_Sounds.WheelBrake_NotAsphalt then ent.VC_Sounds.WheelBrake_NotAsphalt = VC.SoundEmit(ent, "vcmod/surface_dirt.wav", 100, 100, 0, nil, true) end
            local Vel = (ent.VC_BurnoutDustTable and table.Count(ent.VC_BurnoutDustTable) > 0 and ent.VC_RPM / 7 or ent.VC_VelLength) - 100
            ent.VC_Sounds.WheelBrake_NotAsphalt:ChangePitch(100 + math.Clamp(Vel / 50, 0, 30), 0)
            ent.VC_Sounds.WheelBrake_NotAsphalt:ChangeVolume(math.Clamp(math.Clamp(Vel / 250, 0, 1), 0, 1), 0.1)
        elseif ent.VC_Sounds.WheelBrake_NotAsphalt then
            ent.VC_Sounds.WheelBrake_NotAsphalt:FadeOut(0.1)
            ent.VC_Sounds.WheelBrake_NotAsphalt = nil
        end
    end
end

local function AddNewDamagedObject(ent, object, int, state)
    if not object or not int then return end
    if state then
        if hook.Call("VC_CanDamagePart", GAMEMODE, ent, object, int) == false or hook.Call("VC_canDamagePart", GAMEMODE, ent, object, int) == false then return end
        if not ent.VC_DamagedObjects then ent.VC_DamagedObjects = {} end
        if not ent.VC_DamagedObjects[object] then ent.VC_DamagedObjects[object] = {} end
        if not ent.VC_DamagedObjects[object][int] then ent.VC_DamagedObjects[object][int] = true end
        hook.Call("VC_PartDamaged", GAMEMODE, ent, obj, int)
        hook.Call("VC_partDamaged", GAMEMODE, ent, obj, int)
    else
        if ent.VC_DamagedObjects and VC.ObjectIsDamaged(ent, object, int) then
            ent.VC_DamagedObjects[object][int] = nil
            if table.Count(ent.VC_DamagedObjects[object]) == 0 then ent.VC_DamagedObjects[object] = nil end
            if table.Count(ent.VC_DamagedObjects) == 0 then ent.VC_DamagedObjects = nil end
            hook.Call("VC_PartRepaired", GAMEMODE, ent, object, int)
        end
    end

    if object == "light" then DamagedObject_light_categorize(ent, int, state) end
end

net.Receive("VC_SendToClient_DmgObjState_All", function(len)
    local ent, tbl = net.ReadEntity(), net.ReadTable()
    if not IsValid(ent) then return end
    if table.Count(tbl) == 0 then
        ent.VC_DamagedObjects = nil
    else
        for k, v in pairs(tbl) do
            for k2, v2 in pairs(v) do
                AddNewDamagedObject(ent, k, k2, true)
            end
        end

        ent.VC_DamageObjectsForceReceived = true
    end
end)

net.Receive("VC_SendToClient_DmgObjState", function(len)
    local ent, object, int, state = net.ReadEntity(), net.ReadString(), net.ReadInt(16), net.ReadBool()
    if not IsValid(ent) then return end
    AddNewDamagedObject(ent, object, int, state)
end)

concommand.Add("vc_viewlookbehind", function(ply, cmd, arg)
    local HA = tonumber(arg[1])
    if HA == 1 and not VC.View_LookingBehind then
        VC.View_LookingBehind = true
    elseif HA == 2 and VC.View_LookingBehind then
        VC.View_LookingBehind = false
    end
end)

function VC.Handle_Input_VC1(ply, ent, Veh, IsNotPod, VSC)
    if VSC and not vgui.CursorVisible() then
        if not ply.VC_UpKeysPressTime or CurTime() >= ply.VC_UpKeysPressTime then
            if input.IsKeyDown(KEY_LALT) and not ent.VC_ExtraSeat then
                for i = 1, 10 do
                    local Ib = i == 10 and 0 or i
                    if input.IsKeyDown(_G["KEY_" .. Ib]) then
                        RunConsoleCommand("VC_ClearSeat", Ib)
                        ply.VC_UpKeysPressTime = CurTime() + 0.2
                    end
                end
            else
                for i = 1, 10 do
                    local Ib = i == 10 and 0 or i
                    if input.IsKeyDown(_G["KEY_" .. Ib]) then
                        if Ib > 0 then
                            RunConsoleCommand("VC_Switch_Seats_" .. Ib)
                        else
                            RunConsoleCommand("VC_Switch_Seats")
                        end

                        ply.VC_UpKeysPressTime = CurTime() + 0.2
                    end
                end
            end
        end
    end
end

function VC.LitersToGallons(num)
    return num * 0.264
end

function VC.LitersToKwH(num)
    return num * 1.7
end

function VC.LiterToAuto(num, ftype, am)
    if not am then am = 10 end
    if ftype == 2 then
        num = VC.LitersToKwH(num)
    else
        if VC.getSetting("HUD_MPh") then num = VC.LitersToGallons(num) end
    end
    return math.ceil(num * am) / am
end

function VC.TextToAuto_s(ftype)
    local text = ""
    if ftype == 2 then
        text = VC.Lng("kWh")
    else
        if VC.getSetting("HUD_MPh") then
            text = VC.Lng("g_gallons")
        else
            text = VC.Lng("g_liters")
        end
    end
    return text
end

function VC.TextToAuto(ftype)
    local text = ""
    if ftype == 2 then
        text = VC.Lng("kWh")
    else
        if VC.getSetting("HUD_MPh") then
            text = VC.Lng("gallons")
        else
            text = VC.Lng("liters")
        end
    end
    return text
end


local View_Auto_InOutInt = 0
local function View_Handle_Auto(ply, ent, Veh, IsNotPod, VSC, pos, ang, fov, CursorVis, View)
    local LookBehind = VC.View_LookingBehind and not vgui.CursorVisible()
    if LookBehind then VC.View_Auto_LastLookBehind = CurTime() + 0.5 end
    local LookBehindRev = nil
    if VC.View_Auto_LastLookBehind and CurTime() < VC.View_Auto_LastLookBehind then
        LookBehindRev = true
    else
        VC.View_Auto_LastLookBehind = nil
    end

    if LookBehind or LookBehindRev or not CursorVis and (VC.getSetting("ThirdPerson_Auto") and VC.IsThirdPerson and VC.getSetting("ThirdPerson_Ang_Stf") > 0 or VC.getSetting("FirstPerson_Auto") and not VC.IsThirdPerson and VC.getSetting("FirstPerson_Ang_Stf") > 0 and not ply.VC_InGunMode) and not Veh.VC_IsAirboat and CurTime() >= (ply.VC_View_LastMouseMovedTime or (CurTime() + 1)) + (VC.velAvg:Length() >= 50 and 1.5 or ply.VC_LEAACR) then
        local LBP = nil
        if not VC.IsThirdPerson then
            LBP = Veh:WorldToLocal(ply:EyePos()).x > 5 and -105 or -75
        else
            LBP = -90
        end

        local FAng = (VC.IsThirdPerson and VC.getSetting("ThirdPerson_Auto_Back") or not VC.IsThirdPerson and VC.getSetting("FirstPerson_Auto_Back")) and Veh == ent and (LookBehind or LookBehindRev or VCMod2 and (Veh:GetNWInt("VC_Throttle", 0) == 0 or Veh:GetNWInt("VC_Gear", 0) < 0) or input.IsKeyDown(KEY_S)) and (VC.velAvg:Dot(Veh:GetRight()) > 150 or LookBehind) and LBP or 90
        if not VC.AngleInBounds(0.1, ply.VC_View_Angle_Real or ply:EyeAngles(), Angle(VC.IsThirdPerson and VC.getSetting("ThirdPerson_Auto_Pitch", 0), FAng, 0)) then
            local AVel = math.Clamp(VC.velAvg:Length() / (FAng > 0 and (VC.IsThirdPerson and 25000 or 22000) or (VC.IsThirdPerson and 13000 or 10000)), 0, 0.0775)
            if ply.VC_APLBP and ply.VC_APLBP ~= FAng then View_Auto_InOutInt = 0 end
            ply.VC_APLBP = FAng
            if View_Auto_InOutInt < 1 then View_Auto_InOutInt = View_Auto_InOutInt + 0.005 + AVel * VC.FTm() end
            if View_Auto_InOutInt > 1 then View_Auto_InOutInt = 1 end
            local CAng = LerpAngle(((LookBehind or LookBehindRev) and 0.1 or (0.003 + AVel) * View_Auto_InOutInt) * VC.FTm(), ply.VC_View_Angle_Real, (Veh:GetAngles() - ent:GetAngles()) + Angle(VC.IsThirdPerson and VC.getSetting("ThirdPerson_Auto_Pitch", 0), FAng, 0))
            local PAng = ply:EyeAngles() - (ply.VC_View_Angle_Real - CAng)
            ply:SetEyeAngles(Angle(PAng.p, PAng.y, ply:EyeAngles().r))
            ply.VC_View_Angle_Real = Angle(CAng.p, CAng.y, ply:EyeAngles().r)
            ply.VC_View_Angle_Simulated = ply:EyeAngles()
            ply.VC_View_LastMouseMovedTime = 1
        else
            View_Auto_InOutInt = 0
        end
    else
        View_Auto_InOutInt = 0
    end
    return View
end

local function View_Handle_Mouse_Movement(ply, ent, Veh, IsNotPod, VSC, pos, ang, fov, CursorVis, View)
    local MMvd = false
    if not ply.VC_View_Angle_Simulated or not VC.AngleInBounds(0.0001, ply.VC_View_Angle_Simulated, ply:EyeAngles()) then
        ply.VC_View_Angle_Real = (ply.VC_View_Angle_Real or ply:EyeAngles()) + (ply:EyeAngles() - (ply.VC_View_Angle_Simulated or ply:EyeAngles()))
        ply.VC_View_Angle_Simulated = ply.VC_View_Angle_Real
        MMvd = true
    end

    if MMvd or not CursorVis and (input.IsMouseDown(MOUSE_LEFT) or input.IsMouseDown(MOUSE_RIGHT) or VC.View_LookingBehind) then
        ply.VC_View_LastMouseMovedTime = CurTime()
        ply.VC_LEAACR = math.random(4.5, 6)
    end
    return MMvd
end

local function View_Handle_TP_Hight_Auto(ply, ent, Veh, IsNotPod, VSC, pos, ang, fov, CursorVis, View, Fltr, APos, APVD)
    local Int = 1
    if VC.getSetting("ThirdPerson_Hight_Auto") then
        local CVel = VC.velAvg:Length()
        CVel = (CVel - 150) * 0.04
        if CVel < 0 then CVel = 0 end
        if CVel > 20 then CVel = 20 end
        ply.VC_ViewTP_UpL = Lerp(0.02 * VC.FTm(), ply.VC_ViewTP_UpL or CVel, CVel)
        Int = ply.VC_ViewTP_UpL
        if not IsNotPod and VSC then Int = Int + 100 end
    end
    return Int
end

local function View_Handle_TP_Hight_Auto_Speed(ply, ent, Veh, IsNotPod, VSC, pos, ang, fov, CursorVis, View, Fltr, APos, APVD, HMlt)
    if VC.getSetting("ThirdPerson_Speed") then
        APos = APos + ang:Up() * (15 + HMlt)
        APos = APos - ang:Forward() * (15 + HMlt)
    end
    return APos
end

local function View_Handle_TP_Trailer(ply, ent, Veh, IsNotPod, VSC, pos, ang, fov, CursorVis, View, Fltr, APos, APVD)
    local trailer = Veh:GetNWEntity("VC_HookedVh")
    if not IsValid(trailer) then trailer = nil end
    if VC.getSetting("ThirdPerson_Cam_Trl") and trailer then
        if not Veh.VC_TrlVwMult or Veh.VC_TrlVwMult < 1 then Veh.VC_TrlVwMult = math.Round(((Veh.VC_TrlVwMult or 0) + 0.01 * VC.FTm()) * 100) / 100 end
    elseif Veh.VC_TrlVwMult then
        if Veh.VC_TrlVwMult > 0 then
            Veh.VC_TrlVwMult = math.Round((Veh.VC_TrlVwMult - 0.01 * VC.FTm()) * 100) / 100
        else
            Veh.VC_TrlVwMult = nil
        end
    end

    if Veh.VC_TrlVwMult then
        if trailer then
            ply.VC_TrlAPos = trailer:LocalToWorld(trailer:OBBCenter()) + Veh:GetUp() * 60
            ply.VC_TrlAPVD = math.Max(100, trailer:BoundingRadius())
        end

        local VwMul = (math.sin(math.pi * (Veh.VC_TrlVwMult - 0.5)) + 1) / 2
        if ply.VC_TrlAPos then APos = LerpVector(VwMul, APos, (APos + ply.VC_TrlAPos) / 2) end
        if ply.VC_TrlAPVD then APVD = APVD + ply.VC_TrlAPVD * VwMul end
        Fltr = {Veh, trailer}
    end
    return {
        APos = APos,
        APVD = APVD,
        Fltr = Fltr
    }
end

VC.velAvgData = nil
VC.velAvgCounter = 1
VC.velAvg = Vector(0, 0, 0)
function VC.calculateVelAvr(ent)
    local velNew = 0
    if IsValid(ent) then
        local vel = ent:GetVelocity()
        if not VC.velAvgData then
            VC.velAvgCounter = 1
            VC.velAvgData = {}
            VC.velAvgData[2] = vel
            VC.velAvgData[3] = vel
            VC.velAvgData[4] = vel
            VC.velAvgData[5] = vel
            VC.velAvgData[6] = vel
            VC.velAvgData[7] = vel
        end

        VC.velAvgData[VC.velAvgCounter] = vel
        if VC.velAvgCounter > 7 then
            VC.velAvgCounter = 1
        else
            VC.velAvgCounter = VC.velAvgCounter + 1
        end

        velNew = (VC.velAvgData[1] + VC.velAvgData[2] + VC.velAvgData[3] + VC.velAvgData[4] + VC.velAvgData[5] + VC.velAvgData[6] + VC.velAvgData[7]) / 7
    end

    VC.velAvg = velNew
end

local function View_Handle_TP_Dyn(ply, ent, Veh, IsNotPod, VSC, pos, ang, fov, CursorVis, View, Fltr, APos, APVD)
    if VC.getSetting("ThirdPerson_Dynamic") then
        if VC.getSetting("ThirdPerson_Ang_Stf") < 100 then
            local angLocal = ply:EyeAngles()
            angLocal.r = 0
            ent:WorldToLocalAngles(angLocal)
            ply:SetEyeAngles(angLocal)
            ply.VC_CCAng = Veh:GetAngles()
            ply.VC_View_Angle_Simulated = angLocal
        elseif ply.VC_CCAng then
            ply:SetEyeAngles(ply.VC_View_Angle_Real or ply:EyeAngles())
            ply.VC_CCAng = nil
        end

        if not ply.VC_ThrdP then
            ply.VC_TPVDC = APVD * 1.03
            ply.VC_ThrdP = true
        elseif ply.VC_ThrdP and not VC.IsThirdPerson then
            ply.VC_ThrdP = false
        end
    else
        if ply.VC_CCAng then
            ply:SetEyeAngles(ply.VC_View_Angle_Real or ply:EyeAngles())
            ply.VC_CCAng = nil
        end

        ply.VC_CnstVV = nil
    end

    if VC.getSetting("ThirdPerson_Type") == 1 then
        local VelMeasure = VC.velAvg - (VC.View_TP_LastVelMeasure or VC.velAvg)
        VC.View_TP_LastVel = LerpVector(0.15, VC.View_TP_LastVel or VelMeasure, VelMeasure)
        VC.View_TP_LastVelMeasure = VC.velAvg
        VC.View_TP_LastVel_Lerp = LerpVector(0.2, VC.View_TP_LastVel_Lerp or VC.View_TP_LastVel, VC.View_TP_LastVel)
        APos = APos + VC.View_TP_LastVel_Lerp
        ply.VC_CnstVV = APos
    elseif VC.getSetting("ThirdPerson_Type") == 2 then
        APos = LerpVector(math.Clamp(VC.getSetting("ThirdPerson_Vec_Stf") * 0.005 * VC.FTm(), 0, 1), ply.VC_CnstVV or APos, APos)
        if VC.getSetting("ThirdPerson_Vec_Stf") < 100 then
            ply.VC_CnstVV = APos
        else
            ply.VC_CnstVV = nil
        end
    end
    return {
        APos = APos,
        APVD = APVD,
        Fltr = Fltr
    }
end

local function View_ThirdPerson(ply, ent, Veh, IsNotPod, VSC, pos, ang, fov, CursorVis, View)
    if not VC.getSetting("ThirdPerson_Use") or not IsValid(Veh) then return View end
    View = {}
    local MMvd = View_Handle_Mouse_Movement(ply, ent, Veh, IsNotPod, VSC, pos, ang, fov, CursorVis, View)
    View = View_Handle_Auto(ply, ent, Veh, IsNotPod, VSC, pos, ang, fov, CursorVis, View)
    local Fltr, APos, APVD = {Veh, ply}, VC.OBBToWorld(Veh) + ang:Up(), Veh.VC_View_TP_Radius or 250
    local HMlt = View_Handle_TP_Hight_Auto(ply, ent, Veh, IsNotPod, VSC, pos, ang, fov, CursorVis, View, Fltr, APos, APVD)
    APos = View_Handle_TP_Hight_Auto_Speed(ply, ent, Veh, IsNotPod, VSC, pos, ang, fov, CursorVis, View, Fltr, APos, APVD, HMlt)
    local Data = View_Handle_TP_Trailer(ply, ent, Veh, IsNotPod, VSC, pos, ang, fov, CursorVis, View, Fltr, APos, APVD)
    Fltr = Data.Fltr
    APos = Data.APos
    APVD = Data.APVD
    APVD = APVD * (VC.View_TP_CamZoomLevel or 1)
    if ent.VC_IsPrisonerPod and not ent.VC_ExtraSeat then APVD = APVD / 2 end
    local Data = View_Handle_TP_Dyn(ply, ent, Veh, IsNotPod, VSC, pos, ang, fov, CursorVis, View, Fltr, APos, APVD)
    Fltr = Data.Fltr
    APos = Data.APos
    APVD = Data.APVD
    ply.VC_TPVDC = ply.VC_TPVDC or APVD
    if ply.VC_TPVDC > APVD + 0.05 or ply.VC_TPVDC < APVD - 0.05 then ply.VC_TPVDC = Lerp(0.04 * VC.FTm(), ply.VC_TPVDC, APVD) end
    local trctbl = {
        start = APos,
        endpos = APos + ang:Forward() * -ply.VC_TPVDC,
        filter = Fltr
    }

    if VC.getServerSetting("TP_Props") then trctbl.mask = MASK_NPCWORLDSTATIC end
    local TTTr = util.TraceLine(trctbl)
    View.origin = TTTr.HitPos + TTTr.HitNormal * (3 + ply.VC_TPVDC / 600)
    return View
end

local function View_Outside(ply, ent, Veh, IsNotPod, VSC, pos, ang, fov, CursorVis, View)
    return View
end

local function endViewThirdPerson(ply)
    local ang = ply:EyeAngles()
    ply:SetEyeAngles(Angle(ang.p, ang.y, 0))
    ply.VC_CCAng = nil
    ply.VC_View_Angle_Real = nil
    ply.VC_View_Angle_Simulated = nil
    ply.VC_CnstVV = nil
    ply.VC_TPVDC = nil
    ply.VC_TrlAPos = nil
    ply.VC_TrlAPVD = nil
end

function VC.HandleView(ply, ent, Veh, IsNotPod, VSC, pos, ang, fov)
    VC.calculateVelAvr(Veh)
    local View = nil
    local CursorVis = vgui.CursorVisible()
    local IsViewerSelf = VC.CheckViewerIsSelf()
    if VSC then
        if VC.Handle_View_Cinematic and IsViewerSelf and VC.Cinematic_View and not VC.isMidEnterExit(ply) then
            View = VC.Handle_View_Cinematic(ply, ent, Veh, IsNotPod, VSC, pos, ang, fov)
        else
            if ply.VC_Cin_CurMode then
                VC.CinModes[ply.VC_Cin_CurMode].End(ply, Veh)
                ply.VC_Cin_CurMode = nil
                ply.VC_Cin_ChangeTime = nil
                ply.VC_Cin_CurTime = nil
            end

            local lastRanMode = VC.View_LastRanMode
            if VC.IsThirdPerson then
                VC.TP_Ran = true
                View = View_ThirdPerson(ply, ent, Veh, IsNotPod, VSC, pos, ang, fov, CursorVis, View)
                VC.View_LastRanMode = "TP"
            else
                if VC.TP_Ran then
                    endViewThirdPerson(ply)
                    VC.TP_Ran = nil
                end

                if IsViewerSelf then
                    View = {}
                    View.origin = pos
                    if VC.View_FirstPerson then View = VC.View_FirstPerson(ply, ent, Veh, IsNotPod, VSC, pos, ang, fov, CursorVis, View) end
                    VC.View_LastRanMode = "FP"
                else
                    View = View_Outside(ply, ent, Veh, IsNotPod, VSC, pos, ang, fov, CursorVis, View)
                    VC.View_LastRanMode = "Other"
                end
            end

            if lastRanMode ~= VC.View_LastRanMode then VC.ViewChanged() end
        end
    end
    return View
end

hook.Add("ShouldDrawLocalPlayer", "VC_ShouldDrawLocalPlayer", function(ply)
    if not VC.getSetting("Enabled") then return end
    local ent = ply:GetVehicle()
    if IsValid(ent) and VC.isVCModCompatible(ent) and VC.isThirdPerson(ent) then return true end
end)


VC.DrawFT["Icons"] = function(ply, CARot, ent, DrvV, Veh, Sart_Height, Lrp, SrnTbl)
    local on = ent and Veh == ent
    local data = on and VC_suckfreemmann(ent)
    on = on and data and data.HUD_CanDisplay
    local anim = VC.UI_AnimData("Icons", on, 0.02 + Lrp / VC.AnimCT, 0.01 + Lrp / VC.AnimCT)
    local anim_trailer = VC.UI_AnimData("Icons_Trailer", anim and Veh and IsValid(Veh:GetNWEntity("VC_HookedVh")) and anim == 1, 0.05, 0.02)
    local MainSz = 38
    local Temp_Sart_Height = Sart_Height + 3
    if anim then
        local Rat_L = anim * 2
        if Rat_L > 1 then Rat_L = 1 end
        local Rat_B = anim * 3
        if Rat_B > 1 then Rat_B = 1 end
        local Rat_T = anim * 2 - 1
        if Rat_T < 0 then Rat_T = 0 end
        local Extra_Trl = anim_trailer and (anim_trailer * 3) * 40 or 0
        if Extra_Trl < 0 then Extra_Trl = 0 end
        if Extra_Trl > 40 then Extra_Trl = 40 end
        VC.HUD_DrawBG(Rat_B, ScrW() - Extra_Trl - 170 + CARot[1], Sart_Height + CARot[2], 220 - CARot[1], MainSz)
        local CanBlink, CanRunning, CanFog, CanHead = nil, nil, nil, nil
        if Veh and data then
            local LhtTbl = data.LightTable
            if LhtTbl then
                CanBlink = LhtTbl.Blinker
                CanRunning = LhtTbl.Running
                CanFog = LhtTbl.Fog
                CanHead = LhtTbl.Head or LhtTbl.HBeam or LhtTbl.LBeam
            end
        end

        local clr_off = VC.ColorCopyAlpha(VC.Color.Base, 255 * Rat_T)
        local clr_on = Color(100, 255, 55, 255 * Rat_T)
        local PY = Temp_Sart_Height + CARot[2]
        local iconSize = 8
        if anim_trailer then
            local Rat_L = anim_trailer * 2
            if Rat_L > 1 then Rat_L = 1 end
            local Rat_BT = anim_trailer * 3
            if Rat_BT > 1 then Rat_BT = 1 end
            local Rat_TT = anim_trailer * 2 - 1
            if Rat_TT < 0 then Rat_TT = 0 end
            surface.SetDrawColor(100, 255, 55, 255 * Rat_TT)
            surface.SetMaterial(VC.Material.icon_trailer)
            surface.DrawTexturedRect(math.Round(ScrW() - 200 + CARot[1] - iconSize / 2), math.Round(Sart_Height + CARot[2] + 8 - iconSize / 2), 20 + iconSize, 20 + iconSize)
        end

        local amount = 0
        if CanBlink then amount = amount + 2 end
        if CanRunning then amount = amount + 1 end
        if CanFog then amount = amount + 1 end
        if CanHead then amount = amount + 1 end
        if anim or amount > 0 or anim_trailer then
            local num = 160
            local amount_ran = 0
            if amount < 3 then
                num = num / (amount + 1) + 10
            else
                num = num / amount
            end

            local BL = Veh and Veh:GetNWBool("VC_Lights_BlinkerLeft_Created", false)
            local BR = Veh and Veh:GetNWBool("VC_Lights_BlinkerRight_Created", false)
            local HB = Veh and VC.GetState(Veh, "HighBeamsOn")
            local LB = Veh and VC.GetState(Veh, "LowBeamsOn")
            local Run = Veh and VC.GetState(Veh, "RunningLightsOn")
            local Haz = Veh and Veh:GetNWBool("VC_Lights_Hazards_Created", false)
            local Fog = Veh and VC.GetState(Veh, "FogLightsOn")
            if CanBlink then
                if Veh and BL or Haz then
                    surface.SetDrawColor(clr_on)
                else
                    surface.SetDrawColor(clr_off)
                end

                surface.SetMaterial(VC.Material.icon_blinker_left)
                surface.DrawTexturedRect(math.Round(ScrW() - 160 + CARot[1]) - iconSize / 2, math.Round(PY + 3) - iconSize / 2, 20 + iconSize, 20 + iconSize)
                amount_ran = amount_ran + 1
            end

            if CanHead then
                surface.SetDrawColor(clr_off)
                surface.SetMaterial(VC.Material.icon_lowbeams)
                if Veh and (HB or LB) then
                    if HB then
                        surface.SetMaterial(VC.Material.icon_highbeams)
                        surface.SetDrawColor(1, 255, 255, 255 * Rat_T)
                    else
                        surface.SetDrawColor(clr_on)
                    end
                end

                surface.DrawTexturedRect(math.Round(ScrW() - num * (amount - amount_ran) + CARot[1]) - iconSize / 2, math.Round(Temp_Sart_Height + CARot[2] + 3) - iconSize / 2, 20 + iconSize, 20 + iconSize)
                amount_ran = amount_ran + 1
            end

            if CanRunning then
                if Veh and Run then
                    surface.SetDrawColor(clr_on)
                else
                    surface.SetDrawColor(clr_off)
                end

                surface.SetMaterial(VC.Material.icon_running)
                surface.DrawTexturedRect(math.Round(ScrW() - num * (amount - amount_ran) + CARot[1]) - iconSize / 2, math.Round(Temp_Sart_Height + CARot[2] + 3) - iconSize / 2, 20 + iconSize, 20 + iconSize)
                amount_ran = amount_ran + 1
            end

            if CanFog then
                if Veh and Fog then
                    surface.SetDrawColor(255, 200, 0, 255 * Rat_T)
                else
                    surface.SetDrawColor(clr_off)
                end

                surface.SetMaterial(VC.Material.icon_fog)
                surface.DrawTexturedRect(math.Round(ScrW() - num * (amount - amount_ran) + CARot[1]) - iconSize / 2, math.Round(Temp_Sart_Height + CARot[2] + 3) - iconSize / 2, 20 + iconSize, 20 + iconSize)
                amount_ran = amount_ran + 1
            end

            if CanBlink then
                if Veh and BR or Haz then
                    surface.SetDrawColor(clr_on)
                else
                    surface.SetDrawColor(clr_off)
                end

                surface.SetMaterial(VC.Material.icon_blinker_right)
                surface.DrawTexturedRect(math.Round(ScrW() - num * (amount - amount_ran) + CARot[1]) - iconSize / 2, math.Round(Temp_Sart_Height + CARot[2] + 3) - iconSize / 2, 20 + iconSize, 20 + iconSize)
                amount_ran = amount_ran + 1
            end

            local Trl = (anim_trailer or 0) * 40
            local Clr = clr_off
            if Veh and (BL or BR or Hd or Run or Haz or Fog) then Clr = clr_on end
            draw.RoundedBox(0, math.Round(ScrW() - 165 * Rat_L + CARot[1] - Trl), math.Round(Sart_Height + 30 + CARot[2]), 170 - CARot[1] + Trl, 2, Clr)
        end

        if anim then Sart_Height = Sart_Height + MainSz + 2 end
    end
    return Sart_Height
end

VC.Material.TopDown = Material("vcmod/car_topdown.png")
VC.DrawFT["Health"] = function(ply, CARot, ent, DrvV, Veh, Sart_Height, Lrp, SrnTbl)
    local on = ent and Veh == ent and VC.getServerSetting("Damage") and ent.VC_isSupported and not ent:GetNWBool("VC_HealthDisabled", false)
    local anim = VC.UI_AnimData("Health", on, 0.02 + Lrp / VC.AnimCT, 0.01 + Lrp / VC.AnimCT)
    local anim_adv = VC.UI_AnimData("Health_Adv", anim and anim == 1, 0.03, 0.02) or 0
    local MainSz = 32
    if anim then
        local Rat_Adv_L = anim_adv * 2
        if Rat_Adv_L > 1 then Rat_Adv_L = 1 end
        local Rat_Adv_T = anim_adv * 2 - 1
        if Rat_Adv_T < 0 then Rat_Adv_T = 0 end
        local advon = VC.getSetting("HUD_Health_Adv")
        if anim_adv > 0 and advon then MainSz = MainSz + 70 * (Rat_Adv_L or 0) end
        local Rat_L = anim * 2
        if Rat_L > 1 then Rat_L = 1 end
        local Rat_B = anim * 3
        if Rat_B > 1 then Rat_B = 1 end
        local Rat_T = anim * 2 - 1
        if Rat_T < 0 then Rat_T = 0 end
        local Num = ent and ent:GetNWInt("VC_HealthPerc", 1) or 1
        if not VC.Last_Health then VC.Last_Health = {} end
        if on then VC.Last_Health.Perc = Num end
        local warning = nil
        if VC.Last_Health.Perc <= 0 then warning = Color(255, 0, 0, (math.sin(CurTime() * 20) + 1) * 25.5 * Rat_T) end
        VC.HUD_DrawBG(Rat_B, ScrW() - 170 + CARot[1], Sart_Height + CARot[2], 180 - CARot[1], MainSz, nil, warning)
        draw.SimpleText(VC.Lng("Health"), "VC_Regular2", math.Round(ScrW() - 160 + CARot[1]), math.Round(Sart_Height + 22 + CARot[2]), Color(255, 255, 255, 255 * Rat_T), TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
        draw.SimpleText(math.ceil(VC.Last_Health.Perc * 100) .. "%", "VC_Regular2", math.Round(ScrW() - 20 + CARot[1]), math.Round(Sart_Height + 22 + CARot[2]), Color(255 - 155 * VC.Last_Health.Perc, 100 + 155 * VC.Last_Health.Perc, 55, 255 * Rat_T), TEXT_ALIGN_RIGHT, TEXT_ALIGN_BOTTOM)
        local Clr = Color(100, 255, 55, 255)
        if VC.Last_Health.Perc < 0.4 then
            if VC.Last_Health.Perc < 0.125 then
                if math.sin(CurTime() * 30) > 0 then Clr = Color(255, 55, 55, 255) end
            else
                Clr = Color(255, 155, 0, 255)
            end
        end

        draw.RoundedBox(0, math.Round(ScrW() - 165 * Rat_L + CARot[1]), math.Round(Sart_Height + 24 + CARot[2]), 170 - CARot[1], 2, Clr)
        if advon then
            local tpx = math.Round(ScrW() - 165 + CARot[1])
            local tpy = math.Round(Sart_Height + 32 + CARot[2])
            surface.SetDrawColor(255, 255, 255, 120 * Rat_Adv_T)
            surface.SetMaterial(VC.Material.TopDown)
            surface.DrawTexturedRect(tpx, tpy, 160, 65)
            surface.SetDrawColor(255, 0, 0, 255 * Rat_T)
            local wplx = math.Round(ScrW() - 138 + CARot[1])
            local wpty = math.Round(Sart_Height + 35 + CARot[2])
            if VC.Last_Health.Perc < 0.4 then
                local szx, szy = 25, 30
                if VC.Last_Health.Perc < 0.125 then
                    draw.RoundedBox(4, wplx + szx / 2 - 20, wpty + szy / 2 - 1, szx, szy, Color(255, 0, 0, (math.sin(CurTime() * 20) * 127.5 + 127.5) * Rat_Adv_T))
                else
                    draw.RoundedBox(4, wplx + szx / 2 - 20, wpty + szy / 2 - 1, szx, szy, Color(255, 155, 0, (math.sin(CurTime() * 5) * 50 + 205) * Rat_Adv_T))
                end
            end

            if ent and ent.VC_DamagedObjects then
                local wheel_sin = (math.sin(CurTime() * 10) * 75 + 170) * Rat_Adv_T
                if ent.VC_DamagedObjects.wheel then
                    if ent.VC_DamagedObjects.wheel[1] then draw.RoundedBox(4, wplx, wpty + 49, 24, 10, Color(255, 0, 0, wheel_sin)) end
                    if ent.VC_DamagedObjects.wheel[2] then draw.RoundedBox(4, wplx, wpty, 24, 10, Color(255, 0, 0, wheel_sin)) end
                    if ent.VC_DamagedObjects.wheel[3] then draw.RoundedBox(4, wplx + 83, wpty + 49, 24, 10, Color(255, 0, 0, wheel_sin)) end
                    if ent.VC_DamagedObjects.wheel[4] then draw.RoundedBox(4, wplx + 83, wpty, 24, 10, Color(255, 0, 0, wheel_sin)) end
                end

                if ent.VC_DamagedObjects.LPT then
                    surface.SetDrawColor(255, 0, 0, wheel_sin)
                    surface.SetMaterial(VC.Material.Circle_32)
                    if ent.VC_DamagedObjects.LPT[1] then
                        surface.DrawTexturedRect(wplx - 18, wpty + 42, 15, 15)
                        draw.SimpleText(ent.VC_DamagedObjects.LPT[1], "VC_Regular2", wplx - 11, wpty + 49, Color(255, 255, 255, wheel_sin), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                    end

                    if ent.VC_DamagedObjects.LPT[2] then
                        surface.DrawTexturedRect(wplx - 18, wpty + 2, 15, 15)
                        draw.SimpleText(ent.VC_DamagedObjects.LPT[2], "VC_Regular2", wplx - 11, wpty + 9, Color(255, 255, 255, wheel_sin), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                    end

                    if ent.VC_DamagedObjects.LPT[3] then
                        surface.DrawTexturedRect(wplx + 110, wpty + 42, 15, 15)
                        draw.SimpleText(ent.VC_DamagedObjects.LPT[3], "VC_Regular2", wplx + 118, wpty + 49, Color(255, 255, 255, wheel_sin), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                    end

                    if ent.VC_DamagedObjects.LPT[4] then
                        surface.DrawTexturedRect(wplx + 110, wpty + 2, 15, 15)
                        draw.SimpleText(ent.VC_DamagedObjects.LPT[4], "VC_Regular2", wplx + 118, wpty + 9, Color(255, 255, 255, wheel_sin), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                    end
                end

                if ent.VC_DamagedObjects.L_ELS then
                    draw.RoundedBox(2, wplx + 49, wpty + 12, 13, 35, Color(255, 0, 0, wheel_sin))
                    draw.SimpleText(ent.VC_DamagedObjects.L_ELS, "VC_Regular2", wplx + 55, wpty + 30, Color(255, 255, 255, wheel_sin), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                end

                if ent.VC_DamagedObjects.exhaust then
                    surface.SetDrawColor(255, 0, 0, wheel_sin)
                    surface.SetMaterial(VC.Material.Circle_32)
                    surface.DrawTexturedRect(wplx + 120, wpty + 35, 10, 10)
                end
            end
        end
    end

    if anim then Sart_Height = Sart_Height + MainSz + 2 end
    return Sart_Height
end

net.Receive("VC_Fuel_Update_Cons", function(len)
    VC.FuelCons = net.ReadInt(16) / 10
    if VC.FuelCons < 0 then VC.FuelCons = 0 end
end)

VC.DrawFT["Fuel"] = function(ply, CARot, ent, DrvV, Veh, Sart_Height, Lrp, SrnTbl)
    if not VC.getServerSetting("Fuel") then return Sart_Height end
    if Veh ~= ent then ent = nil end
    local on = ent and VC.isFuelConsumptionEnabled(ent) and ent.VC_isSupported and not ent:GetNWBool("VC_Fuel_Disabled", false)
    local anim = VC.UI_AnimData("Fuel", on, 0.02 + Lrp / VC.AnimCT, 0.01 + Lrp / VC.AnimCT)
    local MainSz = 52
    if anim then
        local Rat_L = anim * 2
        if Rat_L > 1 then Rat_L = 1 end
        local Rat_B = anim * 3
        if Rat_B > 1 then Rat_B = 1 end
        local Rat_T = anim * 2 - 1
        if Rat_T < 0 then Rat_T = 0 end
        local Max = ent and VC.getFuelMax(ent, 0) or VC.Fuel_Last.Max
        local Cur = ent and VC.getFuel(ent, 0) or VC.Fuel_Last.Cur
        if not VC.Fuel_Last then VC.Fuel_Last = {} end
        VC.Fuel_Last.Max = Max
        VC.Fuel_Last.Cur = Cur
        local Num = Cur / Max
        local inwarning = Num < 0.25
        local isout = Num <= 0
        local warning = nil
        if isout then warning = Color(255, 255, 255, (math.sin(CurTime() * 20) + 1) * 55.5 * Rat_T) end
        VC.HUD_DrawBG(Rat_B, ScrW() - 170 + CARot[1], Sart_Height + CARot[2], 180 - CARot[1], MainSz, nil, warning)
        local ftype = ent and ent:GetNWInt("VC_FuelType", 0) or VC.Fuel_Last.ftype or 0
        VC.Fuel_Last.ftype = ftype
        draw.SimpleText(ftype == 2 and VC.Lng(VC.FuelTypes[ftype].shrt) or VC.Lng(VC.FuelTypes[ftype].name), "VC_Regular2", math.Round(ScrW() - 160 + CARot[1]), math.Round(Sart_Height + 22 + CARot[2]), Color(255, 255, 255, 255 * Rat_T), TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
        local Clr = Color(100, 255, 55, 255)
        if inwarning then if isout or math.sin(CurTime() * (30 - 20 * Num * 4)) > 0 then Clr = Color(255, 255, 255, 255) end end
        local text = math.ceil(VC.LiterToAuto(Cur, ftype)) .. "/" .. VC.LiterToAuto(Max, ftype, 1) .. " " .. VC.TextToAuto_s(ftype)
        if Num < 0 then Num = 0 end
        if Max == 0 then Num = 1 end
        draw.SimpleText(text, "VC_Regular2", math.Round(ScrW() - 20 + CARot[1]), math.Round(Sart_Height + 22 + CARot[2]), Color(Clr.r, Clr.g, Clr.b, 255 * Rat_T), TEXT_ALIGN_RIGHT, TEXT_ALIGN_BOTTOM)
        local cons = VC.FuelCons or 0
        local perc = 0
        if cons > 5 then
            if cons < 100 then
                perc = math.abs(cons - 5, 0, cons) / 95
            else
                perc = 1
            end
        end

        draw.SimpleText(VC.LiterToAuto(cons, ftype) .. " " .. VC.TextToAuto_s(ftype) .. "/" .. VC.Lng("hour"), "VC_Regular2", math.Round(ScrW() - 20 + CARot[1]), math.Round(Sart_Height + 22 + 25 + CARot[2]), Color(100 + 155 * perc, 255 - 155 * perc, 55, 155 * Rat_T), TEXT_ALIGN_RIGHT, TEXT_ALIGN_BOTTOM)
        draw.RoundedBox(0, math.Round(ScrW() - 165 * Rat_L + CARot[1]), math.Round(Sart_Height + 24 + CARot[2]), 170 - CARot[1], 2, Clr)
    end

    if anim then Sart_Height = Sart_Height + MainSz + 2 end
    return Sart_Height
end

VC.DrawFT["DriveBy"] = function(ply, CARot, ent, DrvV, GVeh, Sart_Height, Lrp, SrnTbl)
    if VC.getServerSetting("DriveBy") then
        local dbent = nil
        local indriveby = nil
        local ent = ply:GetVehicle()
        if not IsValid(ent) then
            ent = nil
        else
            dbent = ent:GetNWEntity("VC_InDriveByMode")
            indriveby = IsValid(dbent) and dbent ~= ent
        end

        local Wep = ply:GetActiveWeapon()
        if not IsValid(Wep) then Wep = nil end
        local on = VC.CheckViewerIsSelf() and VC.getSetting("HUD_DriveBy") and ent and ent:GetNWBool("VC_CanDriveBy", false) and Wep and (Wep:GetClass() ~= "vc_wrench") and (math.abs(ent:GetParent():WorldToLocal(ent:GetPos()).x) > 10 or ent:GetNWInt("VC_Key", 0) == 1)
        local anim = VC.UI_AnimData("DriveBy", on, 0.02 + Lrp / VC.AnimCT, 0.01 + Lrp / VC.AnimCT)
        if anim then
            local Ctrl = VC.Controls_List and VC.Controls_List["vc_drivebymode_toggle"]
            local control = nil
            if Ctrl and Ctrl.key then control = VC.KBK[Ctrl.key] or VC.KBK_Mouse[Ctrl.key] end
            if not control or not control.name then
                control = string.gsub(Ctrl and Ctrl.key or "None", "KEY_", "")
            else
                control = control and control.name or "None"
            end

            if indriveby then
                if not ply.VC_DriveByKDV or ply.VC_DriveByKDV < 1 then ply.VC_DriveByKDV = math.Round(((ply.VC_DriveByKDV or 0) + 0.1) * 100) / 100 end
                CCVel = -ent:GetVelocity():Dot(ent:GetRight())
            elseif ply.VC_DriveByKDV then
                if ply.VC_DriveByKDV > 0 then ply.VC_DriveByKDV = math.Round((ply.VC_DriveByKDV - 0.1) * 100) / 100 end
            end

            local Sx = math.Round(ScrW() / 2 - (300 / 2) * anim + CARot[1])
            local Sy = math.Round(ScrH() / 1.1 + (20 + (15 - anim * 15) + CARot[2]))
            local sizeextra = 50 + 60 * (ply.VC_DriveByKDV or 0)
            local int = ply.VC_DriveByKDV or 0
            local sizex = (300 + sizeextra) * anim
            VC.DrawFadeRect(Sx - sizeextra / 2, Sy - 30, sizex, 35)
            draw.RoundedBox(0, Sx - sizeextra / 2, Sy, sizex, 2, Color(0, 255 - 100 * int, 100 + 155 * int, 255 * anim))
            if not VC.Fonts["VC_DriveBy"] then
                VC.Fonts["VC_DriveBy"] = true
                surface.CreateFont("VC_DriveBy", {
                    font = "MenuLarge",
                    size = 20,
                    weight = 1000,
                    blursize = 0,
                    scanlines = 0,
                    antialias = true,
                    underline = false,
                    italic = false,
                    strikeout = false,
                    symbol = false,
                    rotary = false,
                    shadow = false,
                    additive = false,
                    outline = false
                })
            end

            draw.SimpleText("[" .. (control or VC.Lng("None")) .. "] " .. (indriveby and VC.Lng("ExitDriveByMode") or VC.Lng("EnterDriveByMode")), "VC_DriveBy", math.Round(ScrW() / 2 - (20 - anim * 20) + CARot[1]), math.Round(ScrH() / 1.1 + 8 + (5 - anim * 5) + CARot[2]), Color(255, 255, 255, (180 + math.sin(CurTime() * (indriveby and 3 or 1)) * 35) * anim), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
    end
end

VC.DrawFT["Name"] = function(ply, CARot, ent, DrvV, Veh, Sart_Height)
    local name = VC.getName(Veh)
    if name and not ply.VC_HUD_Name_Tm then
        ply.VC_HUD_PNam = name
        ply.VC_HUD_Name_Tm = CurTime() + 3
    elseif ply.VC_HUD_Name_Tm and not name then
        ply.VC_HUD_Name_Tm = nil
    end

    local on = ply.VC_HUD_Name_Tm and CurTime() < ply.VC_HUD_Name_Tm
    local anim = VC.UI_AnimData("Name", on, 0.01, 0.005)
    if anim and ply.VC_HUD_PNam ~= "" then
        local Num = VC.EaseInOut(anim)
        CARot = CARot or CalcRot()
        surface.SetFont("VC_Name")
        local Wth = surface.GetTextSize(ply.VC_HUD_PNam) + 80
        if not VC.Fonts["VC_Name"] then
            VC.Fonts["VC_Name"] = true
            surface.CreateFont("VC_Name", {
                font = "tahoma",
                size = 30,
                weight = 1000,
                blursize = 0,
                scanlines = 0,
                antialias = true,
                underline = false,
                italic = false,
                strikeout = false,
                symbol = false,
                rotary = false,
                shadow = false,
                additive = false,
                outline = false
            })
        end

        local height = VC.getSetting("HUD_Name_Height") or 0.75
        local SizeXe = math.Round((Wth + CARot[1]) * math.Clamp(Num * 10, 0, 1))
        local PosY = math.Round(ScrH() * height + CARot[2])
        local tclr = VC.Color.Main
        draw.RoundedBox(0, -30, PosY, SizeXe, 45, tclr)
        surface.SetDrawColor(tclr)
        surface.SetMaterial(VC.Material.Fade)
        surface.DrawTexturedRect(math.Round(SizeXe - 30), PosY, 45, 45)
        draw.RoundedBox(0, 0, math.Round(ScrH() * height + CARot[2] + 35), (Wth + CARot[1] - 15) * math.Clamp(Num * 3, 0, 1), 2, Color(100, 255, 55, 255))
        draw.SimpleText(ply.VC_HUD_PNam, "VC_Name", math.Round(Wth + CARot[1] - 35 + (35 * Num - 35)), math.Round(ScrH() * height + CARot[2] + 20), Color(255, 255, 255, 255 * math.Clamp((Num - 0.25) * 1.25, 0, 1)), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
    end
end

VC.DrawFT["Cruise"] = function(ply, CARot, ent, DrvV, Veh, Sart_Height)
    local on = DrvV and ent == Veh and ent:GetNWInt("VC_Cruise_Spd", 0) > 0
    local anim = VC.UI_AnimData("Cruise", on, 0.05, 0.05)
    if anim then
        CARot = CARot or CalcRot()
        local CCVel = ent and ent:GetNWInt("VC_Cruise_Spd", 0) or 0
        if DrvV and (ply:KeyDown(IN_FORWARD) or ply:KeyDown(IN_BACK)) then
            if not ply.VC_Cruise_KDV or ply.VC_Cruise_KDV < 1 then ply.VC_Cruise_KDV = math.Round(((ply.VC_Cruise_KDV or 0) + 0.1) * 100) / 100 end
            CCVel = -ent:GetVelocity():Dot(ent:GetRight())
        elseif ply.VC_Cruise_KDV then
            if ply.VC_Cruise_KDV > 0 then ply.VC_Cruise_KDV = math.Round((ply.VC_Cruise_KDV - 0.1) * 100) / 100 end
        end

        local SCVr = math.Clamp((ply.VC_Cruise_HUD_L or 0) / 5 - 5, 0, 20) * (1 - (ply.VC_Cruise_KDV or 0))
        local Miles = VC.getSetting("HUD_MPh")
        CCVel = (CCVel > 10 and CCVel or 10) * (Miles and 0.0568181818 or 0.09144)
        ply.VC_Cruise_HUD_L = Lerp(0.05 * VC.FTm(), ply.VC_Cruise_HUD_L or 0, CCVel)
        local Sx = math.Round(ScrW() / 2 - (300 / 2 + 15 * (ply.VC_Cruise_KDV or 0)) * anim + CARot[1])
        local Sy = math.Round(ScrH() / 1.1 + (20 + (15 - anim * 15) + CARot[2]))
        local sizex = (300 + 25 * (ply.VC_Cruise_KDV or 0)) * anim
        VC.DrawFadeRect(Sx, Sy - 40, sizex, 45)
        draw.RoundedBox(0, Sx, Sy, sizex, 2, Color(100, 255, 55, 255 * anim))
        if not VC.Fonts["VC_Cruise"] then
            VC.Fonts["VC_Cruise"] = true
            surface.CreateFont("VC_Cruise", {
                font = "MenuLarge",
                size = 26,
                weight = 1000,
                blursize = 0,
                scanlines = 0,
                antialias = true,
                underline = false,
                italic = false,
                strikeout = false,
                symbol = false,
                rotary = false,
                shadow = false,
                additive = false,
                outline = false
            })
        end

        draw.SimpleText(VC.Lng("CruisingAt") .. " " .. tostring(math.Round(ply.VC_Cruise_HUD_L)) .. " " .. (Miles and "mi/h" or "km/h") .. ".", "VC_Cruise", math.Round(ScrW() / 2 + CARot[1]), math.Round(ScrH() / 1.1 + (10 - anim * 10) + CARot[2]), Color(255, 255 - 200 * (ply.VC_Cruise_KDV or 0), 255 - 200 * (ply.VC_Cruise_KDV or 0), 180 * anim + math.sin(CurTime() * 5 + SCVr / 3) * 35), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    elseif ply.VC_Cruise_HUD_L then
        ply.VC_Cruise_HUD_L = nil
        ply.VC_Cruise_KDV = nil
    end
end

VC.DrawFT["PickUp"] = function(ply, CARot, ent, DrvV, Veh, Sart_Height)
    for k, v in pairs(ents.FindByClass("vc_pickup*")) do
        if not IsValid(v) then continue end
        if not v.VC_PVsb then v.VC_PVsb = util.GetPixelVisibleHandle() end
        local Vis = util.PixelVisible(v:GetPos() + Vector(0, 0, 25), 5, v.VC_PVsb)
        local Dist = nil
        if Vis > 0 then Dist = VC.GetViewPos():Distance(v:GetPos()) end
        local Type = v.VC_Type or "health"
        local text = VC.Lng("Unknown")
        local isCarPart = Type == "carpart"
        local isAtc = nil
        if isCarPart then isAtc = IsValid(v:GetNWEntity("VC_AttachedTo")) end
        if isAtc and Dist then Dist = Dist / 2 end
        if not v.VC_CanDraw then
            if v.VC_CanDrawTimer then
                if CurTime() >= v.VC_CanDrawTimer then
                    v.VC_CanDraw = true
                    v.VC_CanDrawTimer = nil
                end
            else
                v.VC_CanDrawTimer = CurTime() + 1
            end
        end

        local on = v.VC_CanDraw and Vis > 0 and Dist < (v:GetNWInt("VC_Storage", 0) == -1 and 200 or VC.getSetting("PickupDistance", 2500))
        local anim = VC.UI_AnimData("Pickup_" .. v:EntIndex(), on, 0.05, 0.05)
        if anim then
            local VisM = anim * 255
            local Pos = v:GetPos():ToScreen()
            local PSx, PSy = Pos.x, Pos.y
            local PEx, PEy = Pos.x + 20, Pos.y - 15
            if not isAtc then
                if Type == "health" then
                    local chunks = string.Explode(" ", v.VC_Text)
                    text = string.gsub(VC.Lng("Pickup_" .. chunks[2]), ":val:", chunks[3] .. "%")
                elseif Type == "partkit" then
                    text = VC.Lng("Pickup_PartKit")
                elseif Type == "fuel" then
                    local num = v:GetNWInt("VC_Storage", 0)
                    if num == -1 then
                        num = 0
                    else
                        if num == 0 then num = v.VC_Storage end
                    end

                    local txt = ""
                    if num == 0 then
                        txt = VC.Lng("Empty")
                    else
                        txt = VC.Lng(VC.FuelTypes[v.VC_FuelType].name) .. " " .. VC.LiterToAuto(num, v.VC_FuelType) .. " " .. VC.TextToAuto(v.VC_FuelType)
                    end

                    text = VC.Lng("Pickup_Fuel") .. txt
                elseif isCarPart then
                    local meth = v.VC_Method or "unknown"
                    if meth == "wheel" then meth = "tire" end
                    text = VC.Lng("Pickup_Carpart") .. " " .. string.lower(VC.Lng(VC.capitalizeFirstLetter(meth)))
                end

                surface.SetFont("VC_Name")
                local tsize = surface.GetTextSize(text)
                VC.DrawFadeRect(PEx, PEy - 25, tsize + 5, 30)
                draw.SimpleText(text, "VC_Name", PEx + 5, PEy - 10, Color(255, 255, 255, VisM), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
                surface.SetDrawColor(v.VC_Color.r, v.VC_Color.g, v.VC_Color.b, VisM)
                surface.DrawLine(PSx, PSy, PEx + 1, PEy)
                surface.DrawLine(PSx, PSy + 1, PEx, PEy + 1)
                surface.DrawLine(PSx, PSy + 2, PEx, PEy + 2)
                draw.RoundedBox(0, PEx, PEy, tsize + 5, 2, Color(v.VC_Color.r, v.VC_Color.g, v.VC_Color.b, VisM))
                surface.SetMaterial(VC.Material.Circle_32)
                surface.DrawTexturedRect(PSx - 4, PSy - 2, 8, 8)
            end
        end
    end
end

local function GetDamagedParts(ent)
    local Points = {}
    if ent:GetNWInt("VC_HealthPerc", 1) < 1 then
        Points["engine"] = {}
        Points["engine"][1] = {}
        Points["engine"][1].Pos = ent:WorldToLocal(VC.getEnginePos(ent))
    end

    if ent.VC_DamagedObjects then
        for k, v in pairs(ent.VC_DamagedObjects) do
            if not Points[k] then Points[k] = {} end
            if k ~= "L_ELS" then
                for k2, v2 in pairs(v) do
                    Points[k][k2] = {
                        Pos = VC.GetObjectPos(ent, k, k2, 137)
                    }
                end
            end
        end
    end
    return Points
end

VC.DrawFT["Damage"] = function(ply, CARot, ent, DrvV, Veh, Sart_Height)
    local Wep = ply:GetActiveWeapon()
    if not IsValid(Wep) then Wep = nil end
    local On = not IsValid(ply:GetVehicle()) and Wep and (Wep:GetClass() == "vc_wrench" or Wep:GetClass() == "vc_repair")
    local dent = nil
    if wep and wep ~= NULL then
        dent = wep:GetNWEntity("VC_DamagedEnt")
    else
        wep = nil
    end

    if On or VC.HUD_DamagedObjects then
        local TVeh, TPos = VC.getVehicleTrace(ply)
        if On then On = TVeh and TVeh:IsVehicle() end
        if TVeh then VC.HUD_DamagedObjects_LEnt = TVeh end
        if (On or VC.HUD_DamagedObjects) and IsValid(VC.HUD_DamagedObjects_LEnt) then
            local distgood = TPos and TPos:Distance(ply:GetPos()) < 300
            local Points = GetDamagedParts(VC.HUD_DamagedObjects_LEnt)
            for k, v in pairs(Points) do
                if not VC.HUD_DamagedObjects then VC.HUD_DamagedObjects = {} end
                if not VC.HUD_DamagedObjects[k] then VC.HUD_DamagedObjects[k] = {} end
                for k2, v2 in pairs(v) do
                    if not VC.HUD_DamagedObjects[k][k2] then VC.HUD_DamagedObjects[k][k2] = v2 end
                end
            end

            if not VC.HUD_DamagedObjects then return end
            for k, v in pairs(VC.HUD_DamagedObjects) do
                if k ~= "LPT" then
                    for k2, v2 in pairs(v) do
                        local on = Points[k] and Points[k][k2] and distgood and On
                        local anim = VC.UI_AnimData("HUD_Damage_Point_" .. k .. k2, on, 0.05, 0.05)
                        if anim then
                            local VisM = anim * 255
                            local Pos = VC.HUD_DamagedObjects_LEnt:LocalToWorld(v2.Pos or Vector(0, 0, 0)):ToScreen()
                            local PSx, PSy = Pos.x, Pos.y
                            local size = 18 - VC.EaseInOut(anim) * 10
                            local clr = VC.Color.Accent_Light
                            surface.SetDrawColor(clr.r, clr.g, clr.b, VisM)
                            surface.SetMaterial(VC.Material.Glow)
                            surface.DrawTexturedRect(PSx - size * 32, PSy - size * 32, size * 64, size * 64)
                            local clr = VC.Color.Base
                            surface.SetDrawColor(clr.r, clr.g, clr.b, VisM)
                            surface.SetMaterial(VC.Material.Circle_32)
                            surface.DrawTexturedRect(PSx - size / 2, PSy - size / 2, size, size)
                        else
                            VC.HUD_DamagedObjects[k][k2] = nil
                            if table.Count(VC.HUD_DamagedObjects[k]) == 0 then VC.HUD_DamagedObjects[k] = nil end
                            if table.Count(VC.HUD_DamagedObjects) == 0 then VC.HUD_DamagedObjects = nil end
                        end
                    end
                end
            end
        end
    end

    local on = On and IsValid(dent)
    local anim = VC.UI_AnimData("HUD_Damage_Point_Fix", on, 0.05, 0.05)
    if anim then
        if IsValid(dent) then VC.HUD_DamagedObjects_Dent = dent end
        if IsValid(VC.HUD_DamagedObjects_Dent) then
            local start, finish = wep:GetNWInt("VC_DoingStart", 0), wep:GetNWInt("VC_DoingFinish", 0)
            local spos = VC.HUD_DamagedObjects_Dent:LocalToWorld(wep:GetNWVector("VC_DamagedPos"), Vector(0, 0, 0)):ToScreen()
            local doing = start > 0
            local prc = 0
            if doing then prc = math.Clamp(100 - math.Round((finish - CurTime()) / (finish - start) * 100), 0, 100) end
            local PSx, PSy = spos.x, spos.y
            local PEx, PEy = math.Round(spos.x + 20), math.Round(spos.y - 15)
            local part = wep:GetNWString("VC_DamagedPart", "")
            VC.DrawFadeRect(PEx - 25, PEy, 60 * anim + 5, 30)
            local tclr = VC.Color.Base
            if doing then tclr = Color(200, 255, 200, 255) end
            draw.SimpleText(prc .. " %", "VC_Dev_Text", PEx + 40 * anim, PEy + 15, Color(255, 255, 255, 255 * anim), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
            if part and VC.GetPartInfo(part, true) then
                surface.SetDrawColor(tclr)
                local pname = part
                if pname == "light" and VC.DamagedLightIsELS(dent, wep:GetNWString("VC_DamagedPart_Int", "")).isELS then pname = "light_els" end
                local icon = VC.GetPartIcon(pname)
                if icon then
                    surface.SetMaterial(icon)
                    surface.DrawTexturedRect(PEx - 30, PEy + 1, 28, 28)
                end
            end
        end
    end
end

VC.DrawFT["Fuel Lid Pos"] = function(ply, CARot, ent, DrvV, Veh, Sart_Height)
    local Wep = ply:GetActiveWeapon()
    if not IsValid(Wep) then Wep = nil end
    local FOn = not IsValid(ply:GetVehicle()) and (VC.PickedUpNozzle_Time and CurTime() < VC.PickedUpNozzle_Time + 30 or Wep and (Wep:GetClass() == "vc_jerrycan"))
    if VC.getSetting("HUD_FuelLidPosition") and FOn then
        for k, v in pairs(VC.GetVehicleList()) do
            if not IsValid(v) then continue end
            local TVeh, TPos = v, v:GetPos()
            local On = false
            if FOn then On = TVeh and TVeh:IsVehicle() and not TVeh:GetNWBool("VC_Fuel_Disabled", false) end
            if TVeh then VC.HUD_DamagedObjects_LEnt = TVeh end
            local distgood = TPos and TPos:Distance(ply:GetPos()) < 300
            if not VC.Fuel_Last then VC.Fuel_Last = {} end
            local Max = TVeh and VC.getFuelMax(TVeh, 0) or VC.Fuel_Last.Max
            local Cur = math.ceil(TVeh and VC.getFuel(TVeh, 0) or VC.Fuel_Last.Cur)
            local ftype = TVeh and TVeh:GetNWInt("VC_FuelType", 0) or VC.Fuel_Last.ftype
            if not VC.Fuel_Last then VC.Fuel_Last = {} end
            VC.Fuel_Last.Max = Max
            VC.Fuel_Last.Cur = Cur
            local on = distgood and On
            local anim = VC.UI_AnimData("HUD_Fuel_Lid_Pos_" .. VC.getName(TVeh, TVeh:GetModel()), on, 0.05, 0.05)
            if anim then
                local VisM = anim * 255
                local Pos = VC.HUD_DamagedObjects_LEnt and VC.HUD_DamagedObjects_LEnt:LocalToWorld(TVeh:GetNWVector("VC_FuelLidPos"), Vector(0, 0, 0)):ToScreen()
                local PSx, PSy = Pos.x, Pos.y
                local PEx, PEy = math.Round(Pos.x + 20), math.Round(Pos.y - 15)
                local text = VC.Lng(VC.FuelTypes[ftype].name) .. ": " .. VC.LiterToAuto(Cur, ftype, 100) .. "/" .. VC.LiterToAuto(Max, ftype) .. " " .. VC.TextToAuto(ftype)
                surface.SetFont("VC_Name")
                local tsize = surface.GetTextSize(text)
                local Sizex = 20
                local Sizey = 30
                local tclr = table.Copy(VC.Color.Main)
                tclr.a = tclr.a * VisM / 255
                VC.DrawFadeRect(PEx, PEy - Sizey, tsize + 10, Sizey + 5, tclr)
                draw.SimpleText(text, "VC_Name", PEx + 5, PEy - 10, Color(255, 255, 255, VisM), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
                local clr = Color(55, 255, 100, VisM)
                draw.RoundedBox(0, PEx, PEy, tsize + 5, 2, Color(clr.r, clr.g, clr.b, VisM))
                surface.DrawLine(PSx, PSy, PEx + 1, PEy)
                surface.DrawLine(PSx, PSy + 1, PEx, PEy + 1)
                surface.DrawLine(PSx, PSy + 2, PEx, PEy + 2)
                surface.SetMaterial(VC.Material.Circle_32)
                surface.DrawTexturedRect(PSx - 4, PSy - 2, 8, 8)
            end

            if TVeh then
                VC.Fuel_Last.LidPos = TVeh:GetNWVector("VC_FuelLidPos", Vector(0, 0, 0))
                VC.Fuel_Last.ftype = ftype
            end
        end
    end
end


function VC.CreateClSettingsTab_VC1(List, ListP)
    local MPnl = VC.Add_El_Panel(ListP, {1 / 3, 1 / 3, 1 / 3}, 24, true)
    local CBox = VC.Add_El_Checkbox("Enabled", "If VCMod third person view is on or off. If off, none of the settings bellow will work..", "ThirdPerson_Use", VC.Settings)
    MPnl[1]:AddItem(CBox)
    local CBox = VC.Add_El_Checkbox("DynamicView", "The dynamic slidy type of effect", "ThirdPerson_Dynamic", VC.Settings)
    MPnl[2]:AddItem(CBox)
    local CBox = VC.Add_El_Checkbox("SpeedTilt", "Camera tilts up and back when vehicle starts to move.", "ThirdPerson_Speed", VC.Settings)
    MPnl[3]:AddItem(CBox)
    local MPnl = VC.Add_El_Panel(ListP, {1 / 3, 1 / 3, 1 / 3}, 34, true)
    local SNLbl = vgui.Create("DLabel")
    SNLbl:SetText("")
    SNLbl:SetTall(8)
    MPnl[1]:AddItem(SNLbl)
    local CBox = VC.Add_El_Checkbox("AutoFocus", "Focuses the camera behind the vehicle.", "ThirdPerson_Auto", VC.Settings)
    MPnl[1]:AddItem(CBox)
    local SNLbl = vgui.Create("DLabel")
    SNLbl:SetText("")
    SNLbl:SetTall(8)
    MPnl[2]:AddItem(SNLbl)
    local CBox = VC.Add_El_Checkbox("Reverse", "Focuses the camera in front of the vehicle while reversing.", "ThirdPerson_Auto_Back", VC.Settings)
    MPnl[2]:AddItem(CBox)
    local Sldr = VC.Add_El_Slider("Height", 0, 20, 0, "How high behind the car the camera will focus.", "ThirdPerson_Auto_Pitch", VC.Settings)
    MPnl[3]:AddItem(Sldr)
    local Sldr = VC.Add_El_Slider("VectorStiffness", 0, 100, 0, "How far the view will stay behind before slowly returning to normal.", "ThirdPerson_Vec_Stf", VC.Settings)
    ListP:AddItem(Sldr)
    local Sldr = VC.Add_El_Slider("AngleStiffness", 0, 100, 0, "How far the view will sway from side to side before slowly returning to normal.", "ThirdPerson_Ang_Stf", VC.Settings)
    ListP:AddItem(Sldr)
    local Type = vgui.Create("DComboBox", ListP)
    Type:AddChoice(VC.Lng("Advanced"))
    Type:AddChoice(VC.Lng("Lerp"))
    Type:SetSize(100, 24)
    Type:SetPos(List:GetWide() - Type:GetWide() - 20, 0)
    Type:ChooseOptionID(VC.getSetting("ThirdPerson_Type"))
    Type.OnSelect = function(idx, val) VC.SaveSetting("ThirdPerson_Type", val) end
    local CBox = VC.Add_El_Checkbox("TruckView", "View focuses in between the trailer and the truck.", "ThirdPerson_Cam_Trl", VC.Settings)
    ListP:AddItem(CBox)
    local CBox = VC.Add_El_Slider("Height", 0.2, 3, 2, "Vehicles camera hight multiplier.", "ThirdPerson_Hight_Mult", VC.Settings)
    ListP:AddItem(CBox)
end

function VC.CreateClSettingsTab_TireTracks(List, ListP)
    local CBox = VC.Add_El_Checkbox("Enabled", "This is for all effects.", "TireTracks_Enabled", VC.Settings)
    ListP:AddItem(CBox)
    local Sldr = VC.Add_El_Slider("VisDist", 50, 10000, 0, "Distance at which the tire tracks simply are not drawn", "TireTracks_Dist", VC.Settings)
    ListP:AddItem(Sldr)
    local Sldr = VC.Add_El_Slider("FadeOutTime", 0, 30, 2, "Distance at which the tire tracks simply are not drawn", "TireTracks_FadeOutTime", VC.Settings)
    ListP:AddItem(Sldr)
    local Sldr = VC.Add_El_Slider(VC.Lng("Detail") .. " (%), " .. VC.Lng("PerformanceImpact"), 5, 100, 1, "The detail of the tire track. Heavy impact on performance", "TireTracks_Detail", VC.Settings)
    ListP:AddItem(Sldr)
    local CBox = VC.Add_El_Checkbox("FlatTire", "Leave a mark on the road when driving with a flat tire.", "TireTracks_Sparks", VC.Settings)
    ListP:AddItem(CBox)
end

function VC.CreateClSettingsTab_Other(List, ListP)
    local CBox = VC.Add_El_Checkbox(VC.Lng("Animation") .. ": " .. VC.Lng("BendPassengerLegs"), "Should we bend the passengers legs when entering the VCMod passenger seats?", "Anim_PassengerLegBending", VC.Settings)
    ListP:AddItem(CBox)
    local CBox = VC.Add_El_Checkbox(VC.Lng("Animation") .. ": " .. VC.Lng("OverrideDriverAnims"), "If this is true, on compatible vehicles, driver positioning, animations, pose will be altered.", "Anim_OverrieDriverAnimPos", VC.Settings)
    ListP:AddItem(CBox)
end

function VC.CreateClSettingsTab_Effects(List, ListP)
    local CBox = VC.Add_El_Checkbox("Enabled", "Enabled all the stuff bellow.", "Surface_Enabled", VC.Settings)
    ListP:AddItem(CBox)
    local CBox = VC.Add_El_Checkbox("Normal", "Surface effects for when simply driving on a surface.", "Surface_Normal", VC.Settings)
    ListP:AddItem(CBox)
    local MPnl = VC.Add_El_Panel(ListP, {0.5, 0.5}, 28, true)
    local CBox = VC.Add_El_Checkbox("Skidding", "Surface effects for when the vehicle is braking or skidding.", "Surface_Brakes", VC.Settings)
    MPnl[1]:AddItem(CBox)
    local CBox = VC.Add_El_Checkbox("Sound", "Emit audio while doing it.", "Surface_Brakes_Audio", VC.Settings)
    MPnl[2]:AddItem(CBox)
    local MPnl = VC.Add_El_Panel(ListP, {0.5, 0.5}, 28, true)
    local CBox = VC.Add_El_Checkbox("Sparks", "Surface effects for when driving with a flat tire.", "Surface_Sparks", VC.Settings)
    MPnl[1]:AddItem(CBox)
    local CBox = VC.Add_El_Checkbox("Sound", "Emit audio while doing it.", "Surface_Sparks_Audio", VC.Settings)
    MPnl[2]:AddItem(CBox)
end

local function BuildMenu(Pnl)
    local List = VC.Add_El_List(0, 35, Pnl:GetWide(), Pnl:GetTall() - 60)
    List:SetParent(Pnl)
    local ElTbl = {}
    local Settings_Sv = {}
    local CBox = VC.Add_El_Checkbox("Enabled_Sv", "Basically shuts down all the stuff bellow.", "Enabled", Settings_Sv, true)
    List:AddItem(CBox)
    ElTbl.Enabled = CBox
    local Sheet = vgui.Create("DPropertySheet")
    Sheet:SetTall(435)
    local List_1_1 = VC.Add_El_List(0, 6, 450, 435)
    Sheet:AddSheet(VC.Lng("Lights"), List_1_1, "icon16/lightbulb.png", false, false, "Light options.")
    local List_1_fuel = VC.Add_El_List(0, 6, 450, 435)
    Sheet:AddSheet(VC.Lng("Fuel"), List_1_fuel, "icon16/basket.png", false, false, "Fuel options.")
    local List_1_2 = VC.Add_El_List(0, 6, 450, 435)
    Sheet:AddSheet(VC.Lng("Health"), List_1_2, "icon16/heart.png", false, false, "Health and damage controls.")
    local List_1_6 = VC.Add_El_List(0, 6, 450, 435)
    Sheet:AddSheet(VC.Lng("AdvancedDamage"), List_1_6, "icon16/exclamation.png", false, false, "Health and damage controls, more advanced stuff.")
    local List_1_5 = VC.Add_El_List(0, 6, 450, 435)
    Sheet:AddSheet(VC.Lng("Effects"), List_1_5, "icon16/chart_line.png", false, false, "Effect options.")
    local List_1_3 = VC.Add_El_List(0, 6, 450, 435)
    Sheet:AddSheet(VC.Lng("Sound"), List_1_3, "icon16/sound.png", false, false, "Sound options.")
    local List_1_4 = VC.Add_El_List(0, 6, 450, 800)
    Sheet:AddSheet(VC.Lng("Other"), List_1_4, "icon16/anchor.png", false, false, "Other options.")
    List:AddItem(Sheet)
    local CBox = VC.Add_El_Checkbox("Enabled", "Enables/Disables lights on vehicles including: emergency lights, running lights, reverse lights, blinkers, hazards, head lights.", "Lights", Settings_Sv, true)
    ElTbl.Lights = CBox
    List_1_1:AddItem(CBox)
    local MPnl = VC.Add_El_Panel(List_1_1, {0.5, 0.5}, 32, true)
    local SNLbl = vgui.Create("DLabel")
    SNLbl:SetText("")
    SNLbl:SetTall(8)
    MPnl[1]:AddItem(SNLbl)
    local CBox = VC.Add_El_Checkbox("RunningLights", "Enables/Disables running lights on vehicles.", "Lights_Running", Settings_Sv, true)
    ElTbl.Lights_Running = CBox
    MPnl[1]:AddItem(CBox)
    local Sldr = VC.Add_El_Slider("OffTime", 0, 600, 0, "Lights will turn off if the car is left alone after this time.", "LightsOffTime", Settings_Sv, true)
    ElTbl.LightsOffTime = Sldr
    MPnl[2]:AddItem(Sldr)
    local MPnl = VC.Add_El_Panel(List_1_1, {1 / 3, 1 / 3, 1 / 3}, 32, true)
    local SNLbl = vgui.Create("DLabel")
    SNLbl:SetText("")
    SNLbl:SetTall(8)
    MPnl[1]:AddItem(SNLbl)
    local CBox = VC.Add_El_Checkbox("HeadLights", "Enables/Disables headlights on vehicles. Low beams and high beams.", "HeadLights", Settings_Sv, true)
    ElTbl.HeadLights = CBox
    MPnl[1]:AddItem(CBox)
    local Sldr = VC.Add_El_Slider("DistMultiplier", 0, 2, 2, "How far the headlights will lights up the world.", "HLights_Dist_M", Settings_Sv, true)
    ElTbl.HLights_Dist_M = Sldr
    MPnl[2]:AddItem(Sldr)
    local Sldr = VC.Add_El_Slider("OffTime", 0, 120, 0, "Headlights will turn off if the car is left alone after this time.", "HLightsOffTime", Settings_Sv, true)
    ElTbl.HLightsOffTime = Sldr
    MPnl[3]:AddItem(Sldr)
    local MPnl = VC.Add_El_Panel(List_1_1, {1 / 3, 1 / 3, 1 / 3}, 48, true)
    local SNLbl = vgui.Create("DLabel")
    SNLbl:SetText("")
    SNLbl:SetTall(8)
    MPnl[1]:AddItem(SNLbl)
    local CBox = VC.Add_El_Checkbox("FogLights", "Enables/Disables headlights on vehicles.", "FogLights", Settings_Sv, true)
    ElTbl.FogLights = CBox
    MPnl[1]:AddItem(CBox)
    local Sldr = VC.Add_El_Slider("DistMultiplier", 0, 2, 2, "How far the headlights will lights up the world.", "FogLights_Dist_M", Settings_Sv, true)
    ElTbl.FogLights_Dist_M = Sldr
    MPnl[2]:AddItem(Sldr)
    local Sldr = VC.Add_El_Slider("OffTime", 0, 120, 0, "Headlights will turn off if the car is left alone after this time.", "FogLightsOffTime", Settings_Sv, true)
    ElTbl.FogLightsOffTime = Sldr
    MPnl[3]:AddItem(Sldr)
    local CBox = VC.Add_El_Checkbox("HandbrakeLights", "Should the brake light turn on when pressing the handbrake too [SPACE] key.", "Lights_HandBrake", Settings_Sv, true)
    ElTbl.Lights_HandBrake = CBox
    List_1_1:AddItem(CBox)
    local CBox = VC.Add_El_Checkbox("InteriorLights", "If the door is opened the interior lights will turn on.", "Lights_Interior", Settings_Sv, true)
    ElTbl.Lights_Interior = CBox
    List_1_1:AddItem(CBox)
    local CBox = VC.Add_El_Checkbox("BlinkersOffExit", "Should the blinkers auto turn off when a player leaves the driver seat.", "Lights_Blinker_OffOnExit", Settings_Sv, true)
    ElTbl.Lights_Blinker_OffOnExit = CBox
    List_1_1:AddItem(CBox)
    local CBox = VC.Add_El_Checkbox("DamageEnabled", "With this the vehicle will receive physical and weapon based damage.", "Damage", Settings_Sv, true)
    List_1_2:AddItem(CBox)
    ElTbl.Damage = CBox
    local SNLbl = vgui.Create("DLabel")
    SNLbl:SetText("")
    SNLbl:SetTall(4)
    List_1_2:AddItem(SNLbl)
    VC.Add_El_Line(List_1_2, VC.Color.Blue)
    local SNLbl = vgui.Create("DLabel")
    SNLbl:SetText("")
    SNLbl:SetTall(4)
    List_1_2:AddItem(SNLbl)
    local Sldr = VC.Add_El_Slider("StartHealthMultiplier", 0, 20, 1, "Starting health multiplier, applied to a car when it is spawned.", "Health_Multiplier", Settings_Sv, true)
    List_1_2:AddItem(Sldr)
    ElTbl.Health_Multiplier = Sldr
    local Sldr = VC.Add_El_Slider("FireDuration", 0, 600, 1, "For how long the fire will last after the vehicle has exploded.", "Dmg_Fire_Duration", Settings_Sv, true)
    List_1_2:AddItem(Sldr)
    ElTbl.Dmg_Fire_Duration = Sldr
    local Sldr = VC.Add_El_Slider("SmokeDuration", 0, 600, 1, "For how long the fire will last after the vehicle has exploded.", "Dmg_Smoke_Duration", Settings_Sv, true)
    List_1_2:AddItem(Sldr)
    ElTbl.Dmg_Smoke_Duration = Sldr
    local MPnl = VC.Add_El_Panel(List_1_2, {0.5, 0.5}, 32, true)
    local SNLbl = vgui.Create("DLabel")
    SNLbl:SetText("")
    SNLbl:SetTall(8)
    MPnl[1]:AddItem(SNLbl)
    local CBox = VC.Add_El_Checkbox("RemoveDestroyedVehicle", "Vehicle will be removed after it has exploded.", "Damage_Expl_Rem", Settings_Sv, true)
    MPnl[1]:AddItem(CBox)
    ElTbl.Damage_Expl_Rem = CBox
    local Sldr = VC.Add_El_Slider("Time", 0, 3600, 0, "Vehicle will be removed in this amount of time.", "Damage_Expl_Rem_Time", Settings_Sv, true)
    MPnl[2]:AddItem(Sldr)
    ElTbl.Damage_Expl_Rem_Time = Sldr
    local CBox = VC.Add_El_Checkbox("CanEnterIfDestroyed", "Can the vehicle be entered if it has been destroyed?", "Damage_CanEnterIfDestroyed", Settings_Sv, true)
    List_1_2:AddItem(CBox)
    ElTbl.Damage_CanEnterIfDestroyed = CBox
    VC.Add_El_Banner(List_1_2, "Repair")
    local CBox = VC.Add_El_Checkbox("Damage_Repair_GiveWrenchToDriver", "Give the repair wrench to driver upon entering the drivers seat.", "Damage_Repair_GiveWrenchToDriver", Settings_Sv, true)
    List_1_2:AddItem(CBox)
    ElTbl.Damage_Repair_GiveWrenchToDriver = CBox
    local CBox = VC.Add_El_Checkbox("Damage_Repair_GiveWrenchToCarPartUser", "Give the repair wrench to the person who uses a vehicle part.", "Damage_Repair_GiveWrenchToCarPartUser", Settings_Sv, true)
    List_1_2:AddItem(CBox)
    ElTbl.Damage_Repair_GiveWrenchToCarPartUser = CBox
    local CBox = VC.Add_El_Checkbox("Damage_Repair_NeedPart", "You need a vehicle part in order to repart stuff.", "Damage_Repair_NeedPart", Settings_Sv, true)
    List_1_2:AddItem(CBox)
    ElTbl.Damage_Repair_NeedPart = CBox
    local Sldr = VC.Add_El_Slider("RepairTime", 0, 5, 2, "How fast parts will be repaired by hand", "Damage_Repair_TimeMult", Settings_Sv, true)
    List_1_2:AddItem(Sldr)
    ElTbl.Damage_Repair_TimeMult = Sldr
    VC.Add_El_Banner(List_1_2, "Other")
    local CBox = VC.Add_El_Checkbox("HealthRepairBulletDamage", "Attempt to repair the default bullet source vehicle bullet damage issues.", "HealthRepairBulletDamage", Settings_Sv, true)
    List_1_2:AddItem(CBox)
    ElTbl.HealthRepairBulletDamage = CBox
    local CBox = VC.Add_El_Checkbox("CarsCantRunOverPlayers", "Cars cant run over players.", "CarsCantDamagePlayers", Settings_Sv, true)
    List_1_2:AddItem(CBox)
    ElTbl.CarsCantDamagePlayers = CBox
    local MPnl = VC.Add_El_Panel(List_1_2, {0.5, 0.5}, 32, true)
    local SNLbl = vgui.Create("DLabel")
    SNLbl:SetText("")
    SNLbl:SetTall(8)
    MPnl[1]:AddItem(SNLbl)
    local CBox = VC.Add_El_Checkbox("CanShootPlayersInSeats", "If players should be able to shoot out the players in seats.", "ShootPlayers", Settings_Sv, true)
    MPnl[1]:AddItem(CBox)
    ElTbl.ShootPlayers = CBox
    local Sldr = VC.Add_El_Slider("HitLikelinessMult", 0, 5, 0, "How likely the player is to be hit.", "ShootPlayers_Prec_Mult", Settings_Sv, true)
    MPnl[2]:AddItem(Sldr)
    ElTbl.ShootPlayers_Prec_Mult = Sldr
    local CBox = VC.Add_El_Checkbox("CanShootPlayersInSeatsOverrideDefault", "This is mainly for people with custom addon setups who are experiencing some kind of an issue.\nIf the default driver damage methods shuld be replaced by the VCMod ones or not.", "ShootPlayers_OverrideDefault", Settings_Sv, true)
    List_1_2:AddItem(CBox)
    ElTbl.ShootPlayers_OverrideDefault = CBox
    local CBox = VC.Add_El_Checkbox("Damage_Ignite", "Ignite the car with fire after explosion", "Damage_Ignite", Settings_Sv, true)
    List_1_2:AddItem(CBox)
    ElTbl.Damage_Ignite = CBox
    local CBox = VC.Add_El_Checkbox("Drain_Fuel", "Drain vehicles fuel on explosion", "Damage_explosion_drain_fuel", Settings_Sv, true)
    List_1_2:AddItem(CBox)
    ElTbl.Damage_explosion_drain_fuel = CBox
    VC.Add_El_Banner(List_1_6, "PhysicalDamage")
    local CBox = VC.Add_El_Checkbox("PhysicalDamage", "Vehicle will take damage when colliding with things.", "PhysicalDamage", Settings_Sv, true)
    List_1_6:AddItem(CBox)
    ElTbl.PhysicalDamage = CBox
    local CBox = VC.Add_El_Checkbox("PhysicalDamageWPhysGun", "Damage will be applied while not using physgun", "PhysicalDamageWPhysGun", Settings_Sv, true)
    List_1_6:AddItem(CBox)
    ElTbl.PhysicalDamageWPhysGun = CBox
    local CBox = VC.Add_El_Checkbox("OnlyWithPassengers", "Physical damage will not work unless the vehicle has passengers in it.", "OnlyWithPassengers", Settings_Sv, true)
    List_1_6:AddItem(CBox)
    ElTbl.OnlyWithPassengers = CBox
    local Sldr = VC.Add_El_Slider("Player damage multiplier", 0, 5, 1, "Damage will be multiplied by this amount to the players within the seats.", "PhysicalDamage_PlyDmgMult", Settings_Sv, true)
    List_1_6:AddItem(Sldr)
    ElTbl.PhysicalDamage_PlyDmgMult = Sldr
    local CBox = VC.Add_El_Checkbox("Disable default driver physical damage", "Will disable all physical damage dealt to the driver. Useful for replacing it with VCMods damage", "PhysicalDamage_PlyDisable", Settings_Sv, true)
    List_1_6:AddItem(CBox)
    ElTbl.PhysicalDamage_PlyDisable = CBox
    local Sldr = VC.Add_El_Slider("Multiplier", 0, 5, 1, "Damage will be multiplied by this amount.", "PhysicalDamage_Mult", Settings_Sv, true)
    List_1_6:AddItem(Sldr)
    ElTbl.PhysicalDamage_Mult = Sldr
    local Sldr = VC.Add_El_Slider("MinimumSpeed", 0, 1000, 0, "Damage will be started to count upwards from this number.", "Damage_Phys_MinVel", Settings_Sv, true)
    List_1_6:AddItem(Sldr)
    ElTbl.Damage_Phys_MinVel = Sldr
    local CBox = VC.Add_El_Checkbox("Damage_Custom_Sounds", "Emit custom sounds when damaged.", "Sound_Damage_Custom", Settings_Sv, true)
    List_1_6:AddItem(CBox)
    ElTbl.Sound_Damage_Custom = CBox
    VC.Add_El_Banner(List_1_6, "Objects")
    local CBox = VC.Add_El_Checkbox("Damage_Lights", "Able to damage the vehicles lights.", "Damage_Lights", Settings_Sv, true)
    List_1_6:AddItem(CBox)
    ElTbl.Damage_Lights = CBox
    local MPnl = VC.Add_El_Panel(List_1_6, {0.4, 0.6}, 18, true)
    local CBox = VC.Add_El_Checkbox("Damage_Wheels", "Able to damage the vehicles tires.", "Damage_Wheels", Settings_Sv, true)
    MPnl[1]:AddItem(CBox)
    ElTbl.Damage_Wheels = CBox
    local CBox = VC.Add_El_Checkbox("Damage_Wheels_ELSOff", "ELS vehicles have bullet proof tires.", "Damage_Wheels_ELSOff", Settings_Sv, true)
    MPnl[2]:AddItem(CBox)
    ElTbl.Damage_Wheels_ELSOff = CBox
    local MPnl = VC.Add_El_Panel(List_1_6, {0.4, 0.6}, 18, true)
    local CBox = VC.Add_El_Checkbox("Damage_Exhaust", "Able to damage the vehicles exhaust.", "Damage_Exhaust", Settings_Sv, true)
    MPnl[1]:AddItem(CBox)
    ElTbl.Damage_Exhaust = CBox
    local CBox = VC.Add_El_Checkbox("Damage_Exhaust_Backfire", "Exhaust backfire damaged engine.", "Damage_Exhaust_Backfire", Settings_Sv, true)
    MPnl[2]:AddItem(CBox)
    ElTbl.Damage_Exhaust_Backfire = CBox
    local MPnl = VC.Add_El_Panel(List_1_6, {0.4, 0.3, 0.3}, 18, true)
    local CBox = VC.Add_El_Checkbox("Damage_FuelLid", "Able to shoot the players fuel lid", "Damage_FuelLid", Settings_Sv, true)
    MPnl[1]:AddItem(CBox)
    ElTbl.Damage_FuelLid = CBox
    local CBox = VC.Add_El_Checkbox("Explode", "If the fuel lid is shot explode the vehicle? If not, it will only leak its fuel.", "Damage_FuelLid_Explode", Settings_Sv, true)
    MPnl[2]:AddItem(CBox)
    ElTbl.Damage_FuelLid_Explode = CBox
    local CBox = VC.Add_El_Checkbox("Drain_Fuel", "Drains all vehicles fuel.", "Damage_FuelLid_DrainFuel", Settings_Sv, true)
    MPnl[3]:AddItem(CBox)
    ElTbl.Damage_FuelLid_DrainFuel = CBox
    local CBox = VC.Add_El_Checkbox("Explode", "Explode the engine once its in critical condition.", "Damage_Explode", Settings_Sv, true)
    List_1_6:AddItem(CBox)
    ElTbl.Damage_Explode = CBox
    VC.Add_El_Banner(List_1_6, "Spikestrip")
    local CBox = VC.Add_El_Checkbox("SpikeStrip_auto_give_els", "Should the spike strip be automatically given to anyone who enters a police vehicle? Not rear seats.", "SpikeStrip_auto_give_els", Settings_Sv, true)
    List_1_6:AddItem(CBox)
    ElTbl.SpikeStrip_auto_give_els = CBox
    local CBox = VC.Add_El_Checkbox("SpikeStrip_auto_remove_death", "Should the spike strip auto remove itself of a dead player?", "SpikeStrip_auto_remove_death", Settings_Sv, true)
    List_1_6:AddItem(CBox)
    ElTbl.SpikeStrip_auto_remove_death = CBox
    local CBox = VC.Add_El_Checkbox("CanDamagePlayersNPCs", "Should the spike strip damage entities above it?", "SpikeStrip_damage_players", Settings_Sv, true)
    List_1_6:AddItem(CBox)
    ElTbl.SpikeStrip_damage_players = CBox
    local CBox = VC.Add_El_Checkbox("IgnoreEmergencyVehicles", "Should the spike strip ignore ELS vehicles?", "SpikeStrip_Ignore_ELS", Settings_Sv, true)
    List_1_6:AddItem(CBox)
    ElTbl.SpikeStrip_Ignore_ELS = CBox
    Pnl.FrameRate = VGUIFrameTime() - (Pnl.FrameTime or 0)
    Pnl.FrameTime = VGUIFrameTime()
    local Horz = vgui.Create("DHorizontalScroller", List_1_fuel)
    Horz:SetSize(Pnl:GetWide() - 120, 100)
    Horz:AlignTop(20)
    Horz:AlignLeft(50)
    Horz:SetOverlap(0)
    Horz:NoClipping(true)
    function HorzResetAlpha(int)
        Horz:AlphaTo(0, 0, 0)
        Horz:AlphaTo(255, int or 0.5, 0)
    end

    HorzResetAlpha(1)
    local Pnls = {}
    local function FillData()
        for k, v in pairs(Pnls) do
            if IsValid(v) then v:Remove() end
        end

        Pnls = {}
        for k, v in pairs(ents.FindByClass("vc_fuel_station_*")) do
            local ftype = VC.FuelTypes[v.VC_FuelType or 0]
            local mdl = vgui.Create("DModelPanel", List_1_fuel)
            mdl:SetModel(ftype.mdl)
            mdl:SetCamPos(Vector(45, 0, 0))
            mdl:SetSize(150, 150)
            local RandMove = math.Rand(1.5, 2.5)
            function mdl:LayoutEntity()
                mdl:SetLookAt(Vector(0, math.sin(CurTime() * RandMove), 0))
                return
            end

            local function DoClick()
                local DDM = VC.DermaMenu("Fuel station options")
                DDM:AddButton("Remove", function()
                    if IsValid(v) and VC.CanEditAdminSettings(LocalPlayer()) then
                        net.Start("VC_Fuel_Remove")
                        net.WriteEntity(v)
                        net.SendToServer()
                        timer.Simple(0.5, function() FillData() end)
                    else
                        VCPopup("AccessRestricted", "cross")
                    end
                end):SetImage("icon16/cross.png")

                DDM:AddButton("Trace position", function()
                    if IsValid(v) and VC.CanEditAdminSettings(LocalPlayer()) then
                        net.Start("VC_Fuel_Trace")
                        net.WriteEntity(v)
                        net.SendToServer()
                    else
                        VCPopup("AccessRestricted", "cross")
                    end
                end):SetImage("icon16/map.png")

                DDM:Open()
            end

            mdl.DoClick = DoClick
            mdl.DoRightClick = DoClick
            local Nm = VC.Lng(ftype.name)
            local clr = VC.Color.Main
            mdl.PaintOver = function(obj, Sx, Sy)
                mdl:SetCamPos(Vector(45, 0, 0))
                local tclr = table.Copy(clr)
                draw.RoundedBox(0, 0, 0, Sx, 25, clr)
                if not mdl:IsHovered() then draw.RoundedBox(0, 0, 0, Sx, Sy, Color(0, 0, 0, 55)) end
                if mdl:IsDown() then draw.RoundedBox(0, 0, 0, Sx, Sy, Color(0, 100, 100, 55)) end
                draw.DrawText(Nm, nil, Sx / 2, 7, table.Copy(VC.Color.Blue), TEXT_ALIGN_CENTER)
                local pos = 0
                if mdl:IsHovered() then
                    tclr = table.Copy(VC.Color.Blue)
                    surface.SetDrawColor(tclr)
                    surface.DrawLine(pos, 0, pos + Sx - 1, 0)
                    surface.DrawLine(pos, Sy - 1, pos + Sx - 1, Sy - 1)
                    surface.DrawLine(pos, 0, pos, Sy - 1)
                    surface.DrawLine(pos + Sx - 1, 0, pos + Sx - 1, Sy - 1)
                end
            end

            table.insert(Pnls, mdl)
            Horz:AddPanel(mdl)
        end
    end

    FillData()
    function Horz:OnMouseWheeled(delta)
        Horz.OffsetX = Horz.OffsetX + delta * -100
        self:InvalidateLayout(true)
        return true
    end

    function Horz:PerformLayout()
        local w, h = self:GetSize()
        local x = 0
        self.pnlCanvas:SetTall(h)
        if self.Panels then
            for k, v in pairs(self.Panels) do
                if IsValid(v) then
                    v:SetPos(x, 0)
                    v:SetTall(h)
                    v:ApplySchemeSettings()
                    x = x + v:GetWide() - self.m_iOverlap
                end
            end

            self.pnlCanvas:SetWide(x + self.m_iOverlap)
            if w < self.pnlCanvas:GetWide() then
                self.OffsetX = math.Clamp(self.OffsetX, 0, self.pnlCanvas:GetWide() - self:GetWide())
            else
                self.OffsetX = 0
            end

            self.pnlCanvas.x = Lerp(0.1, self.pnlCanvas.x, -self.OffsetX)
        end

        self.btnLeft:SetVisible(false)
        self.btnRight:SetVisible(false)
    end

    local clr = VC.Color.Main
    local nvf = VC.Lng("Empty")
    Horz.Paint = function(obj, Sx, Sy)
        draw.RoundedBox(0, 0, 0, Sx, Sy, clr)
        surface.SetDrawColor(clr)
        surface.SetMaterial(VC.Material.Fade)
        surface.DrawTexturedRectRotated(Sx + VC.FadeW / 2, Sy / 2, VC.FadeW, Sy, 0)
        surface.DrawTexturedRectRotated(-VC.FadeW / 2, Sy / 2, VC.FadeW, Sy, 180)
        if #Pnls == 0 then draw.DrawText(nvf, "VC_Big_Italic", Sx / 2, 35, VC.Color.Blue, TEXT_ALIGN_CENTER) end
    end

    local CBox = VC.Add_El_Checkbox("Enabled", "Allows regular people to use car dealers.", "Fuel", Settings_Sv, true)
    List_1_fuel:AddItem(CBox)
    ElTbl.Fuel = CBox
    local SNLbl = vgui.Create("DLabel")
    SNLbl:SetText("")
    SNLbl:SetTall(110)
    List_1_fuel:AddItem(SNLbl)
    local Add = vgui.Create("VC_Button")
    Add:SetColor(VC.Color.Btn_Add)
    Add:SetText(VC.Lng("Add"))
    List_1_fuel:AddItem(Add)
    Add:SetToolTip("Create a new fueling station.")
    Add.DoClick = function()
        if VC.CanEditAdminSettings(LocalPlayer()) then
            local DDM = VC.DermaMenu("Fuel station options")
            for k, v in pairs(VC.FuelTypes) do
                DDM:AddButton(VC.Lng(v.name) .. " " .. v.shrt, function()
                    net.Start("VC_Fuel_Add")
                    net.WriteInt(k, 4)
                    net.SendToServer()
                    timer.Simple(0.5, function() FillData() end)
                end)
            end

            DDM:Open()
        else
            VCPopup("AccessRestricted", "cross")
        end
    end

    local SNLbl = vgui.Create("DLabel")
    SNLbl:SetText("")
    SNLbl:SetTall(2)
    List_1_fuel:AddItem(SNLbl)
    local MPnl = VC.Add_El_Panel(List_1_fuel, {0.5, 0.5}, 32, true)
    local Respawn = vgui.Create("VC_Button")
    Respawn:SetColor(VC.Color.Btn_Spw)
    Respawn:SetText(VC.Lng("Respawn"))
    MPnl[1]:AddItem(Respawn)
    Respawn:SetToolTip("Respawn all fuel stations on the map.")
    Respawn.DoClick = function()
        if VC.CanEditAdminSettings(LocalPlayer()) then
            net.Start("VC_Fuel_Respawn")
            net.SendToServer()
            timer.Simple(0.5, function() FillData() end)
        else
            VCPopup("AccessRestricted", "cross")
        end
    end

    local SavePos = vgui.Create("VC_Button")
    SavePos:SetColor(VC.Color.Good)
    SavePos:SetText(VC.Lng("Save"))
    MPnl[2]:AddItem(SavePos)
    SavePos:SetToolTip("Saves position of all fuel stations on the map.")
    SavePos.DoClick = function()
        if VC.CanEditAdminSettings(LocalPlayer()) then
            net.Start("VC_Fuel_Save")
            net.SendToServer()
            timer.Simple(0.5, function() FillData() end)
        else
            VCPopup("AccessRestricted", "cross")
        end
    end

    local MPnl = VC.Add_El_Panel(List_1_fuel, {0.5, 0.5}, 32, true)
    local CBox = VC.Add_El_Checkbox("Persistent", "Will automatically respawn if removed by scripts.", "Fuel_Persistent", Settings_Sv, true)
    MPnl[1]:AddItem(CBox)
    ElTbl.Fuel_Persistent = CBox
    local CBox = VC.Add_El_Checkbox("Fuel_lidNeedUnlocked", "Vehicle has to be unlocked to be able to use the fuel lid.", "Fuel_lidNeedUnlocked", Settings_Sv, true)
    MPnl[2]:AddItem(CBox)
    ElTbl.Fuel_lidNeedUnlocked = CBox
    local Sldr = VC.Add_El_Slider("Fuel_Cons_Mult", 0, 50, 2, "Vehicle fuel consumption multiplier.", "Fuel_Cons_Mult", Settings_Sv, true)
    List_1_fuel:AddItem(Sldr)
    ElTbl.Fuel_Cons_Mult = Sldr
    local MPnl = VC.Add_El_Panel(List_1_fuel, {0.5, 0.5}, 32, true)
    local Sldr = VC.Add_El_Slider("Refuel_MaxCapacity", 0, 1000, 0, "Maximum amount of purchased fuel that could be stored at one fuel station. In liters!", "Refuel_MaxCapacity", Settings_Sv, true)
    MPnl[1]:AddItem(Sldr)
    ElTbl.Refuel_MaxCapacity = Sldr
    local Sldr = VC.Add_El_Slider("Fuel_StartMult", 0, 5, 2, "Starting fuel multiplier", "Fuel_StartMult", Settings_Sv, true)
    MPnl[2]:AddItem(Sldr)
    ElTbl.Fuel_StartMult = Sldr
    local MPnl = VC.Add_El_Panel(List_1_fuel, {0.5, 0.5}, 32, true)
    local Sldr = VC.Add_El_Slider("Refuel_Mult_Station", 0, 10, 2, "How fast players are able to refuel vehicles by fuel stations.", "Refuel_Mult_Station", Settings_Sv, true)
    MPnl[1]:AddItem(Sldr)
    ElTbl.Refuel_Mult_Station = Sldr
    local Sldr = VC.Add_El_Slider("Refuel_Mult_Hand", 0, 10, 2, "How fast players are able to refuel vehicles by fuel hand.", "Refuel_Mult_Hand", Settings_Sv, true)
    MPnl[2]:AddItem(Sldr)
    ElTbl.Refuel_Mult_Hand = Sldr
    local CBox = VC.Add_El_Checkbox("Fuel_Pickup_Pickup", "If players are able to pickup the fuel canisters.", "Fuel_Pickup_Pickup", Settings_Sv, true)
    List_1_fuel:AddItem(CBox)
    ElTbl.Fuel_Pickup_Pickup = CBox
    local CBox = VC.Add_El_Checkbox("Fuel_Pickup_Explode", "If players are able to pickup the fuel canisters.", "Fuel_Pickup_Explode", Settings_Sv, true)
    List_1_fuel:AddItem(CBox)
    ElTbl.Fuel_Pickup_Explode = CBox
    local MPnl = VC.Add_El_Panel(List_1_fuel, {0.5, 0.5}, 18, true)
    local CBox = VC.Add_El_Checkbox("Fuel_Pickup_Touch", "Should the jerrycan instanly refuel the vehicle when it touches it?", "Fuel_Pickup_Touch", Settings_Sv, true)
    MPnl[1]:AddItem(CBox)
    ElTbl.Fuel_Pickup_Touch = CBox
    local CBox = VC.Add_El_Checkbox("Fuel_Pickup_Touch_Elec", "Should the jerrycan instanly refuel the vehicle when it touches it? Only for eletric vehicles", "Fuel_Pickup_Touch_Elec", Settings_Sv, true)
    MPnl[2]:AddItem(CBox)
    ElTbl.Fuel_Pickup_Touch_Elec = CBox
    local CBox = VC.Add_El_Checkbox("Fuel_Pickups_Beside_Stations", "Should a jerrycan be spawned besides the fuel station?", "Fuel_Pickups_Beside_Stations", Settings_Sv, true)
    List_1_fuel:AddItem(CBox)
    ElTbl.Fuel_Pickups_Beside_Stations = CBox
    local MPnl = VC.Add_El_Panel(List_1_fuel, {1 / 3, 1 / 3, 1 / 3}, 32, true)
    local Sldr = VC.Add_El_Slider(VC.Lng("Price") .. " " .. VC.Lng("Petrol"), 0, 100, 3, "The price of the fuel per liter.", "Fuel_PPL_0", Settings_Sv, true)
    MPnl[1]:AddItem(Sldr)
    ElTbl.Fuel_PPL_0 = Sldr
    local Sldr = VC.Add_El_Slider(VC.Lng("Price") .. " " .. VC.Lng("Diesel"), 0, 100, 3, "The price of the fuel per liter.", "Fuel_PPL_1", Settings_Sv, true)
    MPnl[2]:AddItem(Sldr)
    ElTbl.Fuel_PPL_1 = Sldr
    local Sldr = VC.Add_El_Slider(VC.Lng("Price") .. " " .. VC.Lng("Electricity"), 0, 100, 3, "The price of the fuel per liter.", "Fuel_PPL_2", Settings_Sv, true)
    MPnl[3]:AddItem(Sldr)
    ElTbl.Fuel_PPL_2 = Sldr
    local MPnl = VC.Add_El_Panel(List_1_3, {0.5, 0.5}, 32, true)
    local SNLbl = vgui.Create("DLabel")
    SNLbl:SetText("")
    SNLbl:SetTall(8)
    MPnl[1]:AddItem(SNLbl)
    local CBox = VC.Add_El_Checkbox("Horn", "This will allow people to use cars horn.", "Horn_Enabled", Settings_Sv, true)
    MPnl[1]:AddItem(CBox)
    ElTbl.Horn_Enabled = CBox
    local Sldr = VC.Add_El_Slider("Volume", 0, 1, 1, "How loud the horn will be.", "Horn_Volume", Settings_Sv, true)
    MPnl[2]:AddItem(Sldr)
    ElTbl.Horn_Volume = Sldr
    local CBox = VC.Add_El_Checkbox("DoorSounds", "Emit sounds when a door is being open/closed.", "Door_Sounds", Settings_Sv, true)
    List_1_3:AddItem(CBox)
    ElTbl.Door_Sounds = CBox
    local CBox = VC.Add_El_Checkbox("TruckRevBeep", "While a truck (vehicle bigger than usual or is supporting a truck socket type is considered a truck) it emits a sound.", "Truck_BackUp_Sounds", Settings_Sv, true)
    List_1_3:AddItem(CBox)
    ElTbl.Truck_BackUp_Sounds = CBox
    VC.Add_El_Banner(List_1_4, "Trailer")
    local CBox = VC.Add_El_Checkbox("TrailerAttach", "This will allow you to attach trailers to trucks.", "Trl_Enabled", Settings_Sv, true)
    List_1_4:AddItem(CBox)
    ElTbl.Trl_Enabled = CBox
    local Sldr = VC.Add_El_Slider("Distance", 10, 1000, 0, "How far the trailer should be from the truck to attempt to attach?", "Trl_Dist", Settings_Sv, true)
    List_1_4:AddItem(Sldr)
    ElTbl.Trl_Dist = Sldr
    local Sldr = VC.Add_El_Slider("TrailerAttachConStrengthM", 0, 1, 2, "How strong the connection is, before it breaks. Multiplier.", "Trl_Strength", Settings_Sv, true)
    List_1_4:AddItem(Sldr)
    ElTbl.Trl_Strength = Sldr
    local CBox = VC.Add_El_Checkbox("TrailersCanAtchToReg", "All regular (none big) vehicles will have an attachment point setup near its end, to simulate a hook.", "Trl_Enabled_Reg", Settings_Sv, true)
    List_1_4:AddItem(CBox)
    ElTbl.Trl_Enabled_Reg = CBox
    VC.Add_El_Banner(List_1_4, "Other")
    local CBox = VC.Add_El_Checkbox("PlayersGetDamagedOnExit", "It is not a good idea to jump out of the car while its moving, you could get hurt.", "Exit_Velocity_Damage", Settings_Sv, true)
    List_1_4:AddItem(CBox)
    ElTbl.Exit_Velocity_Damage = CBox
    local CBox = VC.Add_El_Checkbox("DriveBy", "Allow passengers to shoot out the window of their seats.", "DriveBy", Settings_Sv, true)
    List_1_4:AddItem(CBox)
    ElTbl.DriveBy = CBox
    local CBox = VC.Add_El_Checkbox("DriveBy_NoSwitch", "Will not allow to switch weapons while in drive by mode.", "DriveBy_NoSwitch", Settings_Sv, true)
    List_1_4:AddItem(CBox)
    ElTbl.DriveBy_NoSwitch = CBox
    local MPnl = VC.Add_El_Panel(List_1_4, {0.5, 0.5}, 18, true)
    local CBox = VC.Add_El_Checkbox("Cruise", "This will allow people to use cars cruise.", "Cruise_Enabled", Settings_Sv, true)
    MPnl[1]:AddItem(CBox)
    ElTbl.Cruise_Enabled = CBox
    local CBox = VC.Add_El_Checkbox("OffOnExit", "Turn off the cruise control when the driver exits the vehicle.", "Cruise_OffOnExit", Settings_Sv, true)
    MPnl[2]:AddItem(CBox)
    ElTbl.Cruise_OffOnExit = CBox
    local MPnl = VC.Add_El_Panel(List_1_4, {0.5, 0.5}, 18, true)
    local CBox = VC.Add_El_Checkbox("Exhaust", "Exhaust effect when a vehicle is idle or in movement.", "Exhaust_Effect", Settings_Sv, true)
    MPnl[1]:AddItem(CBox)
    ElTbl.Exhaust_Effect = CBox
    local CBox = VC.Add_El_Checkbox("Exhaust_Effect_BackFireHealthLow", "Emit exhaust when engine is damaged.", "Exhaust_Effect_BackFireHealthLow", Settings_Sv, true)
    MPnl[2]:AddItem(CBox)
    ElTbl.Exhaust_Effect_BackFireHealthLow = CBox
    local MPnl = VC.Add_El_Panel(List_1_4, {0.5, 0.5}, 36, true)
    local CBox = VC.Add_El_Checkbox("PassengerSeats", "Allows a vehicle to have passenger seats.", "Passenger_Seats", Settings_Sv, true)
    MPnl[1]:AddItem(CBox)
    ElTbl.Passenger_Seats = CBox
    local CBox = VC.Add_El_Checkbox("AbleToSwitch", "People are allowed to switched seats from within the vehicle.", "Seat_Switch", Settings_Sv, true)
    MPnl[2]:AddItem(CBox)
    ElTbl.Seat_Switch = CBox
    local CBox = VC.Add_El_Checkbox("DriverUsesCustomExitPos", "Should we override the default player exit positioning as well?", "ExitPoint_OverrideDriver", Settings_Sv, true)
    MPnl[1]:AddItem(CBox)
    ElTbl.ExitPoint_OverrideDriver = CBox
    VC.Add_El_Banner(List_1_4, "Minor")
    local MPnl = VC.Add_El_Panel(List_1_4, {0.5, 0.5}, 18, true)
    local CBox = VC.Add_El_Checkbox("OverrideDefaultSteeringLockOnExit", "Overrides the default steering method of garrysmod when a driver exits.", "Wheel_Lock", Settings_Sv, true)
    MPnl[1]:AddItem(CBox)
    ElTbl.Wheel_Lock = CBox
    local CBox = VC.Add_El_Checkbox("OverrideDefaultBrakesOnExit", "Overrides the default always brake method of garrysmod when a drive exits.", "Brake_Lock", Settings_Sv, true)
    MPnl[2]:AddItem(CBox)
    ElTbl.Brake_Lock = CBox
    local CBox = VC.Add_El_Checkbox("MatchPlayerSpeedExit", "Players speed gets set to the ones of a car when they exit a vehicle.", "Exit_Velocity", Settings_Sv, true)
    List_1_4:AddItem(CBox)
    ElTbl.Exit_Velocity = CBox
    local CBox = VC.Add_El_Checkbox("NoCollidePlyOnExit", "This allows for more stable exit.", "Exit_NoCollision", Settings_Sv, true)
    List_1_4:AddItem(CBox)
    ElTbl.Exit_NoCollision = CBox
    local CBox = VC.Add_El_Checkbox("LockFromInside", "Allows to lock the vehicle form within.", "Lock_From_Inside", Settings_Sv, true)
    List_1_4:AddItem(CBox)
    ElTbl.Lock_From_Inside = CBox
    local CBox = VC.Add_El_Checkbox("ThirdPersonViewSeeThroughProps", "Should the third person view of playeres allow them to see through props or not.", "TP_Props", Settings_Sv, true)
    List_1_4:AddItem(CBox)
    ElTbl.TP_Props = CBox
    local MPnl = VC.Add_El_Panel(List_1_4, {0.5, 0.5}, 18, true)
    local SNLbl = vgui.Create("DLabel")
    SNLbl:SetText("Currency")
    MPnl[1]:AddItem(SNLbl)
    local CBox_Currency = vgui.Create("DComboBox", Pnl)
    MPnl[2]:AddItem(CBox_Currency)
    for k, v in pairs(VC.Constant_Currency) do
        CBox_Currency:AddChoice(v.shrt .. " (" .. v.symbol .. ") " .. v.name)
    end

    CBox_Currency.OnSelect = function(idx, val) Settings_Sv["Currency"] = val end
    local CBox = VC.Add_El_Checkbox("Indication", 'Things such as popuplights and other VCMod related bodygroup and pose paramter manipulation.', "Indication", Settings_Sv, true)
    List_1_4:AddItem(CBox)
    ElTbl.Indication = CBox
    local CBox = VC.Add_El_Checkbox("Unlock vehicle on use by person who locked from inside", 'If the vehicle is locked from within, should we allow the person who locked it and then exited it to unlock it, regardless if he is the owner or not?', "UnlockVehicleOnSpawnerUsePostLock", Settings_Sv, true)
    List_1_4:AddItem(CBox)
    ElTbl.UnlockVehicleOnSpawnerUsePostLock = CBox
    local SNLbl = vgui.Create("DLabel")
    SNLbl:SetText("")
    SNLbl:SetTall(4)
    List_1_5:AddItem(SNLbl)
    VC.Add_El_Banner(List_1_5, "Health")
    local CBox = VC.Add_El_Checkbox("Repairing", "Emit effects while repairing.", "Effect_Repair", Settings_Sv, true)
    List_1_5:AddItem(CBox)
    ElTbl.Effect_Repair = CBox
    local CBox = VC.Add_El_Checkbox("Light_Damage", "Emit effects when a light gets damaged/fixed.", "Effect_Light", Settings_Sv, true)
    List_1_5:AddItem(CBox)
    ElTbl.Effect_Light = CBox
    local CBox = VC.Add_El_Checkbox("Light_Damaged", "Emit sparks out of lights if they are damaged and are attempted to be used.", "Effect_Light_Damaged", Settings_Sv, true)
    List_1_5:AddItem(CBox)
    ElTbl.Effect_Light_Damaged = CBox
    local CBox = VC.Add_El_Checkbox("Exhaust_Damage", "Emit effects when an exhaust is damaged/fixed.", "Effect_Exhaust", Settings_Sv, true)
    List_1_5:AddItem(CBox)
    ElTbl.Effect_Exhaust = CBox
    local CBox = VC.Add_El_Checkbox("Wheel_Damage", "Emit effects when an tire is damaged/fixed.", "Effect_Wheel", Settings_Sv, true)
    List_1_5:AddItem(CBox)
    ElTbl.Effect_Wheel = CBox
    local CBox = VC.Add_El_Checkbox("Damage_Sparks_Damage", "Emit sparks when vehicle collides with something in the collision spot.", "Effect_Damage_Sparks", Settings_Sv, true)
    List_1_5:AddItem(CBox)
    ElTbl.Effect_Damage_Sparks = CBox
    local CBox = VC.Add_El_Checkbox("Explosion_Custom", "Uses custom explosion effect.", "Effect_Explosion_Custom", Settings_Sv, true)
    List_1_5:AddItem(CBox)
    ElTbl.Effect_Explosion_Custom = CBox
    VC.Add_El_Banner(List_1_5, "Other")
    local CBox = VC.Add_El_Checkbox("Exhaust_Custom", "Uses custom exhaust effects.", "Effect_Exhaust_Custom", Settings_Sv, true)
    List_1_5:AddItem(CBox)
    ElTbl.Effect_Exhaust_Custom = CBox
    local CBox = VC.Add_El_Checkbox("Brake_Effects", "Enabled effects while braking.", "Effect_Slide", Settings_Sv, true)
    List_1_5:AddItem(CBox)
    ElTbl.Effect_Slide = CBox
    local CBox = VC.Add_El_Checkbox("TireTracks", "Enabled tiretracks for all players (players can not override it on their own anymore).", "Tiretracks", Settings_Sv, true)
    List_1_5:AddItem(CBox)
    ElTbl.Tiretracks = CBox
    local Btn = vgui.Create("VC_Button")
    Btn:SetColor(VC.Color.Btn_Add)
    Btn:SetSize(75, 20)
    Btn:SetPos(Pnl:GetWide() / 2 - 112.25, Pnl:GetTall() - 20)
    Btn:SetText(VC.Lng("Save"))
    Btn:SetParent(Pnl)
    Btn:SetToolTip("Save the settings.")
    Btn.DoClick = function()
        if VC.CanEditAdminSettings(LocalPlayer()) then
            net.Start("VC_SendSettingsToServer")
            net.WriteTable(Settings_Sv)
            net.SendToServer()
            VCPopup("SettingsSaved", "check")
        end
    end

    local Btn = vgui.Create("VC_Button")
    Btn:SetColor(VC.Color.Btn_Orn)
    Btn:SetSize(75, 20)
    Btn:SetPos(Pnl:GetWide() / 2 - 37.25, Pnl:GetTall() - 20)
    Btn:SetText(VC.Lng("Reset"))
    Btn:SetParent(Pnl)
    Btn:SetToolTip("Reset all settings to their default values.")
    Btn.DoClick = function()
        if VC.CanEditAdminSettings(LocalPlayer()) then
            RunConsoleCommand("VC_ResetSettings")
            if VC.Menu_Panel then VC.Menu_Panel.VC_Refresh_Panel = true end
            VCPopup("SettingsReset", "check")
        end
    end

    local Btn = vgui.Create("VC_Button")
    Btn:SetColor(VC.Color.Btn_Spw)
    Btn:SetPos(Pnl:GetWide() / 2 + 37.25, Pnl:GetTall() - 20)
    Btn:SetSize(75, 20)
    Btn:SetText(VC.Lng("Load"))
    Btn:SetParent(Pnl)
    Btn:SetToolTip("Load settings from the server.")
    Btn.DoClick = function()
        if VC.CanEditAdminSettings(LocalPlayer()) then
            RunConsoleCommand("VC_GetSettings_Sv")
            VCPopup("LoadedSettingsFromServer", "check")
        end
    end

    if VC.CanEditAdminSettings(LocalPlayer()) then RunConsoleCommand("VC_GetSettings_Sv") end
    local X, Y = List:GetPos()
    local Sx, Sy = List:GetSize()
    Pnl.Paint = function(obj, Sx, Sy)
        draw.RoundedBox(0, X, Y, Sx, Sy, Color(0, 0, 0, 100))
        draw.DrawText(VC.Lng("OptOnly_Admin"), "VC_Dev_Text", List:GetWide() / 2, 5, VC.Color.Blue, TEXT_ALIGN_CENTER)
    end

    Pnl.Think = function()
        if VC.Settings_TempTbl then
            CBox_Currency:ChooseOptionID(VC.Settings_TempTbl.Currency or 1)
            for k, v in pairs(VC.Settings_TempTbl) do
                if ElTbl[k] then ElTbl[k]:SetValue(v) end
                Settings_Sv[k] = v
            end

            VC.Settings_TempTbl = nil
        end
    end
    return Draw
end

VC.Menu_Items_A.Options = {"Options", BuildMenu}
local function BuildMenu(Pnl)
    local Settings_Sv = {}
    local ElTbl = {}
    Pnl.FrameRate = VGUIFrameTime() - (Pnl.FrameTime or 0)
    Pnl.FrameTime = VGUIFrameTime()
    local Horz = vgui.Create("DHorizontalScroller", Pnl)
    Horz:SetSize(Pnl:GetWide() - 80, 100)
    Horz:AlignTop(30)
    Horz:AlignLeft(40)
    Horz:SetOverlap(0)
    Horz:NoClipping(true)
    local Btn_Prev = vgui.Create("DButton", Pnl)
    Btn_Prev:SetText("")
    Btn_Prev:SetSize(15, Horz:GetTall())
    Btn_Prev:AlignLeft(0)
    Btn_Prev:AlignTop(30)
    local Btn_Next = vgui.Create("DButton", Pnl)
    Btn_Next:SetText("")
    Btn_Next:SetSize(15, Horz:GetTall())
    Btn_Next:AlignRight(0)
    Btn_Next:AlignTop(30)
    function HorzResetAlpha(int)
        Horz:AlphaTo(0, 0, 0)
        Horz:AlphaTo(255, int or 0.5, 0)
        Btn_Prev:AlphaTo(0, 0, 0)
        Btn_Prev:AlphaTo(255, int or 0.5, 0)
        Btn_Next:AlphaTo(0, 0, 0)
        Btn_Next:AlphaTo(255, int or 0.5, 0)
    end

    HorzResetAlpha(1)
    local Pnls = {}
    local function FillData()
        for k, v in pairs(Pnls) do
            if IsValid(v) then v:Remove() end
        end

        Pnls = {}
        for k, v in pairs(ents.FindByClass("vc_npc_cardealer")) do
            local mdl = vgui.Create("DModelPanel", Pnl)
            mdl:SetModel(v:GetModel())
            mdl:SetCamPos(Vector(30, 0, 62))
            mdl:SetLookAt(Vector(0, 0, 62))
            mdl:SetSize(150, 150)
            local RandMove = math.Rand(1.5, 2.5)
            function mdl:LayoutEntity()
                mdl:SetLookAt(Vector(0, math.sin(CurTime() * RandMove), 62))
                return
            end

            local function DoClick()
                local DDM = VC.DermaMenu("CD ID: " .. v:GetNWInt("VC_Int"))
                DDM:AddButton("Open edit panel", function()
                    if IsValid(v) and VC.CanEditAdminSettings(LocalPlayer()) then
                        net.Start("VC_CD_RequestOpen")
                        net.WriteEntity(v)
                        net.SendToServer()
                    else
                        VCPopup("AccessRestricted", "cross")
                    end
                end):SetImage("icon16/application.png")

                DDM:AddButton("Trace position", function()
                    if IsValid(v) and VC.CanEditAdminSettings(LocalPlayer()) then
                        net.Start("VC_CD_TracePos")
                        net.WriteEntity(v)
                        net.SendToServer()
                    else
                        VCPopup("AccessRestricted", "cross")
                    end
                end):SetImage("icon16/map.png")

                DDM:AddButton("Delete", function()
                    if IsValid(v) and VC.CanEditAdminSettings(LocalPlayer()) then
                        net.Start("VC_CD_Delete")
                        net.WriteEntity(v)
                        net.SendToServer()
                        timer.Simple(0.5, function() FillData() end)
                    else
                        VCPopup("AccessRestricted", "cross")
                    end
                end):SetImage("icon16/delete.png")

                DDM:Open()
            end

            mdl.DoClick = DoClick
            mdl.DoRightClick = DoClick
            local Nm = VC.getName(v, VC.CD.Default.Name)
            local clr = VC.Color.Main
            mdl.PaintOver = function(obj, Sx, Sy)
                local tclr = table.Copy(clr)
                draw.RoundedBox(0, 0, 0, Sx, 25, clr)
                if not mdl:IsHovered() then draw.RoundedBox(0, 0, 0, Sx, Sy, Color(0, 0, 0, 55)) end
                if mdl:IsDown() then draw.RoundedBox(0, 0, 0, Sx, Sy, Color(0, 100, 100, 55)) end
                draw.DrawText(Nm, nil, Sx / 2, 7, table.Copy(VC.Color.Blue), TEXT_ALIGN_CENTER)
                local pos = 0
                if mdl:IsHovered() then
                    tclr = table.Copy(VC.Color.Blue)
                    surface.SetDrawColor(tclr)
                    surface.DrawLine(pos, 0, pos + Sx - 1, 0)
                    surface.DrawLine(pos, Sy - 1, pos + Sx - 1, Sy - 1)
                    surface.DrawLine(pos, 0, pos, Sy - 1)
                    surface.DrawLine(pos + Sx - 1, 0, pos + Sx - 1, Sy - 1)
                end
            end

            table.insert(Pnls, mdl)
            Horz:AddPanel(mdl)
        end
    end

    FillData()
    Horz.Think = function()
        if Btn_Prev:IsDown() then
            Horz.OffsetX = Horz.OffsetX - (2000 * Pnl.FrameRate)
            Horz:InvalidateLayout(true)
        end

        if Btn_Next:IsDown() then
            Horz.OffsetX = Horz.OffsetX + (2000 * Pnl.FrameRate)
            Horz:InvalidateLayout(true)
        end
    end

    function Horz:OnMouseWheeled(delta)
        Horz.OffsetX = Horz.OffsetX + delta * -100
        self:InvalidateLayout(true)
        return true
    end

    function Horz:PerformLayout()
        local w, h = self:GetSize()
        local x = 0
        self.pnlCanvas:SetTall(h)
        if self.Panels then
            for k, v in pairs(self.Panels) do
                if IsValid(v) then
                    v:SetPos(x, 0)
                    v:SetTall(h)
                    v:ApplySchemeSettings()
                    x = x + v:GetWide() - self.m_iOverlap
                end
            end

            self.pnlCanvas:SetWide(x + self.m_iOverlap)
            if w < self.pnlCanvas:GetWide() then
                self.OffsetX = math.Clamp(self.OffsetX, 0, self.pnlCanvas:GetWide() - self:GetWide())
            else
                self.OffsetX = 0
            end

            self.pnlCanvas.x = Lerp(0.1, self.pnlCanvas.x, -self.OffsetX)
        end

        self.btnLeft:SetVisible(false)
        self.btnRight:SetVisible(false)
        Btn_Prev:SetVisible(self.pnlCanvas.x < -25)
        Btn_Next:SetVisible(self.pnlCanvas.x + self.pnlCanvas:GetWide() > (self:GetWide() + 25))
    end

    Btn_Next.Paint = function(obj, Sx, Sy)
        surface.SetDrawColor(255, 255, 255, obj:IsHovered() and 255 or 55)
        surface.SetMaterial(VC.Material.icon_right)
        surface.DrawTexturedRect(0, 10, Sx, Sy - 20)
    end

    Btn_Prev.Paint = function(obj, Sx, Sy)
        surface.SetDrawColor(255, 255, 255, obj:IsHovered() and 255 or 55)
        surface.SetMaterial(VC.Material.icon_left)
        surface.DrawTexturedRect(0, 10, Sx, Sy - 20)
    end

    local clr = VC.Color.Main
    local nvf = VC.Lng("NoCDFound")
    Horz.Paint = function(obj, Sx, Sy)
        draw.RoundedBox(0, 0, 0, Sx, Sy, clr)
        surface.SetDrawColor(clr)
        surface.SetMaterial(VC.Material.Fade)
        surface.DrawTexturedRectRotated(Sx + VC.FadeW / 2, Sy / 2, VC.FadeW, Sy, 0)
        surface.DrawTexturedRectRotated(-VC.FadeW / 2, Sy / 2, VC.FadeW, Sy, 180)
        if #Pnls == 0 then draw.DrawText(nvf, "VC_Big_Italic", Sx / 2, 35, VC.Color.Blue, TEXT_ALIGN_CENTER) end
    end

    local List = VC.Add_El_List(0, 35 + 100, Pnl:GetWide(), Pnl:GetTall() - 35)
    List:SetParent(Pnl)
    local Add = vgui.Create("VC_Button")
    Add:SetColor(VC.Color.Btn_Add)
    Add:SetText(VC.Lng("Add"))
    List:AddItem(Add)
    Add:SetToolTip("Create a new car dealer.")
    Add.DoClick = function()
        if VC.CanEditAdminSettings(LocalPlayer()) then
            net.Start("VC_CD_Add")
            net.SendToServer()
            timer.Simple(0.5, function() FillData() end)
        else
            VCPopup("AccessRestricted", "cross")
        end
    end

    local SNLbl = vgui.Create("DLabel")
    SNLbl:SetText("")
    SNLbl:SetTall(2)
    List:AddItem(SNLbl)
    local Respawn = vgui.Create("VC_Button")
    Respawn:SetColor(VC.Color.Btn_Spw)
    Respawn:SetText(VC.Lng("Respawn"))
    List:AddItem(Respawn)
    Respawn:SetToolTip("Respawn all car dealers on the map.")
    Respawn.DoClick = function()
        if VC.CanEditAdminSettings(LocalPlayer()) then
            net.Start("VC_CD_Refresh")
            net.SendToServer()
            timer.Simple(0.5, function() FillData() end)
        else
            VCPopup("AccessRestricted", "cross")
        end
    end

    local SNLbl = vgui.Create("DLabel")
    SNLbl:SetText("")
    SNLbl:SetTall(10)
    List:AddItem(SNLbl)
    local CBox = VC.Add_El_Checkbox("Enabled", "Allows regular people to use car dealers.", "CD_Enabled", Settings_Sv, true)
    List:AddItem(CBox)
    ElTbl.CD_Enabled = CBox
    local MPnl = VC.Add_El_Panel(List, {0.3, 0.35, 0.35}, 32, true)
    local SNLbl = vgui.Create("DLabel")
    SNLbl:SetText("")
    SNLbl:SetTall(8)
    MPnl[1]:AddItem(SNLbl)
    local CBox = VC.Add_El_Checkbox("TowingCost", "Vehicles will be towed for money if they are too far away or not found.", "CD_Towing", Settings_Sv, true)
    MPnl[1]:AddItem(CBox)
    ElTbl.CD_Towing = CBox
    local Sldr = VC.Add_El_Slider("Price", 50, 50000, 0, "How much towing will cost.", "CD_TowingPrice", Settings_Sv, true)
    MPnl[2]:AddItem(Sldr)
    ElTbl.CD_TowingPrice = Sldr
    local Sldr = VC.Add_El_Slider("Distance", 500, 50000, 0, "Minimum distance the car has to be for it to be able to be stored for free.", "CD_Distance", Settings_Sv, true)
    MPnl[3]:AddItem(Sldr)
    ElTbl.CD_Distance = Sldr
    local MPnl = VC.Add_El_Panel(List, {0.65, 0.35}, 32, true)
    local SNLbl = vgui.Create("DLabel")
    SNLbl:SetText("")
    SNLbl:SetTall(8)
    MPnl[1]:AddItem(SNLbl)
    local CBox = VC.Add_El_Checkbox("TowingNotAllowTooFar", "Do not allow the car to be towed back if its too far.", "CD_TowingTooFar", Settings_Sv, true)
    MPnl[1]:AddItem(CBox)
    ElTbl.CD_TowingTooFar = CBox
    local Sldr = VC.Add_El_Slider("Distance", 500, 50000, 0, "If the distance is greater than this the towing will not be allowed.", "CD_TowingTooFar_Distance", Settings_Sv, true)
    MPnl[2]:AddItem(Sldr)
    ElTbl.CD_TowingTooFar_Distance = Sldr
    local MPnl = VC.Add_El_Panel(List, {0.5, 0.5}, 32, true)
    local SNLbl = vgui.Create("DLabel")
    SNLbl:SetText("")
    SNLbl:SetTall(8)
    MPnl[1]:AddItem(SNLbl)
    local CBox = VC.Add_El_Checkbox("TestDrive", "Allow players to test drive their vehicle for a limited time.", "CD_TestDrive", Settings_Sv, true)
    MPnl[1]:AddItem(CBox)
    ElTbl.CD_TestDrive = CBox
    local Sldr = VC.Add_El_Slider("Time", 5, 60 * 10, 0, "For this amount of time.", "CD_TestDriveTime", Settings_Sv, true)
    MPnl[2]:AddItem(Sldr)
    ElTbl.CD_TestDriveTime = Sldr
    local MPnl = VC.Add_El_Panel(List, {0.5, 0.5}, 32, true)
    local SNLbl = vgui.Create("DLabel")
    SNLbl:SetText("")
    SNLbl:SetTall(8)
    MPnl[1]:AddItem(SNLbl)
    local CBox = VC.Add_El_Checkbox("LimitReturnDistance", "Should we limit the return distance of the car from a car dealer?", "CD_ReturnLimitByDistance", Settings_Sv, true)
    MPnl[1]:AddItem(CBox)
    ElTbl.CD_ReturnLimitByDistance = CBox
    local Sldr = VC.Add_El_Slider("Distance", 500, 50000, 0, "The distance needed.", "CD_ReturnLimitByDistanceDist", Settings_Sv, true)
    MPnl[2]:AddItem(Sldr)
    ElTbl.CD_ReturnLimitByDistanceDist = Sldr
    local Sldr = VC.Add_El_Slider("RefundPricePerc", 0, 100, 0, "When selling a car, what the refund price should be from the original price.", "CD_RefundPrice", Settings_Sv, true)
    List:AddItem(Sldr)
    ElTbl.CD_RefundPrice = Sldr
    local CBox = VC.Add_El_Checkbox("OnlyAllowOneCarToBeSpawnedPerCarDealerPerUser", "Only one vehicle can be spawned per car dealer using per one user.", "CD_OnlyAllowOne", Settings_Sv, true)
    List:AddItem(CBox)
    ElTbl.CD_OnlyAllowOne = CBox
    local CBox = VC.Add_El_Checkbox("VehiclesCanBeRemovedByTool", "If this is unchecked you are unable to remove your vehicles using a remover tool.", "CD_Veh_RemTool", Settings_Sv, true)
    List:AddItem(CBox)
    ElTbl.CD_Veh_RemTool = CBox
    local CBox = VC.Add_El_Checkbox("Humming", "Car dealers hum once in a while.", "CD_Hum", Settings_Sv, true)
    List:AddItem(CBox)
    ElTbl.CD_Hum = CBox
    local CBox = VC.Add_El_Checkbox("Persistent", "Will automatically respawn if removed by scripts.", "CD_Persistent", Settings_Sv, true)
    List:AddItem(CBox)
    ElTbl.CD_Persistent = CBox
    local CBox = VC.Add_El_Checkbox("StoreInformation", "This will store all VCMod damage states, remaining fuel amount, etc.", "CD_StoreInfo", Settings_Sv, true)
    List:AddItem(CBox)
    ElTbl.CD_StoreInfo = CBox
    local CBox = VC.Add_El_Checkbox("Unlock vehicle on use by the spawner", "Unlocks vehicle upon use for the player who spawned the vehicle", "CD_UnlockVehicleOnSpawnerUse", Settings_Sv, true)
    List:AddItem(CBox)
    ElTbl.CD_UnlockVehicleOnSpawnerUse = CBox
    local MPnl = VC.Add_El_Panel(List, {0.5, 0.5}, 24, true)
    local CBox = VC.Add_El_Checkbox("AutoEnter", "Automatically enter the spawned vehicle.", "CD_EnterVehicleOnSpawn", Settings_Sv, true)
    MPnl[1]:AddItem(CBox)
    ElTbl.CD_EnterVehicleOnSpawn = CBox
    local CBox = VC.Add_El_Checkbox("AutoReturnOnDisconnect", "Automatically return the spawned vehicles when a player disconnects.", "CD_AutoReturnOnDisconnect", Settings_Sv, true)
    MPnl[2]:AddItem(CBox)
    ElTbl.CD_AutoReturnOnDisconnect = CBox
    local Sldr = VC.Add_El_Slider("TextViewDistance", 50, 5000, 0, "How far the text above the car dealer's heads will be visible.", "CD_Text_Dist", Settings_Sv, true)
    List:AddItem(Sldr)
    ElTbl.CD_Text_Dist = Sldr
    Pnl.Paint = function(obj, Sx, Sy)
        draw.DrawText(VC.Lng("CD_Settings"), "VC_Dev_Text", List:GetWide() / 2, 5, VC.Color.Blue, TEXT_ALIGN_CENTER)
        draw.DrawText(VC.Lng("Map") .. ": " .. game.GetMap(), "VC_Dev_Text", List:GetWide(), 5, VC.Color.Blue, TEXT_ALIGN_RIGHT)
    end

    local Btn = vgui.Create("VC_Button")
    Btn:SetColor(VC.Color.Btn_Add)
    Btn:SetSize(75, 20)
    Btn:SetPos(Pnl:GetWide() / 2 - 112.25, Pnl:GetTall() - 20)
    Btn:SetText(VC.Lng("Save"))
    Btn:SetParent(Pnl)
    Btn:SetToolTip("Save the settings.")
    Btn.DoClick = function()
        if VC.CanEditAdminSettings(LocalPlayer()) then
            net.Start("VC_SendSettingsToServer")
            net.WriteTable(Settings_Sv)
            net.SendToServer()
            VCPopup("SettingsSaved", "check")
        end
    end

    local Btn = vgui.Create("VC_Button")
    Btn:SetColor(VC.Color.Btn_Orn)
    Btn:SetSize(75, 20)
    Btn:SetPos(Pnl:GetWide() / 2 - 37.25, Pnl:GetTall() - 20)
    Btn:SetText(VC.Lng("Reset"))
    Btn:SetParent(Pnl)
    Btn:SetToolTip("Reset all settings to their default values.")
    Btn.DoClick = function()
        if VC.CanEditAdminSettings(LocalPlayer()) then
            RunConsoleCommand("VC_ResetSettings")
            if VC.Menu_Panel then VC.Menu_Panel.VC_Refresh_Panel = true end
            VCPopup("SettingsReset", "check")
        end
    end

    local Btn = vgui.Create("VC_Button")
    Btn:SetColor(VC.Color.Btn_Spw)
    Btn:SetPos(Pnl:GetWide() / 2 + 37.25, Pnl:GetTall() - 20)
    Btn:SetSize(75, 20)
    Btn:SetText(VC.Lng("Load"))
    Btn:SetParent(Pnl)
    Btn:SetToolTip("Load settings from the server.")
    Btn.DoClick = function()
        if VC.CanEditAdminSettings(LocalPlayer()) then
            RunConsoleCommand("VC_GetSettings_Sv")
            VCPopup("LoadedSettingsFromServer", "check")
        end
    end

    if VC.CanEditAdminSettings(LocalPlayer()) then RunConsoleCommand("VC_GetSettings_Sv") end
    VC.CD.MM_Refresh = nil
    Pnl.Think = function()
        if VC.CD.MM_Refresh then
            timer.Simple(0.2, FillData)
            VC.CD.MM_Refresh = nil
        end

        if VC.Settings_TempTbl then
            for k, v in pairs(VC.Settings_TempTbl) do
                if ElTbl[k] then ElTbl[k]:SetValue(v) end
                Settings_Sv[k] = v
            end

            VC.Settings_TempTbl = nil
        end
    end
    return Draw
end

VC.Menu_Items_A.NPC_CD = {"CD_Settings", BuildMenu}
local function BuildMenu(Pnl)
    local Settings_Sv = {}
    local ElTbl = {}
    Pnl.FrameRate = VGUIFrameTime() - (Pnl.FrameTime or 0)
    Pnl.FrameTime = VGUIFrameTime()
    local Horz = vgui.Create("DHorizontalScroller", Pnl)
    Horz:SetSize(Pnl:GetWide() - 80, 100)
    Horz:AlignTop(30)
    Horz:AlignLeft(40)
    Horz:SetOverlap(0)
    Horz:NoClipping(true)
    local Btn_Prev = vgui.Create("DButton", Pnl)
    Btn_Prev:SetText("")
    Btn_Prev:SetSize(15, Horz:GetTall())
    Btn_Prev:AlignLeft(0)
    Btn_Prev:AlignTop(30)
    local Btn_Next = vgui.Create("DButton", Pnl)
    Btn_Next:SetText("")
    Btn_Next:SetSize(15, Horz:GetTall())
    Btn_Next:AlignRight(0)
    Btn_Next:AlignTop(30)
    function HorzResetAlpha(int)
        Horz:AlphaTo(0, 0, 0)
        Horz:AlphaTo(255, int or 0.5, 0)
        Btn_Prev:AlphaTo(0, 0, 0)
        Btn_Prev:AlphaTo(255, int or 0.5, 0)
        Btn_Next:AlphaTo(0, 0, 0)
        Btn_Next:AlphaTo(255, int or 0.5, 0)
    end

    HorzResetAlpha(1)
    local Pnls = {}
    local function FillData()
        for k, v in pairs(Pnls) do
            if IsValid(v) then v:Remove() end
        end

        Pnls = {}
        for k, v in pairs(ents.FindByClass("vc_npc_repair")) do
            local mdl = vgui.Create("DModelPanel", Pnl)
            mdl:SetModel(v:GetModel())
            mdl:SetCamPos(Vector(30, 0, 62))
            mdl:SetLookAt(Vector(0, 0, 62))
            mdl:SetSize(150, 150)
            local RandMove = math.Rand(1.5, 2.5)
            function mdl:LayoutEntity()
                mdl:SetLookAt(Vector(0, math.sin(CurTime() * RandMove), 62))
                return
            end

            local function DoClick()
                local DDM = VC.DermaMenu("RM ID: " .. v:GetNWInt("VC_Int"))
                DDM:AddButton("Open edit panel", function()
                    if IsValid(v) and VC.CanEditAdminSettings(LocalPlayer()) then
                        net.Start("VC_RM_RequestOpen")
                        net.WriteEntity(v)
                        net.SendToServer()
                    else
                        VCPopup("AccessRestricted", "cross")
                    end
                end):SetImage("icon16/application.png")

                DDM:AddButton("Trace position", function()
                    if IsValid(v) and VC.CanEditAdminSettings(LocalPlayer()) then
                        net.Start("VC_RM_TracePos")
                        net.WriteEntity(v)
                        net.SendToServer()
                    else
                        VCPopup("AccessRestricted", "cross")
                    end
                end):SetImage("icon16/map.png")

                DDM:AddButton("Delete", function()
                    if IsValid(v) and VC.CanEditAdminSettings(LocalPlayer()) then
                        net.Start("VC_RM_Delete")
                        net.WriteEntity(v)
                        net.SendToServer()
                        timer.Simple(0.5, function() FillData() end)
                    else
                        VCPopup("AccessRestricted", "cross")
                    end
                end):SetImage("icon16/delete.png")

                DDM:Open()
            end

            mdl.DoClick = DoClick
            mdl.DoRightClick = DoClick
            local Nm = VC.getName(v, VC.RM.Default.Name)
            local clr = VC.Color.Main
            mdl.PaintOver = function(obj, Sx, Sy)
                local tclr = table.Copy(clr)
                draw.RoundedBox(0, 0, 0, Sx, 25, clr)
                if not mdl:IsHovered() then draw.RoundedBox(0, 0, 0, Sx, Sy, Color(0, 0, 0, 55)) end
                if mdl:IsDown() then draw.RoundedBox(0, 0, 0, Sx, Sy, Color(0, 100, 100, 55)) end
                draw.DrawText(Nm, nil, Sx / 2, 7, table.Copy(VC.Color.Blue), TEXT_ALIGN_CENTER)
                local pos = 0
                if mdl:IsHovered() then
                    tclr = table.Copy(VC.Color.Blue)
                    surface.SetDrawColor(tclr)
                    surface.DrawLine(pos, 0, pos + Sx - 1, 0)
                    surface.DrawLine(pos, Sy - 1, pos + Sx - 1, Sy - 1)
                    surface.DrawLine(pos, 0, pos, Sy - 1)
                    surface.DrawLine(pos + Sx - 1, 0, pos + Sx - 1, Sy - 1)
                end
            end

            table.insert(Pnls, mdl)
            Horz:AddPanel(mdl)
        end
    end

    FillData()
    Horz.Think = function()
        if Btn_Prev:IsDown() then
            Horz.OffsetX = Horz.OffsetX - (2000 * Pnl.FrameRate)
            Horz:InvalidateLayout(true)
        end

        if Btn_Next:IsDown() then
            Horz.OffsetX = Horz.OffsetX + (2000 * Pnl.FrameRate)
            Horz:InvalidateLayout(true)
        end
    end

    function Horz:OnMouseWheeled(delta)
        Horz.OffsetX = Horz.OffsetX + delta * -100
        self:InvalidateLayout(true)
        return true
    end

    function Horz:PerformLayout()
        local w, h = self:GetSize()
        local x = 0
        self.pnlCanvas:SetTall(h)
        if self.Panels then
            for k, v in pairs(self.Panels) do
                if IsValid(v) then
                    v:SetPos(x, 0)
                    v:SetTall(h)
                    v:ApplySchemeSettings()
                    x = x + v:GetWide() - self.m_iOverlap
                end
            end

            self.pnlCanvas:SetWide(x + self.m_iOverlap)
            if w < self.pnlCanvas:GetWide() then
                self.OffsetX = math.Clamp(self.OffsetX, 0, self.pnlCanvas:GetWide() - self:GetWide())
            else
                self.OffsetX = 0
            end

            self.pnlCanvas.x = Lerp(0.1, self.pnlCanvas.x, -self.OffsetX)
        end

        self.btnLeft:SetVisible(false)
        self.btnRight:SetVisible(false)
        Btn_Prev:SetVisible(self.pnlCanvas.x < -25)
        Btn_Next:SetVisible(self.pnlCanvas.x + self.pnlCanvas:GetWide() > (self:GetWide() + 25))
    end

    Btn_Next.Paint = function(obj, Sx, Sy)
        surface.SetDrawColor(255, 255, 255, obj:IsHovered() and 255 or 55)
        surface.SetMaterial(VC.Material.icon_right)
        surface.DrawTexturedRect(0, 10, Sx, Sy - 20)
    end

    Btn_Prev.Paint = function(obj, Sx, Sy)
        surface.SetDrawColor(255, 255, 255, obj:IsHovered() and 255 or 55)
        surface.SetMaterial(VC.Material.icon_left)
        surface.DrawTexturedRect(0, 10, Sx, Sy - 20)
    end

    local clr = VC.Color.Main
    local nvf = VC.Lng("NoneFound")
    Horz.Paint = function(obj, Sx, Sy)
        draw.RoundedBox(0, 0, 0, Sx, Sy, clr)
        surface.SetDrawColor(clr)
        surface.SetMaterial(VC.Material.Fade)
        surface.DrawTexturedRectRotated(Sx + VC.FadeW / 2, Sy / 2, VC.FadeW, Sy, 0)
        surface.DrawTexturedRectRotated(-VC.FadeW / 2, Sy / 2, VC.FadeW, Sy, 180)
        if #Pnls == 0 then draw.DrawText(nvf, "VC_Big_Italic", Sx / 2, 35, VC.Color.Blue, TEXT_ALIGN_CENTER) end
    end

    local List = VC.Add_El_List(0, 35 + 100, Pnl:GetWide(), Pnl:GetTall() - 35)
    List:SetParent(Pnl)
    local Add = vgui.Create("VC_Button")
    Add:SetColor(VC.Color.Btn_Add)
    Add:SetText(VC.Lng("Add"))
    List:AddItem(Add)
    Add:SetToolTip("Create a new repair main.")
    Add.DoClick = function()
        if VC.CanEditAdminSettings(LocalPlayer()) then
            net.Start("VC_RM_Add")
            net.SendToServer()
            timer.Simple(0.5, function() FillData() end)
        else
            VCPopup("AccessRestricted", "cross")
        end
    end

    local SNLbl = vgui.Create("DLabel")
    SNLbl:SetText("")
    SNLbl:SetTall(2)
    List:AddItem(SNLbl)
    local Respawn = vgui.Create("VC_Button")
    Respawn:SetColor(VC.Color.Btn_Spw)
    Respawn:SetText(VC.Lng("Respawn"))
    List:AddItem(Respawn)
    Respawn:SetToolTip("Respawn all repair-men on the map.")
    Respawn.DoClick = function()
        if VC.CanEditAdminSettings(LocalPlayer()) then
            net.Start("VC_RM_Refresh")
            net.SendToServer()
            timer.Simple(0.5, function() FillData() end)
        else
            VCPopup("AccessRestricted", "cross")
        end
    end

    local SNLbl = vgui.Create("DLabel")
    SNLbl:SetText("")
    SNLbl:SetTall(10)
    List:AddItem(SNLbl)
    local CBox = VC.Add_El_Checkbox("Enabled", "Allows regular people to use repair-men.", "RM_Enabled", Settings_Sv, true)
    List:AddItem(CBox)
    ElTbl.RM_Enabled = CBox
    local Sldr = VC.Add_El_Slider("TextViewDistance", 50, 5000, 0, "How far the text above the repair man's heads will be visible.", "RM_Text_Dist", Settings_Sv, true)
    List:AddItem(Sldr)
    ElTbl.RM_Text_Dist = Sldr
    local MPnl = VC.Add_El_Panel(List, {0.5, 0.5}, 32, true)
    local Sldr = VC.Add_El_Slider("DetectDistance", 50, 5000, 0, "How far a car has to be ir order to be detected by the repair-man.", "RM_Distance", Settings_Sv, true)
    MPnl[1]:AddItem(Sldr)
    ElTbl.RM_Distance = Sldr
    local Sldr = VC.Add_El_Slider("RepairSpeedMult", 0, 5, 2, "How fast parts will be repaired", "RM_RepairSpeedMult", Settings_Sv, true)
    MPnl[2]:AddItem(Sldr)
    ElTbl.RM_RepairSpeedMult = Sldr
    local MPnl = VC.Add_El_Panel(List, {0.5, 0.5}, 16, true)
    local CBox = VC.Add_El_Checkbox("Humming", "Will hum once in a while.", "RM_Hum", Settings_Sv, true)
    MPnl[1]:AddItem(CBox)
    ElTbl.RM_Hum = CBox
    local CBox = VC.Add_El_Checkbox("Persistent", "Will automatically respawn if removed by scripts.", "RM_Persistent", Settings_Sv, true)
    MPnl[2]:AddItem(CBox)
    ElTbl.RM_Persistent = CBox
    VC.Add_El_Banner(List, "Prices")
    local Sldr = VC.Add_El_Slider(VC.Lng("Price") .. " " .. string.lower(VC.Lng("Time")), 0, 10, 2, "Price of repairs, per second.", "RM_Repair_Time_Cost", Settings_Sv, true)
    List:AddItem(Sldr)
    ElTbl.RM_Repair_Time_Cost = Sldr
    local Sldr = VC.Add_El_Slider(VC.Lng("Price") .. " " .. string.lower(VC.Lng("Engine")), 0, 100000, 0, "Price of engine full repair. (Price will be twice as low if the engine is not fully destroyed).", "RM_Price_Engine", Settings_Sv, true)
    List:AddItem(Sldr)
    ElTbl.RM_Price_Engine = Sldr
    local Sldr = VC.Add_El_Slider(VC.Lng("Price") .. " " .. string.lower(VC.Lng("Light")), 0, 100000, 0, "Price of a new light.", "RM_Price_Light", Settings_Sv, true)
    List:AddItem(Sldr)
    ElTbl.RM_Price_Light = Sldr
    local Sldr = VC.Add_El_Slider(VC.Lng("Price") .. " " .. string.lower(VC.Lng("Tire")), 0, 100000, 0, "Price of a new tire.", "RM_Price_Tire", Settings_Sv, true)
    List:AddItem(Sldr)
    ElTbl.RM_Price_Tire = Sldr
    local Sldr = VC.Add_El_Slider(VC.Lng("Price") .. " " .. string.lower(VC.Lng("Exhaust")), 0, 100000, 0, "Price of a new exhaust pipe.", "RM_Price_Exhaust", Settings_Sv, true)
    List:AddItem(Sldr)
    ElTbl.RM_Price_Exhaust = Sldr
    Pnl.Paint = function(obj, Sx, Sy)
        draw.DrawText(VC.Lng("RM_Settings"), "VC_Dev_Text", List:GetWide() / 2, 5, VC.Color.Blue, TEXT_ALIGN_CENTER)
        draw.DrawText(VC.Lng("Map") .. ": " .. game.GetMap(), "VC_Dev_Text", List:GetWide(), 5, VC.Color.Blue, TEXT_ALIGN_RIGHT)
    end

    local Btn = vgui.Create("VC_Button")
    Btn:SetColor(VC.Color.Btn_Add)
    Btn:SetSize(75, 20)
    Btn:SetPos(Pnl:GetWide() / 2 - 112.25, Pnl:GetTall() - 20)
    Btn:SetText(VC.Lng("Save"))
    Btn:SetParent(Pnl)
    Btn:SetToolTip("Save the settings.")
    Btn.DoClick = function()
        if VC.CanEditAdminSettings(LocalPlayer()) then
            net.Start("VC_SendSettingsToServer")
            net.WriteTable(Settings_Sv)
            net.SendToServer()
            VCPopup("SettingsSaved", "check")
        end
    end

    local Btn = vgui.Create("VC_Button")
    Btn:SetColor(VC.Color.Btn_Orn)
    Btn:SetSize(75, 20)
    Btn:SetPos(Pnl:GetWide() / 2 - 37.25, Pnl:GetTall() - 20)
    Btn:SetText(VC.Lng("Reset"))
    Btn:SetParent(Pnl)
    Btn:SetToolTip("Reset all settings to their default values.")
    Btn.DoClick = function()
        if VC.CanEditAdminSettings(LocalPlayer()) then
            RunConsoleCommand("VC_ResetSettings")
            if VC.Menu_Panel then VC.Menu_Panel.VC_Refresh_Panel = true end
            VCPopup("SettingsReset", "check")
        end
    end

    local Btn = vgui.Create("VC_Button")
    Btn:SetColor(VC.Color.Btn_Spw)
    Btn:SetPos(Pnl:GetWide() / 2 + 37.25, Pnl:GetTall() - 20)
    Btn:SetSize(75, 20)
    Btn:SetText(VC.Lng("Load"))
    Btn:SetParent(Pnl)
    Btn:SetToolTip("Load settings from the server.")
    Btn.DoClick = function()
        if VC.CanEditAdminSettings(LocalPlayer()) then
            RunConsoleCommand("VC_GetSettings_Sv")
            VCPopup("LoadedSettingsFromServer", "check")
        end
    end

    if VC.CanEditAdminSettings(LocalPlayer()) then RunConsoleCommand("VC_GetSettings_Sv") end
    VC.CD.MM_Refresh = nil
    Pnl.Think = function()
        if VC.Settings_TempTbl then
            for k, v in pairs(VC.Settings_TempTbl) do
                if ElTbl[k] then ElTbl[k]:SetValue(v) end
                Settings_Sv[k] = v
            end

            VC.Settings_TempTbl = nil
        end
    end
    return Draw
end

VC.Menu_Items_A.NPC_RM = {"RepairMan", BuildMenu}

if not VC.SurfaceTireTracks then VC.SurfaceTireTracks = {} end
function VC.HandleTireTrackData(ent, EntLN)
    if not VC.GetDataGeneral then return end
    if VC.getSetting("TireTracks_Enabled") and VC.getServerSetting("Tiretracks") and (ent.VC_SlidingData or VC.getSetting("TireTracks_Sparks") and ent.VC_WheelSparkTable) then
        local dist = ent:GetPos():Distance(VC.GetViewPos())
        if dist > VC.getSetting("TireTracks_Dist", 5000) then return end
        local detail = (1 + (100 - VC.getSetting("TireTracks_Detail", 75)) / 5) * 3
        local wheelData, isBike = VC.getWheelData(ent)
        for k, wheel in pairs(wheelData) do
            if ent.VC_SlidingData and ent.VC_SlidingData[k] or ent.VC_WheelSparkTable and ent.VC_WheelSparkTable[k] then
                local mrand = ent.VC_SlidingData and ent.VC_SlidingData[k] or ent.VC_WheelSparkTable and math.Round(ent.VC_WheelSparkTable[k].Tmr)
                local key = EntLN .. "_" .. k .. "_" .. mrand
                if not VC.SurfaceTireTracks[key] then VC.SurfaceTireTracks[key] = {} end
                local wheel = VC.Wheels[k]
                local Vec = nil
                if ent:LookupAttachment(wheel) ~= 0 then Vec = ent:GetAttachment(ent:LookupAttachment(wheel)).Pos end
                if Vec then
                    local cur = VC.SurfaceTireTracks[key]
                    local prev = cur[#cur]
                    local olpos = prev and prev.wpos
                    if not olpos or olpos:Distance(Vec) > detail then
                        local VecLocal = ent:WorldToLocal(Vec)
                        if isBike then VecLocal.x = 0 end
                        Vec = ent:LocalToWorld(VecLocal)
                        local ors = VC.GetDataGeneral(VC.GetModel(ent))
                        if ors then
                            if k == 1 or k == 2 then
                                ors = ors.w_r_f
                            else
                                ors = ors.w_r_r
                            end
                        end

                        local Trc = util.TraceLine({
                            start = Vec,
                            endpos = Vec + Vector(0, 0, -((ors or 42) + 3)),
                            mask = MASK_SOLID_BRUSHONLY
                        })

                        if Trc.Hit then
                            local tpos = Trc.HitPos + Vector(0, 0, 1)
                            table.insert(VC.SurfaceTireTracks[key], {
                                wpos = Vec,
                                pos = tpos,
                                time = CurTime() + VC.getSetting("TireTracks_FadeOutTime", 5)
                            })
                        end
                    end
                end
            end
        end
    end
end

local function updateSlideTbl(ent, w1, w2, w3, w4)
    if not IsValid(ent) then return end
    ent.VC_SurfaceData = nil
    if w1 or w2 or w3 or w4 then
        local mrand = math.Round(CurTime())
        if not ent.VC_SlidingData then ent.VC_SlidingData = {} end
        ent.VC_SlidingData[1] = w1 and (ent.VC_SlidingData[1] or mrand) or nil
        ent.VC_SlidingData[2] = w2 and (ent.VC_SlidingData[2] or mrand) or nil
        ent.VC_SlidingData[3] = w3 and (ent.VC_SlidingData[3] or mrand) or nil
        ent.VC_SlidingData[4] = w4 and (ent.VC_SlidingData[4] or mrand) or nil
        ent.VC_SlidingData.Time = CurTime() + 8
    else
        ent.VC_SlidingData = nil
    end
end

net.Receive("VC_WheelSkidding", function()
    local ent, w1, w2, w3, w4 = net.ReadEntity(), net.ReadBool(), net.ReadBool(), net.ReadBool(), net.ReadBool()
    updateSlideTbl(ent, w1, w2, w3, w4)
end)

local WheelPxlHndl = {}
VC.Material.TireTracks = Material("vcmod/tiretracks")
hook.Add("PreDrawOpaqueRenderables", "VC_Wheel_Surface", function()
    if VC.getSetting("TireTracks_Enabled") and table.Count(VC.SurfaceTireTracks) > 0 then
        cam.Start3D()
        render.SetMaterial(VC.Material.TireTracks)
        for k, v in pairs(VC.SurfaceTireTracks) do
            local lastmemp = nil
            for k2, v2 in pairs(v) do
                if VC.SurfaceTireTracks[k][k2 - 1] then
                    local pos1, pos2 = VC.SurfaceTireTracks[k][k2 - 1].pos, v2.pos
                    local key = k .. "_" .. k2
                    if not WheelPxlHndl[key] then WheelPxlHndl[key] = {} end
                    if not WheelPxlHndl[key].Vis or CurTime() >= WheelPxlHndl[key].NTime then
                        WheelPxlHndl[key].Vis = LocalPlayer():IsLineOfSightClear(pos2) and LocalPlayer():IsLineOfSightClear(pos1)
                        WheelPxlHndl[key].NTime = CurTime() + 0.2
                    end

                    if WheelPxlHndl[key].Vis then
                        local ang = (pos1 - pos2):Angle()
                        local p1, p2, p3, p4 = pos1 + ang:Right() * 4, pos2 + ang:Right() * 4, pos2 - ang:Right() * 4, pos1 - ang:Right() * 4
                        local mult = (v2.time - 1) - CurTime()
                        if mult <= 0 then
                            mult = 1 + mult
                        else
                            mult = 1
                        end

                        render.DrawQuad(lastmemp and lastmemp[1] or p1, p2, p3, lastmemp and lastmemp[2] or p4, Color(0, 0, 0, 155 * mult))
                        lastmemp = {p2, p3}
                    end
                end

                if CurTime() >= v2.time then VC.SurfaceTireTracks[k][k2] = nil end
            end
        end

        cam.End3D()
    end
end)

function VC.GetSurfaceData(ent, EntLN)
    if not ent.VC_SurfaceData then
        ent.VC_SurfaceData = {}
        ent.VC_SurfaceData.onGround = nil
        ent.VC_SurfaceData.onAsphalt = nil
        ent.VC_SurfaceData.onNotAsphalt = nil
        ent.VC_SurfaceData.Wheels = {}
    end

    ent.VC_SurfaceData.Wheels = {}
    local wheelData, isBike = VC.getWheelData(ent)
    for k, v in pairs(wheelData) do
        local atc = ent:LookupAttachment(v)
        if atc ~= 0 then
            local addTime = 1 - ent.VC_VelLength / 1500
            if addTime < 0.2 then addTime = 0.2 end
            if not ent.VC_SurfaceData.Wheels[k] or not ent.VC_SurfaceData.Wheels[k].TimeRan or CurTime() >= (ent.VC_SurfaceData.Wheels[k].TimeRan + addTime) then
                local wpos = ent:GetAttachment(atc).Pos
                local dist = LocalPlayer():EyePos():Distance(wpos)
                ent.VC_SurfaceData.Wheels[k] = {}
                if dist < 5000 then
                    local ors = VC.GetDataGeneral(VC.GetModel(ent))
                    if ors then
                        if k == 1 or k == 2 then
                            ors = ors.w_r_f
                        else
                            ors = ors.w_r_r
                        end
                    end

                    local tr = util.TraceLine({
                        start = wpos,
                        endpos = wpos - ent:GetUp() * ((ors or 42) + 3),
                        filter = ent
                    })

                    if tr.Hit and tr.HitWorld then
                        local mat = tr.MatType
                        ent.VC_SurfaceData.Wheels[k].PosW = tr.HitPos
                        local posLocal = ent:WorldToLocal(tr.HitPos)
                        if isBike then posLocal.x = 0 end
                        ent.VC_SurfaceData.Wheels[k].PosL = posLocal
                        ent.VC_SurfaceData.Wheels[k].onAsphalt = mat == 30 or mat == 29 or mat == 67 or mat == 77 or mat == 84
                        ent.VC_SurfaceData.Wheels[k].surfaceMat = mat
                        ent.VC_SurfaceData.Wheels[k].lastDist = dist
                    elseif ent.VC_SlidingData then
                        ent.VC_SlidingData[k] = CurTime()
                    end

                    local onGround, onAsphalt, onNotAsphalt = 0, 0, 0
                    for k2, v2 in pairs(ent.VC_SurfaceData.Wheels) do
                        if v2.surfaceMat then
                            onGround = onGround + 1
                            if not v2.onAsphalt then onNotAsphalt = onNotAsphalt + 1 end
                        end

                        if v2.onAsphalt then onAsphalt = onAsphalt + 1 end
                    end

                    if onGround == 0 then onGround = nil end
                    if onAsphalt == 0 then onAsphalt = nil end
                    if onNotAsphalt == 0 then onNotAsphalt = nil end
                    ent.VC_SurfaceData.onAsphalt = onAsphalt
                    ent.VC_SurfaceData.onNotAsphalt = onNotAsphalt
                    ent.VC_SurfaceData.onGround = onGround
                end

                ent.VC_SurfaceData.Wheels[k].TimeRan = CurTime()
            end
        end
    end
    return ent.VC_SurfaceData
end

function VC.Delete_Particle(ent, key)
    if ent.VC_Entities and ent.VC_Entities[key] then
        if IsValid(ent.VC_Entities[key]) then ent.VC_Entities[key]:Remove() end
        ent.VC_Entities[key] = nil
        if table.Count(ent.VC_Entities) == 0 then ent.VC_Entities = nil end
    end
end

function VC.Spawn_Particle(ent, etype, key, pos, ang, eff, tmr, trgt)
    if not pos or not ent then return end
    local tEnt = ClientsideModel("models/props_lab/huladoll.mdl", RENDERGROUP_OPAQUE)
    if not IsValid(tEnt) then return end
    local dc_data = hook.Call("VC_particleEffectEmit", GAMEMODE, ent, etype, eff, tmr)
    if dc_data == false then
        tEnt:Remove()
        return
    elseif dc_data then
        eff = dc_data
    end

    tEnt:SetAngles(ent:LocalToWorldAngles(ang))
    tEnt:SetPos(ent:LocalToWorld(pos))
    tEnt:SetParent(ent)
    tEnt:SetNoDraw(true)
    VC_freemanngnida(tEnt, ent, key)
    local WDE = ParticleEffectAttach(eff, PATTACH_ABSORIGIN_FOLLOW, tEnt, 0)
    if tmr ~= false then
        timer.Simple(tmr or 1, function()
            if IsValid(tEnt) then
                WDE:Remove()
                tEnt:Remove()
            end
        end)
    end
    return WDE
end

local function NillEffects(ent)
    for k, v in pairs(VC.Wheels) do
        VC.Delete_Particle(ent, "Wheel_Normal_" .. k)
        VC.Delete_Particle(ent, "Wheel_Sparks_" .. k)
        VC.Delete_Particle(ent, "Wheel_Brake_" .. k)
        if ent.VC_WheelRegularDustTable then
            ent.VC_WheelRegularDustTable[k] = nil
            if table.Count(ent.VC_WheelRegularDustTable) == 0 then ent.VC_WheelRegularDustTable = nil end
        end

        if ent.VC_WheelBrakeDustTable then
            ent.VC_WheelBrakeDustTable[k] = nil
            if table.Count(ent.VC_WheelBrakeDustTable) == 0 then ent.VC_WheelBrakeDustTable = nil end
        end

        if ent.VC_WheelSparkTable then
            ent.VC_WheelSparkTable[k] = nil
            if table.Count(ent.VC_WheelSparkTable) == 0 then ent.VC_WheelSparkTable = nil end
        end
    end
end

function VC.HandleSurface(ent, EntLN)
    if not VC.getSetting("TireTracks_Enabled") and not VC.getSetting("Surface_Enabled") or not VC.GetDataGeneral then return end
    if ent.VC_VelLength > 75 then
        VC.GetSurfaceData(ent, EntLN)
        if ent.VC_SlidingData and CurTime() >= ent.VC_SlidingData.Time then ent.VC_SlidingData = nil end
    end

    local DoNormal = ent.VC_VelLength > 100 and VC.getSetting("Surface_Normal")
    local DoSparks = ent.VC_DamagedObjects and ent.VC_DamagedObjects.wheel and (ent.VC_VelLength > 75 or DoBurnout) and VC.getSetting("Surface_Sparks")
    local DoBrakes = ent.VC_VelLength > 100 and ent.VC_SlidingData and VC.getSetting("Surface_Brakes")
    if ent.VC_SurfaceData and ent.VC_SurfaceData.onGround and (DoNormal or DoBrakes or DoSparks) and ent.VC_IsJeep then
        for k, v in pairs(VC.getWheelData(ent)) do
            local posL = nil
            if DoNormal then
                local WD = ent.VC_SurfaceData.Wheels[k]
                if ent.VC_WheelRegularDustTable and ent.VC_WheelRegularDustTable[k] and (ent.VC_WheelRegularDustTable[k].Mat ~= WD.surfaceMat or ent.VC_WheelRegularDustTable[k].Tmr and CurTime() >= ent.VC_WheelRegularDustTable[k].Tmr) then
                    VC.Delete_Particle(ent, "Wheel_Normal_" .. k)
                    ent.VC_WheelRegularDustTable[k] = nil
                end

                local SurfTbl = (VC.SurfaceTable[WD.surfaceMat] or VC.SurfaceTable[0]).Normal
                if (not ent.VC_WheelRegularDustTable or not ent.VC_WheelRegularDustTable[k]) and SurfTbl then
                    if not ent.VC_WheelRegularDustTable then ent.VC_WheelRegularDustTable = {} end
                    ent.VC_WheelRegularDustTable[k] = {
                        Tmr = CurTime() + 1,
                        Mat = WD.surfaceMat,
                        Effect = VC.Spawn_Particle(ent, 3, "Wheel_Normal_" .. k, WD.PosL, ent.VC_Speed_Forward < 0 and Angle(0, 90, 0) or Angle(0, -90, 0), SurfTbl.Effect, false)
                    }
                end
            elseif ent.VC_WheelRegularDustTable and ent.VC_WheelRegularDustTable[k] then
                VC.Delete_Particle(ent, "Wheel_Normal_" .. k)
                ent.VC_WheelRegularDustTable[k] = nil
                if table.Count(ent.VC_WheelRegularDustTable) == 0 then ent.VC_WheelRegularDustTable = nil end
            end

            if DoBrakes and ent.VC_SlidingData and ent.VC_SlidingData[k] then
                local WD = ent.VC_SurfaceData.Wheels[k]
                if ent.VC_WheelBrakeDustTable and ent.VC_WheelBrakeDustTable[k] and (ent.VC_WheelBrakeDustTable[k].Mat ~= WD.surfaceMat or ent.VC_WheelBrakeDustTable[k].Tmr and CurTime() >= ent.VC_WheelBrakeDustTable[k].Tmr) then
                    VC.Delete_Particle(ent, "Wheel_Brake_" .. k)
                    ent.VC_WheelBrakeDustTable[k] = nil
                end

                local SurfTbl = (VC.SurfaceTable[WD.surfaceMat] or VC.SurfaceTable[0]).Brake
                if (not ent.VC_WheelBrakeDustTable or not ent.VC_WheelBrakeDustTable[k]) and SurfTbl then
                    if not ent.VC_WheelBrakeDustTable then ent.VC_WheelBrakeDustTable = {} end
                    ent.VC_WheelBrakeDustTable[k] = {
                        Tmr = CurTime() + 1,
                        Mat = WD.surfaceMat,
                        Effect = VC.Spawn_Particle(ent, 4, "Wheel_Brake_" .. k, WD.PosL, ent.VC_Speed_Forward < 0 and Angle(0, 90, 0) or Angle(0, -90, 0), SurfTbl.Effect, false)
                    }
                end
            elseif ent.VC_WheelBrakeDustTable and ent.VC_WheelBrakeDustTable[k] then
                VC.Delete_Particle(ent, "Wheel_Brake_" .. k)
                ent.VC_WheelBrakeDustTable[k] = nil
                if table.Count(ent.VC_WheelBrakeDustTable) == 0 then ent.VC_WheelBrakeDustTable = nil end
            end

            if DoSparks and ent.VC_DamagedObjects.wheel[k] then
                local WD = ent.VC_SurfaceData.Wheels[k]
                if ent.VC_WheelSparkTable and ent.VC_WheelSparkTable[k] and (ent.VC_WheelSparkTable[k].Tmr and CurTime() >= ent.VC_WheelSparkTable[k].Tmr) then
                    VC.Delete_Particle(ent, "Wheel_Sparks_" .. k)
                    ent.VC_WheelSparkTable[k] = nil
                end

                if not ent.VC_WheelSparkTable or not ent.VC_WheelSparkTable[k] then
                    if not ent.VC_WheelSparkTable then ent.VC_WheelSparkTable = {} end
                    local ang_eff = ent.VC_Speed_Forward < 0 and Angle(0, 90, 0) or Angle(0, -90, 0)
                    ent.VC_WheelSparkTable[k] = {
                        Tmr = CurTime() + 1,
                        Mat = WD.surfaceMat,
                        Effect = VC.Spawn_Particle(ent, 5, "Wheel_Sparks_" .. k, WD.PosL, ang_eff, "VC_WheelSparks", false)
                    }
                end
            elseif ent.VC_WheelSparkTable and ent.VC_WheelSparkTable[k] then
                VC.Delete_Particle(ent, "Wheel_Sparks_" .. k)
                ent.VC_WheelSparkTable[k] = nil
                if table.Count(ent.VC_WheelSparkTable) == 0 then ent.VC_WheelSparkTable = nil end
            end
        end
    else
        NillEffects(ent)
    end
end

local Tbl = {
    {
        HeatUpRate = 0.3,
        Brake = {
            Attach = true,
            Effect = "VC_WheelSmoke_Asphalt"
        },
        Burnout = {
            {
                Attach = false,
                Effect = "VC_Wheelsmoke_BurnoutLeft"
            },
            {
                Attach = true,
                Effect = "VC_Wheelsmoke_Burnout3"
            }
        }
    },
    {
        HeatUpRate = 0.25,
        Normal = {
            Effect = "VC_Wheelsmoke_Dirt_Burnout_Debris"
        },
        Brake = {
            Effect = "VC_Wheelsmoke_Dirt_Burnout"
        },
        Burnout = {
            {
                Attach = true,
                Effect = "VC_Wheelsmoke_Dirt_Burnout3"
            },
            {
                Attach = false,
                Effect = "VC_Wheelsmoke_Dirt_Burnout"
            }
        }
    },
    {
        HeatUpRate = 0.25,
        Normal = {
            Effect = "VC_WheelSmoke_Sand_2"
        },
        Brake = {
            Effect = "VC_WheelSmoke_Sand"
        },
        Burnout = {
            {
                Attach = false,
                FaceRight = true,
                Effect = "VC_Wheelsmoke_Sand_Burnout"
            }
        }
    },
}

VC.SurfaceTable = {
    [12] = Tbl[2],
    [29] = Tbl[1],
    [30] = Tbl[1],
    [0] = {},
    [77] = Tbl[1],
    [67] = Tbl[1],
    [84] = Tbl[1],
    [85] = Tbl[2],
    [68] = Tbl[2],
    [78] = Tbl[3]
}


local function canLBeams(ent)
    return VC.getServerSetting("Lights") and VC.getServerSetting("HeadLights") and IsValid(ent) and VC_suckfreemmann(ent) and VC_suckfreemmann(ent).LightTable and VC_suckfreemmann(ent).LightTable.LBeam
end

local function canHBeams(ent)
    return VC.getServerSetting("Lights") and VC.getServerSetting("HeadLights") and IsValid(ent) and VC_suckfreemmann(ent) and VC_suckfreemmann(ent).LightTable and VC_suckfreemmann(ent).LightTable.HBeam
end

concommand.Add("vc_lowbeams_toggle", function(ply)
    local ent = ply:GetVehicle()
    if canLBeams(ent) then
        if not VC.GetState(ent, "LowBeamsOn") then
            VC.LowBeamsOn(ent)
        else
            VC.LowBeamsOff(ent)
        end
    end
end)

concommand.Add("vc_highbeams_toggle", function(ply)
    local ent = ply:GetVehicle()
    if canHBeams(ent) then
        if not VC.GetState(ent, "HighBeamsOn") then
            VC.HighBeamsOn(ent)
        else
            VC.HighBeamsOff(ent)
        end
    end
end)

concommand.Add("VC_highbeams", function(ply, cmd, arg)
    local ent, HA = ply:GetVehicle(), tonumber(arg[1])
    if not HA then HA = 0 end
    if canHBeams(ent) then
        local on = VC.GetState(ent, "HighBeamsOn")
        if HA == 2 or HA == 0 and on then
            VC.HighBeamsOff(ent)
        else
            VC.HighBeamsOn(ent)
        end
    end
end)

concommand.Add("VC_Hazards_OnOff", function(ply)
    local ent = ply:GetVehicle()
    if IsValid(ent) and VC_suckfreemmann(ent) and VC_suckfreemmann(ent).LightTable and VC_suckfreemmann(ent).LightTable.Blinker then
        if VC.getServerSetting("Lights") and not VC.GetState(ent, "HazardLightsOn") then
            VC.HazardLightsOn(ent)
        else
            VC.HazardLightsOff(ent)
        end
    end
end)

concommand.Add("VC_Blinker_Left", function(ply)
    local ent = ply:GetVehicle()
    if IsValid(ent) and VC_suckfreemmann(ent) and VC_suckfreemmann(ent).LightTable and VC_suckfreemmann(ent).LightTable.Blinker then
        if VC.getServerSetting("Lights") and not VC.GetState(ent, "TurnLightLeftOn") then
            VC.TurnLightLeftOn(ent)
        else
            VC.TurnLightLeftOff(ent)
        end
    end
end)

concommand.Add("VC_Blinker_Right", function(ply)
    local ent = ply:GetVehicle()
    if IsValid(ent) and VC_suckfreemmann(ent) and VC_suckfreemmann(ent).LightTable and VC_suckfreemmann(ent).LightTable.Blinker then
        if VC.getServerSetting("Lights") and not VC.GetState(ent, "TurnLightRightOn") then
            VC.TurnLightRightOn(ent)
        else
            VC.TurnLightRightOff(ent)
        end
    end
end)

concommand.Add("VC_FogLights_OnOff", function(ply)
    local ent = ply:GetVehicle()
    if IsValid(ent) and VC_suckfreemmann(ent) and VC_suckfreemmann(ent).LightTable and VC_suckfreemmann(ent).LightTable.Fog then
        if VC.getServerSetting("Lights") and VC.getServerSetting("FogLights") and not VC.GetState(ent, "FogLightsOn") then
            VC.FogLightsOn(ent)
        else
            VC.FogLightsOff(ent)
        end
    end
end)

concommand.Add("vc_runninglights_toggle", function(ply)
    local ent = ply:GetVehicle()
    if IsValid(ent) and VC_suckfreemmann(ent) and VC_suckfreemmann(ent).LightTable and VC_suckfreemmann(ent).LightTable.Running then
        if VC.getServerSetting("Lights") and not VC.GetState(ent, "RunningLightsOn") then
            VC.RunningLightsOn(ent)
        else
            VC.RunningLightsOff(ent)
        end
    end
end)

concommand.Add("vc_lights_switch", function(ply)
    local ent = ply:GetVehicle()
    if not VC.getServerSetting("Lights") then return end
    if IsValid(ent) then
        local data = VC_suckfreemmann(ent)
        if not data then return end
        local lTable = VC_suckfreemmann(ent).LightTable
        if not lTable then return end
        local hasRunning, hasLowBeam = VC.getServerSetting("Lights_Running") and lTable.Running, VC.getServerSetting("HeadLights") and lTable.LBeam
        if not hasRunning and not hasLowBeam then return end
        local onRunning, onLowBeam = VC.GetState(ent, "RunningLightsOn"), VC.GetState(ent, "LowBeamsOn")
        if onRunning and onLowBeam then
            VC.RunningLightsOff(ent, true)
            VC.LowBeamsOff(ent)
        elseif (not hasRunning or onRunning) and hasLowBeam and not onLowBeam then
            VC.LowBeamsOn(ent)
        elseif not onRunning and hasRunning then
            VC.RunningLightsOn(ent)
        elseif onRunning and not hasLowBeam then
            VC.RunningLightsOff(ent)
        elseif onLowBeam and not hasRunning then
            VC.LowBeamsOff(ent)
        end
    end
end)

concommand.Add("VC_Cruise_OnOff", function(ply)
    local ent = ply:GetVehicle()
    local GVeh = ent.VC_Parent or ent
    if IsValid(ent) and ent == GVeh then
        if VC.GetState(ent, "CruiseOn") then
            VC.CruiseOff(ent)
        else
            VC.CruiseOn(ent)
        end
    end
end)


local function StartEditPlatforms(ent)
    if VC.CD.EditPlatorms and not IsValid(VC.CD.EditPlatorms[1]) then VC.CD.EditPlatorms = nil end
    if not VC.CD.EditPlatorms then
        VC.CD.EditPlatorms = {ent, VC.CD.LastInt}
        net.Start("VC_CD_CreateSpawnPlatforms")
        net.WriteEntity(ent)
        net.WriteInt(VC.CD.LastInt, 8)
        net.SendToServer()
        VCPopup("Started editing platforms.")
    end
end

local function FinishEditPlatforms()
    if VC.CD.EditPlatorms and IsValid(VC.CD.EditPlatorms[1]) then
        VCPopup("Finished editing platforms.")
        net.Start("VC_CD_PlatformsDoneEditting")
        net.SendToServer()
        local PTbl = {}
        for k, v in pairs(ents.FindByClass("vc_npc_obj_spawn")) do
            if IsValid(v:GetNWEntity("VC_NPC")) and v:GetNWEntity("VC_NPC") == VC.CD.EditPlatorms[1] and IsValid(v:GetNWEntity("VC_Owner")) and v:GetNWEntity("VC_Owner") == LocalPlayer() then
                table.insert(PTbl, {
                    Pos = v:GetPos(),
                    Ang = v:GetAngles()
                })
            end
        end

        local ttbl = VC.CD.LastTbl
        ttbl.Platforms = PTbl
        VC.CD.LastTbl = ttbl
        VC.CD.open_menu_cardealer_edit(VC.CD.EditPlatorms[1])
        VC.CD.EditPlatorms = nil
    end
end

local function DeletePlatform(ent)
    if VC.CD.EditPlatorms then
        net.Start("VC_CD_DeletePlatform")
        net.WriteEntity(ent)
        net.SendToServer()
    end
end

local function SpawnPlatform(ent)
    if VC.CD.EditPlatorms then
        net.Start("VC_CD_SpawnPlatform")
        net.WriteEntity(ent)
        net.SendToServer()
    end
end

local function StartEditVehicles(ent)
    if VC.CD.EditVehicles and not IsValid(VC.CD.EditVehicles[1]) then VC.CD.EditVehicles = nil end
    if not VC.CD.EditVehicles then
        VC.CD.EditVehicles = {ent, VC.CD.LastInt}
        VCPopup("Started editing vehicles.")
    end
end

local function FinishEditVehicles()
    if VC.CD.EditVehicles and IsValid(VC.CD.EditVehicles[1]) then
        VCPopup("Finished editing vehicles.")
        VC.CD.open_menu_cardealer_edit(VC.CD.EditVehicles[1])
        VC.CD.EditVehicles = nil
    end
end

local function DoInsertVehicle(NPC, edata, options)
    if type(edata) == "table" then
        net.Start("VC_CD_AddVehicle_Manual")
        net.WriteEntity(NPC)
        net.WriteTable(options)
        net.WriteString(util.TableToJSON(edata))
        net.SendToServer()
        VC.CD.open_menu_cardealer_edit(VC.CD.LastNPC)
    else
        net.Start("VC_CD_AddVehicle")
        net.WriteEntity(NPC)
        net.WriteEntity(edata)
        net.WriteTable(options)
        net.SendToServer()
    end
end

local function DeleteVehicle(NPC)
    if VC.CD.EditVehicles then
        local ent = LocalPlayer():GetEyeTraceNoCursor().Entity
        if IsValid(ent) and ent.VC_isSupported and VC.GetModel(ent) then
            local cn = VC.getName(ent, "Unknown")
            local can = false
            if VC.CD.LastTbl and VC.CD.LastTbl.Vehicles then
                for k, v in pairs(VC.CD.LastTbl.Vehicles) do
                    if VC.GetModel(ent) == v.Model and (cn == v.Name or "Unknown") then
                        can = true
                        break
                    end
                end
            end

            if can then
                net.Start("VC_CD_DeleteVehicle")
                net.WriteEntity(NPC)
                net.WriteString(VC.CD.getVehicleID(ent))
                net.SendToServer()
            end
        end
    end
end

local function InsertVehicle(NPC)
    if VC.CD.EditVehicles then
        local ent = LocalPlayer():GetEyeTraceNoCursor().Entity
        if IsValid(ent) and ent.VC_isSupported then
            VC.CD.open_menu_addcar(NPC, ent)
        else
            VCPopup("Look at a vehicle first.")
        end
    end
end

net.Receive("VC_CD_Send_Menu_Open", function(len)
    local ent, tbl, plytbl, int, refund, admin = net.ReadEntity(), net.ReadTable(), net.ReadTable(), net.ReadInt(8), net.ReadInt(8), net.ReadInt(4)
    VC.CD_RefundPrice = refund
    if IsValid(ent) then
        if admin and admin == 1 then
            VC.CD.open_menu_choice(ent, tbl, plytbl, int)
        else
            VC.CD.open_menu_main(ent, tbl, plytbl, int)
        end
    end
end)

net.Receive("VC_CD_SendInfo_Import_NPC", function(len)
    local NPCData = net.ReadTable()
    if not NPCData then VCPopup("Error", "cross") end
    VC.CD.Import = NPCData
end)

net.Receive("VC_CD_Send_Vehicle_Table", function(len)
    local tbl = net.ReadTable()
    VC.CD.LastTbl.Vehicles = tbl
    VC.CD.RefreshVehicles = true
end)

net.Receive("VC_CD_VehicleSpawnedData", function(len)
    local ent, testdrive, endtime = net.ReadEntity(), net.ReadBool(), net.ReadInt(8)
    VC.CD.SpawnedVehicleData_LastPos_X = nil
    VC.CD.SpawnedVehicleData_LastPos_Y = nil
    VC.CD.SpawnedVehicleData = {
        Entity = ent,
        EndTime = CurTime() + 30
    }

    if testdrive and endtime > 0 then
        VC.CD.SpawnedTestDriveData = {
            Entity = ent,
            EndTime = CurTime() + endtime
        }
    end

    if IsValid(VC.CD.Main_Pnl) then VC.CD.Main_Pnl.VC_RefreshModelList = 3 end
end)

net.Receive("VC_CD_Return_Vehicle_Data", function(len)
    local price, ID, PlyOptions = net.ReadInt(8), net.ReadString(), net.ReadTable()
    VC.CD.Main_Pnl.Returned = {ID, price, PlyOptions}
end)

local function importRequest(NPC, ttype)
    net.Start("VC_CD_Import")
    net.WriteString(tostring(NPC))
    net.WriteInt(ttype, 8)
    net.SendToServer()
end

net.Receive("VC_CD_ImportGetList", function(len)
    local NPCList = net.ReadTable()
    if VC.CD_Edit_Panel then
        local DDM = VC.DermaMenu("Import from other")
        for map, mapData in pairs(NPCList) do
            local ISM = DDM:VC_AddSubMenu(map .. " (" .. table.Count(mapData) .. ")")
            for NPC, NPCData in pairs(mapData) do
                local ISM2 = ISM:VC_AddSubMenu((NPCData.Name or VC.Lng("Unknown")) .. " (Created " .. VC.time_elapsed_string(NPC) .. ")")
                ISM2:AddButton("Everything", function() importRequest(NPC, 0) end):SetImage("icon16/key.png")
                ISM2:AddSpacer()
                ISM2:AddButton("Other info (Name, ranks, model, etc)", function() importRequest(NPC, 3) end):SetImage("icon16/textfield.png")
                ISM2:AddButton("Spawn platforms (" .. NPCData.Platforms .. ")", function() importRequest(NPC, 1) end):SetImage("icon16/tab.png")
                ISM2:AddButton("Vehicles (" .. NPCData.Vehicles .. ")", function() importRequest(NPC, 2) end):SetImage("icon16/car.png")
            end
        end

        if DDM then DDM:Open() end
    end
end)

net.Receive("VC_CD_RequestInfo_Close", function(len)
    VC.HUD_FadeAlpha = 255
    if IsValid(VC.CD.Main_Pnl) then VC.CD.Main_Pnl:Close() end
end)

function VC.CD.open_menu_addcar(NPC, ent, mdata)
    if not IsValid(VC.CD.AddCar_Pnl) then
        VC.CD.AddCar_Pnl = vgui.Create("DFrame")
        VC.CD.AddCar_Pnl:SetSize(700, 250)
        VC.CD.AddCar_Pnl:SetTitle("")
        VC.CD.AddCar_Pnl:SetPos(ScrW() / 2 - VC.CD.AddCar_Pnl:GetWide() / 2, ScrH() / 2 - VC.CD.AddCar_Pnl:GetTall() / 2)
        VC.CD.AddCar_Pnl:SetDraggable(false)
        VC.CD.AddCar_Pnl:AlphaTo(0, 0, 0)
        VC.CD.AddCar_Pnl:AlphaTo(255, 0.2, 0)
        VC.CD.AddCar_Pnl:ShowCloseButton(false)
        local cn = mdata and mdata.Name or VC.getName(ent, "Unknown")
        local mdl = mdata and mdata.Model or VC.GetModel(ent)
        local defskin = mdata and (mdata.DefaultSkin or 0) or ent:GetSkin()
        local bgroupstring = mdata and mdata.BGroups or ""
        if bgroupstring == "" and IsValid(ent) then
            bgroupstring = bgroupstring
            for k, v in pairs(ent:GetBodyGroups()) do
                bgroupstring = bgroupstring .. ent:GetBodygroup(k)
            end
        end

        local curskin = mdata and mdata.DefaultSkin or 0
        if curskin == 0 and IsValid(ent) then curskin = ent:GetSkin() end
        local AHas = nil
        for k, v in pairs(VC.CD.LastTbl.Vehicles) do
            if (v.Name or "Unknown") == cn and v.Model == mdl and (v.DefaultSkin or 0) == defskin then
                AHas = table.Copy(v)
                break
            end
        end

        VC.CD.AddCar_Pnl.Paint = function(obj, Sx, Sy)
            draw.RoundedBox(0, 0, 0, Sx, Sy, VC.Color.Main)
            draw.RoundedBox(0, 10, 10, 287, 201, VC.Color.Main)
            draw.RoundedBox(0, 300, 40, 390, 50, VC.Color.Main)
            draw.DrawText(cn, "VC_Big_Italic", Sx * 0.7, 10, VC.Color.Good, TEXT_ALIGN_CENTER)
            draw.DrawText("Model:", "VC_Dev_Text", 305, 45, VC.Color.Good, TEXT_ALIGN_LEFT)
            draw.DrawText(mdl, "VC_Dev_Text", 365, 45, VC.Color.Blue, TEXT_ALIGN_LEFT)
            draw.DrawText("Spawn skin:", "VC_Dev_Text", VC.CD.AddCar_Pnl:GetWide() * 0.7 + 10, 65, VC.Color.Good, TEXT_ALIGN_LEFT)
            draw.DrawText("Price:", "VC_Dev_Text", 305, 65, VC.Color.Good, TEXT_ALIGN_LEFT)
        end

        local el_mdl = vgui.Create("DModelPanel", VC.CD.AddCar_Pnl)
        el_mdl:SetModel(mdl)
        el_mdl:SetCamPos(Vector(20, 0, 62))
        el_mdl:SetLookAt(Vector(0, 0, 62))
        el_mdl:SetSize(310, 200)
        el_mdl:SetPos(5, 5)
        el_mdl.ModelLength = el_mdl:GetEntity():GetRenderBounds():Length() * 1.5 - 200
        function el_mdl:LayoutEntity()
            el_mdl:SetLookAt(Vector(10, 0, 75))
            el_mdl:SetCamPos(Vector(300 + el_mdl.ModelLength, 0, 50))
            return
        end

        local el_price = vgui.Create("DNumberWang", VC.CD.AddCar_Pnl)
        el_price:SetTall(20)
        el_price:SetMin(0)
        el_price:SetMax(10000000)
        el_price:SetDecimals(0)
        el_price:SetToolTip("Vehicle price.")
        el_price:SetValue(AHas and AHas.Price or 1000)
        el_price:SetPos(365, 63)
        local El_List1 = VC.Add_El_List(305, 98, 190, 48)
        El_List1:SetParent(VC.CD.AddCar_Pnl)
        El_List1:NoClipping(true)
        El_List1.Paint = function(obj, Sx, Sy) draw.RoundedBox(0, -5, -5, Sx + 10, Sy + 7, VC.Color.Main) end
        local el_colour = VC.Add_El_Checkbox("Allow to customise colour", "Allows the vehicles to be customised.")
        el_colour:SetValue(AHas and AHas.DD_Clr and 0 or 1)
        El_List1:AddItem(el_colour)
        local el_skin = VC.Add_El_Checkbox("Allow to customise skin (paintjob)", "Allows the vehicles to be customised.")
        el_skin:SetValue(AHas and AHas.DD_Skin and 0 or 1)
        El_List1:AddItem(el_skin)
        local el_bgroup = VC.Add_El_Checkbox("Allow to customise bodygroups", "Allows the vehicles to be customised.")
        el_bgroup:SetValue(AHas and AHas.DD_BGrp and 0 or 1)
        El_List1:AddItem(el_bgroup)
        local El_List1 = VC.Add_El_List(305, 155, 190, 51)
        El_List1:SetParent(VC.CD.AddCar_Pnl)
        El_List1:NoClipping(true)
        El_List1.Paint = function(obj, Sx, Sy) draw.RoundedBox(0, -5, -5, Sx + 10, Sy + 10, VC.Color.Main) end
        local Restrict_rank_Tbl = AHas and AHas.RankRestrict or {}
        if not VC.CD.LastTbl.RankRestrict then VC.CD.LastTbl.RankRestrict = {} end
        for k, v in pairs(VC.getRanks()) do
            local el = VC.Add_El_Checkbox(v, "This rank is allowed to use this car dealer.")
            El_List1:AddItem(el)
            el:SetValue(not Restrict_rank_Tbl[k])
            el.OnChange = function(idx, val) Restrict_rank_Tbl[k] = not val end
        end

        local RestrictTbl = AHas and AHas.JobRestrict or {}
        if RPExtraTeams then
            local El_List1 = VC.Add_El_List(508, 98, 177, 108)
            El_List1:SetParent(VC.CD.AddCar_Pnl)
            El_List1:NoClipping(true)
            El_List1.Paint = function(obj, Sx, Sy) draw.RoundedBox(0, -5, -5, Sx + 10, Sy + 10, VC.Color.Main) end
            for k, v in pairs(RPExtraTeams) do
                local nm = v.name or VC.Lng("Unknown")
                local el_opt = VC.Add_El_Checkbox(nm, "Allow the vehicles to be spawned by this user group.")
                el_opt:SetValue(not RestrictTbl[nm])
                El_List1:AddItem(el_opt)
                el_opt.OnChange = function(idx, val) RestrictTbl[nm] = not val end
            end
        end

        local el_skindef = vgui.Create("DComboBox", VC.CD.AddCar_Pnl)
        for i = 1, el_mdl:GetEntity():SkinCount() do
            el_skindef:AddChoice("Skin " .. i)
        end

        el_skindef.OnSelect = function(idx, val)
            curskin = val - 1
            el_mdl:GetEntity():SetSkin(curskin)
        end

        el_skindef:ChooseOptionID(curskin + 1)
        el_skindef:SetWide(100)
        el_skindef:SetPos(VC.CD.AddCar_Pnl:GetWide() - el_skindef:GetWide() - 15, 63)
        el_mdl:GetEntity():SetBodyGroups(bgroupstring)
        local Add = vgui.Create("VC_Button", VC.CD.AddCar_Pnl)
        Add:SetColor(VC.Color.Btn_Add)
        Add:SetText(AHas and "Change" or "Add")
        Add:SetKey("enter")
        Add:SetSize(VC.CD.AddCar_Pnl:GetWide() / 2 - 15, 25)
        Add:SetPos(10, VC.CD.AddCar_Pnl:GetTall() - Add:GetTall() - 10)
        local Cancel = vgui.Create("VC_Button", VC.CD.AddCar_Pnl)
        Cancel:SetColor(VC.Color.Btn_Rem)
        Cancel:SetText("Cancel")
        Cancel:SetKey("BACKSPACE")
        Cancel:SetSize(VC.CD.AddCar_Pnl:GetWide() / 2 - 15, 25)
        Cancel:SetPos(VC.CD.AddCar_Pnl:GetWide() / 2 + 5, VC.CD.AddCar_Pnl:GetTall() - Add:GetTall() - 10)
        Add.DoClick = function()
            DoInsertVehicle(NPC, mdata or ent, {
                BGroups = bgroupstring,
                DefaultSkin = curskin,
                Price = el_price:GetValue(),
                DD_Clr = not el_colour:GetChecked(),
                DD_Skin = not el_skin:GetChecked(),
                DD_BGrp = not el_bgroup:GetChecked(),
                JobRestrict = RestrictTbl,
                RankRestrict = Restrict_rank_Tbl
            })

            VC.CD.AddCar_Pnl:Close()
        end

        Cancel.DoClick = function()
            VC.CD.AddCar_Pnl:Close()
            if mdata then VC.CD.open_menu_cardealer_edit(VC.CD.LastNPC) end
        end

        VC.CD.AddCar_Pnl.Think = function()
            if not VC.isTyping() then
                if input.IsKeyDown(KEY_ENTER) then Add.DoClick() end
                if input.IsKeyDown(KEY_BACKSPACE) then Cancel.DoClick() end
            end
        end

        VC.CD.AddCar_Pnl:MakePopup()
    end
end

local clr_main = table.Copy(VC.Color.Main)
clr_main.a = 240
local clr_topbutton = table.Copy(clr_main)
clr_topbutton.a = 150
local clr_topbutton_text = table.Copy(VC.Color.Blue)
local clr_topbutton_text_close = table.Copy(VC.Color.White)
local clr_topbutton_close = table.Copy(VC.Color.Bad)
local clr_topbutton_close_text = Color(225, 225, 255, 255)
local function CreateButtonTop(Name, Sx, seln, close)
    local Btn = vgui.Create("DButton", VC.CD.Main_Pnl)
    Btn:SetParent(VC.CD.Main_Pnl)
    Btn:SetText("")
    Btn:SetSize(close and 80 or 150, 30)
    Btn:SetPos(Sx, 0)
    Btn:NoClipping(true)
    Btn.Paint = function(obj, Sx, Sy)
        local tclr = table.Copy(clr_main)
        if VC.CD.Main_Pnl.Sel ~= seln then tclr = table.Copy(clr_topbutton) end
        local textclr = clr_topbutton_text
        if close then
            textclr = clr_topbutton_text_close
            tclr = clr_topbutton_close
        end

        draw.RoundedBox(0, VC.FadeW / 2, 0, Sx - VC.FadeW, Sy, tclr)
        surface.SetDrawColor(tclr)
        surface.SetMaterial(VC.Material.Fade)
        surface.DrawTexturedRectRotated(Sx, Sy / 2, VC.FadeW, Sy, 0)
        surface.DrawTexturedRectRotated(0, Sy / 2, VC.FadeW, Sy, 180)
        draw.DrawText(Name, Btn:IsHovered() and "VC_Big_Italic" or "VC_Big", Sx / 2, 3, close and textclr or clr_topbutton_text, TEXT_ALIGN_CENTER)
    end
    return Btn
end

local backPressed = nil
local enterPressed = nil
local function DoMainMenu(NPC, tbl, plytbl, int)
    if VC.isPlayerRestricted(LocalPlayer(), nil, tbl) then return end
    local MPx = ScrW() * 0.8
    local MPy = ScrH() * 0.85
    local SwitchSpeed = 74
    local Pnl = vgui.Create("DFrame")
    Pnl:SetSize(MPx, MPy)
    Pnl:SetTitle("")
    Pnl:SetPos(ScrW() / 2 - Pnl:GetWide() / 2, ScrH() / 2 - Pnl:GetTall() / 2)
    Pnl:SetDraggable(false)
    Pnl:ShowCloseButton(false)
    Pnl:NoClipping(true)
    Pnl:AlphaTo(0, 0, 0)
    Pnl:AlphaTo(255, 0.2, 0)
    VC.CD.Main_Pnl = Pnl
    Pnl.FrameRate = 0
    local clr = table.Copy(VC.Color.Main)
    clr.a = 200
    Pnl.Sel = 1
    Pnl.Paint = function(obj, Sx, Sy)
        draw.RoundedBox(0, 0, 30, Sx, Sy - 30, clr_main)
        surface.SetDrawColor(clr_main.r, clr_main.g, clr_main.b, clr_main.a)
        surface.SetFont("VC_Big")
        local name = VC.getName(NPC, VC.Lng("Unknown"))
        local tsize = surface.GetTextSize(name)
        local Width = tsize
        local start = Sx - Width - 200
        draw.RoundedBox(0, start, 0, Width, 30, clr_main)
        surface.SetMaterial(VC.Material.Fade)
        surface.DrawTexturedRectRotated(Sx + VC.FadeW / 2, 16 + Sy / 2, VC.FadeW, Sy - 30, 0)
        surface.DrawTexturedRectRotated(-VC.FadeW / 2, 16 + Sy / 2, VC.FadeW, Sy - 30, 180)
        surface.DrawTexturedRectRotated(start + Width + VC.FadeW / 2, 15, VC.FadeW, 30, 0)
        surface.DrawTexturedRectRotated(start - VC.FadeW / 2, 15, VC.FadeW, 30, 180)
        draw.DrawText(name, "VC_Big", start + Width / 2, 5, VC.Color.White, TEXT_ALIGN_CENTER)
    end

    local InfoPanel = VC.Add_El_List(0, 200, 175, 140)
    local TN = CurTime()
    InfoPanel:SetParent(Pnl)
    InfoPanel:AlphaTo(0, 0, 0)
    InfoPanel:AlphaTo(255, 2, 0)
    timer.Simple(2.5, function() if IsValid(InfoPanel) then InfoPanel:AlphaTo(0, 0.5, 0) end end)
    InfoPanel:NoClipping(true)
    InfoPanel.Paint = function(obj, Sx, Sy)
        draw.RoundedBox(0, 0, 0, Sx + 15, Sy, clr)
        surface.SetDrawColor(clr)
        surface.SetMaterial(VC.Material.Fade)
        surface.DrawTexturedRectRotated(Sx + VC.FadeW / 2 + 15, Sy / 2, VC.FadeW, Sy, 0)
        surface.DrawTexturedRectRotated(-VC.FadeW / 2 + 15, Sy / 2, VC.FadeW, Sy, 180)
    end

    InfoPanel.Think = function()
        local Alpha = InfoPanel:GetAlpha()
        local pos = CurTime() - (TN + 3)
        if pos > 0 then
            InfoPanel:Remove()
        else
            InfoPanel:SetPos(0, 310 + pos * 25)
        end
    end

    local Lbl = vgui.Create("DLabel")
    Lbl:SetFont("VC_Dev_Text")
    Lbl:SetText(VC.Lng("Controls") .. ":")
    Lbl:SetColor(VC.Color.White)
    InfoPanel:AddItem(Lbl)
    local Lbl = vgui.Create("DLabel")
    Lbl:SetText("[ENTER]               - " .. VC.Lng("Buy") .. " / " .. VC.Lng("Sell"))
    Lbl:SetColor(Color(255, 255, 255, 255))
    InfoPanel:AddItem(Lbl)
    local Lbl = vgui.Create("DLabel")
    Lbl:SetText("[SPACE]               - " .. VC.Lng("Spawn"))
    Lbl:SetColor(Color(255, 255, 255, 255))
    InfoPanel:AddItem(Lbl)
    local Lbl = vgui.Create("DLabel")
    Lbl:SetText("[TAB]                   - " .. VC.Lng("Tab"))
    Lbl:SetColor(Color(255, 255, 255, 255))
    InfoPanel:AddItem(Lbl)
    local Lbl = vgui.Create("DLabel")
    Lbl:SetText("[BACKSPACE]      - " .. VC.Lng("Close"))
    Lbl:SetColor(Color(255, 255, 255, 255))
    InfoPanel:AddItem(Lbl)
    local Lbl = vgui.Create("DLabel")
    Lbl:SetText("[LEFT]/[RIGHT]   - " .. VC.Lng("Previous") .. " / " .. VC.Lng("Next"))
    Lbl:SetColor(Color(255, 255, 255, 255))
    InfoPanel:AddItem(Lbl)
    local Lbl = vgui.Create("DLabel")
    Lbl:SetText("[UP]-[Down]        - " .. VC.Lng("Rotate"))
    Lbl:SetColor(Color(255, 255, 255, 255))
    InfoPanel:AddItem(Lbl)
    local ModelView = vgui.Create("DModelPanel", Pnl)
    ModelView:SetSize(MPx, MPy)
    ModelView:SetPos(MPx / 2 - ModelView:GetWide() / 2, 40 + MPy / 2 - ModelView:GetTall() / 2)
    ModelView:SetModel("")
    ModelView.ModelLength = 0
    ModelView.VC_RotX = 0
    ModelView.VC_RotY = 0
    ModelView.FarZ = ModelView.FarZ / 1
    Pnl.PaintOver = function(obj, Sx, Sy)
        if Pnl.Sel_Mdl then
            local name = Pnl.Sel_Mdl.Name or VC.CD.Default.Name
            surface.SetFont("VC_Big")
            local tsize = surface.GetTextSize(name)
            local Py = -math.abs(ModelView.VC_Progress / 15)
            local start = math.Round(Sx / 2 - tsize / 2 + ModelView.VC_Progress * 1.2)
            local tclr = table.Copy(VC.Color.Blue)
            tclr.a = 500 - math.abs(ModelView.VC_Progress) * 2
            local dclr = table.Copy(clr)
            dclr.a = tclr.a
            draw.RoundedBox(0, start, 65 + Py, tsize, 45, dclr)
            surface.SetMaterial(VC.Material.Fade)
            surface.DrawTexturedRectRotated(math.Round(start + tsize + VC.FadeW / 2), 70 + 18 + Py, math.Round(VC.FadeW), 45, 0)
            surface.DrawTexturedRectRotated(math.Round(start - VC.FadeW / 2), 70 + 18 + Py, math.Round(VC.FadeW), 45, 180)
            draw.DrawText(name, "VC_Big", Sx / 2 + ModelView.VC_Progress * 1.25, 75 + Py, tclr, TEXT_ALIGN_CENTER)
        end
    end

    function ModelView:LayoutEntity()
        local tvec = Vector(0, 1500, 0)
        tvec:Rotate(Angle(0, math.Clamp(ModelView.VC_Progress, -3000, 3000) / (50 - math.abs(ModelView.VC_Progress / 10)), 0))
        tvec = tvec - Vector(0, 1500, 0)
        ModelView.R_Ang_Rot_X = Lerp(0.05, ModelView.R_Ang_Rot_X or ModelView.VC_RotX, ModelView.VC_RotX)
        ModelView.R_Ang_Rot_Y = Lerp(0.05, ModelView.R_Ang_Rot_Y or ModelView.VC_RotY, ModelView.VC_RotY)
        local ang = Angle(ModelView.R_Ang_Rot_Y + 15, ModelView.R_Ang_Rot_X / 2 - 130, 0)
        local pos = -ang:Forward() * (250 - tvec.y * 2) + ang:Up() * 20 + ang:Right() * tvec.x - ang:Forward() * 50 - ang:Up() * ModelView.R_Ang_Rot_Y / 2 - ang:Forward() * ModelView.ModelLength
        ModelView:SetLookAng(ang)
        ModelView:SetCamPos(pos)
        return
    end

    function ModelView:OnMousePressed(code)
        if code == MOUSE_LEFT then
            ModelView.VC_ToSelect = nil
            local Mx, My = gui.MousePos()
            ModelView.VC_IsCapturing = {
                x = Mx - ModelView.VC_Progress,
                y = My
            }
        elseif code == MOUSE_RIGHT then
            local Mx, My = gui.MousePos()
            ModelView.VC_IsCapturing_Right = {
                x = Mx,
                y = My
            }
        end
    end

    function ModelView:OnMouseReleased(code)
        if code == MOUSE_LEFT then
            ModelView.VC_IsCapturing = false
        elseif code == MOUSE_RIGHT then
            ModelView.VC_IsCapturing_Right = false
            ModelView.VC_LastRight_X = nil
            ModelView.VC_LastRight_Y = nil
        end
    end

    function ModelView:OnMouseWheeled(delta)
        if Pnl.Sel_Mdl then ModelView.VC_LastSpeed = SwitchSpeed * math.Clamp(delta, -1, 1) end
    end

    ModelView.Think = function()
        if not Pnl.Sel_Mdl then return end
        if not ModelView:IsHovered() then
            if ModelView.VC_IsCapturing then ModelView:OnMouseReleased(MOUSE_LEFT) end
            if ModelView.VC_IsCapturing_Right then ModelView:OnMouseReleased(MOUSE_RIGHT) end
        end

        if not ModelView.VC_Progress then ModelView.VC_Progress = 0 end
        if ModelView.VC_IsCapturing_Right then
            local Mx, My = gui.MousePos()
            ModelView.VC_RotX = ModelView.VC_RotX + ((ModelView.VC_LastRight_X or Mx) - Mx)
            ModelView.VC_RotY = math.Clamp(ModelView.VC_RotY - ((ModelView.VC_LastRight_Y or My) - My), -15, 25)
            ModelView.VC_LastRight_X = Mx
            ModelView.VC_LastRight_Y = My
        end

        if ModelView.VC_IsCapturing then
            local Mx, My = gui.MousePos()
            ModelView.VC_LastSpeed = ModelView.VC_Progress - (Mx - ModelView.VC_IsCapturing.x)
            ModelView.VC_Progress = Mx - ModelView.VC_IsCapturing.x
        else
            ModelView.VC_Progress = Lerp(0.02, ModelView.VC_Progress, 0)
            ModelView.VC_LastSpeed = Lerp(0.09, ModelView.VC_LastSpeed, 0)
            ModelView.VC_Progress = ModelView.VC_Progress - ModelView.VC_LastSpeed
        end

        if ModelView.VC_Progress < -375 then
            ModelView.VC_Progress = 375
            if ModelView.VC_IsCapturing then
                local Mx, My = gui.MousePos()
                ModelView.VC_IsCapturing = {
                    x = Mx - ModelView.VC_Progress,
                    y = My
                }
            end

            Pnl.NextModel()
        end

        if ModelView.VC_Progress > 375 then
            ModelView.VC_Progress = -375
            if ModelView.VC_IsCapturing then
                local Mx, My = gui.MousePos()
                ModelView.VC_IsCapturing = {
                    x = Mx - ModelView.VC_Progress,
                    y = My
                }
            end

            Pnl.PrevModel()
        end
    end

    local Horz = vgui.Create("DHorizontalScroller", Pnl)
    Horz:SetSize(MPx - 30, 100)
    Horz:AlignBottom(0)
    Horz:AlignLeft(15)
    Horz:SetOverlap(0)
    Horz:NoClipping(true)
    local Btn_Prev = vgui.Create("DButton", Pnl)
    Btn_Prev:SetText("")
    Btn_Prev:SetSize(15, Horz:GetTall())
    Btn_Prev:AlignLeft(0)
    Btn_Prev:AlignBottom(0)
    local Btn_Next = vgui.Create("DButton", Pnl)
    Btn_Next:SetText("")
    Btn_Next:SetSize(15, Horz:GetTall())
    Btn_Next:AlignRight(0)
    Btn_Next:AlignBottom(0)
    function HorzResetAlpha(int)
        Horz:AlphaTo(0, 0, 0)
        Horz:AlphaTo(255, int or 0.5, 0)
        Btn_Prev:AlphaTo(0, 0, 0)
        Btn_Prev:AlphaTo(255, int or 0.5, 0)
        Btn_Next:AlphaTo(0, 0, 0)
        Btn_Next:AlphaTo(255, int or 0.5, 0)
    end

    HorzResetAlpha(1)
    local OptionsPanel = VC.Add_El_List(Pnl:GetWide() - 170, 30, 170, Pnl:GetTall() - 29 - Horz:GetTall())
    OptionsPanel.StartPos_X, OptionsPanel.StartPos_Y = OptionsPanel:GetPos()
    OptionsPanel:SetParent(Pnl)
    OptionsPanel:AlphaTo(0, 0, 0)
    OptionsPanel:NoClipping(true)
    local Lbl = vgui.Create("DLabel")
    Lbl:SetTall(20)
    Lbl:SetText("")
    OptionsPanel:AddItem(Lbl)
    local Lbl = vgui.Create("DLabel")
    Lbl:SetFont("VC_Big_Italic")
    Lbl:SetText(VC.Lng("customisation") .. ":")
    Lbl:SetColor(VC.Color.White)
    OptionsPanel:AddItem(Lbl)
    local Lbl = vgui.Create("DLabel")
    Lbl:SetTall(10)
    Lbl:SetText("")
    OptionsPanel:AddItem(Lbl)
    OptionsPanel.Paint = function(obj, Sx, Sy)
        draw.RoundedBox(0, 0, 0, Sx - 10, Sy, clr)
        surface.SetDrawColor(clr)
        surface.SetMaterial(VC.Material.Fade)
        surface.DrawTexturedRectRotated(Sx + VC.FadeW / 2 - 10, Sy / 2, VC.FadeW, Sy, 0)
        surface.DrawTexturedRectRotated(-VC.FadeW / 2, Sy / 2, VC.FadeW, Sy, 180)
    end

    local DataPanel = VC.Add_El_List(20, 30 + 30, 200, Pnl:GetTall() - 29 - Horz:GetTall())
    DataPanel.StartPos_X, DataPanel.StartPos_Y = DataPanel:GetPos()
    DataPanel:SetParent(Pnl)
    DataPanel:AlphaTo(0, 0, 0)
    DataPanel:NoClipping(true)
    local Cust_Save = vgui.Create("DButton", OptionsPanel)
    Cust_Save:SetSize(OptionsPanel:GetWide(), 40)
    Cust_Save:SetPos(0, OptionsPanel:GetTall() - Cust_Save:GetTall() - 25)
    Cust_Save:SetText("")
    local Cust_Reset = vgui.Create("DButton", OptionsPanel)
    local pos = OptionsPanel:GetWide() / 2
    Cust_Reset:SetSize(pos, 18)
    Cust_Reset:SetPos(pos / 2, OptionsPanel:GetTall() - Cust_Reset:GetTall() - 4)
    Cust_Reset:SetText("")
    local cust_obj_tbl = {}
    local cust_temp_color = nil
    local cust_temp_skin = nil
    local function ChangeLeftData()
        if VC.CD.DataLabels then
            for k, v in pairs(VC.CD.DataLabels) do
                v:Remove()
            end
        end

        if Pnl.Sel_Mdl then
            local ID = VC.CD.getName(Pnl.Sel_Mdl.Model, Pnl.Sel_Mdl.Name, Pnl.Sel_Mdl.DefaultSkin)
            local data = plytbl and plytbl.Vehicles and plytbl.Vehicles[ID]
            if data then
                if not VC.CD.DataLabels then VC.CD.DataLabels = {} end
                if data.Fuel and data.Fuel <= 99 then
                    local Lbl = vgui.Create("DLabel")
                    Lbl:NoClipping(true)
                    Lbl.Paint = function(obj, Sx, Sy)
                        Sy = Sy * 0.75
                        surface.SetDrawColor(Color(255, 255, 255, 255))
                        surface.SetMaterial(VC.Material.icon_fuel)
                        surface.DrawTexturedRect(-Sy - 8, 3, Sy, Sy + 3)
                    end

                    Lbl:SetTall(35)
                    Lbl:SetText(math.Round(data.Fuel) .. " %")
                    Lbl:SetFont("VC_HUD_Bisgs")
                    Lbl:SetColor(VC.Color.White)
                    DataPanel:AddItem(Lbl)
                    table.insert(VC.CD.DataLabels, Lbl)
                end

                if data.Health and data.Health <= 99 then
                    local tclr = VC.Color.White
                    local txt = "damaged"
                    if data.Health <= 0 then
                        txt = "destroyed"
                        tclr = VC.Color.Bad
                    elseif data.Health <= 12.5 then
                        txt = "critical"
                        tclr = VC.Color.Bad
                    elseif data.Health <= 40 then
                        txt = "severelydamaged"
                        tclr = VC.Color.White
                    end

                    local Lbl = vgui.Create("DLabel")
                    Lbl:NoClipping(true)
                    Lbl.Paint = function(obj, Sx, Sy)
                        Sy = Sy * 0.75
                        surface.SetDrawColor(Color(255, 255, 255, 255))
                        surface.SetMaterial(VC.Material.icon_engine)
                        surface.DrawTexturedRect(-Sy - 8, 3, Sy, Sy + 3)
                    end

                    Lbl:SetTall(35)
                    Lbl:SetText(VC.Lng("Engine") .. " " .. VC.Lng(txt))
                    Lbl:SetFont("VC_HUD_Bisgs")
                    Lbl:SetColor(tclr)
                    DataPanel:AddItem(Lbl)
                    table.insert(VC.CD.DataLabels, Lbl)
                end

                if data.DamagedObjects then
                    if data.DamagedObjects.light then
                        local Lbl = vgui.Create("DLabel")
                        Lbl:NoClipping(true)
                        Lbl.Paint = function(obj, Sx, Sy)
                            Sy = Sy * 0.75
                            surface.SetDrawColor(Color(255, 255, 255, 255))
                            surface.SetMaterial(VC.Material.icon_highbeams)
                            surface.DrawTexturedRect(-Sy - 8, 3, Sy, Sy + 3)
                        end

                        Lbl:SetTall(35)
                        Lbl:SetText(VC.Lng("damaged") .. " (" .. table.Count(data.DamagedObjects.light) .. ")")
                        Lbl:SetFont("VC_HUD_Bisgs")
                        Lbl:SetColor(VC.Color.White)
                        DataPanel:AddItem(Lbl)
                        table.insert(VC.CD.DataLabels, Lbl)
                    end

                    if data.DamagedObjects.wheel then
                        local Lbl = vgui.Create("DLabel")
                        Lbl:NoClipping(true)
                        Lbl.Paint = function(obj, Sx, Sy)
                            Sy = Sy * 0.75
                            surface.SetDrawColor(Color(255, 255, 255, 255))
                            surface.SetMaterial(VC.Material.icon_wheel)
                            surface.DrawTexturedRect(-Sy - 8, 3, Sy, Sy + 3)
                        end

                        Lbl:SetTall(35)
                        Lbl:SetText(VC.Lng("damaged") .. " (" .. table.Count(data.DamagedObjects.wheel) .. ")")
                        Lbl:SetFont("VC_HUD_Bisgs")
                        Lbl:SetColor(VC.Color.White)
                        DataPanel:AddItem(Lbl)
                        table.insert(VC.CD.DataLabels, Lbl)
                    end

                    if data.DamagedObjects.exhaust then
                        local Lbl = vgui.Create("DLabel")
                        Lbl:NoClipping(true)
                        Lbl.Paint = function(obj, Sx, Sy)
                            Sy = Sy * 0.75
                            surface.SetDrawColor(Color(255, 255, 255, 255))
                            surface.SetMaterial(VC.Material.icon_exhaust)
                            surface.DrawTexturedRect(-Sy - 8, 3, Sy, Sy + 3)
                        end

                        Lbl:SetTall(35)
                        Lbl:SetText(VC.Lng("damaged") .. " (" .. table.Count(data.DamagedObjects.exhaust) .. ")")
                        Lbl:SetFont("VC_HUD_Bisgs")
                        Lbl:SetColor(VC.Color.White)
                        DataPanel:AddItem(Lbl)
                        table.insert(VC.CD.DataLabels, Lbl)
                    end
                end
            end
        end
    end

    local function ChangeCustomisation(clr, skn, bgrp)
        if clr and tbl.DD_Clr then clr = nil end
        if skn and tbl.DD_Skin then skn = nil end
        if bgrp and tbl.DD_BGrp then bgrp = nil end
        cust_temp_color = nil
        cust_temp_skin = nil
        for k, v in pairs(cust_obj_tbl) do
            if IsValid(v) then v:Remove() end
        end

        cust_obj_tbl = {}
        if not Pnl.Sel_Mdl then return end
        local ID = VC.CD.getName(Pnl.Sel_Mdl.Model, Pnl.Sel_Mdl.Name, Pnl.Sel_Mdl.DefaultSkin)
        local ccaropt = Pnl.Sel_Mdl and plytbl.Vehicles and plytbl.Vehicles[ID]
        local can = false
        if clr then
            local Clr = vgui.Create("DColorMixer", OptionsPanel)
            Clr:SetTall(100)
            OptionsPanel:AddItem(Clr)
            Clr:SetAlphaBar(false)
            Clr:SetPalette(false)
            Clr:SetWangs(false)
            Clr.ValueChanged = function(idx, val)
                if ccaropt then plytbl.Vehicles[ID].TColor = val end
                cust_temp_color = val
                ModelView:SetColor(val)
            end

            Clr:SetColor(ccaropt and (ccaropt.TColor or ccaropt.Color) or Color(255, 255, 255))
            table.insert(cust_obj_tbl, Clr)
            can = true
        else
            ModelView:SetColor(Color(255, 255, 255, 255))
        end

        local skincount = ModelView:GetEntity():SkinCount()
        if skn and skincount > 1 then
            local Lbl = vgui.Create("DLabel")
            Lbl:SetTall(15)
            Lbl:SetText("")
            OptionsPanel:AddItem(Lbl)
            table.insert(cust_obj_tbl, Lbl)
            local SkinList = vgui.Create("DComboBox", OptionsPanel)
            for i = 1, skincount do
                SkinList:AddChoice(VC.Lng("Paintjob") .. " " .. i)
            end

            SkinList:ChooseOptionID((ccaropt and (plytbl.Vehicles[ID].TSkin or plytbl.Vehicles[ID].Skin) or ModelView:GetEntity():GetSkin()) + 1)
            OptionsPanel:AddItem(SkinList)
            SkinList.OnSelect = function(idx, val)
                curskin = val - 1
                cust_temp_skin = curskin
                if ccaropt then plytbl.Vehicles[ID].TSkin = curskin end
                ModelView:GetEntity():SetSkin(curskin)
            end

            if ccaropt and (ccaropt.TSkin or ccaropt.Skin) then ModelView:GetEntity():SetSkin(ccaropt.TSkin or ccaropt.Skin) end
            table.insert(cust_obj_tbl, SkinList)
            can = true
        end

        if bgrp then
            if clr or skn and skincount > 0 then
                local Lbl = vgui.Create("DLabel")
                Lbl:SetTall(10)
                Lbl:SetText("")
                OptionsPanel:AddItem(Lbl)
                table.insert(cust_obj_tbl, Lbl)
            end

            can = true
            for k, v in pairs(ModelView:GetEntity():GetBodyGroups() or {}) do
                if v.name and v.num > 1 then
                    if ccaropt then
                        local bgt = plytbl.Vehicles[ID].TBGroups or plytbl.Vehicles[ID].BGroups
                        if bgt then bgt = bgt[v.id] end
                        if bgt then ModelView:GetEntity():SetBodygroup(v.id, bgt) end
                    end

                    local MPnl = VC.Add_El_Panel(OptionsPanel, {0.5, 0.5}, 25, true)
                    local Lbl = vgui.Create("DLabel")
                    local OptN = string.gsub(v.name, "_", " ")
                    Lbl:SetText(OptN)
                    Lbl:SetColor(VC.Color.White)
                    MPnl[1]:AddItem(Lbl)
                    table.insert(cust_obj_tbl, MPnl.Main)
                    local SkinList = vgui.Create("DComboBox", OptionsPanel)
                    if v.submodels then
                        local SMC = #v.submodels
                        for k, v in pairs(v.submodels) do
                            local text = string.gsub(string.gsub(v, ".smd", ""), ".dmx", "")
                            if text == "" then text = "Disabled" end
                            text = string.gsub(text, OptN, "")
                            if text == "" or string.lower(text) == string.lower(OptN) or string.lower(text) == "a" and SMC < 3 then text = "Enabled" end
                            SkinList:AddChoice(string.gsub(text, "_", " "))
                        end
                    end

                    SkinList:ChooseOptionID(ModelView:GetEntity():GetBodygroup(v.id) + 1)
                    MPnl[2]:AddItem(SkinList)
                    SkinList.OnSelect = function(idx, val)
                        ModelView:GetEntity():SetBodygroup(v.id, val - 1)
                        if ccaropt then
                            if not plytbl.Vehicles[ID].TBGroups then plytbl.Vehicles[ID].TBGroups = {} end
                            plytbl.Vehicles[ID].TBGroups[v.id] = val - 1
                        end
                    end

                    table.insert(cust_obj_tbl, SkinList)
                end
            end
        end

        Cust_Save:SetVisible(ccaropt and true or false)
        Cust_Reset:SetVisible(ccaropt and true or false)
        OptionsPanel.Can = can
    end

    Cust_Save.Paint = function(obj, Sx, Sy)
        surface.SetMaterial(VC.Material.Button)
        surface.SetDrawColor(VC.Color.Good.r, VC.Color.Good.g, VC.Color.Good.b, obj:IsHovered() and 255 or 100)
        surface.DrawTexturedRect(0, 0, Sx, Sy)
        draw.DrawText(VC.Lng("Save"), obj:IsHovered() and "VC_Big_Italic" or "VC_Big", Sx / 2, 5, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER)
    end

    Cust_Save.DoClick = function()
        local ID = Pnl.Sel_Mdl and VC.CD.getName(Pnl.Sel_Mdl.Model, Pnl.Sel_Mdl.Name, Pnl.Sel_Mdl.DefaultSkin)
        if not ID or not plytbl.Vehicles or not plytbl.Vehicles[ID] then return end
        if plytbl.Vehicles[ID].TColor then plytbl.Vehicles[ID].Color = plytbl.Vehicles[ID].TColor end
        if plytbl.Vehicles[ID].TSkin then plytbl.Vehicles[ID].Skin = plytbl.Vehicles[ID].TSkin end
        if plytbl.Vehicles[ID].TBGroups then plytbl.Vehicles[ID].BGroups = plytbl.Vehicles[ID].TBGroups end
        ModelView.RefreshCustomisation = true
        net.Start("VC_CD_Vehicle_Options_Send")
        net.WriteEntity(NPC)
        net.WriteString(ID)
        net.WriteTable(plytbl.Vehicles[ID])
        net.SendToServer()
    end

    Cust_Reset.Paint = function(obj, Sx, Sy)
        surface.SetMaterial(VC.Material.Button)
        surface.SetDrawColor(VC.Color.White.r, VC.Color.White.g, VC.Color.White.b, obj:IsHovered() and 255 or 100)
        surface.DrawTexturedRect(0, 0, Sx, Sy)
        draw.DrawText(VC.Lng("Reset"), obj:IsHovered() and "VC_Dev_Text" or "VC_Dev_Text", Sx / 2, 0, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER)
    end

    Cust_Reset.DoClick = function()
        local ID = Pnl.Sel_Mdl and VC.CD.getName(Pnl.Sel_Mdl.Model, Pnl.Sel_Mdl.Name, Pnl.Sel_Mdl.DefaultSkin)
        if not ID or not plytbl.Vehicles or not plytbl.Vehicles[ID] then return end
        plytbl.Vehicles[ID].TColor = nil
        plytbl.Vehicles[ID].Color = nil
        plytbl.Vehicles[ID].TSkin = nil
        plytbl.Vehicles[ID].Skin = nil
        plytbl.Vehicles[ID].TBGroups = nil
        plytbl.Vehicles[ID].BGroups = nil
        ModelView.RefreshCustomisation = true
        ModelView:GetEntity():SetSkin(Pnl.Sel_Mdl.DefaultSkin or 0)
        if Pnl.Sel_Mdl.BGroups then ModelView:GetEntity():SetBodyGroups(Pnl.Sel_Mdl.BGroups) end
        ChangeCustomisation(not Pnl.Sel_Mdl.DD_Clr, not Pnl.Sel_Mdl.DD_Skin, not Pnl.Sel_Mdl.DD_BGrp)
        ChangeLeftData()
        net.Start("VC_CD_Vehicle_Options_Send")
        net.WriteEntity(NPC)
        net.WriteString(ID)
        net.WriteTable(plytbl.Vehicles[ID])
        net.SendToServer()
    end

    function Pnl.DoSelect(k, v)
        Pnl.Sel_Mdl = table.Copy(v)
        Pnl.Sel_Mdl.ID = k
        ModelView:SetModel(v.Model or "")
        ModelView.ModelLength = ModelView:GetEntity():GetRenderBounds():Length() * 1.5 - 200
        if Pnl.Sel_Mdl.BGroups then ModelView:GetEntity():SetBodyGroups(Pnl.Sel_Mdl.BGroups) end
        ModelView:GetEntity():SetSkin(Pnl.Sel_Mdl.DefaultSkin or 0)
        local ent = ModelView:GetEntity()
        ent:SetPoseParameter("vehicle_steer", -1)
        ent:SetPoseParameter("vehicle_wheel_rl_height", 0.5)
        ent:SetPoseParameter("vehicle_wheel_rr_height", 0.5)
        ent:SetPoseParameter("vehicle_wheel_fl_height", 0.5)
        ent:SetPoseParameter("vehicle_wheel_fr_height", 0.5)
        if ModelView.VC_ToSelect and ModelView.VC_ToSelect ~= Pnl.Sel_Mdl.ID then
            ModelView.VC_LastSpeed = SwitchSpeed * 1.45 * math.Clamp(ModelView.VC_ToSelect - Pnl.Sel_Mdl.ID, -1, 1)
        else
            ModelView.VC_ToSelect = nil
        end

        ChangeCustomisation(not v.DD_Clr, not v.DD_Skin, not v.DD_BGrp)
        ChangeLeftData()
    end

    function Pnl.NextModel()
        if Pnl.Sel_Mdl then
            local i, amount = Pnl.Sel_Mdl.ID + 1, #Pnl.VC_VehicleList
            if amount > 1 then
                if i <= amount then
                    Pnl.DoSelect(i, Pnl.VC_VehicleList[i])
                else
                    Pnl.DoSelect(1, Pnl.VC_VehicleList[1])
                end
            end
        end
    end

    function Pnl.PrevModel()
        if Pnl.Sel_Mdl then
            local i, amount = Pnl.Sel_Mdl.ID - 1, #Pnl.VC_VehicleList
            if amount > 1 then
                if i > 0 then
                    Pnl.DoSelect(i, Pnl.VC_VehicleList[i])
                else
                    Pnl.DoSelect(amount, Pnl.VC_VehicleList[amount])
                end
            end
        end
    end

    local Close = CreateButtonTop(VC.Lng("Close"), MPx - 100, nil, true)
    Close.DoClick = function() Pnl:Close() end
    local All = CreateButtonTop(VC.Lng("All"), 0, 1)
    All.DoClick = function()
        ModelView.VC_ToSelect = nil
        if All.IgnoreAnim then
            All.IgnoreAnim = nil
        else
            HorzResetAlpha()
        end

        Pnl.VC_RefreshModelList = true
        Pnl.Sel = 1
    end

    local Purchased = CreateButtonTop(VC.Lng("Purchased"), 200, 2)
    Purchased.DoClick = function()
        ModelView.VC_ToSelect = nil
        HorzResetAlpha()
        Pnl.VC_RefreshModelList = true
        Pnl.Sel = 2
    end

    local Available = CreateButtonTop(VC.Lng("Available"), 400, 3)
    Available.DoClick = function()
        ModelView.VC_ToSelect = nil
        HorzResetAlpha()
        Pnl.VC_RefreshModelList = true
        Pnl.Sel = 3
    end

    local Job = CreateButtonTop(VC.Lng("JobRelated"), 600, 4)
    Job.DoClick = function()
        ModelView.VC_ToSelect = nil
        HorzResetAlpha()
        Pnl.VC_RefreshModelList = true
        Pnl.Sel = 4
    end

    All.IgnoreAnim = true
    All.DoClick()
    Horz.Think = function()
        if Btn_Prev:IsDown() then
            Horz.OffsetX = Horz.OffsetX - (2000 * Pnl.FrameRate)
            Horz:InvalidateLayout(true)
        end

        if Btn_Next:IsDown() then
            Horz.OffsetX = Horz.OffsetX + (2000 * Pnl.FrameRate)
            Horz:InvalidateLayout(true)
        end
    end

    function Horz:OnMouseWheeled(delta)
        Horz.OffsetX = Horz.OffsetX + delta * -100
        self:InvalidateLayout(true)
        return true
    end

    function Horz:PerformLayout()
        local w, h = self:GetSize()
        local x = 0
        self.pnlCanvas:SetTall(h)
        if self.Panels then
            for k, v in pairs(self.Panels) do
                if IsValid(v) then
                    v:SetPos(x, 0)
                    v:SetTall(h)
                    v:ApplySchemeSettings()
                    x = x + v:GetWide() - self.m_iOverlap
                end
            end

            self.pnlCanvas:SetWide(x + self.m_iOverlap)
            if w < self.pnlCanvas:GetWide() then
                self.OffsetX = math.Clamp(self.OffsetX, 0, self.pnlCanvas:GetWide() - self:GetWide())
            else
                self.OffsetX = 0
            end

            self.pnlCanvas.x = Lerp(0.1, self.pnlCanvas.x, -self.OffsetX)
        end

        self.btnLeft:SetVisible(false)
        self.btnRight:SetVisible(false)
        Btn_Prev:SetVisible(self.pnlCanvas.x < -25)
        Btn_Next:SetVisible(self.pnlCanvas.x + self.pnlCanvas:GetWide() > (self:GetWide() + 25))
    end

    Btn_Next.Paint = function(obj, Sx, Sy)
        surface.SetDrawColor(255, 255, 255, obj:IsHovered() and 255 or 55)
        surface.SetMaterial(VC.Material.icon_right)
        surface.DrawTexturedRect(0, 10, Sx, Sy - 20)
    end

    Btn_Prev.Paint = function(obj, Sx, Sy)
        surface.SetDrawColor(255, 255, 255, obj:IsHovered() and 255 or 55)
        surface.SetMaterial(VC.Material.icon_left)
        surface.DrawTexturedRect(0, 10, Sx, Sy - 20)
    end

    local nvf = VC.Lng("NoVehiclesFound")
    Horz.Paint = function(obj, Sx, Sy)
        draw.RoundedBox(0, 0, 0, Sx, Sy, clr)
        surface.SetDrawColor(clr)
        surface.SetMaterial(VC.Material.Fade)
        surface.DrawTexturedRectRotated(Sx + VC.FadeW / 2, Sy / 2, VC.FadeW, Sy, 0)
        surface.DrawTexturedRectRotated(-VC.FadeW / 2, Sy / 2, VC.FadeW, Sy, 180)
        if not Pnl.Sel_Mdl then draw.DrawText(nvf, "VC_Big_Italic", Sx / 2, 35, VC.Color.Blue, TEXT_ALIGN_CENTER) end
    end

    local MainPanel = VC.Add_El_List(ModelView:GetWide() / 2 - 200, ModelView:GetTall() - 100 - 50, 400, 50)
    MainPanel:SetParent(Pnl)
    MainPanel:NoClipping(true)
    MainPanel:AlphaTo(0, 0, 0)
    MainPanel.Paint = function(obj, Sx, Sy)
        draw.RoundedBox(0, 0, 0, Sx, Sy, clr)
        surface.SetMaterial(VC.Material.Fade)
        surface.DrawTexturedRectRotated(Sx + VC.FadeW / 2, Sy / 2, VC.FadeW, Sy, 0)
        surface.DrawTexturedRectRotated(-VC.FadeW / 2, Sy / 2, VC.FadeW, Sy, 180)
    end

    local shrt = VC.getCurCurrency().shrt
    local symbol = VC.getCurCurrency().symbol
    local mat_free = Material("vcmod/pricetag_free.png")
    local mat_price = Material("vcmod/pricetag.png")
    local BuySell = vgui.Create("DButton")
    BuySell:SetSize(MainPanel:GetWide() / 2, MainPanel:GetTall() - 8)
    BuySell:SetPos(0, 4)
    BuySell:SetParent(MainPanel)
    BuySell:NoClipping(true)
    BuySell:SetText("")
    BuySell.VC_Type = 2
    local Spawn = vgui.Create("DButton")
    Spawn:SetSize(MainPanel:GetWide() / 2, MainPanel:GetTall() - 8)
    Spawn:SetPos(MainPanel:GetWide() / 2 + 8, 4)
    Spawn:SetParent(MainPanel)
    Spawn:NoClipping(true)
    Spawn:SetText("")
    Spawn.VC_Type = 1
    BuySell.DoClick = function()
        if BuySell.VC_Type == 1 then
            if Pnl.Sel_Mdl then
                local id = VC.CD.getName(Pnl.Sel_Mdl.Model, Pnl.Sel_Mdl.Name, Pnl.Sel_Mdl.DefaultSkin)
                Pnl.VC_RefreshModelList = 2
                if plytbl.Vehicles and plytbl.Vehicles[id] then return end
                if VC.isPlayerRestricted(LocalPlayer(), nil, VC.CD.Main_Pnl.Sel_Mdl) then return false end
                if not VC.CanAfford(LocalPlayer(), Pnl.Sel_Mdl.Price) then
                    VCPopup("CD_Cant_Afford", "cross", 2.5)
                    return
                end

                local Settings = {}
                VC.CD.Buy_Vehicle(NPC, id, Settings)
                if not plytbl.Vehicles then plytbl.Vehicles = {} end
                plytbl.Vehicles[id] = Settings
                VCPopup("Purchased", "check", 1.5)
                HorzResetAlpha()
            end
        elseif BuySell.VC_Type == 2 then
            if Spawn.VC_Type == 4 then
                VCPopup("FirstReturnTheVehicle", "cross")
                Pnl.VC_RefreshModelList = 3
                return
            end

            local C_Pnl = vgui.Create("DFrame")
            C_Pnl:SetSize(400, 200)
            C_Pnl:SetTitle("")
            C_Pnl:SetPos(ScrW() / 2 - C_Pnl:GetWide() / 2, ScrH() / 2 - C_Pnl:GetTall() / 2)
            C_Pnl:SetDraggable(false)
            C_Pnl:ShowCloseButton(false)
            C_Pnl:AlphaTo(0, 0, 0)
            C_Pnl:AlphaTo(255, 0.2, 0)
            C_Pnl:SetParent(Pnl)
            C_Pnl.VC_FocusCheckTime = CurTime() + 1
            C_Pnl.Paint = function(obj, Sx, Sy)
                if Pnl.Sel_Mdl then
                    draw.RoundedBox(0, 0, 0, Sx, Sy, VC.Color.Main)
                    surface.SetDrawColor(255, 255, 255, 225)
                    local Sure = VC.Lng("AreYouSureYouWantToSell") .. ' "' .. Pnl.Sel_Mdl.Name .. '"?'
                    draw.DrawText(Sure, "VC_Dev_Text", Sx / 2, 30, VC.Color.Blue, TEXT_ALIGN_CENTER)
                    local sz = surface.GetTextSize(Sure or "") + 20
                    if sz > Sx then C_Pnl:SetWide(sz) end
                    draw.DrawText(VC.Lng("OriginalPrice") .. ":", nil, 30, 70, VC.Color.Blue, TEXT_ALIGN_LEFT)
                    draw.DrawText(symbol .. VC.PreparePrice(Pnl.Sel_Mdl.Price), nil, 170, 70, VC.Color.White, TEXT_ALIGN_LEFT)
                    draw.DrawText(VC.Lng("RefundPercentage") .. ":", nil, 30, 85, VC.Color.Blue, TEXT_ALIGN_LEFT)
                    draw.DrawText(VC.CD_RefundPrice .. " %", nil, 170, 85, VC.Color.White, TEXT_ALIGN_LEFT)
                    draw.DrawText(VC.Lng("SellingPrice") .. ":", nil, 30, 100, VC.Color.Blue, TEXT_ALIGN_LEFT)
                    draw.DrawText(symbol .. VC.PreparePrice(Pnl.Sel_Mdl.Price * VC.CD_RefundPrice / 100), nil, 170, 100, VC.Color.White, TEXT_ALIGN_LEFT)
                    if CurTime() >= C_Pnl.VC_FocusCheckTime and not C_Pnl:HasFocus() then C_Pnl:Remove() end
                end
            end

            local Accept = vgui.Create("DButton", C_Pnl)
            Accept:SetText(VC.Lng("Accept"))
            Accept:SetFont("VC_Big_Italic")
            Accept:SetSize(C_Pnl:GetWide() / 2 - 30, 50)
            Accept:SetPos(20, C_Pnl:GetTall() - Accept:GetTall() - 15)
            Accept.Paint = function(obj, Sx, Sy)
                draw.RoundedBox(0, 0, 0, Sx, Sy, Color(0, 255, 0, 255))
                draw.RoundedBox(0, 0, 0, Sx, Sy, Color(255, 255, 255, 100))
            end

            local Cancel = vgui.Create("DButton", C_Pnl)
            Cancel:SetText(VC.Lng("Cancel"))
            Cancel:SetFont("VC_Big_Italic")
            Cancel:SetSize(C_Pnl:GetWide() / 2 - 30, 50)
            Cancel:SetPos(C_Pnl:GetWide() / 2 + 10, C_Pnl:GetTall() - Cancel:GetTall() - 15)
            Cancel.Paint = function(obj, Sx, Sy)
                draw.RoundedBox(0, 0, 0, Sx, Sy, VC.Color.Bad)
                draw.RoundedBox(0, 0, 0, Sx, Sy, Color(255, 255, 255, 55))
            end

            Accept.DoClick = function()
                if Pnl.Sel_Mdl then
                    local id = VC.CD.getName(Pnl.Sel_Mdl.Model, Pnl.Sel_Mdl.Name, Pnl.Sel_Mdl.DefaultSkin)
                    if not plytbl.Vehicles or not plytbl.Vehicles[id] then
                        Pnl:Close()
                        return
                    end

                    VC.CD.Sell_Vehicle(NPC, id)
                    plytbl.Vehicles[id] = nil
                    VCPopup("Sold", "check", 1.5)
                    HorzResetAlpha()
                    Pnl.VC_RefreshModelList = 2
                    C_Pnl:Close()
                end
            end

            C_Pnl.Think = function()
                local backDown = input.IsKeyDown(KEY_BACKSPACE)
                if backDown and not backPressed then
                    Cancel.DoClick()
                    backPressed = true
                elseif not backDown and backPressed then
                    backPressed = false
                end

                local enterDown = input.IsKeyDown(KEY_ENTER)
                if enterDown and not enterPressed then
                    Accept.DoClick()
                    enterPressed = true
                elseif not enterDown and enterPressed then
                    enterPressed = false
                end
            end

            Cancel.DoClick = function() C_Pnl:Close() end
            C_Pnl:MakePopup()
        end
    end

    local text_purcase = VC.Lng("Purchase")
    local text_sell = VC.Lng("Sell")
    BuySell.Paint = function(obj, Sx, Sy)
        if not MainPanel.Price then return end
        local price = VC.PreparePrice(math.Round(MainPanel.Price, 3))
        surface.SetMaterial(VC.Material.Button)
        if BuySell.VC_Type == 1 then
            surface.SetDrawColor(VC.Color.Good.r, VC.Color.Good.g, VC.Color.Good.b, obj:IsHovered() and 255 or 100)
            surface.DrawTexturedRect(0, 0, Sx, Sy)
            draw.DrawText(text_purcase, obj:IsHovered() and "VC_Big_Italic" or "VC_Big", Sx / 2, 8, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER)
            if price == 0 then
                surface.SetDrawColor(255, 255, 255, 255)
                surface.SetMaterial(mat_free)
                surface.DrawTexturedRect(0, 0, 40, 40)
            else
                local text = symbol .. price
                surface.SetFont("VC_Dev_Text")
                local sz = surface.GetTextSize(text or "") + 20
                surface.SetDrawColor(255, 255, 255, 255)
                surface.SetMaterial(mat_price)
                surface.DrawTexturedRect(-25, Sy - 20, 90, 20)
                draw.RoundedBox(4, -sz + 40, Sy - 20, sz + 5, 18, Color(217, 54, 0, 255))
                local tclr = table.Copy(VC.Color.White)
                draw.DrawText(text, "VC_Dev_Text", 35, Sy - 19, tclr, TEXT_ALIGN_RIGHT)
            end
        elseif BuySell.VC_Type == 2 then
            local text = symbol .. price
            surface.SetFont("VC_Dev_Text")
            local sz = surface.GetTextSize(text or "") + 20
            surface.SetDrawColor(VC.Color.Neutral.r, VC.Color.Neutral.g, VC.Color.Neutral.b, obj:IsHovered() and 255 or 100)
            surface.DrawTexturedRect(0, 0, Sx, Sy)
            draw.DrawText(text_sell, obj:IsHovered() and "VC_Big_Italic" or "VC_Big", Sx / 2, 8, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER)
            surface.SetDrawColor(255, 255, 255, 255)
            surface.SetMaterial(mat_price)
            surface.DrawTexturedRect(-25, Sy - 20, 90, 20)
            draw.RoundedBox(4, -sz + 40, Sy - 20, sz + 5, 18, Color(217, 54, 0, 255))
            local tclr = table.Copy(VC.Color.White)
            draw.DrawText(text, "VC_Dev_Text", 35, Sy - 19, tclr, TEXT_ALIGN_RIGHT)
        end
    end

    Spawn.DoClick = function()
        if not Pnl.Sel_Mdl then return end
        local ID = VC.CD.getName(Pnl.Sel_Mdl.Model, Pnl.Sel_Mdl.Name, Pnl.Sel_Mdl.DefaultSkin)
        local Settings = plytbl.Vehicles and plytbl.Vehicles[ID]
        if not Settings then
            Settings = {}
            Settings.Color = cust_temp_color
            Settings.Skin = cust_temp_skin
        end

        if Spawn.VC_Type == 1 then
            if Pnl.Sel_Mdl then
                VC.CD.TestDrive(NPC, ID, Settings)
                Pnl.VC_RefreshModelList = 3
            end
        elseif Spawn.VC_Type == 2 then
            if Pnl.Sel_Mdl then
                VC.CD.Spawn(NPC, ID, tbl, Settings, plytbl)
                Pnl.VC_RefreshModelList = 3
            end
        elseif Spawn.VC_Type == 3 then
            VC.CD.EndTestDrive()
        elseif Spawn.VC_Type == 4 then
            VC.CD.Return(NPC, ID)
        end
    end

    Spawn.Paint = function(obj, Sx, Sy)
        surface.SetMaterial(VC.Material.Button)
        if Spawn.VC_Type == 1 then
            local tclr = table.Copy(VC.Color.Blue)
            surface.SetDrawColor(tclr.r, tclr.g, tclr.b, obj:IsHovered() and 255 or 100)
            surface.DrawTexturedRect(0, 0, Sx, Sy)
            draw.DrawText(VC.Lng("TestDrive"), obj:IsHovered() and "VC_Big_Italic" or "VC_Big", Sx / 2, 8, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER)
        elseif Spawn.VC_Type == 2 then
            surface.SetDrawColor(VC.Color.Blue.r, VC.Color.Blue.g, VC.Color.Blue.b, obj:IsHovered() and 255 or 100)
            surface.DrawTexturedRect(0, 0, Sx, Sy)
            draw.DrawText(VC.Lng("Spawn"), obj:IsHovered() and "VC_Big_Italic" or "VC_Big", Sx / 2, 8, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER)
        elseif Spawn.VC_Type == 3 then
            local tclr = table.Copy(VC.Color.White)
            surface.SetDrawColor(tclr.r, tclr.g, tclr.b, obj:IsHovered() and 255 or 100)
            surface.DrawTexturedRect(0, 0, Sx, Sy)
            draw.DrawText(VC.Lng("EndTestDrive"), obj:IsHovered() and "VC_Big_Italic" or "VC_Big", Sx / 2, 8, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER)
        elseif Spawn.VC_Type == 4 then
            local tclr = table.Copy(VC.Color.Bad)
            tclr.r = 255
            tclr.g = tclr.r / 2
            surface.SetDrawColor(tclr.r, tclr.g, tclr.b, obj:IsHovered() and 255 or 100)
            surface.DrawTexturedRect(0, 0, Sx, Sy)
            draw.DrawText(VC.Lng("Return"), obj:IsHovered() and "VC_Big_Italic" or "VC_Big", Sx / 2, 8, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER)
        end
    end

    local function GetTblID(k, dec)
        local ID, amount = 0, #Pnl.VC_VehicleList
        if dec then
            ID = k - 1
            if ID < 1 then ID = amount end
        else
            ID = k + 1
            if ID > amount then ID = 1 end
        end
        return ID
    end

    local models = {}
    local tabPressed = nil
    local spacePressed = nil
    Pnl.Think = function()
        if Pnl:HasFocus() then
            local tabDown = input.IsKeyDown(KEY_TAB)
            if tabDown and not tabPressed then
                if Pnl.Sel then
                    if Pnl.Sel == 1 then
                        Purchased.DoClick()
                    elseif Pnl.Sel == 2 then
                        Available.DoClick()
                    elseif Pnl.Sel == 3 then
                        Job.DoClick()
                    else
                        All.DoClick()
                    end
                end

                tabPressed = true
            elseif not tabDown and tabPressed then
                tabPressed = false
            end

            local spaceDown = input.IsKeyDown(KEY_SPACE)
            if spaceDown and not spacePressed then
                Spawn.DoClick()
                spacePressed = true
            elseif not spaceDown and spacePressed then
                spacePressed = false
            end

            local enterDown = input.IsKeyDown(KEY_ENTER)
            if enterDown and not enterPressed then
                BuySell.DoClick()
                enterPressed = true
            elseif not enterDown and enterPressed then
                enterPressed = false
            end

            local backDown = input.IsKeyDown(KEY_BACKSPACE)
            if backDown and not backPressed then
                Close.DoClick()
                backPressed = true
            elseif not backDown and backPressed then
                backPressed = false
            end

            local leftDown = input.IsKeyDown(KEY_A) or input.IsKeyDown(KEY_LEFT)
            if leftDown then if Pnl.Sel_Mdl then ModelView.VC_LastSpeed = ModelView.VC_LastSpeed - 10 end end
            local rightDown = input.IsKeyDown(KEY_D) or input.IsKeyDown(KEY_RIGHT)
            if rightDown then if Pnl.Sel_Mdl then ModelView.VC_LastSpeed = ModelView.VC_LastSpeed + 10 end end
            local upDown = input.IsKeyDown(KEY_W) or input.IsKeyDown(KEY_UP)
            if upDown then if Pnl.Sel_Mdl then ModelView.VC_RotX = ModelView.VC_RotX - 17 end end
            local downDown = input.IsKeyDown(KEY_S) or input.IsKeyDown(KEY_DOWN)
            if downDown then if Pnl.Sel_Mdl then ModelView.VC_RotX = ModelView.VC_RotX + 17 end end
        end

        if not ModelView.VC_LastSpeed then ModelView.VC_LastSpeed = 0 end
        local Alpha = MainPanel:GetAlpha()
        local ShouldDraw = Pnl.Sel_Mdl and ModelView.VC_Progress and ModelView.VC_Progress > -250 and ModelView.VC_Progress < 250 and (math.abs(ModelView.VC_LastSpeed) < 20 or ModelView.VC_IsCapturing)
        if ShouldDraw and (Alpha == 0 or not MainPanel:IsVisible()) then
            MainPanel:SetVisible(true)
            MainPanel:AlphaTo(255, 0.3, 0)
            local ID = VC.CD.getName(Pnl.Sel_Mdl.Model, Pnl.Sel_Mdl.Name, Pnl.Sel_Mdl.DefaultSkin)
            BuySell.VC_Type = plytbl.Vehicles and plytbl.Vehicles[ID] and 2 or 1
            Spawn.VC_Type = BuySell.VC_Type
            if VC.CD.SpawnedTestDriveData then Spawn.VC_Type = 3 end
            if plytbl.Vehicles and plytbl.Vehicles[ID] and plytbl.Vehicles[ID].Spawned then Spawn.VC_Type = 4 end
            MainPanel.Price = Pnl.Sel_Mdl.Price
            ChangeLeftData()
        elseif Alpha == 255 and not ShouldDraw then
            MainPanel:AlphaTo(0, 0.1, 0)
            ChangeLeftData()
        end

        if not ShouldDraw and Alpha == 0 then MainPanel:SetVisible(false) end
        local Alpha = OptionsPanel:GetAlpha()
        local ShouldDraw = Pnl.Sel_Mdl and OptionsPanel.Can and ModelView.VC_Progress and ModelView.VC_Progress > -100 and ModelView.VC_Progress < 100 and math.abs(ModelView.VC_LastSpeed) < 20 and not ModelView.VC_IsCapturing
        if ShouldDraw and (Alpha == 0 or not OptionsPanel:IsVisible()) then
            OptionsPanel:SetVisible(true)
            OptionsPanel:AlphaTo(255, 0.3, 0)
        elseif Alpha == 255 and not ShouldDraw then
            OptionsPanel:AlphaTo(0, 0.1, 0)
        end

        if not ShouldDraw and Alpha == 0 then OptionsPanel:SetVisible(false) end
        local Alpha = DataPanel:GetAlpha()
        local ID = Pnl.Sel_Mdl and VC.CD.getName(Pnl.Sel_Mdl.Model, Pnl.Sel_Mdl.Name, Pnl.Sel_Mdl.DefaultSkin)
        local ShouldDraw = ID and plytbl.Vehicles and plytbl.Vehicles[ID] and not plytbl.Vehicles[ID].Spawned and Pnl.Sel_Mdl and DataPanel and ModelView.VC_Progress and ModelView.VC_Progress > -100 and ModelView.VC_Progress < 100 and math.abs(ModelView.VC_LastSpeed) < 20 and not ModelView.VC_IsCapturing
        if ShouldDraw and (Alpha == 0 or not DataPanel:IsVisible()) then
            DataPanel:SetVisible(true)
            DataPanel:AlphaTo(255, 0.3, 0)
            local ID = VC.CD.getName(Pnl.Sel_Mdl.Model, Pnl.Sel_Mdl.Name, Pnl.Sel_Mdl.DefaultSkin)
        elseif Alpha == 255 and not ShouldDraw then
            DataPanel:AlphaTo(0, 0.1, 0)
        end

        if VC.CD.Main_Pnl.Returned then
            VC_RET = VC.CD.Main_Pnl.Returned
            local symbol = VC.getCurCurrency().symbol
            if VC.CD.Main_Pnl.Returned[2] == 0 then
                VCPopup("VehicleReturned", "check")
            else
                VCPopup(VC.Lng("VehicleTowedFor") .. " " .. symbol .. VC.PreparePrice(VC.CD.Main_Pnl.Returned[2]) .. ".", "info", 4)
            end

            if plytbl.Vehicles and plytbl.Vehicles[VC.CD.Main_Pnl.Returned[1]] then
                plytbl.Vehicles[VC.CD.Main_Pnl.Returned[1]] = VC.CD.Main_Pnl.Returned[3]
                plytbl.Vehicles[VC.CD.Main_Pnl.Returned[1]].Spawned = nil
                if VC.CD.getName(Pnl.Sel_Mdl.Model, Pnl.Sel_Mdl.Name, Pnl.Sel_Mdl.DefaultSkin) == VC.CD.Main_Pnl.Returned[1] then VC.CD.Main_Pnl.VC_RefreshModelList = 3 end
            end

            VC.CD.Main_Pnl.Returned = nil
            ChangeLeftData()
        end

        Pnl.FrameRate = VGUIFrameTime() - (Pnl.FrameTime or 0)
        Pnl.FrameTime = VGUIFrameTime()
        if Pnl.VC_RefreshModelList then
            Pnl.VC_VehicleList = {}
            if Pnl.Sel == 1 then
                for k, v in pairs(tbl.Vehicles) do
                    table.insert(Pnl.VC_VehicleList, v)
                end
            elseif Pnl.Sel == 2 then
                if plytbl and plytbl.Vehicles then
                    for k, v in pairs(plytbl.Vehicles) do
                        if tbl.Vehicles[k] then table.insert(Pnl.VC_VehicleList, tbl.Vehicles[k]) end
                    end
                end
            elseif Pnl.Sel == 3 then
                for k, v in pairs(tbl.Vehicles) do
                    local can = true
                    if plytbl and plytbl.Vehicles and plytbl.Vehicles[k] then can = false end
                    if can then table.insert(Pnl.VC_VehicleList, v) end
                end
            elseif Pnl.Sel == 4 then
                if tbl.JobRestrict then
                    local JobName = LocalPlayer().getJobTable and LocalPlayer():getJobTable() and LocalPlayer():getJobTable().name or "Unknown"
                    for k, v in pairs(tbl.Vehicles) do
                        local can = true
                        if not v.JobRestrict[JobName] then can = false end
                        if can then table.insert(Pnl.VC_VehicleList, v) end
                    end
                end
            end

            local ttbl = {}
            for k, v in pairs(Pnl.VC_VehicleList) do
                ttbl[k] = (v.Name or "Unknown") .. "__vc__" .. k
            end

            table.sort(ttbl)
            local ttsbl2 = {}
            for k, v in pairs(ttbl) do
                local num = tonumber(string.Explode("__vc__", v)[2])
                ttsbl2[k] = Pnl.VC_VehicleList[num]
            end

            Pnl.VC_VehicleList = table.Copy(ttsbl2)
            if Pnl.VC_RefreshModelList == 3 then
                MainPanel:AlphaTo(0, 0.1, 0)
                Pnl.VC_RefreshModelList = nil
                return
            end

            local oldmdl = Pnl.Sel_Mdl and table.Copy(Pnl.Sel_Mdl) or {}
            local oldclr = nil
            local oldskin = nil
            local oldbgrps = nil
            local LProgress, LSpeed = ModelView.VC_Progress, ModelView.VC_LastSpeed
            if IsValid(ModelView:GetEntity()) then
                oldclr = ModelView:GetColor()
                oldskin = ModelView:GetEntity():GetSkin()
                oldbgrps = ""
                if oldbgrps == "" then
                    oldbgrps = oldbgrps .. "0"
                    for k, v in pairs(ModelView:GetEntity():GetBodyGroups()) do
                        oldbgrps = oldbgrps .. ModelView:GetEntity():GetBodygroup(k)
                    end
                end
            end

            local mat_lock = Material("icon16/lock.png")
            ModelView:SetModel("")
            ModelView.ModelLength = 0
            Pnl.Sel_Mdl = nil
            ModelView.VC_Progress = 350
            ModelView.VC_LastSpeed = 25
            for k, v in pairs(models) do
                if IsValid(v[1]) then v[1]:Remove() end
            end

            models = {}
            local LastOffset = Horz.OffsetX
            for k, v in pairs(Pnl.VC_VehicleList) do
                local mdl = vgui.Create("DModelPanel", Pnl)
                mdl:SetModel(v.Model or "")
                if IsValid(mdl:GetEntity()) then
                    mdl.ModelLength = mdl:GetEntity():GetRenderBounds():Length() * 1.5 - 200
                    mdl:SetLookAng(Vector(0, 0, 62))
                    mdl:SetSize(250, 150)
                    function mdl:LayoutEntity()
                        mdl:SetLookAng(Angle(0, 180, 0))
                        mdl:SetCamPos(Vector(mdl:IsHovered() and 250 or 280, 0, 60) - Angle(0, 180, 0):Forward() * mdl.ModelLength)
                        return
                    end

                    mdl.DoClick = function()
                        if Pnl.Sel_Mdl then
                            ModelView.VC_ToSelect = k
                            ModelView.VC_Progress = 0
                            ModelView.VC_LastSpeed = SwitchSpeed * math.Clamp(k - Pnl.Sel_Mdl.ID, -1, 1)
                            MainPanel:AlphaTo(0, 0.1, 0)
                        else
                            Pnl.DoSelect(k, v)
                        end
                    end

                    mdl.DoDoubleClick = function()
                        Pnl.DoSelect(k, v)
                        ModelView.VC_Progress = 0
                        ModelView.VC_LastSpeed = 0
                    end

                    local ID = VC.CD.getName(v.Model, v.Name, v.DefaultSkin)
                    local Restr = VC.isPlayerRestricted(LocalPlayer(), v, tbl, true)
                    if v.BGroups then mdl:GetEntity():SetBodyGroups(v.BGroups) end
                    mdl:GetEntity():SetSkin(v.DefaultSkin or 0)
                    mdl.PaintOver = function(obj, Sx, Sy)
                        local tclr = table.Copy(clr)
                        local sel = Pnl.Sel_Mdl and Pnl.Sel_Mdl.Name == v.Name and (Pnl.Sel_Mdl.DefaultSkin or 0) == (v.DefaultSkin or 0) and Pnl.Sel_Mdl.Model == v.Model
                        draw.RoundedBox(0, 0, 0, Sx, 25, clr)
                        if not mdl:IsHovered() and not (mdl:IsHovered() or sel) then draw.RoundedBox(0, 0, 0, Sx, Sy, Color(0, 0, 0, 200)) end
                        if mdl:IsDown() then draw.RoundedBox(0, 0, 0, Sx, Sy, Color(0, 100, 100, 55)) end
                        draw.DrawText(v.Name, nil, Sx / 2, 7, table.Copy(VC.Color.White), TEXT_ALIGN_CENTER)
                        local pos = 0
                        if mdl:IsHovered() then
                            tclr = table.Copy(VC.Color.Blue)
                            surface.SetDrawColor(tclr)
                            surface.DrawLine(pos, 0, pos + Sx - 1, 0)
                            surface.DrawLine(pos, Sy - 1, pos + Sx - 1, Sy - 1)
                            surface.DrawLine(pos, 0, pos, Sy - 1)
                            surface.DrawLine(pos + Sx - 1, 0, pos + Sx - 1, Sy - 1)
                        end

                        if sel then
                            tclr = table.Copy(VC.Color.Good)
                            pos = -ModelView.VC_Progress / 3
                            surface.SetDrawColor(tclr)
                            surface.DrawLine(pos, 0, pos + Sx - 1, 0)
                            surface.DrawLine(pos, Sy - 1, pos + Sx - 1, Sy - 1)
                            surface.DrawLine(pos, 0, pos, Sy - 1)
                            surface.DrawLine(pos + Sx - 1, 0, pos + Sx - 1, Sy - 1)
                        end

                        local alpha = (mdl:IsHovered() or sel) and 255 or 55
                        if v.Price == 0 then
                            surface.SetDrawColor(255, 255, 255, (mdl:IsHovered() or sel) and 255 or 30)
                            surface.SetMaterial(mat_free)
                            surface.DrawTexturedRect(0, 0, 80, 80)
                        else
                            local text = symbol .. VC.PreparePrice(v.Price)
                            surface.SetFont("VC_Dev_Text")
                            local sz = math.Round(surface.GetTextSize(text or "") + 20)
                            draw.RoundedBox(4, math.Round(Sx - sz + 5), Sy - 20, sz - 10, 18, Color(217, 54, 0, alpha))
                            local tclr = table.Copy(VC.Color.White)
                            tclr.a = alpha
                            draw.DrawText(text, "VC_Dev_Text", Sx - 10, Sy - 19, tclr, TEXT_ALIGN_RIGHT)
                        end

                        surface.SetDrawColor(255, 255, 255, alpha)
                        if Restr then
                            surface.SetDrawColor(255, 255, 255, 255)
                            surface.SetMaterial(mat_lock)
                            surface.DrawTexturedRect(5, 5, 15, 15)
                        end

                        if plytbl.Vehicles and plytbl.Vehicles[ID] then
                            surface.SetMaterial(VC.Material.Check)
                            surface.DrawTexturedRect(Sx - 30, 0, 30, 30)
                        end

                        if Pnl.Sel_Mdl and Pnl.Sel_Mdl.ID ~= k and Pnl.Sel_Mdl.ID == GetTblID(k) then
                            tclr = table.Copy(VC.Color.Good)
                            pos = -ModelView.VC_Progress / 3 + mdl:GetWide() + 1
                            surface.SetDrawColor(tclr)
                            surface.DrawLine(pos, 0, pos + Sx - 1, 0)
                            surface.DrawLine(pos, Sy - 1, pos + Sx - 1, Sy - 1)
                            surface.DrawLine(pos, 0, pos, Sy - 1)
                            surface.DrawLine(pos + Sx - 1, 0, pos + Sx - 1, Sy - 1)
                        end

                        if Pnl.Sel_Mdl and Pnl.Sel_Mdl.ID ~= k and Pnl.Sel_Mdl.ID == GetTblID(k, true) then
                            tclr = table.Copy(VC.Color.Good)
                            pos = -ModelView.VC_Progress / 3 - mdl:GetWide() - 1
                            surface.SetDrawColor(tclr)
                            surface.DrawLine(pos, 0, pos + Sx - 1, 0)
                            surface.DrawLine(pos, Sy - 1, pos + Sx - 1, Sy - 1)
                            surface.DrawLine(pos, 0, pos, Sy - 1)
                            surface.DrawLine(pos + Sx - 1, 0, pos + Sx - 1, Sy - 1)
                        end
                    end

                    Horz:AddPanel(mdl)
                    table.insert(models, {mdl, ID})
                end
            end

            Horz.OffsetX = LastOffset
            Horz.pnlCanvas.x = -Horz.OffsetX
            local ran = false
            if oldmdl then
                for k, v in pairs(Pnl.VC_VehicleList) do
                    if (v.Name or "Unknown") == (oldmdl.Name or "Unknown") and v.Model == oldmdl.Model and (v.DefaultSkin or 0) == (oldmdl.DefaultSkin or 0) then
                        ModelView.VC_Progress = LProgress
                        ModelView.VC_LastSpeed = LSpeed
                        if Pnl.VC_RefreshModelList == 2 then MainPanel:AlphaTo(0, 0.1, 0) end
                        ran = true
                        Pnl.DoSelect(k, v)
                        if oldclr then
                            ModelView:SetColor(oldclr)
                            ModelView:GetEntity():SetSkin(oldskin)
                            ModelView:GetEntity():SetBodyGroups(oldbgrps)
                        end

                        break
                    end
                end
            end

            if not ran and #Pnl.VC_VehicleList > 0 then Pnl.DoSelect(1, Pnl.VC_VehicleList[1]) end
            Pnl.VC_RefreshModelList = nil
            ModelView.RefreshCustomisation = true
            ModelView.RefreshLeftData = true
        end

        if ModelView.RefreshCustomisation then
            for k, v in pairs(models) do
                if plytbl.Vehicles and plytbl.Vehicles[v[2]] then
                    if not tbl.DD_Clr and not tbl.Vehicles[v[2]].DD_Clr then v[1]:SetColor(plytbl.Vehicles[v[2]].Color or Color(255, 255, 255, 255)) end
                    if not tbl.DD_Skin and not tbl.Vehicles[v[2]].DD_Skin then v[1]:GetEntity():SetSkin(plytbl.Vehicles[v[2]].Skin or tbl.Vehicles[v[2]].DefaultSkin or 0) end
                    if not tbl.DD_BGrp and not tbl.Vehicles[v[2]].DD_BGrp then
                        if plytbl.Vehicles[v[2]].BGroups then
                            for k2, v2 in pairs(plytbl.Vehicles[v[2]].BGroups) do
                                v[1]:GetEntity():SetBodygroup(k2, v2)
                            end
                        elseif tbl.Vehicles[v[2]].BGroups then
                            v[1]:GetEntity():SetBodyGroups(tbl.Vehicles[v[2]].BGroups)
                        end
                    end
                end
            end

            ModelView.RefreshCustomisation = nil
        end

        if ModelView.RefreshLeftData then ModelView.RefreshLeftData = nil end
    end

    Pnl:MakePopup()
end

function VC.CD.open_menu_main(NPC, tbl, plytbl, int)
    if not IsValid(VC.CD.Main_Pnl) then
        if not NPC.VC_LoadingMsg then
            VCPopup("CD_Loading", "info", 0.5)
            timer.Simple(0.1, function() DoMainMenu(NPC, tbl, plytbl, int) end)
            NPC.VC_LoadingMsg = true
        else
            DoMainMenu(NPC, tbl, plytbl, int)
        end
    end
end

function VC.CD.Buy_Vehicle(NPC, ID, settings)
    net.Start("VC_CD_Buy_Vehicle")
    net.WriteEntity(NPC)
    net.WriteString(ID)
    net.WriteTable(settings)
    net.SendToServer()
end

function VC.CD.Sell_Vehicle(NPC, ID)
    net.Start("VC_CD_Sell_Vehicle")
    net.WriteEntity(NPC)
    net.WriteString(ID)
    net.SendToServer()
end

function VC.CD.TestDrive(NPC, ID, settings)
    net.Start("VC_CD_StartTestDrive")
    net.WriteEntity(NPC)
    net.WriteString(ID)
    net.WriteTable(settings)
    net.SendToServer()
end

function VC.CD.EndTestDrive(nosend)
    VCPopup("TestDriveEnded")
    VC.CD.SpawnedTestDriveData = nil
    if VC.CD.Main_Pnl and VC.CD.Main_Pnl:IsVisible() then VC.CD.Main_Pnl.VC_RefreshModelList = 3 end
    if not nosend then
        net.Start("VC_CD_EndTestDrive")
        net.SendToServer()
    end
end

function VC.CD.Spawn(NPC, ID, tbl, settings, plytbl)
    if plytbl.Vehicles and plytbl.Vehicles[ID] and not plytbl.Vehicles[ID].Spawned then
        if tbl and tbl.Platforms then
            local pos, ang = VC.CD.GetSpawnPosAng(LocalPlayer(), tbl, NPC)
            if not pos or not ang then
                VCPopup("ParkingLotsTaken", "cross")
                return
            end

            plytbl.Vehicles[ID].Spawned = true
            net.Start("VC_CD_Spawn_Vehicle")
            net.WriteEntity(NPC)
            net.WriteString(ID)
            net.WriteTable(settings)
            net.SendToServer()
        end
    else
        VCPopup("Error spawning.", "cross")
    end
end

function VC.CD.Return(NPC, ID)
    net.Start("VC_CD_Return_Vehicle")
    net.WriteEntity(NPC)
    net.WriteString(ID)
    net.SendToServer()
end

function VC.CD.open_menu_choice(ent, tbl, plytbl, int)
    if not int then int = VC.CD.LastInt end
    if VC.CD.EditPlatorms and IsValid(VC.CD.EditPlatorms[1]) then
        VCPopup("Close platform editing menu first.", "cross")
        return
    end

    if not int then int = VC.CD.LastInt end
    if VC.CD.EditVehicles and IsValid(VC.CD.EditVehicles[1]) then
        VCPopup("Close vehicle editing menu first.", "cross")
        return
    end

    local Pnl = vgui.Create("DFrame")
    Pnl:SetSize(400, 200)
    Pnl:SetTitle("")
    Pnl:SetPos(ScrW() / 2 - Pnl:GetWide() / 2, ScrH() / 2 - Pnl:GetTall() / 2)
    Pnl:SetDraggable(false)
    Pnl:ShowCloseButton(false)
    Pnl:AlphaTo(0, 0, 0)
    Pnl:AlphaTo(255, 0.2, 0)
    Pnl.Paint = function(obj, Sx, Sy)
        draw.RoundedBox(0, 0, 0, Sx, Sy, VC.Color.Main)
        draw.DrawText("This menu is only visible to administrators.", "VC_Dev_Text", 10, 10, VC.Color.White, TEXT_ALIGN_LEFT)
    end

    local CarDealer = vgui.Create("VC_Button", Pnl)
    CarDealer:SetColor(VC.Color.Btn_Add)
    CarDealer:SetText("Dealer's menu")
    CarDealer:SetFont("VC_Big_Italic")
    CarDealer:SetSize(Pnl:GetWide() / 2 - 30, Pnl:GetTall() - 55)
    CarDealer:SetPos(20, 35)
    local CarDealer_Edit = vgui.Create("VC_Button", Pnl)
    CarDealer_Edit:SetColor(VC.Color.Btn_Chng)
    CarDealer_Edit:SetText("Edit menu")
    CarDealer_Edit:SetFont("VC_Big_Italic")
    CarDealer_Edit:SetSize(Pnl:GetWide() / 2 - 30, Pnl:GetTall() - 55)
    CarDealer_Edit:SetPos(Pnl:GetWide() / 2 + 10, 35)
    CarDealer.DoClick = function()
        VC.CD.open_menu_main(ent, tbl, plytbl, int)
        Pnl:Close()
    end

    CarDealer_Edit.DoClick = function()
        VC.CD.LastTbl = tbl or table.Copy(VC.CD.Default)
        VC.CD.LastInt = int
        if IsValid(ent) then
            VC.CD.LastNPC = ent
            VC.CD.open_menu_cardealer_edit(ent)
        end

        Pnl:Close()
    end

    Pnl:MakePopup()
end

function VC.CD.open_menu_cardealer_edit(ent)
    if IsValid(VC.CD_Edit_Panel) then
        VC.CD_Edit_Panel:Close()
        VC.CD_Edit_Panel = nil
    end

    if not IsValid(ent) then
        VCPopup("ERROR: missing car dealer entity!", "cross")
        return
    end

    local Pnl = vgui.Create("DFrame")
    VC.CD_Edit_Panel = Pnl
    Pnl:SetSize(600, 320)
    Pnl:SetTitle("")
    Pnl:SetPos(ScrW() / 2 - Pnl:GetWide() / 2, ScrH() / 2 - Pnl:GetTall() / 2)
    Pnl:ShowCloseButton(false)
    Pnl:AlphaTo(0, 0, 0)
    Pnl:AlphaTo(255, 0.2, 0)
    VC.CD.LastTbl.Pos = ent:GetPos()
    VC.CD.LastTbl.Ang = ent:GetAngles()
    VC.CD.LastTbl.Model = ent:GetModel()
    Pnl.Paint = function(obj, Sx, Sy)
        draw.RoundedBox(0, 0, 0, Sx, Sy, VC.Color.Main)
        draw.RoundedBox(0, 0, 0, Sx, 25, VC.Color.Main)
        draw.DrawText('VCMod Car Dealer Editor. Created: ' .. VC.time_elapsed_string(ent:GetNWInt("VC_Int", 0)) .. '.', "VC_Dev_Text", 7, 5, VC.Color.Blue, TEXT_ALIGN_LEFT)
        draw.RoundedBox(0, 10, 30, 155, 255, VC.Color.Main)
        draw.RoundedBox(0, 170, 30, 420, 30, VC.Color.Main)
        draw.RoundedBox(0, 170, 65, 420, 60, VC.Color.Main)
        draw.DrawText("Name:", "VC_Dev_Text", 15, 40, VC.Color.White, TEXT_ALIGN_LEFT)
        draw.DrawText("Model:", "VC_Dev_Text", 15, 215, VC.Color.White, TEXT_ALIGN_LEFT)
        draw.DrawText("Pos: " .. math.Round(VC.CD.LastTbl.Pos.x) .. ", " .. math.Round(VC.CD.LastTbl.Pos.y) .. ", " .. math.Round(VC.CD.LastTbl.Pos.z), "VC_Dev_Text", 15, 235, VC.Color.White, TEXT_ALIGN_LEFT)
        draw.DrawText("Ang: " .. math.Round(VC.CD.LastTbl.Ang.p) .. ", " .. math.Round(VC.CD.LastTbl.Ang.y) .. ", " .. math.Round(VC.CD.LastTbl.Ang.r), "VC_Dev_Text", 15, 255, VC.Color.White, TEXT_ALIGN_LEFT)
    end

    local delete = vgui.Create("VC_Button", Pnl)
    delete:SetToolTip("Delete the car dealer from the server and all the data files.")
    delete:SetText("Delete this car dealer")
    delete:SetSize(Pnl:GetWide() - 20, 20)
    delete:SetPos(10, Pnl:GetTall() - delete:GetTall() - 10)
    delete:SetColor(VC.Color.Btn_Rem)
    delete:SetTextIsWhite(true)
    delete.DoClick = function()
        net.Start("VC_CD_Delete")
        net.WriteEntity(ent)
        net.SendToServer()
        Pnl:Close()
        VC.CD.MM_Refresh = true
    end

    local done = vgui.Create("DImageButton", Pnl)
    done:SetMaterial(VC.Material.icon_check)
    done:SetToolTip("Close menu and save settings.")
    done:SetSize(20 + 15, 20)
    done:SetPos(Pnl:GetWide() - done:GetWide() - 2 - 15, 2)
    done.DoClick = function()
        net.Start("VC_CD_DoneEditting")
        net.WriteEntity(ent)
        net.WriteTable(VC.CD.LastTbl)
        net.WriteInt(VC.CD.LastInt, 8)
        net.WriteInt(1, 8)
        net.SendToServer()
        Pnl:Close()
        VC.CD.MM_Refresh = true
    end

    local cancel = vgui.Create("DImageButton", Pnl)
    cancel:SetMaterial(VC.Material.icon_cross)
    cancel:SetToolTip("Discard all settings and close.")
    cancel:SetSize(20, 20)
    cancel:SetPos(Pnl:GetWide() - cancel:GetWide() - 24 - 45, 2)
    cancel.DoClick = function()
        Pnl:Close()
        VC.CD.MM_Refresh = true
    end

    local opt = vgui.Create("DImageButton", Pnl)
    opt:SetMaterial(VC.Material.icon_paste)
    opt:SetToolTip("Import from other car dealers.")
    opt:SetSize(20, 20)
    opt:SetPos(Pnl:GetWide() - 65 - 60, 2)
    opt.DoClick = function()
        net.Start("VC_CD_ImportGetList")
        net.SendToServer()
    end

    local el_mdl = vgui.Create("DModelPanel", Pnl)
    el_mdl:SetModel(VC.CD.LastTbl.Model)
    el_mdl:SetCamPos(Vector(20, 0, 62))
    el_mdl:SetLookAt(Vector(0, 0, 62))
    el_mdl:SetSize(150, 150)
    el_mdl:SetPos(10, 50)
    function el_mdl:LayoutEntity()
        el_mdl:SetLookAt(Vector(0, math.sin(CurTime() * 2), 62))
        return
    end

    local el_name = vgui.Create("DTextEntry", Pnl)
    el_name:SetTall(20)
    el_name:SetWide(100)
    el_name:SetToolTip("Car dealer's name.")
    el_name:SetValue(VC.CD.LastTbl.Name)
    el_name:SetPos(60, 35)
    el_name.OnTextChanged = function()
        local val = el_name:GetValue()
        VC.CD.LastTbl.Name = val
    end

    local el_mdlname = vgui.Create("DTextEntry", Pnl)
    el_mdlname:SetTall(20)
    el_mdlname:SetWide(100)
    el_mdlname:SetToolTip("Car dealer's model. Enter it manually here or click on the image.")
    el_mdlname:SetValue(VC.CD.LastTbl.Model)
    el_mdlname:SetPos(60, 210)
    el_mdlname.OnTextChanged = function()
        local val = el_mdlname:GetValue()
        VC.CD.LastTbl.Model = val
        el_mdl:SetModel(val)
    end

    local function SetModel(mdl)
        el_mdlname:SetValue(mdl)
        el_mdl:GetEntity():SetModel(mdl)
        el_mdlname.OnTextChanged()
        local iSeq = el_mdl:GetEntity():LookupSequence("walk_all")
        if iSeq <= 0 then iSeq = el_mdl:GetEntity():LookupSequence("WalkUnarmed_all") end
        if iSeq <= 0 then iSeq = el_mdl:GetEntity():LookupSequence("walk_all_moderate") end
        if iSeq > 0 then el_mdl:GetEntity():ResetSequence(iSeq) end
    end

    el_mdl.DoClick = function()
        local DDM = VC.DermaMenu("Model")
        DDM:AddButton("Mossman", function() SetModel("models/mossman.mdl") end)
        DDM:AddButton("Barney", function() SetModel("models/Barney.mdl") end)
        DDM:AddButton("Breen", function() SetModel("models/breen.mdl") end)
        DDM:AddButton("Eli", function() SetModel("models/Eli.mdl") end)
        DDM:AddButton("GMan", function() SetModel("models/gman_high.mdl") end)
        DDM:AddButton("Kleiner", function() SetModel("models/Kleiner.mdl") end)
        DDM:AddButton("Father Grigory", function() SetModel("models/monk.mdl") end)
        DDM:AddButton("Vortigaunt", function() SetModel("models/vortigaunt.mdl") end)
        DDM:AddButton("Police", function() SetModel("models/Police.mdl") end)
        DDM:AddButton("Zombie", function() SetModel("models/Zombie/Classic.mdl") end)
        DDM:Open()
    end

    local El_List1 = VC.Add_El_List(175, 35, 410, 120, 2)
    El_List1:SetParent(Pnl)
    local MPnl = VC.Add_El_Panel(El_List1, {0.4, 0.6}, 25, true)
    local PlatformLable = vgui.Create("DLabel")
    PlatformLable:SetTextColor(VC.Color.White)
    PlatformLable:SetFont("VC_Dev_Text")
    MPnl[1]:AddItem(PlatformLable)
    local EditPlatform = vgui.Create("VC_Button", Pnl)
    EditPlatform:SetToolTip("Allows you to edit this NPC's spawn platforms.")
    EditPlatform:SetText("Manage")
    EditPlatform:SetSize(Pnl:GetWide() - 20, 20)
    MPnl[2]:AddItem(EditPlatform)
    EditPlatform:SetColor(Color(100, 155, 255, 255))
    EditPlatform:SetTextIsWhite(true)
    EditPlatform.DoClick = function()
        Pnl:Close()
        StartEditPlatforms(ent)
    end

    local El_List1 = VC.Add_El_List(175, 72, 410, 120, 2)
    El_List1:SetParent(Pnl)
    local MPnl = VC.Add_El_Panel(El_List1, {0.4, 0.6}, 25, true)
    local VehiclesLable = vgui.Create("DLabel")
    VehiclesLable:SetText("Vehicles: " .. table.Count(VC.CD.LastTbl.Vehicles))
    VehiclesLable:SetTextColor(VC.Color.White)
    VehiclesLable:SetFont("VC_Dev_Text")
    MPnl[1]:AddItem(VehiclesLable)
    local EditVehicles = vgui.Create("VC_Button", Pnl)
    EditVehicles:SetToolTip("Allows you to edit this NPC's vehicles.")
    EditVehicles:SetText("Manage")
    EditVehicles:SetSize(Pnl:GetWide() - 20, 20)
    MPnl[2]:AddItem(EditVehicles)
    EditVehicles:SetColor(VC.Color.White)
    EditVehicles:SetTextIsWhite(true)
    EditVehicles.DoClick = function()
        Pnl:Close()
        StartEditVehicles(ent)
    end

    local Veh_ARB = vgui.Create("VC_ARB")
    Veh_ARB:SetTall(20)
    El_List1:AddItem(Veh_ARB)
    Veh_ARB.RemoveButton = 3
    Veh_ARB.VC_BTbl = {
        {
            name = "Add",
            tooltip = "Add a new vehicle.",
            clk = function()
                local DDM = nil
                local cat = {}
                local cattest = {}
                for k, v in pairs(list.Get("Vehicles")) do
                    local tc = v.Category or "Unknown"
                    if not cattest[tc] then cattest[tc] = {} end
                    table.insert(cattest[tc], v)
                end

                for k, v in SortedPairs(cattest) do
                    local tempn = {}
                    for k2, v2 in pairs(v) do
                        tempn[v2.Name or "Unknown"] = v2
                    end

                    for k2, v2 in SortedPairs(tempn) do
                        if not VC.CD.LastTbl.Vehicles[VC.CD.getName(v2.Model, v2.Name, v2.DefaultSkin)] and v2.Class and VC.classIsSupported(string.lower(v2.Class)) then
                            if not DDM then DDM = VC.DermaMenu("Add vehicle") end
                            if not cat[k] then cat[k] = DDM:VC_AddSubMenu(k) end
                            cat[k]:AddButton(v2.Name or "Unknown", function()
                                VC.CD.open_menu_addcar(ent, nil, v2)
                                Pnl:Close()
                            end)
                        end
                    end
                end

                if DDM then DDM:Open() end
            end
        },
        {
            name = "Change",
            tooltip = "Change the current vehicles.",
            clk = function()
                local DDM = nil
                local cat = {}
                local cattest = {}
                for k, v in pairs(VC.CD.LastTbl.Vehicles) do
                    local tc = v.Category or "Unknown"
                    if not cattest[tc] then cattest[tc] = {} end
                    table.insert(cattest[tc], v)
                end

                for k, v in SortedPairs(cattest) do
                    local tempn = {}
                    for k2, v2 in pairs(v) do
                        tempn[v2.Name or "Unknown"] = v2
                    end

                    for k2, v2 in SortedPairs(tempn) do
                        if not DDM then DDM = VC.DermaMenu("Change vehicle") end
                        if not cat[k] then cat[k] = DDM:VC_AddSubMenu(k) end
                        v2.KeyValues = {
                            vehiclescript = v2.Handling
                        }

                        cat[v2.Category]:AddButton((v2.Name or "Unknown") .. ", skin " .. ((v2.DefaultSkin or 0) + 1), function()
                            VC.CD.open_menu_addcar(ent, nil, v2)
                            Pnl:Close()
                        end)
                    end
                end

                if DDM then DDM:Open() end
            end
        },
        {
            name = "Remove",
            tooltip = "Remove vehicle.",
            clk = function()
                local DDM = nil
                local cat = {}
                local cattest = {}
                for k, v in pairs(VC.CD.LastTbl.Vehicles) do
                    local tc = v.Category or "Unknown"
                    if not cattest[tc] then cattest[tc] = {} end
                    table.insert(cattest[tc], v)
                end

                for k, v in SortedPairs(cattest) do
                    local tempn = {}
                    for k2, v2 in pairs(v) do
                        tempn[v2.Name or "Unknown"] = v2
                    end

                    for k2, v2 in SortedPairs(tempn) do
                        if not DDM then DDM = VC.DermaMenu("Remove vehicle") end
                        if not cat[k] then cat[k] = DDM:VC_AddSubMenu(k) end
                        cat[v2.Category]:AddButton((v2.Name or "Unknown") .. ", skin " .. ((v2.DefaultSkin or 0) + 1), function()
                            net.Start("VC_CD_DeleteVehicle")
                            net.WriteEntity(ent)
                            net.WriteString(VC.CD.getName(v2.Model, v2.Name, v2.DefaultSkin))
                            net.SendToServer()
                        end)
                    end
                end

                if DDM then DDM:Open() end
            end
        }
    }

    local El_List1 = VC.Add_El_List(175, 135, 210, 48)
    El_List1:SetParent(Pnl)
    El_List1:NoClipping(true)
    El_List1.Paint = function(obj, Sx, Sy) draw.RoundedBox(0, -5, -5, Sx + 10, Sy + 10, VC.Color.Main) end
    local el_colour = VC.Add_El_Checkbox("Allow to customise colour", "Allows the vehicles to be customised.")
    El_List1:AddItem(el_colour)
    el_colour.OnChange = function(idx, val) VC.CD.LastTbl.DD_Clr = not val end
    local el_skin = VC.Add_El_Checkbox("Allow to customise skin (paintjob)", "Allows the vehicles to be customised.")
    El_List1:AddItem(el_skin)
    el_skin.OnChange = function(idx, val) VC.CD.LastTbl.DD_Skin = not val end
    local el_bgroup = VC.Add_El_Checkbox("Allow to customise bodygroups", "Allows the vehicles to be customised.")
    El_List1:AddItem(el_bgroup)
    el_bgroup.OnChange = function(idx, val) VC.CD.LastTbl.DD_BGrp = not val end
    local El_List1 = VC.Add_El_List(175, 198, 210, 82)
    El_List1:SetParent(Pnl)
    El_List1:NoClipping(true)
    El_List1.Paint = function(obj, Sx, Sy) draw.RoundedBox(0, -5, -5, Sx + 10, Sy + 10, VC.Color.Main) end
    if not VC.CD.LastTbl.RankRestrict then VC.CD.LastTbl.RankRestrict = {} end
    local ResE2L = {}
    for k, v in pairs(VC.getRanks()) do
        local el = VC.Add_El_Checkbox(v, "This rank is allowed to use this car delaer.")
        El_List1:AddItem(el)
        el.OnChange = function(idx, val) VC.CD.LastTbl.RankRestrict[k] = not val end
        ResE2L[k] = el
    end

    local ResElL = {}
    if RPExtraTeams then
        if not VC.CD.LastTbl.JobRestrict then VC.CD.LastTbl.JobRestrict = {} end
        local El_List1 = VC.Add_El_List(400, 135, 185, 145)
        El_List1:SetParent(Pnl)
        El_List1:NoClipping(true)
        El_List1.Paint = function(obj, Sx, Sy) draw.RoundedBox(0, -5, -5, Sx + 10, Sy + 10, VC.Color.Main) end
        for k, v in pairs(RPExtraTeams) do
            local nm = v.name or "Unknown"
            ResElL[nm] = VC.Add_El_Checkbox(nm, "This job is allowed to use this car dealer.")
            El_List1:AddItem(ResElL[nm])
            ResElL[nm].OnChange = function(idx, val) VC.CD.LastTbl.JobRestrict[nm] = not val end
        end
    end

    local function RefreshInfo()
        local tmdl = VC.CD.LastTbl.Model
        el_mdlname:SetValue(tmdl)
        SetModel(tmdl)
        el_mdlname.OnTextChanged()
        el_name:SetValue(VC.CD.LastTbl.Name)
        el_colour:SetValue(VC.CD.LastTbl.DD_Clr and 0 or 1)
        el_skin:SetValue(VC.CD.LastTbl.DD_Skin and 0 or 1)
        el_bgroup:SetValue(VC.CD.LastTbl.DD_BGrp and 0 or 1)
        if not VC.CD.LastTbl.RankRestrict then VC.CD.LastTbl.RankRestrict = {} end
        for k, v in pairs(VC.getRanks()) do
            if ResE2L[k] then ResE2L[k]:SetValue(not VC.CD.LastTbl.RankRestrict[k]) end
        end

        if RPExtraTeams then
            if not VC.CD.LastTbl.JobRestrict then VC.CD.LastTbl.JobRestrict = {} end
            for k, v in pairs(RPExtraTeams) do
                local nm = v.name or "Unknown"
                if ResElL[nm] then ResElL[nm]:SetValue(not VC.CD.LastTbl.JobRestrict[nm]) end
            end
        end

        local count = VC.CD.LastTbl.Platforms and #VC.CD.LastTbl.Platforms or 0
        PlatformLable:SetText("Spawn platforms: " .. count)
    end

    RefreshInfo()
    Pnl.Think = function()
        if VC.CD.Import then
            if not VC.CD.LastTbl then VC.CD.LastTbl = {} end
            if VC.CD.Import.Platforms then VC.CD.LastTbl.Platforms = table.Copy(VC.CD.Import.Platforms) end
            if VC.CD.Import.Vehicles then VC.CD.LastTbl.Vehicles = table.Copy(VC.CD.Import.Vehicles) end
            if VC.CD.Import.Name then VC.CD.LastTbl.Name = VC.CD.Import.Name end
            if VC.CD.Import.Model then VC.CD.LastTbl.Model = VC.CD.Import.Model end
            if VC.CD.Import.Model then VC.CD.LastTbl.Model = VC.CD.Import.Model end
            if VC.CD.Import.DD_Clr then VC.CD.LastTbl.DD_Clr = VC.CD.Import.DD_Clr end
            if VC.CD.Import.DD_Skin then VC.CD.LastTbl.DD_Skin = VC.CD.Import.DD_Skin end
            if VC.CD.Import.DD_BGrp then VC.CD.LastTbl.DD_BGrp = VC.CD.Import.DD_BGrp end
            if VC.CD.Import.RankRestrict then VC.CD.LastTbl.RankRestrict = VC.CD.Import.RankRestrict end
            if VC.CD.Import.JobRestrict then VC.CD.LastTbl.JobRestrict = VC.CD.Import.JobRestrict end
            RefreshInfo()
            VC.CD.RefreshVehicles = true
            VC.CD.Import = nil
            VCPopup("Done", "check")
        end

        if VC.CD.RefreshVehicles then
            VehiclesLable:SetText("Vehicles: " .. table.Count(VC.CD.LastTbl.Vehicles))
            VC.CD.RefreshVehicles = nil
        end
    end

    Pnl:MakePopup()
end

function VC.CD.DrawInfo(ent, text, key, textDist)
    if not ent.VC_PVsb then
        ent.VC_Color = VC.Color.White
        ent.VC_PVsb = util.GetPixelVisibleHandle()
    end

    local BInd = ent:LookupBone("ValveBiped.Bip01_Head1")
    local pos = Vector(0, 0, 0)
    if BInd then
        local BonePos, BoneAng = ent:GetBonePosition(ent:LookupBone("ValveBiped.Bip01_Head1"))
        pos = BonePos + Vector(0, 0, 8)
    else
        pos = ent:GetPos() + Vector(0, 0, 65)
    end

    local Vis = util.PixelVisible(pos + Vector(0, 0, 5), 1, ent.VC_PVsb)
    local Dist = nil
    if Vis > 0 then Dist = VC.GetViewPos():Distance(pos) end
    local on = Vis > 0 and Dist < textDist
    local anim = VC.UI_AnimData("CD_" .. key, on, 0.05, 0.02)
    if anim and ent.VC_LastPos_X and ent.VC_LastPos_Y then
        surface.SetFont("VC_Name")
        local tz = surface.GetTextSize(text or "")
        local Sx = math.Round(ent.VC_LastPos_X + (anim - 1) * 50)
        local Sy = math.Round(ent.VC_LastPos_Y - 25)
        local PSx, PSy = tz, 50
        local clr = table.Copy(VC.Color.Main)
        clr.a = clr.a * anim
        draw.RoundedBox(0, math.Round(Sx - PSx / 2) + 1, Sy, PSx, PSy, clr)
        surface.SetMaterial(VC.Material.Fade)
        surface.DrawTexturedRectRotated(math.Round(Sx + VC.FadeW / 2 + PSx / 2 + 1), Sy + PSy / 2, VC.FadeW, PSy, 0)
        surface.DrawTexturedRectRotated(math.Round(Sx - VC.FadeW / 2 - PSx / 2 + 1), Sy + PSy / 2, VC.FadeW, PSy, 180)
        local tclr = table.Copy(VC.Color.White)
        tclr.a = tclr.a * anim
        draw.SimpleText(text, "VC_Name", Sx, Sy + 25, tclr, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    local pos = (ent:GetPos() + Vector(0, 0, 75)):ToScreen()
    ent.VC_LastPos_X = math.Clamp(Lerp(0.2, ent.VC_LastPos_X or pos.x, pos.x), -200, ScrW() + 200)
    ent.VC_LastPos_Y = math.Clamp(Lerp(0.2, ent.VC_LastPos_Y or pos.y, pos.y), -200, ScrH() + 200)
end

local VC_KeyDownIn = nil
local VC_KeyDownDel = nil
function VC.CD.HUDPaint()
    local FTm = VC.FTm()
    local carDealers = ents.FindByClass("vc_npc_cardealer")
    if table.Count(carDealers) > 0 then
        local textDist = VC.getServerSetting("CD_Text_Dist", 500)
        for key, ent in pairs(ents.FindByClass("vc_npc_cardealer")) do
            local text = VC.getName(ent, VC.CD.Default.Name)
            if hook.Call("VC_CD_canRenderInfo", GAMEMODE, ent, text) ~= false and hook.Call("VC_CD_CanRenderInfo", GAMEMODE, ent, text) ~= false then VC.CD.DrawInfo(ent, text, key, textDist) end
        end
    end

    if VC.CD.EditPlatorms then
        local NPC = VC.CD.EditPlatorms[1]
        local PInsert, PEnd, PDel = input.IsKeyDown(KEY_INSERT) or input.IsKeyDown(KEY_LALT) and input.IsKeyDown(KEY_RIGHT), input.IsKeyDown(KEY_END) or input.IsKeyDown(KEY_LALT) and input.IsKeyDown(KEY_DOWN), input.IsKeyDown(KEY_DELETE) or input.IsKeyDown(KEY_LALT) and input.IsKeyDown(KEY_LEFT)
        if IsValid(NPC) and not PEnd then
            if PInsert and not VC_KeyDownIn then
                VC_KeyDownIn = true
            elseif VC_KeyDownIn and not PInsert then
                SpawnPlatform(NPC)
                VC_KeyDownIn = nil
            end

            if PDel and not VC_KeyDownDel then
                VC_KeyDownDel = true
            elseif VC_KeyDownDel and not PDel then
                DeletePlatform(NPC)
                VC_KeyDownDel = nil
            end

            local LineP = ScrH() * 0.15
            local NPCPos = (NPC:GetPos() + Vector(0, 0, 50)):ToScreen()
            draw.RoundedBox(0, 0, LineP, ScrW(), 50, Color(100, 155, 200, 155))
            for i = 1, 6 do
                surface.DrawLine(NPCPos.x, NPCPos.y, ScrW() / 2 - 3 + i, LineP + 50)
            end

            draw.SimpleText('[INSERT] or [LALT] + [RIGHT ARROW]   - Spawn new platform', nil, 10, LineP + 10, VC.Color.White, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            draw.SimpleText('[END] or [LALT] + [DOWN ARROW]   - Done editing', nil, 10, LineP + 25, VC.Color.White, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            draw.SimpleText('[DELETE] or [LALT] + [LEFT ARROW]   - Delete platform', nil, 10, LineP + 40, VC.Color.White, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            for i = 1, 6 do
                surface.DrawLine(NPCPos.x, NPCPos.y, ScrW() / 2 - 3 + i, LineP + 50)
            end

            draw.SimpleText('VCMod: Editing spawn platforms for car dealer: "' .. VC.getName(NPC, VC.Lng("Unknown")) .. '"', "VC_Name", ScrW() / 2, LineP + 25, VC.Color.White, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        else
            FinishEditPlatforms()
        end
    end

    if VC.CD.EditVehicles then
        local NPC = VC.CD.EditVehicles[1]
        local PInsert, PEnd, PDel = input.IsKeyDown(KEY_INSERT) or input.IsKeyDown(KEY_LALT) and input.IsKeyDown(KEY_RIGHT), input.IsKeyDown(KEY_END) or input.IsKeyDown(KEY_LALT) and input.IsKeyDown(KEY_DOWN), input.IsKeyDown(KEY_DELETE) or input.IsKeyDown(KEY_LALT) and input.IsKeyDown(KEY_LEFT)
        if IsValid(NPC) and not PEnd then
            if PInsert and not VC_KeyDownIn then
                VC_KeyDownIn = true
            elseif VC_KeyDownIn and not PInsert then
                InsertVehicle(NPC)
                VC_KeyDownIn = nil
            end

            if PDel and not VC_KeyDownDel then
                VC_KeyDownDel = true
            elseif VC_KeyDownDel and not PDel then
                DeleteVehicle(NPC)
                VC_KeyDownDel = nil
            end

            local LineP = ScrH() * 0.15
            local NPCPos = (NPC:GetPos() + Vector(0, 0, 50)):ToScreen()
            draw.RoundedBox(0, 0, LineP, ScrW(), 50, Color(255, 155, 0, 155))
            for i = 1, 6 do
                surface.DrawLine(NPCPos.x, NPCPos.y, ScrW() / 2 - 3 + i, LineP + 50)
            end

            draw.SimpleText('[INSERT] or [LALT] + [RIGHT ARROW]   - Insert vehicle', nil, 10, LineP + 10, VC.Color.White, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            draw.SimpleText('[END] or [LALT] + [DOWN ARROW]   - Done editing', nil, 10, LineP + 25, VC.Color.White, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            draw.SimpleText('[DELETE] or [LALT] + [LEFT ARROW]   - Remove vehicle', nil, 10, LineP + 40, VC.Color.White, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            for i = 1, 6 do
                surface.DrawLine(NPCPos.x, NPCPos.y, ScrW() / 2 - 3 + i, LineP + 50)
            end

            draw.SimpleText('VCMod: Editing vehicle list for car dealer: "' .. VC.getName(NPC, VC.Lng("Unknown")) .. '"', "VC_Name", ScrW() / 2, LineP + 25, VC.Color.White, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        else
            FinishEditVehicles()
        end
    end

    local FTm = VC.FTm()
    if VC.CD.SpawnedTestDriveData and not IsValid(VC.CD.SpawnedTestDriveData.Entity) then VC.CD.EndTestDrive() end
    if VC.CD.SpawnedVehicleData and (not IsValid(VC.CD.SpawnedVehicleData.Entity) or CurTime() >= VC.CD.SpawnedVehicleData.EndTime or IsValid(LocalPlayer():GetVehicle())) then VC.CD.SpawnedVehicleData = nil end
    local testdrivedistgood = VC.CD.SpawnedTestDriveData and VC.CD.SpawnedTestDriveData.Entity and VC.CD.SpawnedTestDriveData.Entity:GetPos():Distance(LocalPlayer():GetPos()) < 2000
    if VC.CD.SpawnedTestDriveData and (not VC.CD.TestDriveFade or VC.CD.TestDriveFade < 1) and testdrivedistgood then
        VC.CD.TestDriveFade = (VC.CD.TestDriveFade or 0) + 0.05 * FTm
        if VC.CD.TestDriveFade > 1 then VC.CD.TestDriveFade = 1 end
    elseif (not VC.CD.SpawnedTestDriveData or not testdrivedistgood) and VC.CD.TestDriveFade then
        VC.CD.TestDriveFade = VC.CD.TestDriveFade - 0.03 * FTm
        if VC.CD.TestDriveFade <= 0 then VC.CD.TestDriveFade = nil end
    end

    local drivedistgood = VC.CD.SpawnedVehicleData and VC.CD.SpawnedVehicleData.Entity and VC.CD.SpawnedVehicleData.Entity:GetPos():Distance(LocalPlayer():GetPos()) < 2000
    if VC.CD.SpawnedVehicleData and (not VC.CD.SpawnedDriveFade or VC.CD.SpawnedDriveFade < 1) and drivedistgood then
        VC.CD.SpawnedDriveFade = (VC.CD.SpawnedDriveFade or 0) + 0.03 * FTm
        if VC.CD.SpawnedDriveFade > 1 then VC.CD.SpawnedDriveFade = 1 end
    elseif (not VC.CD.SpawnedVehicleData or not drivedistgood) and VC.CD.SpawnedDriveFade then
        VC.CD.SpawnedDriveFade = VC.CD.SpawnedDriveFade - 0.02 * FTm
        if VC.CD.SpawnedDriveFade <= 0 then VC.CD.SpawnedDriveFade = nil end
    end

    if VC.CD.TestDriveFade then
        local Sx = ScrW() / 2 - (VC.CD.TestDriveFade - 1) * 50
        local Sy = 90
        local PSx, PSy = 500, 50
        local clr = table.Copy(VC.Color.Main)
        clr.a = clr.a * VC.CD.TestDriveFade
        draw.RoundedBox(0, Sx - PSx / 2, Sy, PSx, PSy, clr)
        surface.SetMaterial(VC.Material.Fade)
        surface.DrawTexturedRectRotated(Sx + VC.FadeW / 2 + PSx / 2, Sy + PSy / 2, VC.FadeW, PSy, 0)
        surface.DrawTexturedRectRotated(Sx + -VC.FadeW / 2 - PSx / 2, Sy + PSy / 2, VC.FadeW, PSy, 180)
        local timeleft = (VC.CD.SpawnedTestDriveData and VC.CD.SpawnedTestDriveData.EndTime or 0) - CurTime()
        if timeleft < 0 then timeleft = 0 end
        local min, sec = math.floor(timeleft / 60), math.floor(timeleft) % 60
        local tclr = table.Copy(VC.Color.Blue)
        tclr.a = tclr.a * VC.CD.TestDriveFade
        draw.SimpleText(VC.Lng('TestDriveTimeLeft'), "VC_Name", Sx + 70, Sy + 25, tclr, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
        local tclr = table.Copy(min == 0 and sec < 10 and VC.Color.Bad or VC.Color.White)
        tclr.a = tclr.a * VC.CD.TestDriveFade
        draw.SimpleText((min < 10 and "0" or "") .. tostring(min) .. ":" .. (sec < 10 and "0" or "") .. tostring(sec), "VC_Name", Sx + 110, Sy + 25, tclr, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    if VC.CD.SpawnedDriveFade then
        if VC.CD.SpawnedVehicleData_LastPos_X and VC.CD.SpawnedVehicleData_LastPos_Y then
            local text = VC.Lng('SpawnedVehicle')
            surface.SetFont("VC_Name")
            local tz = surface.GetTextSize(text or "")
            local Sx = math.Round(VC.CD.SpawnedVehicleData_LastPos_X + (VC.CD.SpawnedDriveFade - 1) * 50)
            local Sy = math.Round(VC.CD.SpawnedVehicleData_LastPos_Y - 25)
            local PSx, PSy = tz, 50
            local clr = table.Copy(VC.Color.Main)
            clr.a = clr.a * VC.CD.SpawnedDriveFade
            draw.RoundedBox(0, math.Round(Sx - PSx / 2), Sy, PSx, PSy, clr)
            surface.SetMaterial(VC.Material.Fade)
            surface.DrawTexturedRectRotated(math.Round(Sx + VC.FadeW / 2 + PSx / 2), Sy + PSy / 2, VC.FadeW, PSy, 0)
            surface.DrawTexturedRectRotated(math.Round(Sx + -VC.FadeW / 2 - PSx / 2), Sy + PSy / 2, VC.FadeW, PSy, 180)
            local tclr = table.Copy(VC.Color.Good)
            tclr.a = tclr.a * VC.CD.SpawnedDriveFade
            draw.SimpleText(text, "VC_Name", Sx, Sy + 25, tclr, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end

        if VC.CD.SpawnedVehicleData and VC.CD.SpawnedVehicleData.Entity then
            local pos = (VC.CD.SpawnedVehicleData.Entity:GetPos() + Vector(0, 0, 50)):ToScreen()
            VC.CD.SpawnedVehicleData_LastPos_X = math.Clamp(Lerp(0.1, VC.CD.SpawnedVehicleData_LastPos_X or pos.x, pos.x), -200, ScrW() + 200)
            VC.CD.SpawnedVehicleData_LastPos_Y = math.Clamp(Lerp(0.1, VC.CD.SpawnedVehicleData_LastPos_Y or pos.y, pos.y), -200, ScrH() + 200)
        end
    end
end

hook.Add("PostDrawTranslucentRenderables", "VC_CD_PostDrawTranslucentRenderables", function()
    if VC.CD.EditVehicles and IsValid(VC.CD.EditVehicles[1]) then
        render.SetMaterial(VC.Material.Beam)
        for k, v in pairs(VC.GetVehicleList()) do
            if IsValid(v) then
                local Has = nil
                for k2, v2 in pairs(VC.CD.LastTbl.Vehicles) do
                    if VC.GetModel(v) == v2.Model and VC.getName(v, VC.Lng("Unknown")) == (v2.Name or "Unknown") and v:GetSkin() == (v2.DefaultSkin or 0) then
                        Has = true
                        break
                    end
                end

                if Has then render.DrawBeam(v:GetPos() + v:GetUp() * 30, VC.CD.EditVehicles[1]:GetPos() + VC.CD.EditVehicles[1]:GetUp() * 50, 5, 1, 1, Color(200, 100, 0, 255)) end
            end
        end
    end
end)