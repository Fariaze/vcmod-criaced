VCModels['models/corvettecorvette.mdl']	=	{
		em_state	=	5236594515,
		SpecClass	=	"4b51a532e07f192390904281e93adb71",
		Copyright	=	"DurkaTeam @ 2025 No rights reserved",
		Exhaust	=	{
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-11.569999694824,-107.69000244141,15.449999809265),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(-7.2699999809265,-107.69000244141,15.449999809265),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(11.569999694824,-107.69000244141,15.449999809265),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				{
				Ang	=	Angle(0,-90,0),
				Pos	=	Vector(7.2699999809265,-107.69000244141,15.449999809265),
				EffectStress	=	"VC_Exhaust_Stress",
				EffectIdle	=	"VC_Exhaust",
					},
				},
		ExtraSeats	=	{
				{
				Ang	=	Angle(0,0,0),
				Pos	=	Vector(20.430000305176,-4.0700001716614,26.180000305176),
				RadioControl	=	true,
					},
				},
		DLT	=	3491063010,
		Lights	=	{
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						55,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(33.909999847412,-106.69000244141,42.259998321533),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				FogColor	=	{
						255,
						55,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(21.930000305176,-109.0299987793,42.259998321533),
				UseDynamic	=	true,
				UseBrake	=	true,
				UseFog	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseReverse	=	true,
				Pos	=	Vector(21.819999694824,-107.06999969482,17.639999389648),
				ReverseColor	=	{
						200,
						225,
						255,
						},
				SpecLine	=	{
					Amount	=	5,
					Pos	=	Vector(30.700000762939,-104.83999633789,17.180000305176),
					Use	=	true,
						},
				UseSprite	=	true,
				UseDynamic	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(45.080001831055,86.699996948242,24.229999542236),
				UseDynamic	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				SpecLine	=	{
					Amount	=	15,
					Pos	=	Vector(42.139999389648,95,24.059999465942),
					Use	=	true,
						},
				RenderInner_Size	=	1.2,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				Pos	=	Vector(38.340000152588,86.23999786377,32.069999694824),
				UseSprite	=	true,
				RunningColor	=	{
						216.54,
						189.87,
						214.84,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseHead	=	true,
				UsePrjTex	=	true,
				Pos	=	Vector(32.970001220703,90.269996643066,30.770000457764),
				UseDynamic	=	true,
				HeadColor	=	{
						219,
						215,
						255,
						},
				ProjTexture	=	{
					Forward	=	30,
					Size	=	2000,
					Angle	=	Angle(0,90,0),
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				FogColor	=	{
						220,
						225,
						255,
						},
				ProjTexture	=	{
					Size	=	2000,
					Angle	=	Angle(0,90,0),
						},
				UsePrjTex	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(-35.419998168945,94.849998474121,14.859999656677),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseFog	=	true,
				UseSprite	=	true,
				RenderInner_Size	=	1.2,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						55,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(-33.909999847412,-106.69000244141,42.259998321533),
				UseDynamic	=	true,
				UseBlinkers	=	true,
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				FogColor	=	{
						255,
						55,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(-21.930000305176,-109.0299987793,42.259998321533),
				UseDynamic	=	true,
				UseBrake	=	true,
				UseFog	=	true,
				BrakeColor	=	{
						255,
						55,
						0,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.2,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				UseReverse	=	true,
				Pos	=	Vector(-21.819999694824,-107.06999969482,17.639999389648),
				ReverseColor	=	{
						200,
						225,
						255,
						},
				SpecLine	=	{
					Amount	=	5,
					Pos	=	Vector(-30.700000762939,-104.83999633789,17.180000305176),
					Use	=	true,
						},
				UseSprite	=	true,
				UseDynamic	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(-45.080001831055,86.699996948242,24.229999542236),
				UseDynamic	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				SpecLine	=	{
					Amount	=	15,
					Pos	=	Vector(-42.139999389648,95,24.059999465942),
					Use	=	true,
						},
				RenderInner_Size	=	1.2,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				Pos	=	Vector(-38.340000152588,86.23999786377,32.069999694824),
				UseSprite	=	true,
				RunningColor	=	{
						216.54,
						189.87,
						214.84,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.8,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseHead	=	true,
				UsePrjTex	=	true,
				Pos	=	Vector(-32.970001220703,90.269996643066,30.770000457764),
				UseDynamic	=	true,
				HeadColor	=	{
						219,
						215,
						255,
						},
				UseSprite	=	true,
				ProjTexture	=	{
					Forward	=	30,
					Size	=	2000,
					Angle	=	Angle(0,90,0),
						},
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(-28.520000457764,91.879997253418,30.409999847412),
				UseDynamic	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1.2,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.08,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				Pos	=	Vector(45.180000305176,-88.120002746582,37.639999389648),
				UseRunning	=	true,
				SpecLine	=	{
					Amount	=	15,
					Pos	=	Vector(43.119998931885,-97.129997253418,38.229999542236),
					Use	=	true,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.075,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				Pos	=	Vector(45.180000305176,-88.120002746582,37.639999389648),
				UseSprite	=	true,
				RunningColor	=	{
						216.54,
						189.87,
						214.84,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				UseSprite	=	true,
				Pos	=	Vector(28.520000457764,91.879997253418,30.409999847412),
				UseDynamic	=	true,
				RenderInner	=	true,
				Beta_Inner3D	=	true,
				RenderInner_Size	=	1.2,
				UseBlinkers	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.6,
						},
				Dynamic	=	{
					Size	=	0.6,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				Pos	=	Vector(-35.419998168945,94.849998474121,14.859999656677),
				UseSprite	=	true,
				RunningColor	=	{
						216.54,
						189.87,
						214.84,
						},
				UseRunning	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.08,
						},
				Dynamic	=	{
					Size	=	0.275,
					Brightness	=	2,
						},
				UseDynamic	=	true,
				Pos	=	Vector(-45.180000305176,-88.120002746582,37.639999389648),
				UseRunning	=	true,
				SpecLine	=	{
					Amount	=	15,
					Pos	=	Vector(-43.119998931885,-97.129997253418,38.229999542236),
					Use	=	true,
						},
				RunningColor	=	{
						255,
						55,
						0,
						},
				UseSprite	=	true,
					},
				{
				Sprite	=	{
					GlowPrxSize	=	5,
					Size	=	0.4,
						},
				Dynamic	=	{
					Size	=	0.4,
					Brightness	=	2,
						},
				BlinkersColor	=	{
						255,
						155,
						0,
						},
				FogColor	=	{
						220,
						225,
						255,
						},
				ProjTexture	=	{
					Size	=	2000,
					Angle	=	Angle(0,90,0),
						},
				UsePrjTex	=	true,
				Beta_Inner3D	=	true,
				Pos	=	Vector(35.419998168945,94.849998474121,14.859999656677),
				UseDynamic	=	true,
				RenderInner	=	true,
				UseFog	=	true,
				UseSprite	=	true,
				RenderInner_Size	=	1.2,
				UseBlinkers	=	true,
					},
				},
		Date	=	"07/08/15 00:50:09",
		Author	=	"freemmaann (STEAM_0:1:14528726)",
}